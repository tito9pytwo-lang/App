package com.example

import android.app.Application
import com.example.data.BackTapRuntimeState
import com.example.service.BackTapAccessibilityService

class BackTapApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        BackTapRuntimeState.setAccessibilityEnabled(
            BackTapAccessibilityService.isAccessibilityServiceEnabled(this)
        )
    }
}
