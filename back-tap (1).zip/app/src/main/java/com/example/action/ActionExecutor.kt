package com.example.action

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.BackTapRuntimeState
import com.example.model.ActionExecutionOutcome
import com.example.model.TapActionConfig
import com.example.model.TapActionType
import com.example.service.BackTapAccessibilityService

class ActionExecutor(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == rearFlashCameraId) {
                isTorchOn = enabled
                BackTapRuntimeState.setFlashlightOn(enabled)
            }
        }
    }

    @Volatile
    private var isTorchOn = false
    private var rearFlashCameraId: String? = null
    private var torchRegistered = false

    init {
        rearFlashCameraId = findRearFlashCameraId()
        registerTorchCallback()
    }

    fun release() {
        if (torchRegistered) {
            runCatching { cameraManager?.unregisterTorchCallback(torchCallback) }
            torchRegistered = false
        }
    }

    fun execute(
        config: TapActionConfig,
        hapticEnabled: Boolean,
        isAppInForeground: Boolean
    ): ActionExecutionOutcome {
        if (config.type == TapActionType.NONE) {
            return ActionExecutionOutcome.ACTION_DISABLED
        }

        if (hapticEnabled) {
            triggerHapticPulse()
        }

        val outcome = when (config.type) {
            TapActionType.NONE -> ActionExecutionOutcome.ACTION_DISABLED
            TapActionType.TOGGLE_FLASHLIGHT -> toggleFlashlight()
            TapActionType.MEDIA_PLAY_PAUSE -> toggleMediaPlayback()
            TapActionType.TAKE_SCREENSHOT -> takeScreenshot()
            TapActionType.OPEN_CAMERA -> launchCamera(isAppInForeground)
            TapActionType.OPEN_SETTINGS -> launchSettings(isAppInForeground)
            TapActionType.OPEN_APP -> launchApp(
                packageName = config.targetPackage,
                appLabel = config.targetAppLabel,
                isAppInForeground = isAppInForeground
            )
        }

        BackTapRuntimeState.recordActionOutcome(outcome)
        return outcome
    }

    fun testLaunchPackage(packageName: String): ActionExecutionOutcome {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            } ?: return ActionExecutionOutcome.APP_NOT_FOUND

        return runCatching {
            context.startActivity(intent)
            ActionExecutionOutcome.SUCCESS
        }.getOrDefault(ActionExecutionOutcome.FAILED)
    }

    private fun toggleFlashlight(): ActionExecutionOutcome {
        val camId = rearFlashCameraId ?: findRearFlashCameraId()?.also { rearFlashCameraId = it }
            ?: return ActionExecutionOutcome.FLASHLIGHT_UNAVAILABLE
        val cm = cameraManager ?: return ActionExecutionOutcome.FLASHLIGHT_UNAVAILABLE

        return runCatching {
            val nextState = !isTorchOn
            cm.setTorchMode(camId, nextState)
            isTorchOn = nextState
            BackTapRuntimeState.setFlashlightOn(nextState)
            ActionExecutionOutcome.SUCCESS
        }.getOrDefault(ActionExecutionOutcome.FLASHLIGHT_UNAVAILABLE)
    }

    private fun toggleMediaPlayback(): ActionExecutionOutcome {
        val am = audioManager ?: return ActionExecutionOutcome.FAILED
        return runCatching {
            val eventTime = SystemClock.uptimeMillis()
            val downEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0)
            val upEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0)
            am.dispatchMediaKeyEvent(downEvent)
            am.dispatchMediaKeyEvent(upEvent)
            ActionExecutionOutcome.SUCCESS
        }.getOrDefault(ActionExecutionOutcome.FAILED)
    }

    private fun takeScreenshot(): ActionExecutionOutcome {
        val accessibilityService = BackTapAccessibilityService.instance
            ?: return ActionExecutionOutcome.NEEDS_ACCESSIBILITY_SERVICE
        return if (accessibilityService.takeScreenshot()) {
            ActionExecutionOutcome.SUCCESS
        } else {
            ActionExecutionOutcome.FAILED
        }
    }

    private fun launchCamera(isAppInForeground: Boolean): ActionExecutionOutcome {
        val stillCameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val resolvedIntent = if (stillCameraIntent.resolveActivity(context.packageManager) != null) {
            stillCameraIntent
        } else {
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
        return launchActivitySafely(
            intent = resolvedIntent,
            fallbackLabel = "Camera",
            isAppInForeground = isAppInForeground
        )
    }

    private fun launchSettings(isAppInForeground: Boolean): ActionExecutionOutcome {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return launchActivitySafely(
            intent = intent,
            fallbackLabel = "Settings",
            isAppInForeground = isAppInForeground
        )
    }

    private fun launchApp(
        packageName: String?,
        appLabel: String?,
        isAppInForeground: Boolean
    ): ActionExecutionOutcome {
        if (packageName.isNullOrBlank()) return ActionExecutionOutcome.APP_NOT_FOUND
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        } ?: return ActionExecutionOutcome.APP_NOT_FOUND

        return launchActivitySafely(
            intent = launchIntent,
            fallbackLabel = appLabel ?: packageName,
            isAppInForeground = isAppInForeground
        )
    }

    private fun launchActivitySafely(
        intent: Intent,
        fallbackLabel: String,
        isAppInForeground: Boolean
    ): ActionExecutionOutcome {
        val accessibilityService = BackTapAccessibilityService.instance
        if (accessibilityService != null) {
            val launched = accessibilityService.launchActivityFromBackground(intent)
            if (launched) return ActionExecutionOutcome.SUCCESS
        }

        if (isAppInForeground || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val launched = runCatching {
                context.startActivity(intent)
                true
            }.getOrDefault(false)
            if (launched) return ActionExecutionOutcome.SUCCESS
        }

        // Android 10+ background activity launch restriction fallback when AccessibilityService is off:
        // Post a high-priority quick-action notification so the user can tap once, and report status.
        postQuickActionNotification(intent, fallbackLabel)
        return ActionExecutionOutcome.NEEDS_ACCESSIBILITY_SERVICE
    }

    private fun postQuickActionNotification(intent: Intent, label: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALERT_CHANNEL_ID,
                context.getString(R.string.action_alert_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.action_alert_channel_desc)
            }
            nm.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            label.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(context.getString(R.string.action_alert_title, label))
            .setContentText(context.getString(R.string.action_alert_body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        runCatching { nm.notify(ALERT_NOTIFICATION_ID, notification) }
    }

    private fun registerTorchCallback() {
        val cm = cameraManager ?: return
        runCatching {
            cm.registerTorchCallback(torchCallback, null)
            torchRegistered = true
        }
    }

    private fun findRearFlashCameraId(): String? {
        val cm = cameraManager ?: return null
        return runCatching {
            val ids = cm.cameraIdList
            ids.firstOrNull { id ->
                val chars = cm.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: ids.firstOrNull { id ->
                cm.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        }.getOrNull()
    }

    private fun triggerHapticPulse() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(32L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createOneShot(32L, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(32L)
                }
            }
        }
    }

    companion object {
        private const val ALERT_CHANNEL_ID = "back_tap_action_alerts"
        private const val ALERT_NOTIFICATION_ID = 4042
    }
}
