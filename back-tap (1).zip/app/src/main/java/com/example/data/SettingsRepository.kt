package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.BackTapSettings
import com.example.model.TapActionConfig
import com.example.model.TapActionType
import com.example.model.ThemePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.backTapDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "back_tap_settings"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val SERVICE_ENABLED = booleanPreferencesKey("service_enabled")
        val DOUBLE_TAP_TYPE = stringPreferencesKey("double_tap_type")
        val DOUBLE_TAP_PACKAGE = stringPreferencesKey("double_tap_package")
        val DOUBLE_TAP_LABEL = stringPreferencesKey("double_tap_label")
        val TRIPLE_TAP_TYPE = stringPreferencesKey("triple_tap_type")
        val TRIPLE_TAP_PACKAGE = stringPreferencesKey("triple_tap_package")
        val TRIPLE_TAP_LABEL = stringPreferencesKey("triple_tap_label")
        val SENSITIVITY = floatPreferencesKey("sensitivity")
        val TAP_INTERVAL_MS = intPreferencesKey("tap_interval_ms")
        val ANTI_MOTION_FILTER = booleanPreferencesKey("anti_motion_filter")
        val PAUSE_SCREEN_OFF = booleanPreferencesKey("pause_screen_off")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val THEME_PREFERENCE = stringPreferencesKey("theme_preference")
        val LANGUAGE = stringPreferencesKey("app_language")
    }

    val settingsFlow: Flow<BackTapSettings> = context.backTapDataStore.data.map { prefs ->
        val doubleType = parseEnum(prefs[Keys.DOUBLE_TAP_TYPE], TapActionType.TOGGLE_FLASHLIGHT)
        val tripleType = parseEnum(prefs[Keys.TRIPLE_TAP_TYPE], TapActionType.OPEN_CAMERA)

        BackTapSettings(
            serviceEnabled = prefs[Keys.SERVICE_ENABLED] ?: false,
            doubleTapAction = TapActionConfig(
                type = doubleType,
                targetPackage = prefs[Keys.DOUBLE_TAP_PACKAGE],
                targetAppLabel = prefs[Keys.DOUBLE_TAP_LABEL]
            ),
            tripleTapAction = TapActionConfig(
                type = tripleType,
                targetPackage = prefs[Keys.TRIPLE_TAP_PACKAGE],
                targetAppLabel = prefs[Keys.TRIPLE_TAP_LABEL]
            ),
            sensitivity = (prefs[Keys.SENSITIVITY] ?: 0.60f).coerceIn(0.15f, 1.0f),
            tapIntervalMs = (prefs[Keys.TAP_INTERVAL_MS] ?: 420).coerceIn(250, 700),
            antiMotionFilterEnabled = prefs[Keys.ANTI_MOTION_FILTER] ?: true,
            pauseWhenScreenOff = prefs[Keys.PAUSE_SCREEN_OFF] ?: true,
            hapticFeedbackEnabled = prefs[Keys.HAPTIC_FEEDBACK] ?: true,
            themePreference = parseEnum(prefs[Keys.THEME_PREFERENCE], ThemePreference.SYSTEM),
            language = parseEnum(prefs[Keys.LANGUAGE], AppLanguage.ARABIC)
        )
    }

    suspend fun setServiceEnabled(enabled: Boolean) {
        context.backTapDataStore.edit { it[Keys.SERVICE_ENABLED] = enabled }
    }

    suspend fun setDoubleTapAction(config: TapActionConfig) {
        context.backTapDataStore.edit { prefs ->
            prefs[Keys.DOUBLE_TAP_TYPE] = config.type.name
            if (config.targetPackage != null) {
                prefs[Keys.DOUBLE_TAP_PACKAGE] = config.targetPackage
            } else {
                prefs.remove(Keys.DOUBLE_TAP_PACKAGE)
            }
            if (config.targetAppLabel != null) {
                prefs[Keys.DOUBLE_TAP_LABEL] = config.targetAppLabel
            } else {
                prefs.remove(Keys.DOUBLE_TAP_LABEL)
            }
        }
    }

    suspend fun setTripleTapAction(config: TapActionConfig) {
        context.backTapDataStore.edit { prefs ->
            prefs[Keys.TRIPLE_TAP_TYPE] = config.type.name
            if (config.targetPackage != null) {
                prefs[Keys.TRIPLE_TAP_PACKAGE] = config.targetPackage
            } else {
                prefs.remove(Keys.TRIPLE_TAP_PACKAGE)
            }
            if (config.targetAppLabel != null) {
                prefs[Keys.TRIPLE_TAP_LABEL] = config.targetAppLabel
            } else {
                prefs.remove(Keys.TRIPLE_TAP_LABEL)
            }
        }
    }

    suspend fun setSensitivity(sensitivity: Float) {
        context.backTapDataStore.edit {
            it[Keys.SENSITIVITY] = sensitivity.coerceIn(0.15f, 1.0f)
        }
    }

    suspend fun setTapIntervalMs(intervalMs: Int) {
        context.backTapDataStore.edit {
            it[Keys.TAP_INTERVAL_MS] = intervalMs.coerceIn(250, 700)
        }
    }

    suspend fun setAntiMotionFilterEnabled(enabled: Boolean) {
        context.backTapDataStore.edit { it[Keys.ANTI_MOTION_FILTER] = enabled }
    }

    suspend fun setPauseWhenScreenOff(enabled: Boolean) {
        context.backTapDataStore.edit { it[Keys.PAUSE_SCREEN_OFF] = enabled }
    }

    suspend fun setHapticFeedbackEnabled(enabled: Boolean) {
        context.backTapDataStore.edit { it[Keys.HAPTIC_FEEDBACK] = enabled }
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        context.backTapDataStore.edit { it[Keys.THEME_PREFERENCE] = theme.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.backTapDataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    private inline fun <reified T : Enum<T>> parseEnum(raw: String?, default: T): T {
        if (raw.isNullOrBlank()) return default
        return runCatching { enumValueOf<T>(raw) }.getOrDefault(default)
    }
}
