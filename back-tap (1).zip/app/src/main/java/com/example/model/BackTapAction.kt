package com.example.model

import android.graphics.drawable.Drawable

enum class TapActionType {
    NONE,
    OPEN_APP,
    OPEN_CAMERA,
    TOGGLE_FLASHLIGHT,
    TAKE_SCREENSHOT,
    MEDIA_PLAY_PAUSE,
    OPEN_SETTINGS
}

data class TapActionConfig(
    val type: TapActionType,
    val targetPackage: String? = null,
    val targetAppLabel: String? = null
)

data class InstalledAppInfo(
    val packageName: String,
    val label: String,
    val icon: Drawable? = null
)

enum class ThemePreference {
    SYSTEM,
    DARK,
    LIGHT
}

enum class AppLanguage {
    ARABIC,
    ENGLISH
}

data class BackTapSettings(
    val serviceEnabled: Boolean = false,
    val doubleTapAction: TapActionConfig = TapActionConfig(TapActionType.TOGGLE_FLASHLIGHT),
    val tripleTapAction: TapActionConfig = TapActionConfig(TapActionType.OPEN_CAMERA),
    val sensitivity: Float = 0.60f,
    val tapIntervalMs: Int = 420,
    val antiMotionFilterEnabled: Boolean = true,
    val pauseWhenScreenOff: Boolean = true,
    val hapticFeedbackEnabled: Boolean = true,
    val themePreference: ThemePreference = ThemePreference.SYSTEM,
    val language: AppLanguage = AppLanguage.ARABIC
)
