package com.example.model

enum class SensorMode {
    LINEAR_ACCEL_AND_GYRO,
    ACCEL_AND_GYRO,
    LINEAR_ACCEL_ONLY,
    ACCEL_ONLY,
    UNSUPPORTED
}

data class SensorCapabilities(
    val hasAccelerometer: Boolean = false,
    val hasLinearAcceleration: Boolean = false,
    val hasGyroscope: Boolean = false,
    val hasFlashlight: Boolean = false,
    val sensorMode: SensorMode = SensorMode.UNSUPPORTED,
    val accelerometerName: String? = null,
    val gyroscopeName: String? = null,
    val androidSdkInt: Int = android.os.Build.VERSION.SDK_INT
) {
    val isSupported: Boolean
        get() = sensorMode != SensorMode.UNSUPPORTED

    val isUsingFallback: Boolean
        get() = sensorMode == SensorMode.LINEAR_ACCEL_ONLY || sensorMode == SensorMode.ACCEL_ONLY
}

enum class ServiceState {
    STOPPED,
    ACTIVE,
    PAUSED_SCREEN_OFF,
    SENSOR_UNAVAILABLE
}

enum class DetectedGesture {
    RAW_TAP,
    DOUBLE_TAP,
    TRIPLE_TAP
}

enum class TapLogStatus {
    SINGLE_TAP,
    DOUBLE_TAP_CONFIRMED,
    TRIPLE_TAP_CONFIRMED,
    REJECTED_MOTION
}

data class TapLogEntry(
    val id: Long,
    val tapNumber: Int,
    val intensityMps2: Float,
    val intervalFromPrevMs: Long?,
    val status: TapLogStatus,
    val timestampMs: Long
)

data class TelemetrySnapshot(
    val timestampMs: Long = 0L,
    val accelX: Float = 0f,
    val accelY: Float = 0f,
    val accelZ: Float = 0f,
    val linearX: Float = 0f,
    val linearY: Float = 0f,
    val linearZ: Float = 0f,
    val magnitude3D: Float = 0f,
    val zAccel: Float = 0f,
    val xyAccel: Float = 0f,
    val gyroMagnitude: Float = 0f,
    val currentThreshold: Float = 2.7f
)

data class TapStats(
    val rawTapCount: Int = 0,
    val doubleTapCount: Int = 0,
    val tripleTapCount: Int = 0,
    val rejectedNoiseCount: Int = 0,
    val lastTapIntensity: Float = 0f,
    val lastInterTapMs: Long? = null,
    val doubleTapRecognized: Boolean = false,
    val lastGesture: DetectedGesture? = null,
    val lastActionResult: ActionExecutionOutcome? = null,
    val lastTapTimestampMs: Long = 0L
)

enum class ActionExecutionOutcome {
    SUCCESS,
    NEEDS_ACCESSIBILITY_SERVICE,
    APP_NOT_FOUND,
    FLASHLIGHT_UNAVAILABLE,
    ACTION_DISABLED,
    FAILED
}
