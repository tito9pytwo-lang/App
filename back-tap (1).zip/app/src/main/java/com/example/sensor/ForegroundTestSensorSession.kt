package com.example.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import com.example.data.BackTapRuntimeState
import com.example.model.BackTapSettings
import com.example.model.TapActionType
import com.example.model.TelemetrySnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * In-foreground SensorEventListener session used exclusively when the user is on the
 * Test Lab screen while the background ForegroundService is stopped.
 * Ensures continuous real-time sensor analysis during testing and clean unregistration on exit.
 */
class ForegroundTestSensorSession(
    context: Context,
    private val scope: CoroutineScope
) : SensorEventListener, TapDetectorEngine.Listener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val linearAccelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val gyroSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    private val tapDetectorEngine = TapDetectorEngine(this)
    private var currentSettings = BackTapSettings()
    private var doubleTapTimeoutJob: Job? = null
    private var isRegistered = false

    fun updateSettings(settings: BackTapSettings) {
        currentSettings = settings
        tapDetectorEngine.updateConfig(
            sensitivity = settings.sensitivity,
            tapIntervalMs = settings.tapIntervalMs,
            antiMotionFilterEnabled = settings.antiMotionFilterEnabled,
            tripleTapEnabled = settings.tripleTapAction.type != TapActionType.NONE
        )
    }

    fun start() {
        val sm = sensorManager ?: return
        if (isRegistered) return
        if (accelSensor == null && linearAccelSensor == null) return

        tapDetectorEngine.reset()
        accelSensor?.let { sm.registerListener(this, it, SENSOR_SAMPLING_US) }
        linearAccelSensor?.let { sm.registerListener(this, it, SENSOR_SAMPLING_US) }
        gyroSensor?.let { sm.registerListener(this, it, SENSOR_SAMPLING_US) }
        isRegistered = true
    }

    fun stop() {
        doubleTapTimeoutJob?.cancel()
        doubleTapTimeoutJob = null
        if (!isRegistered) return
        sensorManager?.unregisterListener(this)
        isRegistered = false
    }

    fun isRunning(): Boolean = isRegistered

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val timestampMs = SystemClock.elapsedRealtime()
        when (event.sensor.type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                tapDetectorEngine.onAccelerometerSample(
                    x = event.values[0],
                    y = event.values[1],
                    z = event.values[2],
                    timestampMs = timestampMs,
                    isLinearAcceleration = true
                )
            }

            Sensor.TYPE_ACCELEROMETER -> {
                tapDetectorEngine.onAccelerometerSample(
                    x = event.values[0],
                    y = event.values[1],
                    z = event.values[2],
                    timestampMs = timestampMs,
                    isLinearAcceleration = false
                )
            }

            Sensor.TYPE_GYROSCOPE -> {
                tapDetectorEngine.onGyroscopeSample(
                    gx = event.values[0],
                    gy = event.values[1],
                    gz = event.values[2],
                    timestampMs = timestampMs
                )
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onRawTap(
        chainCount: Int,
        intensityMps2: Float,
        intervalFromPrevMs: Long?,
        timestampMs: Long
    ) {
        BackTapRuntimeState.recordRawTap(timestampMs, intensityMps2, intervalFromPrevMs)
        if (chainCount == 2 && currentSettings.tripleTapAction.type != TapActionType.NONE) {
            doubleTapTimeoutJob?.cancel()
            doubleTapTimeoutJob = scope.launch {
                delay(currentSettings.tapIntervalMs.toLong() + 15L)
                tapDetectorEngine.checkPendingDoubleTap(SystemClock.elapsedRealtime())
            }
        } else if (chainCount >= 3) {
            doubleTapTimeoutJob?.cancel()
        }
    }

    override fun onDoubleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long) {
        doubleTapTimeoutJob?.cancel()
        BackTapRuntimeState.recordDoubleTap(timestampMs, intensityMps2, intervalMs)
    }

    override fun onTripleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long) {
        doubleTapTimeoutJob?.cancel()
        BackTapRuntimeState.recordTripleTap(timestampMs, intensityMps2, intervalMs)
    }

    override fun onRejectedNoise(intensityMps2: Float, timestampMs: Long) {
        BackTapRuntimeState.recordRejectedNoise(timestampMs, intensityMps2)
    }

    override fun onTelemetry(snapshot: TelemetrySnapshot) {
        BackTapRuntimeState.updateTelemetry(snapshot)
    }

    companion object {
        private const val SENSOR_SAMPLING_US = 10_000
    }
}
