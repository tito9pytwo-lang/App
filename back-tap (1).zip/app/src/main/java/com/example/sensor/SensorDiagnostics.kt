package com.example.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import com.example.model.SensorCapabilities
import com.example.model.SensorMode

object SensorDiagnostics {

    fun inspect(context: Context): SensorCapabilities {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val linearAccelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        val gyroSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        val hasAccel = accelSensor != null
        val hasLinear = linearAccelSensor != null
        val hasGyro = gyroSensor != null

        val mode = when {
            hasLinear && hasGyro -> SensorMode.LINEAR_ACCEL_AND_GYRO
            hasAccel && hasGyro -> SensorMode.ACCEL_AND_GYRO
            hasLinear -> SensorMode.LINEAR_ACCEL_ONLY
            hasAccel -> SensorMode.ACCEL_ONLY
            else -> SensorMode.UNSUPPORTED
        }

        val hasFlashlight = checkFlashlightAvailable(context)

        return SensorCapabilities(
            hasAccelerometer = hasAccel,
            hasLinearAcceleration = hasLinear,
            hasGyroscope = hasGyro,
            hasFlashlight = hasFlashlight,
            sensorMode = mode,
            accelerometerName = linearAccelSensor?.name ?: accelSensor?.name,
            gyroscopeName = gyroSensor?.name,
            androidSdkInt = Build.VERSION.SDK_INT
        )
    }

    private fun checkFlashlightAvailable(context: Context): Boolean {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return false
        return runCatching {
            cameraManager.cameraIdList.any { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        }.getOrDefault(false)
    }
}
