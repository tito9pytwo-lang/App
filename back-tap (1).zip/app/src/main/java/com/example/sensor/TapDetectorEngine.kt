package com.example.sensor

import com.example.model.TelemetrySnapshot
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Multi-axis Back Tap DSP engine.
 *
 * Analyzes full 3D acceleration (X, Y, Z) from both raw Accelerometer (high-pass filtered)
 * and Linear Acceleration, plus 3D Jerk and Peak Detection, with adaptive noise-floor
 * tracking, gyroscope rotation veto, and sustained shake rejection.
 */
class TapDetectorEngine(
    private val listener: Listener
) {
    interface Listener {
        fun onRawTap(chainCount: Int, intensityMps2: Float, intervalFromPrevMs: Long?, timestampMs: Long)
        fun onDoubleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long)
        fun onTripleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long)
        fun onRejectedNoise(intensityMps2: Float, timestampMs: Long)
        fun onTelemetry(snapshot: TelemetrySnapshot)
    }

    private var sensitivity: Float = 0.65f
    private var tapIntervalMs: Int = 480
    private var antiMotionFilterEnabled: Boolean = true
    private var tripleTapEnabled: Boolean = true

    // Raw Accelerometer high-pass state (fast gravity removal)
    private var gravityInitialized = false
    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var lastRawZ = 0f
    private var lastRawTimestampMs = -10_000L
    private var prevAccelHpX = 0f
    private var prevAccelHpY = 0f
    private var prevAccelHpZ = 0f
    private var hasPrevAccelHp = false

    // Linear Acceleration state
    private var lastLinearX = 0f
    private var lastLinearY = 0f
    private var lastLinearZ = 0f
    private var lastLinearMag3D = 0f
    private var lastLinearJerk3D = 0f
    private var lastLinearTimestampMs = -10_000L
    private var linearConsumed = true
    private var prevLinearX = 0f
    private var prevLinearY = 0f
    private var prevLinearZ = 0f
    private var hasPrevLinear = false

    // Adaptive baseline noise floor
    private var noiseFloor = 0f

    // Gyroscope veto state
    private var lastGyroMag = 0f
    private var lastGyroTimestampMs = -10_000L

    // Peak detection state
    private var trackingPeak = false
    private var peakStartMs = 0L
    private var peakMaxIntensity = 0f
    private var peakBestTimestampMs = 0L

    // Suppression and debounce state
    private var suppressUntilMs = -10_000L
    private var lastAcceptedTapMs = -10_000L
    private var lastNoiseReportedMs = -10_000L

    // Sustained shake detection window
    private val elevatedSamples = ArrayDeque<Long>()

    // Multi-tap state machine
    private var pendingTapCount = 0
    private var lastChainTapMs = -10_000L
    private var pendingDoubleTapDeadlineMs: Long? = null
    private var pendingDoubleTapIntensity = 0f
    private var pendingDoubleTapIntervalMs: Long? = null

    fun updateConfig(
        sensitivity: Float,
        tapIntervalMs: Int,
        antiMotionFilterEnabled: Boolean,
        tripleTapEnabled: Boolean
    ) {
        this.sensitivity = sensitivity.coerceIn(0.15f, 1.0f)
        this.tapIntervalMs = tapIntervalMs.coerceIn(250, 800)
        this.antiMotionFilterEnabled = antiMotionFilterEnabled
        this.tripleTapEnabled = tripleTapEnabled
    }

    fun reset() {
        gravityInitialized = false
        gravityX = 0f
        gravityY = 0f
        gravityZ = 0f
        lastRawX = 0f
        lastRawY = 0f
        lastRawZ = 0f
        lastRawTimestampMs = -10_000L
        prevAccelHpX = 0f
        prevAccelHpY = 0f
        prevAccelHpZ = 0f
        hasPrevAccelHp = false

        lastLinearX = 0f
        lastLinearY = 0f
        lastLinearZ = 0f
        lastLinearMag3D = 0f
        lastLinearJerk3D = 0f
        lastLinearTimestampMs = -10_000L
        linearConsumed = true
        prevLinearX = 0f
        prevLinearY = 0f
        prevLinearZ = 0f
        hasPrevLinear = false

        noiseFloor = 0f
        lastGyroMag = 0f
        lastGyroTimestampMs = -10_000L

        trackingPeak = false
        peakStartMs = 0L
        peakMaxIntensity = 0f
        peakBestTimestampMs = 0L

        suppressUntilMs = -10_000L
        lastAcceptedTapMs = -10_000L
        lastNoiseReportedMs = -10_000L
        elevatedSamples.clear()

        pendingTapCount = 0
        lastChainTapMs = -10_000L
        pendingDoubleTapDeadlineMs = null
        pendingDoubleTapIntensity = 0f
        pendingDoubleTapIntervalMs = null
    }

    /**
     * Maps sensitivity [0.15..1.0] to a realistic 3D peak acceleration threshold (m/s^2)
     * calibrated for real smartphone back taps (light ~1.4, medium ~2.7, firm ~4.6 m/s^2).
     */
    fun currentPeakThreshold(): Float = 5.2f - (sensitivity * 3.8f)

    fun onGyroscopeSample(gx: Float, gy: Float, gz: Float, timestampMs: Long) {
        val mag = sqrt(gx * gx + gy * gy + gz * gz)
        lastGyroMag = mag
        lastGyroTimestampMs = timestampMs
        if (antiMotionFilterEnabled && mag > GYRO_ROTATION_VETO_RAD_S) {
            suppressUntilMs = max(suppressUntilMs, timestampMs + GYRO_SUPPRESS_DURATION_MS)
            trackingPeak = false
        }
    }

    fun onAccelerometerSample(
        x: Float,
        y: Float,
        z: Float,
        timestampMs: Long,
        isLinearAcceleration: Boolean
    ) {
        checkPendingDoubleTap(timestampMs)

        if (isLinearAcceleration) {
            processLinearSample(x, y, z, timestampMs)
        } else {
            processRawAccelerometerSample(x, y, z, timestampMs)
        }
    }

    private fun processLinearSample(lx: Float, ly: Float, lz: Float, timestampMs: Long) {
        lastLinearX = lx
        lastLinearY = ly
        lastLinearZ = lz
        lastLinearTimestampMs = timestampMs

        val jerk3D = if (hasPrevLinear) {
            val dx = lx - prevLinearX
            val dy = ly - prevLinearY
            val dz = lz - prevLinearZ
            sqrt(dx * dx + dy * dy + dz * dz)
        } else 0f

        prevLinearX = lx
        prevLinearY = ly
        prevLinearZ = lz
        hasPrevLinear = true

        val mag3D = sqrt(lx * lx + ly * ly + lz * lz)
        lastLinearMag3D = mag3D
        lastLinearJerk3D = jerk3D
        linearConsumed = false

        // Drive evaluation directly only when raw TYPE_ACCELEROMETER is not actively streaming
        val rawAccelActive = (timestampMs - lastRawTimestampMs) <= 100L
        if (!rawAccelActive) {
            evaluateSample(
                mag3D = mag3D,
                jerk3D = jerk3D,
                xyMag = hypot(lx, ly),
                zVal = lz,
                timestampMs = timestampMs
            )
        }
    }

    private fun processRawAccelerometerSample(x: Float, y: Float, z: Float, timestampMs: Long) {
        lastRawX = x
        lastRawY = y
        lastRawZ = z
        lastRawTimestampMs = timestampMs

        if (!gravityInitialized) {
            gravityX = x
            gravityY = y
            gravityZ = z
            gravityInitialized = true
            prevAccelHpX = 0f
            prevAccelHpY = 0f
            prevAccelHpZ = 0f
            hasPrevAccelHp = true
            return
        }

        gravityX = GRAVITY_ALPHA * gravityX + (1f - GRAVITY_ALPHA) * x
        gravityY = GRAVITY_ALPHA * gravityY + (1f - GRAVITY_ALPHA) * y
        gravityZ = GRAVITY_ALPHA * gravityZ + (1f - GRAVITY_ALPHA) * z

        val hpX = x - gravityX
        val hpY = y - gravityY
        val hpZ = z - gravityZ

        val rawJerk3D = if (hasPrevAccelHp) {
            val dx = hpX - prevAccelHpX
            val dy = hpY - prevAccelHpY
            val dz = hpZ - prevAccelHpZ
            sqrt(dx * dx + dy * dy + dz * dz)
        } else 0f

        prevAccelHpX = hpX
        prevAccelHpY = hpY
        prevAccelHpZ = hpZ
        hasPrevAccelHp = true

        val rawHpMag = sqrt(hpX * hpX + hpY * hpY + hpZ * hpZ)
        val dtLinear = timestampMs - lastLinearTimestampMs
        val hasFreshLinear = !linearConsumed && dtLinear in 0L..60L &&
            (rawHpMag > currentPeakThreshold() * 0.35f || dtLinear <= 5L)

        val fusedMag = if (hasFreshLinear) max(rawHpMag, lastLinearMag3D) else rawHpMag
        val fusedJerk = if (hasFreshLinear) max(rawJerk3D, lastLinearJerk3D) else rawJerk3D
        linearConsumed = true
        val xyMag = hypot(hpX, hpY)

        evaluateSample(
            mag3D = fusedMag,
            jerk3D = fusedJerk,
            xyMag = xyMag,
            zVal = hpZ,
            timestampMs = timestampMs
        )
    }

    private fun evaluateSample(
        mag3D: Float,
        jerk3D: Float,
        xyMag: Float,
        zVal: Float,
        timestampMs: Long
    ) {
        val threshold = currentPeakThreshold()
        val effectiveNoiseFloor = noiseFloor.coerceAtMost(threshold * 0.45f)
        val netIntensity = (mag3D - effectiveNoiseFloor).coerceAtLeast(0f)

        // Update slow adaptive baseline only during quiet periods
        if (mag3D < threshold * 0.75f) {
            noiseFloor = 0.92f * noiseFloor + 0.08f * mag3D
        }

        val hasFreshLinear = (timestampMs - lastLinearTimestampMs) <= 150L
        listener.onTelemetry(
            TelemetrySnapshot(
                timestampMs = timestampMs,
                accelX = lastRawX,
                accelY = lastRawY,
                accelZ = lastRawZ,
                linearX = if (hasFreshLinear) lastLinearX else 0f,
                linearY = if (hasFreshLinear) lastLinearY else 0f,
                linearZ = if (hasFreshLinear) lastLinearZ else 0f,
                magnitude3D = mag3D,
                zAccel = zVal,
                xyAccel = xyMag,
                gyroMagnitude = if (timestampMs - lastGyroTimestampMs <= 250L) lastGyroMag else 0f,
                currentThreshold = threshold
            )
        )

        // Track elevated samples in a rolling window to reject continuous shaking / walking
        while (elevatedSamples.isNotEmpty() && timestampMs - elevatedSamples.first() > SHAKE_WINDOW_MS) {
            elevatedSamples.removeFirst()
        }
        if (mag3D > threshold * 0.75f) {
            elevatedSamples.addLast(timestampMs)
        }

        val jerkThreshold = threshold * 0.55f

        if (!trackingPeak) {
            if (netIntensity >= threshold && jerk3D >= jerkThreshold) {
                trackingPeak = true
                peakStartMs = timestampMs
                peakMaxIntensity = netIntensity
                peakBestTimestampMs = timestampMs
            }
            return
        }

        if (netIntensity > peakMaxIntensity) {
            peakMaxIntensity = netIntensity
            peakBestTimestampMs = timestampMs
        }

        val elapsedInPeak = timestampMs - peakStartMs
        val signalDropping = netIntensity < peakMaxIntensity * 0.78f
        if (signalDropping || elapsedInPeak >= PEAK_CAPTURE_WINDOW_MS) {
            val capturedIntensity = peakMaxIntensity
            val capturedTimestamp = peakBestTimestampMs
            trackingPeak = false
            finalizePeakCandidate(capturedIntensity, capturedTimestamp)
        }
    }

    private fun finalizePeakCandidate(intensityMps2: Float, timestampMs: Long) {
        if (antiMotionFilterEnabled) {
            val gyroActive = (timestampMs - lastGyroTimestampMs <= 200L) &&
                lastGyroMag > GYRO_ROTATION_VETO_RAD_S
            if (gyroActive || timestampMs < suppressUntilMs) {
                reportNoiseOnce(intensityMps2, timestampMs)
                return
            }

            if (elevatedSamples.size >= SUSTAINED_SHAKE_SAMPLE_COUNT) {
                suppressUntilMs = max(suppressUntilMs, timestampMs + SHAKE_SUPPRESS_DURATION_MS)
                pendingTapCount = 0
                pendingDoubleTapDeadlineMs = null
                reportNoiseOnce(intensityMps2, timestampMs)
                return
            }
        }

        // Refractory period prevents a single tap's rebound oscillation from counting twice
        if (timestampMs - lastAcceptedTapMs < REFRACTORY_PERIOD_MS) {
            return
        }

        acceptTap(intensityMps2, timestampMs)
    }

    fun checkPendingDoubleTap(nowMs: Long) {
        val deadline = pendingDoubleTapDeadlineMs ?: return
        if (pendingTapCount == 2 && nowMs >= deadline) {
            val intensity = pendingDoubleTapIntensity
            val interval = pendingDoubleTapIntervalMs
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
            listener.onDoubleTap(intensity, interval, nowMs)
        }
    }

    private fun acceptTap(intensityMps2: Float, timestampMs: Long) {
        val intervalFromPrev = if (lastAcceptedTapMs > 0L && (timestampMs - lastAcceptedTapMs) <= tapIntervalMs) {
            timestampMs - lastAcceptedTapMs
        } else {
            null
        }
        lastAcceptedTapMs = timestampMs

        if (pendingTapCount > 0 && (timestampMs - lastChainTapMs) > tapIntervalMs) {
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
        }

        pendingTapCount += 1
        lastChainTapMs = timestampMs

        listener.onRawTap(
            chainCount = pendingTapCount,
            intensityMps2 = intensityMps2,
            intervalFromPrevMs = intervalFromPrev,
            timestampMs = timestampMs
        )

        if (pendingTapCount == 2) {
            if (!tripleTapEnabled) {
                pendingTapCount = 0
                pendingDoubleTapDeadlineMs = null
                listener.onDoubleTap(intensityMps2, intervalFromPrev, timestampMs)
            } else {
                pendingDoubleTapIntensity = intensityMps2
                pendingDoubleTapIntervalMs = intervalFromPrev
                pendingDoubleTapDeadlineMs = timestampMs + tapIntervalMs
            }
        } else if (pendingTapCount >= 3) {
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
            listener.onTripleTap(intensityMps2, intervalFromPrev, timestampMs)
        }
    }

    private fun reportNoiseOnce(intensityMps2: Float, timestampMs: Long) {
        if (timestampMs - lastNoiseReportedMs >= NOISE_REPORT_COOLDOWN_MS) {
            lastNoiseReportedMs = timestampMs
            listener.onRejectedNoise(intensityMps2, timestampMs)
        }
    }

    companion object {
        private const val GRAVITY_ALPHA = 0.80f
        private const val GYRO_ROTATION_VETO_RAD_S = 3.5f
        private const val GYRO_SUPPRESS_DURATION_MS = 260L
        private const val SHAKE_WINDOW_MS = 350L
        private const val SUSTAINED_SHAKE_SAMPLE_COUNT = 14
        private const val SHAKE_SUPPRESS_DURATION_MS = 350L
        private const val PEAK_CAPTURE_WINDOW_MS = 32L
        private const val REFRACTORY_PERIOD_MS = 110L
        private const val NOISE_REPORT_COOLDOWN_MS = 350L
    }
}
