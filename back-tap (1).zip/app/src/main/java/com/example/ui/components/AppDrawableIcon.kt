package com.example.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Screenshot
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.model.TapActionType

@Composable
fun AppDrawableIcon(
    drawable: Drawable?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    val bitmap = remember(drawable) {
        drawable?.let {
            runCatching { it.toBitmap(width = 96, height = 96).asImageBitmap() }.getOrNull()
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = contentDescription,
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Apps,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(size * 0.58f)
            )
        }
    }
}

fun actionIcon(type: TapActionType): ImageVector = when (type) {
    TapActionType.NONE -> Icons.Rounded.Block
    TapActionType.OPEN_APP -> Icons.Rounded.Apps
    TapActionType.OPEN_CAMERA -> Icons.Rounded.CameraAlt
    TapActionType.TOGGLE_FLASHLIGHT -> Icons.Rounded.FlashlightOn
    TapActionType.TAKE_SCREENSHOT -> Icons.Rounded.Screenshot
    TapActionType.MEDIA_PLAY_PAUSE -> Icons.Rounded.PlayArrow
    TapActionType.OPEN_SETTINGS -> Icons.Rounded.Settings
}

@Composable
fun actionTint(type: TapActionType): Color = when (type) {
    TapActionType.NONE -> MaterialTheme.colorScheme.onSurfaceVariant
    TapActionType.OPEN_APP -> MaterialTheme.colorScheme.primary
    TapActionType.OPEN_CAMERA -> MaterialTheme.colorScheme.tertiary
    TapActionType.TOGGLE_FLASHLIGHT -> MaterialTheme.colorScheme.secondary
    TapActionType.TAKE_SCREENSHOT -> MaterialTheme.colorScheme.primary
    TapActionType.MEDIA_PLAY_PAUSE -> MaterialTheme.colorScheme.secondary
    TapActionType.OPEN_SETTINGS -> MaterialTheme.colorScheme.tertiary
}
