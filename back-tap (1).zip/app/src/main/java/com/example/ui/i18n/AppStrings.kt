package com.example.ui.i18n

import androidx.compose.runtime.staticCompositionLocalOf
import com.example.model.ActionExecutionOutcome
import com.example.model.AppLanguage
import com.example.model.SensorMode
import com.example.model.ServiceState
import com.example.model.TapActionConfig
import com.example.model.TapActionType
import com.example.model.ThemePreference

data class AppStrings(
    val appTitle: String,
    val appSubtitle: String,
    val navHome: String,
    val navTest: String,
    val navApps: String,
    val serviceActiveTitle: String,
    val servicePausedTitle: String,
    val serviceStoppedTitle: String,
    val serviceUnsupportedTitle: String,
    val serviceActiveSubtitle: String,
    val servicePausedSubtitle: String,
    val serviceStoppedSubtitle: String,
    val serviceUnsupportedSubtitle: String,
    val turnOnService: String,
    val turnOffService: String,
    val permissionsSectionTitle: String,
    val notificationPermTitle: String,
    val notificationPermDesc: String,
    val accessibilityPermTitle: String,
    val accessibilityPermDesc: String,
    val statusGranted: String,
    val statusRequired: String,
    val grantButton: String,
    val enableButton: String,
    val gesturesSectionTitle: String,
    val doubleTapTitle: String,
    val doubleTapDesc: String,
    val tripleTapTitle: String,
    val tripleTapDesc: String,
    val changeAction: String,
    val calibrationSectionTitle: String,
    val sensitivityLabel: String,
    val sensitivityLow: String,
    val sensitivityMedium: String,
    val sensitivityHigh: String,
    val tapIntervalLabel: String,
    val antiMotionTitle: String,
    val antiMotionDesc: String,
    val hapticTitle: String,
    val hapticDesc: String,
    val testHeroTitle: String,
    val testHeroDesc: String,
    val safeTestModeTitle: String,
    val safeTestModeDesc: String,
    val detectedTapsLabel: String,
    val doubleTapsLabel: String,
    val tripleTapsLabel: String,
    val rejectedNoiseLabel: String,
    val liveWaveformTitle: String,
    val thresholdLabel: String,
    val resetCounters: String,
    val liveLogTitle: String,
    val liveLogEmpty: String,
    val tapIntensityLabel: String,
    val interTapTimeLabel: String,
    val doubleTapStatusLabel: String,
    val doubleTapRecognizedYes: String,
    val doubleTapRecognizedNo: String,
    val tapStatusSingle: String,
    val tapStatusDouble: String,
    val tapStatusTriple: String,
    val tapStatusRejected: String,
    val accelLiveLabel: String,
    val linearLiveLabel: String,
    val guidedTestTitle: String,
    val guidedTestDesc: String,
    val startGuidedTest: String,
    val guidedStepDouble: String,
    val guidedStepTriple: String,
    val guidedStepShake: String,
    val guidedTestPassed: String,
    val skipShakeCheck: String,
    val hardwareCheckTitle: String,
    val sensorAccelLabel: String,
    val sensorLinearLabel: String,
    val sensorGyroLabel: String,
    val sensorFlashLabel: String,
    val availableLabel: String,
    val unavailableLabel: String,
    val fallbackModeNotice: String,
    val appsSectionTitle: String,
    val searchAppsHint: String,
    val assignToDoubleTap: String,
    val assignToTripleTap: String,
    val testOpenApp: String,
    val noAppsFound: String,
    val settingsSectionTitle: String,
    val themeLabel: String,
    val themeSystem: String,
    val themeDark: String,
    val themeLight: String,
    val languageLabel: String,
    val screenOffPauseTitle: String,
    val screenOffPauseDesc: String,
    val pickerTitleDouble: String,
    val pickerTitleTriple: String,
    val chooseInstalledApp: String,
    val actionNone: String,
    val actionOpenApp: String,
    val actionOpenCamera: String,
    val actionToggleFlashlight: String,
    val actionTakeScreenshot: String,
    val actionMediaPlayPause: String,
    val actionOpenSettings: String,
    val testActionNow: String,
    val closeLabel: String,
    val lastExecutionLabel: String
) {
    fun actionLabel(config: TapActionConfig): String = when (config.type) {
        TapActionType.NONE -> actionNone
        TapActionType.OPEN_APP -> config.targetAppLabel?.let { "$actionOpenApp: $it" } ?: actionOpenApp
        TapActionType.OPEN_CAMERA -> actionOpenCamera
        TapActionType.TOGGLE_FLASHLIGHT -> actionToggleFlashlight
        TapActionType.TAKE_SCREENSHOT -> actionTakeScreenshot
        TapActionType.MEDIA_PLAY_PAUSE -> actionMediaPlayPause
        TapActionType.OPEN_SETTINGS -> actionOpenSettings
    }

    fun actionShortName(type: TapActionType): String = when (type) {
        TapActionType.NONE -> actionNone
        TapActionType.OPEN_APP -> actionOpenApp
        TapActionType.OPEN_CAMERA -> actionOpenCamera
        TapActionType.TOGGLE_FLASHLIGHT -> actionToggleFlashlight
        TapActionType.TAKE_SCREENSHOT -> actionTakeScreenshot
        TapActionType.MEDIA_PLAY_PAUSE -> actionMediaPlayPause
        TapActionType.OPEN_SETTINGS -> actionOpenSettings
    }

    fun serviceStateTitle(state: ServiceState): String = when (state) {
        ServiceState.ACTIVE -> serviceActiveTitle
        ServiceState.PAUSED_SCREEN_OFF -> servicePausedTitle
        ServiceState.STOPPED -> serviceStoppedTitle
        ServiceState.SENSOR_UNAVAILABLE -> serviceUnsupportedTitle
    }

    fun serviceStateSubtitle(state: ServiceState): String = when (state) {
        ServiceState.ACTIVE -> serviceActiveSubtitle
        ServiceState.PAUSED_SCREEN_OFF -> servicePausedSubtitle
        ServiceState.STOPPED -> serviceStoppedSubtitle
        ServiceState.SENSOR_UNAVAILABLE -> serviceUnsupportedSubtitle
    }

    fun sensorModeLabel(mode: SensorMode): String = when (mode) {
        SensorMode.LINEAR_ACCEL_AND_GYRO -> "Linear Accel + Gyroscope"
        SensorMode.ACCEL_AND_GYRO -> "Accelerometer + Gyroscope"
        SensorMode.LINEAR_ACCEL_ONLY -> "Linear Accel (Fallback)"
        SensorMode.ACCEL_ONLY -> "Accelerometer (Fallback)"
        SensorMode.UNSUPPORTED -> unavailableLabel
    }

    fun themeLabel(pref: ThemePreference): String = when (pref) {
        ThemePreference.SYSTEM -> themeSystem
        ThemePreference.DARK -> themeDark
        ThemePreference.LIGHT -> themeLight
    }

    fun outcomeMessage(outcome: ActionExecutionOutcome, isArabic: Boolean): String = when (outcome) {
        ActionExecutionOutcome.SUCCESS -> if (isArabic) "تم تنفيذ الإجراء بنجاح" else "Action executed successfully"
        ActionExecutionOutcome.NEEDS_ACCESSIBILITY_SERVICE -> if (isArabic) "يتطلب تفعيل خدمة إمكانية الوصول للتشغيل من الخلفية" else "Enable Accessibility Service for background launches & screenshots"
        ActionExecutionOutcome.APP_NOT_FOUND -> if (isArabic) "التطبيق المحدد غير متوفر" else "Selected app could not be found"
        ActionExecutionOutcome.FLASHLIGHT_UNAVAILABLE -> if (isArabic) "المصباح غير متاح على هذا الجهاز" else "Flashlight unavailable on this device"
        ActionExecutionOutcome.ACTION_DISABLED -> if (isArabic) "الإجراء معطل" else "Action is disabled"
        ActionExecutionOutcome.FAILED -> if (isArabic) "تعذر تنفيذ الإجراء" else "Failed to execute action"
    }
}

val ArabicStrings = AppStrings(
    appTitle = "Back Tap",
    appSubtitle = "التحكم بالنقر على ظهر الهاتف",
    navHome = "الرئيسية",
    navTest = "الاختبار",
    navApps = "التطبيقات",
    serviceActiveTitle = "الخدمة نشطة وتعمل بالخلفية",
    servicePausedTitle = "متوقفة مؤقتاً (الشاشة مطفأة)",
    serviceStoppedTitle = "خدمة Back Tap متوقفة",
    serviceUnsupportedTitle = "المستشعر المطلوب غير متوفر",
    serviceActiveSubtitle = "تعمل أثناء استخدام التطبيقات الأخرى كواتساب والألعاب والمتصفح",
    servicePausedSubtitle = "سيتم الاستئناف تلقائياً فور تشغيل الشاشة لتوفير البطارية",
    serviceStoppedSubtitle = "اضغط لتشغيل مراقبة النقرات على ظهر الهاتف",
    serviceUnsupportedSubtitle = "هذا الجهاز لا يحتوي على مستشعر تسارع متوافق",
    turnOnService = "تشغيل الخدمة",
    turnOffService = "إيقاف الخدمة",
    permissionsSectionTitle = "جاهزية النظام والصلاحيات",
    notificationPermTitle = "إشعارات الخدمة بالخلفية",
    notificationPermDesc = "مطلوبة لإبقاء خدمة استشعار النقرات تعمل باستمرار في الخلفية",
    accessibilityPermTitle = "خدمة إمكانية الوصول (فتح التطبيقات ولقطة الشاشة)",
    accessibilityPermDesc = "تسمح لـ Back Tap بفتح التطبيقات والكاميرا وأخذ لقطة شاشة أثناء وجودك داخل تطبيقات أخرى",
    statusGranted = "مفعّل",
    statusRequired = "يحتاج تفعيل",
    grantButton = "منح الصلاحية",
    enableButton = "فتح الإعدادات",
    gesturesSectionTitle = "إيماءات النقر على ظهر الهاتف",
    doubleTapTitle = "نقرتان متتاليتان",
    doubleTapDesc = "انقر مرتين على ظهر الهاتف",
    tripleTapTitle = "ثلاث نقرات متتالية",
    tripleTapDesc = "انقر ثلاث مرات على ظهر الهاتف",
    changeAction = "تغيير الإجراء",
    calibrationSectionTitle = "إعدادات الحساسية ومنع الأخطاء",
    sensitivityLabel = "حساسية اكتشاف النقرات",
    sensitivityLow = "منخفضة (ضربات قوية)",
    sensitivityMedium = "متوازنة",
    sensitivityHigh = "عالية (نقرات خفيفة)",
    tapIntervalLabel = "الوقت الفاصل بين النقرات",
    antiMotionTitle = "منع الاهتزازات والحركات العادية",
    antiMotionDesc = "يستخدم الجيروسكوب وتحليل الاهتزاز المستمر لمنع التشغيل بالخطأ أثناء المشي أو تحريك الهاتف",
    hapticTitle = "اهتزاز تأكيدي عند النقر",
    hapticDesc = "إعطاء نبضة اهتزاز خفيفة عند تنفيذ الاختصار",
    testHeroTitle = "مختبر اختبار النقرات المباشر",
    testHeroDesc = "انقر مرتين على ظهر هاتفك الآن — يتم تحليل محاور X وY وZ لحظياً",
    safeTestModeTitle = "وضع الاختبار الآمن (بدون مغادرة الشاشة)",
    safeTestModeDesc = "يعد النقرات ويختبر الإيماءات هنا دون تنفيذ فتح التطبيقات فعلياً",
    detectedTapsLabel = "النقرات المكتشفة",
    doubleTapsLabel = "نقرتان",
    tripleTapsLabel = "ثلاث نقرات",
    rejectedNoiseLabel = "اهتزازات مرفوضة",
    liveWaveformTitle = "مؤشر التسارع الثلاثي 3D (X, Y, Z)",
    thresholdLabel = "عتبة النبضة",
    resetCounters = "تصفير العداد",
    liveLogTitle = "السجل المباشر للنقرات",
    liveLogEmpty = "اطرق على ظهر الهاتف لرؤية شدة كل نقرة والفاصل الزمني هنا",
    tapIntensityLabel = "شدة آخر نقرة",
    interTapTimeLabel = "الوقت بين النقرتين",
    doubleTapStatusLabel = "حالة النقرتين المتتاليتين",
    doubleTapRecognizedYes = "تم التعرف على نقرتين ✓",
    doubleTapRecognizedNo = "في انتظار نقرتين",
    tapStatusSingle = "نقرة مفردة",
    tapStatusDouble = "نقرتان متتاليتان ✓",
    tapStatusTriple = "ثلاث نقرات ✓",
    tapStatusRejected = "اهتزاز/حركة مرفوضة",
    accelLiveLabel = "التسارع (Accel)",
    linearLiveLabel = "الخطي (Linear)",
    guidedTestTitle = "اختبار التوافق العملي",
    guidedTestDesc = "تحقق عملياً من قدرة هاتفك على اكتشاف النقرات وتجاهل الاهتزازات",
    startGuidedTest = "بدء الاختبار العملي",
    guidedStepDouble = "الخطوة 1: انقر نقرتين متتاليتين على ظهر الهاتف",
    guidedStepTriple = "الخطوة 2: انقر ثلاث نقرات متتالية على ظهر الهاتف",
    guidedStepShake = "الخطوة 3: هز الهاتف حركة عادية للتحقق من عدم التشغيل بالخطأ",
    guidedTestPassed = "ممتاز! هاتفك يدعم Back Tap بدقة عالية ويعزل الاهتزازات بنجاح.",
    skipShakeCheck = "تأكيد اجتياز العزل",
    hardwareCheckTitle = "فحص مستشعرات الجهاز",
    sensorAccelLabel = "مستشعر التسارع (Accelerometer)",
    sensorLinearLabel = "التسارع الخطي (Linear Accel)",
    sensorGyroLabel = "الجيروسكوب (Gyroscope)",
    sensorFlashLabel = "فلاش الكاميرا (المصباح)",
    availableLabel = "متوفر",
    unavailableLabel = "غير متوفر",
    fallbackModeNotice = "الجيروسكوب غير متوفر في هذا الجهاز — يعمل التطبيق تلقائياً بخوارزمية التسارع البديلة.",
    appsSectionTitle = "قائمة التطبيقات المثبتة",
    searchAppsHint = "ابحث عن تطبيق...",
    assignToDoubleTap = "تعيين لنقرتين",
    assignToTripleTap = "تعيين لـ 3 نقرات",
    testOpenApp = "فتح تجريبي",
    noAppsFound = "لم يتم العثور على تطبيقات مطابقة",
    settingsSectionTitle = "المظهر والبطارية واللغة",
    themeLabel = "مظهر التطبيق",
    themeSystem = "تلقائي",
    themeDark = "داكن",
    themeLight = "فاتح",
    languageLabel = "لغة الواجهة",
    screenOffPauseTitle = "إيقاف مؤقت عند إطفاء الشاشة",
    screenOffPauseDesc = "يوقف قراءة المستشعرات عندما تكون الشاشة مغلقة لتقليل استهلاك البطارية",
    pickerTitleDouble = "اختر إجراء النقرتين",
    pickerTitleTriple = "اختر إجراء الثلاث نقرات",
    chooseInstalledApp = "اختيار تطبيق مثبت من القائمة",
    actionNone = "بدون إجراء (معطل)",
    actionOpenApp = "فتح تطبيق",
    actionOpenCamera = "فتح الكاميرا",
    actionToggleFlashlight = "تشغيل / إيقاف المصباح",
    actionTakeScreenshot = "التقاط لقطة شاشة",
    actionMediaPlayPause = "تشغيل / إيقاف الموسيقى",
    actionOpenSettings = "فتح الإعدادات",
    testActionNow = "تجربة الإجراء الآن",
    closeLabel = "إغلاق",
    lastExecutionLabel = "آخر تنفيذ"
)

val EnglishStrings = AppStrings(
    appTitle = "Back Tap",
    appSubtitle = "Control your phone by tapping the back",
    navHome = "Home",
    navTest = "Tap Lab",
    navApps = "Apps",
    serviceActiveTitle = "Service Active in Background",
    servicePausedTitle = "Paused (Screen Off)",
    serviceStoppedTitle = "Back Tap Service Stopped",
    serviceUnsupportedTitle = "Required Sensor Unavailable",
    serviceActiveSubtitle = "Works across WhatsApp, games, browsers, and other apps",
    servicePausedSubtitle = "Will automatically resume when screen turns on to save battery",
    serviceStoppedSubtitle = "Tap to start listening for back-of-device gestures",
    serviceUnsupportedSubtitle = "This device lacks a compatible accelerometer sensor",
    turnOnService = "Start Service",
    turnOffService = "Stop Service",
    permissionsSectionTitle = "System Readiness & Permissions",
    notificationPermTitle = "Background Service Notification",
    notificationPermDesc = "Required on Android 13+ to keep motion detection active reliably",
    accessibilityPermTitle = "Accessibility Service (App Launch & Screenshots)",
    accessibilityPermDesc = "Allows Back Tap to launch apps, camera, settings, and take screenshots while inside other apps",
    statusGranted = "Active",
    statusRequired = "Setup Needed",
    grantButton = "Grant",
    enableButton = "Open Settings",
    gesturesSectionTitle = "Back Tap Gestures",
    doubleTapTitle = "Double Tap",
    doubleTapDesc = "Tap twice on the back of your phone",
    tripleTapTitle = "Triple Tap",
    tripleTapDesc = "Tap three times on the back of your phone",
    changeAction = "Change Action",
    calibrationSectionTitle = "Sensitivity & False-Tap Protection",
    sensitivityLabel = "Tap Detection Sensitivity",
    sensitivityLow = "Low (Firm taps)",
    sensitivityMedium = "Balanced",
    sensitivityHigh = "High (Light taps)",
    tapIntervalLabel = "Max Interval Between Taps",
    antiMotionTitle = "Anti-Vibration & Motion Filter",
    antiMotionDesc = "Uses gyroscope and sustained shake filtering to prevent accidental triggers while walking or handling",
    hapticTitle = "Haptic Confirmation",
    hapticDesc = "Gentle vibration pulse when a shortcut triggers",
    testHeroTitle = "Live Back Tap Tester",
    testHeroDesc = "Tap the back of your phone twice — analyzing X, Y, Z axes in real time",
    safeTestModeTitle = "Safe Test Mode (Stay in App)",
    safeTestModeDesc = "Counts taps and tests gestures here without launching external apps",
    detectedTapsLabel = "Detected Taps",
    doubleTapsLabel = "Double Taps",
    tripleTapsLabel = "Triple Taps",
    rejectedNoiseLabel = "Rejected Shakes",
    liveWaveformTitle = "Live 3D Acceleration (X, Y, Z)",
    thresholdLabel = "Threshold",
    resetCounters = "Reset",
    liveLogTitle = "Live Tap Event Log",
    liveLogEmpty = "Tap the back of your phone to see each tap's intensity and interval here",
    tapIntensityLabel = "Last Intensity",
    interTapTimeLabel = "Inter-Tap Time",
    doubleTapStatusLabel = "Double Tap Status",
    doubleTapRecognizedYes = "Double Tap Recognized ✓",
    doubleTapRecognizedNo = "Waiting for Double Tap",
    tapStatusSingle = "Single Tap",
    tapStatusDouble = "Double Tap Confirmed ✓",
    tapStatusTriple = "Triple Tap Confirmed ✓",
    tapStatusRejected = "Motion / Shake Rejected",
    accelLiveLabel = "Accel",
    linearLiveLabel = "Linear",
    guidedTestTitle = "Practical Compatibility Test",
    guidedTestDesc = "Verify step-by-step that your hardware detects back taps and rejects normal motion",
    startGuidedTest = "Start Practical Test",
    guidedStepDouble = "Step 1: Perform a Double Tap on the back of your phone",
    guidedStepTriple = "Step 2: Perform a Triple Tap on the back of your phone",
    guidedStepShake = "Step 3: Gently shake your phone to verify false-tap rejection",
    guidedTestPassed = "Verified! Your phone supports Back Tap accurately and filters normal motion.",
    skipShakeCheck = "Confirm Motion Check",
    hardwareCheckTitle = "Hardware Sensor Diagnostics",
    sensorAccelLabel = "Accelerometer",
    sensorLinearLabel = "Linear Acceleration",
    sensorGyroLabel = "Gyroscope",
    sensorFlashLabel = "Camera Flashlight",
    availableLabel = "Available",
    unavailableLabel = "Unavailable",
    fallbackModeNotice = "Gyroscope not found on this device — running automatically with accelerometer fallback filtering.",
    appsSectionTitle = "Installed Apps",
    searchAppsHint = "Search installed apps...",
    assignToDoubleTap = "Set Double Tap",
    assignToTripleTap = "Set Triple Tap",
    testOpenApp = "Launch",
    noAppsFound = "No matching apps found",
    settingsSectionTitle = "Appearance, Battery & Language",
    themeLabel = "App Theme",
    themeSystem = "System",
    themeDark = "Dark",
    themeLight = "Light",
    languageLabel = "Language",
    screenOffPauseTitle = "Pause When Screen Is Off",
    screenOffPauseDesc = "Unregisters motion sensors while screen is locked for minimal battery drain",
    pickerTitleDouble = "Choose Double Tap Action",
    pickerTitleTriple = "Choose Triple Tap Action",
    chooseInstalledApp = "Pick an Installed App",
    actionNone = "Disabled (None)",
    actionOpenApp = "Open App",
    actionOpenCamera = "Open Camera",
    actionToggleFlashlight = "Toggle Flashlight",
    actionTakeScreenshot = "Take Screenshot",
    actionMediaPlayPause = "Play / Pause Media",
    actionOpenSettings = "Open Settings",
    testActionNow = "Test Action Now",
    closeLabel = "Close",
    lastExecutionLabel = "Last result"
)

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.ARABIC -> ArabicStrings
    AppLanguage.ENGLISH -> EnglishStrings
}

val LocalAppStrings = staticCompositionLocalOf { ArabicStrings }
