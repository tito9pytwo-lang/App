package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.ActionExecutionOutcome
import com.example.model.AppLanguage
import com.example.model.BackTapSettings
import com.example.model.InstalledAppInfo
import com.example.model.SensorCapabilities
import com.example.model.ServiceState
import com.example.model.TapActionConfig
import com.example.model.TapActionType
import com.example.model.TapStats
import com.example.ui.components.AppDrawableIcon
import com.example.ui.components.actionIcon
import com.example.ui.components.actionTint
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.MonoTelemetryStyle
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    settings: BackTapSettings,
    serviceState: ServiceState,
    sensorCapabilities: SensorCapabilities,
    accessibilityEnabled: Boolean,
    notificationPermissionGranted: Boolean,
    installedApps: List<InstalledAppInfo>,
    stats: TapStats,
    onToggleService: (Boolean) -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onEditDoubleTap: () -> Unit,
    onEditTripleTap: () -> Unit,
    onTestAction: (TapActionConfig) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onIntervalChange: (Int) -> Unit,
    onAntiMotionChange: (Boolean) -> Unit,
    onHapticChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val isArabic = settings.language == AppLanguage.ARABIC

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Service Power Hero Card
            item {
                ServiceHeroCard(
                    serviceEnabled = settings.serviceEnabled,
                    serviceState = serviceState,
                    sensorCapabilities = sensorCapabilities,
                    lastOutcome = stats.lastActionResult,
                    isArabic = isArabic,
                    onToggleService = onToggleService
                )
            }

            // 2. Permissions & Readiness Card
            item {
                PermissionsCard(
                    notificationGranted = notificationPermissionGranted,
                    accessibilityEnabled = accessibilityEnabled,
                    onRequestNotification = onRequestNotificationPermission,
                    onOpenAccessibility = onOpenAccessibilitySettings
                )
            }

            // 3. Double & Triple Tap Gesture Cards
            item {
                Text(
                    text = strings.gesturesSectionTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    GestureActionCard(
                        badgeText = "2x",
                        title = strings.doubleTapTitle,
                        subtitle = strings.doubleTapDesc,
                        actionConfig = settings.doubleTapAction,
                        installedApps = installedApps,
                        editButtonTag = "edit_double_tap_button",
                        testButtonTag = "test_double_tap_button",
                        onEditClick = onEditDoubleTap,
                        onTestClick = { onTestAction(settings.doubleTapAction) }
                    )
                    GestureActionCard(
                        badgeText = "3x",
                        title = strings.tripleTapTitle,
                        subtitle = strings.tripleTapDesc,
                        actionConfig = settings.tripleTapAction,
                        installedApps = installedApps,
                        editButtonTag = "edit_triple_tap_button",
                        testButtonTag = "test_triple_tap_button",
                        onEditClick = onEditTripleTap,
                        onTestClick = { onTestAction(settings.tripleTapAction) }
                    )
                }
            }

            // 4. Sensitivity & Anti-Motion Calibration Card
            item {
                CalibrationCard(
                    sensitivity = settings.sensitivity,
                    tapIntervalMs = settings.tapIntervalMs,
                    antiMotionEnabled = settings.antiMotionFilterEnabled,
                    hapticEnabled = settings.hapticFeedbackEnabled,
                    hasGyroscope = sensorCapabilities.hasGyroscope,
                    onSensitivityChange = onSensitivityChange,
                    onIntervalChange = onIntervalChange,
                    onAntiMotionChange = onAntiMotionChange,
                    onHapticChange = onHapticChange
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun ServiceHeroCard(
    serviceEnabled: Boolean,
    serviceState: ServiceState,
    sensorCapabilities: SensorCapabilities,
    lastOutcome: ActionExecutionOutcome?,
    isArabic: Boolean,
    onToggleService: (Boolean) -> Unit
) {
    val strings = LocalAppStrings.current
    val statusColor by animateColorAsState(
        targetValue = when (serviceState) {
            ServiceState.ACTIVE -> MaterialTheme.colorScheme.secondary
            ServiceState.PAUSED_SCREEN_OFF -> MaterialTheme.colorScheme.tertiary
            ServiceState.STOPPED -> MaterialTheme.colorScheme.onSurfaceVariant
            ServiceState.SENSOR_UNAVAILABLE -> MaterialTheme.colorScheme.error
        },
        label = "service_status_color"
    )

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = 1.dp,
            color = if (serviceState == ServiceState.ACTIVE) {
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            statusColor.copy(alpha = 0.14f),
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        color = statusColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Text(
                                text = strings.serviceStateTitle(serviceState),
                                style = MaterialTheme.typography.labelLarge,
                                color = statusColor
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Sensors,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = strings.sensorModeLabel(sensorCapabilities.sensorMode),
                                style = MonoTelemetryStyle.copy(
                                    fontSize = MaterialTheme.typography.labelSmall.fontSize
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Text(
                    text = strings.serviceStateSubtitle(serviceState),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = { onToggleService(!serviceEnabled) },
                    enabled = sensorCapabilities.isSupported,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (serviceEnabled) {
                            MaterialTheme.colorScheme.errorContainer
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        contentColor = if (serviceEnabled) {
                            MaterialTheme.colorScheme.onErrorContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimary
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("service_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PowerSettingsNew,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (serviceEnabled) strings.turnOffService else strings.turnOnService,
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                if (lastOutcome != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${strings.lastExecutionLabel}: ${strings.outcomeMessage(lastOutcome, isArabic)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (lastOutcome == ActionExecutionOutcome.SUCCESS) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                MaterialTheme.colorScheme.tertiary
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionsCard(
    notificationGranted: Boolean,
    accessibilityEnabled: Boolean,
    onRequestNotification: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    val strings = LocalAppStrings.current

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = strings.permissionsSectionTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Accessibility Service row (required for Android 10+ background app launch & screenshots)
            PermissionStatusRow(
                icon = Icons.Rounded.AccessibilityNew,
                title = strings.accessibilityPermTitle,
                description = strings.accessibilityPermDesc,
                granted = accessibilityEnabled,
                actionLabel = strings.enableButton,
                buttonTag = "enable_accessibility_button",
                onAction = onOpenAccessibility
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                PermissionStatusRow(
                    icon = Icons.Rounded.NotificationsActive,
                    title = strings.notificationPermTitle,
                    description = strings.notificationPermDesc,
                    granted = notificationGranted,
                    actionLabel = strings.grantButton,
                    buttonTag = "grant_notifications_button",
                    onAction = onRequestNotification
                )
            }
        }
    }
}

@Composable
private fun PermissionStatusRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    granted: Boolean,
    actionLabel: String,
    buttonTag: String,
    onAction: () -> Unit
) {
    val strings = LocalAppStrings.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            color = if (granted) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.tertiaryContainer
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.size(42.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (granted) Icons.Rounded.CheckCircle else icon,
                    contentDescription = null,
                    tint = if (granted) {
                        MaterialTheme.colorScheme.secondary
                    } else {
                        MaterialTheme.colorScheme.tertiary
                    },
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Surface(
                    color = if (granted) {
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)
                    } else {
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f)
                    },
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        text = if (granted) strings.statusGranted else strings.statusRequired,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (granted) {
                            MaterialTheme.colorScheme.secondary
                        } else {
                            MaterialTheme.colorScheme.tertiary
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (!granted) {
            OutlinedButton(
                onClick = onAction,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag(buttonTag)
            ) {
                Text(
                    text = actionLabel,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
private fun GestureActionCard(
    badgeText: String,
    title: String,
    subtitle: String,
    actionConfig: TapActionConfig,
    installedApps: List<InstalledAppInfo>,
    editButtonTag: String,
    testButtonTag: String,
    onEditClick: () -> Unit,
    onTestClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    val matchedApp = if (actionConfig.type == TapActionType.OPEN_APP && actionConfig.targetPackage != null) {
        installedApps.firstOrNull { it.packageName == actionConfig.targetPackage }
    } else null

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = badgeText,
                            style = MonoTelemetryStyle.copy(
                                fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (actionConfig.type != TapActionType.NONE) {
                    FilledTonalIconButton(
                        onClick = onTestClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag(testButtonTag)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = strings.testActionNow
                        )
                    }
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (matchedApp != null) {
                            AppDrawableIcon(
                                drawable = matchedApp.icon,
                                contentDescription = matchedApp.label,
                                size = 32.dp
                            )
                        } else {
                            Icon(
                                imageVector = actionIcon(actionConfig.type),
                                contentDescription = null,
                                tint = actionTint(actionConfig.type),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            text = strings.actionLabel(actionConfig),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    FilledTonalButton(
                        onClick = onEditClick,
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag(editButtonTag)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.changeAction,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalibrationCard(
    sensitivity: Float,
    tapIntervalMs: Int,
    antiMotionEnabled: Boolean,
    hapticEnabled: Boolean,
    hasGyroscope: Boolean,
    onSensitivityChange: (Float) -> Unit,
    onIntervalChange: (Int) -> Unit,
    onAntiMotionChange: (Boolean) -> Unit,
    onHapticChange: (Boolean) -> Unit
) {
    val strings = LocalAppStrings.current
    val sensitivityPercent = (sensitivity * 100f).roundToInt()
    val sensitivityDesc = when {
        sensitivity < 0.40f -> strings.sensitivityLow
        sensitivity > 0.72f -> strings.sensitivityHigh
        else -> strings.sensitivityMedium
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.calibrationSectionTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Sensitivity slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.sensitivityLabel,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "$sensitivityPercent% ($sensitivityDesc)",
                        style = MonoTelemetryStyle,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = sensitivity,
                    onValueChange = onSensitivityChange,
                    valueRange = 0.15f..1.0f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sensitivity_slider")
                )
            }

            // Tap Interval slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.tapIntervalLabel,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "${tapIntervalMs} ms",
                        style = MonoTelemetryStyle,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = tapIntervalMs.toFloat(),
                    onValueChange = { onIntervalChange(it.roundToInt()) },
                    valueRange = 250f..700f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("interval_slider")
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Anti-motion filter toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (hasGyroscope) Icons.Rounded.TouchApp else Icons.Rounded.WarningAmber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Column {
                        Text(
                            text = strings.antiMotionTitle,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = strings.antiMotionDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Switch(
                    checked = antiMotionEnabled,
                    onCheckedChange = onAntiMotionChange,
                    modifier = Modifier.testTag("anti_motion_switch")
                )
            }

            // Haptic feedback toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Vibration,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(
                            text = strings.hapticTitle,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = strings.hapticDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Switch(
                    checked = hapticEnabled,
                    onCheckedChange = onHapticChange,
                    modifier = Modifier.testTag("haptic_switch")
                )
            }
        }
    }
}
