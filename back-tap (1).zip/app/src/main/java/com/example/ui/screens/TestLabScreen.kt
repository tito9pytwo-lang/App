package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.TapPulseEvent
import com.example.model.SensorCapabilities
import com.example.model.ServiceState
import com.example.model.TapLogEntry
import com.example.model.TapLogStatus
import com.example.model.TapStats
import com.example.model.TelemetrySnapshot
import com.example.ui.components.BackTapPulseCanvas
import com.example.ui.components.LiveAccelerationWaveform
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.MonoTelemetryStyle
import com.example.ui.viewmodel.GuidedTestStep
import kotlinx.coroutines.flow.SharedFlow
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun TestLabScreen(
    serviceState: ServiceState,
    sensorCapabilities: SensorCapabilities,
    telemetry: TelemetrySnapshot,
    waveformSamples: List<Float>,
    stats: TapStats,
    tapLogs: List<TapLogEntry>,
    sensitivity: Float,
    safeTestMode: Boolean,
    guidedTestStep: GuidedTestStep,
    pulseEvents: SharedFlow<TapPulseEvent>,
    onToggleService: (Boolean) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onSafeTestModeChange: (Boolean) -> Unit,
    onResetStats: () -> Unit,
    onStartGuidedTest: () -> Unit,
    onCompleteShakeManually: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Live Tap Tester Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.testHeroTitle,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = strings.testHeroDesc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(
                                onClick = onResetStats,
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("reset_stats_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.resetCounters)
                            }
                        }

                        BackTapPulseCanvas(
                            serviceState = if (sensorCapabilities.isSupported) ServiceState.ACTIVE else serviceState,
                            rawTapCount = stats.rawTapCount,
                            pulseEvents = pulseEvents
                        )

                        // Double-Tap Recognition Live Status Banner
                        Surface(
                            color = if (stats.doubleTapRecognized) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = strings.doubleTapStatusLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (stats.doubleTapRecognized) {
                                        strings.doubleTapRecognizedYes
                                    } else {
                                        strings.doubleTapRecognizedNo
                                    },
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (stats.doubleTapRecognized) {
                                        MaterialTheme.colorScheme.secondary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }

                        // Counters Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CounterMetricTile(
                                label = strings.doubleTapsLabel,
                                value = stats.doubleTapCount.toString(),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            CounterMetricTile(
                                label = strings.tapIntensityLabel,
                                value = if (stats.lastTapIntensity > 0f) {
                                    String.format(Locale.US, "%.1f", stats.lastTapIntensity)
                                } else "--",
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.weight(1f)
                            )
                            CounterMetricTile(
                                label = strings.interTapTimeLabel,
                                value = stats.lastInterTapMs?.let { "${it}ms" } ?: "--",
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            CounterMetricTile(
                                label = strings.rejectedNoiseLabel,
                                value = stats.rejectedNoiseCount.toString(),
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Quick Sensitivity Tuning directly in Test Lab
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.sensitivityLabel,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "${(sensitivity * 100f).roundToInt()}%",
                                    style = MonoTelemetryStyle,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = sensitivity,
                                onValueChange = onSensitivityChange,
                                valueRange = 0.15f..1.0f,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("test_lab_sensitivity_slider")
                            )
                        }

                        // Safe Test Mode Toggle
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.safeTestModeTitle,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = strings.safeTestModeDesc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = safeTestMode,
                                    onCheckedChange = onSafeTestModeChange,
                                    modifier = Modifier.testTag("safe_test_mode_switch")
                                )
                            }
                        }

                        if (serviceState == ServiceState.STOPPED && sensorCapabilities.isSupported) {
                            OutlinedButton(
                                onClick = { onToggleService(true) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("test_lab_start_service_button")
                            ) {
                                Text(strings.turnOnService)
                            }
                        }
                    }
                }
            }

            // 2. Live 3D Waveform & Real-Time X/Y/Z Sensor Telemetry Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.liveWaveformTitle,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "${strings.thresholdLabel}: ${
                                    String.format(Locale.US, "%.2f", telemetry.currentThreshold)
                                } m/s²",
                                style = MonoTelemetryStyle,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }

                        LiveAccelerationWaveform(
                            samples = waveformSamples,
                            threshold = telemetry.currentThreshold
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "${strings.accelLiveLabel}: X=${fmt(telemetry.accelX)}  Y=${fmt(telemetry.accelY)}  Z=${fmt(telemetry.accelZ)}",
                                    style = MonoTelemetryStyle,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${strings.linearLiveLabel}: X=${fmt(telemetry.linearX)}  Y=${fmt(telemetry.linearY)}  Z=${fmt(telemetry.linearZ)}",
                                    style = MonoTelemetryStyle,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "3D Mag: ${String.format(Locale.US, "%.2f", telemetry.magnitude3D)} m/s²",
                                        style = MonoTelemetryStyle,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = "Gyro: ${String.format(Locale.US, "%.2f", telemetry.gyroMagnitude)} rad/s",
                                        style = MonoTelemetryStyle,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Live Tap Event Log Card
            item {
                LiveTapLogCard(logs = tapLogs)
            }

            // 4. Guided Practical Compatibility Test Card
            item {
                GuidedPracticalTestCard(
                    step = guidedTestStep,
                    sensorSupported = sensorCapabilities.isSupported,
                    onStartTest = onStartGuidedTest,
                    onCompleteShake = onCompleteShakeManually
                )
            }

            // 5. Hardware Sensor Diagnostics Card
            item {
                HardwareDiagnosticsCard(capabilities = sensorCapabilities)
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

private fun fmt(value: Float): String = String.format(Locale.US, "%+.2f", value)

@Composable
private fun LiveTapLogCard(logs: List<TapLogEntry>) {
    val strings = LocalAppStrings.current

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_tap_log_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.History,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.liveLogTitle,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (logs.isEmpty()) {
                Text(
                    text = strings.liveLogEmpty,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    logs.take(10).forEach { entry ->
                        val badgeColor = when (entry.status) {
                            TapLogStatus.SINGLE_TAP -> MaterialTheme.colorScheme.primary
                            TapLogStatus.DOUBLE_TAP_CONFIRMED -> MaterialTheme.colorScheme.secondary
                            TapLogStatus.TRIPLE_TAP_CONFIRMED -> MaterialTheme.colorScheme.secondary
                            TapLogStatus.REJECTED_MOTION -> MaterialTheme.colorScheme.tertiary
                        }
                        val statusText = when (entry.status) {
                            TapLogStatus.SINGLE_TAP -> strings.tapStatusSingle
                            TapLogStatus.DOUBLE_TAP_CONFIRMED -> strings.tapStatusDouble
                            TapLogStatus.TRIPLE_TAP_CONFIRMED -> strings.tapStatusTriple
                            TapLogStatus.REJECTED_MOTION -> strings.tapStatusRejected
                        }

                        Surface(
                            color = badgeColor.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = if (entry.status == TapLogStatus.REJECTED_MOTION) {
                                            statusText
                                        } else {
                                            "#${entry.tapNumber} • $statusText"
                                        },
                                        style = MaterialTheme.typography.labelLarge,
                                        color = badgeColor
                                    )
                                    Text(
                                        text = buildString {
                                            append("${String.format(Locale.US, "%.2f", entry.intensityMps2)} m/s²")
                                            entry.intervalFromPrevMs?.let { dt ->
                                                append("  •  Δt = ${dt} ms")
                                            }
                                        },
                                        style = MonoTelemetryStyle,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CounterMetricTile(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MonoTelemetryStyle.copy(
                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                    fontWeight = FontWeight.Bold
                ),
                color = color,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GuidedPracticalTestCard(
    step: GuidedTestStep,
    sensorSupported: Boolean,
    onStartTest: () -> Unit,
    onCompleteShake: () -> Unit
) {
    val strings = LocalAppStrings.current
    val progress = when (step) {
        GuidedTestStep.IDLE -> 0f
        GuidedTestStep.WAITING_DOUBLE_TAP -> 0.25f
        GuidedTestStep.WAITING_TRIPLE_TAP -> 0.55f
        GuidedTestStep.WAITING_SHAKE_TEST -> 0.80f
        GuidedTestStep.PASSED -> 1.0f
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Science,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.guidedTestTitle,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Text(
                text = strings.guidedTestDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (step != GuidedTestStep.IDLE) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )

                val stepMessage = when (step) {
                    GuidedTestStep.WAITING_DOUBLE_TAP -> strings.guidedStepDouble
                    GuidedTestStep.WAITING_TRIPLE_TAP -> strings.guidedStepTriple
                    GuidedTestStep.WAITING_SHAKE_TEST -> strings.guidedStepShake
                    GuidedTestStep.PASSED -> strings.guidedTestPassed
                    GuidedTestStep.IDLE -> ""
                }

                Surface(
                    color = if (step == GuidedTestStep.PASSED) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (step == GuidedTestStep.PASSED) {
                                Icons.Rounded.CheckCircle
                            } else {
                                Icons.Rounded.Info
                            },
                            contentDescription = null,
                            tint = if (step == GuidedTestStep.PASSED) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                MaterialTheme.colorScheme.primary
                            }
                        )
                        Text(
                            text = stepMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartTest,
                    enabled = sensorSupported,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("start_guided_test_button")
                ) {
                    Text(strings.startGuidedTest)
                }

                if (step == GuidedTestStep.WAITING_SHAKE_TEST) {
                    OutlinedButton(
                        onClick = onCompleteShake,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("confirm_shake_step_button")
                    ) {
                        Text(strings.skipShakeCheck)
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareDiagnosticsCard(capabilities: SensorCapabilities) {
    val strings = LocalAppStrings.current

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Sensors,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.hardwareCheckTitle,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            SensorRowItem(strings.sensorLinearLabel, capabilities.hasLinearAcceleration)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorAccelLabel, capabilities.hasAccelerometer)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorGyroLabel, capabilities.hasGyroscope)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorFlashLabel, capabilities.hasFlashlight)

            if (capabilities.isUsingFallback) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = strings.fallbackModeNotice,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SensorRowItem(label: String, available: Boolean) {
    val strings = LocalAppStrings.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Surface(
            color = if (available) {
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)
            } else {
                MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
            },
            shape = RoundedCornerShape(50.dp)
        ) {
            Text(
                text = if (available) strings.availableLabel else strings.unavailableLabel,
                style = MaterialTheme.typography.labelMedium,
                color = if (available) {
                    MaterialTheme.colorScheme.secondary
                } else {
                    MaterialTheme.colorScheme.error
                },
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}
