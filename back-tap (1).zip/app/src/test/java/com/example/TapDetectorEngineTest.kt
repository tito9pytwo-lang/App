package com.example

import com.example.model.TelemetrySnapshot
import com.example.sensor.TapDetectorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class TapDetectorEngineTest {

    private var rawTaps = 0
    private var doubleTaps = 0
    private var tripleTaps = 0
    private var rejectedNoise = 0
    private var lastIntensity = 0f
    private var lastIntervalMs: Long? = null

    private lateinit var engine: TapDetectorEngine

    @Before
    fun setup() {
        rawTaps = 0
        doubleTaps = 0
        tripleTaps = 0
        rejectedNoise = 0
        lastIntensity = 0f
        lastIntervalMs = null
        engine = TapDetectorEngine(object : TapDetectorEngine.Listener {
            override fun onRawTap(
                chainCount: Int,
                intensityMps2: Float,
                intervalFromPrevMs: Long?,
                timestampMs: Long
            ) {
                rawTaps++
                lastIntensity = intensityMps2
                if (intervalFromPrevMs != null) {
                    lastIntervalMs = intervalFromPrevMs
                }
            }

            override fun onDoubleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long) {
                doubleTaps++
                lastIntensity = intensityMps2
                lastIntervalMs = intervalMs
            }

            override fun onTripleTap(intensityMps2: Float, intervalMs: Long?, timestampMs: Long) {
                tripleTaps++
            }

            override fun onRejectedNoise(intensityMps2: Float, timestampMs: Long) {
                rejectedNoise++
            }

            override fun onTelemetry(snapshot: TelemetrySnapshot) = Unit
        })
    }

    @Test
    fun `detects realistic multi-axis light back taps across X Y Z`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 480,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        // Realistic phone held upright: gravity on Y (~9.81), gentle X/Y/Z tap (~3.1 m/s^2 3D)
        var t = 0L
        repeat(15) {
            engine.onAccelerometerSample(0.1f, 9.81f, 0.2f, t, isLinearAcceleration = false)
            t += 10L
        }

        // Tap 1: primarily X and Y impulse (e.g. tapping near upper camera corner), not just Z
        engine.onAccelerometerSample(2.6f, 9.81f + 2.4f, 1.3f, t, isLinearAcceleration = false)
        t += 10L
        engine.onAccelerometerSample(0.2f, 9.81f + 0.1f, 0.2f, t, isLinearAcceleration = false)
        t += 10L

        // Wait 240ms between taps
        repeat(24) {
            engine.onAccelerometerSample(0.1f, 9.81f, 0.2f, t, isLinearAcceleration = false)
            t += 10L
        }

        // Tap 2: angled impulse
        engine.onAccelerometerSample(2.4f, 9.81f + 2.5f, 1.4f, t, isLinearAcceleration = false)
        t += 10L
        engine.onAccelerometerSample(0.1f, 9.81f, 0.2f, t, isLinearAcceleration = false)

        assertEquals(2, rawTaps)
        assertEquals(1, doubleTaps)
        assertTrue(lastIntensity > 2.5f)
        assertNotNull(lastIntervalMs)
        assertTrue(lastIntervalMs!! in 200L..350L)
    }

    @Test
    fun `detects double tap after interval timeout when triple tap enabled`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 400,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        feedRestSamples(0L, 80L)
        feedTapImpulse(100L, 4.2f)
        feedRestSamples(110L, 240L)
        feedTapImpulse(280L, 4.5f)

        // Before 400ms expires, double tap waits for possible 3rd tap
        assertEquals(0, doubleTaps)

        engine.checkPendingDoubleTap(700L)
        assertEquals(1, doubleTaps)
        assertEquals(0, tripleTaps)
    }

    @Test
    fun `detects triple tap and suppresses double tap`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 450,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        feedRestSamples(0L, 60L)
        feedTapImpulse(80L, 4.2f)
        feedRestSamples(90L, 200L)
        feedTapImpulse(220L, 4.6f)
        feedRestSamples(230L, 340L)
        feedTapImpulse(360L, 4.3f)

        engine.checkPendingDoubleTap(900L)
        assertEquals(3, rawTaps)
        assertEquals(0, doubleTaps)
        assertEquals(1, tripleTaps)
    }

    @Test
    fun `simultaneous accelerometer and linear acceleration stream does not double count`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 450,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        var t = 0L
        repeat(15) {
            engine.onAccelerometerSample(0f, 0f, 9.81f, t, isLinearAcceleration = false)
            engine.onAccelerometerSample(0f, 0f, 0f, t + 2L, isLinearAcceleration = true)
            t += 10L
        }

        // Single physical tap delivered on both sensors followed by continuous rest samples
        engine.onAccelerometerSample(1.5f, 1.5f, 9.81f + 3.5f, t, isLinearAcceleration = false)
        engine.onAccelerometerSample(1.5f, 1.5f, 3.5f, t + 2L, isLinearAcceleration = true)
        t += 10L
        repeat(3) {
            engine.onAccelerometerSample(0f, 0f, 9.81f, t, isLinearAcceleration = false)
            engine.onAccelerometerSample(0f, 0f, 0f, t + 2L, isLinearAcceleration = true)
            t += 10L
        }

        assertEquals(1, rawTaps)
        assertEquals(0, doubleTaps)
    }

    @Test
    fun `allows normal hand micro rotation during tap while rejecting vigorous rotation`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 480,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        feedRestSamples(0L, 60L)
        // Small hand wobble (~1.1 rad/s) from holding phone during tap should STILL succeed
        engine.onGyroscopeSample(0.8f, 0.6f, 0.4f, 75L)
        feedTapImpulse(80L, 4.0f)
        feedRestSamples(90L, 220L)
        engine.onGyroscopeSample(0.7f, 0.5f, 0.3f, 235L)
        feedTapImpulse(240L, 4.1f)

        assertEquals(2, rawTaps)
        assertEquals(1, doubleTaps)

        // Vigorous flip/shake (> 3.5 rad/s) must be rejected
        feedRestSamples(260L, 350L)
        engine.onGyroscopeSample(3.4f, 2.2f, 1.1f, 360L)
        feedTapImpulse(370L, 5.0f)
        assertTrue(rejectedNoise >= 1)
    }

    @Test
    fun `rejects sustained shaking motion`() {
        engine.updateConfig(
            sensitivity = 0.65f,
            tapIntervalMs = 480,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        var t = 0L
        repeat(20) { i ->
            val mag = if (i % 2 == 0) 4.8f else -4.8f
            engine.onAccelerometerSample(2.5f, 2.5f, mag, t, isLinearAcceleration = true)
            t += 10L
        }

        assertEquals(0, doubleTaps)
        assertTrue(rejectedNoise >= 1)
    }

    private fun feedRestSamples(startMs: Long, endMs: Long) {
        var t = startMs
        while (t <= endMs) {
            engine.onAccelerometerSample(0f, 0f, 0f, t, isLinearAcceleration = true)
            t += 10L
        }
    }

    private fun feedTapImpulse(timestampMs: Long, zStrength: Float) {
        engine.onAccelerometerSample(1.2f, 1.0f, zStrength, timestampMs, isLinearAcceleration = true)
        engine.onAccelerometerSample(0.1f, 0.1f, 0.1f, timestampMs + 10L, isLinearAcceleration = true)
    }
}
