package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.AppLanguage
import com.example.ui.components.ActionPickerSheet
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AppsSettingsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.TestLabScreen
import com.example.ui.theme.BackTapTheme
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

object BackTapRoutes {
    const val HOME = "home"
    const val TEST_LAB = "test_lab"
    const val APPS_SETTINGS = "apps_settings"
}

private enum class EditingTarget {
    DOUBLE_TAP,
    TRIPLE_TAP
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BackTapAppRoot(viewModel = viewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackTapAppRoot(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val serviceState by viewModel.serviceState.collectAsStateWithLifecycle()
    val sensorCapabilities by viewModel.sensorCapabilities.collectAsStateWithLifecycle()
    val accessibilityEnabled by viewModel.accessibilityEnabled.collectAsStateWithLifecycle()
    val notificationGranted by viewModel.notificationPermissionGranted.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val appsLoading by viewModel.appsLoading.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val waveformSamples by viewModel.waveformSamples.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val safeTestMode by viewModel.testLabSafeMode.collectAsStateWithLifecycle()
    val guidedTestStep by viewModel.guidedTestStep.collectAsStateWithLifecycle()

    val strings = remember(settings.language) { stringsFor(settings.language) }
    val layoutDirection = if (settings.language == AppLanguage.ARABIC) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { viewModel.refreshSystemStatus() }
    )

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var editingTarget by rememberSaveable { mutableStateOf<EditingTarget?>(null) }

    BackTapTheme(themePreference = settings.themePreference) {
        CompositionLocalProvider(
            LocalAppStrings provides strings,
            LocalLayoutDirection provides layoutDirection
        ) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavigationRail = maxWidth >= 600.dp

                val navigateTo = { route: String ->
                    navController.navigate(route) {
                        popUpTo(BackTapRoutes.HOME) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }

                val isHomeSelected = currentRoute == null || currentRoute == BackTapRoutes.HOME
                val isTestSelected = currentRoute == BackTapRoutes.TEST_LAB
                val isAppsSelected = currentRoute == BackTapRoutes.APPS_SETTINGS

                Row(modifier = Modifier.fillMaxSize()) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            NavigationRailItem(
                                selected = isHomeSelected,
                                onClick = { navigateTo(BackTapRoutes.HOME) },
                                icon = {
                                    Icon(
                                        imageVector = if (isHomeSelected) Icons.Rounded.Home else Icons.Outlined.Home,
                                        contentDescription = strings.navHome
                                    )
                                },
                                label = { Text(strings.navHome) },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationRailItem(
                                selected = isTestSelected,
                                onClick = { navigateTo(BackTapRoutes.TEST_LAB) },
                                icon = {
                                    Icon(
                                        imageVector = if (isTestSelected) Icons.Rounded.Sensors else Icons.Outlined.Sensors,
                                        contentDescription = strings.navTest
                                    )
                                },
                                label = { Text(strings.navTest) },
                                modifier = Modifier.testTag("nav_test")
                            )
                            NavigationRailItem(
                                selected = isAppsSelected,
                                onClick = { navigateTo(BackTapRoutes.APPS_SETTINGS) },
                                icon = {
                                    Icon(
                                        imageVector = if (isAppsSelected) Icons.Rounded.Apps else Icons.Outlined.Apps,
                                        contentDescription = strings.navApps
                                    )
                                },
                                label = { Text(strings.navApps) },
                                modifier = Modifier.testTag("nav_apps")
                            )
                        }
                    }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        contentWindowInsets = WindowInsets.safeDrawing,
                        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                        topBar = {
                            CenterAlignedTopAppBar(
                                title = {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = strings.appTitle,
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Text(
                                            text = strings.appSubtitle,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                actions = {
                                    TextButton(
                                        onClick = {
                                            val nextLang = if (settings.language == AppLanguage.ARABIC) {
                                                AppLanguage.ENGLISH
                                            } else {
                                                AppLanguage.ARABIC
                                            }
                                            viewModel.setLanguage(nextLang)
                                        },
                                        modifier = Modifier.testTag("header_language_toggle")
                                    ) {
                                        Text(
                                            text = if (settings.language == AppLanguage.ARABIC) "EN" else "عربي",
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.background
                                )
                            )
                        },
                        bottomBar = {
                            if (!useNavigationRail) {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface
                                ) {
                                    NavigationBarItem(
                                        selected = isHomeSelected,
                                        onClick = { navigateTo(BackTapRoutes.HOME) },
                                        icon = {
                                            Icon(
                                                imageVector = if (isHomeSelected) Icons.Rounded.Home else Icons.Outlined.Home,
                                                contentDescription = strings.navHome
                                            )
                                        },
                                        label = { Text(strings.navHome) },
                                        modifier = Modifier.testTag("nav_home")
                                    )
                                    NavigationBarItem(
                                        selected = isTestSelected,
                                        onClick = { navigateTo(BackTapRoutes.TEST_LAB) },
                                        icon = {
                                            Icon(
                                                imageVector = if (isTestSelected) Icons.Rounded.Sensors else Icons.Outlined.Sensors,
                                                contentDescription = strings.navTest
                                            )
                                        },
                                        label = { Text(strings.navTest) },
                                        modifier = Modifier.testTag("nav_test")
                                    )
                                    NavigationBarItem(
                                        selected = isAppsSelected,
                                        onClick = { navigateTo(BackTapRoutes.APPS_SETTINGS) },
                                        icon = {
                                            Icon(
                                                imageVector = if (isAppsSelected) Icons.Rounded.Apps else Icons.Outlined.Apps,
                                                contentDescription = strings.navApps
                                            )
                                        },
                                        label = { Text(strings.navApps) },
                                        modifier = Modifier.testTag("nav_apps")
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = BackTapRoutes.HOME,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(BackTapRoutes.HOME) {
                                HomeScreen(
                                    settings = settings,
                                    serviceState = serviceState,
                                    sensorCapabilities = sensorCapabilities,
                                    accessibilityEnabled = accessibilityEnabled,
                                    notificationPermissionGranted = notificationGranted,
                                    installedApps = installedApps,
                                    stats = stats,
                                    onToggleService = { enable ->
                                        if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationGranted) {
                                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                        viewModel.toggleService(enable)
                                    },
                                    onRequestNotificationPermission = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                    },
                                    onOpenAccessibilitySettings = {
                                        viewModel.openAccessibilitySettings()
                                    },
                                    onEditDoubleTap = { editingTarget = EditingTarget.DOUBLE_TAP },
                                    onEditTripleTap = { editingTarget = EditingTarget.TRIPLE_TAP },
                                    onTestAction = { config ->
                                        val outcome = viewModel.testActionDirectly(config)
                                        val msg = strings.outcomeMessage(
                                            outcome,
                                            settings.language == AppLanguage.ARABIC
                                        )
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(msg)
                                        }
                                    },
                                    onSensitivityChange = viewModel::setSensitivity,
                                    onIntervalChange = viewModel::setTapIntervalMs,
                                    onAntiMotionChange = viewModel::setAntiMotionFilterEnabled,
                                    onHapticChange = viewModel::setHapticFeedbackEnabled
                                )
                            }

                            composable(BackTapRoutes.TEST_LAB) {
                                DisposableEffect(Unit) {
                                    viewModel.setTestLabVisible(true)
                                    onDispose { viewModel.setTestLabVisible(false) }
                                }
                                TestLabScreen(
                                    serviceState = serviceState,
                                    sensorCapabilities = sensorCapabilities,
                                    telemetry = telemetry,
                                    waveformSamples = waveformSamples,
                                    stats = stats,
                                    safeTestMode = safeTestMode,
                                    guidedTestStep = guidedTestStep,
                                    pulseEvents = viewModel.pulseEvents,
                                    onToggleService = { enable ->
                                        if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationGranted) {
                                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                        viewModel.toggleService(enable)
                                    },
                                    onSafeTestModeChange = viewModel::setTestLabSafeMode,
                                    onResetStats = viewModel::resetTestStats,
                                    onStartGuidedTest = viewModel::startGuidedTest,
                                    onCompleteShakeManually = viewModel::completeShakeStepManually
                                )
                            }

                            composable(BackTapRoutes.APPS_SETTINGS) {
                                AppsSettingsScreen(
                                    settings = settings,
                                    installedApps = installedApps,
                                    appsLoading = appsLoading,
                                    onAssignDoubleTap = { config ->
                                        viewModel.setDoubleTapAction(config)
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(
                                                "${strings.doubleTapTitle}: ${strings.actionLabel(config)}"
                                            )
                                        }
                                    },
                                    onAssignTripleTap = { config ->
                                        viewModel.setTripleTapAction(config)
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(
                                                "${strings.tripleTapTitle}: ${strings.actionLabel(config)}"
                                            )
                                        }
                                    },
                                    onLaunchApp = { pkg ->
                                        val outcome = viewModel.launchInstalledApp(pkg)
                                        val msg = strings.outcomeMessage(
                                            outcome,
                                            settings.language == AppLanguage.ARABIC
                                        )
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar(msg)
                                        }
                                    },
                                    onThemeChange = viewModel::setThemePreference,
                                    onLanguageChange = viewModel::setLanguage,
                                    onPauseScreenOffChange = viewModel::setPauseWhenScreenOff
                                )
                            }
                        }
                    }
                }
            }

            val currentTarget = editingTarget
            if (currentTarget != null) {
                ActionPickerSheet(
                    title = if (currentTarget == EditingTarget.DOUBLE_TAP) {
                        strings.pickerTitleDouble
                    } else {
                        strings.pickerTitleTriple
                    },
                    currentConfig = if (currentTarget == EditingTarget.DOUBLE_TAP) {
                        settings.doubleTapAction
                    } else {
                        settings.tripleTapAction
                    },
                    installedApps = installedApps,
                    onSelectAction = { selected ->
                        if (currentTarget == EditingTarget.DOUBLE_TAP) {
                            viewModel.setDoubleTapAction(selected)
                        } else {
                            viewModel.setTripleTapAction(selected)
                        }
                    },
                    onDismiss = { editingTarget = null }
                )
            }
        }
    }
}
