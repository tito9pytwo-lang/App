package com.example.data

import com.example.model.ActionExecutionOutcome
import com.example.model.DetectedGesture
import com.example.model.ServiceState
import com.example.model.TapStats
import com.example.model.TelemetrySnapshot
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class TapPulseEvent(
    val id: Long,
    val gesture: DetectedGesture
)

object BackTapRuntimeState {
    private const val WAVEFORM_CAPACITY = 64

    private val _serviceState = MutableStateFlow(ServiceState.STOPPED)
    val serviceState: StateFlow<ServiceState> = _serviceState.asStateFlow()

    private val _accessibilityEnabled = MutableStateFlow(false)
    val accessibilityEnabled: StateFlow<Boolean> = _accessibilityEnabled.asStateFlow()

    private val _flashlightOn = MutableStateFlow(false)
    val flashlightOn: StateFlow<Boolean> = _flashlightOn.asStateFlow()

    private val _testLabSafeMode = MutableStateFlow(true)
    val testLabSafeMode: StateFlow<Boolean> = _testLabSafeMode.asStateFlow()

    private val _isTestLabVisible = MutableStateFlow(false)
    val isTestLabVisible: StateFlow<Boolean> = _isTestLabVisible.asStateFlow()

    private val _telemetry = MutableStateFlow(TelemetrySnapshot())
    val telemetry: StateFlow<TelemetrySnapshot> = _telemetry.asStateFlow()

    private val _waveformSamples = MutableStateFlow<List<Float>>(List(WAVEFORM_CAPACITY) { 0f })
    val waveformSamples: StateFlow<List<Float>> = _waveformSamples.asStateFlow()

    private val _stats = MutableStateFlow(TapStats())
    val stats: StateFlow<TapStats> = _stats.asStateFlow()

    private val _pulseEvents = MutableSharedFlow<TapPulseEvent>(extraBufferCapacity = 16)
    val pulseEvents: SharedFlow<TapPulseEvent> = _pulseEvents.asSharedFlow()

    private var pulseIdCounter = 0L

    fun setServiceState(state: ServiceState) {
        _serviceState.value = state
    }

    fun setAccessibilityEnabled(enabled: Boolean) {
        _accessibilityEnabled.value = enabled
    }

    fun setFlashlightOn(on: Boolean) {
        _flashlightOn.value = on
    }

    fun setTestLabSafeMode(safeMode: Boolean) {
        _testLabSafeMode.value = safeMode
    }

    fun setTestLabVisible(visible: Boolean) {
        _isTestLabVisible.value = visible
    }

    fun shouldSuppressActionExecution(): Boolean {
        return _isTestLabVisible.value && _testLabSafeMode.value
    }

    fun updateTelemetry(snapshot: TelemetrySnapshot) {
        _telemetry.value = snapshot
        _waveformSamples.update { current ->
            val next = if (current.size >= WAVEFORM_CAPACITY) {
                current.drop(1) + snapshot.zAccel
            } else {
                current + snapshot.zAccel
            }
            next
        }
    }

    fun recordRawTap(timestampMs: Long) {
        _stats.update {
            it.copy(
                rawTapCount = it.rawTapCount + 1,
                lastGesture = DetectedGesture.RAW_TAP,
                lastTapTimestampMs = timestampMs
            )
        }
        _pulseEvents.tryEmit(TapPulseEvent(++pulseIdCounter, DetectedGesture.RAW_TAP))
    }

    fun recordDoubleTap(timestampMs: Long) {
        _stats.update {
            it.copy(
                doubleTapCount = it.doubleTapCount + 1,
                lastGesture = DetectedGesture.DOUBLE_TAP,
                lastTapTimestampMs = timestampMs
            )
        }
        _pulseEvents.tryEmit(TapPulseEvent(++pulseIdCounter, DetectedGesture.DOUBLE_TAP))
    }

    fun recordTripleTap(timestampMs: Long) {
        _stats.update {
            it.copy(
                tripleTapCount = it.tripleTapCount + 1,
                lastGesture = DetectedGesture.TRIPLE_TAP,
                lastTapTimestampMs = timestampMs
            )
        }
        _pulseEvents.tryEmit(TapPulseEvent(++pulseIdCounter, DetectedGesture.TRIPLE_TAP))
    }

    fun recordRejectedNoise() {
        _stats.update {
            it.copy(rejectedNoiseCount = it.rejectedNoiseCount + 1)
        }
    }

    fun recordActionOutcome(outcome: ActionExecutionOutcome) {
        _stats.update {
            it.copy(lastActionResult = outcome)
        }
    }

    fun resetStats() {
        _stats.value = TapStats()
    }
}
