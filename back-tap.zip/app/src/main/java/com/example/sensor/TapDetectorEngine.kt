package com.example.sensor

import com.example.model.TelemetrySnapshot
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

class TapDetectorEngine(
    private val listener: Listener
) {
    interface Listener {
        fun onRawTap(chainCount: Int, timestampMs: Long)
        fun onDoubleTap(timestampMs: Long)
        fun onTripleTap(timestampMs: Long)
        fun onRejectedNoise(timestampMs: Long)
        fun onTelemetry(snapshot: TelemetrySnapshot)
    }

    private var sensitivity: Float = 0.60f
    private var tapIntervalMs: Int = 420
    private var antiMotionFilterEnabled: Boolean = true
    private var tripleTapEnabled: Boolean = true

    // Gravity low-pass state for raw TYPE_ACCELEROMETER fallback
    private var gravityInitialized = false
    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f
    private var prevLz = 0f
    private var hasPrevLz = false

    // Gyroscope veto state
    private var lastGyroMag = 0f
    private var lastGyroTimestampMs = -10_000L

    // Suppression and debounce state
    private var suppressUntilMs = -10_000L
    private var lastAcceptedTapMs = -10_000L
    private var lastNoiseReportedMs = -10_000L

    // Sustained shake detection window
    private val elevatedSamples = ArrayDeque<Long>()

    // Multi-tap state machine
    private var pendingTapCount = 0
    private var lastChainTapMs = -10_000L
    private var pendingDoubleTapDeadlineMs: Long? = null

    fun updateConfig(
        sensitivity: Float,
        tapIntervalMs: Int,
        antiMotionFilterEnabled: Boolean,
        tripleTapEnabled: Boolean
    ) {
        this.sensitivity = sensitivity.coerceIn(0.15f, 1.0f)
        this.tapIntervalMs = tapIntervalMs.coerceIn(250, 700)
        this.antiMotionFilterEnabled = antiMotionFilterEnabled
        this.tripleTapEnabled = tripleTapEnabled
    }

    fun reset() {
        gravityInitialized = false
        gravityX = 0f
        gravityY = 0f
        gravityZ = 0f
        prevLz = 0f
        hasPrevLz = false
        lastGyroMag = 0f
        lastGyroTimestampMs = -10_000L
        suppressUntilMs = -10_000L
        lastAcceptedTapMs = -10_000L
        lastNoiseReportedMs = -10_000L
        elevatedSamples.clear()
        pendingTapCount = 0
        lastChainTapMs = -10_000L
        pendingDoubleTapDeadlineMs = null
    }

    fun currentZThreshold(): Float = 9.5f - (sensitivity * 6.5f)

    fun onGyroscopeSample(gx: Float, gy: Float, gz: Float, timestampMs: Long) {
        val mag = sqrt(gx * gx + gy * gy + gz * gz)
        lastGyroMag = mag
        lastGyroTimestampMs = timestampMs
        if (antiMotionFilterEnabled && mag > GYRO_ROTATION_VETO_RAD_S) {
            suppressUntilMs = max(suppressUntilMs, timestampMs + GYRO_SUPPRESS_DURATION_MS)
        }
    }

    fun onAccelerometerSample(
        x: Float,
        y: Float,
        z: Float,
        timestampMs: Long,
        isLinearAcceleration: Boolean
    ) {
        // First evaluate any expired double-tap timer
        checkPendingDoubleTap(timestampMs)

        val lx: Float
        val ly: Float
        val lz: Float

        if (isLinearAcceleration) {
            lx = x
            ly = y
            lz = z
        } else {
            if (!gravityInitialized) {
                gravityX = x
                gravityY = y
                gravityZ = z
                gravityInitialized = true
                prevLz = 0f
                hasPrevLz = true
                return
            }
            gravityX = GRAVITY_ALPHA * gravityX + (1f - GRAVITY_ALPHA) * x
            gravityY = GRAVITY_ALPHA * gravityY + (1f - GRAVITY_ALPHA) * y
            gravityZ = GRAVITY_ALPHA * gravityZ + (1f - GRAVITY_ALPHA) * z
            lx = x - gravityX
            ly = y - gravityY
            lz = z - gravityZ
        }

        val jerkZ = if (hasPrevLz) abs(lz - prevLz) else 0f
        prevLz = lz
        hasPrevLz = true

        val absZ = abs(lz)
        val xyMag = hypot(lx, ly)
        val totalMag = sqrt(lx * lx + ly * ly + lz * lz)
        val zThreshold = currentZThreshold()
        val jerkThreshold = zThreshold * 0.70f

        listener.onTelemetry(
            TelemetrySnapshot(
                timestampMs = timestampMs,
                zAccel = lz,
                xyAccel = xyMag,
                gyroMagnitude = if (timestampMs - lastGyroTimestampMs <= 250L) lastGyroMag else 0f,
                currentThreshold = zThreshold
            )
        )

        // Track sustained energy to reject vigorous shaking / walking
        while (elevatedSamples.isNotEmpty() && timestampMs - elevatedSamples.first() > SHAKE_WINDOW_MS) {
            elevatedSamples.removeFirst()
        }
        if (totalMag > zThreshold * 0.65f) {
            elevatedSamples.addLast(timestampMs)
        }

        val isSharpZSpike = absZ >= zThreshold && jerkZ >= jerkThreshold
        if (!isSharpZSpike) {
            return
        }

        // Check anti-motion & vibration filters
        if (antiMotionFilterEnabled) {
            val gyroActive = (timestampMs - lastGyroTimestampMs <= 200L) &&
                lastGyroMag > GYRO_ROTATION_VETO_RAD_S
            if (gyroActive || timestampMs < suppressUntilMs) {
                reportNoiseOnce(timestampMs)
                return
            }

            if (elevatedSamples.size >= SUSTAINED_SHAKE_SAMPLE_COUNT) {
                suppressUntilMs = max(suppressUntilMs, timestampMs + SHAKE_SUPPRESS_DURATION_MS)
                pendingTapCount = 0
                pendingDoubleTapDeadlineMs = null
                reportNoiseOnce(timestampMs)
                return
            }

            // Z-axis dominance: back taps move primarily perpendicular to the screen
            if (absZ < xyMag * 0.65f && absZ < zThreshold * 1.85f) {
                reportNoiseOnce(timestampMs)
                return
            }
        }

        // Refractory debounce period to prevent single-tap ring-down double counting
        if (timestampMs - lastAcceptedTapMs < REFRACTORY_PERIOD_MS) {
            return
        }

        acceptTap(timestampMs)
    }

    fun checkPendingDoubleTap(nowMs: Long) {
        val deadline = pendingDoubleTapDeadlineMs ?: return
        if (pendingTapCount == 2 && nowMs >= deadline) {
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
            listener.onDoubleTap(nowMs)
        }
    }

    fun getPendingDoubleTapDeadlineMs(): Long? = pendingDoubleTapDeadlineMs

    private fun acceptTap(timestampMs: Long) {
        lastAcceptedTapMs = timestampMs

        if (pendingTapCount > 0 && (timestampMs - lastChainTapMs) > tapIntervalMs) {
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
        }

        pendingTapCount += 1
        lastChainTapMs = timestampMs
        listener.onRawTap(pendingTapCount, timestampMs)

        if (pendingTapCount == 2) {
            if (!tripleTapEnabled) {
                pendingTapCount = 0
                pendingDoubleTapDeadlineMs = null
                listener.onDoubleTap(timestampMs)
            } else {
                pendingDoubleTapDeadlineMs = timestampMs + tapIntervalMs
            }
        } else if (pendingTapCount >= 3) {
            pendingTapCount = 0
            pendingDoubleTapDeadlineMs = null
            listener.onTripleTap(timestampMs)
        }
    }

    private fun reportNoiseOnce(timestampMs: Long) {
        if (timestampMs - lastNoiseReportedMs >= NOISE_REPORT_COOLDOWN_MS) {
            lastNoiseReportedMs = timestampMs
            listener.onRejectedNoise(timestampMs)
        }
    }

    companion object {
        private const val GRAVITY_ALPHA = 0.82f
        private const val GYRO_ROTATION_VETO_RAD_S = 2.4f
        private const val GYRO_SUPPRESS_DURATION_MS = 260L
        private const val SHAKE_WINDOW_MS = 300L
        private const val SUSTAINED_SHAKE_SAMPLE_COUNT = 7
        private const val SHAKE_SUPPRESS_DURATION_MS = 320L
        private const val REFRACTORY_PERIOD_MS = 115L
        private const val NOISE_REPORT_COOLDOWN_MS = 350L
    }
}
