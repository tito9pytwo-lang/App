package com.example.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.action.ActionExecutor
import com.example.data.BackTapRuntimeState
import com.example.data.SettingsRepository
import com.example.model.BackTapSettings
import com.example.model.ServiceState
import com.example.model.TapActionType
import com.example.model.TelemetrySnapshot
import com.example.sensor.TapDetectorEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class BackTapForegroundService : Service(), SensorEventListener, TapDetectorEngine.Listener {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var actionExecutor: ActionExecutor
    private lateinit var tapDetectorEngine: TapDetectorEngine
    private var sensorManager: SensorManager? = null

    private var activeAccelSensor: Sensor? = null
    private var usingLinearAcceleration = false
    private var gyroSensor: Sensor? = null
    private var sensorsRegistered = false

    private var currentSettings = BackTapSettings()
    private var doubleTapTimeoutJob: Job? = null
    private var isScreenInteractive = true
    private var screenReceiverRegistered = false

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenInteractive = false
                    if (currentSettings.pauseWhenScreenOff) {
                        unregisterSensors()
                        BackTapRuntimeState.setServiceState(ServiceState.PAUSED_SCREEN_OFF)
                        updateNotification(paused = true)
                    }
                }

                Intent.ACTION_SCREEN_ON -> {
                    isScreenInteractive = true
                    if (currentSettings.serviceEnabled && !sensorsRegistered) {
                        registerSensors()
                        updateNotification(paused = false)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(applicationContext)
        actionExecutor = ActionExecutor(applicationContext)
        tapDetectorEngine = TapDetectorEngine(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        isScreenInteractive = powerManager?.isInteractive ?: true

        resolveBestSensors()
        registerScreenReceiver()

        serviceScope.launch {
            settingsRepository.settingsFlow.collectLatest { settings ->
                currentSettings = settings
                tapDetectorEngine.updateConfig(
                    sensitivity = settings.sensitivity,
                    tapIntervalMs = settings.tapIntervalMs,
                    antiMotionFilterEnabled = settings.antiMotionFilterEnabled,
                    tripleTapEnabled = settings.tripleTapAction.type != TapActionType.NONE
                )

                if (!settings.pauseWhenScreenOff && !sensorsRegistered && settings.serviceEnabled) {
                    registerSensors()
                    updateNotification(paused = false)
                } else if (settings.pauseWhenScreenOff && !isScreenInteractive && sensorsRegistered) {
                    unregisterSensors()
                    BackTapRuntimeState.setServiceState(ServiceState.PAUSED_SCREEN_OFF)
                    updateNotification(paused = true)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            serviceScope.launch {
                settingsRepository.setServiceEnabled(false)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        ensureNotificationChannel()
        val notification = buildNotification(paused = false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (activeAccelSensor == null) {
            BackTapRuntimeState.setServiceState(ServiceState.SENSOR_UNAVAILABLE)
        } else if (currentSettings.pauseWhenScreenOff && !isScreenInteractive) {
            BackTapRuntimeState.setServiceState(ServiceState.PAUSED_SCREEN_OFF)
            updateNotification(paused = true)
        } else {
            registerSensors()
        }

        return START_STICKY
    }

    override fun onDestroy() {
        doubleTapTimeoutJob?.cancel()
        unregisterSensors()
        unregisterScreenReceiver()
        actionExecutor.release()
        BackTapRuntimeState.setServiceState(ServiceState.STOPPED)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val timestampMs = SystemClock.elapsedRealtime()
        when (event.sensor.type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                tapDetectorEngine.onAccelerometerSample(
                    x = event.values[0],
                    y = event.values[1],
                    z = event.values[2],
                    timestampMs = timestampMs,
                    isLinearAcceleration = true
                )
            }

            Sensor.TYPE_ACCELEROMETER -> {
                tapDetectorEngine.onAccelerometerSample(
                    x = event.values[0],
                    y = event.values[1],
                    z = event.values[2],
                    timestampMs = timestampMs,
                    isLinearAcceleration = false
                )
            }

            Sensor.TYPE_GYROSCOPE -> {
                tapDetectorEngine.onGyroscopeSample(
                    gx = event.values[0],
                    gy = event.values[1],
                    gz = event.values[2],
                    timestampMs = timestampMs
                )
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No-op
    }

    override fun onRawTap(chainCount: Int, timestampMs: Long) {
        BackTapRuntimeState.recordRawTap(timestampMs)
        if (chainCount == 2 && currentSettings.tripleTapAction.type != TapActionType.NONE) {
            doubleTapTimeoutJob?.cancel()
            doubleTapTimeoutJob = serviceScope.launch {
                delay(currentSettings.tapIntervalMs.toLong() + 15L)
                tapDetectorEngine.checkPendingDoubleTap(SystemClock.elapsedRealtime())
            }
        } else if (chainCount >= 3) {
            doubleTapTimeoutJob?.cancel()
        }
    }

    override fun onDoubleTap(timestampMs: Long) {
        doubleTapTimeoutJob?.cancel()
        BackTapRuntimeState.recordDoubleTap(timestampMs)
        if (!BackTapRuntimeState.shouldSuppressActionExecution()) {
            actionExecutor.execute(
                config = currentSettings.doubleTapAction,
                hapticEnabled = currentSettings.hapticFeedbackEnabled,
                isAppInForeground = isSelfAppInForeground()
            )
        }
    }

    override fun onTripleTap(timestampMs: Long) {
        doubleTapTimeoutJob?.cancel()
        BackTapRuntimeState.recordTripleTap(timestampMs)
        if (!BackTapRuntimeState.shouldSuppressActionExecution()) {
            actionExecutor.execute(
                config = currentSettings.tripleTapAction,
                hapticEnabled = currentSettings.hapticFeedbackEnabled,
                isAppInForeground = isSelfAppInForeground()
            )
        }
    }

    override fun onRejectedNoise(timestampMs: Long) {
        BackTapRuntimeState.recordRejectedNoise()
    }

    override fun onTelemetry(snapshot: TelemetrySnapshot) {
        BackTapRuntimeState.updateTelemetry(snapshot)
    }

    private fun resolveBestSensors() {
        val sm = sensorManager ?: return
        val linear = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (linear != null) {
            activeAccelSensor = linear
            usingLinearAcceleration = true
        } else {
            activeAccelSensor = accel
            usingLinearAcceleration = false
        }
        gyroSensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    }

    private fun registerSensors() {
        val sm = sensorManager ?: return
        val accel = activeAccelSensor
        if (accel == null) {
            BackTapRuntimeState.setServiceState(ServiceState.SENSOR_UNAVAILABLE)
            return
        }
        if (sensorsRegistered) return

        tapDetectorEngine.reset()
        // SENSOR_DELAY_GAME (~20ms / 50Hz) balances sharp tap detection and low battery usage
        sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME)
        gyroSensor?.let { gyro ->
            sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME)
        }
        sensorsRegistered = true
        BackTapRuntimeState.setServiceState(ServiceState.ACTIVE)
    }

    private fun unregisterSensors() {
        if (!sensorsRegistered) return
        sensorManager?.unregisterListener(this)
        sensorsRegistered = false
    }

    private fun registerScreenReceiver() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            this,
            screenStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        screenReceiverRegistered = true
    }

    private fun unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return
        runCatching { unregisterReceiver(screenStateReceiver) }
        screenReceiverRegistered = false
    }

    private fun isSelfAppInForeground(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
        val appProcesses = am.runningAppProcesses ?: return false
        return appProcesses.any { process ->
            process.processName == packageName &&
                process.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.fgs_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.fgs_channel_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(paused: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, BackTapForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentText = if (paused) {
            getString(R.string.fgs_notification_paused)
        } else {
            getString(R.string.fgs_notification_text)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.fgs_notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppPendingIntent)
            .addAction(0, getString(R.string.fgs_action_stop), stopPendingIntent)
            .build()
    }

    private fun updateNotification(paused: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        runCatching { nm.notify(NOTIFICATION_ID, buildNotification(paused)) }
    }

    companion object {
        private const val CHANNEL_ID = "back_tap_foreground_channel"
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_STOP = "com.example.action.STOP_BACK_TAP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, BackTapForegroundService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, BackTapForegroundService::class.java)
            context.stopService(intent)
        }
    }
}
