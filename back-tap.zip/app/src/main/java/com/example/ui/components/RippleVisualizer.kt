package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.TapPulseEvent
import com.example.model.DetectedGesture
import com.example.model.ServiceState
import com.example.ui.theme.MonoTelemetryStyle
import kotlinx.coroutines.flow.SharedFlow
import kotlin.math.max

@Composable
fun BackTapPulseCanvas(
    serviceState: ServiceState,
    rawTapCount: Int,
    pulseEvents: SharedFlow<TapPulseEvent>,
    modifier: Modifier = Modifier
) {
    val rippleProgress = remember { Animatable(1f) }
    val activeColor = when (serviceState) {
        ServiceState.ACTIVE -> MaterialTheme.colorScheme.secondary
        ServiceState.PAUSED_SCREEN_OFF -> MaterialTheme.colorScheme.tertiary
        ServiceState.STOPPED -> MaterialTheme.colorScheme.outline
        ServiceState.SENSOR_UNAVAILABLE -> MaterialTheme.colorScheme.error
    }
    val pulseAccent = MaterialTheme.colorScheme.primary

    LaunchedEffect(pulseEvents) {
        pulseEvents.collect { event ->
            rippleProgress.snapTo(0f)
            val duration = when (event.gesture) {
                DetectedGesture.TRIPLE_TAP -> 650
                DetectedGesture.DOUBLE_TAP -> 520
                DetectedGesture.RAW_TAP -> 380
            }
            rippleProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = duration, easing = FastOutSlowInEasing)
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "idle_pulse")
    val idleBreath by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_breath"
    )

    Box(
        modifier = modifier.size(168.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f - 4.dp.toPx()

            // Outer ambient halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        activeColor.copy(alpha = if (serviceState == ServiceState.ACTIVE) 0.20f else 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius,
                center = center
            )

            // Breathing inner rings
            val ringScale = if (serviceState == ServiceState.ACTIVE) idleBreath else 0.92f
            drawCircle(
                color = activeColor.copy(alpha = 0.25f),
                radius = maxRadius * 0.72f * ringScale,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
            drawCircle(
                color = activeColor.copy(alpha = 0.45f),
                radius = maxRadius * 0.50f * ringScale,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Expanding tap ripple wave
            val p = rippleProgress.value
            if (p < 0.99f) {
                val r = maxRadius * (0.35f + p * 0.65f)
                val alpha = (1f - p).coerceIn(0f, 1f)
                drawCircle(
                    color = pulseAccent.copy(alpha = alpha * 0.85f),
                    radius = r,
                    center = center,
                    style = Stroke(width = (3.5f * (1f - p) + 1f).dp.toPx())
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Rounded.TouchApp,
                contentDescription = null,
                tint = activeColor,
                modifier = Modifier.size(30.dp)
            )
            Text(
                text = rawTapCount.toString(),
                style = MonoTelemetryStyle.copy(
                    fontSize = MaterialTheme.typography.headlineMedium.fontSize,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun LiveAccelerationWaveform(
    samples: List<Float>,
    threshold: Float,
    modifier: Modifier = Modifier
) {
    val lineColor = MaterialTheme.colorScheme.primary
    val thresholdColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.85f)
    val zeroAxisColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val fillBrush = Brush.verticalGradient(
        colors = listOf(
            lineColor.copy(alpha = 0.28f),
            Color.Transparent
        )
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(124.dp)
    ) {
        val width = size.width
        val height = size.height
        val midY = height / 2f

        val maxScale = max(threshold * 1.8f, 12f)

        // Zero centerline
        drawLine(
            color = zeroAxisColor,
            start = Offset(0f, midY),
            end = Offset(width, midY),
            strokeWidth = 1.dp.toPx()
        )

        // Positive and negative threshold dashed lines
        val threshOffsetY = (threshold / maxScale).coerceIn(0f, 0.95f) * (height / 2f)
        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
        drawLine(
            color = thresholdColor,
            start = Offset(0f, midY - threshOffsetY),
            end = Offset(width, midY - threshOffsetY),
            strokeWidth = 1.2.dp.toPx(),
            pathEffect = dashEffect
        )
        drawLine(
            color = thresholdColor,
            start = Offset(0f, midY + threshOffsetY),
            end = Offset(width, midY + threshOffsetY),
            strokeWidth = 1.2.dp.toPx(),
            pathEffect = dashEffect
        )

        if (samples.size >= 2) {
            val stepX = width / (samples.size - 1).coerceAtLeast(1)
            val linePath = Path()
            val areaPath = Path()

            samples.forEachIndexed { index, value ->
                val x = index * stepX
                val clamped = (value / maxScale).coerceIn(-0.95f, 0.95f)
                val y = midY - clamped * (height / 2f)
                if (index == 0) {
                    linePath.moveTo(x, y)
                    areaPath.moveTo(x, midY)
                    areaPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    areaPath.lineTo(x, y)
                }
            }
            areaPath.lineTo(width, midY)
            areaPath.close()

            drawPath(path = areaPath, brush = fillBrush)
            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(
                    width = 2.4.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}
