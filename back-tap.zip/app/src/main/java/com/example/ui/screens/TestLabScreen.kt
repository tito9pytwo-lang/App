package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.TapPulseEvent
import com.example.model.SensorCapabilities
import com.example.model.ServiceState
import com.example.model.TapStats
import com.example.model.TelemetrySnapshot
import com.example.ui.components.BackTapPulseCanvas
import com.example.ui.components.LiveAccelerationWaveform
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.MonoTelemetryStyle
import com.example.ui.viewmodel.GuidedTestStep
import kotlinx.coroutines.flow.SharedFlow
import java.util.Locale

@Composable
fun TestLabScreen(
    serviceState: ServiceState,
    sensorCapabilities: SensorCapabilities,
    telemetry: TelemetrySnapshot,
    waveformSamples: List<Float>,
    stats: TapStats,
    safeTestMode: Boolean,
    guidedTestStep: GuidedTestStep,
    pulseEvents: SharedFlow<TapPulseEvent>,
    onToggleService: (Boolean) -> Unit,
    onSafeTestModeChange: (Boolean) -> Unit,
    onResetStats: () -> Unit,
    onStartGuidedTest: () -> Unit,
    onCompleteShakeManually: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Live Tap Tester Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.testHeroTitle,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = strings.testHeroDesc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(
                                onClick = onResetStats,
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("reset_stats_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.resetCounters)
                            }
                        }

                        BackTapPulseCanvas(
                            serviceState = serviceState,
                            rawTapCount = stats.rawTapCount,
                            pulseEvents = pulseEvents
                        )

                        if (serviceState == ServiceState.STOPPED && sensorCapabilities.isSupported) {
                            Button(
                                onClick = { onToggleService(true) },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("test_lab_start_service_button")
                            ) {
                                Text(strings.turnOnService)
                            }
                        }

                        // Counters Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CounterMetricTile(
                                label = strings.doubleTapsLabel,
                                value = stats.doubleTapCount.toString(),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            CounterMetricTile(
                                label = strings.tripleTapsLabel,
                                value = stats.tripleTapCount.toString(),
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.weight(1f)
                            )
                            CounterMetricTile(
                                label = strings.rejectedNoiseLabel,
                                value = stats.rejectedNoiseCount.toString(),
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Safe Test Mode Toggle
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.safeTestModeTitle,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = strings.safeTestModeDesc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = safeTestMode,
                                    onCheckedChange = onSafeTestModeChange,
                                    modifier = Modifier.testTag("safe_test_mode_switch")
                                )
                            }
                        }
                    }
                }
            }

            // 2. Live Waveform Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.liveWaveformTitle,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "${strings.thresholdLabel}: ${
                                    String.format(Locale.US, "%.1f", telemetry.currentThreshold)
                                } m/s²",
                                style = MonoTelemetryStyle,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }

                        LiveAccelerationWaveform(
                            samples = waveformSamples,
                            threshold = telemetry.currentThreshold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Z: ${String.format(Locale.US, "%+.2f", telemetry.zAccel)} m/s²",
                                style = MonoTelemetryStyle,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "XY: ${String.format(Locale.US, "%.2f", telemetry.xyAccel)} m/s²",
                                style = MonoTelemetryStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Gyro: ${String.format(Locale.US, "%.2f", telemetry.gyroMagnitude)} rad/s",
                                style = MonoTelemetryStyle,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // 3. Guided Practical Compatibility Test Card
            item {
                GuidedPracticalTestCard(
                    step = guidedTestStep,
                    sensorSupported = sensorCapabilities.isSupported,
                    onStartTest = onStartGuidedTest,
                    onCompleteShake = onCompleteShakeManually
                )
            }

            // 4. Hardware Sensor Diagnostics Card
            item {
                HardwareDiagnosticsCard(capabilities = sensorCapabilities)
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun CounterMetricTile(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MonoTelemetryStyle.copy(
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    fontWeight = FontWeight.Bold
                ),
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun GuidedPracticalTestCard(
    step: GuidedTestStep,
    sensorSupported: Boolean,
    onStartTest: () -> Unit,
    onCompleteShake: () -> Unit
) {
    val strings = LocalAppStrings.current
    val progress = when (step) {
        GuidedTestStep.IDLE -> 0f
        GuidedTestStep.WAITING_DOUBLE_TAP -> 0.25f
        GuidedTestStep.WAITING_TRIPLE_TAP -> 0.55f
        GuidedTestStep.WAITING_SHAKE_TEST -> 0.80f
        GuidedTestStep.PASSED -> 1.0f
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Science,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.guidedTestTitle,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Text(
                text = strings.guidedTestDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (step != GuidedTestStep.IDLE) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )

                val stepMessage = when (step) {
                    GuidedTestStep.WAITING_DOUBLE_TAP -> strings.guidedStepDouble
                    GuidedTestStep.WAITING_TRIPLE_TAP -> strings.guidedStepTriple
                    GuidedTestStep.WAITING_SHAKE_TEST -> strings.guidedStepShake
                    GuidedTestStep.PASSED -> strings.guidedTestPassed
                    GuidedTestStep.IDLE -> ""
                }

                Surface(
                    color = if (step == GuidedTestStep.PASSED) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (step == GuidedTestStep.PASSED) {
                                Icons.Rounded.CheckCircle
                            } else {
                                Icons.Rounded.Info
                            },
                            contentDescription = null,
                            tint = if (step == GuidedTestStep.PASSED) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                MaterialTheme.colorScheme.primary
                            }
                        )
                        Text(
                            text = stepMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartTest,
                    enabled = sensorSupported,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("start_guided_test_button")
                ) {
                    Text(strings.startGuidedTest)
                }

                if (step == GuidedTestStep.WAITING_SHAKE_TEST) {
                    OutlinedButton(
                        onClick = onCompleteShake,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("confirm_shake_step_button")
                    ) {
                        Text(strings.skipShakeCheck)
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareDiagnosticsCard(capabilities: SensorCapabilities) {
    val strings = LocalAppStrings.current

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Sensors,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = strings.hardwareCheckTitle,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            SensorRowItem(strings.sensorLinearLabel, capabilities.hasLinearAcceleration)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorAccelLabel, capabilities.hasAccelerometer)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorGyroLabel, capabilities.hasGyroscope)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            SensorRowItem(strings.sensorFlashLabel, capabilities.hasFlashlight)

            if (capabilities.isUsingFallback) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = strings.fallbackModeNotice,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SensorRowItem(label: String, available: Boolean) {
    val strings = LocalAppStrings.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Surface(
            color = if (available) {
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)
            } else {
                MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
            },
            shape = RoundedCornerShape(50.dp)
        ) {
            Text(
                text = if (available) strings.availableLabel else strings.unavailableLabel,
                style = MaterialTheme.typography.labelMedium,
                color = if (available) {
                    MaterialTheme.colorScheme.secondary
                } else {
                    MaterialTheme.colorScheme.error
                },
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}
