package com.example.ui.viewmodel

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.action.ActionExecutor
import com.example.data.BackTapRuntimeState
import com.example.data.InstalledAppsRepository
import com.example.data.SettingsRepository
import com.example.data.TapPulseEvent
import com.example.model.ActionExecutionOutcome
import com.example.model.AppLanguage
import com.example.model.BackTapSettings
import com.example.model.InstalledAppInfo
import com.example.model.SensorCapabilities
import com.example.model.ServiceState
import com.example.model.TapActionConfig
import com.example.model.TapStats
import com.example.model.TelemetrySnapshot
import com.example.model.ThemePreference
import com.example.sensor.SensorDiagnostics
import com.example.service.BackTapAccessibilityService
import com.example.service.BackTapForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class GuidedTestStep {
    IDLE,
    WAITING_DOUBLE_TAP,
    WAITING_TRIPLE_TAP,
    WAITING_SHAKE_TEST,
    PASSED
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val installedAppsRepository = InstalledAppsRepository(application)
    private val actionExecutor = ActionExecutor(application)

    val settings: StateFlow<BackTapSettings> = settingsRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = BackTapSettings()
        )

    val serviceState: StateFlow<ServiceState> = BackTapRuntimeState.serviceState
    val accessibilityEnabled: StateFlow<Boolean> = BackTapRuntimeState.accessibilityEnabled
    val telemetry: StateFlow<TelemetrySnapshot> = BackTapRuntimeState.telemetry
    val waveformSamples: StateFlow<List<Float>> = BackTapRuntimeState.waveformSamples
    val stats: StateFlow<TapStats> = BackTapRuntimeState.stats
    val testLabSafeMode: StateFlow<Boolean> = BackTapRuntimeState.testLabSafeMode
    val pulseEvents: SharedFlow<TapPulseEvent> = BackTapRuntimeState.pulseEvents

    private val _sensorCapabilities = MutableStateFlow(SensorDiagnostics.inspect(application))
    val sensorCapabilities: StateFlow<SensorCapabilities> = _sensorCapabilities.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _appsLoading = MutableStateFlow(true)
    val appsLoading: StateFlow<Boolean> = _appsLoading.asStateFlow()

    private val _notificationPermissionGranted = MutableStateFlow(checkNotificationPermission())
    val notificationPermissionGranted: StateFlow<Boolean> = _notificationPermissionGranted.asStateFlow()

    private val _guidedTestStep = MutableStateFlow(GuidedTestStep.IDLE)
    val guidedTestStep: StateFlow<GuidedTestStep> = _guidedTestStep.asStateFlow()

    private var guidedStartDoubleCount = 0
    private var guidedStartTripleCount = 0
    private var guidedStartNoiseCount = 0

    init {
        refreshSystemStatus()
        loadInstalledApps()

        // Auto-resume service if user previously enabled it and sensors are available
        viewModelScope.launch {
            val initial = settingsRepository.settingsFlow.first()
            if (initial.serviceEnabled && _sensorCapabilities.value.isSupported) {
                BackTapForegroundService.start(getApplication())
            }
        }

        // Advance guided practical test automatically as real gestures arrive
        viewModelScope.launch {
            stats.collect { currentStats ->
                when (_guidedTestStep.value) {
                    GuidedTestStep.WAITING_DOUBLE_TAP -> {
                        if (currentStats.doubleTapCount > guidedStartDoubleCount) {
                            guidedStartTripleCount = currentStats.tripleTapCount
                            _guidedTestStep.value = GuidedTestStep.WAITING_TRIPLE_TAP
                        }
                    }

                    GuidedTestStep.WAITING_TRIPLE_TAP -> {
                        if (currentStats.tripleTapCount > guidedStartTripleCount) {
                            guidedStartNoiseCount = currentStats.rejectedNoiseCount
                            _guidedTestStep.value = GuidedTestStep.WAITING_SHAKE_TEST
                        }
                    }

                    GuidedTestStep.WAITING_SHAKE_TEST -> {
                        if (currentStats.rejectedNoiseCount > guidedStartNoiseCount) {
                            _guidedTestStep.value = GuidedTestStep.PASSED
                        }
                    }

                    else -> Unit
                }
            }
        }
    }

    override fun onCleared() {
        actionExecutor.release()
        super.onCleared()
    }

    fun refreshSystemStatus() {
        val ctx = getApplication<Application>()
        _sensorCapabilities.value = SensorDiagnostics.inspect(ctx)
        _notificationPermissionGranted.value = checkNotificationPermission()
        BackTapRuntimeState.setAccessibilityEnabled(
            BackTapAccessibilityService.isAccessibilityServiceEnabled(ctx)
        )
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _appsLoading.value = true
            _installedApps.value = installedAppsRepository.loadLaunchableApps()
            _appsLoading.value = false
        }
    }

    fun toggleService(enable: Boolean) {
        viewModelScope.launch {
            settingsRepository.setServiceEnabled(enable)
            val ctx = getApplication<Application>()
            if (enable) {
                BackTapForegroundService.start(ctx)
            } else {
                BackTapForegroundService.stop(ctx)
            }
        }
    }

    fun setDoubleTapAction(config: TapActionConfig) {
        viewModelScope.launch {
            settingsRepository.setDoubleTapAction(config)
        }
    }

    fun setTripleTapAction(config: TapActionConfig) {
        viewModelScope.launch {
            settingsRepository.setTripleTapAction(config)
        }
    }

    fun setSensitivity(sensitivity: Float) {
        viewModelScope.launch {
            settingsRepository.setSensitivity(sensitivity)
        }
    }

    fun setTapIntervalMs(intervalMs: Int) {
        viewModelScope.launch {
            settingsRepository.setTapIntervalMs(intervalMs)
        }
    }

    fun setAntiMotionFilterEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAntiMotionFilterEnabled(enabled)
        }
    }

    fun setPauseWhenScreenOff(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setPauseWhenScreenOff(enabled)
        }
    }

    fun setHapticFeedbackEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setHapticFeedbackEnabled(enabled)
        }
    }

    fun setThemePreference(theme: ThemePreference) {
        viewModelScope.launch {
            settingsRepository.setThemePreference(theme)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsRepository.setLanguage(language)
        }
    }

    fun setTestLabSafeMode(safeMode: Boolean) {
        BackTapRuntimeState.setTestLabSafeMode(safeMode)
    }

    fun setTestLabVisible(visible: Boolean) {
        BackTapRuntimeState.setTestLabVisible(visible)
    }

    fun resetTestStats() {
        BackTapRuntimeState.resetStats()
    }

    fun startGuidedTest() {
        if (!settings.value.serviceEnabled && _sensorCapabilities.value.isSupported) {
            toggleService(true)
        }
        BackTapRuntimeState.setTestLabSafeMode(true)
        val current = stats.value
        guidedStartDoubleCount = current.doubleTapCount
        guidedStartTripleCount = current.tripleTapCount
        guidedStartNoiseCount = current.rejectedNoiseCount
        _guidedTestStep.value = GuidedTestStep.WAITING_DOUBLE_TAP
    }

    fun completeShakeStepManually() {
        if (_guidedTestStep.value == GuidedTestStep.WAITING_SHAKE_TEST) {
            _guidedTestStep.value = GuidedTestStep.PASSED
        }
    }

    fun testActionDirectly(config: TapActionConfig): ActionExecutionOutcome {
        return actionExecutor.execute(
            config = config,
            hapticEnabled = settings.value.hapticFeedbackEnabled,
            isAppInForeground = true
        )
    }

    fun launchInstalledApp(packageName: String): ActionExecutionOutcome {
        return actionExecutor.testLaunchPackage(packageName)
    }

    fun openAccessibilitySettings() {
        val ctx = getApplication<Application>()
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    }

    private fun checkNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            getApplication(),
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }
}
