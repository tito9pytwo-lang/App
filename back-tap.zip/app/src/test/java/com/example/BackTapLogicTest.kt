package com.example

import com.example.data.BackTapRuntimeState
import com.example.model.ActionExecutionOutcome
import com.example.model.AppLanguage
import com.example.model.SensorCapabilities
import com.example.model.SensorMode
import com.example.model.ServiceState
import com.example.model.TapActionConfig
import com.example.model.TapActionType
import com.example.model.TelemetrySnapshot
import com.example.ui.i18n.stringsFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class BackTapLogicTest {

    @Before
    fun setup() {
        BackTapRuntimeState.resetStats()
        BackTapRuntimeState.setTestLabVisible(false)
        BackTapRuntimeState.setTestLabSafeMode(true)
        BackTapRuntimeState.setServiceState(ServiceState.STOPPED)
        BackTapRuntimeState.setAccessibilityEnabled(false)
    }

    @Test
    fun `sensor capabilities accurately classify fallback mode when gyroscope missing`() {
        val accelOnly = SensorCapabilities(
            hasAccelerometer = true,
            hasLinearAcceleration = false,
            hasGyroscope = false,
            hasFlashlight = true,
            sensorMode = SensorMode.ACCEL_ONLY
        )
        assertTrue(accelOnly.isSupported)
        assertTrue(accelOnly.isUsingFallback)

        val fullSensors = SensorCapabilities(
            hasAccelerometer = true,
            hasLinearAcceleration = true,
            hasGyroscope = true,
            hasFlashlight = true,
            sensorMode = SensorMode.LINEAR_ACCEL_AND_GYRO
        )
        assertTrue(fullSensors.isSupported)
        assertFalse(fullSensors.isUsingFallback)

        val unsupported = SensorCapabilities(
            hasAccelerometer = false,
            hasLinearAcceleration = false,
            hasGyroscope = false,
            hasFlashlight = false,
            sensorMode = SensorMode.UNSUPPORTED
        )
        assertFalse(unsupported.isSupported)
    }

    @Test
    fun `runtime state tracks tap stats, waveform buffer, and safe test mode suppression`() {
        BackTapRuntimeState.recordRawTap(100L)
        BackTapRuntimeState.recordDoubleTap(200L)
        BackTapRuntimeState.recordTripleTap(500L)
        BackTapRuntimeState.recordRejectedNoise()
        BackTapRuntimeState.recordActionOutcome(ActionExecutionOutcome.SUCCESS)

        val stats = BackTapRuntimeState.stats.value
        assertEquals(1, stats.rawTapCount)
        assertEquals(1, stats.doubleTapCount)
        assertEquals(1, stats.tripleTapCount)
        assertEquals(1, stats.rejectedNoiseCount)
        assertEquals(ActionExecutionOutcome.SUCCESS, stats.lastActionResult)

        // Safe test mode suppresses action execution only while TestLab is visible
        assertFalse(BackTapRuntimeState.shouldSuppressActionExecution())
        BackTapRuntimeState.setTestLabVisible(true)
        assertTrue(BackTapRuntimeState.shouldSuppressActionExecution())
        BackTapRuntimeState.setTestLabSafeMode(false)
        assertFalse(BackTapRuntimeState.shouldSuppressActionExecution())

        // Waveform keeps fixed capacity of 64 samples
        repeat(80) { i ->
            BackTapRuntimeState.updateTelemetry(TelemetrySnapshot(timestampMs = i.toLong(), zAccel = i * 0.1f))
        }
        assertEquals(64, BackTapRuntimeState.waveformSamples.value.size)

        BackTapRuntimeState.resetStats()
        assertEquals(0, BackTapRuntimeState.stats.value.rawTapCount)
    }

    @Test
    fun `bilingual strings format app actions and permission outcomes`() {
        val ar = stringsFor(AppLanguage.ARABIC)
        val en = stringsFor(AppLanguage.ENGLISH)

        val whatsappConfig = TapActionConfig(
            type = TapActionType.OPEN_APP,
            targetPackage = "com.whatsapp",
            targetAppLabel = "WhatsApp"
        )

        assertTrue(ar.actionLabel(whatsappConfig).contains("WhatsApp"))
        assertTrue(en.actionLabel(whatsappConfig).contains("WhatsApp"))

        assertTrue(
            ar.outcomeMessage(ActionExecutionOutcome.NEEDS_ACCESSIBILITY_SERVICE, isArabic = true)
                .contains("إمكانية الوصول")
        )
        assertTrue(
            en.outcomeMessage(ActionExecutionOutcome.NEEDS_ACCESSIBILITY_SERVICE, isArabic = false)
                .contains("Accessibility Service")
        )
    }
}
