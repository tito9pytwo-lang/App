package com.example

import com.example.model.TelemetrySnapshot
import com.example.sensor.TapDetectorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class TapDetectorEngineTest {

    private var rawTaps = 0
    private var doubleTaps = 0
    private var tripleTaps = 0
    private var rejectedNoise = 0

    private lateinit var engine: TapDetectorEngine

    @Before
    fun setup() {
        rawTaps = 0
        doubleTaps = 0
        tripleTaps = 0
        rejectedNoise = 0
        engine = TapDetectorEngine(object : TapDetectorEngine.Listener {
            override fun onRawTap(chainCount: Int, timestampMs: Long) {
                rawTaps++
            }

            override fun onDoubleTap(timestampMs: Long) {
                doubleTaps++
            }

            override fun onTripleTap(timestampMs: Long) {
                tripleTaps++
            }

            override fun onRejectedNoise(timestampMs: Long) {
                rejectedNoise++
            }

            override fun onTelemetry(snapshot: TelemetrySnapshot) = Unit
        })
    }

    @Test
    fun `detects double tap immediately when triple tap disabled`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 420,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        feedRestSamples(0L, 100L)
        feedTapImpulse(120L)
        feedRestSamples(140L, 260L)
        feedTapImpulse(300L)

        assertEquals(2, rawTaps)
        assertEquals(1, doubleTaps)
        assertEquals(0, tripleTaps)
    }

    @Test
    fun `detects double tap after interval timeout when triple tap enabled`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 400,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        feedRestSamples(0L, 80L)
        feedTapImpulse(100L)
        feedRestSamples(120L, 240L)
        feedTapImpulse(280L)

        // Before 400ms expires, double tap should wait for possible 3rd tap
        assertEquals(0, doubleTaps)

        engine.checkPendingDoubleTap(685L)
        assertEquals(1, doubleTaps)
        assertEquals(0, tripleTaps)
    }

    @Test
    fun `detects triple tap and suppresses double tap`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 420,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        feedRestSamples(0L, 60L)
        feedTapImpulse(80L)
        feedRestSamples(100L, 200L)
        feedTapImpulse(220L)
        feedRestSamples(240L, 340L)
        feedTapImpulse(360L)

        engine.checkPendingDoubleTap(900L)
        assertEquals(3, rawTaps)
        assertEquals(0, doubleTaps)
        assertEquals(1, tripleTaps)
    }

    @Test
    fun `rejects tap spikes during high gyroscope rotation`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 420,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        feedRestSamples(0L, 60L)
        engine.onGyroscopeSample(3.2f, 1.5f, 0.5f, 90L)
        feedTapImpulse(100L)
        feedRestSamples(120L, 220L)
        engine.onGyroscopeSample(3.0f, 1.0f, 0.4f, 230L)
        feedTapImpulse(240L)

        assertEquals(0, rawTaps)
        assertEquals(0, doubleTaps)
        assertTrue(rejectedNoise >= 1)
    }

    @Test
    fun `rejects sustained shaking motion`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 420,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = true
        )

        // Simulate 10 consecutive elevated samples (shaking/walking)
        var t = 0L
        repeat(10) { i ->
            val z = if (i % 2 == 0) 6.8f else -6.8f
            engine.onAccelerometerSample(2.5f, 2.5f, z, t, isLinearAcceleration = true)
            t += 20L
        }

        assertEquals(0, doubleTaps)
        assertTrue(rejectedNoise >= 1)
    }

    @Test
    fun `raw accelerometer high pass filter ignores static gravity and detects tap`() {
        engine.updateConfig(
            sensitivity = 0.60f,
            tapIntervalMs = 420,
            antiMotionFilterEnabled = true,
            tripleTapEnabled = false
        )

        // Resting phone with 9.81 m/s^2 gravity on Z axis
        var t = 0L
        repeat(15) {
            engine.onAccelerometerSample(0f, 0f, 9.81f, t, isLinearAcceleration = false)
            t += 20L
        }
        assertEquals(0, rawTaps)

        // Tap 1 on top of gravity
        engine.onAccelerometerSample(0.2f, 0.1f, 9.81f + 9.0f, t, isLinearAcceleration = false)
        t += 20L
        repeat(8) {
            engine.onAccelerometerSample(0f, 0f, 9.81f, t, isLinearAcceleration = false)
            t += 20L
        }

        // Tap 2 on top of gravity
        engine.onAccelerometerSample(0.2f, 0.1f, 9.81f + 9.0f, t, isLinearAcceleration = false)

        assertEquals(2, rawTaps)
        assertEquals(1, doubleTaps)
    }

    private fun feedRestSamples(startMs: Long, endMs: Long) {
        var t = startMs
        while (t <= endMs) {
            engine.onAccelerometerSample(0f, 0f, 0f, t, isLinearAcceleration = true)
            t += 20L
        }
    }

    private fun feedTapImpulse(timestampMs: Long) {
        engine.onAccelerometerSample(0.4f, 0.3f, 8.2f, timestampMs, isLinearAcceleration = true)
    }
}
