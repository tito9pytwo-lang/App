package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber

data class CapsuleSettings(
  val serviceEnabled: Boolean = true,
  val notchOffsetYDp: Int = 0, // Glued to the very top edge by default
  val capsuleWidthDp: Int = 190,
  val capsuleHeightDp: Int = 36,
  val accentColorIndex: Int = 0,
  val autoCollapseSeconds: Int = 0, // 0 = manual / outside touch collapse only
  val showWhenIdle: Boolean = true,
  val hapticFeedback: Boolean = true,
  // 10 Features toggles
  val enableBatteryAlerts: Boolean = true,
  val enableCallAlerts: Boolean = true,
  val enableTimer: Boolean = true,
  val enableNetSpeed: Boolean = false,
  val enableNotifications: Boolean = true,
  val enableBluetoothAlerts: Boolean = true,
  val enableFlashlightAlert: Boolean = true,
  val enableSportsLive: Boolean = false,
  val enableClockDate: Boolean = false
) {
  val accentColor: Color
    get() = when (accentColorIndex) {
      0 -> RealmeGreen
      1 -> CyberCyan
      2 -> ElectricPurple
      3 -> SunsetAmber
      4 -> Color(0xFFFFFFFF) // Apple dynamic white/silver accent
      else -> RealmeGreen
    }
}
