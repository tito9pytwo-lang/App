package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CapsuleSettingsManager private constructor(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("dynamic_capsule_prefs", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(loadSettings())
  val settings: StateFlow<CapsuleSettings> = _settings.asStateFlow()

  private fun loadSettings(): CapsuleSettings {
    return CapsuleSettings(
      serviceEnabled = prefs.getBoolean(KEY_SERVICE_ENABLED, true),
      notchOffsetYDp = prefs.getInt(KEY_NOTCH_OFFSET_Y, 0),
      capsuleWidthDp = prefs.getInt(KEY_CAPSULE_WIDTH, 190),
      capsuleHeightDp = prefs.getInt(KEY_CAPSULE_HEIGHT, 36),
      accentColorIndex = prefs.getInt(KEY_ACCENT_COLOR, 0),
      autoCollapseSeconds = prefs.getInt(KEY_AUTO_COLLAPSE, 0),
      showWhenIdle = prefs.getBoolean(KEY_SHOW_WHEN_IDLE, true),
      hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true),
      enableBatteryAlerts = prefs.getBoolean(KEY_BATTERY_ALERTS, true),
      enableCallAlerts = prefs.getBoolean(KEY_CALL_ALERTS, true),
      enableTimer = prefs.getBoolean(KEY_TIMER, true),
      enableNetSpeed = prefs.getBoolean(KEY_NET_SPEED, false),
      enableNotifications = prefs.getBoolean(KEY_NOTIFICATIONS, true),
      enableBluetoothAlerts = prefs.getBoolean(KEY_BLUETOOTH_ALERTS, true),
      enableFlashlightAlert = prefs.getBoolean(KEY_FLASHLIGHT_ALERT, true),
      enableSportsLive = prefs.getBoolean(KEY_SPORTS_LIVE, false),
      enableClockDate = prefs.getBoolean(KEY_CLOCK_DATE, false)
    )
  }

  fun updateServiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    _settings.value = _settings.value.copy(serviceEnabled = enabled)
  }

  fun updateNotchOffsetY(offset: Int) {
    prefs.edit().putInt(KEY_NOTCH_OFFSET_Y, offset).apply()
    _settings.value = _settings.value.copy(notchOffsetYDp = offset)
  }

  fun updateCapsuleWidth(width: Int) {
    prefs.edit().putInt(KEY_CAPSULE_WIDTH, width).apply()
    _settings.value = _settings.value.copy(capsuleWidthDp = width)
  }

  fun updateCapsuleHeight(height: Int) {
    prefs.edit().putInt(KEY_CAPSULE_HEIGHT, height).apply()
    _settings.value = _settings.value.copy(capsuleHeightDp = height)
  }

  fun updateAccentColorIndex(index: Int) {
    prefs.edit().putInt(KEY_ACCENT_COLOR, index).apply()
    _settings.value = _settings.value.copy(accentColorIndex = index)
  }

  fun updateAutoCollapseSeconds(seconds: Int) {
    prefs.edit().putInt(KEY_AUTO_COLLAPSE, seconds).apply()
    _settings.value = _settings.value.copy(autoCollapseSeconds = seconds)
  }

  fun updateShowWhenIdle(show: Boolean) {
    prefs.edit().putBoolean(KEY_SHOW_WHEN_IDLE, show).apply()
    _settings.value = _settings.value.copy(showWhenIdle = show)
  }

  fun toggleFeature(featureKey: String, enabled: Boolean) {
    prefs.edit().putBoolean(featureKey, enabled).apply()
    _settings.value = when (featureKey) {
      KEY_BATTERY_ALERTS -> _settings.value.copy(enableBatteryAlerts = enabled)
      KEY_CALL_ALERTS -> _settings.value.copy(enableCallAlerts = enabled)
      KEY_TIMER -> _settings.value.copy(enableTimer = enabled)
      KEY_NET_SPEED -> _settings.value.copy(enableNetSpeed = enabled)
      KEY_NOTIFICATIONS -> _settings.value.copy(enableNotifications = enabled)
      KEY_BLUETOOTH_ALERTS -> _settings.value.copy(enableBluetoothAlerts = enabled)
      KEY_FLASHLIGHT_ALERT -> _settings.value.copy(enableFlashlightAlert = enabled)
      KEY_SPORTS_LIVE -> _settings.value.copy(enableSportsLive = enabled)
      KEY_CLOCK_DATE -> _settings.value.copy(enableClockDate = enabled)
      else -> _settings.value
    }
  }

  companion object {
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_NOTCH_OFFSET_Y = "notch_offset_y"
    private const val KEY_CAPSULE_WIDTH = "capsule_width"
    private const val KEY_CAPSULE_HEIGHT = "capsule_height"
    private const val KEY_ACCENT_COLOR = "accent_color"
    private const val KEY_AUTO_COLLAPSE = "auto_collapse"
    private const val KEY_SHOW_WHEN_IDLE = "show_when_idle"
    private const val KEY_HAPTIC = "haptic"

    const val KEY_BATTERY_ALERTS = "enable_battery_alerts"
    const val KEY_CALL_ALERTS = "enable_call_alerts"
    const val KEY_TIMER = "enable_timer"
    const val KEY_NET_SPEED = "enable_net_speed"
    const val KEY_NOTIFICATIONS = "enable_notifications"
    const val KEY_BLUETOOTH_ALERTS = "enable_bluetooth_alerts"
    const val KEY_FLASHLIGHT_ALERT = "enable_flashlight_alert"
    const val KEY_SPORTS_LIVE = "enable_sports_live"
    const val KEY_CLOCK_DATE = "enable_clock_date"

    @Volatile
    private var INSTANCE: CapsuleSettingsManager? = null

    fun getInstance(context: Context): CapsuleSettingsManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: CapsuleSettingsManager(context).also { INSTANCE = it }
      }
    }
  }
}
