package com.example.island

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object IslandStateManager {

  private const val TAG = "IslandStateManager"
  private val scope = CoroutineScope(Dispatchers.Main + Job())

  // States
  private val _batteryState = MutableStateFlow(BatteryState())
  val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

  private val _callState = MutableStateFlow(CallState())
  val callState: StateFlow<CallState> = _callState.asStateFlow()

  private val _timerState = MutableStateFlow(TimerState())
  val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

  private val _netSpeedState = MutableStateFlow(NetSpeedState())
  val netSpeedState: StateFlow<NetSpeedState> = _netSpeedState.asStateFlow()

  private val _activeNotification = MutableStateFlow<NotificationEvent?>(null)
  val activeNotification: StateFlow<NotificationEvent?> = _activeNotification.asStateFlow()

  private val _bluetoothState = MutableStateFlow(BluetoothState())
  val bluetoothState: StateFlow<BluetoothState> = _bluetoothState.asStateFlow()

  private val _flashlightState = MutableStateFlow(FlashlightState())
  val flashlightState: StateFlow<FlashlightState> = _flashlightState.asStateFlow()

  private val _sportsState = MutableStateFlow(SportsState())
  val sportsState: StateFlow<SportsState> = _sportsState.asStateFlow()

  private val _timeString = MutableStateFlow(formatCurrentTime())
  val timeString: StateFlow<String> = _timeString.asStateFlow()

  private val _dateString = MutableStateFlow(formatCurrentDate())
  val dateString: StateFlow<String> = _dateString.asStateFlow()

  // Active overlay feature
  private val _activeCard = MutableStateFlow(IslandActiveCard.MUSIC)
  val activeCard: StateFlow<IslandActiveCard> = _activeCard.asStateFlow()

  private var timerJob: Job? = null
  private var callTickerJob: Job? = null
  private var netSpeedJob: Job? = null
  private var clockJob: Job? = null
  private var notificationExpireJob: Job? = null
  private var batteryExpireJob: Job? = null

  private var lastRxBytes: Long = 0L
  private var lastSpeedCheckTime: Long = 0L

  private var cameraManager: CameraManager? = null
  private var torchCallback: CameraManager.TorchCallback? = null
  private var isInitialized = false

  fun initialize(context: Context) {
    if (isInitialized) return
    isInitialized = true

    registerBatteryReceiver(context)
    startClockTicker()
    initFlashlight(context)
  }

  private fun registerBatteryReceiver(context: Context) {
    val filter = IntentFilter().apply {
      addAction(Intent.ACTION_POWER_CONNECTED)
      addAction(Intent.ACTION_POWER_DISCONNECTED)
      addAction(Intent.ACTION_BATTERY_CHANGED)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
          Intent.ACTION_POWER_CONNECTED -> {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            showBatteryCharging(pct)
          }
          Intent.ACTION_POWER_DISCONNECTED -> {
            _batteryState.value = _batteryState.value.copy(
              isCharging = false,
              lastEventTime = System.currentTimeMillis()
            )
          }
          Intent.ACTION_BATTERY_CHANGED -> {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
              status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            val isLow = pct <= 20 && !isCharging

            _batteryState.value = _batteryState.value.copy(
              isCharging = isCharging,
              percentage = pct,
              isLow = isLow
            )
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering battery receiver", e)
    }
  }

  fun showBatteryCharging(pct: Int) {
    _batteryState.value = BatteryState(
      isCharging = true,
      percentage = pct,
      isLow = false,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Timer controls
  fun startTimer(seconds: Int, title: String = "Timer") {
    timerJob?.cancel()
    _timerState.value = TimerState(
      isRunning = true,
      remainingSeconds = seconds,
      totalSeconds = seconds,
      title = title
    )
    _activeCard.value = IslandActiveCard.TIMER

    timerJob = scope.launch {
      while (isActive && _timerState.value.remainingSeconds > 0) {
        delay(1000)
        val current = _timerState.value
        if (!current.isRunning) break
        val remaining = current.remainingSeconds - 1
        _timerState.value = current.copy(remainingSeconds = remaining)
        if (remaining <= 0) {
          _timerState.value = current.copy(isRunning = false, remainingSeconds = 0)
          break
        }
      }
    }
  }

  fun toggleTimerPause() {
    val cur = _timerState.value
    if (cur.isRunning) {
      _timerState.value = cur.copy(isRunning = false)
    } else if (cur.remainingSeconds > 0) {
      startTimer(cur.remainingSeconds, cur.title)
    }
  }

  fun cancelTimer() {
    timerJob?.cancel()
    _timerState.value = TimerState()
    if (_activeCard.value == IslandActiveCard.TIMER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Call simulation and controls
  fun startCall(caller: String = "Tania Castillo", isIncoming: Boolean = true) {
    callTickerJob?.cancel()
    _callState.value = CallState(
      isActive = true,
      callerName = caller,
      callerNumber = "Mobile",
      durationSeconds = 0,
      isIncoming = isIncoming
    )
    _activeCard.value = IslandActiveCard.CALL

    if (!isIncoming) {
      startCallTicker()
    }
  }

  fun answerCall() {
    val cur = _callState.value
    _callState.value = cur.copy(isIncoming = false)
    startCallTicker()
  }

  private fun startCallTicker() {
    callTickerJob?.cancel()
    callTickerJob = scope.launch {
      while (isActive && _callState.value.isActive) {
        delay(1000)
        val cur = _callState.value
        _callState.value = cur.copy(durationSeconds = cur.durationSeconds + 1)
      }
    }
  }

  fun endCall() {
    callTickerJob?.cancel()
    _callState.value = CallState()
    if (_activeCard.value == IslandActiveCard.CALL) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Notification Event
  fun postNotificationEvent(appName: String, title: String, text: String, pkg: String = "") {
    val event = NotificationEvent(
      id = System.currentTimeMillis(),
      packageName = pkg,
      appName = appName,
      title = title,
      text = text,
      timestamp = System.currentTimeMillis()
    )
    _activeNotification.value = event
    _activeCard.value = IslandActiveCard.NOTIFICATION

    notificationExpireJob?.cancel()
    notificationExpireJob = scope.launch {
      delay(4500)
      if (_activeNotification.value?.id == event.id) {
        _activeNotification.value = null
        if (_activeCard.value == IslandActiveCard.NOTIFICATION) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  // Bluetooth Event
  fun showBluetoothConnected(deviceName: String = "AirPods Pro", batteryPct: Int = 90) {
    _bluetoothState.value = BluetoothState(
      isConnected = true,
      deviceName = deviceName,
      batteryPct = batteryPct,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BLUETOOTH

    scope.launch {
      delay(5500)
      if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Flashlight
  private fun initFlashlight(context: Context) {
    try {
      cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
      torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
          super.onTorchModeChanged(cameraId, enabled)
          _flashlightState.value = FlashlightState(isOn = enabled)
          if (enabled) {
            _activeCard.value = IslandActiveCard.FLASHLIGHT
          } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
            _activeCard.value = IslandActiveCard.MUSIC
          }
        }
      }
      torchCallback?.let { cameraManager?.registerTorchCallback(it, null) }
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing camera torch callback", e)
    }
  }

  fun toggleFlashlight(context: Context) {
    try {
      val cam = cameraManager ?: context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
      val firstCamId = cam?.cameraIdList?.firstOrNull() ?: return
      val newMode = !_flashlightState.value.isOn
      cam.setTorchMode(firstCamId, newMode)
      _flashlightState.value = FlashlightState(isOn = newMode)
    } catch (e: Exception) {
      Log.e(TAG, "Failed to toggle flashlight", e)
      // Local fallback toggle for UI
      val newMode = !_flashlightState.value.isOn
      _flashlightState.value = FlashlightState(isOn = newMode)
    }
  }

  // Sports
  fun showSportsScore(
    team1: String = "SF", score1: Int = 5,
    team2: String = "COL", score2: Int = 1,
    status: String = "7th • 0-0",
    headline: String = "Joc Pederson singles on a soft ground ball to first base."
  ) {
    _sportsState.value = SportsState(
      isActive = true,
      team1 = team1,
      score1 = score1,
      team2 = team2,
      score2 = score2,
      status = status,
      headline = headline
    )
    _activeCard.value = IslandActiveCard.SPORTS
  }

  fun dismissSports() {
    _sportsState.value = _sportsState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.SPORTS) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Network Speed Ticker
  fun setNetSpeedEnabled(enabled: Boolean) {
    netSpeedJob?.cancel()
    if (!enabled) {
      _netSpeedState.value = _netSpeedState.value.copy(isEnabled = false)
      return
    }

    _netSpeedState.value = _netSpeedState.value.copy(isEnabled = true)
    lastRxBytes = TrafficStats.getTotalRxBytes()
    lastSpeedCheckTime = SystemClock.elapsedRealtime()

    netSpeedJob = scope.launch {
      while (isActive) {
        delay(1500)
        val now = SystemClock.elapsedRealtime()
        val currentRx = TrafficStats.getTotalRxBytes()
        val elapsedSec = (now - lastSpeedCheckTime) / 1000f

        if (elapsedSec > 0 && currentRx >= lastRxBytes && lastRxBytes > 0) {
          val bytesPerSec = ((currentRx - lastRxBytes) / elapsedSec).toLong()
          val speedText = formatSpeed(bytesPerSec)
          _netSpeedState.value = _netSpeedState.value.copy(downloadSpeedText = speedText)
        }

        lastRxBytes = currentRx
        lastSpeedCheckTime = now
      }
    }
  }

  private fun formatSpeed(bytesPerSec: Long): String {
    return when {
      bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024f * 1024f))
      bytesPerSec >= 1024 -> String.format(Locale.US, "%d KB/s", bytesPerSec / 1024)
      else -> String.format(Locale.US, "%d B/s", bytesPerSec)
    }
  }

  // Clock
  private fun startClockTicker() {
    clockJob?.cancel()
    clockJob = scope.launch {
      while (isActive) {
        _timeString.value = formatCurrentTime()
        _dateString.value = formatCurrentDate()
        delay(30000)
      }
    }
  }

  private fun formatCurrentTime(): String {
    return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
  }

  private fun formatCurrentDate(): String {
    return SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
  }

  fun selectCard(card: IslandActiveCard) {
    _activeCard.value = card
  }
}
