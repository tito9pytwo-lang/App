package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(0)
    assertEquals(0, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateAccentColorIndex(1)
    assertEquals(1, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Test Artist",
      durationMs = 215000L,
      currentPositionMs = 75000L,
      isPlaying = false
    )

    assertEquals("03:35", track.formatTime(track.durationMs))
    assertEquals("01:15", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }

  @Test
  fun `test island state manager features`() {
    IslandStateManager.showBatteryCharging(90)
    assertTrue(IslandStateManager.batteryState.value.isCharging)
    assertEquals(90, IslandStateManager.batteryState.value.percentage)

    IslandStateManager.startTimer(120, "Test Timer")
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertEquals("02:00", IslandStateManager.timerState.value.formatRemaining())
    IslandStateManager.cancelTimer()

    IslandStateManager.startCall("Alice", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertEquals("Alice", IslandStateManager.callState.value.callerName)
    IslandStateManager.endCall()
  }
}
