package com.example.ui.capsule

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CapsuleSettings
import com.example.island.BatteryState
import com.example.island.BluetoothState
import com.example.island.CallState
import com.example.island.DownloadState
import com.example.island.FlashlightState
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NotificationEvent
import com.example.island.RingerState
import com.example.island.SoundMode
import com.example.island.TimerState
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CapsuleMode {
  MINI,
  EXPANDED
}

/**
 * Reusable Marquee Text with soft edge fade ("يتحرك و يختفي")
 * Scrolls horizontally if text is longer than container, and fades at both ends.
 */
@Composable
fun MarqueeFadingText(
  text: String,
  modifier: Modifier = Modifier,
  color: Color = Color.White,
  fontSize: TextUnit = 12.sp,
  fontWeight: FontWeight = FontWeight.Bold,
  maxLines: Int = 1,
  edgeFadeWidth: Dp = 8.dp,
  textAlign: TextAlign? = null
) {
  val edgePx = with(LocalDensity.current) { edgeFadeWidth.toPx() }
  Text(
    text = text,
    color = color,
    fontSize = fontSize,
    fontWeight = fontWeight,
    maxLines = maxLines,
    textAlign = textAlign,
    modifier = modifier
      .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
      .drawWithContent {
        drawContent()
        if (size.width > edgePx * 2) {
          // Left soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Transparent, Color.Black),
              startX = 0f,
              endX = edgePx
            ),
            blendMode = BlendMode.DstIn
          )
          // Right soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Black, Color.Transparent),
              startX = size.width - edgePx,
              endX = size.width
            ),
            blendMode = BlendMode.DstIn
          )
        }
      }
      .basicMarquee(
        iterations = Int.MAX_VALUE,
        repeatDelayMillis = 1400,
        initialDelayMillis = 900,
        velocity = 32.dp
      )
  )
}

@Composable
fun DynamicCapsuleView(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  mode: CapsuleMode,
  onModeChange: (CapsuleMode) -> Unit,
  modifier: Modifier = Modifier,
  onPlayPauseClick: () -> Unit = { MediaSessionHolder.togglePlayPause() },
  onNextClick: () -> Unit = { MediaSessionHolder.skipToNext() },
  onPrevClick: () -> Unit = { MediaSessionHolder.skipToPrevious() },
  onSeek: (Long) -> Unit = { MediaSessionHolder.seekTo(it) },
  onDismissToNotification: () -> Unit = {}
) {
  val accentColor = settings.accentColor
  val activeCard by IslandStateManager.activeCard.collectAsState()
  val batteryState by IslandStateManager.batteryState.collectAsState()
  val callState by IslandStateManager.callState.collectAsState()
  val timerState by IslandStateManager.timerState.collectAsState()
  val notifEvent by IslandStateManager.activeNotification.collectAsState()
  val bluetooth by IslandStateManager.bluetoothState.collectAsState()
  val flashlight by IslandStateManager.flashlightState.collectAsState()
  val ringer by IslandStateManager.ringerState.collectAsState()
  val currentSoundMode by IslandStateManager.currentSoundMode.collectAsState()
  val downloadState by IslandStateManager.downloadState.collectAsState()

  val isExpanded = mode == CapsuleMode.EXPANDED

  val scope = rememberCoroutineScope()
  val dragOffsetX = remember { Animatable(0f) }
  val dragOffsetY = remember { Animatable(0f) }
  val dismissThresholdPx = with(LocalDensity.current) { 55.dp.toPx() }

  // Apple-grade fluid spring morphing dimensions
  val targetWidth = if (isExpanded) 364.dp else 236.dp
  val targetHeight = if (isExpanded) 206.dp else settings.capsuleHeightDp.dp
  val targetCornerRadius = if (isExpanded) 32.dp else 24.dp

  val animatedWidth by animateDpAsState(
    targetValue = targetWidth,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioLowBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_width"
  )
  val animatedHeight by animateDpAsState(
    targetValue = targetHeight,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioLowBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_height"
  )
  val animatedCornerRadius by animateDpAsState(
    targetValue = targetCornerRadius,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_corners"
  )

  Surface(
    modifier = modifier
      .testTag(if (isExpanded) "expanded_capsule_card" else "mini_capsule_surface")
      .graphicsLayer {
        translationX = dragOffsetX.value
        translationY = dragOffsetY.value
        val distance = kotlin.math.hypot(dragOffsetX.value.toDouble(), dragOffsetY.value.toDouble()).toFloat()
        alpha = (1f - (distance / (dismissThresholdPx * 2.2f))).coerceIn(0.25f, 1f)
      }
      .pointerInput(isExpanded) {
        detectDragGestures(
          onDrag = { change, dragAmount ->
            change.consume()
            scope.launch {
              dragOffsetX.snapTo(dragOffsetX.value + dragAmount.x)
              dragOffsetY.snapTo((dragOffsetY.value + dragAmount.y).coerceAtMost(25f))
            }
          },
          onDragEnd = {
            val x = dragOffsetX.value
            val y = dragOffsetY.value
            val swipedRight = x > dismissThresholdPx
            val swipedLeft = x < -dismissThresholdPx
            val swipedUp = y < -dismissThresholdPx

            if (swipedRight || swipedLeft || swipedUp) {
              scope.launch {
                val targetX = if (swipedRight) x + 600f else if (swipedLeft) x - 600f else x
                val targetY = if (swipedUp) y - 500f else y
                launch { dragOffsetX.animateTo(targetX, spring(stiffness = Spring.StiffnessMedium)) }
                launch { dragOffsetY.animateTo(targetY, spring(stiffness = Spring.StiffnessMedium)) }
                delay(90)
                onDismissToNotification()
                dragOffsetX.snapTo(0f)
                dragOffsetY.snapTo(0f)
              }
            } else {
              scope.launch {
                launch { dragOffsetX.animateTo(0f, spring(dampingRatio = Spring.DampingRatioLowBouncy)) }
                launch { dragOffsetY.animateTo(0f, spring(dampingRatio = Spring.DampingRatioLowBouncy)) }
              }
            }
          },
          onDragCancel = {
            scope.launch {
              launch { dragOffsetX.animateTo(0f) }
              launch { dragOffsetY.animateTo(0f) }
            }
          }
        )
      }
      .width(animatedWidth)
      .height(animatedHeight)
      .shadow(
        elevation = if (isExpanded) 24.dp else 16.dp,
        shape = RoundedCornerShape(animatedCornerRadius),
        spotColor = accentColor.copy(alpha = if (isExpanded) 0.5f else 0.4f)
      )
      .clip(RoundedCornerShape(animatedCornerRadius))
      .background(Color(0xFF07080A))
      .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
          listOf(
            Color.White.copy(alpha = if (isExpanded) 0.22f else 0.16f),
            Color(0xFF1B2230),
            accentColor.copy(alpha = 0.35f)
          )
        ),
        shape = RoundedCornerShape(animatedCornerRadius)
      )
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = {
          if (!isExpanded && dragOffsetX.value == 0f && dragOffsetY.value == 0f) {
            onModeChange(CapsuleMode.EXPANDED)
          }
        }
      ),
    color = Color(0xFF07080A),
    shape = RoundedCornerShape(animatedCornerRadius)
  ) {
    AnimatedContent(
      targetState = isExpanded,
      transitionSpec = {
        (fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
          scaleIn(initialScale = 0.94f, animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy)))
          .togetherWith(
            fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
              scaleOut(targetScale = 0.94f, animationSpec = spring())
          )
      },
      label = "capsule_morphing_content"
    ) { expanded ->
      if (expanded) {
        ExpandedDynamicContent(
          trackInfo = trackInfo,
          settings = settings,
          accentColor = accentColor,
          activeCard = activeCard,
          batteryState = batteryState,
          callState = callState,
          timerState = timerState,
          notifEvent = notifEvent,
          bluetooth = bluetooth,
          flashlight = flashlight,
          ringer = ringer,
          currentSoundMode = currentSoundMode,
          downloadState = downloadState,
          onCollapse = { onModeChange(CapsuleMode.MINI) },
          onPlayPauseClick = onPlayPauseClick,
          onNextClick = onNextClick,
          onPrevClick = onPrevClick,
          onSeek = onSeek
        )
      } else {
        MediumDynamicContent(
          trackInfo = trackInfo,
          settings = settings,
          accentColor = accentColor,
          activeCard = activeCard,
          batteryState = batteryState,
          callState = callState,
          timerState = timerState,
          notifEvent = notifEvent,
          bluetooth = bluetooth,
          flashlight = flashlight,
          ringer = ringer,
          downloadState = downloadState
        )
      }
    }
  }
}

/**
 * Collapsed / Mini Dynamic Island Content
 */
@Composable
fun MediumDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  ringer: RingerState,
  downloadState: DownloadState
) {
  val context = LocalContext.current
  val isPlaying = trackInfo?.isPlaying == true

  // Real-time position ticker so the elapsed time ("الوقت الذي ذهب") updates smoothly
  var livePos by remember(trackInfo?.lastUpdateTime, trackInfo?.currentPositionMs) {
    mutableLongStateOf(trackInfo?.getEstimatedPositionMs() ?: 0L)
  }
  LaunchedEffect(trackInfo, isPlaying) {
    while (isActive && isPlaying) {
      delay(500)
      livePos = trackInfo?.getEstimatedPositionMs() ?: 0L
    }
  }

  Row(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    when {
      // 1. Ringer / Sound Mode Alert (Ring, Vibrate, Silent, Muted DND)
      ringer.isActive && settings.enableRingerAlerts && (System.currentTimeMillis() - ringer.timestamp < 3500L) -> {
        val modeColor = when (ringer.mode) {
          SoundMode.RING -> RealmeGreen
          SoundMode.VIBRATE -> Color(0xFFFFB74D)
          SoundMode.SILENT -> Color(0xFFFF9500)
          SoundMode.MUTED_DND -> Color(0xFFFF453A)
        }
        val modeIcon = when (ringer.mode) {
          SoundMode.RING -> Icons.Default.NotificationsActive
          SoundMode.VIBRATE -> Icons.Default.Vibration
          SoundMode.SILENT -> Icons.Default.NotificationsOff
          SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
        }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(modeColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = modeIcon,
              contentDescription = ringer.mode.labelAr,
              tint = modeColor,
              modifier = Modifier.size(16.dp)
            )
          }
          Text(
            text = ringer.mode.labelAr,
            color = modeColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(modeColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text(
            text = ringer.mode.badgeAr,
            color = Color.Black,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }

      // 3. Flashlight ON: Yellow icon + label + direct turn off button
      flashlight.isOn && settings.enableFlashlightAlert -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFD600)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.FlashlightOn,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(17.dp)
            )
          }
          Text(
            text = "المصباح مفعّل",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFF332A00))
            .clickable { IslandStateManager.turnOffFlashlight(context) }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("إطفاء", color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
      }

      // 4. Call Ongoing / Incoming (Screenshot 4)
      callState.isActive && settings.enableCallAlerts -> {
        if (callState.isIncoming) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f, fill = false)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            Column {
              Text("مكالمة واردة", color = Color(0xFFFF9500), fontSize = 9.sp, fontWeight = FontWeight.Bold)
              MarqueeFadingText(
                text = callState.callerName,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(15.dp))
            }
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFF34C759))
                .clickable { IslandStateManager.answerCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(15.dp))
            }
          }
        } else {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            MarqueeFadingText(
              text = callState.callerName,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(13.dp))
            }
          }
        }
      }

      // 5. Battery Event (Charging, Low Battery Alert, or Full Charge Alert)
      (batteryState.isCharging || batteryState.isLowAlert || batteryState.isFullAlert) &&
        settings.enableBatteryAlerts &&
        (System.currentTimeMillis() - batteryState.lastEventTime < 7000L) -> {
        val batteryColor = when {
          batteryState.isLowAlert -> Color(0xFFFF453A)
          batteryState.isFullAlert -> RealmeGreen
          else -> RealmeGreen
        }
        val batteryLabel = when {
          batteryState.isLowAlert -> "بطارية منخفضة"
          batteryState.isFullAlert -> "اكتمل الشحن"
          else -> "جارٍ الشحن"
        }
        Text(batteryLabel, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("${batteryState.percentage}%", color = batteryColor, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
          Icon(
            imageVector = if (batteryState.isLowAlert) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
            contentDescription = batteryLabel,
            tint = batteryColor,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // 6. App Notification Banner
      notifEvent != null && settings.enableNotifications -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Notifications, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
          MarqueeFadingText(
            text = "${notifEvent.appName}: ${notifEvent.title}",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      // 7. Timer / Stopwatch Active (Syncs automatically with Clock app or internal timer)
      timerState.isActive && settings.enableTimer -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFB74D).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (timerState.isStopwatch) Icons.Default.Timer else Icons.Default.HourglassTop,
              contentDescription = null,
              tint = Color(0xFFFFB74D),
              modifier = Modifier.size(16.dp)
            )
          }
          MarqueeFadingText(
            text = if (timerState.isRunning) timerState.title else "${timerState.title} (متوقف)",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = timerState.formatRemaining(),
          color = if (timerState.isRunning) Color(0xFFFFB74D) else TextMuted,
          fontSize = 13.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 8. Real Download / Install Progress
      downloadState.isActive && settings.enableDownloadProgress && (System.currentTimeMillis() - downloadState.timestamp < 30000L) -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFF00E5FF).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
          }
          MarqueeFadingText(
            text = downloadState.title,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (downloadState.isIndeterminate) "..." else "${downloadState.percent}%",
          color = Color(0xFF00E5FF),
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 9. Bluetooth / Wired Headset Connected
      bluetooth.isConnected && settings.enableBluetoothAlerts && (System.currentTimeMillis() - bluetooth.timestamp < 6000L) -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Headphones, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
          MarqueeFadingText(
            text = bluetooth.deviceName,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (bluetooth.batteryPct in 0..100) "${bluetooth.batteryPct}%" else "متصل",
          color = accentColor,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 9. Music Playing (Real-time elapsed time counter + Marquee + Waveform)
      trackInfo != null && isPlaying -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (trackInfo.albumArt != null) {
            Image(
              bitmap = trackInfo.albumArt.asImageBitmap(),
              contentDescription = "Album Thumbnail",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(0.8.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
            )
          } else {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(accentColor.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Column(modifier = Modifier.weight(1f)) {
            MarqueeFadingText(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            MarqueeFadingText(
              text = trackInfo.artist,
              color = TextSecondary,
              fontSize = 10.sp,
              fontWeight = FontWeight.Normal
            )
          }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Real-time Elapsed Time ("الوقت الذي ذهب") + Mini Waveform
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Text(
            text = trackInfo.formatTime(livePos),
            color = accentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
          MiniWaveformVisualizer(
            isPlaying = true,
            color = accentColor,
            barCount = 4,
            width = 16.dp,
            height = 13.dp
          )
        }
      }

      // Idle state
      else -> {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(Color(0xFF1E2532))
          )
        }
      }
    }
  }
}

/**
 * Expanded Dynamic Island Content
 */
@Composable
fun ExpandedDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  ringer: RingerState,
  currentSoundMode: SoundMode,
  downloadState: DownloadState,
  onCollapse: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val context = LocalContext.current
  var currentSelectedTab by remember { mutableStateOf(activeCard) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(14.dp)
  ) {
    // Header Bar: Activity Tabs + Immediate Collapse Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        TabIndicator(
          icon = Icons.Default.GraphicEq,
          isSelected = currentSelectedTab == IslandActiveCard.MUSIC,
          color = accentColor,
          onClick = { currentSelectedTab = IslandActiveCard.MUSIC }
        )

        TabIndicator(
          icon = when (currentSoundMode) {
            SoundMode.RING -> Icons.Default.VolumeUp
            SoundMode.VIBRATE -> Icons.Default.Vibration
            SoundMode.SILENT -> Icons.Default.NotificationsOff
            SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
          },
          isSelected = currentSelectedTab == IslandActiveCard.RINGER,
          color = Color(0xFFFF9500),
          onClick = { currentSelectedTab = IslandActiveCard.RINGER }
        )

        if (flashlight.isOn) {
          TabIndicator(
            icon = Icons.Default.FlashlightOn,
            isSelected = currentSelectedTab == IslandActiveCard.FLASHLIGHT,
            color = Color(0xFFFFD600),
            onClick = { currentSelectedTab = IslandActiveCard.FLASHLIGHT }
          )
        }

        if (timerState.isActive) {
          TabIndicator(
            icon = if (timerState.isStopwatch) Icons.Default.Timer else Icons.Default.HourglassTop,
            isSelected = currentSelectedTab == IslandActiveCard.TIMER,
            color = Color(0xFFFFB74D),
            onClick = { currentSelectedTab = IslandActiveCard.TIMER }
          )
        }

        if (downloadState.isActive) {
          TabIndicator(
            icon = Icons.Default.Download,
            isSelected = currentSelectedTab == IslandActiveCard.DOWNLOAD,
            color = Color(0xFF00E5FF),
            onClick = { currentSelectedTab = IslandActiveCard.DOWNLOAD }
          )
        }

        if (callState.isActive) {
          TabIndicator(
            icon = Icons.Default.Call,
            isSelected = currentSelectedTab == IslandActiveCard.CALL,
            color = RealmeGreen,
            onClick = { currentSelectedTab = IslandActiveCard.CALL }
          )
        }
      }

      // Collapse Button
      IconButton(
        onClick = onCollapse,
        modifier = Modifier
          .testTag("collapse_capsule_button")
          .size(30.dp)
          .background(Color.White.copy(alpha = 0.12f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Rounded.KeyboardArrowUp,
          contentDescription = "Collapse Capsule",
          tint = TextPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Active Card View
    when (currentSelectedTab) {
      IslandActiveCard.RINGER -> {
        ExpandedRingerView(
          currentMode = currentSoundMode,
          onSelectMode = { mode -> IslandStateManager.setSoundMode(context, mode) }
        )
      }
      IslandActiveCard.FLASHLIGHT -> {
        ExpandedFlashlightView(
          flashlight = flashlight,
          onToggle = { IslandStateManager.toggleFlashlight(context) },
          onTurnOff = {
            IslandStateManager.turnOffFlashlight(context)
            if (trackInfo?.isPlaying == true) currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.TIMER -> {
        ExpandedTimerView(
          timerState = timerState,
          onTogglePause = { IslandStateManager.toggleTimerPause() },
          onCancel = { IslandStateManager.cancelTimer(); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      IslandActiveCard.DOWNLOAD -> {
        ExpandedDownloadView(
          downloadState = downloadState,
          onDismiss = {
            IslandStateManager.clearDownloadProgress()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.BATTERY -> {
        ExpandedBatteryView(batteryState = batteryState)
      }
      IslandActiveCard.CALL -> {
        ExpandedCallView(
          callState = callState,
          onAnswer = { IslandStateManager.answerCall(context) },
          onDecline = { IslandStateManager.declineCall(context); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      else -> {
        ExpandedMusicView(
          trackInfo = trackInfo,
          accentColor = accentColor,
          onPlayPauseClick = onPlayPauseClick,
          onNextClick = onNextClick,
          onPrevClick = onPrevClick,
          onSeek = onSeek
        )
      }
    }
  }
}

@Composable
private fun TabIndicator(
  icon: ImageVector,
  isSelected: Boolean,
  color: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(26.dp)
      .clip(CircleShape)
      .background(if (isSelected) color.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f))
      .border(1.dp, if (isSelected) color else Color.Transparent, CircleShape)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isSelected) color else TextSecondary,
      modifier = Modifier.size(14.dp)
    )
  }
}

/**
 * Music Expanded Player (Screenshot 1 & Screenshot 7)
 */
@Composable
fun ExpandedMusicView(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val isPlaying = trackInfo?.isPlaying == true

  // Real-time position ticker so the elapsed time and slider thumb smoothly advance
  var livePositionMs by remember(trackInfo?.lastUpdateTime, trackInfo?.currentPositionMs) {
    mutableLongStateOf(trackInfo?.getEstimatedPositionMs() ?: 0L)
  }

  LaunchedEffect(trackInfo, isPlaying) {
    while (isActive && isPlaying) {
      delay(400)
      livePositionMs = trackInfo?.getEstimatedPositionMs() ?: 0L
    }
  }

  val rawDuration = trackInfo?.durationMs ?: 0L
  val hasValidDuration = rawDuration > 0L
  val duration = if (hasValidDuration) rawDuration else 180000L

  var isUserDragging by remember { mutableStateOf(false) }
  var dragPositionFraction by remember { mutableFloatStateOf(0f) }
  var isFavorite by remember { mutableStateOf(false) }
  var repeatMode by remember { mutableIntStateOf(0) }

  val effectiveFraction = if (isUserDragging) {
    dragPositionFraction
  } else if (hasValidDuration) {
    (livePositionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
  } else {
    // If stream duration is unknown, smoothly cycle every minute instead of pinning to 1.0f
    ((livePositionMs % 60000L).toFloat() / 60000f)
  }

  Column(modifier = Modifier.fillMaxWidth()) {
    // Top Row: Album Cover + Track Title (Marquee) + Artist + Cast Icon
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (trackInfo?.albumArt != null) {
        Image(
          bitmap = trackInfo.albumArt.asImageBitmap(),
          contentDescription = "Album Art",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            .shadow(10.dp, RoundedCornerShape(14.dp), spotColor = accentColor.copy(alpha = 0.5f))
        )
      } else {
        Box(
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
              Brush.linearGradient(
                listOf(Color(0xFF263248), Color(0xFF131926))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(28.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        MarqueeFadingText(
          text = trackInfo?.title ?: "Far closer",
          color = TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        MarqueeFadingText(
          text = trackInfo?.artist ?: "David",
          color = TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Normal
        )
      }

      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Cast,
          contentDescription = "AirPlay / Cast",
          tint = TextSecondary,
          modifier = Modifier.size(16.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    val canSeek = trackInfo?.canSeek ?: true
    val canSkipNext = trackInfo?.canSkipNext ?: true
    val canSkipPrev = trackInfo?.canSkipPrevious ?: true

    // Controls Row: Repeat, Previous, Play/Pause, Next, Favorite
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = { repeatMode = (repeatMode + 1) % 3 },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = if (repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
          contentDescription = "Repeat",
          tint = if (repeatMode > 0) accentColor else TextMuted,
          modifier = Modifier.size(19.dp)
        )
      }

      IconButton(
        onClick = onPrevClick,
        enabled = canSkipPrev,
        modifier = Modifier
          .testTag("prev_track_button")
          .size(40.dp)
          .background(Color.White.copy(alpha = if (canSkipPrev) 0.06f else 0.02f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipPrevious,
          contentDescription = "Previous Track",
          tint = if (canSkipPrev) TextPrimary else TextMuted.copy(alpha = 0.4f),
          modifier = Modifier.size(22.dp)
        )
      }

      IconButton(
        onClick = onPlayPauseClick,
        modifier = Modifier
          .testTag("play_pause_button")
          .size(52.dp)
          .shadow(12.dp, CircleShape, spotColor = accentColor)
          .background(accentColor, CircleShape)
      ) {
        Icon(
          imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
          contentDescription = if (isPlaying) "Pause" else "Play",
          tint = Color.Black,
          modifier = Modifier.size(30.dp)
        )
      }

      IconButton(
        onClick = onNextClick,
        enabled = canSkipNext,
        modifier = Modifier
          .testTag("next_track_button")
          .size(40.dp)
          .background(Color.White.copy(alpha = if (canSkipNext) 0.06f else 0.02f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipNext,
          contentDescription = "Next Track",
          tint = if (canSkipNext) TextPrimary else TextMuted.copy(alpha = 0.4f),
          modifier = Modifier.size(22.dp)
        )
      }

      IconButton(
        onClick = { isFavorite = !isFavorite },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
          contentDescription = "Favorite",
          tint = if (isFavorite) Color(0xFFFF5252) else TextMuted,
          modifier = Modifier.size(19.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Interactive Draggable Seek Slider (Disabled when seeking not supported, e.g. Spotify Free)
    Slider(
      value = effectiveFraction,
      enabled = canSeek,
      onValueChange = { fraction ->
        if (canSeek) {
          isUserDragging = true
          dragPositionFraction = fraction
        }
      },
      onValueChangeFinished = {
        if (canSeek) {
          val seekTargetMs = (dragPositionFraction * duration).toLong()
          onSeek(seekTargetMs)
        }
        isUserDragging = false
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(18.dp)
        .testTag("track_progress_slider"),
      colors = SliderDefaults.colors(
        thumbColor = if (canSeek) Color.White else Color.Transparent,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color.White.copy(alpha = 0.18f),
        disabledThumbColor = Color.Transparent,
        disabledActiveTrackColor = Color.White.copy(alpha = 0.75f),
        disabledInactiveTrackColor = Color.White.copy(alpha = 0.15f)
      )
    )

    // Timestamp Row: Elapsed time ("الوقت الذي ذهب") + Total Duration
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 2.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      val displayPos = if (isUserDragging) (dragPositionFraction * duration).toLong() else livePositionMs
      Text(
        text = trackInfo?.formatTime(displayPos) ?: "00:00",
        color = TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium
      )
      Text(
        text = if (hasValidDuration) (trackInfo?.formatTime(duration) ?: "00:00") else "--:--",
        color = TextMuted,
        fontSize = 11.sp
      )
    }

    if (!canSeek && trackInfo?.packageName?.contains("spotify", ignoreCase = true) == true) {
      Text(
        text = "التقديم غير متاح في خطة Spotify المجانية",
        color = Color(0xFF1DB954).copy(alpha = 0.75f),
        fontSize = 9.sp,
        fontWeight = FontWeight.Normal,
        textAlign = TextAlign.Center,
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 2.dp)
      )
    }
  }
}

/**
 * Sound Mode Expanded Card (Ring, Vibrate, Silent, Muted/DND)
 */
@Composable
fun ExpandedRingerView(
  currentMode: SoundMode,
  onSelectMode: (SoundMode) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Text(
      text = "وضع الصوت الحالي: ${currentMode.labelAr}",
      color = TextPrimary,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val modes = listOf(
        Triple(SoundMode.RING, Icons.Default.NotificationsActive, RealmeGreen),
        Triple(SoundMode.VIBRATE, Icons.Default.Vibration, Color(0xFFFFB74D)),
        Triple(SoundMode.SILENT, Icons.Default.NotificationsOff, Color(0xFFFF9500)),
        Triple(SoundMode.MUTED_DND, Icons.Default.DoNotDisturbOn, Color(0xFFFF453A))
      )
      modes.forEach { (mode, icon, color) ->
        val selected = currentMode == mode
        Column(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) color.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f))
            .border(
              width = 1.dp,
              color = if (selected) color else Color.Transparent,
              shape = RoundedCornerShape(14.dp)
            )
            .clickable { onSelectMode(mode) }
            .padding(vertical = 10.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = icon,
            contentDescription = mode.badgeAr,
            tint = if (selected) color else TextSecondary,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = mode.badgeAr,
            color = if (selected) color else TextPrimary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
          )
        }
      }
    }
  }
}

/**
 * Real Download / Install Progress Expanded Card
 */
@Composable
fun ExpandedDownloadView(
  downloadState: DownloadState,
  onDismiss: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0xFF00E5FF).copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(22.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(downloadState.appName, color = TextSecondary, fontSize = 11.sp)
          MarqueeFadingText(
            text = downloadState.title,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
      Text(
        text = if (downloadState.isIndeterminate) "..." else "${downloadState.percent}%",
        color = Color(0xFF00E5FF),
        fontSize = 16.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    if (downloadState.isIndeterminate) {
      LinearProgressIndicator(
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = Color(0xFF00E5FF),
        trackColor = Color.White.copy(alpha = 0.15f)
      )
    } else {
      LinearProgressIndicator(
        progress = { (downloadState.progress.toFloat() / downloadState.max.coerceAtLeast(1)).coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = Color(0xFF00E5FF),
        trackColor = Color.White.copy(alpha = 0.15f)
      )
    }
  }
}

/**
 * Timer & Stopwatch Expanded View with Circular Progress Ring
 */
@Composable
fun ExpandedTimerView(
  timerState: TimerState,
  onTogglePause: () -> Unit,
  onCancel: () -> Unit
) {
  val remaining = timerState.remainingSeconds
  val total = if (timerState.totalSeconds > 0) timerState.totalSeconds else remaining.coerceAtLeast(1)
  val progress = if (timerState.isStopwatch) {
    ((timerState.elapsedSeconds % 60) / 60f).coerceIn(0f, 1f)
  } else {
    (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceAround
  ) {
    // Left: Circular Progress Ring with Countdown / Elapsed Time
    Box(
      modifier = Modifier.size(92.dp),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 5.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
        val arcSize = Size(diameter, diameter)

        drawArc(
          color = Color(0xFF2C2F38),
          startAngle = -90f,
          sweepAngle = 360f,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth)
        )

        drawArc(
          color = Color(0xFFFF9F0A),
          startAngle = -90f,
          sweepAngle = 360f * progress,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = timerState.formatRemaining(),
          color = Color.White,
          fontSize = 15.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (timerState.isStopwatch) "إيقاف" else "المؤقت",
          color = Color(0xFFFF9F0A),
          fontSize = 9.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }

    // Right: Action Buttons
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        shape = CircleShape,
        color = Color(0xFFFF9F0A),
        modifier = Modifier
          .clickable(onClick = onTogglePause)
          .padding(horizontal = 20.dp, vertical = 8.dp)
      ) {
        Text(
          text = if (timerState.isRunning) "إيقاف مؤقت" else "استئناف",
          color = Color.Black,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Surface(
        shape = CircleShape,
        color = Color(0xFF2C2F38),
        modifier = Modifier
          .clickable(onClick = onCancel)
          .padding(horizontal = 24.dp, vertical = 8.dp)
      ) {
        Text("إلغاء", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/**
 * Flashlight Expanded Card
 */
@Composable
fun ExpandedFlashlightView(
  flashlight: FlashlightState,
  onToggle: () -> Unit,
  onTurnOff: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF262D3D)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (flashlight.isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
          contentDescription = null,
          tint = if (flashlight.isOn) Color.Black else Color.White,
          modifier = Modifier.size(26.dp)
        )
      }

      Column {
        Text(
          text = if (flashlight.isOn) "المصباح مفعّل" else "المصباح متوقف",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (flashlight.isOn) "Flashlight is ON" else "Flashlight is OFF",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    Button(
      onClick = onToggle,
      colors = ButtonDefaults.buttonColors(
        containerColor = if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF2E384D),
        contentColor = if (flashlight.isOn) Color.Black else Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text(
        text = if (flashlight.isOn) "إطفاء" else "تشغيل",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }
  }
}

/**
 * Phone Call Expanded Card (Screenshot 4)
 */
@Composable
fun ExpandedCallView(
  callState: CallState,
  onAnswer: () -> Unit,
  onDecline: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Box(
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(Color(0xFF384358)),
      contentAlignment = Alignment.Center
    ) {
      Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = if (callState.isIncoming) "مكالمة واردة" else callState.callerNumber,
        color = TextSecondary,
        fontSize = 11.sp
      )
      MarqueeFadingText(
        text = callState.callerName,
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
      if (!callState.isIncoming) {
        Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      } else {
        Text("يرن...", color = Color(0xFFFF9500), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Color(0xFFFF3B30))
          .clickable(onClick = onDecline),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(18.dp))
      }

      if (callState.isIncoming) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF34C759))
            .clickable(onClick = onAnswer),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

/**
 * Battery Charging Expanded Card (Screenshot 3)
 */
@Composable
fun ExpandedBatteryView(batteryState: BatteryState) {
  val color = if (batteryState.isLowAlert) Color(0xFFFF453A) else RealmeGreen
  val titleText = when {
    batteryState.isLowAlert -> "بطارية منخفضة"
    batteryState.isFullAlert -> "اكتمل الشحن"
    else -> "جارٍ الشحن"
  }
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (batteryState.isLowAlert) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
          contentDescription = null,
          tint = color,
          modifier = Modifier.size(24.dp)
        )
      }

      Column {
        Text(titleText, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(
          text = batteryState.pluggedType.ifBlank { if (batteryState.isLowAlert) "يرجى توصيل الشاحن" else "طاقة مستقرة" },
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    Text(
      text = "${batteryState.percentage}%",
      color = color,
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}


/**
 * Mini Waveform Bars
 */
@Composable
fun MiniWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  barCount: Int = 4,
  width: Dp = 18.dp,
  height: Dp = 14.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "mini_wave")

  val animValues = List(barCount) { index ->
    val duration = 400 + (index * 130)
    infiniteTransition.animateFloat(
      initialValue = 0.25f,
      targetValue = 1.0f,
      animationSpec = infiniteRepeatable(
        animation = tween(durationMillis = duration),
        repeatMode = RepeatMode.Reverse
      ),
      label = "bar_$index"
    )
  }

  Canvas(modifier = Modifier.size(width, height)) {
    val barWidth = size.width / (barCount * 1.8f)
    val gap = barWidth * 0.8f

    for (i in 0 until barCount) {
      val hFraction = if (isPlaying) animValues[i].value else 0.25f
      val barHeight = size.height * hFraction
      val x = i * (barWidth + gap)
      val y = (size.height - barHeight) / 2f

      drawRoundRect(
        color = color,
        topLeft = Offset(x, y),
        size = Size(barWidth, barHeight),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2)
      )
    }
  }
}
