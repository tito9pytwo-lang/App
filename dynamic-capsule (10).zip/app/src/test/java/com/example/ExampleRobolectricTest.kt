package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.SoundMode
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence with negative and positive offset`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(-150)
    assertEquals(-150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(150)
    assertEquals(150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(-35)
    assertEquals(-35, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(0)
    assertEquals(0, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateShowWhenIdle(false)
    assertFalse(settingsManager.settings.value.showWhenIdle)

    settingsManager.updateAccentColorIndex(2)
    assertEquals(2, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test call state immediate termination on CALL_STATE_IDLE and decline`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // Start incoming call
    IslandStateManager.startCall("Sarah Connor", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.callState.value.isIncoming)

    // Simulate TelephonyManager reporting CALL_STATE_IDLE (call declined or ended)
    IslandStateManager.handleTelephonyState(android.telephony.TelephonyManager.CALL_STATE_IDLE)
    assertFalse("Call state must terminate immediately when phone is idle", IslandStateManager.callState.value.isActive)

    // Start another call and decline it
    IslandStateManager.startCall("John Smith", "987654321", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    IslandStateManager.declineCall(context)
    assertFalse("Call state must terminate immediately when declined", IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test estimated position bounds and stability`() {
    val now = android.os.SystemClock.elapsedRealtime()
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Artist",
      durationMs = 200000L,
      currentPositionMs = 50000L,
      isPlaying = true,
      lastUpdateTime = now
    )

    // Position at now should be close to base
    val estimated = track.getEstimatedPositionMs()
    assertTrue(estimated in 50000L..50050L)

    // When paused, estimated position should equal currentPositionMs exactly
    val pausedTrack = track.copy(isPlaying = false)
    assertEquals(50000L, pausedTrack.getEstimatedPositionMs())
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Far closer",
      artist = "David",
      durationMs = 236000L,
      currentPositionMs = 174000L,
      isPlaying = false
    )

    assertEquals("03:56", track.formatTime(track.durationMs))
    assertEquals("02:54", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }

  @Test
  fun `test island state manager and activity detection`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // When idle and no music
    assertFalse(IslandStateManager.hasAnyActiveActivity(null))

    // When torch is turned on
    IslandStateManager.turnOnFlashlight(context)
    assertTrue(IslandStateManager.flashlightState.value.isOn)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Turn torch off
    IslandStateManager.turnOffFlashlight(context)
    assertFalse(IslandStateManager.flashlightState.value.isOn)

    // When timer is started
    IslandStateManager.startTimer(60, "Tea Timer")
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.cancelTimer()

    // When call is active
    IslandStateManager.startCall("John Doe", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.endCall()
    assertFalse(IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test external clock timer sync and paused state activity`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    val futureEnd = System.currentTimeMillis() + 120_000L
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 120,
      targetEndTimeMs = futureEnd,
      isRunning = true,
      isStopwatch = false
    )

    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)
    assertEquals(IslandActiveCard.TIMER, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Simulate OEM second-by-second update: totalSeconds must remain preserved at 120
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 95,
      targetEndTimeMs = System.currentTimeMillis() + 95_000L,
      isRunning = true,
      isStopwatch = false
    )
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)

    // Pausing timer must keep isActive true so capsule stays visible
    IslandStateManager.toggleTimerPause()
    assertFalse(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Removing notification clears the external timer cleanly
    IslandStateManager.cancelExternalTimer("0|com.google.android.deskclock|1|null|1001")
    assertFalse(IslandStateManager.timerState.value.isActive)
  }

  @Test
  fun `test 4-state sound mode transitions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.showRingerMode(SoundMode.VIBRATE)
    assertEquals(SoundMode.VIBRATE, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isActive)
    assertTrue(IslandStateManager.ringerState.value.isSilent)
    assertEquals(IslandActiveCard.RINGER, IslandStateManager.activeCard.value)

    IslandStateManager.showRingerMode(SoundMode.SILENT)
    assertEquals(SoundMode.SILENT, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.MUTED_DND)
    assertEquals(SoundMode.MUTED_DND, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.RING)
    assertEquals(SoundMode.RING, IslandStateManager.currentSoundMode.value)
    assertFalse(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.dismissRinger()
    assertFalse(IslandStateManager.ringerState.value.isActive)
  }

  @Test
  fun `test download progress tracking and completion cleanup`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.updateDownloadProgress(
      key = "0|com.android.vending|42|null|1002",
      appName = "Google Play",
      title = "Downloading update",
      progress = 45,
      max = 100,
      indeterminate = false
    )

    assertTrue(IslandStateManager.downloadState.value.isActive)
    assertEquals(45, IslandStateManager.downloadState.value.percent)
    assertEquals(IslandActiveCard.DOWNLOAD, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.clearDownloadProgress("0|com.android.vending|42|null|1002")
    assertFalse(IslandStateManager.downloadState.value.isActive)
  }
}
