package com.example.island

import android.graphics.Bitmap
import java.util.Locale

data class BatteryState(
  val isCharging: Boolean = false,
  val percentage: Int = 85,
  val isLow: Boolean = false,
  val pluggedType: String = "",
  val isLowAlert: Boolean = false,
  val isFullAlert: Boolean = false,
  val lastEventTime: Long = 0L
)

data class CallState(
  val isActive: Boolean = false,
  val callerName: String = "Incoming Call",
  val callerNumber: String = "Mobile",
  val durationSeconds: Int = 0,
  val isIncoming: Boolean = true
) {
  fun formatDuration(): String {
    val mins = durationSeconds / 60
    val secs = durationSeconds % 60
    return String.format(Locale.US, "%02d:%02d", mins, secs)
  }
}

data class TimerState(
  val isActive: Boolean = false,
  val isRunning: Boolean = false,
  val remainingSeconds: Int = 0,
  val totalSeconds: Int = 0,
  val title: String = "المؤقت",
  val isStopwatch: Boolean = false,
  val elapsedSeconds: Int = 0,
  val targetEndTimeMs: Long = 0L,
  val sourcePackage: String = "",
  val notificationKey: String = ""
) {
  fun formatRemaining(): String {
    val secValue = if (isStopwatch) elapsedSeconds else remainingSeconds
    return formatSeconds(secValue)
  }

  private fun formatSeconds(totalSec: Int): String {
    val safe = totalSec.coerceAtLeast(0)
    val hrs = safe / 3600
    val mins = (safe % 3600) / 60
    val secs = safe % 60
    return if (hrs > 0) {
      String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
    } else {
      String.format(Locale.US, "%02d:%02d", mins, secs)
    }
  }
}

data class NotificationEvent(
  val id: Long = System.currentTimeMillis(),
  val packageName: String = "",
  val appName: String = "",
  val title: String = "",
  val text: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

data class BluetoothState(
  val isConnected: Boolean = false,
  val deviceName: String = "Bluetooth Audio",
  val batteryPct: Int = -1,
  val timestamp: Long = 0L
)

data class FlashlightState(
  val isOn: Boolean = false
)

enum class SoundMode(val labelAr: String, val badgeAr: String) {
  RING("وضع الرنين", "رنين"),
  VIBRATE("وضع الاهتزاز", "اهتزاز"),
  SILENT("الوضع الصامت", "صامت"),
  MUTED_DND("مكتوم • عدم الإزعاج", "مكتوم")
}

data class RingerState(
  val isActive: Boolean = false,
  val mode: SoundMode = SoundMode.RING,
  val timestamp: Long = 0L
) {
  val isSilent: Boolean get() = mode != SoundMode.RING
}

data class DownloadState(
  val isActive: Boolean = false,
  val key: String = "",
  val appName: String = "",
  val title: String = "",
  val progress: Int = 0,
  val max: Int = 100,
  val isIndeterminate: Boolean = false,
  val timestamp: Long = 0L
) {
  val percent: Int
    get() = if (max > 0) ((progress * 100f) / max).toInt().coerceIn(0, 100) else 0
}

data class NavigationState(
  val isActive: Boolean = false,
  val key: String = "",
  val packageName: String = "",
  val appName: String = "",
  val instruction: String = "",
  val distanceOrStreet: String = "",
  val etaText: String = "",
  val directionIcon: Bitmap? = null,
  val timestamp: Long = 0L
)

data class PrivacyState(
  val isCameraInUse: Boolean = false,
  val isMicInUse: Boolean = false,
  val isVoiceRecorderActive: Boolean = false,
  val recorderKey: String = "",
  val recorderPackage: String = "",
  val recorderAppName: String = "",
  val recorderTitle: String = "",
  val elapsedSeconds: Int = 0,
  val isRecorderRunning: Boolean = false,
  val timestamp: Long = 0L
) {
  val hasAnyActivity: Boolean
    get() = isCameraInUse || isMicInUse || isVoiceRecorderActive

  fun formatElapsed(): String {
    val safe = elapsedSeconds.coerceAtLeast(0)
    val hrs = safe / 3600
    val mins = (safe % 3600) / 60
    val secs = safe % 60
    return if (hrs > 0) {
      String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
    } else {
      String.format(Locale.US, "%02d:%02d", mins, secs)
    }
  }
}

enum class NetworkEventType {
  WIFI_CONNECTED,
  MOBILE_DATA,
  NO_INTERNET,
  AIRPLANE_ON,
  AIRPLANE_OFF,
  HOTSPOT_ON,
  HOTSPOT_OFF
}

data class NetworkState(
  val isActive: Boolean = false,
  val type: NetworkEventType = NetworkEventType.WIFI_CONNECTED,
  val title: String = "",
  val subtitle: String = "",
  val timestamp: Long = 0L
)

enum class IslandActiveCard {
  MUSIC,
  BATTERY,
  CALL,
  TIMER,
  NAVIGATION,
  PRIVACY,
  NETWORK,
  NOTIFICATION,
  BLUETOOTH,
  FLASHLIGHT,
  RINGER,
  DOWNLOAD,
  QUICK_CONTROLS,
  CLOCK
}
