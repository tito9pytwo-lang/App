package com.example.island

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.media.MediaTrackInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object IslandStateManager {

  private const val TAG = "IslandStateManager"
  private val scope = CoroutineScope(Dispatchers.Main + Job())

  // States
  private val _batteryState = MutableStateFlow(BatteryState())
  val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

  private val _callState = MutableStateFlow(CallState())
  val callState: StateFlow<CallState> = _callState.asStateFlow()

  private val _timerState = MutableStateFlow(TimerState())
  val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

  private val _activeNotification = MutableStateFlow<NotificationEvent?>(null)
  val activeNotification: StateFlow<NotificationEvent?> = _activeNotification.asStateFlow()

  private val _bluetoothState = MutableStateFlow(BluetoothState())
  val bluetoothState: StateFlow<BluetoothState> = _bluetoothState.asStateFlow()

  private val _flashlightState = MutableStateFlow(FlashlightState())
  val flashlightState: StateFlow<FlashlightState> = _flashlightState.asStateFlow()

  private val _ringerState = MutableStateFlow(RingerState())
  val ringerState: StateFlow<RingerState> = _ringerState.asStateFlow()

  private val _currentSoundMode = MutableStateFlow(SoundMode.RING)
  val currentSoundMode: StateFlow<SoundMode> = _currentSoundMode.asStateFlow()

  private val _downloadState = MutableStateFlow(DownloadState())
  val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

  private val _navigationState = MutableStateFlow(NavigationState())
  val navigationState: StateFlow<NavigationState> = _navigationState.asStateFlow()

  private val _privacyState = MutableStateFlow(PrivacyState())
  val privacyState: StateFlow<PrivacyState> = _privacyState.asStateFlow()

  private val _networkState = MutableStateFlow(NetworkState())
  val networkState: StateFlow<NetworkState> = _networkState.asStateFlow()

  private val _activeCard = MutableStateFlow(IslandActiveCard.MUSIC)
  val activeCard: StateFlow<IslandActiveCard> = _activeCard.asStateFlow()

  private var timerJob: Job? = null
  private var callTickerJob: Job? = null
  private var recorderTickerJob: Job? = null
  private var notificationExpireJob: Job? = null
  private var batteryExpireJob: Job? = null
  private var ringerExpireJob: Job? = null
  private var bluetoothExpireJob: Job? = null
  private var downloadExpireJob: Job? = null
  private var networkExpireJob: Job? = null
  private var networkLostCheckJob: Job? = null
  private var lastTelephonyState: Int = TelephonyManager.CALL_STATE_IDLE
  private var lastNetworkType: NetworkEventType? = null
  private var lastHotspotEnabled: Boolean? = null

  private var timerPauseResumeIntent: PendingIntent? = null
  private var timerCancelIntent: PendingIntent? = null
  private var navContentIntent: PendingIntent? = null
  private var navStopIntent: PendingIntent? = null
  private var notifContentIntent: PendingIntent? = null
  private var downloadContentIntent: PendingIntent? = null
  private var downloadPackageName: String = ""
  private var recorderPauseIntent: PendingIntent? = null
  private var recorderStopIntent: PendingIntent? = null
  private var lastLowAlertPct: Int = 100
  private var lastFullAlertShown: Boolean = false
  private var wasChargingState: Boolean? = null

  private var cameraManager: CameraManager? = null
  private var torchCallback: CameraManager.TorchCallback? = null
  private var availabilityCallback: CameraManager.AvailabilityCallback? = null
  private var audioRecordingCallback: AudioManager.AudioRecordingCallback? = null
  private val unavailableCameras = mutableSetOf<String>()
  private var flashCameraId: String? = null
  private var isInitialized = false

  fun initialize(context: Context) {
    if (isInitialized) return
    isInitialized = true

    val appCtx = context.applicationContext ?: context
    registerBatteryReceiver(appCtx)
    initFlashlight(appCtx)
    initPrivacyMonitors(appCtx)
    registerNetworkAndConnectivityMonitors(appCtx)
    registerTelephony(appCtx)
    registerRingerReceiver(appCtx)
    registerBluetoothAndHeadsetReceiver(appCtx)
  }

  fun shouldShowInOrientation(isLandscape: Boolean, hideInLandscape: Boolean, hasActiveCall: Boolean): Boolean {
    if (!isLandscape || !hideInLandscape) return true
    // Always keep incoming/active calls visible so user never misses a call while gaming/watching video
    return hasActiveCall
  }

  fun hasAnyActiveActivity(trackInfo: MediaTrackInfo?): Boolean {
    val now = System.currentTimeMillis()
    val isMusicActive = trackInfo != null && trackInfo.isPlaying
    val isFlashlightActive = _flashlightState.value.isOn
    val isCallActive = _callState.value.isActive
    val isTimerActive = _timerState.value.isActive
    val isNavActive = _navigationState.value.isActive
    val isPrivacyActive = _privacyState.value.hasAnyActivity
    val isNetworkActive = _networkState.value.isActive && (now - _networkState.value.timestamp < 4000L)
    val isBatteryAlertActive = (_batteryState.value.isCharging || _batteryState.value.isLowAlert || _batteryState.value.isFullAlert) &&
      (now - _batteryState.value.lastEventTime < 7000L)
    val isNotifActive = _activeNotification.value != null && (now - (_activeNotification.value?.timestamp ?: 0L) < 5000L)
    val isBluetoothActive = _bluetoothState.value.isConnected && (now - _bluetoothState.value.timestamp < 5500L)
    val isRingerActive = _ringerState.value.isActive && (now - _ringerState.value.timestamp < 3500L)
    val isDownloadActive = _downloadState.value.isActive && (now - _downloadState.value.timestamp < 30000L)

    return isMusicActive || isFlashlightActive || isCallActive || isTimerActive ||
      isNavActive || isPrivacyActive || isNetworkActive || isBatteryAlertActive ||
      isNotifActive || isBluetoothActive || isRingerActive || isDownloadActive
  }

  fun isCardCurrentlyActive(card: IslandActiveCard, trackInfo: MediaTrackInfo?, settings: CapsuleSettings): Boolean {
    val now = System.currentTimeMillis()
    return when (card) {
      IslandActiveCard.RINGER -> _ringerState.value.isActive && settings.enableRingerAlerts && (now - _ringerState.value.timestamp < 3500L)
      IslandActiveCard.CALL -> _callState.value.isActive && settings.enableCallAlerts
      IslandActiveCard.NETWORK -> _networkState.value.isActive && settings.enableNetworkAlerts && (now - _networkState.value.timestamp < 4000L)
      IslandActiveCard.BATTERY -> (_batteryState.value.isCharging || _batteryState.value.isLowAlert || _batteryState.value.isFullAlert) &&
        settings.enableBatteryAlerts && (now - _batteryState.value.lastEventTime < 7000L)
      IslandActiveCard.NOTIFICATION -> _activeNotification.value != null && settings.enableNotifications &&
        (now - (_activeNotification.value?.timestamp ?: 0L) < 5000L)
      IslandActiveCard.BLUETOOTH -> _bluetoothState.value.isConnected && settings.enableBluetoothAlerts &&
        (now - _bluetoothState.value.timestamp < 6000L)
      IslandActiveCard.NAVIGATION -> _navigationState.value.isActive && settings.enableNavigationAlerts
      IslandActiveCard.TIMER -> _timerState.value.isActive && settings.enableTimer
      IslandActiveCard.DOWNLOAD -> _downloadState.value.isActive && settings.enableDownloadProgress &&
        (now - _downloadState.value.timestamp < 30000L)
      IslandActiveCard.FLASHLIGHT -> _flashlightState.value.isOn && settings.enableFlashlightAlert
      IslandActiveCard.PRIVACY -> _privacyState.value.hasAnyActivity && settings.enablePrivacyAlerts
      IslandActiveCard.MUSIC -> trackInfo != null && trackInfo.isPlaying
      IslandActiveCard.QUICK_CONTROLS, IslandActiveCard.CLOCK -> false
    }
  }

  fun resolvePrimaryMiniCard(trackInfo: MediaTrackInfo?, settings: CapsuleSettings): IslandActiveCard? {
    val urgentOrder = listOf(
      IslandActiveCard.CALL,
      IslandActiveCard.RINGER,
      IslandActiveCard.NETWORK,
      IslandActiveCard.BATTERY,
      IslandActiveCard.NOTIFICATION,
      IslandActiveCard.BLUETOOTH
    )
    for (urgent in urgentOrder) {
      if (isCardCurrentlyActive(urgent, trackInfo, settings)) return urgent
    }

    val selected = _activeCard.value
    val persistentOrder = listOf(
      IslandActiveCard.NAVIGATION,
      IslandActiveCard.TIMER,
      IslandActiveCard.DOWNLOAD,
      IslandActiveCard.FLASHLIGHT,
      IslandActiveCard.MUSIC,
      IslandActiveCard.PRIVACY
    )
    if (selected in persistentOrder && isCardCurrentlyActive(selected, trackInfo, settings)) {
      return selected
    }
    return persistentOrder.firstOrNull { isCardCurrentlyActive(it, trackInfo, settings) }
  }

  fun getSecondaryActiveCard(
    trackInfo: MediaTrackInfo?,
    settings: CapsuleSettings,
    primaryCard: IslandActiveCard?
  ): IslandActiveCard? {
    if (!settings.enableDualCapsule || primaryCard == null) return null
    val candidates = listOf(
      IslandActiveCard.CALL,
      IslandActiveCard.NAVIGATION,
      IslandActiveCard.TIMER,
      IslandActiveCard.DOWNLOAD,
      IslandActiveCard.MUSIC,
      IslandActiveCard.FLASHLIGHT,
      IslandActiveCard.PRIVACY
    )
    return candidates.firstOrNull { it != primaryCard && isCardCurrentlyActive(it, trackInfo, settings) }
  }

  private fun registerBatteryReceiver(context: Context) {
    val filter = IntentFilter().apply {
      addAction(Intent.ACTION_POWER_CONNECTED)
      addAction(Intent.ACTION_POWER_DISCONNECTED)
      addAction(Intent.ACTION_BATTERY_CHANGED)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
          Intent.ACTION_POWER_CONNECTED -> {
            val bm = ctx?.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.takeIf { it in 0..100 }
              ?: _batteryState.value.percentage
            lastFullAlertShown = false
            lastLowAlertPct = 100
            showBatteryCharging(pct)
          }
          Intent.ACTION_POWER_DISCONNECTED -> {
            wasChargingState = false
            lastFullAlertShown = false
            _batteryState.value = _batteryState.value.copy(
              isCharging = false,
              isFullAlert = false,
              lastEventTime = System.currentTimeMillis()
            )
          }
          Intent.ACTION_BATTERY_CHANGED -> {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
              status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            val isLow = pct <= 20 && !isCharging
            val pluggedLabel = when (plugged) {
              BatteryManager.BATTERY_PLUGGED_AC -> "شاحن سريع (AC)"
              BatteryManager.BATTERY_PLUGGED_USB -> "شحن USB"
              BatteryManager.BATTERY_PLUGGED_WIRELESS -> "شحن لاسلكي"
              else -> if (isCharging) "متصل بالشاحن" else ""
            }

            val prevCharging = wasChargingState
            wasChargingState = isCharging
            val batteryEnabled = ctx?.let { CapsuleSettingsManager.getInstance(it).settings.value.enableBatteryAlerts } ?: true

            if (prevCharging == false && isCharging) {
              if (batteryEnabled) showBatteryCharging(pct, pluggedLabel)
              return
            }

            if (isCharging && (status == BatteryManager.BATTERY_STATUS_FULL || pct >= 100) && !lastFullAlertShown) {
              lastFullAlertShown = true
              if (batteryEnabled) showBatteryFullAlert(pct, pluggedLabel)
              return
            }

            if (isLow && pct < lastLowAlertPct && (pct == 20 || pct == 15 || pct == 10 || pct <= 5)) {
              lastLowAlertPct = pct
              if (batteryEnabled) showBatteryLowAlert(pct)
              return
            }

            _batteryState.value = _batteryState.value.copy(
              isCharging = isCharging,
              percentage = pct,
              isLow = isLow,
              pluggedType = pluggedLabel
            )
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering battery receiver", e)
    }
  }

  fun showBatteryCharging(pct: Int, pluggedType: String = "شحن سريع") {
    _batteryState.value = BatteryState(
      isCharging = true,
      percentage = pct,
      isLow = false,
      pluggedType = pluggedType,
      isLowAlert = false,
      isFullAlert = false,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showBatteryLowAlert(pct: Int) {
    _batteryState.value = BatteryState(
      isCharging = false,
      percentage = pct,
      isLow = true,
      pluggedType = "بطارية منخفضة",
      isLowAlert = true,
      isFullAlert = false,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      _batteryState.value = _batteryState.value.copy(isLowAlert = false)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showBatteryFullAlert(pct: Int, pluggedType: String) {
    _batteryState.value = BatteryState(
      isCharging = true,
      percentage = pct,
      isLow = false,
      pluggedType = pluggedType,
      isLowAlert = false,
      isFullAlert = true,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      _batteryState.value = _batteryState.value.copy(isFullAlert = false)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Timer & Stopwatch Controls (Internal + Real Clock App Sync)
  fun startTimer(seconds: Int, title: String = "المؤقت") {
    timerPauseResumeIntent = null
    timerCancelIntent = null
    timerJob?.cancel()
    val targetEndMs = System.currentTimeMillis() + seconds * 1000L
    _timerState.value = TimerState(
      isActive = true,
      isRunning = true,
      remainingSeconds = seconds,
      totalSeconds = seconds.coerceAtLeast(1),
      title = title,
      isStopwatch = false,
      elapsedSeconds = 0,
      targetEndTimeMs = targetEndMs,
      sourcePackage = "",
      notificationKey = ""
    )
    _activeCard.value = IslandActiveCard.TIMER
    launchTimerTicker()
  }

  fun updateExternalTimer(
    key: String,
    pkg: String,
    title: String,
    remainingSeconds: Int,
    targetEndTimeMs: Long,
    isRunning: Boolean,
    isStopwatch: Boolean = false,
    elapsedSeconds: Int = 0,
    pauseResumeIntent: PendingIntent? = null,
    cancelIntent: PendingIntent? = null
  ) {
    timerPauseResumeIntent = pauseResumeIntent ?: timerPauseResumeIntent
    timerCancelIntent = cancelIntent ?: timerCancelIntent

    val existing = _timerState.value
    val sameTimer = existing.isActive && existing.notificationKey == key && existing.isStopwatch == isStopwatch
    val effectiveTotal = if (sameTimer) {
      maxOf(existing.totalSeconds, remainingSeconds.coerceAtLeast(1))
    } else {
      remainingSeconds.coerceAtLeast(1)
    }

    val computedRemaining = if (!isStopwatch && isRunning && targetEndTimeMs > System.currentTimeMillis()) {
      ((targetEndTimeMs - System.currentTimeMillis() + 500L) / 1000L).toInt().coerceAtLeast(0)
    } else {
      remainingSeconds.coerceAtLeast(0)
    }

    val wasActive = existing.isActive && existing.notificationKey == key
    _timerState.value = TimerState(
      isActive = true,
      isRunning = isRunning,
      remainingSeconds = computedRemaining,
      totalSeconds = effectiveTotal,
      title = title.ifBlank { if (isStopwatch) "ساعة الإيقاف" else "مؤقت الساعة" },
      isStopwatch = isStopwatch,
      elapsedSeconds = elapsedSeconds.coerceAtLeast(0),
      targetEndTimeMs = targetEndTimeMs,
      sourcePackage = pkg,
      notificationKey = key
    )

    if (!wasActive) {
      _activeCard.value = IslandActiveCard.TIMER
    }

    if (isRunning) {
      launchTimerTicker()
    } else {
      timerJob?.cancel()
    }
  }

  fun cancelExternalTimer(key: String? = null) {
    val cur = _timerState.value
    if (!cur.isActive) return
    if (key == null || cur.notificationKey == key || (cur.sourcePackage.isNotEmpty() && key.contains(cur.sourcePackage))) {
      timerJob?.cancel()
      timerPauseResumeIntent = null
      timerCancelIntent = null
      _timerState.value = TimerState()
      if (_activeCard.value == IslandActiveCard.TIMER) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  private fun launchTimerTicker() {
    timerJob?.cancel()
    timerJob = scope.launch {
      while (isActive && _timerState.value.isActive && _timerState.value.isRunning) {
        delay(1000)
        val current = _timerState.value
        if (!current.isActive || !current.isRunning) break

        if (current.isStopwatch) {
          _timerState.value = current.copy(elapsedSeconds = current.elapsedSeconds + 1)
        } else {
          val remaining = if (current.targetEndTimeMs > 0L) {
            ((current.targetEndTimeMs - System.currentTimeMillis() + 500L) / 1000L).toInt().coerceAtLeast(0)
          } else {
            (current.remainingSeconds - 1).coerceAtLeast(0)
          }
          _timerState.value = current.copy(remainingSeconds = remaining)
          if (remaining <= 0) {
            _timerState.value = current.copy(isRunning = false, remainingSeconds = 0)
            // If internal timer finished, clear after a short moment; external clock app handles its own alarm notification
            if (current.sourcePackage.isEmpty()) {
              delay(4000)
              if (_timerState.value.remainingSeconds == 0 && _timerState.value.sourcePackage.isEmpty()) {
                cancelTimer()
              }
            }
            break
          }
        }
      }
    }
  }

  fun toggleTimerPause() {
    val cur = _timerState.value
    if (!cur.isActive) return

    val pending = timerPauseResumeIntent
    if (pending != null) {
      try {
        pending.send()
      } catch (e: Exception) {
        Log.e(TAG, "Failed to send timer pause/resume intent", e)
      }
    }

    if (cur.isRunning) {
      timerJob?.cancel()
      _timerState.value = cur.copy(isRunning = false)
    } else if (cur.isStopwatch || cur.remainingSeconds > 0) {
      val newTarget = if (!cur.isStopwatch) System.currentTimeMillis() + cur.remainingSeconds * 1000L else 0L
      _timerState.value = cur.copy(isRunning = true, targetEndTimeMs = newTarget)
      launchTimerTicker()
    }
  }

  fun cancelTimer() {
    val pending = timerCancelIntent
    if (pending != null) {
      try {
        pending.send()
      } catch (e: Exception) {
        Log.e(TAG, "Failed to send timer cancel intent", e)
      }
    }
    timerJob?.cancel()
    timerPauseResumeIntent = null
    timerCancelIntent = null
    _timerState.value = TimerState()
    if (_activeCard.value == IslandActiveCard.TIMER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun isTelephonyRinging(): Boolean = lastTelephonyState == TelephonyManager.CALL_STATE_RINGING
  fun isTelephonyActive(): Boolean = lastTelephonyState == TelephonyManager.CALL_STATE_OFFHOOK

  // Call controls & actual answering / declining
  fun startCall(caller: String = "Incoming Call", number: String = "Mobile", isIncoming: Boolean = true) {
    val currentCall = _callState.value
    val isTelephonyRinging = lastTelephonyState == TelephonyManager.CALL_STATE_RINGING

    // If telephony is actively ringing or current call is already incoming and not explicitly answered,
    // force it to remain incoming to strictly prevent starting the duration timer before answering!
    val effectiveIncoming = if (isTelephonyRinging) {
      true
    } else if (currentCall.isActive && currentCall.isIncoming && !isIncoming) {
      currentCall.isIncoming
    } else {
      isIncoming
    }

    _callState.value = CallState(
      isActive = true,
      callerName = if (caller.isNotBlank() && caller != "Incoming Call") caller else currentCall.callerName.ifBlank { caller },
      callerNumber = if (number.isNotBlank() && number != "Mobile") number else currentCall.callerNumber.ifBlank { number },
      durationSeconds = if (effectiveIncoming) 0 else currentCall.durationSeconds,
      isIncoming = effectiveIncoming
    )
    _activeCard.value = IslandActiveCard.CALL

    if (effectiveIncoming) {
      // CRITICAL: NEVER run call duration ticker while the call is incoming / ringing!
      callTickerJob?.cancel()
      callTickerJob = null
    } else {
      startCallTicker()
    }
  }

  fun setCallAnswered() {
    val cur = _callState.value
    if (cur.isActive) {
      _callState.value = cur.copy(isIncoming = false, durationSeconds = 0)
      startCallTicker()
    }
  }

  fun answerCall(context: Context) {
    CallManager.answerCall(context)
    setCallAnswered()
  }

  fun declineCall(context: Context) {
    CallManager.declineCall(context)
    endCall()
  }

  private fun startCallTicker() {
    callTickerJob?.cancel()
    callTickerJob = scope.launch {
      while (isActive && _callState.value.isActive && !_callState.value.isIncoming) {
        delay(1000)
        val cur = _callState.value
        if (!cur.isIncoming && cur.isActive) {
          _callState.value = cur.copy(durationSeconds = cur.durationSeconds + 1)
        }
      }
    }
  }

  fun endCall() {
    callTickerJob?.cancel()
    callTickerJob = null
    CallManager.clearNotificationIntents()
    _callState.value = CallState(isActive = false)
    if (_activeCard.value == IslandActiveCard.CALL) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun handleTelephonyState(state: Int) {
    Log.d(TAG, "Telephony state changed: $state")
    lastTelephonyState = state
    when (state) {
      TelephonyManager.CALL_STATE_IDLE -> {
        // Immediate termination on IDLE without any lingering states or delays
        endCall()
      }
      TelephonyManager.CALL_STATE_OFFHOOK -> {
        // Active connected call: user answered the call or placed an active call
        if (_callState.value.isActive) {
          setCallAnswered()
        } else {
          startCall(caller = "Active Call", number = "Mobile", isIncoming = false)
        }
      }
      TelephonyManager.CALL_STATE_RINGING -> {
        // Phone is ringing: strictly incoming, NEVER answered
        startCall(caller = "Incoming Call", number = "Mobile", isIncoming = true)
      }
    }
  }

  private fun registerTelephony(context: Context) {
    try {
      val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
      if (tm != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          tm.registerTelephonyCallback(
            context.mainExecutor,
            object : TelephonyCallback(), TelephonyCallback.CallStateListener {
              override fun onCallStateChanged(state: Int) {
                handleTelephonyState(state)
              }
            }
          )
        } else {
          @Suppress("DEPRECATION")
          tm.listen(
            object : PhoneStateListener() {
              @Deprecated("Deprecated in Java")
              override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleTelephonyState(state)
              }
            },
            PhoneStateListener.LISTEN_CALL_STATE
          )
        }
      }
    } catch (e: SecurityException) {
      Log.w(TAG, "TelephonyManager permission not granted, listening via broadcast", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering TelephonyManager callback", e)
    }

    try {
      val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          val stateStr = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
          when (stateStr) {
            TelephonyManager.EXTRA_STATE_IDLE -> handleTelephonyState(TelephonyManager.CALL_STATE_IDLE)
            TelephonyManager.EXTRA_STATE_OFFHOOK -> handleTelephonyState(TelephonyManager.CALL_STATE_OFFHOOK)
            TelephonyManager.EXTRA_STATE_RINGING -> {
              val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Mobile"
              startCall(caller = "Incoming Call", number = incomingNumber, isIncoming = true)
            }
          }
        }
      }
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.w(TAG, "Error registering phone state broadcast receiver", e)
    }
  }

  // Notification Event & App Launch
  fun postNotificationEvent(
    appName: String,
    title: String,
    text: String,
    pkg: String = "",
    contentIntent: PendingIntent? = null
  ) {
    notifContentIntent = contentIntent
    val event = NotificationEvent(
      id = System.currentTimeMillis(),
      packageName = pkg,
      appName = appName,
      title = title,
      text = text,
      timestamp = System.currentTimeMillis()
    )
    _activeNotification.value = event
    _activeCard.value = IslandActiveCard.NOTIFICATION

    notificationExpireJob?.cancel()
    notificationExpireJob = scope.launch {
      delay(4500)
      if (_activeNotification.value?.id == event.id) {
        _activeNotification.value = null
        notifContentIntent = null
        if (_activeCard.value == IslandActiveCard.NOTIFICATION) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  fun openActiveNotificationApp(context: Context) {
    val pkg = _activeNotification.value?.packageName
    openSourceApp(context, pkg, notifContentIntent)
  }

  fun openSourceApp(context: Context, packageName: String?, pendingIntent: PendingIntent? = null) {
    if (pendingIntent != null) {
      try {
        pendingIntent.send()
        return
      } catch (e: Exception) {
        Log.w(TAG, "PendingIntent launch failed, falling back to package launch", e)
      }
    }
    if (!packageName.isNullOrBlank()) {
      try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
          launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(launchIntent)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Failed to launch app $packageName", e)
      }
    }
  }

  // Bluetooth Event & Real Receivers
  fun showBluetoothConnected(deviceName: String = "Bluetooth Audio", batteryPct: Int = -1) {
    _bluetoothState.value = BluetoothState(
      isConnected = true,
      deviceName = deviceName,
      batteryPct = batteryPct,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BLUETOOTH

    bluetoothExpireJob?.cancel()
    bluetoothExpireJob = scope.launch {
      delay(5500)
      if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  private fun registerBluetoothAndHeadsetReceiver(context: Context) {
    val filter = IntentFilter().apply {
      addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
      addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
      addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
      addAction(Intent.ACTION_HEADSET_PLUG)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
          Intent.ACTION_HEADSET_PLUG -> {
            if (isInitialStickyBroadcast) return
            val state = intent.getIntExtra("state", 0)
            if (state == 1) {
              val hasMic = intent.getIntExtra("microphone", 0) == 1
              showBluetoothConnected(
                deviceName = if (hasMic) "سماعة سلكية مع مايك" else "سماعة سلكية",
                batteryPct = -1
              )
            }
          }
          BluetoothDevice.ACTION_ACL_CONNECTED,
          BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
          BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
            if (action != BluetoothDevice.ACTION_ACL_CONNECTED) {
              val connState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
              if (connState != BluetoothProfile.STATE_CONNECTED) return
            }

            val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
              intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
              @Suppress("DEPRECATION")
              intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            }
            if (device == null) return

            val canReadName = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
              ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

            val name = if (canReadName) {
              try {
                device.name?.takeIf { it.isNotBlank() } ?: "جهاز بلوتوث"
              } catch (e: SecurityException) {
                "جهاز بلوتوث"
              }
            } else {
              "جهاز بلوتوث"
            }

            var batteryPct = intent.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
            if (batteryPct < 0 && canReadName) {
              batteryPct = try {
                val method = device.javaClass.getMethod("getBatteryLevel")
                (method.invoke(device) as? Int) ?: -1
              } catch (e: Exception) {
                -1
              }
            }

            val btEnabled = CapsuleSettingsManager.getInstance(ctx ?: context).settings.value.enableBluetoothAlerts
            if (btEnabled) {
              showBluetoothConnected(deviceName = name, batteryPct = batteryPct)
            }
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering Bluetooth/Headset receiver", e)
    }
  }

  // Real Download / Install Progress
  fun updateDownloadProgress(
    key: String,
    appName: String,
    title: String,
    progress: Int,
    max: Int,
    indeterminate: Boolean,
    pkg: String = "",
    contentIntent: PendingIntent? = null
  ) {
    if (pkg.isNotBlank()) downloadPackageName = pkg
    if (contentIntent != null) downloadContentIntent = contentIntent

    val existing = _downloadState.value
    val isNew = !existing.isActive || existing.key != key
    _downloadState.value = DownloadState(
      isActive = true,
      key = key,
      appName = appName,
      title = title,
      progress = progress,
      max = max.coerceAtLeast(1),
      isIndeterminate = indeterminate,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !_callState.value.isActive && !_flashlightState.value.isOn) {
      _activeCard.value = IslandActiveCard.DOWNLOAD
    }

    downloadExpireJob?.cancel()
    downloadExpireJob = scope.launch {
      delay(25000)
      if (_downloadState.value.key == key && System.currentTimeMillis() - _downloadState.value.timestamp >= 25000L) {
        clearDownloadProgress(key)
      }
    }
  }

  fun openDownloadApp(context: Context) {
    openSourceApp(context, downloadPackageName, downloadContentIntent)
  }

  fun clearDownloadProgress(key: String? = null) {
    val cur = _downloadState.value
    if (!cur.isActive) return
    if (key == null || cur.key == key) {
      downloadExpireJob?.cancel()
      downloadContentIntent = null
      downloadPackageName = ""
      _downloadState.value = DownloadState()
      if (_activeCard.value == IslandActiveCard.DOWNLOAD) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Live Navigation (Google Maps / Waze notifications without API keys)
  fun updateNavigation(
    key: String,
    pkg: String,
    appName: String,
    instruction: String,
    distanceOrStreet: String,
    etaText: String,
    directionIcon: Bitmap? = null,
    contentIntent: PendingIntent? = null,
    stopIntent: PendingIntent? = null
  ) {
    if (contentIntent != null) navContentIntent = contentIntent
    if (stopIntent != null) navStopIntent = stopIntent
    val isNew = !_navigationState.value.isActive || _navigationState.value.key != key

    _navigationState.value = NavigationState(
      isActive = true,
      key = key,
      packageName = pkg,
      appName = appName,
      instruction = instruction.ifBlank { "الملاحة جارية" },
      distanceOrStreet = distanceOrStreet,
      etaText = etaText,
      directionIcon = directionIcon ?: _navigationState.value.directionIcon,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.NAVIGATION
    }
  }

  fun openNavigationApp(context: Context) {
    openSourceApp(context, _navigationState.value.packageName.ifBlank { "com.google.android.apps.maps" }, navContentIntent)
  }

  fun stopNavigation() {
    val stopPi = navStopIntent
    if (stopPi != null) {
      try {
        stopPi.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending navigation stop intent", e)
      }
    }
    clearNavigation()
  }

  fun clearNavigation(key: String? = null) {
    val cur = _navigationState.value
    if (!cur.isActive) return
    if (key == null || cur.key == key) {
      navContentIntent = null
      navStopIntent = null
      _navigationState.value = NavigationState()
      if (_activeCard.value == IslandActiveCard.NAVIGATION) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Network, Wi-Fi, Airplane Mode & Hotspot Monitor
  private fun registerNetworkAndConnectivityMonitors(context: Context) {
    try {
      val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
      if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        val initCaps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        lastNetworkType = when {
          initCaps == null -> NetworkEventType.NO_INTERNET
          initCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkEventType.WIFI_CONNECTED
          initCaps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkEventType.MOBILE_DATA
          else -> lastNetworkType
        }

        val callback = object : ConnectivityManager.NetworkCallback() {
          override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            super.onCapabilitiesChanged(network, caps)
            networkLostCheckJob?.cancel()
            val detected = when {
              caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkEventType.WIFI_CONNECTED
              caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkEventType.MOBILE_DATA
              else -> return
            }
            if (detected != lastNetworkType) {
              lastNetworkType = detected
              val enabled = CapsuleSettingsManager.getInstance(context).settings.value.enableNetworkAlerts
              if (enabled) {
                when (detected) {
                  NetworkEventType.WIFI_CONNECTED -> {
                    val ssidName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                      val wifiInfo = caps.transportInfo as? WifiInfo
                      val raw = wifiInfo?.ssid?.removeSurrounding("\"")
                      if (!raw.isNullOrBlank() && !raw.equals("<unknown ssid>", ignoreCase = true)) raw else null
                    } else null
                    showNetworkAlert(
                      type = NetworkEventType.WIFI_CONNECTED,
                      title = ssidName ?: "متصل بشبكة Wi-Fi",
                      subtitle = "تم الاتصال بالشبكة اللاسلكية"
                    )
                  }
                  NetworkEventType.MOBILE_DATA -> {
                    showNetworkAlert(
                      type = NetworkEventType.MOBILE_DATA,
                      title = "بيانات الهاتف",
                      subtitle = "تم التحويل إلى شبكة الجوال"
                    )
                  }
                  else -> {}
                }
              }
            }
          }

          override fun onLost(network: Network) {
            super.onLost(network)
            networkLostCheckJob?.cancel()
            networkLostCheckJob = scope.launch {
              delay(800)
              val active = cm.activeNetwork
              val isAirplane = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON,
                0
              ) != 0
              if (active == null && !isAirplane && lastNetworkType != NetworkEventType.NO_INTERNET) {
                lastNetworkType = NetworkEventType.NO_INTERNET
                if (CapsuleSettingsManager.getInstance(context).settings.value.enableNetworkAlerts) {
                  showNetworkAlert(
                    type = NetworkEventType.NO_INTERNET,
                    title = "انقطع الاتصال",
                    subtitle = "لا يتوفر اتصال بالإنترنت"
                  )
                }
              }
            }
          }
        }
        cm.registerDefaultNetworkCallback(callback)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error registering ConnectivityManager NetworkCallback", e)
    }

    try {
      val filter = IntentFilter().apply {
        addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
      }
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          val act = intent?.action ?: return
          val c = ctx ?: context
          if (!CapsuleSettingsManager.getInstance(c).settings.value.enableNetworkAlerts) return

          when (act) {
            Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
              if (isInitialStickyBroadcast) return
              val enabled = intent.getBooleanExtra("state", false)
              showNetworkAlert(
                type = if (enabled) NetworkEventType.AIRPLANE_ON else NetworkEventType.AIRPLANE_OFF,
                title = if (enabled) "وضع الطيران مفعّل" else "تم إيقاف وضع الطيران",
                subtitle = if (enabled) "تم إيقاف جميع الشبكات" else "جارٍ استعادة الاتصال"
              )
            }
            "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
              val state = intent.getIntExtra("wifi_state", -1)
              val enabled = when (state) {
                13 -> true // WIFI_AP_STATE_ENABLED
                11 -> false // WIFI_AP_STATE_DISABLED
                else -> return
              }
              if (isInitialStickyBroadcast) {
                lastHotspotEnabled = enabled
                return
              }
              if (lastHotspotEnabled != enabled) {
                lastHotspotEnabled = enabled
                showNetworkAlert(
                  type = if (enabled) NetworkEventType.HOTSPOT_ON else NetworkEventType.HOTSPOT_OFF,
                  title = if (enabled) "نقطة الاتصال مفعّلة" else "تم إيقاف نقطة الاتصال",
                  subtitle = if (enabled) "مشاركة Wi-Fi نشطة الآن" else "توقفت مشاركة الإنترنت"
                )
              }
            }
          }
        }
      }
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.w(TAG, "Error registering Airplane/Hotspot receiver", e)
    }
  }

  fun showNetworkAlert(type: NetworkEventType, title: String, subtitle: String) {
    _networkState.value = NetworkState(
      isActive = true,
      type = type,
      title = title,
      subtitle = subtitle,
      timestamp = System.currentTimeMillis()
    )
    if (!_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.NETWORK
    }

    networkExpireJob?.cancel()
    networkExpireJob = scope.launch {
      delay(4000)
      _networkState.value = _networkState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.NETWORK) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun notifyHotspotFromSystemNotification(enabled: Boolean) {
    if (lastHotspotEnabled == enabled) return
    lastHotspotEnabled = enabled
    showNetworkAlert(
      type = if (enabled) NetworkEventType.HOTSPOT_ON else NetworkEventType.HOTSPOT_OFF,
      title = if (enabled) "نقطة الاتصال مفعّلة" else "تم إيقاف نقطة الاتصال",
      subtitle = if (enabled) "مشاركة Wi-Fi نشطة الآن" else "توقفت مشاركة الإنترنت"
    )
  }

  // Real Camera, Microphone & Voice Recorder Privacy Monitor
  private fun initPrivacyMonitors(context: Context) {
    try {
      val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
      if (cm != null) {
        availabilityCallback = object : CameraManager.AvailabilityCallback() {
          override fun onCameraAvailable(cameraId: String) {
            super.onCameraAvailable(cameraId)
            unavailableCameras.remove(cameraId)
            updateCameraUsageState()
          }

          override fun onCameraUnavailable(cameraId: String) {
            super.onCameraUnavailable(cameraId)
            if (!_flashlightState.value.isOn || cameraId != flashCameraId) {
              unavailableCameras.add(cameraId)
              updateCameraUsageState()
            }
          }
        }
        cm.registerAvailabilityCallback(availabilityCallback!!, null)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Could not register Camera AvailabilityCallback", e)
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      try {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null) {
          val initialMicActive = am.activeRecordingConfigurations.isNotEmpty()
          _privacyState.value = _privacyState.value.copy(isMicInUse = initialMicActive)

          audioRecordingCallback = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
              super.onRecordingConfigChanged(configs)
              val active = !configs.isNullOrEmpty()
              _privacyState.value = _privacyState.value.copy(
                isMicInUse = active,
                timestamp = System.currentTimeMillis()
              )
            }
          }
          am.registerAudioRecordingCallback(audioRecordingCallback!!, null)
        }
      } catch (e: Exception) {
        Log.w(TAG, "Could not register AudioRecordingCallback", e)
      }
    }
  }

  private fun updateCameraUsageState() {
    val active = unavailableCameras.isNotEmpty()
    _privacyState.value = _privacyState.value.copy(
      isCameraInUse = active,
      timestamp = System.currentTimeMillis()
    )
  }

  fun updateVoiceRecorder(
    key: String,
    pkg: String,
    appName: String,
    title: String,
    elapsedSeconds: Int,
    isRunning: Boolean,
    pauseIntent: PendingIntent? = null,
    stopIntent: PendingIntent? = null
  ) {
    if (pauseIntent != null) recorderPauseIntent = pauseIntent
    if (stopIntent != null) recorderStopIntent = stopIntent
    val isNew = !_privacyState.value.isVoiceRecorderActive || _privacyState.value.recorderKey != key

    _privacyState.value = _privacyState.value.copy(
      isVoiceRecorderActive = true,
      recorderKey = key,
      recorderPackage = pkg,
      recorderAppName = appName,
      recorderTitle = title.ifBlank { "تسجيل صوتي" },
      elapsedSeconds = elapsedSeconds.coerceAtLeast(0),
      isRecorderRunning = isRunning,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.PRIVACY
    }

    if (isRunning) {
      launchRecorderTicker()
    } else {
      recorderTickerJob?.cancel()
    }
  }

  private fun launchRecorderTicker() {
    recorderTickerJob?.cancel()
    recorderTickerJob = scope.launch {
      while (isActive && _privacyState.value.isVoiceRecorderActive && _privacyState.value.isRecorderRunning) {
        delay(1000)
        val cur = _privacyState.value
        if (!cur.isVoiceRecorderActive || !cur.isRecorderRunning) break
        _privacyState.value = cur.copy(elapsedSeconds = cur.elapsedSeconds + 1)
      }
    }
  }

  fun toggleVoiceRecorderPause() {
    val cur = _privacyState.value
    if (!cur.isVoiceRecorderActive) return
    recorderPauseIntent?.let {
      try {
        it.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending recorder pause intent", e)
      }
    }
    if (cur.isRecorderRunning) {
      recorderTickerJob?.cancel()
      _privacyState.value = cur.copy(isRecorderRunning = false)
    } else {
      _privacyState.value = cur.copy(isRecorderRunning = true)
      launchRecorderTicker()
    }
  }

  fun stopVoiceRecorder() {
    recorderStopIntent?.let {
      try {
        it.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending recorder stop intent", e)
      }
    }
    clearVoiceRecorder()
  }

  fun clearVoiceRecorder(key: String? = null) {
    val cur = _privacyState.value
    if (!cur.isVoiceRecorderActive) return
    if (key == null || cur.recorderKey == key) {
      recorderTickerJob?.cancel()
      recorderPauseIntent = null
      recorderStopIntent = null
      _privacyState.value = cur.copy(
        isVoiceRecorderActive = false,
        recorderKey = "",
        recorderPackage = "",
        recorderAppName = "",
        recorderTitle = "",
        elapsedSeconds = 0,
        isRecorderRunning = false
      )
      if (_activeCard.value == IslandActiveCard.PRIVACY && !cur.isCameraInUse && !cur.isMicInUse) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Camera Torch / Flashlight implementation
  private fun initFlashlight(context: Context) {
    try {
      val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
      cameraManager = cm
      if (cm != null) {
        flashCameraId = findFlashCameraId(cm)
        torchCallback = object : CameraManager.TorchCallback() {
          override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            super.onTorchModeChanged(cameraId, enabled)
            if (cameraId == flashCameraId || flashCameraId == null) {
              flashCameraId = cameraId
              _flashlightState.value = FlashlightState(isOn = enabled)
              if (enabled) {
                _activeCard.value = IslandActiveCard.FLASHLIGHT
              } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
                _activeCard.value = IslandActiveCard.MUSIC
              }
            }
          }
        }
        cm.registerTorchCallback(torchCallback!!, null)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing camera torch callback", e)
    }
  }

  private fun findFlashCameraId(cm: CameraManager): String? {
    try {
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val facing = chars.get(CameraCharacteristics.LENS_FACING)
        if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
          return id
        }
      }
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        if (chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
          return id
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error finding flash camera id", e)
    }
    return cm.cameraIdList.firstOrNull()
  }

  fun toggleFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    val targetMode = !_flashlightState.value.isOn
    try {
      cm?.setTorchMode(id, targetMode)
      _flashlightState.value = FlashlightState(isOn = targetMode)
      if (targetMode) {
        _activeCard.value = IslandActiveCard.FLASHLIGHT
      } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error toggling torch on camera id $id", e)
      _flashlightState.value = FlashlightState(isOn = targetMode)
    }
  }

  fun turnOffFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    try {
      cm?.setTorchMode(id, false)
      _flashlightState.value = FlashlightState(isOn = false)
      if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error turning off torch", e)
      _flashlightState.value = FlashlightState(isOn = false)
    }
  }

  fun turnOnFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    try {
      cm?.setTorchMode(id, true)
      _flashlightState.value = FlashlightState(isOn = true)
      _activeCard.value = IslandActiveCard.FLASHLIGHT
    } catch (e: Exception) {
      Log.e(TAG, "Error turning on torch", e)
      _flashlightState.value = FlashlightState(isOn = true)
    }
  }

  // Sound Mode Detection & Control (Ring / Vibrate / Silent / Muted DND)
  fun detectRealSoundMode(context: Context): SoundMode {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null) {
      val filter = nm.currentInterruptionFilter
      if (filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
        filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
      ) {
        return SoundMode.MUTED_DND
      }
    }

    return when (am?.ringerMode) {
      AudioManager.RINGER_MODE_VIBRATE -> SoundMode.VIBRATE
      AudioManager.RINGER_MODE_SILENT -> SoundMode.SILENT
      AudioManager.RINGER_MODE_NORMAL -> {
        val ringVol = am.getStreamVolume(AudioManager.STREAM_RING)
        if (ringVol == 0) SoundMode.SILENT else SoundMode.RING
      }
      else -> SoundMode.RING
    }
  }

  private fun registerRingerReceiver(context: Context) {
    _currentSoundMode.value = detectRealSoundMode(context)

    val filter = IntentFilter().apply {
      addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
      }
      addAction("android.media.VOLUME_CHANGED_ACTION")
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val act = intent?.action ?: return
        val c = ctx ?: context

        if (act == "android.media.VOLUME_CHANGED_ACTION") {
          val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
          if (streamType != AudioManager.STREAM_RING) return
        }

        val detected = detectRealSoundMode(c)
        val previous = _currentSoundMode.value
        _currentSoundMode.value = detected

        val ringerEnabled = CapsuleSettingsManager.getInstance(c).settings.value.enableRingerAlerts
        if (ringerEnabled && !isInitialStickyBroadcast && (detected != previous || act != "android.media.VOLUME_CHANGED_ACTION")) {
          showRingerMode(detected)
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering ringer receiver", e)
    }
  }

  fun setSoundMode(context: Context, mode: SoundMode) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    val policyGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || (nm?.isNotificationPolicyAccessGranted == true)

    try {
      when (mode) {
        SoundMode.RING -> {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && policyGranted) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_NORMAL
          if (am.getStreamVolume(AudioManager.STREAM_RING) == 0) {
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_RING)
            am.setStreamVolume(AudioManager.STREAM_RING, (maxVol / 2).coerceAtLeast(1), 0)
          }
        }
        SoundMode.VIBRATE -> {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && policyGranted) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
        }
        SoundMode.SILENT -> {
          if (!policyGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            openNotificationPolicySettings(context)
            return
          }
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_SILENT
        }
        SoundMode.MUTED_DND -> {
          if (!policyGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            openNotificationPolicySettings(context)
            return
          }
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
          }
        }
      }
      val actual = detectRealSoundMode(context)
      _currentSoundMode.value = actual
      showRingerMode(actual)
    } catch (e: SecurityException) {
      Log.w(TAG, "Policy access required for silent/DND", e)
      openNotificationPolicySettings(context)
    } catch (e: Exception) {
      Log.e(TAG, "Error setting sound mode", e)
    }
  }

  fun cycleSoundMode(context: Context) {
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    val policyGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || (nm?.isNotificationPolicyAccessGranted == true)
    val nextMode = when (_currentSoundMode.value) {
      SoundMode.RING -> SoundMode.VIBRATE
      SoundMode.VIBRATE -> if (policyGranted) SoundMode.SILENT else SoundMode.RING
      SoundMode.SILENT -> SoundMode.MUTED_DND
      SoundMode.MUTED_DND -> SoundMode.RING
    }
    setSoundMode(context, nextMode)
  }

  private fun openNotificationPolicySettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      try {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
      } catch (e: Exception) {
        Log.e(TAG, "Could not open DND policy settings", e)
      }
    }
  }

  fun showRingerMode(mode: SoundMode) {
    _currentSoundMode.value = mode
    _ringerState.value = RingerState(
      isActive = true,
      mode = mode,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.RINGER

    ringerExpireJob?.cancel()
    ringerExpireJob = scope.launch {
      delay(3500)
      _ringerState.value = _ringerState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.RINGER) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showRingerMode(isSilent: Boolean) {
    showRingerMode(if (isSilent) SoundMode.SILENT else SoundMode.RING)
  }

  fun dismissRinger() {
    _ringerState.value = _ringerState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.RINGER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun selectCard(card: IslandActiveCard) {
    _activeCard.value = card
  }
}
