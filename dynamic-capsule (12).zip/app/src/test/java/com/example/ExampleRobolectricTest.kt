package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NetworkEventType
import com.example.island.SoundMode
import com.example.media.AlbumColorExtractor
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence with negative and positive offset`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(-150)
    assertEquals(-150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(150)
    assertEquals(150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(-35)
    assertEquals(-35, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(0)
    assertEquals(0, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateShowWhenIdle(false)
    assertFalse(settingsManager.settings.value.showWhenIdle)

    settingsManager.updateAccentColorIndex(2)
    assertEquals(2, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test call state immediate termination on CALL_STATE_IDLE and decline`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // Start incoming call
    IslandStateManager.startCall("Sarah Connor", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.callState.value.isIncoming)

    // Simulate TelephonyManager reporting CALL_STATE_IDLE (call declined or ended)
    IslandStateManager.handleTelephonyState(android.telephony.TelephonyManager.CALL_STATE_IDLE)
    assertFalse("Call state must terminate immediately when phone is idle", IslandStateManager.callState.value.isActive)

    // Start another call and decline it
    IslandStateManager.startCall("John Smith", "987654321", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    IslandStateManager.declineCall(context)
    assertFalse("Call state must terminate immediately when declined", IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test estimated position bounds and stability`() {
    val now = android.os.SystemClock.elapsedRealtime()
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Artist",
      durationMs = 200000L,
      currentPositionMs = 50000L,
      isPlaying = true,
      lastUpdateTime = now
    )

    // Position at now should be close to base
    val estimated = track.getEstimatedPositionMs()
    assertTrue(estimated in 50000L..50050L)

    // When paused, estimated position should equal currentPositionMs exactly
    val pausedTrack = track.copy(isPlaying = false)
    assertEquals(50000L, pausedTrack.getEstimatedPositionMs())
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Far closer",
      artist = "David",
      durationMs = 236000L,
      currentPositionMs = 174000L,
      isPlaying = false
    )

    assertEquals("03:56", track.formatTime(track.durationMs))
    assertEquals("02:54", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }

  @Test
  fun `test island state manager and activity detection`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // When idle and no music
    assertFalse(IslandStateManager.hasAnyActiveActivity(null))

    // When torch is turned on
    IslandStateManager.turnOnFlashlight(context)
    assertTrue(IslandStateManager.flashlightState.value.isOn)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Turn torch off
    IslandStateManager.turnOffFlashlight(context)
    assertFalse(IslandStateManager.flashlightState.value.isOn)

    // When timer is started
    IslandStateManager.startTimer(60, "Tea Timer")
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.cancelTimer()

    // When call is active
    IslandStateManager.startCall("John Doe", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.endCall()
    assertFalse(IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test external clock timer sync and paused state activity`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    val futureEnd = System.currentTimeMillis() + 120_000L
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 120,
      targetEndTimeMs = futureEnd,
      isRunning = true,
      isStopwatch = false
    )

    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)
    assertEquals(IslandActiveCard.TIMER, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Simulate OEM second-by-second update: totalSeconds must remain preserved at 120
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 95,
      targetEndTimeMs = System.currentTimeMillis() + 95_000L,
      isRunning = true,
      isStopwatch = false
    )
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)

    // Pausing timer must keep isActive true so capsule stays visible
    IslandStateManager.toggleTimerPause()
    assertFalse(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Removing notification clears the external timer cleanly
    IslandStateManager.cancelExternalTimer("0|com.google.android.deskclock|1|null|1001")
    assertFalse(IslandStateManager.timerState.value.isActive)
  }

  @Test
  fun `test 4-state sound mode transitions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.showRingerMode(SoundMode.VIBRATE)
    assertEquals(SoundMode.VIBRATE, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isActive)
    assertTrue(IslandStateManager.ringerState.value.isSilent)
    assertEquals(IslandActiveCard.RINGER, IslandStateManager.activeCard.value)

    IslandStateManager.showRingerMode(SoundMode.SILENT)
    assertEquals(SoundMode.SILENT, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.MUTED_DND)
    assertEquals(SoundMode.MUTED_DND, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.RING)
    assertEquals(SoundMode.RING, IslandStateManager.currentSoundMode.value)
    assertFalse(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.dismissRinger()
    assertFalse(IslandStateManager.ringerState.value.isActive)
  }

  @Test
  fun `test download progress tracking and completion cleanup`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.updateDownloadProgress(
      key = "0|com.android.vending|42|null|1002",
      appName = "Google Play",
      title = "Downloading update",
      progress = 45,
      max = 100,
      indeterminate = false
    )

    assertTrue(IslandStateManager.downloadState.value.isActive)
    assertEquals(45, IslandStateManager.downloadState.value.percent)
    assertEquals(IslandActiveCard.DOWNLOAD, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.clearDownloadProgress("0|com.android.vending|42|null|1002")
    assertFalse(IslandStateManager.downloadState.value.isActive)
  }

  @Test
  fun `test navigation state and voice recorder privacy state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // Google Maps Navigation (API-free notification parsing state)
    IslandStateManager.updateNavigation(
      key = "0|com.google.android.apps.maps|10|nav|100",
      pkg = "com.google.android.apps.maps",
      appName = "Maps",
      instruction = "200 م",
      distanceOrStreet = "انعطف يميناً إلى شارع الملك فهد",
      etaText = "12 دقيقة • 5 كم"
    )
    assertTrue(IslandStateManager.navigationState.value.isActive)
    assertEquals(IslandActiveCard.NAVIGATION, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.clearNavigation("0|com.google.android.apps.maps|10|nav|100")
    assertFalse(IslandStateManager.navigationState.value.isActive)

    // Voice Recorder Privacy State
    IslandStateManager.updateVoiceRecorder(
      key = "0|com.coloros.soundrecorder|5|rec|100",
      pkg = "com.coloros.soundrecorder",
      appName = "المسجل",
      title = "تسجيل صوتي",
      elapsedSeconds = 15,
      isRunning = true
    )
    assertTrue(IslandStateManager.privacyState.value.isVoiceRecorderActive)
    assertEquals("00:15", IslandStateManager.privacyState.value.formatElapsed())
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.toggleVoiceRecorderPause()
    assertFalse(IslandStateManager.privacyState.value.isRecorderRunning)

    IslandStateManager.clearVoiceRecorder("0|com.coloros.soundrecorder|5|rec|100")
    assertFalse(IslandStateManager.privacyState.value.isVoiceRecorderActive)
  }

  @Test
  fun `test dual split capsule activity switching and excluded packages persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // Test App Notification Filter persistence
    settingsManager.setPackageExcluded("com.whatsapp", true)
    assertTrue(settingsManager.settings.value.excludedPackages.contains("com.whatsapp"))
    settingsManager.clearExcludedPackages()
    assertFalse(settingsManager.settings.value.excludedPackages.contains("com.whatsapp"))

    // Test Dual Split Capsule when Music and Timer are both active
    val playingTrack = MediaTrackInfo(
      title = "Track A",
      artist = "Artist A",
      durationMs = 180000L,
      currentPositionMs = 10000L,
      isPlaying = true
    )
    IslandStateManager.startTimer(90, "Tea Timer")
    IslandStateManager.selectCard(IslandActiveCard.MUSIC)

    val settings = settingsManager.settings.value
    val primary = IslandStateManager.resolvePrimaryMiniCard(playingTrack, settings)
    val secondary = IslandStateManager.getSecondaryActiveCard(playingTrack, settings, primary)
    assertEquals(IslandActiveCard.MUSIC, primary)
    assertEquals(IslandActiveCard.TIMER, secondary)

    // Tapping secondary swaps primary to TIMER and secondary to MUSIC
    IslandStateManager.selectCard(secondary!!)
    val swappedPrimary = IslandStateManager.resolvePrimaryMiniCard(playingTrack, settings)
    val swappedSecondary = IslandStateManager.getSecondaryActiveCard(playingTrack, settings, swappedPrimary)
    assertEquals(IslandActiveCard.TIMER, swappedPrimary)
    assertEquals(IslandActiveCard.MUSIC, swappedSecondary)

    IslandStateManager.cancelTimer()
  }

  @Test
  fun `test album color extractor extracts vibrant color and falls back safely`() {
    val fallback = Color(0xFF00E676)

    // Null bitmap returns fallback
    assertEquals(fallback, AlbumColorExtractor.extractAccentColor(null, fallback))

    // Pure black bitmap returns fallback
    val blackBmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888).apply {
      eraseColor(AndroidColor.BLACK)
    }
    assertEquals(fallback, AlbumColorExtractor.extractAccentColor(blackBmp, fallback))

    // Bright crimson bitmap extracts red-dominant vibrant accent
    val redBmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888).apply {
      eraseColor(AndroidColor.rgb(230, 30, 60))
    }
    val extracted = AlbumColorExtractor.extractAccentColor(redBmp, fallback)
    assertTrue("Red channel should dominate extracted color", extracted.red > extracted.green && extracted.red > extracted.blue)
  }

  @Test
  fun `test landscape auto-hide orientation logic preserves incoming and active calls`() {
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = false, hideInLandscape = true, hasActiveCall = false))
    assertFalse(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = true, hasActiveCall = false))
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = true, hasActiveCall = true))
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = false, hasActiveCall = false))
  }

  @Test
  fun `test network alerts and new capsule settings persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateCapsuleStyleIndex(1)
    assertEquals(1, settingsManager.settings.value.capsuleStyleIndex)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DYNAMIC_ALBUM_COLORS, false)
    assertFalse(settingsManager.settings.value.enableDynamicAlbumColors)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DYNAMIC_ALBUM_COLORS, true)
    assertTrue(settingsManager.settings.value.enableDynamicAlbumColors)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_HIDE_IN_LANDSCAPE, false)
    assertFalse(settingsManager.settings.value.hideInLandscape)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_NETWORK_ALERTS, true)
    assertTrue(settingsManager.settings.value.enableNetworkAlerts)

    IslandStateManager.showNetworkAlert(
      type = NetworkEventType.WIFI_CONNECTED,
      title = "HomeWiFi",
      subtitle = "تم الاتصال بالشبكة اللاسلكية"
    )
    assertTrue(IslandStateManager.networkState.value.isActive)
    assertEquals(NetworkEventType.WIFI_CONNECTED, IslandStateManager.networkState.value.type)
    assertEquals("HomeWiFi", IslandStateManager.networkState.value.title)
    assertEquals(IslandActiveCard.NETWORK, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
  }
}
