package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CapsuleSettingsManager private constructor(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("dynamic_capsule_prefs", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(loadSettings())
  val settings: StateFlow<CapsuleSettings> = _settings.asStateFlow()

  private fun loadSettings(): CapsuleSettings {
    return CapsuleSettings(
      serviceEnabled = prefs.getBoolean(KEY_SERVICE_ENABLED, true),
      notchOffsetYDp = prefs.getInt(KEY_NOTCH_OFFSET_Y, 0),
      capsuleWidthDp = prefs.getInt(KEY_CAPSULE_WIDTH, 220),
      capsuleHeightDp = prefs.getInt(KEY_CAPSULE_HEIGHT, 46),
      accentColorIndex = prefs.getInt(KEY_ACCENT_COLOR, 0),
      autoCollapseSeconds = prefs.getInt(KEY_AUTO_COLLAPSE, 0),
      showWhenIdle = prefs.getBoolean(KEY_SHOW_WHEN_IDLE, false),
      hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true),
      enableBatteryAlerts = prefs.getBoolean(KEY_BATTERY_ALERTS, true),
      enableCallAlerts = prefs.getBoolean(KEY_CALL_ALERTS, true),
      enableTimer = prefs.getBoolean(KEY_TIMER, true),
      enableNotifications = prefs.getBoolean(KEY_NOTIFICATIONS, true),
      enableBluetoothAlerts = prefs.getBoolean(KEY_BLUETOOTH_ALERTS, true),
      enableFlashlightAlert = prefs.getBoolean(KEY_FLASHLIGHT_ALERT, true),
      enableRingerAlerts = prefs.getBoolean(KEY_RINGER_ALERTS, true),
      enableDownloadProgress = prefs.getBoolean(KEY_DOWNLOAD_PROGRESS, true),
      enableNavigationAlerts = prefs.getBoolean(KEY_NAVIGATION_ALERTS, true),
      enablePrivacyAlerts = prefs.getBoolean(KEY_PRIVACY_ALERTS, true),
      enableDualCapsule = prefs.getBoolean(KEY_DUAL_CAPSULE, true),
      enableDynamicAlbumColors = prefs.getBoolean(KEY_DYNAMIC_ALBUM_COLORS, true),
      capsuleStyleIndex = prefs.getInt(KEY_CAPSULE_STYLE, 0),
      openAnimationIndex = prefs.getInt(KEY_OPEN_ANIMATION, 0),
      auraAnimationIndex = prefs.getInt(KEY_AURA_ANIMATION, 0),
      visualizerStyleIndex = prefs.getInt(KEY_VISUALIZER_STYLE, 0),
      hideInLandscape = prefs.getBoolean(KEY_HIDE_IN_LANDSCAPE, true),
      enableNetworkAlerts = prefs.getBoolean(KEY_NETWORK_ALERTS, true),
      enableVolumeAlerts = prefs.getBoolean(KEY_VOLUME_ALERTS, true),
      enableAlarmSync = prefs.getBoolean(KEY_ALARM_SYNC, true),
      excludedPackages = prefs.getStringSet(KEY_EXCLUDED_PACKAGES, emptySet())?.toSet() ?: emptySet()
    )
  }

  fun updateServiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    _settings.value = _settings.value.copy(serviceEnabled = enabled)
  }

  fun updateNotchOffsetY(offset: Int) {
    prefs.edit().putInt(KEY_NOTCH_OFFSET_Y, offset).apply()
    _settings.value = _settings.value.copy(notchOffsetYDp = offset)
  }

  fun updateCapsuleWidth(width: Int) {
    prefs.edit().putInt(KEY_CAPSULE_WIDTH, width).apply()
    _settings.value = _settings.value.copy(capsuleWidthDp = width)
  }

  fun updateCapsuleHeight(height: Int) {
    prefs.edit().putInt(KEY_CAPSULE_HEIGHT, height).apply()
    _settings.value = _settings.value.copy(capsuleHeightDp = height)
  }

  fun updateAccentColorIndex(index: Int) {
    prefs.edit().putInt(KEY_ACCENT_COLOR, index).apply()
    _settings.value = _settings.value.copy(accentColorIndex = index)
  }

  fun updateAutoCollapseSeconds(seconds: Int) {
    prefs.edit().putInt(KEY_AUTO_COLLAPSE, seconds).apply()
    _settings.value = _settings.value.copy(autoCollapseSeconds = seconds)
  }

  fun updateShowWhenIdle(show: Boolean) {
    prefs.edit().putBoolean(KEY_SHOW_WHEN_IDLE, show).apply()
    _settings.value = _settings.value.copy(showWhenIdle = show)
  }

  fun toggleFeature(featureKey: String, enabled: Boolean) {
    prefs.edit().putBoolean(featureKey, enabled).apply()
    _settings.value = when (featureKey) {
      KEY_BATTERY_ALERTS -> _settings.value.copy(enableBatteryAlerts = enabled)
      KEY_CALL_ALERTS -> _settings.value.copy(enableCallAlerts = enabled)
      KEY_TIMER -> _settings.value.copy(enableTimer = enabled)
      KEY_NOTIFICATIONS -> _settings.value.copy(enableNotifications = enabled)
      KEY_BLUETOOTH_ALERTS -> _settings.value.copy(enableBluetoothAlerts = enabled)
      KEY_FLASHLIGHT_ALERT -> _settings.value.copy(enableFlashlightAlert = enabled)
      KEY_RINGER_ALERTS -> _settings.value.copy(enableRingerAlerts = enabled)
      KEY_DOWNLOAD_PROGRESS -> _settings.value.copy(enableDownloadProgress = enabled)
      KEY_NAVIGATION_ALERTS -> _settings.value.copy(enableNavigationAlerts = enabled)
      KEY_PRIVACY_ALERTS -> _settings.value.copy(enablePrivacyAlerts = enabled)
      KEY_DUAL_CAPSULE -> _settings.value.copy(enableDualCapsule = enabled)
      KEY_DYNAMIC_ALBUM_COLORS -> _settings.value.copy(enableDynamicAlbumColors = enabled)
      KEY_HIDE_IN_LANDSCAPE -> _settings.value.copy(hideInLandscape = enabled)
      KEY_NETWORK_ALERTS -> _settings.value.copy(enableNetworkAlerts = enabled)
      KEY_VOLUME_ALERTS -> _settings.value.copy(enableVolumeAlerts = enabled)
      KEY_ALARM_SYNC -> _settings.value.copy(enableAlarmSync = enabled)
      KEY_HAPTIC -> _settings.value.copy(hapticFeedback = enabled)
      else -> _settings.value
    }
  }

  fun updateCapsuleStyleIndex(index: Int) {
    prefs.edit().putInt(KEY_CAPSULE_STYLE, index).apply()
    _settings.value = _settings.value.copy(capsuleStyleIndex = index)
  }

  fun updateOpenAnimationIndex(index: Int) {
    val safe = index.coerceIn(0, 4)
    prefs.edit().putInt(KEY_OPEN_ANIMATION, safe).apply()
    _settings.value = _settings.value.copy(openAnimationIndex = safe)
  }

  fun updateAuraAnimationIndex(index: Int) {
    val safe = index.coerceIn(0, 4)
    prefs.edit().putInt(KEY_AURA_ANIMATION, safe).apply()
    _settings.value = _settings.value.copy(auraAnimationIndex = safe)
  }

  fun updateVisualizerStyleIndex(index: Int) {
    val safe = index.coerceIn(0, 3)
    prefs.edit().putInt(KEY_VISUALIZER_STYLE, safe).apply()
    _settings.value = _settings.value.copy(visualizerStyleIndex = safe)
  }

  fun setPackageExcluded(packageName: String, excluded: Boolean) {
    val updated = _settings.value.excludedPackages.toMutableSet()
    if (excluded) updated.add(packageName) else updated.remove(packageName)
    val immutable = updated.toSet()
    prefs.edit().putStringSet(KEY_EXCLUDED_PACKAGES, immutable).apply()
    _settings.value = _settings.value.copy(excludedPackages = immutable)
  }

  fun clearExcludedPackages() {
    prefs.edit().putStringSet(KEY_EXCLUDED_PACKAGES, emptySet()).apply()
    _settings.value = _settings.value.copy(excludedPackages = emptySet())
  }

  companion object {
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_NOTCH_OFFSET_Y = "notch_offset_y"
    private const val KEY_CAPSULE_WIDTH = "capsule_width"
    private const val KEY_CAPSULE_HEIGHT = "capsule_height"
    private const val KEY_ACCENT_COLOR = "accent_color"
    private const val KEY_AUTO_COLLAPSE = "auto_collapse"
    private const val KEY_SHOW_WHEN_IDLE = "show_when_idle"
    const val KEY_HAPTIC = "haptic"

    const val KEY_BATTERY_ALERTS = "enable_battery_alerts"
    const val KEY_CALL_ALERTS = "enable_call_alerts"
    const val KEY_TIMER = "enable_timer"
    const val KEY_NOTIFICATIONS = "enable_notifications"
    const val KEY_BLUETOOTH_ALERTS = "enable_bluetooth_alerts"
    const val KEY_FLASHLIGHT_ALERT = "enable_flashlight_alert"
    const val KEY_RINGER_ALERTS = "enable_ringer_alerts"
    const val KEY_DOWNLOAD_PROGRESS = "enable_download_progress"
    const val KEY_NAVIGATION_ALERTS = "enable_navigation_alerts"
    const val KEY_PRIVACY_ALERTS = "enable_privacy_alerts"
    const val KEY_DUAL_CAPSULE = "enable_dual_capsule"
    const val KEY_DYNAMIC_ALBUM_COLORS = "enable_dynamic_album_colors"
    const val KEY_HIDE_IN_LANDSCAPE = "hide_in_landscape"
    const val KEY_NETWORK_ALERTS = "enable_network_alerts"
    const val KEY_VOLUME_ALERTS = "enable_volume_alerts"
    const val KEY_ALARM_SYNC = "enable_alarm_sync"
    private const val KEY_CAPSULE_STYLE = "capsule_style_index"
    private const val KEY_OPEN_ANIMATION = "open_animation_index"
    private const val KEY_AURA_ANIMATION = "aura_animation_index"
    private const val KEY_VISUALIZER_STYLE = "visualizer_style_index"
    private const val KEY_EXCLUDED_PACKAGES = "excluded_notif_packages"

    @Volatile
    private var INSTANCE: CapsuleSettingsManager? = null

    fun getInstance(context: Context): CapsuleSettingsManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: CapsuleSettingsManager(context).also { INSTANCE = it }
      }
    }
  }
}
