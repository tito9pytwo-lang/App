package com.example.island

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object WeatherRepository {

  private const val TAG = "WeatherRepository"
  private const val PREFS_NAME = "dynamic_capsule_weather_prefs"
  private const val KEY_LAST_LAT = "last_lat"
  private const val KEY_LAST_LON = "last_lon"
  private const val KEY_LAST_CITY = "last_city"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(12, TimeUnit.SECONDS)
      .readTimeout(12, TimeUnit.SECONDS)
      .build()
  }

  private fun prefs(context: Context): SharedPreferences =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  suspend fun fetchLiveWeather(
    context: Context,
    explicitCityQuery: String = ""
  ): Result<WeatherState> = withContext(Dispatchers.IO) {
    try {
      val appCtx = context.applicationContext ?: context
      var targetLat: Double? = null
      var targetLon: Double? = null
      var resolvedCity = ""

      // 1. If user entered an explicit city name, geocode it via Open-Meteo Geocoding API
      if (explicitCityQuery.isNotBlank()) {
        val geo = geocodeCity(explicitCityQuery.trim())
        if (geo != null) {
          targetLat = geo.first
          targetLon = geo.second
          resolvedCity = geo.third
        }
      }

      // 2. Otherwise use real device coarse location if permission is granted
      if (targetLat == null || targetLon == null) {
        val deviceLoc = getBestLastKnownLocation(appCtx)
        if (deviceLoc != null) {
          targetLat = deviceLoc.latitude
          targetLon = deviceLoc.longitude
          resolvedCity = reverseGeocodeCity(appCtx, targetLat, targetLon)
            ?: "موقعي الحالي"
        }
      }

      // 3. Fallback to previously resolved coordinates stored on device (no hardcoded fake cities)
      if (targetLat == null || targetLon == null) {
        val p = prefs(appCtx)
        if (p.contains(KEY_LAST_LAT) && p.contains(KEY_LAST_LON)) {
          targetLat = Double.fromBits(p.getLong(KEY_LAST_LAT, 0L))
          targetLon = Double.fromBits(p.getLong(KEY_LAST_LON, 0L))
          resolvedCity = p.getString(KEY_LAST_CITY, "موقعي") ?: "موقعي"
        }
      }

      if (targetLat == null || targetLon == null) {
        return@withContext Result.failure(
          IllegalStateException("يرجى منح إذن الموقع أو كتابة اسم مدينتك لتحديث الطقس")
        )
      }

      // Persist resolved coordinates cleanly
      prefs(appCtx).edit()
        .putLong(KEY_LAST_LAT, targetLat.toBits())
        .putLong(KEY_LAST_LON, targetLon.toBits())
        .putString(KEY_LAST_CITY, resolvedCity)
        .apply()

      val forecastUrl = String.format(
        Locale.US,
        "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f" +
          "&current=temperature_2m,relative_humidity_2m,is_day,weather_code,wind_speed_10m" +
          "&hourly=temperature_2m,weather_code&daily=sunrise,sunset&timezone=auto&forecast_days=1",
        targetLat,
        targetLon
      )

      val request = Request.Builder().url(forecastUrl).get().build()
      val responseBody = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(IllegalStateException("تعذر الاتصال بخدمة الطقس (${resp.code})"))
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة الطقس"))

      val state = parseOpenMeteoResponse(responseBody, resolvedCity)
      Result.success(state)
    } catch (e: Exception) {
      Log.e(TAG, "Failed fetching live weather", e)
      Result.failure(e)
    }
  }

  private fun geocodeCity(cityName: String): Triple<Double, Double, String>? {
    return try {
      val encoded = URLEncoder.encode(cityName, "UTF-8")
      val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=ar&format=json"
      val req = Request.Builder().url(url).get().build()
      val body = httpClient.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) return null
        resp.body?.string()
      } ?: return null

      val json = JSONObject(body)
      val results = json.optJSONArray("results") ?: return null
      if (results.length() == 0) return null
      val first = results.getJSONObject(0)
      val lat = first.getDouble("latitude")
      val lon = first.getDouble("longitude")
      val name = first.optString("name", cityName)
      Triple(lat, lon, name)
    } catch (e: Exception) {
      Log.w(TAG, "Geocoding failed for $cityName", e)
      null
    }
  }

  @SuppressLint("MissingPermission")
  private fun getBestLastKnownLocation(context: Context): Location? {
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    if (!hasCoarse && !hasFine) return null

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val providers = buildList {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        add(LocationManager.FUSED_PROVIDER)
      }
      add(LocationManager.NETWORK_PROVIDER)
      add(LocationManager.GPS_PROVIDER)
      add(LocationManager.PASSIVE_PROVIDER)
    }

    var best: Location? = null
    for (provider in providers) {
      try {
        val loc = lm.getLastKnownLocation(provider) ?: continue
        if (best == null || loc.time > best.time) {
          best = loc
        }
      } catch (_: Exception) {
      }
    }
    return best
  }

  @Suppress("DEPRECATION")
  private fun reverseGeocodeCity(context: Context, lat: Double, lon: Double): String? {
    return try {
      if (!Geocoder.isPresent()) return null
      val geocoder = Geocoder(context, Locale("ar"))
      val list = geocoder.getFromLocation(lat, lon, 1) ?: return null
      val addr = list.firstOrNull() ?: return null
      addr.locality ?: addr.subAdminArea ?: addr.adminArea ?: addr.countryName
    } catch (_: Exception) {
      null
    }
  }

  internal fun parseOpenMeteoResponse(jsonStr: String, cityName: String): WeatherState {
    val root = JSONObject(jsonStr)
    val current = root.getJSONObject("current")
    val tempC = current.optDouble("temperature_2m", 0.0).roundToInt()
    val humidity = current.optDouble("relative_humidity_2m", 0.0).roundToInt()
    val windKmh = current.optDouble("wind_speed_10m", 0.0).roundToInt()
    val weatherCode = current.optInt("weather_code", 0)
    val isDay = current.optInt("is_day", 1) == 1

    val (conditionAr, isSeverityWarning) = mapWmoCodeToArabic(weatherCode, tempC)

    var sunriseText = "06:00"
    var sunsetText = "18:00"
    var solarProgress = if (isDay) 0.5f else 0.1f

    val daily = root.optJSONObject("daily")
    val sunriseIso = daily?.optJSONArray("sunrise")?.optString(0).orEmpty()
    val sunsetIso = daily?.optJSONArray("sunset")?.optString(0).orEmpty()
    if (sunriseIso.contains("T") && sunsetIso.contains("T")) {
      sunriseText = sunriseIso.substringAfter("T").take(5)
      sunsetText = sunsetIso.substringAfter("T").take(5)
      solarProgress = computeSolarProgress(sunriseIso, sunsetIso)
    }

    val hourlyItems = mutableListOf<HourlyWeatherItem>()
    val hourly = root.optJSONObject("hourly")
    if (hourly != null) {
      val times = hourly.optJSONArray("time")
      val temps = hourly.optJSONArray("temperature_2m")
      val codes = hourly.optJSONArray("weather_code")
      val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
      if (times != null && temps != null && codes != null) {
        val len = times.length()
        var startIdx = 0
        for (i in 0 until len) {
          val t = times.optString(i)
          val h = t.substringAfter("T", "").take(2).toIntOrNull()
          if (h != null && h >= currentHour) {
            startIdx = i
            break
          }
        }
        val endIdx = (startIdx + 6).coerceAtMost(len)
        for (i in startIdx until endIdx) {
          val hourStr = times.optString(i).substringAfter("T", "").take(5)
          val tC = temps.optDouble(i, 0.0).roundToInt()
          val wCode = codes.optInt(i, 0)
          hourlyItems.add(HourlyWeatherItem(hourLabel = hourStr, tempC = tC, weatherCode = wCode))
        }
      }
    }

    val dateStr = SimpleDateFormat("EEEE, d MMM", Locale("ar")).format(Date())

    return WeatherState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = isSeverityWarning,
      cityName = cityName.ifBlank { "الطقس الحالي" },
      temperatureC = tempC,
      conditionAr = conditionAr,
      weatherCode = weatherCode,
      isDay = isDay,
      windSpeedKmh = windKmh,
      humidityPct = humidity,
      sunriseText = sunriseText,
      sunsetText = sunsetText,
      sunriseProgress = solarProgress,
      dateLabel = dateStr,
      isWarning = isSeverityWarning,
      hourlyForecast = hourlyItems,
      errorMessage = null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  private fun computeSolarProgress(sunriseIso: String, sunsetIso: String): Float {
    return try {
      val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
      val riseMs = fmt.parse(sunriseIso)?.time ?: return 0.5f
      val setMs = fmt.parse(sunsetIso)?.time ?: return 0.5f
      val nowMs = System.currentTimeMillis()
      if (setMs <= riseMs) return 0.5f
      ((nowMs - riseMs).toFloat() / (setMs - riseMs).toFloat()).coerceIn(0f, 1f)
    } catch (_: Exception) {
      0.5f
    }
  }

  fun mapWmoCodeToArabic(code: Int, tempC: Int = 22): Pair<String, Boolean> {
    val label = when (code) {
      0 -> "سماء صافية"
      1 -> "صافي غالباً"
      2 -> "غائم جزئياً"
      3 -> "غائم كلياً"
      45, 48 -> "ضباب"
      51, 53, 55 -> "رذاذ خفيف"
      56, 57 -> "رذاذ متجمد"
      61, 63 -> "أمطار"
      65 -> "أمطار غزيرة"
      66, 67 -> "مطر متجمد"
      71, 73 -> "تساقط ثلوج"
      75, 77 -> "عاصفة ثلجية"
      80, 81, 82 -> "زخات مطرية"
      85, 86 -> "زخات ثلجية"
      95, 96, 99 -> "عاصفة رعدية"
      else -> "متقلب"
    }
    val warning = code >= 65 || code in listOf(45, 48) || tempC >= 44 || tempC <= 0
    return Pair(label, warning)
  }
}
