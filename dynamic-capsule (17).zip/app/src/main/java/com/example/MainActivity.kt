package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.ui.screens.CapsuleSplashOverlay
import com.example.ui.screens.MainSettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    IslandStateManager.initialize(applicationContext)
    val settingsManager = CapsuleSettingsManager.getInstance(applicationContext)

    setContent {
      MyApplicationTheme(darkTheme = true) {
        val settings by settingsManager.settings.collectAsState()
        var showSplash by rememberSaveable { mutableStateOf(true) }

        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
        ) {
          MainSettingsScreen(
            settingsManager = settingsManager,
            modifier = Modifier.fillMaxSize()
          )

          CapsuleSplashOverlay(
            visible = showSplash,
            accentColor = settings.accentColor,
            onFinished = { showSplash = false }
          )
        }
      }
    }
  }
}
