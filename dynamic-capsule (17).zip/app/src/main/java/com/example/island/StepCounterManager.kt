package com.example.island

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StepCounterManager(
  private val context: Context,
  private val onStepsUpdated: (StepsState, Boolean) -> Unit
) : SensorEventListener {

  private val appContext: Context = context.applicationContext ?: context
  private val prefs: SharedPreferences =
    appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  private val sensorManager: SensorManager? =
    appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
  private val stepSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

  private var isListening = false
  private var lastMilestoneAnnounced = 0
  private var lastStepEventTimeMs = 0L

  fun hasHardwareSensor(): Boolean = stepSensor != null

  fun hasActivityPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      ContextCompat.checkSelfPermission(
        appContext,
        Manifest.permission.ACTIVITY_RECOGNITION
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun startListening() {
    if (isListening || stepSensor == null || !hasActivityPermission()) {
      emitCurrentState(milestoneHit = false)
      return
    }
    try {
      sensorManager?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI)
      isListening = true
    } catch (e: Exception) {
      Log.e(TAG, "Failed to register TYPE_STEP_COUNTER listener", e)
    }
    emitCurrentState(milestoneHit = false)
  }

  fun stopListening() {
    if (isListening) {
      sensorManager?.unregisterListener(this)
      isListening = false
    }
  }

  fun currentState(): StepsState {
    val today = todayDateKey()
    ensureDateKey(today)

    val carried = prefs.getInt(KEY_CARRIED_STEPS, 0)
    val lastRaw = prefs.getFloat(KEY_LAST_RAW_STEPS, -1f)
    val baseline = prefs.getFloat(KEY_BASELINE_RAW_STEPS, -1f)
    val deltaSteps = if (lastRaw >= 0f && baseline >= 0f && lastRaw >= baseline) {
      (lastRaw - baseline).toInt()
    } else 0

    val todaySteps = (carried + deltaSteps).coerceAtLeast(0)
    val goal = prefs.getInt(KEY_DAILY_GOAL, DEFAULT_GOAL).coerceIn(1000, 50000)
    val activeSec = prefs.getInt(KEY_ACTIVE_SECONDS, 0).coerceAtLeast(0)
    val paused = prefs.getBoolean(KEY_IS_PAUSED, false)

    val distanceKm = (todaySteps * STRIDE_METERS) / 1000f
    val calories = (todaySteps * KCAL_PER_STEP).toInt()

    return StepsState(
      isActive = todaySteps > 0 || !paused,
      isAlertActive = false,
      steps = todaySteps,
      dailyGoal = goal,
      distanceKm = distanceKm,
      caloriesKcal = calories,
      activeSeconds = activeSec,
      isPaused = paused,
      hasHardwareSensor = hasHardwareSensor(),
      timestamp = System.currentTimeMillis()
    )
  }

  fun setPaused(paused: Boolean) {
    prefs.edit().putBoolean(KEY_IS_PAUSED, paused).apply()
    emitCurrentState(milestoneHit = false)
  }

  fun resetToday() {
    val today = todayDateKey()
    val lastRaw = prefs.getFloat(KEY_LAST_RAW_STEPS, -1f)
    prefs.edit()
      .putString(KEY_SAVED_DATE, today)
      .putInt(KEY_CARRIED_STEPS, 0)
      .putInt(KEY_ACTIVE_SECONDS, 0)
      .apply {
        if (lastRaw >= 0f) {
          putFloat(KEY_BASELINE_RAW_STEPS, lastRaw)
        } else {
          remove(KEY_BASELINE_RAW_STEPS)
        }
      }
      .apply()
    lastMilestoneAnnounced = 0
    emitCurrentState(milestoneHit = false)
  }

  fun cycleDailyGoal(): Int {
    val current = prefs.getInt(KEY_DAILY_GOAL, DEFAULT_GOAL)
    val goals = listOf(4000, 6000, 8000, 10000, 12000)
    val nextIdx = (goals.indexOf(current) + 1) % goals.size
    val nextGoal = goals[nextIdx]
    prefs.edit().putInt(KEY_DAILY_GOAL, nextGoal).apply()
    emitCurrentState(milestoneHit = false)
    return nextGoal
  }

  fun setDailyGoal(goal: Int) {
    prefs.edit().putInt(KEY_DAILY_GOAL, goal.coerceIn(1000, 50000)).apply()
    emitCurrentState(milestoneHit = false)
  }

  override fun onSensorChanged(event: SensorEvent?) {
    if (event?.sensor?.type != Sensor.TYPE_STEP_COUNTER) return
    val rawSteps = event.values.firstOrNull() ?: return
    processRawSensorReading(rawSteps, System.currentTimeMillis())
  }

  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

  internal fun processRawSensorReading(rawSteps: Float, nowMs: Long) {
    val today = todayDateKey(nowMs)
    val dateChanged = ensureDateKey(today)

    val paused = prefs.getBoolean(KEY_IS_PAUSED, false)
    var baseline = prefs.getFloat(KEY_BASELINE_RAW_STEPS, -1f)
    val lastRaw = prefs.getFloat(KEY_LAST_RAW_STEPS, -1f)
    var carried = if (dateChanged) 0 else prefs.getInt(KEY_CARRIED_STEPS, 0)
    var activeSec = if (dateChanged) 0 else prefs.getInt(KEY_ACTIVE_SECONDS, 0)

    if (baseline < 0f || dateChanged) {
      baseline = rawSteps
    } else if (lastRaw >= 0f && rawSteps < lastRaw) {
      // Device rebooted cleanly: bank previous session's steps before resetting baseline
      carried += (lastRaw - baseline).toInt().coerceAtLeast(0)
      baseline = 0f
    }

    val deltaSinceLast = if (lastRaw >= 0f && rawSteps > lastRaw) {
      (rawSteps - lastRaw).toInt()
    } else 0

    if (paused && deltaSinceLast > 0) {
      // Advance baseline so steps taken while paused are excluded
      baseline += deltaSinceLast
    } else if (!paused && deltaSinceLast > 0) {
      if (lastStepEventTimeMs > 0L && nowMs - lastStepEventTimeMs in 500L..12_000L) {
        activeSec += ((nowMs - lastStepEventTimeMs) / 1000L).toInt().coerceAtLeast(1)
      } else {
        activeSec += 1
      }
      lastStepEventTimeMs = nowMs
    }

    prefs.edit()
      .putString(KEY_SAVED_DATE, today)
      .putFloat(KEY_BASELINE_RAW_STEPS, baseline)
      .putFloat(KEY_LAST_RAW_STEPS, rawSteps)
      .putInt(KEY_CARRIED_STEPS, carried)
      .putInt(KEY_ACTIVE_SECONDS, activeSec)
      .apply()

    val st = currentState()
    val goal = st.dailyGoal
    val milestoneHit = when {
      st.steps >= goal && lastMilestoneAnnounced < goal -> {
        lastMilestoneAnnounced = goal
        true
      }
      st.steps >= 1000 && (st.steps / 1000) * 1000 > lastMilestoneAnnounced -> {
        lastMilestoneAnnounced = (st.steps / 1000) * 1000
        true
      }
      else -> false
    }

    emitCurrentState(milestoneHit = milestoneHit)
  }

  private fun emitCurrentState(milestoneHit: Boolean) {
    onStepsUpdated(currentState(), milestoneHit)
  }

  private fun ensureDateKey(today: String): Boolean {
    val saved = prefs.getString(KEY_SAVED_DATE, null)
    return if (saved != today) {
      prefs.edit()
        .putString(KEY_SAVED_DATE, today)
        .putInt(KEY_CARRIED_STEPS, 0)
        .putInt(KEY_ACTIVE_SECONDS, 0)
        .remove(KEY_BASELINE_RAW_STEPS)
        .apply()
      lastMilestoneAnnounced = 0
      true
    } else {
      false
    }
  }

  private fun todayDateKey(nowMs: Long = System.currentTimeMillis()): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(nowMs))

  companion object {
    private const val TAG = "StepCounterManager"
    private const val PREFS_NAME = "dynamic_capsule_steps_prefs"
    private const val KEY_SAVED_DATE = "saved_date"
    private const val KEY_CARRIED_STEPS = "carried_steps"
    private const val KEY_BASELINE_RAW_STEPS = "baseline_raw_steps"
    private const val KEY_LAST_RAW_STEPS = "last_raw_steps"
    private const val KEY_DAILY_GOAL = "daily_goal"
    private const val KEY_ACTIVE_SECONDS = "active_seconds"
    private const val KEY_IS_PAUSED = "is_paused"
    private const val DEFAULT_GOAL = 6000
    private const val STRIDE_METERS = 0.762f
    private const val KCAL_PER_STEP = 0.04f
  }
}
