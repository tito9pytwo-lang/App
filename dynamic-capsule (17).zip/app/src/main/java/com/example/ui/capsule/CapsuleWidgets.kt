package com.example.ui.capsule

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.island.BluetoothState
import com.example.island.CompassState
import com.example.island.FocusState
import com.example.island.HourlyWeatherItem
import com.example.island.StepsState
import com.example.island.WeatherState
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun weatherIconAndColor(weatherCode: Int, isDay: Boolean = true, isWarning: Boolean = false): Pair<ImageVector, Color> {
  if (isWarning) return Pair(Icons.Default.Warning, Color(0xFFFFB300))
  return when {
    weatherCode >= 95 -> Pair(Icons.Default.Thunderstorm, Color(0xFFFF9800))
    weatherCode in listOf(71, 73, 75, 77, 85, 86) -> Pair(Icons.Default.AcUnit, Color(0xFF81D4FA))
    weatherCode in listOf(51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82) -> Pair(Icons.Default.Grain, Color(0xFF4FC3F7))
    weatherCode in listOf(2, 3, 45, 48) -> Pair(Icons.Default.Cloud, Color(0xFFB0BEC5))
    !isDay -> Pair(Icons.Default.NightsStay, Color(0xFF90CAF9))
    else -> Pair(Icons.Default.WbSunny, Color(0xFFFFD54F))
  }
}

// =======================
// 1. BLUETOOTH MINI + EXPANDED
// =======================

@Composable
fun MiniBluetoothContent(
  bluetooth: BluetoothState,
  accentColor: Color
) {
  val btColor = when {
    bluetooth.batteryPct in 0..20 -> Color(0xFFFF453A)
    bluetooth.batteryPct in 21..100 -> RealmeGreen
    else -> Color(0xFF4285F4)
  }

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.20f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Headphones, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
      }
      MarqueeFadingText(
        text = bluetooth.deviceName,
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(10.dp))
        .background(btColor.copy(alpha = 0.18f))
        .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
      ) {
        if (bluetooth.batteryPct in 0..100) {
          Icon(Icons.Default.BatteryStd, contentDescription = null, tint = btColor, modifier = Modifier.size(13.dp))
          Text(
            text = "${bluetooth.batteryPct}%",
            color = btColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold
          )
        } else {
          Icon(Icons.Default.BluetoothConnected, contentDescription = null, tint = btColor, modifier = Modifier.size(13.dp))
          Text("متصل", color = btColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun ExpandedBluetoothView(
  bluetooth: BluetoothState,
  accentColor: Color,
  context: Context,
  onOpenSettings: () -> Unit
) {
  val hasBattery = bluetooth.batteryPct in 0..100
  val pctColor = when {
    !hasBattery -> Color(0xFF4285F4)
    bluetooth.batteryPct <= 20 -> Color(0xFFFF453A)
    bluetooth.batteryPct <= 50 -> Color(0xFFFFB74D)
    else -> RealmeGreen
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(pctColor.copy(alpha = 0.18f))
            .border(1.5.dp, pctColor.copy(alpha = 0.7f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Headphones, contentDescription = null, tint = pctColor, modifier = Modifier.size(25.dp))
        }
        Column {
          Text(
            text = if (bluetooth.isConnected) "جهاز بلوتوث متصل" else "سماعة بلوتوث",
            color = TextSecondary,
            fontSize = 11.sp
          )
          MarqueeFadingText(
            text = bluetooth.deviceName,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      if (hasBattery) {
        Text(
          text = "${bluetooth.batteryPct}%",
          color = pctColor,
          fontSize = 24.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    if (hasBattery) {
      LinearProgressIndicator(
        progress = { (bluetooth.batteryPct / 100f).coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(CircleShape),
        color = pctColor,
        trackColor = Color(0xFF222834)
      )
    } else {
      Text(
        text = "نسبة البطارية غير متوفرة من هذه السماعة أو نظام الهاتف حالياً.",
        color = TextMuted,
        fontSize = 11.sp
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.18f))
          .clickable {
            try {
              val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
              context.startActivity(intent)
            } catch (_: Exception) {}
            onOpenSettings()
          }
          .padding(horizontal = 14.dp, vertical = 7.dp)
      ) {
        Text("إعدادات البلوتوث", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }

      Text(
        text = if (hasBattery) "شحن السماعة المباشر" else "صوت لاسلكي",
        color = TextSecondary,
        fontSize = 11.sp
      )
    }
  }
}

// =======================
// 2. LIVE WEATHER MINI + EXPANDED (Inspired by Screenshot 1)
// =======================

@Composable
fun MiniWeatherContent(weatherState: WeatherState) {
  val (icon, tint) = weatherIconAndColor(
    weatherCode = weatherState.weatherCode,
    isDay = weatherState.isDay,
    isWarning = weatherState.isWarning
  )

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(tint.copy(alpha = if (weatherState.isWarning) 0.92f else 0.22f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = weatherState.conditionAr,
          tint = if (weatherState.isWarning) Color.Black else tint,
          modifier = Modifier.size(16.dp)
        )
      }

      val label = buildString {
        append(weatherState.conditionAr.ifBlank { "الطقس" })
        if (weatherState.cityName.isNotBlank()) {
          append(" • ")
          append(weatherState.cityName)
        }
      }
      MarqueeFadingText(
        text = label,
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Text(
      text = "${weatherState.temperatureC}°",
      color = tint,
      fontSize = 14.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedWeatherView(
  weatherState: WeatherState,
  onRefresh: () -> Unit
) {
  val (icon, iconColor) = weatherIconAndColor(
    weatherCode = weatherState.weatherCode,
    isDay = weatherState.isDay,
    isWarning = weatherState.isWarning
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_weather_view"),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    // Top location, date, wind/humidity & refresh button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
      ) {
        Icon(Icons.Default.LocationOn, contentDescription = null, tint = iconColor, modifier = Modifier.size(14.dp))
        Column {
          Text(
            text = weatherState.cityName.ifBlank { "الطقس المباشر" },
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          if (weatherState.dateLabel.isNotBlank()) {
            Text(weatherState.dateLabel, color = TextMuted, fontSize = 9.sp, maxLines = 1)
          }
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(horizontal = 7.dp, vertical = 3.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Icon(Icons.Default.WaterDrop, contentDescription = null, tint = Color(0xFF4FC3F7), modifier = Modifier.size(11.dp))
          Text("${weatherState.humidityPct}%", color = TextSecondary, fontSize = 10.sp)
          Icon(Icons.Default.Air, contentDescription = null, tint = Color(0xFF90CAF9), modifier = Modifier.size(11.dp))
          Text("${weatherState.windSpeedKmh}", color = TextSecondary, fontSize = 10.sp)
        }

        Box(
          modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onRefresh),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "تحديث الطقس",
            tint = iconColor,
            modifier = Modifier.size(15.dp)
          )
        }
      }
    }

    // Centerpiece Solar Horizon Arc + Sunrise/Sunset + Big Temperature
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(64.dp),
      contentAlignment = Alignment.Center
    ) {
      SolarArcCanvas(
        progress = weatherState.sunriseProgress,
        isDay = weatherState.isDay,
        modifier = Modifier
          .fillMaxWidth()
          .height(62.dp)
      )

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp)
          .align(Alignment.BottomCenter),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
      ) {
        Column(horizontalAlignment = Alignment.Start) {
          Text("الشروق", color = TextMuted, fontSize = 9.sp)
          Text(weatherState.sunriseText.ifBlank { "06:00" }, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(18.dp))
            Text(
              text = "${weatherState.temperatureC}°C",
              color = Color.White,
              fontSize = 22.sp,
              fontWeight = FontWeight.ExtraBold
            )
          }
          Text(
            text = weatherState.conditionAr,
            color = iconColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("الغروب", color = TextMuted, fontSize = 9.sp)
          Text(weatherState.sunsetText.ifBlank { "18:00" }, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Bottom Hourly Forecast Strip (high-contrast, full unclipped icons & temperatures)
    if (weatherState.hourlyForecast.isNotEmpty()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("weather_hourly_strip")
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF131824))
          .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
          .padding(horizontal = 10.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        weatherState.hourlyForecast.take(6).forEach { item ->
          HourlyForecastSlot(item)
        }
      }
    }
  }
}

@Composable
private fun HourlyForecastSlot(item: HourlyWeatherItem) {
  val hourNum = item.hourLabel.take(2).toIntOrNull() ?: 12
  val slotIsDay = hourNum in 6..18
  val (icon, tint) = weatherIconAndColor(item.weatherCode, isDay = slotIsDay)
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(3.dp)
  ) {
    Text(
      text = item.hourLabel,
      color = Color(0xFFB4BED2),
      fontSize = 10.sp,
      fontWeight = FontWeight.Medium,
      maxLines = 1
    )
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = tint,
      modifier = Modifier.size(16.dp)
    )
    Text(
      text = "${item.tempC}°",
      color = Color.White,
      fontSize = 11.sp,
      fontWeight = FontWeight.ExtraBold,
      maxLines = 1
    )
  }
}

@Composable
fun SolarArcCanvas(
  progress: Float,
  isDay: Boolean,
  modifier: Modifier = Modifier
) {
  val clamped = progress.coerceIn(0.05f, 0.95f)
  val animatedPos by animateFloatAsState(
    targetValue = clamped,
    animationSpec = tween(durationMillis = 700),
    label = "sun_arc_pos"
  )

  Canvas(modifier = modifier) {
    val startX = size.width * 0.12f
    val endX = size.width * 0.88f
    val baseY = size.height * 0.82f
    val peakY = size.height * 0.12f
    val midX = (startX + endX) / 2f

    val path = Path().apply {
      moveTo(startX, baseY)
      quadraticTo(midX, peakY - 18f, endX, baseY)
    }

    // Background arc
    drawPath(
      path = path,
      brush = Brush.horizontalGradient(
        colors = listOf(Color(0xFF3E351A), Color(0xFFFFD54F), Color(0xFF3E351A))
      ),
      style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
    )

    // Evaluate sun point along quadratic bezier curve
    val t = animatedPos
    val oneMinusT = 1f - t
    val ctrlY = peakY - 18f
    val sunX = (oneMinusT * oneMinusT * startX) + (2f * oneMinusT * t * midX) + (t * t * endX)
    val sunY = (oneMinusT * oneMinusT * baseY) + (2f * oneMinusT * t * ctrlY) + (t * t * baseY)

    val haloColor = if (isDay) Color(0xFFFFD54F) else Color(0xFF81D4FA)
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(haloColor.copy(alpha = 0.45f), Color.Transparent),
        center = Offset(sunX, sunY),
        radius = 18.dp.toPx()
      ),
      radius = 18.dp.toPx(),
      center = Offset(sunX, sunY)
    )
    drawCircle(
      color = haloColor,
      radius = 6.dp.toPx(),
      center = Offset(sunX, sunY)
    )
  }
}

// =======================
// 3. STEP COUNTER & DISTANCE MINI + EXPANDED (Inspired by Screenshot 2)
// =======================

@Composable
fun MiniStepsContent(stepsState: StepsState) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      WindingStepPathCanvas(
        progress = stepsState.goalFraction,
        color = RealmeGreen,
        strokeWidth = 2.6.dp,
        modifier = Modifier.size(width = 34.dp, height = 18.dp)
      )
      Text(
        text = "${stepsState.steps} خطوة",
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1
      )
    }

    Spacer(modifier = Modifier.width(6.dp))

    Text(
      text = String.format(Locale.US, "%.2f Km", stepsState.distanceKm),
      color = RealmeGreen,
      fontSize = 12.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedStepsView(
  stepsState: StepsState,
  onCycleGoal: () -> Unit,
  onTogglePause: () -> Unit,
  onResetToday: () -> Unit
) {
  val quartersEarned = (stepsState.goalFraction * 4f).toInt().coerceIn(0, 4)

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_steps_view"),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Top Header: Title + 4 Milestone Badges (Screenshot 2 inspired)
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(16.dp))
        Text("عداد الخطوات اليومي", color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
      }

      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (i in 1..4) {
          val unlocked = i <= quartersEarned
          Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = if (unlocked) RealmeGreen else Color(0xFF333B4A),
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }

    // Hero 3-column metrics + glowing winding S-path center graphic
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Steps + Duration
      Column(
        modifier = Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.Default.Timer, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
        Text(
          text = "${stepsState.steps}",
          color = Color.White,
          fontSize = 18.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (stepsState.activeSeconds > 0) stepsState.formatActiveDuration() else "الخطوات",
          color = TextMuted,
          fontSize = 10.sp
        )
      }

      // Center: Neon green winding step progress path
      WindingStepPathCanvas(
        progress = stepsState.goalFraction,
        color = RealmeGreen,
        strokeWidth = 5.5.dp,
        modifier = Modifier.size(width = 96.dp, height = 46.dp)
      )

      // Right: Distance + Daily Goal
      Column(
        modifier = Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
        Text(
          text = String.format(Locale.US, "%.2f Km", stepsState.distanceKm),
          color = Color.White,
          fontSize = 15.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = "الهدف ${stepsState.dailyGoal}",
          color = TextMuted,
          fontSize = 10.sp
        )
      }
    }

    if (!stepsState.hasHardwareSensor) {
      Text(
        text = "لا يتوفر مستشعر خطوات مدمج في هذا الجهاز",
        color = Color(0xFFFFB74D),
        fontSize = 10.sp
      )
    }

    // Bottom Controls: Change Goal, Primary Green Pill Reset/Status, Pause/Resume
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(Color(0xFF1F242E))
          .clickable(onClick = onCycleGoal),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Flag, contentDescription = "تغيير الهدف", tint = TextPrimary, modifier = Modifier.size(16.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Box(
        modifier = Modifier
          .clip(CircleShape)
          .background(RealmeGreen)
          .clickable(onClick = onResetToday)
          .padding(horizontal = 24.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "تصفير اليوم",
          color = Color.Black,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(Color(0xFF1F242E))
          .clickable(onClick = onTogglePause),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (stepsState.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
          contentDescription = if (stepsState.isPaused) "استئناف العد" else "إيقاف مؤقت",
          tint = TextPrimary,
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

@Composable
fun WindingStepPathCanvas(
  progress: Float,
  color: Color,
  strokeWidth: Dp,
  modifier: Modifier = Modifier
) {
  val animFrac by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 550),
    label = "step_path_progress"
  )

  Canvas(modifier = modifier) {
    val pad = strokeWidth.toPx() * 1.4f
    val w = (size.width - pad * 2).coerceAtLeast(10f)
    val h = (size.height - pad * 2).coerceAtLeast(8f)
    val left = pad
    val top = pad
    val bottom = pad + h

    val fullPath = Path().apply {
      moveTo(left, bottom)
      lineTo(left, top + h * 0.25f)
      cubicTo(left, top, left + w * 0.33f, top, left + w * 0.33f, top + h * 0.35f)
      lineTo(left + w * 0.33f, bottom - h * 0.2f)
      cubicTo(left + w * 0.33f, bottom, left + w * 0.67f, bottom, left + w * 0.67f, bottom - h * 0.35f)
      lineTo(left + w * 0.67f, top + h * 0.25f)
      cubicTo(left + w * 0.67f, top, left + w, top, left + w, top + h * 0.4f)
      lineTo(left + w, bottom)
    }

    // Track path
    drawPath(
      path = fullPath,
      color = Color(0xFF282E3A),
      style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Progress sub-path via PathMeasure
    val measure = PathMeasure()
    measure.setPath(fullPath, false)
    val activePath = Path()
    val stopDist = measure.length * animFrac.coerceAtLeast(0.06f)
    measure.getSegment(0f, stopDist, activePath, true)

    drawPath(
      path = activePath,
      color = color,
      style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Start & end node dots
    val nodeR = (strokeWidth.toPx() * 0.85f).coerceAtLeast(2.5f)
    drawCircle(color = color, radius = nodeR, center = Offset(left, bottom))
    drawCircle(
      color = if (animFrac >= 0.99f) color else Color(0xFF3E4759),
      radius = nodeR,
      center = Offset(left + w, bottom)
    )
  }
}

// =======================
// 4. EXTRA REAL FEATURES: COMPASS + POMODORO FOCUS
// =======================

@Composable
fun MiniCompassContent(compass: CompassState, accentColor: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Explore, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
      }
      Text("البوصلة: ${compass.directionAr}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }

    Text(
      text = "${compass.azimuthDeg.toInt()}°",
      color = accentColor,
      fontSize = 13.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedCompassView(
  compass: CompassState,
  accentColor: Color,
  onStopCompass: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Canvas(modifier = Modifier.size(62.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f - 4f
        drawCircle(
          color = Color(0xFF1E2532),
          radius = radius,
          style = Stroke(width = 3.dp.toPx())
        )
        val angleRad = Math.toRadians((-compass.azimuthDeg).toDouble() - 90.0)
        val tipX = center.x + (cos(angleRad) * (radius - 6f)).toFloat()
        val tipY = center.y + (sin(angleRad) * (radius - 6f)).toFloat()
        val oppX = center.x - (cos(angleRad) * (radius * 0.45f)).toFloat()
        val oppY = center.y - (sin(angleRad) * (radius * 0.45f)).toFloat()

        drawLine(color = Color(0xFFFF453A), start = center, end = Offset(tipX, tipY), strokeWidth = 3.5.dp.toPx(), cap = StrokeCap.Round)
        drawLine(color = TextSecondary, start = center, end = Offset(oppX, oppY), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = center)
      }

      Column {
        Text(
          text = if (compass.hasSensor) "${compass.azimuthDeg.toInt()}° ${compass.directionAr}" else "غير مدعوم",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (compass.hasSensor) "مستشعر المغناطيسية الحقيقي" else "لا يتوفر مستشعر بوصلة",
          color = TextSecondary,
          fontSize = 11.sp
        )
      }
    }

    Box(
      modifier = Modifier
        .clip(CircleShape)
        .background(Color(0xFF2C2F38))
        .clickable(onClick = onStopCompass)
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      Text("إغلاق", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
fun MiniFocusContent(focus: FocusState) {
  val color = if (focus.isBreak) Color(0xFF00E5FF) else Color(0xFFFF6E6E)
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
      }
      Text(
        text = if (focus.isBreak) "استراحة تركيز" else "جلسة تركيز",
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }
    Text(
      text = focus.formatRemaining(),
      color = color,
      fontSize = 13.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedFocusView(
  focus: FocusState,
  onTogglePause: () -> Unit,
  onStartFocus: (Int, Boolean) -> Unit,
  onCancel: () -> Unit
) {
  val color = if (focus.isBreak) Color(0xFF00E5FF) else Color(0xFFFF6E6E)
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
        }
        Column {
          Text(
            text = when {
              !focus.isActive -> "مؤقت التركيز (Pomodoro)"
              focus.isBreak -> "وقت الاستراحة"
              else -> "جلسة التركيز العميق"
            },
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = if (focus.isActive) "ركّز على مهامك بدون تشتيت" else "ابدأ جلسة 25 دقيقة أو استراحة",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
      }

      if (focus.isActive) {
        Text(
          text = focus.formatRemaining(),
          color = color,
          fontSize = 22.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    if (focus.isActive) {
      val frac = if (focus.totalSeconds > 0) (focus.remainingSeconds.toFloat() / focus.totalSeconds).coerceIn(0f, 1f) else 0f
      LinearProgressIndicator(
        progress = { frac },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
        color = color,
        trackColor = Color(0xFF222834)
      )
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onTogglePause)
            .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
          Text(if (focus.isRunning) "إيقاف مؤقت" else "استئناف", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFF2C2F38))
            .clickable(onClick = onCancel)
            .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
          Text("إنهاء", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    } else {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple(25, false, "25د تركيز"), Triple(50, false, "50د عميق"), Triple(5, true, "5د راحة")).forEach { (m, brk, lbl) ->
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF1F242E))
              .clickable { onStartFocus(m, brk) }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(lbl, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
