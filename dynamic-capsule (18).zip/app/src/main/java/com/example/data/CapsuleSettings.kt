package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber

data class CapsuleSettings(
  val serviceEnabled: Boolean = true,
  val notchOffsetYDp: Int = 0, // Extra offset below status bar
  val capsuleWidthDp: Int = 220, // Medium size, easy to see and touch
  val capsuleHeightDp: Int = 46, // Medium height, comfortable touch target
  val accentColorIndex: Int = 0,
  val autoCollapseSeconds: Int = 0,
  val showWhenIdle: Boolean = false, // Hidden when idle so no window is visible without activity
  val hapticFeedback: Boolean = true,
  // Feature toggles
  val enableBatteryAlerts: Boolean = true,
  val enableCallAlerts: Boolean = true,
  val enableTimer: Boolean = true,
  val enableNotifications: Boolean = true,
  val enableBluetoothAlerts: Boolean = true,
  val enableFlashlightAlert: Boolean = true,
  val enableRingerAlerts: Boolean = true,
  val enableDownloadProgress: Boolean = true,
  val enableNavigationAlerts: Boolean = true,
  val enablePrivacyAlerts: Boolean = true,
  val enableDualCapsule: Boolean = true,
  val enableDynamicAlbumColors: Boolean = true,
  val capsuleStyleIndex: Int = 0, // 0 = Glow, 1 = Neon Gradient, 2 = Minimal
  val openAnimationIndex: Int = 0, // 0 = Elastic Spring, 1 = Liquid Pop, 2 = Drop Slide, 3 = 3D Flip Zoom, 4 = Snappy Crisp
  val auraAnimationIndex: Int = 0, // 0 = Static, 1 = Spinning RGB Aura, 2 = Breathing Pulse, 3 = Dual Laser Sweep, 4 = Reactive EQ Halo
  val visualizerStyleIndex: Int = 0, // 0 = Classic Bars, 1 = Smooth Sine Wave, 2 = Sonic Pulse Dots, 3 = Mirror EQ
  val hideInLandscape: Boolean = true,
  val enableNetworkAlerts: Boolean = true,
  val enableVolumeAlerts: Boolean = true,
  val enableAlarmSync: Boolean = true,
  val enableStepsCounter: Boolean = true,
  val pinStepsInCapsule: Boolean = false,
  val enableWeatherAlerts: Boolean = true,
  val pinWeatherInCapsule: Boolean = false,
  val weatherCityQuery: String = "",
  val enableCompass: Boolean = true,
  val enableFocusTimer: Boolean = true,
  val appThemeIndex: Int = 0, // 0 = Classic Dark, 1 = iPhone Liquid Glass, 2 = iPhone Light Frost, 3 = Cyber Neon
  val excludedPackages: Set<String> = emptySet()
) {
  val accentColor: Color
    get() = when (accentColorIndex) {
      0 -> RealmeGreen
      1 -> CyberCyan
      2 -> ElectricPurple
      3 -> SunsetAmber
      4 -> Color(0xFFFFFFFF)
      5 -> Color(0xFF0A84FF) // iOS Apple Blue
      else -> RealmeGreen
    }

  val isLiquidGlassCapsule: Boolean
    get() = appThemeIndex == 1 || appThemeIndex == 2 || capsuleStyleIndex == 3
}
