package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppTheme
import com.example.ui.theme.AppThemeBackdrop
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import kotlinx.coroutines.delay

@Composable
fun CapsuleSplashOverlay(
  visible: Boolean,
  accentColor: Color,
  onFinished: () -> Unit
) {
  var phase by remember { mutableIntStateOf(0) }
  val palette = AppTheme.colors

  LaunchedEffect(visible) {
    if (visible) {
      phase = 0
      delay(90)
      phase = 1 // Expand from punch-hole dot to capsule pill
      delay(340)
      phase = 2 // Reveal icons, title & developer credit
      delay(1500)
      onFinished()
    }
  }

  AnimatedVisibility(
    visible = visible,
    enter = fadeIn(tween(120)),
    exit = fadeOut(tween(340)) + scaleOut(targetScale = 1.04f, animationSpec = tween(340))
  ) {
    val capsuleWidth by animateDpAsState(
      targetValue = if (phase >= 1) 264.dp else 28.dp,
      animationSpec = spring(dampingRatio = 0.56f, stiffness = Spring.StiffnessMediumLow),
      label = "splash_capsule_w"
    )
    val capsuleHeight by animateDpAsState(
      targetValue = if (phase >= 1) 58.dp else 28.dp,
      animationSpec = spring(dampingRatio = 0.58f, stiffness = Spring.StiffnessMediumLow),
      label = "splash_capsule_h"
    )
    val contentAlpha by animateFloatAsState(
      targetValue = if (phase >= 2) 1f else 0f,
      animationSpec = tween(380, easing = FastOutSlowInEasing),
      label = "splash_content_alpha"
    )
    val titleOffsetY by animateFloatAsState(
      targetValue = if (phase >= 2) 0f else 26f,
      animationSpec = spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessLow),
      label = "splash_title_y"
    )
    val devOffsetY by animateFloatAsState(
      targetValue = if (phase >= 2) 0f else 18f,
      animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow),
      label = "splash_dev_y"
    )

    val infinite = rememberInfiniteTransition(label = "splash_eq")
    val eqPulse by infinite.animateFloat(
      initialValue = 0.35f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(420), RepeatMode.Reverse),
      label = "splash_eq_pulse"
    )
    val auraSweep by infinite.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Restart),
      label = "splash_aura_sweep"
    )

    val titleShimmer = remember { Animatable(0f) }
    LaunchedEffect(phase) {
      if (phase >= 2) {
        titleShimmer.animateTo(1f, animationSpec = tween(700, easing = FastOutSlowInEasing))
      }
    }

    AppThemeBackdrop(
      palette = palette,
      accentColor = accentColor,
      modifier = Modifier
        .fillMaxSize()
        .testTag("capsule_splash_overlay")
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onFinished
        )
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .navigationBarsPadding(),
        contentAlignment = Alignment.Center
      ) {
        // Ambient center glow behind the morphing capsule
        Canvas(modifier = Modifier.fillMaxSize()) {
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(
                palette.splashGlowA,
                palette.splashGlowB,
                Color.Transparent
              ),
              center = Offset(size.width / 2f, size.height * 0.44f),
              radius = size.minDimension * 0.55f
            ),
            radius = size.minDimension * 0.55f,
            center = Offset(size.width / 2f, size.height * 0.44f)
          )
        }

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier.padding(24.dp)
        ) {
          // Expanding Dynamic Capsule Hero
          val capsuleBg = if (palette.isGlass) Color(0xD90A101C) else Color(0xFF06070A)
          val capsuleBorderBrush = if (palette.isGlass) {
            Brush.linearGradient(
              colors = listOf(
                Color.White.copy(alpha = 0.72f),
                CyberCyan.copy(alpha = 0.65f),
                accentColor,
                Color.White.copy(alpha = 0.55f)
              ),
              start = Offset(auraSweep * 320f - 120f, 0f),
              end = Offset(auraSweep * 320f + 180f, 120f)
            )
          } else {
            Brush.linearGradient(
              colors = listOf(accentColor, CyberCyan, ElectricPurple, accentColor),
              start = Offset(auraSweep * 320f - 120f, 0f),
              end = Offset(auraSweep * 320f + 180f, 120f)
            )
          }

          Box(
            modifier = Modifier
              .width(capsuleWidth)
              .height(capsuleHeight)
              .shadow(
                elevation = 24.dp,
                shape = RoundedCornerShape(30.dp),
                spotColor = accentColor.copy(alpha = 0.7f)
              )
              .clip(RoundedCornerShape(30.dp))
              .background(capsuleBg)
              .then(
                if (palette.isGlass) {
                  Modifier.background(
                    Brush.verticalGradient(
                      colors = listOf(Color.White.copy(alpha = 0.16f), Color.Transparent)
                    )
                  )
                } else Modifier
              )
              .border(
                width = 1.6.dp,
                brush = capsuleBorderBrush,
                shape = RoundedCornerShape(30.dp)
              )
              .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
          ) {
            if (phase < 1) {
              Box(
                modifier = Modifier
                  .size(10.dp)
                  .clip(CircleShape)
                  .background(accentColor)
              )
            } else {
              Row(
                modifier = Modifier
                  .fillMaxSize()
                  .alpha(contentAlpha),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(30.dp)
                      .clip(CircleShape)
                      .background(accentColor.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
                  }
                  Icon(Icons.Default.WbSunny, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(15.dp))
                  Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
                  Icon(Icons.Default.Headphones, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(15.dp))
                }

                // Animated equaliser bars inside capsule
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                  val multipliers = listOf(0.55f, 1f, 0.7f, 0.9f)
                  multipliers.forEachIndexed { idx, m ->
                    val barH = (8f + 12f * m * if (idx % 2 == 0) eqPulse else (1.35f - eqPulse)).coerceIn(6f, 20f)
                    Box(
                      modifier = Modifier
                        .width(3.dp)
                        .height(barH.dp)
                        .clip(CircleShape)
                        .background(if (idx % 2 == 0) accentColor else CyberCyan)
                    )
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(24.dp))

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
              .alpha(contentAlpha)
              .graphicsLayer { translationY = titleOffsetY }
          ) {
            Text(
              text = "Dynamic Capsule",
              color = palette.textPrimary,
              fontSize = 26.sp,
              fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "الكبسولة الذكية المتفاعلة",
              color = accentColor,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "موسيقى • طقس مباشر • خطوات • بلوتوث • مكالمات",
              color = palette.textSecondary,
              fontSize = 11.sp
            )
          }

          Spacer(modifier = Modifier.height(26.dp))

          // Developer attribution directly under the opening animation
          Row(
            modifier = Modifier
              .testTag("splash_developer_badge")
              .alpha(contentAlpha)
              .graphicsLayer { translationY = devOffsetY }
              .clip(CircleShape)
              .background(
                if (palette.isGlass) palette.surface else palette.surfaceElevated.copy(alpha = 0.85f)
              )
              .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                  colors = listOf(
                    if (palette.isGlass) palette.specularTopLeft else accentColor.copy(alpha = 0.55f),
                    accentColor.copy(alpha = 0.35f)
                  )
                ),
                shape = CircleShape
              )
              .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(15.dp)
            )
            Text(
              text = "مطور التطبيق: مصطفى",
              color = palette.textPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}
