package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AppThemeOption(
  val index: Int,
  val titleAr: String,
  val subtitleAr: String,
  val badgeAr: String,
  val previewBg: Color,
  val previewCard: Color,
  val previewAccent: Color
) {
  CLASSIC_DARK(
    index = 0,
    titleAr = "الكلاسيكي الداكن",
    subtitleAr = "المظهر العادي المألوف بتباين مريح",
    badgeAr = "افتراضي",
    previewBg = Color(0xFF090B10),
    previewCard = Color(0xFF121620),
    previewAccent = RealmeGreen
  ),
  IPHONE_LIQUID_GLASS(
    index = 1,
    titleAr = "زجاج آيفون",
    subtitleAr = "زجاج iOS الشفاف مع انعكاس ضوئي حقيقي",
    badgeAr = "iOS Glass",
    previewBg = Color(0xFF060D1F),
    previewCard = Color(0x99253554),
    previewAccent = Color(0xFF5AC8FA)
  ),
  IPHONE_LIGHT_FROST(
    index = 2,
    titleAr = "زجاج آيفون النهاري",
    subtitleAr = "بلور ثلجي مشرق بأسلوب آيفون الفاتح",
    badgeAr = "Light Glass",
    previewBg = Color(0xFFE7F0FF),
    previewCard = Color(0xCCFFFFFF),
    previewAccent = Color(0xFF007AFF)
  ),
  CYBER_NEON(
    index = 3,
    titleAr = "نيون سايبربانك",
    subtitleAr = "إضاءات نيون عميقة وتباين مستقبلي",
    badgeAr = "Neon",
    previewBg = Color(0xFF060514),
    previewCard = Color(0xB814102E),
    previewAccent = Color(0xFF00E5FF)
  );

  companion object {
    fun fromIndex(index: Int): AppThemeOption =
      entries.firstOrNull { it.index == index } ?: CLASSIC_DARK
  }
}

data class AppThemePalette(
  val option: AppThemeOption,
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val border: Color,
  val specularTopLeft: Color,
  val specularBottomRight: Color,
  val glossHighlight: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textMuted: Color,
  val navBarContainer: Color,
  val splashGlowA: Color,
  val splashGlowB: Color,
  val dividerColor: Color,
  val sliderInactiveTrack: Color
) {
  val isGlass: Boolean
    get() = option == AppThemeOption.IPHONE_LIQUID_GLASS ||
      option == AppThemeOption.IPHONE_LIGHT_FROST ||
      option == AppThemeOption.CYBER_NEON

  val isLight: Boolean
    get() = option == AppThemeOption.IPHONE_LIGHT_FROST
}

val ClassicDarkPalette = AppThemePalette(
  option = AppThemeOption.CLASSIC_DARK,
  background = DarkBackground,
  surface = DarkSurface,
  surfaceElevated = DarkSurfaceCard,
  border = DarkSurfaceBorder,
  specularTopLeft = DarkSurfaceBorder,
  specularBottomRight = DarkSurfaceBorder,
  glossHighlight = Color.Transparent,
  textPrimary = TextPrimary,
  textSecondary = TextSecondary,
  textMuted = TextMuted,
  navBarContainer = DarkSurface,
  splashGlowA = RealmeGreen.copy(alpha = 0.18f),
  splashGlowB = CyberCyan.copy(alpha = 0.08f),
  dividerColor = DarkSurfaceBorder,
  sliderInactiveTrack = Color(0xFF262E3E)
)

val IphoneLiquidGlassPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIQUID_GLASS,
  background = Color(0xFF050914),
  surface = Color(0x8E19243A), // Translucent smoked glass letting wallpaper glow through
  surfaceElevated = Color(0x78263554),
  border = Color(0x52FFFFFF),
  specularTopLeft = Color(0x99FFFFFF), // Bright iOS glass top-left refraction highlight
  specularBottomRight = Color(0x555AC8FA), // Cool ice-cyan refraction on bottom-right edge
  glossHighlight = Color(0x28FFFFFF),
  textPrimary = Color(0xFFF7FAFF),
  textSecondary = Color(0xFFC7D7F2),
  textMuted = Color(0xFF8CA3C7),
  navBarContainer = Color(0xB8141E32),
  splashGlowA = Color(0xFF0A84FF).copy(alpha = 0.28f),
  splashGlowB = Color(0xFF5AC8FA).copy(alpha = 0.20f),
  dividerColor = Color(0x29FFFFFF),
  sliderInactiveTrack = Color(0x40FFFFFF)
)

val IphoneLightFrostPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIGHT_FROST,
  background = Color(0xFFEAF2FF),
  surface = Color(0xB8FFFFFF), // High-frost luminous white glass
  surfaceElevated = Color(0x9CEAF1FF),
  border = Color(0x99FFFFFF),
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = Color(0x66007AFF),
  glossHighlight = Color(0x55FFFFFF),
  textPrimary = Color(0xFF0B1324),
  textSecondary = Color(0xFF3E4C66),
  textMuted = Color(0xFF6A7996),
  navBarContainer = Color(0xD6FFFFFF),
  splashGlowA = Color(0xFF007AFF).copy(alpha = 0.20f),
  splashGlowB = Color(0xFF5AC8FA).copy(alpha = 0.22f),
  dividerColor = Color(0x240F172A),
  sliderInactiveTrack = Color(0x33007AFF)
)

val CyberNeonPalette = AppThemePalette(
  option = AppThemeOption.CYBER_NEON,
  background = Color(0xFF050512),
  surface = Color(0xBA110E28),
  surfaceElevated = Color(0xAD1C1642),
  border = Color(0x5900E5FF),
  specularTopLeft = Color(0xAA00E5FF),
  specularBottomRight = Color(0x88D500F9),
  glossHighlight = Color(0x1C00E5FF),
  textPrimary = Color(0xFFF3F8FF),
  textSecondary = Color(0xFFB4C5EC),
  textMuted = Color(0xFF7B8AB8),
  navBarContainer = Color(0xCC0D0A22),
  splashGlowA = Color(0xFF00E5FF).copy(alpha = 0.24f),
  splashGlowB = Color(0xFFD500F9).copy(alpha = 0.20f),
  dividerColor = Color(0x3300E5FF),
  sliderInactiveTrack = Color(0xFF282052)
)

fun paletteForThemeIndex(index: Int): AppThemePalette = when (index) {
  1 -> IphoneLiquidGlassPalette
  2 -> IphoneLightFrostPalette
  3 -> CyberNeonPalette
  else -> ClassicDarkPalette
}

val LocalAppThemePalette = compositionLocalOf { ClassicDarkPalette }

object AppTheme {
  val colors: AppThemePalette
    @Composable
    get() = LocalAppThemePalette.current
}

/**
 * Animated ambient wallpaper behind translucent glass cards so iPhone Liquid Glass & Cyber Neon
 * show genuine optical depth and color refraction.
 */
@Composable
fun AppThemeBackdrop(
  palette: AppThemePalette,
  accentColor: Color,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  val bgColor by animateColorAsState(palette.background, tween(350), label = "theme_bg")

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
  ) {
    if (palette.isGlass) {
      val infinite = rememberInfiniteTransition(label = "glass_wallpaper")
      val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000), RepeatMode.Restart),
        label = "wallpaper_drift"
      )

      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val angle = (drift * 2f * PI).toFloat()

        when (palette.option) {
          AppThemeOption.IPHONE_LIQUID_GLASS -> {
            // Deep midnight iOS 26 sapphire gradient base
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(
                  Color(0xFF060C1B),
                  Color(0xFF091329),
                  Color(0xFF040710)
                )
              )
            )
            // Orb 1: Apple Blue
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF0A84FF).copy(alpha = 0.42f), Color.Transparent),
                center = Offset(w * (0.22f + 0.08f * cos(angle)), h * (0.18f + 0.04f * sin(angle))),
                radius = w * 0.72f
              ),
              center = Offset(w * (0.22f + 0.08f * cos(angle)), h * (0.18f + 0.04f * sin(angle))),
              radius = w * 0.72f
            )
            // Orb 2: Glacial Cyan
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF5AC8FA).copy(alpha = 0.30f), Color.Transparent),
                center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.46f + 0.06f * cos(angle))),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.46f + 0.06f * cos(angle))),
              radius = w * 0.65f
            )
            // Orb 3: iOS Iris Violet + subtle user accent blend
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFFBF5AF2).copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.82f - 0.04f * cos(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.82f - 0.04f * cos(angle))),
              radius = w * 0.68f
            )
          }

          AppThemeOption.IPHONE_LIGHT_FROST -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(
                  Color(0xFFF3F7FF),
                  Color(0xFFE3ECFF),
                  Color(0xFFF0EBFF)
                )
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF64D2FF).copy(alpha = 0.42f), Color.Transparent),
                center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
              radius = w * 0.68f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF007AFF).copy(alpha = 0.24f), Color.Transparent),
                center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
                radius = w * 0.62f
              ),
              center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
              radius = w * 0.62f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFFAF52DE).copy(alpha = 0.20f), Color.Transparent),
                center = Offset(w * (0.30f + 0.05f * sin(angle)), h * 0.85f),
                radius = w * 0.64f
              ),
              center = Offset(w * (0.30f + 0.05f * sin(angle)), h * 0.85f),
              radius = w * 0.64f
            )
          }

          AppThemeOption.CYBER_NEON -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF040410), Color(0xFF090720), Color(0xFF04040C))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.28f), Color.Transparent),
                center = Offset(w * (0.18f + 0.08f * cos(angle)), h * 0.20f),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.18f + 0.08f * cos(angle)), h * 0.20f),
              radius = w * 0.65f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFFD500F9).copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
                radius = w * 0.70f
              ),
              center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
              radius = w * 0.70f
            )
          }

          else -> {
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(accentColor.copy(alpha = 0.06f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.15f),
                radius = w * 0.6f
              ),
              center = Offset(w * 0.5f, h * 0.15f),
              radius = w * 0.6f
            )
          }
        }
      }
    }

    content()
  }
}

/**
 * Drop-in Card wrapper that behaves as a crisp M3 Card in Classic Dark
 * and transforms into an authentic iPhone Liquid Glass card (translucent fill + specular top
 * gloss + diagonal light-refracting rim) when a glass theme is selected.
 */
@Composable
fun ThemedCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 22.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  val palette = AppTheme.colors
  val shape: Shape = RoundedCornerShape(cornerRadius)

  if (!palette.isGlass) {
    Card(
      modifier = modifier.fillMaxWidth(),
      colors = CardDefaults.cardColors(containerColor = palette.surface),
      shape = shape,
      border = BorderStroke(1.dp, palette.border),
      content = content
    )
  } else {
    val rimBrush = Brush.linearGradient(
      colors = listOf(
        palette.specularTopLeft,
        palette.border.copy(alpha = 0.24f),
        palette.specularBottomRight
      )
    )
    val glassSheen = Brush.verticalGradient(
      colors = listOf(
        palette.glossHighlight,
        Color.Transparent,
        palette.glossHighlight.copy(alpha = 0.08f)
      )
    )
    Box(
      modifier = modifier
        .fillMaxWidth()
        .shadow(
          elevation = if (palette.isLight) 12.dp else 18.dp,
          shape = shape,
          spotColor = if (palette.isLight) Color(0x33007AFF) else Color(0x440A84FF),
          ambientColor = if (palette.isLight) Color(0x22000000) else Color(0x44000000)
        )
        .clip(shape)
        .background(palette.surface)
        .background(glassSheen)
        .border(width = 1.15.dp, brush = rimBrush, shape = shape)
    ) {
      Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
  }
}
