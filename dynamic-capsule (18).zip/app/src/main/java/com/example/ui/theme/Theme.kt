package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.CompositionLocalProvider

private val DarkColorScheme =
  darkColorScheme(
    primary = RealmeGreen,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00381B),
    onPrimaryContainer = RealmeGreen,
    secondary = CyberCyan,
    onSecondary = Color.Black,
    tertiary = ElectricPurple,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Color(0xFF007AFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E8FF),
    onPrimaryContainer = Color(0xFF001C3B),
    secondary = Color(0xFF5AC8FA),
    onSecondary = Color.Black,
    tertiary = Color(0xFFAF52DE),
    background = Color(0xFFEAF2FF),
    onBackground = Color(0xFF0B1324),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B1324),
    surfaceVariant = Color(0xFFDCE7FA),
    onSurfaceVariant = Color(0xFF3E4C66),
    outline = Color(0xFFB8C9E8)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  appThemeIndex: Int = 0,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val palette = paletteForThemeIndex(appThemeIndex)
  val useDark = darkTheme && !palette.isLight
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      useDark -> DarkColorScheme.copy(
        background = palette.background,
        surface = palette.surface,
        surfaceVariant = palette.surfaceElevated,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.border
      )
      else -> LightColorScheme
    }

  CompositionLocalProvider(LocalAppThemePalette provides palette) {
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
  }
}
