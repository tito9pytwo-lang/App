package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AppThemeOption(
  val index: Int,
  val titleAr: String,
  val subtitleAr: String,
  val badgeAr: String,
  val previewBg: Color,
  val previewCard: Color,
  val previewAccent: Color
) {
  CLASSIC_DARK(
    index = 0,
    titleAr = "أوبسيديان الكهرماني",
    subtitleAr = "فحمي دافئ مع ذهب كهرماني ولمسات زمردية راقية",
    badgeAr = "Obsidian Gold",
    previewBg = ObsidianBackground,
    previewCard = ObsidianCardBackground,
    previewAccent = ObsidianPrimary
  ),
  IPHONE_LIQUID_GLASS(
    index = 1,
    titleAr = "زجاج تيتانيوم",
    subtitleAr = "زجاج iOS مدخّن بانعكاس ذهبي وزمرّدي فاخر",
    badgeAr = "Titanium Glass",
    previewBg = Color(0xFF100E0B),
    previewCard = Color(0x9E211C16),
    previewAccent = ObsidianPrimary
  ),
  IPHONE_LIGHT_FROST(
    index = 2,
    titleAr = "زجاج الكريستال النهاري",
    subtitleAr = "بلور رملي دافئ بإضاءة كهرمانية وزمرّدية",
    badgeAr = "Warm Frost",
    previewBg = Color(0xFFF3ECE0),
    previewCard = Color(0xCCFFFDF8),
    previewAccent = SandstoneLightPrimary
  ),
  CYBER_NEON(
    index = 3,
    titleAr = "زمرد الغابة والبرونز",
    subtitleAr = "أوبسيديان زمردي عميق مع تباين برونزي حاد",
    badgeAr = "Forest Emerald",
    previewBg = Color(0xFF07130E),
    previewCard = Color(0xCC10221A),
    previewAccent = ObsidianSecondary
  ),
  AURORA_LIGHT(
    index = 4,
    titleAr = "العاج الرملي",
    subtitleAr = "الوضع الفاتح الدافئ بأسلوب الورق التحريري",
    badgeAr = "Sandstone",
    previewBg = SandstoneLightBackground,
    previewCard = SandstoneLightCardBackground,
    previewAccent = SandstoneLightPrimary
  );

  companion object {
    fun fromIndex(index: Int): AppThemeOption =
      entries.firstOrNull { it.index == index } ?: CLASSIC_DARK
  }
}

enum class CardVariant {
  HERO_PREVIEW,
  STUDIO_CREATIVE,
  UTILITY_COMPACT,
  STATUS_REACTIVE,
  CONTROL_PANEL
}

data class AppThemePalette(
  val option: AppThemeOption,
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val primary: Color,
  val secondary: Color,
  val tertiary: Color,
  val success: Color,
  val warning: Color,
  val error: Color,
  val border: Color,
  val specularTopLeft: Color,
  val specularBottomRight: Color,
  val glossHighlight: Color,
  val heroGradientStart: Color,
  val heroGradientEnd: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textMuted: Color,
  val navBarContainer: Color,
  val splashGlowA: Color,
  val splashGlowB: Color,
  val dividerColor: Color,
  val sliderInactiveTrack: Color
) {
  val isGlass: Boolean
    get() = option == AppThemeOption.IPHONE_LIQUID_GLASS ||
      option == AppThemeOption.IPHONE_LIGHT_FROST ||
      option == AppThemeOption.CYBER_NEON

  val isLight: Boolean
    get() = option == AppThemeOption.IPHONE_LIGHT_FROST ||
      option == AppThemeOption.AURORA_LIGHT
}

val ClassicDarkPalette = AppThemePalette(
  option = AppThemeOption.CLASSIC_DARK,
  background = ObsidianBackground,
  surface = ObsidianCardBackground,
  surfaceElevated = ObsidianElevatedSurface,
  primary = ObsidianPrimary,
  secondary = ObsidianSecondary,
  tertiary = ObsidianTertiary,
  success = ObsidianSuccess,
  warning = ObsidianWarning,
  error = ObsidianError,
  border = ObsidianBorder,
  specularTopLeft = Color(0xFF473B2E),
  specularBottomRight = ObsidianBorder,
  glossHighlight = Color(0x0FFFF6E6),
  heroGradientStart = Color(0xFF231C14),
  heroGradientEnd = ObsidianCardBackground,
  textPrimary = ObsidianTextPrimary,
  textSecondary = ObsidianTextSecondary,
  textMuted = ObsidianTextMuted,
  navBarContainer = Color(0xFF171410),
  splashGlowA = ObsidianPrimary.copy(alpha = 0.24f),
  splashGlowB = ObsidianSecondary.copy(alpha = 0.16f),
  dividerColor = ObsidianBorder,
  sliderInactiveTrack = Color(0xFF332B22)
)

val AuroraLightPalette = AppThemePalette(
  option = AppThemeOption.AURORA_LIGHT,
  background = SandstoneLightBackground,
  surface = SandstoneLightCardBackground,
  surfaceElevated = SandstoneLightElevatedSurface,
  primary = SandstoneLightPrimary,
  secondary = SandstoneLightSecondary,
  tertiary = SandstoneLightTertiary,
  success = SandstoneLightSuccess,
  warning = SandstoneLightWarning,
  error = SandstoneLightError,
  border = SandstoneLightBorder,
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = SandstoneLightBorder,
  glossHighlight = Color(0x33FFFDF8),
  heroGradientStart = Color(0xFFFFFDF9),
  heroGradientEnd = Color(0xFFF3E9D8),
  textPrimary = SandstoneLightTextPrimary,
  textSecondary = SandstoneLightTextSecondary,
  textMuted = SandstoneLightTextMuted,
  navBarContainer = Color(0xFFFFFDF9),
  splashGlowA = SandstoneLightPrimary.copy(alpha = 0.16f),
  splashGlowB = SandstoneLightSecondary.copy(alpha = 0.14f),
  dividerColor = SandstoneLightBorder,
  sliderInactiveTrack = Color(0xFFD5C8B4)
)

val IphoneLiquidGlassPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIQUID_GLASS,
  background = Color(0xFF0B0A08),
  surface = Color(0x9E1E1914), // Smoked Warm Titanium Glass
  surfaceElevated = Color(0x9429221B),
  primary = ObsidianPrimary,
  secondary = ObsidianSecondary,
  tertiary = ObsidianTertiary,
  success = ObsidianSuccess,
  warning = ObsidianWarning,
  error = ObsidianError,
  border = Color(0x55C7A473),
  specularTopLeft = Color(0x88FFF4E0),
  specularBottomRight = Color(0x66F59E0B),
  glossHighlight = Color(0x20FFF5E4),
  heroGradientStart = Color(0xC2282017),
  heroGradientEnd = Color(0x9E1B1611),
  textPrimary = ObsidianTextPrimary,
  textSecondary = ObsidianTextSecondary,
  textMuted = ObsidianTextMuted,
  navBarContainer = Color(0xDE16120E),
  splashGlowA = ObsidianPrimary.copy(alpha = 0.28f),
  splashGlowB = ObsidianSecondary.copy(alpha = 0.20f),
  dividerColor = Color(0x2EFFF4E0),
  sliderInactiveTrack = Color(0x40FFF4E0)
)

val IphoneLightFrostPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIGHT_FROST,
  background = Color(0xFFF2EBE0),
  surface = Color(0xD4FFFDF9),
  surfaceElevated = Color(0xBFEFE5D5),
  primary = SandstoneLightPrimary,
  secondary = SandstoneLightSecondary,
  tertiary = SandstoneLightTertiary,
  success = SandstoneLightSuccess,
  warning = SandstoneLightWarning,
  error = SandstoneLightError,
  border = Color(0xB3FFFDF8),
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = Color(0x55C26D00),
  glossHighlight = Color(0x55FFFFFF),
  heroGradientStart = Color(0xEDFFFDF9),
  heroGradientEnd = Color(0xD4F4E9D7),
  textPrimary = SandstoneLightTextPrimary,
  textSecondary = SandstoneLightTextSecondary,
  textMuted = SandstoneLightTextMuted,
  navBarContainer = Color(0xE8FFFDF9),
  splashGlowA = SandstoneLightPrimary.copy(alpha = 0.20f),
  splashGlowB = SandstoneLightSecondary.copy(alpha = 0.18f),
  dividerColor = Color(0x221E1915),
  sliderInactiveTrack = Color(0x33C26D00)
)

val CyberNeonPalette = AppThemePalette(
  option = AppThemeOption.CYBER_NEON,
  background = Color(0xFF07120D),
  surface = Color(0xCC0F2119),
  surfaceElevated = Color(0xBF162E23),
  primary = ObsidianSecondary,     // Emerald Lead
  secondary = ObsidianPrimary,     // Warm Gold Secondary
  tertiary = ObsidianTertiary,     // Terracotta Coral
  success = ObsidianSuccess,
  warning = ObsidianWarning,
  error = ObsidianError,
  border = Color(0x5510B981),
  specularTopLeft = Color(0x9910B981),
  specularBottomRight = Color(0x88F59E0B),
  glossHighlight = Color(0x1A10B981),
  heroGradientStart = Color(0xD6153023),
  heroGradientEnd = Color(0xCC0F2119),
  textPrimary = Color(0xFFF2FBF7),
  textSecondary = Color(0xFFA7C7B8),
  textMuted = Color(0xFF6F9484),
  navBarContainer = Color(0xDE0B1913),
  splashGlowA = ObsidianSecondary.copy(alpha = 0.26f),
  splashGlowB = ObsidianPrimary.copy(alpha = 0.22f),
  dividerColor = Color(0x3310B981),
  sliderInactiveTrack = Color(0xFF1D3D2E)
)

fun paletteForThemeIndex(index: Int): AppThemePalette = when (index) {
  1 -> IphoneLiquidGlassPalette
  2 -> IphoneLightFrostPalette
  3 -> CyberNeonPalette
  4 -> AuroraLightPalette
  else -> ClassicDarkPalette
}

val LocalAppThemePalette = compositionLocalOf { ClassicDarkPalette }

object AppTheme {
  val colors: AppThemePalette
    @Composable
    get() = LocalAppThemePalette.current
}

/**
 * Warm atmospheric radial lighting + animated glass refraction wallpaper for glass themes.
 * Completely free of blue and purple tones.
 */
@Composable
fun AppThemeBackdrop(
  palette: AppThemePalette,
  accentColor: Color,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  val bgColor by animateColorAsState(palette.background, tween(350), label = "theme_bg")

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
  ) {
    if (palette.isGlass) {
      val infinite = rememberInfiniteTransition(label = "glass_wallpaper")
      val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000), RepeatMode.Restart),
        label = "wallpaper_drift"
      )

      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val angle = (drift * 2f * PI).toFloat()

        when (palette.option) {
          AppThemeOption.IPHONE_LIQUID_GLASS -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF120E0A), Color(0xFF0D0B09), Color(0xFF080705))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianPrimary.copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.20f + 0.08f * cos(angle)), h * (0.16f + 0.04f * sin(angle))),
                radius = w * 0.72f
              ),
              center = Offset(w * (0.20f + 0.08f * cos(angle)), h * (0.16f + 0.04f * sin(angle))),
              radius = w * 0.72f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianSecondary.copy(alpha = 0.20f), Color.Transparent),
                center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.48f + 0.06f * cos(angle))),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.48f + 0.06f * cos(angle))),
              radius = w * 0.65f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianTertiary.copy(alpha = 0.16f), Color.Transparent),
                center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.84f - 0.04f * cos(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.84f - 0.04f * cos(angle))),
              radius = w * 0.68f
            )
          }

          AppThemeOption.IPHONE_LIGHT_FROST -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFBF6EE), Color(0xFFF1E6D5), Color(0xFFF7F1E7))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianPrimary.copy(alpha = 0.24f), Color.Transparent),
                center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
              radius = w * 0.68f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianSecondary.copy(alpha = 0.18f), Color.Transparent),
                center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
                radius = w * 0.62f
              ),
              center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
              radius = w * 0.62f
            )
          }

          AppThemeOption.CYBER_NEON -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF06110C), Color(0xFF0A1B13), Color(0xFF050D09))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianSecondary.copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.18f + 0.08f * cos(angle)), h * (0.20f + 0.03f * sin(angle))),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.18f + 0.08f * cos(angle)), h * (0.20f + 0.03f * sin(angle))),
              radius = w * 0.65f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianPrimary.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
                radius = w * 0.70f
              ),
              center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
              radius = w * 0.70f
            )
          }

          else -> Unit
        }
      }
    } else {
      // Warm Horizon Ambience (Amber top-left warmth + subtle Jade diagonal balance)
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(palette.primary.copy(alpha = if (palette.isLight) 0.09f else 0.11f), Color.Transparent),
            center = Offset(w * 0.15f, h * 0.08f),
            radius = w * 0.90f
          ),
          center = Offset(w * 0.15f, h * 0.08f),
          radius = w * 0.90f
        )
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(palette.secondary.copy(alpha = if (palette.isLight) 0.07f else 0.07f), Color.Transparent),
            center = Offset(w * 0.88f, h * 0.86f),
            radius = w * 0.78f
          ),
          center = Offset(w * 0.88f, h * 0.86f),
          radius = w * 0.78f
        )
      }
    }

    content()
  }
}

/**
 * Distinct Architectural Card System:
 * - HERO_PREVIEW: Bold bevel with warm diagonal Amber-to-Bronze gradient sheen
 * - STUDIO_CREATIVE: Signature vertical Emerald/Coral accent spine on the start edge
 * - STATUS_REACTIVE: Top status hairline strip + status-tinted rim
 * - UTILITY_COMPACT: Compact crisp smoked tray
 * - CONTROL_PANEL: Structured bronze-rimmed panel
 */
@Composable
fun ThemedCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 20.dp,
  variant: CardVariant = CardVariant.CONTROL_PANEL,
  statusColor: Color? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val palette = AppTheme.colors
  val resolvedRadius = when (variant) {
    CardVariant.HERO_PREVIEW -> 26.dp
    CardVariant.UTILITY_COMPACT -> 18.dp
    else -> cornerRadius
  }
  val shape: Shape = RoundedCornerShape(resolvedRadius)

  if (!palette.isGlass) {
    val elevationDp = when (variant) {
      CardVariant.HERO_PREVIEW -> 14.dp
      CardVariant.STUDIO_CREATIVE -> 9.dp
      CardVariant.STATUS_REACTIVE -> 8.dp
      CardVariant.UTILITY_COMPACT -> 5.dp
      CardVariant.CONTROL_PANEL -> 7.dp
    }

    val borderBrush = when (variant) {
      CardVariant.HERO_PREVIEW -> Brush.linearGradient(
        colors = listOf(
          palette.primary.copy(alpha = if (palette.isLight) 0.44f else 0.55f),
          palette.border,
          palette.secondary.copy(alpha = if (palette.isLight) 0.30f else 0.38f)
        )
      )
      CardVariant.STUDIO_CREATIVE -> Brush.linearGradient(
        colors = listOf(
          palette.secondary.copy(alpha = if (palette.isLight) 0.36f else 0.42f),
          palette.border
        )
      )
      CardVariant.STATUS_REACTIVE -> {
        val tint = statusColor ?: palette.primary
        Brush.horizontalGradient(
          colors = listOf(tint.copy(alpha = 0.55f), palette.border)
        )
      }
      CardVariant.UTILITY_COMPACT -> Brush.linearGradient(
        colors = listOf(palette.border, palette.border)
      )
      CardVariant.CONTROL_PANEL -> Brush.verticalGradient(
        colors = listOf(
          if (palette.isLight) palette.border else Color(0xFF44392C),
          palette.border
        )
      )
    }

    val spotColor = when (variant) {
      CardVariant.HERO_PREVIEW -> palette.primary.copy(alpha = if (palette.isLight) 0.16f else 0.30f)
      CardVariant.STUDIO_CREATIVE -> palette.secondary.copy(alpha = if (palette.isLight) 0.12f else 0.20f)
      CardVariant.STATUS_REACTIVE -> (statusColor ?: palette.primary).copy(alpha = 0.18f)
      else -> Color.Black.copy(alpha = if (palette.isLight) 0.08f else 0.45f)
    }

    val surfaceModifier = when (variant) {
      CardVariant.HERO_PREVIEW -> Modifier.background(
        Brush.linearGradient(
          colors = listOf(palette.heroGradientStart, palette.heroGradientEnd)
        )
      )
      else -> Modifier.background(palette.surface)
    }

    Box(
      modifier = modifier
        .fillMaxWidth()
        .shadow(
          elevation = elevationDp,
          shape = shape,
          spotColor = spotColor,
          ambientColor = Color.Black.copy(alpha = if (palette.isLight) 0.08f else 0.40f)
        )
        .clip(shape)
        .then(surfaceModifier)
        .border(
          width = if (variant == CardVariant.HERO_PREVIEW || variant == CardVariant.STATUS_REACTIVE) 1.3.dp else 1.dp,
          brush = borderBrush,
          shape = shape
        )
    ) {
      when (variant) {
        CardVariant.STUDIO_CREATIVE -> {
          Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(
              modifier = Modifier
                .width(4.dp)
                .fillMaxHeight()
                .background(
                  Brush.verticalGradient(listOf(palette.secondary, palette.primary))
                )
            )
            Column(modifier = Modifier.weight(1f), content = content)
          }
        }
        CardVariant.STATUS_REACTIVE -> {
          val accent = statusColor ?: palette.primary
          Column(modifier = Modifier.fillMaxWidth()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.2f))))
            )
            Column(modifier = Modifier.fillMaxWidth(), content = content)
          }
        }
        else -> {
          Column(modifier = Modifier.fillMaxWidth(), content = content)
        }
      }
    }
  } else {
    val accentTint = statusColor ?: when (variant) {
      CardVariant.STUDIO_CREATIVE -> palette.secondary
      CardVariant.HERO_PREVIEW -> palette.primary
      else -> palette.specularBottomRight
    }
    val rimBrush = Brush.linearGradient(
      colors = listOf(
        palette.specularTopLeft,
        palette.border.copy(alpha = 0.25f),
        accentTint.copy(alpha = 0.65f)
      )
    )
    val glassSheen = Brush.verticalGradient(
      colors = listOf(
        palette.glossHighlight,
        Color.Transparent,
        palette.glossHighlight.copy(alpha = 0.08f)
      )
    )
    Box(
      modifier = modifier
        .fillMaxWidth()
        .shadow(
          elevation = when (variant) {
            CardVariant.HERO_PREVIEW -> if (palette.isLight) 16.dp else 22.dp
            else -> if (palette.isLight) 11.dp else 16.dp
          },
          shape = shape,
          spotColor = palette.primary.copy(alpha = if (palette.isLight) 0.20f else 0.28f),
          ambientColor = if (palette.isLight) Color(0x22000000) else Color(0x44000000)
        )
        .clip(shape)
        .background(palette.surface)
        .background(glassSheen)
        .border(width = 1.15.dp, brush = rimBrush, shape = shape)
    ) {
      Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
  }
}
