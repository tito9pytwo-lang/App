package com.example.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ObsidianPrimary,
    onPrimary = Color(0xFF261500),
    primaryContainer = Color(0xFF3A280A),
    onPrimaryContainer = ObsidianTextPrimary,
    secondary = ObsidianSecondary,
    onSecondary = Color(0xFF04261B),
    secondaryContainer = Color(0xFF103025),
    onSecondaryContainer = ObsidianTextPrimary,
    tertiary = ObsidianTertiary,
    onTertiary = Color(0xFF2B0711),
    background = ObsidianBackground,
    onBackground = ObsidianTextPrimary,
    surface = ObsidianCardBackground,
    onSurface = ObsidianTextPrimary,
    surfaceVariant = ObsidianElevatedSurface,
    onSurfaceVariant = ObsidianTextSecondary,
    error = ObsidianError,
    onError = Color(0xFF2B0808),
    outline = ObsidianBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SandstoneLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFDE6C4),
    onPrimaryContainer = Color(0xFF3B1F00),
    secondary = SandstoneLightSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = SandstoneLightTertiary,
    onTertiary = Color.White,
    background = SandstoneLightBackground,
    onBackground = SandstoneLightTextPrimary,
    surface = SandstoneLightCardBackground,
    onSurface = SandstoneLightTextPrimary,
    surfaceVariant = SandstoneLightElevatedSurface,
    onSurfaceVariant = SandstoneLightTextSecondary,
    error = SandstoneLightError,
    onError = Color.White,
    outline = SandstoneLightBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  appThemeIndex: Int = 0,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val palette = paletteForThemeIndex(appThemeIndex)
  val useDark = darkTheme && !palette.isLight
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      useDark -> DarkColorScheme.copy(
        primary = palette.primary,
        secondary = palette.secondary,
        tertiary = palette.tertiary,
        error = palette.error,
        background = palette.background,
        surface = palette.surface,
        surfaceVariant = palette.surfaceElevated,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.border
      )
      else -> LightColorScheme.copy(
        primary = palette.primary,
        secondary = palette.secondary,
        tertiary = palette.tertiary,
        error = palette.error,
        background = palette.background,
        surface = palette.surface,
        surfaceVariant = palette.surfaceElevated,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.border
      )
    }

  CompositionLocalProvider(LocalAppThemePalette provides palette) {
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
  }
}
