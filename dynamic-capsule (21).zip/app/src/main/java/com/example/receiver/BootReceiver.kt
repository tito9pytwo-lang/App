package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.service.FloatingCapsuleService

class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      if (settings.serviceEnabled && FloatingCapsuleService.isAccessibilityServiceEnabled(context)) {
        // Android automatically binds enabled AccessibilityServices on boot; initialize island state proactively.
        IslandStateManager.initialize(context)
      }
    }
  }
}
