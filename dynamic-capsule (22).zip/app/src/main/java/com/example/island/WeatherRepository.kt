package com.example.island

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.roundToInt

object WeatherRepository {

  data class CitySuggestion(
    val name: String,
    val country: String = "",
    val admin1: String = "",
    val latitude: Double,
    val longitude: Double
  ) {
    fun displaySubtitle(): String =
      listOf(admin1, country).filter { it.isNotBlank() }.joinToString(" • ")

    fun coordinatesLabel(): String =
      String.format(Locale.US, "%.2f°, %.2f°", latitude, longitude)
  }

  private const val TAG = "WeatherRepository"
  private const val PREFS_NAME = "dynamic_capsule_weather_prefs"
  private const val KEY_LAST_LAT = "last_lat"
  private const val KEY_LAST_LON = "last_lon"
  private const val KEY_LAST_CITY = "last_city"
  private const val KEY_LAST_IS_CUSTOM = "last_is_custom"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(12, TimeUnit.SECONDS)
      .readTimeout(12, TimeUnit.SECONDS)
      .build()
  }

  private fun prefs(context: Context): SharedPreferences =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun clearSavedLocation(context: Context) {
    prefs(context).edit()
      .remove(KEY_LAST_LAT)
      .remove(KEY_LAST_LON)
      .remove(KEY_LAST_CITY)
      .remove(KEY_LAST_IS_CUSTOM)
      .apply()
  }

  suspend fun searchCitySuggestions(query: String): Result<List<CitySuggestion>> = withContext(Dispatchers.IO) {
    val clean = query.trim()
    if (clean.length < 2) return@withContext Result.success(emptyList())
    try {
      val arSuggestions = fetchGeocodingList(clean, "ar")
      if (arSuggestions.isNotEmpty()) {
        return@withContext Result.success(arSuggestions)
      }
      val enSuggestions = fetchGeocodingList(clean, "en")
      Result.success(enSuggestions)
    } catch (e: Exception) {
      Log.w(TAG, "City suggestion search failed for $clean", e)
      Result.failure(e)
    }
  }

  private fun fetchGeocodingList(query: String, language: String): List<CitySuggestion> {
    val encoded = URLEncoder.encode(query, "UTF-8")
    val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=8&language=$language&format=json"
    val req = Request.Builder().url(url).get().build()
    val body = httpClient.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) return emptyList()
      resp.body?.string()
    } ?: return emptyList()
    return parseGeocodingSuggestions(body)
  }

  internal fun parseGeocodingSuggestions(jsonStr: String): List<CitySuggestion> {
    return try {
      val json = JSONObject(jsonStr)
      val results = json.optJSONArray("results") ?: return emptyList()
      val seen = mutableSetOf<String>()
      val list = mutableListOf<CitySuggestion>()
      for (i in 0 until results.length()) {
        val obj = results.optJSONObject(i) ?: continue
        val name = obj.optString("name", "").trim()
        if (name.isEmpty()) continue
        val lat = obj.optDouble("latitude", Double.NaN)
        val lon = obj.optDouble("longitude", Double.NaN)
        if (lat.isNaN() || lon.isNaN()) continue
        val country = obj.optString("country", "").trim()
        val admin1 = obj.optString("admin1", "").trim()
        val dedupKey = "${name.lowercase(Locale.US)}|${country.lowercase(Locale.US)}|${String.format(Locale.US, "%.1f,%.1f", lat, lon)}"
        if (seen.add(dedupKey)) {
          list.add(
            CitySuggestion(
              name = name,
              country = country,
              admin1 = admin1,
              latitude = lat,
              longitude = lon
            )
          )
        }
      }
      list
    } catch (e: Exception) {
      Log.w(TAG, "Failed parsing geocoding suggestions", e)
      emptyList()
    }
  }

  suspend fun fetchLiveWeather(
    context: Context,
    explicitCityQuery: String = "",
    explicitLat: Double? = null,
    explicitLon: Double? = null,
    customDisplayAlias: String = ""
  ): Result<WeatherState> = withContext(Dispatchers.IO) {
    try {
      val appCtx = context.applicationContext ?: context
      var targetLat: Double? = null
      var targetLon: Double? = null
      var actualCity = ""
      var isCustomCity = false

      // 1. Exact coordinates from user-selected city prediction take top priority
      if (explicitLat != null && explicitLon != null) {
        targetLat = explicitLat
        targetLon = explicitLon
        actualCity = explicitCityQuery.trim()
          .ifBlank { reverseGeocodeCity(appCtx, explicitLat, explicitLon) ?: "المدينة المختارة" }
        isCustomCity = true
      } else if (explicitCityQuery.isNotBlank()) {
        // 2. Explicit typed city name: geocode strictly (NEVER silently fall back to GPS/old city)
        val trimmed = explicitCityQuery.trim()
        val geo = geocodeCity(trimmed, "ar") ?: geocodeCity(trimmed, "en")
        if (geo != null) {
          targetLat = geo.first
          targetLon = geo.second
          actualCity = geo.third
          isCustomCity = true
        } else {
          return@withContext Result.failure(
            IllegalStateException("لم يتم العثور على مدينة باسم \"$trimmed\" — اختر من الاقتراحات")
          )
        }
      } else {
        // 3. Automatic mode: use real device coarse/fine location
        val deviceLoc = getBestLastKnownLocation(appCtx) ?: requestFreshLocationQuick(appCtx)
        if (deviceLoc != null) {
          targetLat = deviceLoc.latitude
          targetLon = deviceLoc.longitude
          actualCity = reverseGeocodeCity(appCtx, targetLat, targetLon) ?: "موقعي الحالي"
        } else {
          val p = prefs(appCtx)
          if (p.contains(KEY_LAST_LAT) && p.contains(KEY_LAST_LON) && !p.getBoolean(KEY_LAST_IS_CUSTOM, false)) {
            targetLat = Double.fromBits(p.getLong(KEY_LAST_LAT, 0L))
            targetLon = Double.fromBits(p.getLong(KEY_LAST_LON, 0L))
            actualCity = p.getString(KEY_LAST_CITY, "موقعي الحالي") ?: "موقعي الحالي"
          }
        }
      }

      if (targetLat == null || targetLon == null) {
        return@withContext Result.failure(
          IllegalStateException("يرجى منح إذن الموقع أو البحث عن مدينتك لتحديث الطقس")
        )
      }

      // Persist resolved coordinates cleanly
      prefs(appCtx).edit()
        .putLong(KEY_LAST_LAT, targetLat.toBits())
        .putLong(KEY_LAST_LON, targetLon.toBits())
        .putString(KEY_LAST_CITY, actualCity)
        .putBoolean(KEY_LAST_IS_CUSTOM, isCustomCity)
        .apply()

      val forecastUrl = String.format(
        Locale.US,
        "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f" +
          "&current=temperature_2m,relative_humidity_2m,is_day,weather_code,wind_speed_10m" +
          "&hourly=temperature_2m,weather_code&daily=sunrise,sunset&timezone=auto&forecast_days=2",
        targetLat,
        targetLon
      )

      val request = Request.Builder().url(forecastUrl).get().build()
      val responseBody = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(IllegalStateException("تعذر الاتصال بخدمة الطقس (${resp.code})"))
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة الطقس"))

      val shownCity = customDisplayAlias.trim().ifBlank { actualCity }
      val coordLabel = String.format(Locale.US, "%.2f°, %.2f°", targetLat, targetLon)
      val state = parseOpenMeteoResponse(responseBody, shownCity).copy(
        actualCityName = actualCity,
        isCustomCity = isCustomCity,
        resolvedCoordinatesLabel = coordLabel
      )
      Result.success(state)
    } catch (e: Exception) {
      Log.e(TAG, "Failed fetching live weather", e)
      Result.failure(e)
    }
  }

  private fun geocodeCity(cityName: String, language: String = "ar"): Triple<Double, Double, String>? {
    return try {
      val list = fetchGeocodingList(cityName, language)
      val first = list.firstOrNull() ?: return null
      Triple(first.latitude, first.longitude, first.name)
    } catch (e: Exception) {
      Log.w(TAG, "Geocoding failed for $cityName ($language)", e)
      null
    }
  }

  @SuppressLint("MissingPermission")
  private fun getBestLastKnownLocation(context: Context): Location? {
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    if (!hasCoarse && !hasFine) return null

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val providers = buildList {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        add(LocationManager.FUSED_PROVIDER)
      }
      add(LocationManager.NETWORK_PROVIDER)
      add(LocationManager.GPS_PROVIDER)
      add(LocationManager.PASSIVE_PROVIDER)
    }

    var best: Location? = null
    for (provider in providers) {
      try {
        val loc = lm.getLastKnownLocation(provider) ?: continue
        if (best == null || loc.time > best.time) {
          best = loc
        }
      } catch (_: Exception) {
      }
    }
    return best
  }

  @SuppressLint("MissingPermission")
  private suspend fun requestFreshLocationQuick(context: Context): Location? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    if (!hasCoarse && !hasFine) return null

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val provider = when {
      lm.isProviderEnabled(LocationManager.FUSED_PROVIDER) -> LocationManager.FUSED_PROVIDER
      lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
      lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
      else -> return null
    }
    return withTimeoutOrNull(3000L) {
      suspendCancellableCoroutine { cont ->
        try {
          val cancelSignal = android.os.CancellationSignal()
          cont.invokeOnCancellation { cancelSignal.cancel() }
          lm.getCurrentLocation(
            provider,
            cancelSignal,
            context.mainExecutor
          ) { location ->
            if (cont.isActive) cont.resume(location)
          }
        } catch (_: Exception) {
          if (cont.isActive) cont.resume(null)
        }
      }
    }
  }

  @Suppress("DEPRECATION")
  private fun reverseGeocodeCity(context: Context, lat: Double, lon: Double): String? {
    return try {
      if (!Geocoder.isPresent()) return null
      val geocoder = Geocoder(context, Locale("ar"))
      val list = geocoder.getFromLocation(lat, lon, 1) ?: return null
      val addr = list.firstOrNull() ?: return null
      addr.locality ?: addr.subAdminArea ?: addr.adminArea ?: addr.countryName
    } catch (_: Exception) {
      null
    }
  }

  internal fun parseOpenMeteoResponse(jsonStr: String, cityName: String): WeatherState {
    val root = JSONObject(jsonStr)
    val current = root.getJSONObject("current")
    val tempC = current.optDouble("temperature_2m", 0.0).roundToInt()
    val humidity = current.optDouble("relative_humidity_2m", 0.0).roundToInt()
    val windKmh = current.optDouble("wind_speed_10m", 0.0).roundToInt()
    val weatherCode = current.optInt("weather_code", 0)
    val isDay = current.optInt("is_day", 1) == 1

    val (conditionAr, isSeverityWarning) = mapWmoCodeToArabic(weatherCode, tempC)

    var sunriseText = "06:00"
    var sunsetText = "18:00"
    var solarProgress = if (isDay) 0.5f else 0.1f

    val daily = root.optJSONObject("daily")
    val sunriseIso = daily?.optJSONArray("sunrise")?.optString(0).orEmpty()
    val sunsetIso = daily?.optJSONArray("sunset")?.optString(0).orEmpty()
    if (sunriseIso.contains("T") && sunsetIso.contains("T")) {
      sunriseText = sunriseIso.substringAfter("T").take(5)
      sunsetText = sunsetIso.substringAfter("T").take(5)
      solarProgress = computeSolarProgress(sunriseIso, sunsetIso)
    }

    val hourlyItems = mutableListOf<HourlyWeatherItem>()
    val hourly = root.optJSONObject("hourly")
    if (hourly != null) {
      val times = hourly.optJSONArray("time")
      val temps = hourly.optJSONArray("temperature_2m")
      val codes = hourly.optJSONArray("weather_code")
      val cal = Calendar.getInstance()
      val todayDatePrefix = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
      val currentHour = cal.get(Calendar.HOUR_OF_DAY)
      if (times != null && temps != null && codes != null) {
        val len = times.length()
        val firstDatePrefix = if (len > 0) times.optString(0).substringBefore("T") else ""
        var startIdx = 0
        if (firstDatePrefix == todayDatePrefix) {
          val nowKey = String.format(Locale.US, "%sT%02d", todayDatePrefix, currentHour)
          for (i in 0 until len) {
            if (times.optString(i).take(13) >= nowKey) {
              startIdx = i
              break
            }
          }
        } else {
          for (i in 0 until len) {
            val h = times.optString(i).substringAfter("T", "").take(2).toIntOrNull()
            if (h != null && h >= currentHour) {
              startIdx = i
              break
            }
          }
        }
        val endIdx = (startIdx + 6).coerceAtMost(len)
        for (i in startIdx until endIdx) {
          val hourStr = times.optString(i).substringAfter("T", "").take(5)
          val tC = temps.optDouble(i, 0.0).roundToInt()
          val wCode = codes.optInt(i, 0)
          hourlyItems.add(HourlyWeatherItem(hourLabel = hourStr, tempC = tC, weatherCode = wCode))
        }
      }
    }

    val dateStr = SimpleDateFormat("EEEE, d MMM", Locale("ar")).format(Date())

    return WeatherState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = isSeverityWarning,
      cityName = cityName.ifBlank { "الطقس الحالي" },
      temperatureC = tempC,
      conditionAr = conditionAr,
      weatherCode = weatherCode,
      isDay = isDay,
      windSpeedKmh = windKmh,
      humidityPct = humidity,
      sunriseText = sunriseText,
      sunsetText = sunsetText,
      sunriseProgress = solarProgress,
      dateLabel = dateStr,
      isWarning = isSeverityWarning,
      hourlyForecast = hourlyItems,
      errorMessage = null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  private fun computeSolarProgress(sunriseIso: String, sunsetIso: String): Float {
    return try {
      val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
      val riseMs = fmt.parse(sunriseIso)?.time ?: return 0.5f
      val setMs = fmt.parse(sunsetIso)?.time ?: return 0.5f
      val nowMs = System.currentTimeMillis()
      if (setMs <= riseMs) return 0.5f
      ((nowMs - riseMs).toFloat() / (setMs - riseMs).toFloat()).coerceIn(0f, 1f)
    } catch (_: Exception) {
      0.5f
    }
  }

  fun mapWmoCodeToArabic(code: Int, tempC: Int = 22): Pair<String, Boolean> {
    val label = when (code) {
      0 -> "سماء صافية"
      1 -> "صافي غالباً"
      2 -> "غائم جزئياً"
      3 -> "غائم كلياً"
      45, 48 -> "ضباب"
      51, 53, 55 -> "رذاذ خفيف"
      56, 57 -> "رذاذ متجمد"
      61, 63 -> "أمطار"
      65 -> "أمطار غزيرة"
      66, 67 -> "مطر متجمد"
      71, 73 -> "تساقط ثلوج"
      75, 77 -> "عاصفة ثلجية"
      80, 81, 82 -> "زخات مطرية"
      85, 86 -> "زخات ثلجية"
      95, 96, 99 -> "عاصفة رعدية"
      else -> "متقلب"
    }
    val warning = code >= 65 || code in listOf(45, 48) || tempC >= 44 || tempC <= 0
    return Pair(label, warning)
  }
}
