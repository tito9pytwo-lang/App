package com.example.ui.capsule

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.AirplanemodeInactive
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material.icons.filled.WifiTetheringOff
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CapsuleSettings
import com.example.data.FavoriteTracksManager
import com.example.island.BatteryState
import com.example.island.BluetoothState
import com.example.island.CallState
import com.example.island.CompassState
import com.example.island.DownloadState
import com.example.island.FlashlightState
import com.example.island.FocusState
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NavigationState
import com.example.island.NetworkEventType
import com.example.island.NetworkState
import com.example.island.NextAlarmState
import com.example.island.NotificationEvent
import com.example.island.PrivacyState
import com.example.island.RingerState
import com.example.island.SleepTimerState
import com.example.island.SoundMode
import com.example.island.StepsState
import com.example.island.TimerState
import com.example.island.VolumeState
import com.example.island.WeatherState
import com.example.media.AlbumColorExtractor
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import java.util.Locale
import com.example.ui.theme.ObsidianError
import com.example.ui.theme.ObsidianPrimary
import com.example.ui.theme.ObsidianSecondary
import com.example.ui.theme.ObsidianSuccess
import com.example.ui.theme.ObsidianTertiary
import com.example.ui.theme.ObsidianWarning
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CapsuleMode {
  MINI,
  EXPANDED
}

/**
 * Reusable Marquee Text with soft edge fade ("يتحرك و يختفي")
 * Scrolls horizontally if text is longer than container, and fades at both ends.
 */
@Composable
fun MarqueeFadingText(
  text: String,
  modifier: Modifier = Modifier,
  color: Color = Color.White,
  fontSize: TextUnit = 12.sp,
  fontWeight: FontWeight = FontWeight.Bold,
  maxLines: Int = 1,
  edgeFadeWidth: Dp = 8.dp,
  textAlign: TextAlign? = null
) {
  val edgePx = with(LocalDensity.current) { edgeFadeWidth.toPx() }
  Text(
    text = text,
    color = color,
    fontSize = fontSize,
    fontWeight = fontWeight,
    maxLines = maxLines,
    textAlign = textAlign,
    modifier = modifier
      .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
      .drawWithContent {
        drawContent()
        if (size.width > edgePx * 2) {
          // Left soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Transparent, Color.Black),
              startX = 0f,
              endX = edgePx
            ),
            blendMode = BlendMode.DstIn
          )
          // Right soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Black, Color.Transparent),
              startX = size.width - edgePx,
              endX = size.width
            ),
            blendMode = BlendMode.DstIn
          )
        }
      }
      .basicMarquee(
        iterations = Int.MAX_VALUE,
        repeatDelayMillis = 1400,
        initialDelayMillis = 900,
        velocity = 32.dp
      )
  )
}

@Composable
fun DynamicCapsuleView(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  mode: CapsuleMode,
  onModeChange: (CapsuleMode) -> Unit,
  modifier: Modifier = Modifier,
  onPlayPauseClick: () -> Unit = { MediaSessionHolder.togglePlayPause() },
  onNextClick: () -> Unit = { MediaSessionHolder.skipToNext() },
  onPrevClick: () -> Unit = { MediaSessionHolder.skipToPrevious() },
  onSeek: (Long) -> Unit = { MediaSessionHolder.seekTo(it) },
  onDismissToNotification: () -> Unit = {}
) {
  val baseAccent = settings.effectiveAccentColor
  val rawDynamicAccent = remember(trackInfo?.albumArt, settings.enableDynamicAlbumColors, baseAccent) {
    if (settings.enableDynamicAlbumColors && trackInfo?.albumArt != null) {
      AlbumColorExtractor.extractAccentColor(trackInfo.albumArt, baseAccent)
    } else {
      baseAccent
    }
  }
  val accentColor by animateColorAsState(
    targetValue = rawDynamicAccent,
    animationSpec = tween(durationMillis = 600),
    label = "dynamic_album_accent"
  )

  val activeCard by IslandStateManager.activeCard.collectAsState()
  val batteryState by IslandStateManager.batteryState.collectAsState()
  val callState by IslandStateManager.callState.collectAsState()
  val timerState by IslandStateManager.timerState.collectAsState()
  val notifEvent by IslandStateManager.activeNotification.collectAsState()
  val bluetooth by IslandStateManager.bluetoothState.collectAsState()
  val flashlight by IslandStateManager.flashlightState.collectAsState()
  val ringer by IslandStateManager.ringerState.collectAsState()
  val currentSoundMode by IslandStateManager.currentSoundMode.collectAsState()
  val downloadState by IslandStateManager.downloadState.collectAsState()
  val navigationState by IslandStateManager.navigationState.collectAsState()
  val privacyState by IslandStateManager.privacyState.collectAsState()
  val networkState by IslandStateManager.networkState.collectAsState()
  val volumeState by IslandStateManager.volumeState.collectAsState()
  val sleepTimerState by IslandStateManager.sleepTimerState.collectAsState()
  val nextAlarmState by IslandStateManager.nextAlarmState.collectAsState()
  val weatherState by IslandStateManager.weatherState.collectAsState()
  val stepsState by IslandStateManager.stepsState.collectAsState()
  val compassState by IslandStateManager.compassState.collectAsState()
  val focusState by IslandStateManager.focusState.collectAsState()

  val isExpanded = mode == CapsuleMode.EXPANDED
  val primaryMiniCard = IslandStateManager.resolvePrimaryMiniCard(trackInfo, settings)
  val secondaryMiniCard = IslandStateManager.getSecondaryActiveCard(trackInfo, settings, primaryMiniCard)

  val haptic = LocalHapticFeedback.current
  val triggerHaptic: () -> Unit = {
    if (settings.hapticFeedback) {
      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
  }

  val scope = rememberCoroutineScope()
  val dragOffsetX = remember { Animatable(0f) }
  val dragOffsetY = remember { Animatable(0f) }
  val dismissThresholdPx = with(LocalDensity.current) { 55.dp.toPx() }

  LaunchedEffect(Unit) {
    dragOffsetX.snapTo(0f)
    dragOffsetY.snapTo(0f)
  }

  var expandedActiveTab by remember(isExpanded) { mutableStateOf(primaryMiniCard ?: activeCard) }

  val displayedActivityCard = if (isExpanded) expandedActiveTab else (primaryMiniCard ?: activeCard)
  val rawActivityGlowColor = remember(
    displayedActivityCard,
    accentColor,
    weatherState.isWarning,
    weatherState.weatherCode,
    privacyState.isMicInUse,
    privacyState.isVoiceRecorderActive,
    volumeState.isMuted,
    batteryState.percentage,
    batteryState.isCharging
  ) {
    resolveActivityGlowColor(
      card = displayedActivityCard,
      accentColor = accentColor,
      weatherIsWarning = weatherState.isWarning,
      privacyIsAudio = privacyState.isMicInUse || privacyState.isVoiceRecorderActive,
      volumeIsMuted = volumeState.isMuted,
      batteryLevel = batteryState.percentage,
      batteryCharging = batteryState.isCharging
    )
  }
  val activityGlowColor by animateColorAsState(
    targetValue = rawActivityGlowColor,
    animationSpec = tween(durationMillis = 420),
    label = "capsule_activity_glow"
  )

  // Open / Morph animation physics driven by settings.openAnimationIndex
  val targetWidth = if (isExpanded) 364.dp else 236.dp
  val targetHeight = if (isExpanded) {
    when (expandedActiveTab) {
      IslandActiveCard.WEATHER -> 278.dp
      IslandActiveCard.STEPS -> 268.dp
      IslandActiveCard.MUSIC -> 252.dp
      else -> 246.dp
    }
  } else {
    settings.capsuleHeightDp.dp
  }
  val targetCornerRadius = if (isExpanded) 32.dp else 24.dp

  val widthSpec = when (settings.openAnimationIndex) {
    1 -> spring<Dp>(dampingRatio = 0.50f, stiffness = Spring.StiffnessMediumLow)
    2 -> tween<Dp>(durationMillis = 280)
    3 -> spring<Dp>(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
    4 -> tween<Dp>(durationMillis = 150)
    else -> spring<Dp>(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
  }
  val heightSpec = when (settings.openAnimationIndex) {
    1 -> spring<Dp>(dampingRatio = 0.50f, stiffness = Spring.StiffnessMediumLow)
    2 -> tween<Dp>(durationMillis = 280)
    3 -> spring<Dp>(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
    4 -> tween<Dp>(durationMillis = 150)
    else -> spring<Dp>(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
  }

  val animatedWidth by animateDpAsState(targetValue = targetWidth, animationSpec = widthSpec, label = "capsule_width")
  val animatedHeight by animateDpAsState(targetValue = targetHeight, animationSpec = heightSpec, label = "capsule_height")
  val animatedCornerRadius by animateDpAsState(
    targetValue = targetCornerRadius,
    animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
    label = "capsule_corners"
  )

  val anim3DTilt by animateFloatAsState(
    targetValue = if (settings.openAnimationIndex == 3 && !isExpanded) -4f else 0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "capsule_3d_tilt"
  )

  // Live Aura / Border animation driver (5 selectable styles)
  val auraTransition = rememberInfiniteTransition(label = "capsule_aura")
  val auraCycle by auraTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = if (settings.auraAnimationIndex == 4) 1100 else 2800),
      repeatMode = RepeatMode.Restart
    ),
    label = "aura_cycle"
  )
  val pulseGlow by auraTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = if (settings.auraAnimationIndex == 4) 650 else 1500),
      repeatMode = RepeatMode.Reverse
    ),
    label = "aura_pulse"
  )

  val effectiveCapsuleStyle = if (settings.isLiquidGlassCapsule && settings.capsuleStyleIndex == 0) 3 else settings.capsuleStyleIndex
  val isMinimalStyle = effectiveCapsuleStyle == 2 && !settings.isLiquidGlassCapsule
  val capsuleAlpha = if (!settings.capsuleTransparent) {
    1.0f
  } else {
    (settings.capsuleOpacityPercent / 100f).coerceIn(0.40f, 0.96f)
  }
  val defaultFillBase = when (effectiveCapsuleStyle) {
    3 -> Color(0xFF120F0B)
    4 -> Color(0xFF1A1E26)
    5 -> Color(0xFF070C12)
    else -> Color(0xFF0D0B09)
  }
  val resolvedFillBase = if (settings.useCustomColors && settings.customCapsuleBgColor != null) {
    Color(settings.customCapsuleBgColor)
  } else {
    defaultFillBase
  }
  val glassBaseFill = resolvedFillBase.copy(alpha = capsuleAlpha)

  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Surface(
      modifier = Modifier
        .testTag(if (isExpanded) "expanded_capsule_card" else "mini_capsule_surface")
        .graphicsLayer {
          translationX = dragOffsetX.value
          translationY = dragOffsetY.value
          rotationX = anim3DTilt
          val distance = kotlin.math.hypot(dragOffsetX.value.toDouble(), dragOffsetY.value.toDouble()).toFloat()
          alpha = (1f - (distance / (dismissThresholdPx * 2.2f))).coerceIn(0.25f, 1f)
        }
        .pointerInput(isExpanded) {
          detectDragGestures(
            onDrag = { change, dragAmount ->
              change.consume()
              scope.launch {
                dragOffsetX.snapTo(dragOffsetX.value + dragAmount.x)
                dragOffsetY.snapTo((dragOffsetY.value + dragAmount.y).coerceAtMost(25f))
              }
            },
            onDragEnd = {
              val x = dragOffsetX.value
              val y = dragOffsetY.value
              val swipedRight = x > dismissThresholdPx
              val swipedLeft = x < -dismissThresholdPx
              val swipedUp = y < -dismissThresholdPx

              if (swipedRight || swipedLeft || swipedUp) {
                triggerHaptic()
                scope.launch {
                  val targetX = if (swipedRight) x + 600f else if (swipedLeft) x - 600f else x
                  val targetY = if (swipedUp) y - 500f else y
                  launch { dragOffsetX.animateTo(targetX, spring(stiffness = Spring.StiffnessMedium)) }
                  launch { dragOffsetY.animateTo(targetY, spring(stiffness = Spring.StiffnessMedium)) }
                  delay(90)
                  onDismissToNotification()
                  dragOffsetX.snapTo(0f)
                  dragOffsetY.snapTo(0f)
                }
              } else {
                scope.launch {
                  launch { dragOffsetX.animateTo(0f, spring(dampingRatio = Spring.DampingRatioLowBouncy)) }
                  launch { dragOffsetY.animateTo(0f, spring(dampingRatio = Spring.DampingRatioLowBouncy)) }
                }
              }
            },
            onDragCancel = {
              scope.launch {
                launch { dragOffsetX.animateTo(0f) }
                launch { dragOffsetY.animateTo(0f) }
              }
            }
          )
        }
        .width(animatedWidth)
        .height(animatedHeight)
        .shadow(
          elevation = when {
            effectiveCapsuleStyle in listOf(1, 4, 5) || settings.auraAnimationIndex in 1..4 -> if (isExpanded) 28.dp else 20.dp
            effectiveCapsuleStyle == 3 -> if (isExpanded) 28.dp else 18.dp
            isMinimalStyle -> if (isExpanded) 14.dp else 10.dp
            else -> if (isExpanded) 24.dp else 16.dp
          },
          shape = RoundedCornerShape(animatedCornerRadius),
          spotColor = when {
            settings.auraAnimationIndex == 1 -> ObsidianPrimary.copy(alpha = 0.68f)
            settings.auraAnimationIndex == 2 -> activityGlowColor.copy(alpha = (0.35f + 0.50f * pulseGlow))
            settings.auraAnimationIndex == 3 -> ObsidianSecondary.copy(alpha = 0.70f)
            settings.auraAnimationIndex == 4 -> activityGlowColor.copy(alpha = (0.38f + 0.48f * pulseGlow))
            effectiveCapsuleStyle == 3 -> activityGlowColor.copy(alpha = if (isExpanded) 0.48f else 0.36f)
            effectiveCapsuleStyle == 4 -> Color(0xFFE2E8F0).copy(alpha = 0.52f)
            effectiveCapsuleStyle == 5 -> Color(0xFF00F5D4).copy(alpha = 0.58f)
            else -> when (effectiveCapsuleStyle) {
              1 -> activityGlowColor.copy(alpha = 0.65f)
              2 -> activityGlowColor.copy(alpha = 0.24f)
              else -> activityGlowColor.copy(alpha = if (isExpanded) 0.48f else 0.38f)
            }
          },
          ambientColor = activityGlowColor.copy(alpha = if (isMinimalStyle) 0.14f else 0.26f)
        )
        .clip(RoundedCornerShape(animatedCornerRadius))
        .background(glassBaseFill)
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color.White.copy(
                alpha = when {
                  !settings.capsuleTransparent -> 0.04f
                  effectiveCapsuleStyle == 4 -> if (isExpanded) 0.18f else 0.24f
                  effectiveCapsuleStyle == 3 && !isExpanded -> 0.20f
                  effectiveCapsuleStyle == 3 && isExpanded -> 0.14f
                  isMinimalStyle -> 0.08f
                  isExpanded -> 0.09f
                  else -> 0.13f
                }
              ),
              Color.Transparent,
              activityGlowColor.copy(
                alpha = when {
                  !settings.capsuleTransparent -> 0.02f
                  isMinimalStyle -> 0.03f
                  effectiveCapsuleStyle in listOf(3, 5) -> 0.10f
                  else -> 0.06f
                }
              )
            )
          )
        )
        .border(
          width = if (effectiveCapsuleStyle in listOf(1, 3, 4, 5) || settings.auraAnimationIndex in 1..4) 1.35.dp else 1.1.dp,
          brush = rememberAnimatedCapsuleBorderBrush(
            styleIndex = effectiveCapsuleStyle,
            auraAnimationIndex = settings.auraAnimationIndex,
            auraCycle = auraCycle,
            pulseGlow = pulseGlow,
            accentColor = activityGlowColor,
            isExpanded = isExpanded
          ),
          shape = RoundedCornerShape(animatedCornerRadius)
        )
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = {
            if (!isExpanded && dragOffsetX.value == 0f && dragOffsetY.value == 0f) {
              triggerHaptic()
              onModeChange(CapsuleMode.EXPANDED)
            }
          }
        ),
      color = Color.Transparent,
      shape = RoundedCornerShape(animatedCornerRadius)
    ) {
      AnimatedContent(
        targetState = isExpanded,
        transitionSpec = {
          when (settings.openAnimationIndex) {
            1 -> (fadeIn(tween(220)) + scaleIn(initialScale = 0.80f, animationSpec = spring(dampingRatio = 0.52f)))
              .togetherWith(fadeOut(tween(150)) + scaleOut(targetScale = 0.84f))
            2 -> (fadeIn(tween(200)) + slideInVertically(initialOffsetY = { -it / 3 }))
              .togetherWith(fadeOut(tween(150)) + slideOutVertically(targetOffsetY = { -it / 4 }))
            3 -> (fadeIn(tween(220)) + scaleIn(initialScale = 0.85f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)))
              .togetherWith(fadeOut(tween(140)) + scaleOut(targetScale = 0.90f))
            4 -> fadeIn(tween(110)).togetherWith(fadeOut(tween(90)))
            else -> (fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
              scaleIn(initialScale = 0.94f, animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy)))
              .togetherWith(
                fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
                  scaleOut(targetScale = 0.94f, animationSpec = spring())
              )
          }
        },
        label = "capsule_morphing_content"
      ) { expanded ->
        if (expanded) {
          ExpandedDynamicContent(
            trackInfo = trackInfo,
            settings = settings,
            accentColor = accentColor,
            activeCard = primaryMiniCard ?: activeCard,
            batteryState = batteryState,
            callState = callState,
            timerState = timerState,
            sleepTimerState = sleepTimerState,
            nextAlarmState = nextAlarmState,
            notifEvent = notifEvent,
            bluetooth = bluetooth,
            flashlight = flashlight,
            ringer = ringer,
            currentSoundMode = currentSoundMode,
            downloadState = downloadState,
            navigationState = navigationState,
            privacyState = privacyState,
            networkState = networkState,
            volumeState = volumeState,
            weatherState = weatherState,
            stepsState = stepsState,
            compassState = compassState,
            focusState = focusState,
            onTabSelected = { expandedActiveTab = it },
            onHaptic = triggerHaptic,
            onCollapse = {
              triggerHaptic()
              onModeChange(CapsuleMode.MINI)
            },
            onPlayPauseClick = {
              triggerHaptic()
              onPlayPauseClick()
            },
            onNextClick = {
              triggerHaptic()
              onNextClick()
            },
            onPrevClick = {
              triggerHaptic()
              onPrevClick()
            },
            onSeek = onSeek
          )
        } else {
          MediumDynamicContent(
            trackInfo = trackInfo,
            settings = settings,
            accentColor = accentColor,
            primaryCard = primaryMiniCard,
            batteryState = batteryState,
            callState = callState,
            timerState = timerState,
            sleepTimerState = sleepTimerState,
            notifEvent = notifEvent,
            bluetooth = bluetooth,
            flashlight = flashlight,
            ringer = ringer,
            downloadState = downloadState,
            navigationState = navigationState,
            privacyState = privacyState,
            networkState = networkState,
            volumeState = volumeState,
            weatherState = weatherState,
            stepsState = stepsState,
            compassState = compassState,
            focusState = focusState
          )
        }
      }
    }

    // Feature #3: Detached Secondary Circular Pill when 2+ live activities are running
    AnimatedVisibility(
      visible = !isExpanded && settings.enableDualCapsule && secondaryMiniCard != null,
      enter = fadeIn() + scaleIn(initialScale = 0.7f),
      exit = fadeOut() + scaleOut(targetScale = 0.7f)
    ) {
      secondaryMiniCard?.let { secCard ->
        SecondaryMiniPill(
          card = secCard,
          trackInfo = trackInfo,
          timerState = timerState,
          downloadState = downloadState,
          privacyState = privacyState,
          weatherState = weatherState,
          accentColor = accentColor,
          capsuleStyleIndex = effectiveCapsuleStyle,
          fillColor = glassBaseFill,
          isTransparent = settings.capsuleTransparent,
          sizeDp = settings.capsuleHeightDp.dp,
          onClick = {
            triggerHaptic()
            IslandStateManager.selectCard(secCard)
          }
        )
      }
    }
  }
}

@Composable
private fun SecondaryMiniPill(
  card: IslandActiveCard,
  trackInfo: MediaTrackInfo?,
  timerState: TimerState,
  downloadState: DownloadState,
  privacyState: PrivacyState,
  weatherState: WeatherState,
  accentColor: Color,
  capsuleStyleIndex: Int,
  fillColor: Color,
  isTransparent: Boolean,
  sizeDp: Dp,
  onClick: () -> Unit
) {
  val isGlass = capsuleStyleIndex == 3
  val pillGlowColor = resolveActivityGlowColor(
    card = card,
    accentColor = accentColor,
    weatherIsWarning = weatherState.isWarning,
    privacyIsAudio = privacyState.isMicInUse || privacyState.isVoiceRecorderActive,
    volumeIsMuted = false,
    batteryLevel = 80,
    batteryCharging = false
  )
  Box(
    modifier = Modifier
      .testTag("secondary_capsule_pill")
      .size(sizeDp)
      .shadow(
        elevation = if (capsuleStyleIndex == 2) 8.dp else 14.dp,
        shape = CircleShape,
        spotColor = when (capsuleStyleIndex) {
          2 -> pillGlowColor.copy(alpha = 0.28f)
          3 -> pillGlowColor.copy(alpha = 0.48f)
          4 -> Color(0xFFE2E8F0).copy(alpha = 0.45f)
          5 -> Color(0xFF00F5D4).copy(alpha = 0.52f)
          else -> pillGlowColor.copy(alpha = 0.45f)
        }
      )
      .clip(CircleShape)
      .background(fillColor)
      .background(
        Brush.verticalGradient(
          listOf(
            Color(0xFFFFF5E4).copy(alpha = if (!isTransparent) 0.04f else if (isGlass || capsuleStyleIndex == 4) 0.18f else 0.12f),
            Color.Transparent,
            pillGlowColor.copy(alpha = if (!isTransparent) 0.02f else 0.08f)
          )
        )
      )
      .border(
        width = if (capsuleStyleIndex in listOf(1, 3, 4, 5)) 1.35.dp else 1.1.dp,
        brush = when (capsuleStyleIndex) {
          1 -> Brush.linearGradient(listOf(pillGlowColor, ObsidianPrimary, ObsidianSecondary))
          2 -> Brush.verticalGradient(listOf(Color(0xFFFFF4E0).copy(alpha = 0.22f), pillGlowColor.copy(alpha = 0.26f)))
          3 -> Brush.linearGradient(
            listOf(Color(0xFFFFF4E0).copy(alpha = 0.68f), pillGlowColor.copy(alpha = 0.36f), Color(0xFFFFF4E0).copy(alpha = 0.38f))
          )
          4 -> Brush.linearGradient(
            listOf(Color(0xFFF8FAFC).copy(alpha = 0.85f), Color(0xFF64748B).copy(alpha = 0.45f), Color(0xFFE2E8F0).copy(alpha = 0.78f))
          )
          5 -> Brush.linearGradient(
            listOf(Color(0xFF00F5D4), Color(0xFFFF2D55), pillGlowColor)
          )
          else -> Brush.verticalGradient(listOf(Color(0xFFFFF4E0).copy(alpha = 0.24f), pillGlowColor.copy(alpha = 0.52f)))
        },
        shape = CircleShape
      )
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    when (card) {
      IslandActiveCard.TIMER -> {
        val total = if (timerState.totalSeconds > 0) timerState.totalSeconds else timerState.remainingSeconds.coerceAtLeast(1)
        val progress = if (timerState.isStopwatch) {
          ((timerState.elapsedSeconds % 60) / 60f).coerceIn(0f, 1f)
        } else {
          (timerState.remainingSeconds.toFloat() / total.toFloat()).coerceIn(0f, 1f)
        }
        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
          drawArc(
            color = Color(0xFF2C2F38),
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            style = Stroke(width = 2.5.dp.toPx())
          )
          drawArc(
            color = Color(0xFFFFB74D),
            startAngle = -90f,
            sweepAngle = 360f * progress,
            useCenter = false,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
          )
        }
        Icon(
          imageVector = if (timerState.isStopwatch) Icons.Default.Timer else Icons.Default.HourglassTop,
          contentDescription = "Switch to Timer",
          tint = Color(0xFFFFB74D),
          modifier = Modifier.size(17.dp)
        )
      }
      IslandActiveCard.MUSIC -> {
        if (trackInfo?.albumArt != null) {
          Image(
            bitmap = trackInfo.albumArt.asImageBitmap(),
            contentDescription = "Switch to Music",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .fillMaxSize()
              .padding(5.dp)
              .clip(CircleShape)
          )
        } else {
          MiniWaveformVisualizer(isPlaying = trackInfo?.isPlaying == true, color = accentColor, barCount = 3, width = 16.dp, height = 14.dp)
        }
      }
      IslandActiveCard.NAVIGATION -> {
        Icon(Icons.Default.Navigation, contentDescription = "Switch to Navigation", tint = Color(0xFF4285F4), modifier = Modifier.size(19.dp))
      }
      IslandActiveCard.DOWNLOAD -> {
        val frac = (downloadState.progress.toFloat() / downloadState.max.coerceAtLeast(1)).coerceIn(0f, 1f)
        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
          drawArc(
            color = Color(0xFF2C2F38),
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            style = Stroke(width = 2.5.dp.toPx())
          )
          drawArc(
            color = Color(0xFF00E5FF),
            startAngle = -90f,
            sweepAngle = 360f * frac,
            useCenter = false,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
          )
        }
        Icon(Icons.Default.Download, contentDescription = "Switch to Download", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
      }
      IslandActiveCard.FLASHLIGHT -> {
        Icon(Icons.Default.FlashlightOn, contentDescription = "Switch to Flashlight", tint = Color(0xFFFFD600), modifier = Modifier.size(19.dp))
      }
      IslandActiveCard.PRIVACY -> {
        val tint = if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) Color(0xFFFF9500) else Color(0xFF34C759)
        Icon(
          imageVector = if (privacyState.isCameraInUse && !privacyState.isMicInUse) Icons.Default.Videocam else Icons.Default.Mic,
          contentDescription = "Switch to Privacy / Recorder",
          tint = tint,
          modifier = Modifier.size(18.dp)
        )
      }
      IslandActiveCard.CALL -> {
        Icon(Icons.Default.Call, contentDescription = "Switch to Call", tint = RealmeGreen, modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.SLEEP_TIMER -> {
        Icon(Icons.Default.Bedtime, contentDescription = "Switch to Sleep Timer", tint = Color(0xFF9C88FF), modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.STEPS -> {
        Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = "Switch to Steps", tint = RealmeGreen, modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.WEATHER -> {
        val (wIcon, wColor) = weatherIconAndColor(weatherState.weatherCode, weatherState.isDay, weatherState.isWarning)
        Icon(wIcon, contentDescription = "Switch to Weather", tint = wColor, modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.BLUETOOTH -> {
        Icon(Icons.Default.Headphones, contentDescription = "Switch to Bluetooth", tint = accentColor, modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.COMPASS -> {
        Icon(Icons.Default.Explore, contentDescription = "Switch to Compass", tint = accentColor, modifier = Modifier.size(18.dp))
      }
      IslandActiveCard.FOCUS -> {
        Icon(Icons.Default.CenterFocusStrong, contentDescription = "Switch to Focus Timer", tint = Color(0xFFFF6E6E), modifier = Modifier.size(18.dp))
      }
      else -> {
        Icon(Icons.Default.GraphicEq, contentDescription = "Switch Activity", tint = accentColor, modifier = Modifier.size(18.dp))
      }
    }
  }
}

@Composable
private fun rememberAnimatedCapsuleBorderBrush(
  styleIndex: Int,
  auraAnimationIndex: Int,
  auraCycle: Float,
  pulseGlow: Float,
  accentColor: Color,
  isExpanded: Boolean
): Brush {
  val angleRad = (auraCycle * 2f * PI).toFloat()
  val dx = cos(angleRad) * 260f
  val dy = sin(angleRad) * 140f

  return when (auraAnimationIndex) {
    // 1. Spinning Gold-Emerald-Coral Aura
    1 -> Brush.linearGradient(
      colors = listOf(
        ObsidianPrimary,
        ObsidianSecondary,
        ObsidianTertiary,
        accentColor,
        ObsidianPrimary
      ),
      start = Offset(180f - dx, 60f - dy),
      end = Offset(180f + dx, 60f + dy)
    )
    // 2. Breathing Pulse
    2 -> SolidColor(accentColor.copy(alpha = (0.20f + 0.72f * pulseGlow).coerceIn(0f, 1f)))
    // 3. Dual Amber/Jade Sweep
    3 -> Brush.linearGradient(
      colors = listOf(
        Color(0xFF1D1813),
        ObsidianPrimary,
        ObsidianSecondary,
        accentColor,
        Color(0xFF1D1813)
      ),
      start = Offset((auraCycle * 520f) - 180f, 0f),
      end = Offset((auraCycle * 520f) + 120f, 160f),
      tileMode = TileMode.Mirror
    )
    // 4. Reactive EQ Halo
    4 -> Brush.linearGradient(
      colors = listOf(
        accentColor.copy(alpha = 0.45f + 0.50f * pulseGlow),
        ObsidianSecondary.copy(alpha = 0.55f + 0.40f * (1f - pulseGlow)),
        ObsidianPrimary.copy(alpha = 0.45f + 0.50f * pulseGlow)
      ),
      start = Offset(0f, 0f),
      end = Offset(320f, 120f)
    )
    // 0. Static Glassmorphism Style (depends on capsuleStyleIndex)
    else -> when (styleIndex) {
      1 -> Brush.linearGradient(
        colors = listOf(accentColor, ObsidianPrimary, ObsidianSecondary)
      )
      2 -> Brush.verticalGradient(
        colors = listOf(
          Color(0xFFFFF4E0).copy(alpha = 0.24f),
          accentColor.copy(alpha = 0.28f)
        )
      )
      3 -> Brush.linearGradient(
        colors = listOf(
          Color(0xFFFFF4E0).copy(alpha = 0.72f),
          accentColor.copy(alpha = 0.40f),
          Color(0xFFFFF4E0).copy(alpha = 0.18f),
          ObsidianSecondary.copy(alpha = 0.44f)
        )
      )
      // 4. Metallic Chrome Silver
      4 -> Brush.linearGradient(
        colors = listOf(
          Color(0xFFF8FAFC).copy(alpha = 0.88f),
          Color(0xFF94A3B8).copy(alpha = 0.45f),
          Color(0xFFE2E8F0).copy(alpha = 0.85f),
          accentColor.copy(alpha = 0.42f)
        )
      )
      // 5. Dual Neon Matrix (Cyber Teal + Rose + Accent)
      5 -> Brush.linearGradient(
        colors = listOf(
          Color(0xFF00F5D4),
          Color(0xFFFF2D55),
          accentColor,
          Color(0xFF00BBF9)
        )
      )
      else -> Brush.verticalGradient(
        colors = listOf(
          Color(0xFFFFF4E0).copy(alpha = if (isExpanded) 0.26f else 0.22f),
          accentColor.copy(alpha = if (isExpanded) 0.55f else 0.42f)
        )
      )
    }
  }
}

private fun resolveActivityGlowColor(
  card: IslandActiveCard?,
  accentColor: Color,
  weatherIsWarning: Boolean,
  privacyIsAudio: Boolean,
  volumeIsMuted: Boolean,
  batteryLevel: Int,
  batteryCharging: Boolean
): Color = when (card) {
  IslandActiveCard.CALL, IslandActiveCard.STEPS -> ObsidianSuccess
  IslandActiveCard.FLASHLIGHT, IslandActiveCard.TIMER -> ObsidianWarning
  IslandActiveCard.BLUETOOTH, IslandActiveCard.SLEEP_TIMER, IslandActiveCard.COMPASS -> ObsidianSecondary
  IslandActiveCard.WEATHER -> if (weatherIsWarning) ObsidianWarning else ObsidianPrimary
  IslandActiveCard.NAVIGATION, IslandActiveCard.DOWNLOAD, IslandActiveCard.NETWORK -> ObsidianPrimary
  IslandActiveCard.FOCUS -> ObsidianTertiary
  IslandActiveCard.PRIVACY -> if (privacyIsAudio) ObsidianWarning else ObsidianSuccess
  IslandActiveCard.VOLUME -> if (volumeIsMuted) ObsidianError else accentColor
  IslandActiveCard.BATTERY -> when {
    batteryLevel <= 20 && !batteryCharging -> ObsidianError
    else -> ObsidianSuccess
  }
  else -> accentColor
}

/**
 * Collapsed / Mini Dynamic Island Content
 */
@Composable
fun MediumDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  primaryCard: IslandActiveCard?,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  sleepTimerState: SleepTimerState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  ringer: RingerState,
  downloadState: DownloadState,
  navigationState: NavigationState,
  privacyState: PrivacyState,
  networkState: NetworkState,
  volumeState: VolumeState,
  weatherState: WeatherState,
  stepsState: StepsState,
  compassState: CompassState,
  focusState: FocusState
) {
  val context = LocalContext.current
  val isPlaying = trackInfo?.isPlaying == true

  // Real-time position ticker so the elapsed time ("الوقت الذي ذهب") updates smoothly
  var livePos by remember(trackInfo?.lastUpdateTime, trackInfo?.currentPositionMs) {
    mutableLongStateOf(trackInfo?.getEstimatedPositionMs() ?: 0L)
  }
  LaunchedEffect(trackInfo, isPlaying) {
    while (isActive && isPlaying) {
      delay(500)
      livePos = trackInfo?.getEstimatedPositionMs() ?: 0L
    }
  }

  Row(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    when (primaryCard) {
      // 0a. Live Volume Bar Alert
      IslandActiveCard.VOLUME -> {
        val volFraction = (volumeState.volume.toFloat() / volumeState.maxVolume.coerceAtLeast(1)).coerceIn(0f, 1f)
        val volColor = if (volumeState.isMuted) Color(0xFFFF453A) else accentColor
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = if (volumeState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
            contentDescription = "الصوت",
            tint = volColor,
            modifier = Modifier.size(18.dp)
          )
          Box(
            modifier = Modifier
              .weight(1f)
              .height(6.dp)
              .clip(CircleShape)
              .background(Color.White.copy(alpha = 0.16f))
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth(volFraction)
                .height(6.dp)
                .clip(CircleShape)
                .background(volColor)
            )
          }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (volumeState.isMuted) "مكتوم" else "${volumeState.percent}%",
          color = volColor,
          fontSize = 11.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 0b. Network, Wi-Fi, Mobile Data, Airplane Mode & Hotspot Alerts
      IslandActiveCard.NETWORK -> {
        val (netIcon, netColor, netBadge) = when (networkState.type) {
          NetworkEventType.WIFI_CONNECTED -> Triple(Icons.Default.Wifi, Color(0xFF00E5FF), "Wi-Fi")
          NetworkEventType.MOBILE_DATA -> Triple(Icons.Default.SignalCellularAlt, RealmeGreen, "4G/5G")
          NetworkEventType.NO_INTERNET -> Triple(Icons.Default.WifiOff, Color(0xFFFF453A), "مقطوع")
          NetworkEventType.AIRPLANE_ON -> Triple(Icons.Default.AirplanemodeActive, Color(0xFFFF9500), "طيران")
          NetworkEventType.AIRPLANE_OFF -> Triple(Icons.Default.AirplanemodeInactive, RealmeGreen, "متاح")
          NetworkEventType.HOTSPOT_ON -> Triple(Icons.Default.WifiTethering, Color(0xFFFFB74D), "بث نشط")
          NetworkEventType.HOTSPOT_OFF -> Triple(Icons.Default.WifiTetheringOff, TextSecondary, "متوقف")
        }
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(netColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = netIcon,
              contentDescription = networkState.title,
              tint = netColor,
              modifier = Modifier.size(16.dp)
            )
          }
          MarqueeFadingText(
            text = networkState.title.ifBlank { netBadge },
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(netColor.copy(alpha = 0.2f))
            .padding(horizontal = 7.dp, vertical = 2.dp)
        ) {
          Text(
            text = netBadge,
            color = netColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }
      // 1. Ringer / Sound Mode Alert (Ring, Vibrate, Silent, Muted DND)
      IslandActiveCard.RINGER -> {
        val modeColor = when (ringer.mode) {
          SoundMode.RING -> RealmeGreen
          SoundMode.VIBRATE -> Color(0xFFFFB74D)
          SoundMode.SILENT -> Color(0xFFFF9500)
          SoundMode.MUTED_DND -> Color(0xFFFF453A)
        }
        val modeIcon = when (ringer.mode) {
          SoundMode.RING -> Icons.Default.NotificationsActive
          SoundMode.VIBRATE -> Icons.Default.Vibration
          SoundMode.SILENT -> Icons.Default.NotificationsOff
          SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
        }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(modeColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = modeIcon,
              contentDescription = ringer.mode.labelAr,
              tint = modeColor,
              modifier = Modifier.size(16.dp)
            )
          }
          Text(
            text = ringer.mode.labelAr,
            color = modeColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(modeColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text(
            text = ringer.mode.badgeAr,
            color = Color.Black,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }

      // 3. Flashlight ON: Yellow icon + label + direct turn off button
      IslandActiveCard.FLASHLIGHT -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFD600)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.FlashlightOn,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(17.dp)
            )
          }
          Text(
            text = "المصباح مفعّل",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFF332A00))
            .clickable { IslandStateManager.turnOffFlashlight(context) }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("إطفاء", color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
      }

      // 4. Call Ongoing / Incoming (Screenshot 4)
      IslandActiveCard.CALL -> {
        if (callState.isIncoming) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f, fill = false)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            Column {
              Text("مكالمة واردة", color = Color(0xFFFF9500), fontSize = 9.sp, fontWeight = FontWeight.Bold)
              MarqueeFadingText(
                text = callState.callerName,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(15.dp))
            }
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFF34C759))
                .clickable { IslandStateManager.answerCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(15.dp))
            }
          }
        } else {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            MarqueeFadingText(
              text = callState.callerName,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(13.dp))
            }
          }
        }
      }

      // 5. Battery Event (Charging, Low Battery Alert, Full Charge Alert, or Power Saver)
      IslandActiveCard.BATTERY -> {
        val batteryColor = when {
          batteryState.isLowAlert -> Color(0xFFFF453A)
          batteryState.isPowerSaveMode && !batteryState.isCharging -> Color(0xFFFFB74D)
          else -> RealmeGreen
        }
        val batteryLabel = when {
          batteryState.isLowAlert -> "بطارية منخفضة"
          batteryState.isFullAlert -> "اكتمل الشحن"
          batteryState.isPowerSaveMode && !batteryState.isCharging -> "توفير الطاقة"
          else -> "جارٍ الشحن"
        }
        Text(batteryLabel, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("${batteryState.percentage}%", color = batteryColor, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
          Icon(
            imageVector = if (batteryState.isLowAlert) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
            contentDescription = batteryLabel,
            tint = batteryColor,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      // 6. App Notification Banner
      IslandActiveCard.NOTIFICATION if notifEvent != null -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Notifications, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
          MarqueeFadingText(
            text = "${notifEvent.appName}: ${notifEvent.title}",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      // 6b. Sleep Timer Active
      IslandActiveCard.SLEEP_TIMER -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Bedtime, contentDescription = "مؤقت النوم", tint = Color(0xFFB388FF), modifier = Modifier.size(16.dp))
          Text("مؤقت النوم", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(
          text = sleepTimerState.formatRemaining(),
          color = Color(0xFFB388FF),
          fontSize = 13.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 7. Timer / Stopwatch Active (Syncs automatically with Clock app or internal timer)
      IslandActiveCard.TIMER -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFB74D).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (timerState.isStopwatch) Icons.Default.Timer else Icons.Default.HourglassTop,
              contentDescription = null,
              tint = Color(0xFFFFB74D),
              modifier = Modifier.size(16.dp)
            )
          }
          MarqueeFadingText(
            text = if (timerState.isRunning) timerState.title else "${timerState.title} (متوقف)",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = timerState.formatRemaining(),
          color = if (timerState.isRunning) Color(0xFFFFB74D) else TextMuted,
          fontSize = 13.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 8. Live Navigation (Google Maps / Waze, zero API)
      IslandActiveCard.NAVIGATION -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (navigationState.directionIcon != null) {
            Image(
              bitmap = navigationState.directionIcon.asImageBitmap(),
              contentDescription = "Direction",
              modifier = Modifier
                .size(26.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF1A3A6A))
                .padding(2.dp)
            )
          } else {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFF4285F4).copy(alpha = 0.22f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Navigation, contentDescription = null, tint = Color(0xFF4285F4), modifier = Modifier.size(16.dp))
            }
          }
          MarqueeFadingText(
            text = navigationState.instruction,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        if (navigationState.distanceOrStreet.isNotBlank() || navigationState.etaText.isNotBlank()) {
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = navigationState.etaText.ifBlank { navigationState.distanceOrStreet },
            color = Color(0xFF66B2FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
          )
        }
      }

      // 9. Camera, Mic & Voice Recorder Privacy Indicator
      IslandActiveCard.PRIVACY -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(
                if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive)
                  Color(0xFFFF9500).copy(alpha = 0.2f)
                else
                  Color(0xFF34C759).copy(alpha = 0.2f)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (privacyState.isCameraInUse && !privacyState.isMicInUse && !privacyState.isVoiceRecorderActive)
                Icons.Default.Videocam else Icons.Default.Mic,
              contentDescription = null,
              tint = if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) Color(0xFFFF9500) else Color(0xFF34C759),
              modifier = Modifier.size(16.dp)
            )
          }
          MarqueeFadingText(
            text = when {
              privacyState.isVoiceRecorderActive -> privacyState.recorderTitle
              privacyState.isCameraInUse && privacyState.isMicInUse -> "الكاميرا والميكروفون نشطان"
              privacyState.isCameraInUse -> "الكاميرا قيد الاستخدام"
              else -> "الميكروفون قيد الاستخدام"
            },
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        if (privacyState.isVoiceRecorderActive) {
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = privacyState.formatElapsed(),
            color = Color(0xFFFF453A),
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }

      // 10. Real Download / Install Progress
      IslandActiveCard.DOWNLOAD -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFF00E5FF).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
          }
          MarqueeFadingText(
            text = downloadState.title,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (downloadState.isIndeterminate) "..." else "${downloadState.percent}%",
          color = Color(0xFF00E5FF),
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      // 11. Bluetooth / Wired Headset Connected (with battery %)
      IslandActiveCard.BLUETOOTH -> {
        MiniBluetoothContent(bluetooth = bluetooth, accentColor = accentColor)
      }

      // 11b. Live Weather
      IslandActiveCard.WEATHER -> {
        MiniWeatherContent(weatherState = weatherState)
      }

      // 11c. Step Counter & Distance
      IslandActiveCard.STEPS -> {
        MiniStepsContent(stepsState = stepsState)
      }

      // 11d. Live Digital Compass
      IslandActiveCard.COMPASS -> {
        MiniCompassContent(compass = compassState, accentColor = accentColor)
      }

      // 11e. Pomodoro Focus Timer
      IslandActiveCard.FOCUS -> {
        MiniFocusContent(focus = focusState)
      }

      // 12. Music Playing (Real-time elapsed time counter + Marquee + Waveform)
      IslandActiveCard.MUSIC if trackInfo != null -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (trackInfo.albumArt != null) {
            Image(
              bitmap = trackInfo.albumArt.asImageBitmap(),
              contentDescription = "Album Thumbnail",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(0.8.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
            )
          } else {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(accentColor.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Column(modifier = Modifier.weight(1f)) {
            MarqueeFadingText(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            MarqueeFadingText(
              text = trackInfo.artist,
              color = TextSecondary,
              fontSize = 10.sp,
              fontWeight = FontWeight.Normal
            )
          }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Real-time Elapsed Time ("الوقت الذي ذهب") + Mini Waveform
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Text(
            text = trackInfo.formatTime(livePos),
            color = accentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
          MiniWaveformVisualizer(
            isPlaying = true,
            color = accentColor,
            styleIndex = settings.visualizerStyleIndex,
            barCount = 4,
            width = 18.dp,
            height = 14.dp
          )
        }
      }

      // Idle state
      else -> {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(Color(0xFF1E2532))
          )
        }
      }
    }

    // Subtle iOS-style Privacy Dots when Camera or Microphone is active in background
    if (settings.enablePrivacyAlerts && primaryCard != IslandActiveCard.PRIVACY && (privacyState.isCameraInUse || privacyState.isMicInUse)) {
      Spacer(modifier = Modifier.width(6.dp))
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
      ) {
        if (privacyState.isCameraInUse) {
          Box(
            modifier = Modifier
              .size(7.dp)
              .clip(CircleShape)
              .background(Color(0xFF34C759))
          )
        }
        if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) {
          Box(
            modifier = Modifier
              .size(7.dp)
              .clip(CircleShape)
              .background(Color(0xFFFF9500))
          )
        }
      }
    }
  }
}

/**
 * Expanded Dynamic Island Content
 */
@Composable
fun ExpandedDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  sleepTimerState: SleepTimerState,
  nextAlarmState: NextAlarmState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  ringer: RingerState,
  currentSoundMode: SoundMode,
  downloadState: DownloadState,
  navigationState: NavigationState,
  privacyState: PrivacyState,
  networkState: NetworkState,
  volumeState: VolumeState,
  weatherState: WeatherState,
  stepsState: StepsState,
  compassState: CompassState,
  focusState: FocusState,
  onTabSelected: (IslandActiveCard) -> Unit = {},
  onHaptic: () -> Unit,
  onCollapse: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val context = LocalContext.current
  var currentSelectedTab by remember { mutableStateOf(activeCard) }
  LaunchedEffect(activeCard) {
    currentSelectedTab = activeCard
  }
  LaunchedEffect(currentSelectedTab) {
    onTabSelected(currentSelectedTab)
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 12.dp)
  ) {
    // Header Bar: Scrollable Activity Tabs + Immediate Collapse Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier
          .weight(1f)
          .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        TabIndicator(
          icon = Icons.Default.GraphicEq,
          isSelected = currentSelectedTab == IslandActiveCard.MUSIC,
          color = accentColor,
          onClick = { currentSelectedTab = IslandActiveCard.MUSIC }
        )

        if (navigationState.isActive) {
          TabIndicator(
            icon = Icons.Default.Navigation,
            isSelected = currentSelectedTab == IslandActiveCard.NAVIGATION,
            color = Color(0xFF4285F4),
            onClick = { currentSelectedTab = IslandActiveCard.NAVIGATION }
          )
        }

        if (privacyState.hasAnyActivity) {
          TabIndicator(
            icon = Icons.Default.Security,
            isSelected = currentSelectedTab == IslandActiveCard.PRIVACY,
            color = Color(0xFF34C759),
            onClick = { currentSelectedTab = IslandActiveCard.PRIVACY }
          )
        }

        if (timerState.isActive) {
          TabIndicator(
            icon = if (timerState.isStopwatch) Icons.Default.Timer else Icons.Default.HourglassTop,
            isSelected = currentSelectedTab == IslandActiveCard.TIMER,
            color = Color(0xFFFFB74D),
            onClick = { currentSelectedTab = IslandActiveCard.TIMER }
          )
        }

        if (downloadState.isActive) {
          TabIndicator(
            icon = Icons.Default.Download,
            isSelected = currentSelectedTab == IslandActiveCard.DOWNLOAD,
            color = Color(0xFF00E5FF),
            onClick = { currentSelectedTab = IslandActiveCard.DOWNLOAD }
          )
        }

        if (networkState.isActive) {
          TabIndicator(
            icon = Icons.Default.Wifi,
            isSelected = currentSelectedTab == IslandActiveCard.NETWORK,
            color = Color(0xFF00E5FF),
            onClick = { currentSelectedTab = IslandActiveCard.NETWORK }
          )
        }

        if (notifEvent != null) {
          TabIndicator(
            icon = Icons.Default.Notifications,
            isSelected = currentSelectedTab == IslandActiveCard.NOTIFICATION,
            color = accentColor,
            onClick = { currentSelectedTab = IslandActiveCard.NOTIFICATION }
          )
        }

        if (volumeState.isActive) {
          TabIndicator(
            icon = if (volumeState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
            isSelected = currentSelectedTab == IslandActiveCard.VOLUME,
            color = accentColor,
            onClick = { currentSelectedTab = IslandActiveCard.VOLUME }
          )
        }

        TabIndicator(
          icon = when (currentSoundMode) {
            SoundMode.RING -> Icons.AutoMirrored.Filled.VolumeUp
            SoundMode.VIBRATE -> Icons.Default.Vibration
            SoundMode.SILENT -> Icons.Default.NotificationsOff
            SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
          },
          isSelected = currentSelectedTab == IslandActiveCard.RINGER,
          color = Color(0xFFFF9500),
          onClick = { currentSelectedTab = IslandActiveCard.RINGER }
        )

        TabIndicator(
          icon = Icons.Default.Tune,
          isSelected = currentSelectedTab == IslandActiveCard.QUICK_CONTROLS,
          color = Color(0xFF64D2FF),
          onClick = { currentSelectedTab = IslandActiveCard.QUICK_CONTROLS }
        )

        if (flashlight.isOn) {
          TabIndicator(
            icon = Icons.Default.FlashlightOn,
            isSelected = currentSelectedTab == IslandActiveCard.FLASHLIGHT,
            color = Color(0xFFFFD600),
            onClick = { currentSelectedTab = IslandActiveCard.FLASHLIGHT }
          )
        }

        if (callState.isActive) {
          TabIndicator(
            icon = Icons.Default.Call,
            isSelected = currentSelectedTab == IslandActiveCard.CALL,
            color = RealmeGreen,
            onClick = { currentSelectedTab = IslandActiveCard.CALL }
          )
        }

        if (sleepTimerState.isActive) {
          TabIndicator(
            icon = Icons.Default.Bedtime,
            isSelected = currentSelectedTab == IslandActiveCard.SLEEP_TIMER,
            color = Color(0xFF9C88FF),
            onClick = { currentSelectedTab = IslandActiveCard.SLEEP_TIMER }
          )
        }

        if (bluetooth.isConnected || bluetooth.isAlertActive) {
          TabIndicator(
            icon = Icons.Default.Headphones,
            isSelected = currentSelectedTab == IslandActiveCard.BLUETOOTH,
            color = accentColor,
            onClick = { currentSelectedTab = IslandActiveCard.BLUETOOTH }
          )
        }

        if (settings.enableWeatherAlerts) {
          val (wIcon, wColor) = weatherIconAndColor(weatherState.weatherCode, weatherState.isDay, weatherState.isWarning)
          TabIndicator(
            icon = wIcon,
            isSelected = currentSelectedTab == IslandActiveCard.WEATHER,
            color = wColor,
            onClick = {
              if (!weatherState.isLoaded) {
                IslandStateManager.refreshWeather(context, showAlertBanner = false)
              }
              currentSelectedTab = IslandActiveCard.WEATHER
            }
          )
        }

        if (settings.enableStepsCounter) {
          TabIndicator(
            icon = Icons.AutoMirrored.Filled.DirectionsRun,
            isSelected = currentSelectedTab == IslandActiveCard.STEPS,
            color = RealmeGreen,
            onClick = { currentSelectedTab = IslandActiveCard.STEPS }
          )
        }

        if (settings.enableFocusTimer) {
          TabIndicator(
            icon = Icons.Default.CenterFocusStrong,
            isSelected = currentSelectedTab == IslandActiveCard.FOCUS,
            color = Color(0xFFFF6E6E),
            onClick = { currentSelectedTab = IslandActiveCard.FOCUS }
          )
        }

        if (settings.enableCompass && compassState.isActive) {
          TabIndicator(
            icon = Icons.Default.Explore,
            isSelected = currentSelectedTab == IslandActiveCard.COMPASS,
            color = accentColor,
            onClick = { currentSelectedTab = IslandActiveCard.COMPASS }
          )
        }
      }

      Spacer(modifier = Modifier.width(6.dp))

      // HyperIsland Live Telemetry Chip (Battery % or Earned Steps Stars)
      if (stepsState.starsToday > 0 || batteryState.isCharging) {
        Row(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.09f))
            .border(0.6.dp, Color.White.copy(alpha = 0.14f), CircleShape)
            .clickable {
              onHaptic()
              currentSelectedTab = if (batteryState.isCharging) IslandActiveCard.BATTERY else IslandActiveCard.STEPS
            }
            .padding(horizontal = 7.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
          if (batteryState.isCharging) {
            Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(11.dp))
            Text("${batteryState.percentage}%", color = RealmeGreen, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
          } else {
            Text("★${stepsState.starsToday}", color = Color(0xFFFFC107), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
          }
        }
        Spacer(modifier = Modifier.width(4.dp))
      }

      // Collapse Button
      IconButton(
        onClick = onCollapse,
        modifier = Modifier
          .testTag("collapse_capsule_button")
          .size(30.dp)
          .background(Color.White.copy(alpha = 0.12f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Rounded.KeyboardArrowUp,
          contentDescription = "Collapse Capsule",
          tint = TextPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Active Card View
    when (currentSelectedTab) {
      IslandActiveCard.NAVIGATION -> {
        ExpandedNavigationView(
          navigationState = navigationState,
          onOpenMaps = {
            IslandStateManager.openNavigationApp(context)
            onCollapse()
          },
          onStopNav = {
            IslandStateManager.stopNavigation()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.PRIVACY -> {
        ExpandedPrivacyView(
          privacyState = privacyState,
          onTogglePause = { IslandStateManager.toggleVoiceRecorderPause() },
          onStopRecorder = {
            IslandStateManager.stopVoiceRecorder()
            if (!privacyState.isCameraInUse && !privacyState.isMicInUse) {
              currentSelectedTab = IslandActiveCard.MUSIC
            }
          },
          onOpenRecorder = {
            IslandStateManager.openSourceApp(context, privacyState.recorderPackage)
            onCollapse()
          }
        )
      }
      IslandActiveCard.NETWORK -> {
        ExpandedNetworkView(
          networkState = networkState,
          onOpenSettings = {
            try {
              val action = when (networkState.type) {
                NetworkEventType.AIRPLANE_ON, NetworkEventType.AIRPLANE_OFF -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                NetworkEventType.MOBILE_DATA -> Settings.ACTION_DATA_ROAMING_SETTINGS
                else -> Settings.ACTION_WIFI_SETTINGS
              }
              val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
              context.startActivity(intent)
            } catch (_: Exception) {
              try {
                val fallback = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(fallback)
              } catch (_: Exception) {}
            }
            onCollapse()
          }
        )
      }
      IslandActiveCard.NOTIFICATION -> {
        ExpandedNotificationView(
          notifEvent = notifEvent,
          accentColor = accentColor,
          onOpenApp = {
            IslandStateManager.openActiveNotificationApp(context)
            onCollapse()
          }
        )
      }
      IslandActiveCard.VOLUME -> {
        ExpandedVolumeView(
          volumeState = volumeState,
          accentColor = accentColor,
          onToggleMute = {
            onHaptic()
            IslandStateManager.toggleMuteMedia(context)
          },
          onSetVolume = { newVol -> IslandStateManager.setMediaVolume(context, newVol) }
        )
      }
      IslandActiveCard.QUICK_CONTROLS -> {
        ExpandedQuickControlsView(
          accentColor = accentColor,
          flashlightOn = flashlight.isOn,
          currentSoundMode = currentSoundMode,
          sleepTimerState = sleepTimerState,
          nextAlarmState = nextAlarmState,
          onToggleFlashlight = {
            onHaptic()
            IslandStateManager.toggleFlashlight(context)
          },
          onCycleSoundMode = {
            onHaptic()
            IslandStateManager.cycleSoundMode(context)
          },
          onStartQuickTimer = { secs, label ->
            onHaptic()
            IslandStateManager.startTimer(secs, label)
            currentSelectedTab = IslandActiveCard.TIMER
          },
          onStartSleepTimer = { mins ->
            onHaptic()
            IslandStateManager.startSleepTimer(mins)
            currentSelectedTab = IslandActiveCard.SLEEP_TIMER
          },
          onCancelSleepTimer = {
            onHaptic()
            IslandStateManager.cancelSleepTimer()
          },
          onOpenAlarms = {
            onHaptic()
            IslandStateManager.openAlarmApp(context)
            onCollapse()
          },
          onOpenWeather = {
            onHaptic()
            IslandStateManager.refreshWeather(context, showAlertBanner = false)
            currentSelectedTab = IslandActiveCard.WEATHER
          },
          onOpenSteps = {
            onHaptic()
            currentSelectedTab = IslandActiveCard.STEPS
          },
          onOpenCompass = {
            onHaptic()
            IslandStateManager.openCompassCard(context)
            currentSelectedTab = IslandActiveCard.COMPASS
          },
          onOpenFocus = {
            onHaptic()
            currentSelectedTab = IslandActiveCard.FOCUS
          }
        )
      }
      IslandActiveCard.SLEEP_TIMER -> {
        ExpandedSleepTimerView(
          sleepTimerState = sleepTimerState,
          onStartMinutes = { mins ->
            onHaptic()
            IslandStateManager.startSleepTimer(mins)
          },
          onCancel = {
            onHaptic()
            IslandStateManager.cancelSleepTimer()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.RINGER -> {
        ExpandedRingerView(
          currentMode = currentSoundMode,
          onSelectMode = { mode ->
            onHaptic()
            IslandStateManager.setSoundMode(context, mode)
          }
        )
      }
      IslandActiveCard.FLASHLIGHT -> {
        ExpandedFlashlightView(
          flashlight = flashlight,
          onToggle = { IslandStateManager.toggleFlashlight(context) },
          onTurnOff = {
            IslandStateManager.turnOffFlashlight(context)
            if (trackInfo?.isPlaying == true) currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.TIMER -> {
        ExpandedTimerView(
          timerState = timerState,
          onTogglePause = { IslandStateManager.toggleTimerPause() },
          onCancel = { IslandStateManager.cancelTimer(); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      IslandActiveCard.DOWNLOAD -> {
        ExpandedDownloadView(
          downloadState = downloadState,
          onOpenApp = {
            IslandStateManager.openDownloadApp(context)
            onCollapse()
          },
          onDismiss = {
            IslandStateManager.clearDownloadProgress()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.BATTERY -> {
        ExpandedBatteryView(batteryState = batteryState)
      }
      IslandActiveCard.CALL -> {
        ExpandedCallView(
          callState = callState,
          onAnswer = { IslandStateManager.answerCall(context) },
          onDecline = { IslandStateManager.declineCall(context); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      IslandActiveCard.BLUETOOTH -> {
        ExpandedBluetoothView(
          bluetooth = bluetooth,
          accentColor = accentColor,
          context = context,
          onOpenSettings = onCollapse
        )
      }
      IslandActiveCard.WEATHER -> {
        LaunchedEffect(Unit) {
          IslandStateManager.ensureWeatherFresh(context)
        }
        ExpandedWeatherView(
          weatherState = weatherState,
          onRefresh = {
            onHaptic()
            IslandStateManager.refreshWeather(context, showAlertBanner = false)
          }
        )
      }
      IslandActiveCard.STEPS -> {
        ExpandedStepsView(
          stepsState = stepsState,
          onCycleGoal = {
            onHaptic()
            IslandStateManager.cycleStepsGoal()
          },
          onTogglePause = {
            onHaptic()
            IslandStateManager.toggleStepsPause()
          },
          onResetToday = {
            onHaptic()
            IslandStateManager.resetTodaySteps()
          }
        )
      }
      IslandActiveCard.COMPASS -> {
        ExpandedCompassView(
          compass = compassState,
          accentColor = accentColor,
          onStopCompass = {
            onHaptic()
            IslandStateManager.stopCompassCard()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.FOCUS -> {
        ExpandedFocusView(
          focus = focusState,
          onTogglePause = {
            onHaptic()
            IslandStateManager.toggleFocusPause()
          },
          onStartFocus = { mins, isBreak ->
            onHaptic()
            IslandStateManager.startFocusSession(mins, isBreak)
          },
          onCancel = {
            onHaptic()
            IslandStateManager.cancelFocusSession()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      else -> {
        ExpandedMusicView(
          trackInfo = trackInfo,
          accentColor = accentColor,
          onHaptic = onHaptic,
          onCollapse = onCollapse,
          onOpenMusicApp = {
            IslandStateManager.openSourceApp(context, trackInfo?.packageName)
            onCollapse()
          },
          onPlayPauseClick = onPlayPauseClick,
          onNextClick = onNextClick,
          onPrevClick = onPrevClick,
          onSeek = onSeek
        )
      }
    }
  }
}

@Composable
private fun TabIndicator(
  icon: ImageVector,
  isSelected: Boolean,
  color: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(26.dp)
      .clip(CircleShape)
      .background(if (isSelected) color.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f))
      .border(1.dp, if (isSelected) color else Color.Transparent, CircleShape)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isSelected) color else TextSecondary,
      modifier = Modifier.size(14.dp)
    )
  }
}

/**
 * Music Expanded Player with Audio Waveform Seekbar, Real Favorites & Functional Cast / Output Panel
 */
@Composable
fun ExpandedMusicView(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  onHaptic: () -> Unit = {},
  onCollapse: () -> Unit = {},
  onOpenMusicApp: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val context = LocalContext.current
  val favoritesManager = remember(context) { FavoriteTracksManager.getInstance(context) }
  val favorites by favoritesManager.favorites.collectAsState()
  val isPlaying = trackInfo?.isPlaying == true

  // Real-time position ticker so the elapsed time and waveform progress smoothly advance
  var livePositionMs by remember(trackInfo?.lastUpdateTime, trackInfo?.currentPositionMs) {
    mutableLongStateOf(trackInfo?.getEstimatedPositionMs() ?: 0L)
  }

  LaunchedEffect(trackInfo, isPlaying) {
    while (isActive && isPlaying) {
      delay(400)
      livePositionMs = trackInfo?.getEstimatedPositionMs() ?: 0L
    }
  }

  val rawDuration = trackInfo?.durationMs ?: 0L
  val hasValidDuration = rawDuration > 0L
  val duration = if (hasValidDuration) rawDuration else 180000L

  var isUserDragging by remember { mutableStateOf(false) }
  var dragPositionFraction by remember { mutableFloatStateOf(0f) }
  var repeatMode by remember { mutableIntStateOf(0) }
  var showCastPanel by remember { mutableStateOf(false) }
  var favoriteFeedback by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(favoriteFeedback) {
    if (favoriteFeedback != null) {
      delay(1800)
      favoriteFeedback = null
    }
  }

  val isFavorite = trackInfo != null && favorites.any {
    it.id == FavoriteTracksManager.buildTrackId(trackInfo.title, trackInfo.artist)
  }
  val isExternalCastConnected = remember(showCastPanel, trackInfo) {
    IslandStateManager.hasExternalCastOrAudio(context)
  }
  val outputSummary = remember(showCastPanel, trackInfo) {
    IslandStateManager.getAudioOutputSummary(context)
  }

  val effectiveFraction = if (isUserDragging) {
    dragPositionFraction
  } else if (hasValidDuration) {
    (livePositionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
  } else {
    ((livePositionMs % 60000L).toFloat() / 60000f)
  }

  Column(modifier = Modifier.fillMaxWidth()) {
    // Top Row: Album Cover + Track Title (Marquee) + Artist + Functional Cast/Screen-Share Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(14.dp))
          .clickable(enabled = !trackInfo?.packageName.isNullOrBlank(), onClick = onOpenMusicApp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (trackInfo?.albumArt != null) {
          Image(
            bitmap = trackInfo.albumArt.asImageBitmap(),
            contentDescription = "Album Art",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .size(50.dp)
              .clip(RoundedCornerShape(14.dp))
              .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
              .shadow(10.dp, RoundedCornerShape(14.dp), spotColor = accentColor.copy(alpha = 0.5f))
          )
        } else {
          Box(
            modifier = Modifier
              .size(50.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(
                Brush.linearGradient(
                  listOf(Color(0xFF263248), Color(0xFF131926))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.MusicNote,
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(26.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          MarqueeFadingText(
            text = trackInfo?.title ?: "Far closer",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(2.dp))
          MarqueeFadingText(
            text = favoriteFeedback ?: (trackInfo?.artist ?: "David"),
            color = if (favoriteFeedback != null) Color(0xFFFF6B81) else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (favoriteFeedback != null) FontWeight.SemiBold else FontWeight.Normal
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      // Functional Cast / Screen-Share & Output Switcher Button
      Box(
        modifier = Modifier
          .testTag("music_cast_button")
          .size(34.dp)
          .clip(CircleShape)
          .background(
            if (showCastPanel || isExternalCastConnected) accentColor.copy(alpha = 0.22f)
            else Color.White.copy(alpha = 0.09f)
          )
          .border(
            1.dp,
            if (showCastPanel || isExternalCastConnected) accentColor.copy(alpha = 0.7f) else Color.Transparent,
            CircleShape
          )
          .clickable {
            onHaptic()
            showCastPanel = !showCastPanel
          },
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Cast,
          contentDescription = "مشاركة مع شاشة وبث الصوت",
          tint = if (showCastPanel || isExternalCastConnected) accentColor else TextPrimary,
          modifier = Modifier.size(17.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    AnimatedContent(
      targetState = showCastPanel,
      transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(140)) },
      label = "music_or_cast_panel"
    ) { showingCast ->
      if (showingCast) {
        // Real Cast / Wireless Screen Share & Audio Output Panel
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, accentColor.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
            .padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "البث ومشاركة المقطع",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "المخرج الحالي: $outputSummary",
                color = accentColor,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
            Text(
              text = "رجوع",
              color = TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                  onHaptic()
                  showCastPanel = false
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            CastActionButton(
              icon = Icons.Default.Cast,
              label = "بث الشاشة",
              accentColor = accentColor,
              modifier = Modifier.weight(1f),
              onClick = {
                onHaptic()
                IslandStateManager.openScreenCastSettings(context)
                onCollapse()
              }
            )
            CastActionButton(
              icon = Icons.Default.Headphones,
              label = "مخرج الصوت",
              accentColor = Color(0xFF64D2FF),
              modifier = Modifier.weight(1f),
              onClick = {
                onHaptic()
                IslandStateManager.openMediaOutputSwitcher(context, trackInfo?.packageName)
                onCollapse()
              }
            )
            CastActionButton(
              icon = Icons.Default.Share,
              label = "مشاركة",
              accentColor = RealmeGreen,
              modifier = Modifier.weight(1f),
              onClick = {
                onHaptic()
                IslandStateManager.shareTrack(
                  context,
                  trackInfo?.title ?: "مقطع صوتي",
                  trackInfo?.artist ?: ""
                )
                onCollapse()
              }
            )
          }
        }
      } else {
        Column(modifier = Modifier.fillMaxWidth()) {
          val canSeek = trackInfo?.canSeek ?: true
          val canSkipNext = trackInfo?.canSkipNext ?: true
          val canSkipPrev = trackInfo?.canSkipPrevious ?: true

          // Controls Row: Repeat, Previous, Play/Pause, Next, Persistent Favorite
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = {
                onHaptic()
                repeatMode = (repeatMode + 1) % 3
              },
              modifier = Modifier.size(36.dp)
            ) {
              Icon(
                imageVector = if (repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
                contentDescription = "Repeat",
                tint = if (repeatMode > 0) accentColor else TextMuted,
                modifier = Modifier.size(19.dp)
              )
            }

            IconButton(
              onClick = {
                onHaptic()
                onPrevClick()
              },
              enabled = canSkipPrev,
              modifier = Modifier
                .testTag("prev_track_button")
                .size(40.dp)
                .background(Color.White.copy(alpha = if (canSkipPrev) 0.06f else 0.02f), CircleShape)
            ) {
              Icon(
                imageVector = Icons.Default.SkipPrevious,
                contentDescription = "Previous Track",
                tint = if (canSkipPrev) TextPrimary else TextMuted.copy(alpha = 0.4f),
                modifier = Modifier.size(22.dp)
              )
            }

            IconButton(
              onClick = {
                onHaptic()
                onPlayPauseClick()
              },
              modifier = Modifier
                .testTag("play_pause_button")
                .size(48.dp)
                .shadow(12.dp, CircleShape, spotColor = accentColor)
                .background(accentColor, CircleShape)
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.Black,
                modifier = Modifier.size(28.dp)
              )
            }

            IconButton(
              onClick = {
                onHaptic()
                onNextClick()
              },
              enabled = canSkipNext,
              modifier = Modifier
                .testTag("next_track_button")
                .size(40.dp)
                .background(Color.White.copy(alpha = if (canSkipNext) 0.06f else 0.02f), CircleShape)
            ) {
              Icon(
                imageVector = Icons.Default.SkipNext,
                contentDescription = "Next Track",
                tint = if (canSkipNext) TextPrimary else TextMuted.copy(alpha = 0.4f),
                modifier = Modifier.size(22.dp)
              )
            }

            IconButton(
              onClick = {
                onHaptic()
                if (trackInfo != null && trackInfo.title.isNotBlank()) {
                  val added = favoritesManager.toggleFavorite(trackInfo)
                  favoriteFeedback = if (added) "تمت الإضافة إلى المفضلة ♥" else "تمت الإزالة من المفضلة"
                }
              },
              modifier = Modifier
                .testTag("favorite_track_button")
                .size(36.dp)
                .background(
                  if (isFavorite) Color(0xFFFF5252).copy(alpha = 0.16f) else Color.Transparent,
                  CircleShape
                )
            ) {
              Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFavorite) "إزالة من المفضلة" else "إضافة إلى المفضلة",
                tint = if (isFavorite) Color(0xFFFF5252) else TextMuted,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Audio Waveform Interactive Progress Seekbar
          WaveformProgressSeekBar(
            trackKey = "${trackInfo?.title ?: "demo"}|${trackInfo?.artist ?: ""}",
            fraction = effectiveFraction,
            isPlaying = isPlaying,
            canSeek = canSeek,
            isDragging = isUserDragging,
            accentColor = accentColor,
            onFractionChange = { fraction ->
              if (canSeek) {
                isUserDragging = true
                dragPositionFraction = fraction
              }
            },
            onFractionFinished = { finalFraction ->
              if (canSeek) {
                val seekTargetMs = (finalFraction * duration).toLong()
                onSeek(seekTargetMs)
              }
              isUserDragging = false
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("track_progress_slider")
          )

          // Timestamp Row: Elapsed time + Total Duration
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            val displayPos = if (isUserDragging) (dragPositionFraction * duration).toLong() else livePositionMs
            Text(
              text = trackInfo?.formatTime(displayPos) ?: "00:00",
              color = TextPrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            )
            Text(
              text = if (hasValidDuration) (trackInfo?.formatTime(duration) ?: "00:00") else "--:--",
              color = TextMuted,
              fontSize = 11.sp
            )
          }

          if (!canSeek && trackInfo?.packageName?.contains("spotify", ignoreCase = true) == true) {
            Text(
              text = "التقديم غير متاح في خطة Spotify المجانية",
              color = Color(0xFF1DB954).copy(alpha = 0.75f),
              fontSize = 9.sp,
              fontWeight = FontWeight.Normal,
              textAlign = TextAlign.Center,
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 1.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CastActionButton(
  icon: ImageVector,
  label: String,
  accentColor: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(accentColor.copy(alpha = 0.14f))
      .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(vertical = 8.dp, horizontal = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = accentColor,
      modifier = Modifier.size(18.dp)
    )
    Text(
      text = label,
      color = TextPrimary,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

/**
 * Interactive Audio Waveform Seekbar rendered via Canvas with real touch drag/tap seeking
 */
@Composable
fun WaveformProgressSeekBar(
  trackKey: String,
  fraction: Float,
  isPlaying: Boolean,
  canSeek: Boolean,
  isDragging: Boolean,
  accentColor: Color,
  onFractionChange: (Float) -> Unit,
  onFractionFinished: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
  val barCount = 38

  // Deterministic musical silhouette per track
  val barHeights = remember(trackKey) {
    val seed = trackKey.hashCode()
    List(barCount) { index ->
      val t = index.toFloat() / (barCount - 1).coerceAtLeast(1)
      val envelope = 0.65f + 0.35f * kotlin.math.sin(t * Math.PI).toFloat()
      val wave1 = kotlin.math.sin((index * 0.62) + (seed and 0xFF) * 0.1).toFloat()
      val wave2 = kotlin.math.cos((index * 1.15) - ((seed ushr 8) and 0xFF) * 0.07).toFloat()
      val raw = 0.48f + 0.28f * wave1 + 0.18f * wave2
      (raw * envelope).coerceIn(0.20f, 0.96f)
    }
  }

  // Live gentle beat ripple while playing
  val pulseTransition = rememberInfiniteTransition(label = "waveform_seek_pulse")
  val beatPhase by pulseTransition.animateFloat(
    initialValue = 0f,
    targetValue = (Math.PI * 2).toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1200),
      repeatMode = RepeatMode.Restart
    ),
    label = "beat_phase"
  )

  var currentDragFraction by remember { mutableFloatStateOf(fraction) }

  Box(
    modifier = modifier
      .height(34.dp)
      .pointerInput(canSeek, isRtl) {
        if (!canSeek) return@pointerInput
        detectTapGestures { offset ->
          val w = size.width.toFloat().coerceAtLeast(1f)
          val rawFrac = (offset.x / w).coerceIn(0f, 1f)
          val logicalFrac = if (isRtl) 1f - rawFrac else rawFrac
          currentDragFraction = logicalFrac
          onFractionChange(logicalFrac)
          onFractionFinished(logicalFrac)
        }
      }
      .pointerInput(canSeek, isRtl) {
        if (!canSeek) return@pointerInput
        detectHorizontalDragGestures(
          onDragStart = { offset ->
            val w = size.width.toFloat().coerceAtLeast(1f)
            val rawFrac = (offset.x / w).coerceIn(0f, 1f)
            val logicalFrac = if (isRtl) 1f - rawFrac else rawFrac
            currentDragFraction = logicalFrac
            onFractionChange(logicalFrac)
          },
          onHorizontalDrag = { change, _ ->
            change.consume()
            val w = size.width.toFloat().coerceAtLeast(1f)
            val rawFrac = (change.position.x / w).coerceIn(0f, 1f)
            val logicalFrac = if (isRtl) 1f - rawFrac else rawFrac
            currentDragFraction = logicalFrac
            onFractionChange(logicalFrac)
          },
          onDragEnd = {
            onFractionFinished(currentDragFraction)
          },
          onDragCancel = {
            onFractionFinished(currentDragFraction)
          }
        )
      },
    contentAlignment = Alignment.Center
  ) {
    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(26.dp)
    ) {
      val w = size.width
      val h = size.height
      if (w <= 0f || h <= 0f) return@Canvas

      val clampedFraction = fraction.coerceIn(0f, 1f)
      val slotWidth = w / barCount
      val barWidth = (slotWidth * 0.56f).coerceIn(2.5f, 7f)
      val radius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f, barWidth / 2f)

      for (i in 0 until barCount) {
        val visualRatio = (i + 0.5f) / barCount.toFloat()
        val logicalRatio = if (isRtl) 1f - visualRatio else visualRatio
        val isPlayed = logicalRatio <= clampedFraction
        val distanceFromHead = kotlin.math.abs(logicalRatio - clampedFraction)

        val liveBoost = if (isPlaying) {
          val wave = 0.5f + 0.5f * kotlin.math.sin(beatPhase + i * 0.55f).toFloat()
          val headGlow = (1f - (distanceFromHead / 0.16f).coerceIn(0f, 1f)) * 0.24f
          0.86f + 0.14f * wave + headGlow
        } else {
          1f
        }

        val barH = (h * barHeights[i] * liveBoost).coerceIn(h * 0.18f, h)
        val x = i * slotWidth + (slotWidth - barWidth) / 2f
        val y = (h - barH) / 2f

        val barColor = when {
          isPlayed && distanceFromHead < 0.05f -> Color.White
          isPlayed -> accentColor
          canSeek -> Color.White.copy(alpha = 0.24f)
          else -> Color.White.copy(alpha = 0.15f)
        }

        drawRoundRect(
          color = barColor,
          topLeft = Offset(x, y),
          size = Size(barWidth, barH),
          cornerRadius = radius
        )
      }

      if (canSeek) {
        val playheadX = (if (isRtl) (1f - clampedFraction) else clampedFraction) * w
        val pillW = if (isDragging) 4.5.dp.toPx() else 3.dp.toPx()
        val pillH = if (isDragging) h else h * 0.88f
        drawRoundRect(
          color = Color.White,
          topLeft = Offset((playheadX - pillW / 2f).coerceIn(0f, w - pillW), (h - pillH) / 2f),
          size = Size(pillW, pillH),
          cornerRadius = androidx.compose.ui.geometry.CornerRadius(pillW / 2f, pillW / 2f)
        )
      }
    }
  }
}

/**
 * Sound Mode Expanded Card (Ring, Vibrate, Silent, Muted/DND)
 */
@Composable
fun ExpandedRingerView(
  currentMode: SoundMode,
  onSelectMode: (SoundMode) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Text(
      text = "وضع الصوت الحالي: ${currentMode.labelAr}",
      color = TextPrimary,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val modes = listOf(
        Triple(SoundMode.RING, Icons.Default.NotificationsActive, RealmeGreen),
        Triple(SoundMode.VIBRATE, Icons.Default.Vibration, Color(0xFFFFB74D)),
        Triple(SoundMode.SILENT, Icons.Default.NotificationsOff, Color(0xFFFF9500)),
        Triple(SoundMode.MUTED_DND, Icons.Default.DoNotDisturbOn, Color(0xFFFF453A))
      )
      modes.forEach { (mode, icon, color) ->
        val selected = currentMode == mode
        Column(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) color.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f))
            .border(
              width = 1.dp,
              color = if (selected) color else Color.Transparent,
              shape = RoundedCornerShape(14.dp)
            )
            .clickable { onSelectMode(mode) }
            .padding(vertical = 10.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = icon,
            contentDescription = mode.badgeAr,
            tint = if (selected) color else TextSecondary,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = mode.badgeAr,
            color = if (selected) color else TextPrimary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
          )
        }
      }
    }
  }
}

/**
 * Network, Wi-Fi, Airplane Mode & Hotspot Expanded Card
 */
@Composable
fun ExpandedNetworkView(
  networkState: NetworkState,
  onOpenSettings: () -> Unit
) {
  val (icon, tint) = when (networkState.type) {
    NetworkEventType.WIFI_CONNECTED -> Icons.Default.Wifi to Color(0xFF00E5FF)
    NetworkEventType.MOBILE_DATA -> Icons.Default.SignalCellularAlt to RealmeGreen
    NetworkEventType.NO_INTERNET -> Icons.Default.WifiOff to Color(0xFFFF453A)
    NetworkEventType.AIRPLANE_ON -> Icons.Default.AirplanemodeActive to Color(0xFFFF9500)
    NetworkEventType.AIRPLANE_OFF -> Icons.Default.AirplanemodeInactive to RealmeGreen
    NetworkEventType.HOTSPOT_ON -> Icons.Default.WifiTethering to Color(0xFFFFB74D)
    NetworkEventType.HOTSPOT_OFF -> Icons.Default.WifiTetheringOff to TextSecondary
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(tint.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
      }
      Column(modifier = Modifier.weight(1f)) {
        MarqueeFadingText(
          text = networkState.title.ifBlank { "حالة الشبكة" },
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = networkState.subtitle.ifBlank { "اضغط لفتح إعدادات الشبكة" },
          color = TextSecondary,
          fontSize = 11.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    Button(
      onClick = onOpenSettings,
      colors = ButtonDefaults.buttonColors(
        containerColor = tint.copy(alpha = 0.2f),
        contentColor = tint
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text("الإعدادات", fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
  }
}

/**
 * Real Download / Install Progress Expanded Card
 */
@Composable
fun ExpandedDownloadView(
  downloadState: DownloadState,
  onOpenApp: () -> Unit,
  onDismiss: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .clickable(onClick = onOpenApp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0xFF00E5FF).copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(22.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
          Text("${downloadState.appName} • اضغط للفتح", color = TextSecondary, fontSize = 11.sp)
          MarqueeFadingText(
            text = downloadState.title,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
      Text(
        text = if (downloadState.isIndeterminate) "..." else "${downloadState.percent}%",
        color = Color(0xFF00E5FF),
        fontSize = 16.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    if (downloadState.isIndeterminate) {
      LinearProgressIndicator(
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = Color(0xFF00E5FF),
        trackColor = Color.White.copy(alpha = 0.15f)
      )
    } else {
      LinearProgressIndicator(
        progress = { (downloadState.progress.toFloat() / downloadState.max.coerceAtLeast(1)).coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = Color(0xFF00E5FF),
        trackColor = Color.White.copy(alpha = 0.15f)
      )
    }
  }
}

/**
 * Live Navigation Expanded View (Google Maps / Waze, API-Free)
 */
@Composable
fun ExpandedNavigationView(
  navigationState: NavigationState,
  onOpenMaps: () -> Unit,
  onStopNav: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .clickable(onClick = onOpenMaps),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      if (navigationState.directionIcon != null) {
        Image(
          bitmap = navigationState.directionIcon.asImageBitmap(),
          contentDescription = "Direction",
          modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1A3A6A))
            .padding(6.dp)
        )
      } else {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF4285F4).copy(alpha = 0.22f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Navigation, contentDescription = null, tint = Color(0xFF4285F4), modifier = Modifier.size(26.dp))
        }
      }

      Column(modifier = Modifier.weight(1f)) {
        MarqueeFadingText(
          text = navigationState.instruction,
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        if (navigationState.distanceOrStreet.isNotBlank()) {
          MarqueeFadingText(
            text = navigationState.distanceOrStreet,
            color = TextSecondary,
            fontSize = 12.sp
          )
        }
        if (navigationState.etaText.isNotBlank()) {
          Text(
            text = navigationState.etaText,
            color = Color(0xFF66B2FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = onOpenMaps,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4), contentColor = Color.White),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("فتح الخرائط", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }

      Button(
        onClick = onStopNav,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2F38), contentColor = TextPrimary),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("إنهاء", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/**
 * Camera, Microphone & Voice Recorder Expanded Card
 */
@Composable
fun ExpandedPrivacyView(
  privacyState: PrivacyState,
  onTogglePause: () -> Unit,
  onStopRecorder: () -> Unit,
  onOpenRecorder: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(if (privacyState.isCameraInUse) Color(0xFF34C759).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.06f))
          .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(
          Icons.Default.Videocam,
          contentDescription = null,
          tint = if (privacyState.isCameraInUse) Color(0xFF34C759) else TextMuted,
          modifier = Modifier.size(18.dp)
        )
        Text(
          text = if (privacyState.isCameraInUse) "الكاميرا نشطة" else "الكاميرا مغلقة",
          color = if (privacyState.isCameraInUse) Color(0xFF34C759) else TextSecondary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Row(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(12.dp))
          .background(if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) Color(0xFFFF9500).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.06f))
          .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(
          Icons.Default.Mic,
          contentDescription = null,
          tint = if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) Color(0xFFFF9500) else TextMuted,
          modifier = Modifier.size(18.dp)
        )
        Text(
          text = if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) "الميكروفون نشط" else "الميكروفون مغلق",
          color = if (privacyState.isMicInUse || privacyState.isVoiceRecorderActive) Color(0xFFFF9500) else TextSecondary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    if (privacyState.isVoiceRecorderActive) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(Color.White.copy(alpha = 0.07f))
          .clickable(onClick = onOpenRecorder)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(privacyState.recorderAppName, color = TextSecondary, fontSize = 10.sp)
          MarqueeFadingText(text = privacyState.recorderTitle, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Text(
          text = privacyState.formatElapsed(),
          color = Color(0xFFFF453A),
          fontSize = 15.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Spacer(modifier = Modifier.width(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(Color(0xFFFF9500))
              .clickable(onClick = onTogglePause),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (privacyState.isRecorderRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = "Pause/Resume",
              tint = Color.Black,
              modifier = Modifier.size(18.dp)
            )
          }
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(Color(0xFFFF3B30))
              .clickable(onClick = onStopRecorder),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color.White, modifier = Modifier.size(18.dp))
          }
        }
      }
    } else {
      Text(
        text = "مؤشر الأمان يراقب استخدام الكاميرا والميكروفون بالزمن الحقيقي.",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

/**
 * Notification Expanded View with Direct Tap-to-Open App
 */
@Composable
fun ExpandedNotificationView(
  notifEvent: NotificationEvent?,
  accentColor: Color,
  onOpenApp: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .clickable(onClick = onOpenApp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Notifications, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(notifEvent?.appName ?: "إشعار", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(
          text = notifEvent?.title ?: "",
          color = TextPrimary,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = notifEvent?.text ?: "",
          color = TextSecondary,
          fontSize = 12.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    Button(
      onClick = onOpenApp,
      modifier = Modifier.fillMaxWidth(),
      colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("فتح التطبيق", fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
  }
}

/**
 * Live Media Volume Expanded Card
 */
@Composable
fun ExpandedVolumeView(
  volumeState: VolumeState,
  accentColor: Color,
  onToggleMute: () -> Unit,
  onSetVolume: (Int) -> Unit
) {
  val barColor = if (volumeState.isMuted) Color(0xFFFF453A) else accentColor
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(barColor.copy(alpha = 0.2f))
            .clickable(onClick = onToggleMute),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (volumeState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
            contentDescription = "تبديل الكتم",
            tint = barColor,
            modifier = Modifier.size(20.dp)
          )
        }
        Column {
          Text("صوت الوسائط", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text(
            text = if (volumeState.isMuted) "الصوت مكتوم الآن" else "اسحب للشريط أو اضغط الأيقونة للكتم",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
      }
      Text(
        text = "${volumeState.percent}%",
        color = barColor,
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    Slider(
      value = volumeState.volume.toFloat(),
      onValueChange = { onSetVolume(it.toInt()) },
      valueRange = 0f..volumeState.maxVolume.coerceAtLeast(1).toFloat(),
      modifier = Modifier.fillMaxWidth().height(24.dp),
      colors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = barColor,
        inactiveTrackColor = Color.White.copy(alpha = 0.16f)
      )
    )
  }
}

/**
 * Quick Volume, Brightness & Instant Action Pills inside Expanded Capsule
 */
@Composable
fun ExpandedQuickControlsView(
  accentColor: Color,
  flashlightOn: Boolean = false,
  currentSoundMode: SoundMode = SoundMode.RING,
  sleepTimerState: SleepTimerState = SleepTimerState(),
  nextAlarmState: NextAlarmState = NextAlarmState(),
  onToggleFlashlight: () -> Unit = {},
  onCycleSoundMode: () -> Unit = {},
  onStartQuickTimer: (Int, String) -> Unit = { _, _ -> },
  onStartSleepTimer: (Int) -> Unit = {},
  onCancelSleepTimer: () -> Unit = {},
  onOpenAlarms: () -> Unit = {},
  onOpenWeather: () -> Unit = {},
  onOpenSteps: () -> Unit = {},
  onOpenCompass: () -> Unit = {},
  onOpenFocus: () -> Unit = {}
) {
  val context = LocalContext.current
  val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
  val maxVol = remember { (audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15).coerceAtLeast(1) }
  var volumeValue by remember {
    mutableFloatStateOf((audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 7).toFloat())
  }

  val canWriteSettings = Settings.System.canWrite(context)
  var brightnessValue by remember {
    val cur = try {
      Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
    } catch (e: Exception) {
      128
    }
    mutableFloatStateOf(cur.toFloat().coerceIn(10f, 255f))
  }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    // Media Volume Slider
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "صوت الوسائط", tint = accentColor, modifier = Modifier.size(17.dp))
      Slider(
        value = volumeValue,
        onValueChange = { v ->
          volumeValue = v
          try {
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, v.toInt().coerceIn(0, maxVol), 0)
          } catch (_: Exception) {}
        },
        valueRange = 0f..maxVol.toFloat(),
        modifier = Modifier.weight(1f).height(22.dp),
        colors = SliderDefaults.colors(
          thumbColor = Color.White,
          activeTrackColor = accentColor,
          inactiveTrackColor = Color.White.copy(alpha = 0.16f)
        )
      )
      Text(
        text = "${((volumeValue / maxVol) * 100).toInt()}%",
        color = TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.width(34.dp),
        textAlign = TextAlign.End
      )
    }

    // Screen Brightness Slider (or Permission grant prompt)
    if (canWriteSettings) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(Icons.Default.LightMode, contentDescription = "السطوع", tint = Color(0xFFFFD600), modifier = Modifier.size(17.dp))
        Slider(
          value = brightnessValue,
          onValueChange = { b ->
            brightnessValue = b
            try {
              Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
              )
              Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                b.toInt().coerceIn(10, 255)
              )
            } catch (_: Exception) {}
          },
          valueRange = 10f..255f,
          modifier = Modifier.weight(1f).height(22.dp),
          colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = Color(0xFFFFD600),
            inactiveTrackColor = Color.White.copy(alpha = 0.16f)
          )
        )
        Text(
          text = "${((brightnessValue / 255f) * 100).toInt()}%",
          color = TextPrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.width(34.dp),
          textAlign = TextAlign.End
        )
      }
    } else {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(Color.White.copy(alpha = 0.08f))
          .clickable {
            val intent = Intent(
              Settings.ACTION_MANAGE_WRITE_SETTINGS,
              Uri.parse("package:${context.packageName}")
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
          }
          .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.LightMode, contentDescription = null, tint = Color(0xFFFFD600), modifier = Modifier.size(15.dp))
          Text("تفعيل التحكم بالسطوع", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("منح الإذن", color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }

    // One-Tap Quick Action Pills: Flashlight, Sound Mode, 5m Timer, Focus / Sleep Timer, Next Alarm
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(top = 3.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      QuickCapsuleActionPill(
        label = "فلاش",
        icon = if (flashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
        tint = if (flashlightOn) Color(0xFFFFD600) else TextSecondary,
        isActive = flashlightOn,
        onClick = onToggleFlashlight
      )
      QuickCapsuleActionPill(
        label = currentSoundMode.badgeAr,
        icon = when (currentSoundMode) {
          SoundMode.RING -> Icons.Default.NotificationsActive
          SoundMode.VIBRATE -> Icons.Default.Vibration
          SoundMode.SILENT -> Icons.Default.NotificationsOff
          SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
        },
        tint = Color(0xFFFF9500),
        isActive = currentSoundMode != SoundMode.RING,
        onClick = onCycleSoundMode
      )
      QuickCapsuleActionPill(
        label = if (sleepTimerState.isActive) sleepTimerState.formatRemaining() else "نوم 15د",
        icon = Icons.Default.Bedtime,
        tint = Color(0xFFB388FF),
        isActive = sleepTimerState.isActive,
        onClick = {
          if (sleepTimerState.isActive) onCancelSleepTimer() else onStartSleepTimer(15)
        }
      )
      QuickCapsuleActionPill(
        label = if (nextAlarmState.hasAlarm) nextAlarmState.formattedTime else "المنبه",
        icon = Icons.Default.Alarm,
        tint = Color(0xFF64D2FF),
        isActive = nextAlarmState.hasAlarm,
        onClick = onOpenAlarms
      )
      QuickCapsuleActionPill(
        label = "5د",
        icon = Icons.Default.HourglassTop,
        tint = Color(0xFFFFB74D),
        isActive = false,
        onClick = { onStartQuickTimer(300, "مؤقت 5 دقائق") }
      )
      QuickCapsuleActionPill(
        label = "تركيز",
        icon = Icons.Default.CenterFocusStrong,
        tint = Color(0xFFFF6E6E),
        isActive = false,
        onClick = onOpenFocus
      )
      QuickCapsuleActionPill(
        label = "خطوات",
        icon = Icons.AutoMirrored.Filled.DirectionsRun,
        tint = RealmeGreen,
        isActive = false,
        onClick = onOpenSteps
      )
      QuickCapsuleActionPill(
        label = "طقس",
        icon = Icons.Default.WbSunny,
        tint = Color(0xFFFFD54F),
        isActive = false,
        onClick = onOpenWeather
      )
      QuickCapsuleActionPill(
        label = "بوصلة",
        icon = Icons.Default.Explore,
        tint = accentColor,
        isActive = false,
        onClick = onOpenCompass
      )
    }
  }
}

@Composable
fun ExpandedSleepTimerView(
  sleepTimerState: SleepTimerState,
  onStartMinutes: (Int) -> Unit,
  onCancel: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFFB388FF).copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Bedtime, contentDescription = null, tint = Color(0xFFB388FF), modifier = Modifier.size(22.dp))
        }
        Column {
          Text("مؤقت النوم التلقائي", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text("إيقاف الموسيقى تلقائياً عند الانتهاء", color = TextSecondary, fontSize = 11.sp)
        }
      }
      Text(
        text = sleepTimerState.formatRemaining(),
        color = Color(0xFFB388FF),
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      listOf(15, 30, 60).forEach { mins ->
        QuickCapsuleActionPill(
          label = "${mins}د",
          icon = Icons.Default.Bedtime,
          tint = Color(0xFFB388FF),
          isActive = false,
          modifier = Modifier.weight(1f),
          onClick = { onStartMinutes(mins) }
        )
      }
      QuickCapsuleActionPill(
        label = "إلغاء",
        icon = Icons.Default.Stop,
        tint = Color(0xFFFF453A),
        isActive = true,
        modifier = Modifier.weight(1f),
        onClick = onCancel
      )
    }
  }
}

@Composable
private fun QuickCapsuleActionPill(
  label: String,
  icon: ImageVector,
  tint: Color,
  isActive: Boolean,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Row(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(if (isActive) tint.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.08f))
      .border(1.dp, if (isActive) tint else Color.Transparent, RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 6.dp, vertical = 7.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center
  ) {
    Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(14.dp))
    Spacer(modifier = Modifier.width(3.dp))
    Text(
      text = label,
      color = if (isActive) tint else TextPrimary,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      maxLines = 1
    )
  }
}

/**
 * Timer & Stopwatch Expanded View with Circular Progress Ring
 */
@Composable
fun ExpandedTimerView(
  timerState: TimerState,
  onTogglePause: () -> Unit,
  onCancel: () -> Unit
) {
  val remaining = timerState.remainingSeconds
  val total = if (timerState.totalSeconds > 0) timerState.totalSeconds else remaining.coerceAtLeast(1)
  val progress = if (timerState.isStopwatch) {
    ((timerState.elapsedSeconds % 60) / 60f).coerceIn(0f, 1f)
  } else {
    (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceAround
  ) {
    // Left: Circular Progress Ring with Countdown / Elapsed Time
    Box(
      modifier = Modifier.size(92.dp),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 5.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
        val arcSize = Size(diameter, diameter)

        drawArc(
          color = Color(0xFF2C2F38),
          startAngle = -90f,
          sweepAngle = 360f,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth)
        )

        drawArc(
          color = Color(0xFFFF9F0A),
          startAngle = -90f,
          sweepAngle = 360f * progress,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = timerState.formatRemaining(),
          color = Color.White,
          fontSize = 15.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (timerState.isStopwatch) "إيقاف" else "المؤقت",
          color = Color(0xFFFF9F0A),
          fontSize = 9.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }

    // Right: Action Buttons
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        shape = CircleShape,
        color = Color(0xFFFF9F0A),
        modifier = Modifier
          .clickable(onClick = onTogglePause)
          .padding(horizontal = 20.dp, vertical = 8.dp)
      ) {
        Text(
          text = if (timerState.isRunning) "إيقاف مؤقت" else "استئناف",
          color = Color.Black,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Surface(
        shape = CircleShape,
        color = Color(0xFF2C2F38),
        modifier = Modifier
          .clickable(onClick = onCancel)
          .padding(horizontal = 24.dp, vertical = 8.dp)
      ) {
        Text("إلغاء", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/**
 * Flashlight Expanded Card
 */
@Composable
fun ExpandedFlashlightView(
  flashlight: FlashlightState,
  onToggle: () -> Unit,
  onTurnOff: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF262D3D)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (flashlight.isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
          contentDescription = null,
          tint = if (flashlight.isOn) Color.Black else Color.White,
          modifier = Modifier.size(26.dp)
        )
      }

      Column {
        Text(
          text = if (flashlight.isOn) "المصباح مفعّل" else "المصباح متوقف",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (flashlight.isOn) "Flashlight is ON" else "Flashlight is OFF",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    Button(
      onClick = onToggle,
      colors = ButtonDefaults.buttonColors(
        containerColor = if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF2E384D),
        contentColor = if (flashlight.isOn) Color.Black else Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text(
        text = if (flashlight.isOn) "إطفاء" else "تشغيل",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }
  }
}

/**
 * Phone Call Expanded Card (Screenshot 4)
 */
@Composable
fun ExpandedCallView(
  callState: CallState,
  onAnswer: () -> Unit,
  onDecline: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Box(
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(Color(0xFF2D2720)),
      contentAlignment = Alignment.Center
    ) {
      Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = if (callState.isIncoming) "مكالمة واردة" else callState.callerNumber,
        color = TextSecondary,
        fontSize = 11.sp
      )
      MarqueeFadingText(
        text = callState.callerName,
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
      if (!callState.isIncoming) {
        Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      } else {
        Text("يرن...", color = Color(0xFFFF9500), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Color(0xFFFF3B30))
          .clickable(onClick = onDecline),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(18.dp))
      }

      if (callState.isIncoming) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF34C759))
            .clickable(onClick = onAnswer),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

/**
 * Battery Charging Expanded Card (Screenshot 3)
 */
@Composable
fun ExpandedBatteryView(batteryState: BatteryState) {
  val color = if (batteryState.isLowAlert) Color(0xFFFF453A) else RealmeGreen
  val titleText = when {
    batteryState.isLowAlert -> "بطارية منخفضة"
    batteryState.isFullAlert -> "اكتمل الشحن"
    else -> "جارٍ الشحن"
  }
  val telemetryParts = buildList {
    val base = batteryState.pluggedType.ifBlank {
      if (batteryState.isLowAlert) "يرجى توصيل الشاحن" else "طاقة مستقرة"
    }
    add(base)
    if (batteryState.chargingWatts >= 1.0f) {
      add(String.format(Locale.US, "%.1fW", batteryState.chargingWatts))
    }
    if (batteryState.temperatureC > 0f) {
      add(String.format(Locale.US, "%.1f°C", batteryState.temperatureC))
    }
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (batteryState.isLowAlert) Icons.Default.BatteryAlert else Icons.Default.BatteryChargingFull,
          contentDescription = null,
          tint = color,
          modifier = Modifier.size(24.dp)
        )
      }

      Column {
        Text(titleText, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(
          text = telemetryParts.joinToString(" • "),
          color = TextSecondary,
          fontSize = 11.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    Text(
      text = "${batteryState.percentage}%",
      color = color,
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}
