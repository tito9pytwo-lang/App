package com.example.island

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

enum class FootballLeague(val code: String, val labelAr: String) {
  UEFA_CL("uefa.champions", "دوري الأبطال"),
  EPL("eng.1", "الإنجليزي"),
  LALIGA("esp.1", "الإسباني"),
  SAUDI("ksa.1", "دوري روشن"),
  SERIE_A("ita.1", "الإيطالي"),
  BUNDESLIGA("ger.1", "الألماني"),
  ALL("all", "كل البطولات");

  companion object {
    fun fromCode(code: String): FootballLeague =
      entries.firstOrNull { it.code == code } ?: UEFA_CL
  }
}

object FootballRepository {

  private const val TAG = "FootballRepository"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(12, TimeUnit.SECONDS)
      .readTimeout(12, TimeUnit.SECONDS)
      .build()
  }

  suspend fun fetchLiveMatches(leagueCode: String): Result<FootballState> = withContext(Dispatchers.IO) {
    val league = FootballLeague.fromCode(leagueCode)
    try {
      val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/${league.code}/scoreboard"
      val request = Request.Builder().url(url).get().build()
      val body = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(
            IllegalStateException("تعذر الاتصال بخدمة المباريات (${resp.code})")
          )
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة المباريات"))

      val state = parseEspnScoreboardJson(body, league.code, league.labelAr)
      Result.success(state)
    } catch (e: Exception) {
      Log.w(TAG, "Failed fetching live football scores for ${league.code}", e)
      Result.failure(IllegalStateException(toFriendlyError(e)))
    }
  }

  internal fun parseEspnScoreboardJson(
    jsonStr: String,
    leagueCode: String,
    leagueNameAr: String
  ): FootballState {
    val root = JSONObject(jsonStr)
    val events = root.optJSONArray("events")
    val parsed = mutableListOf<FootballMatchItem>()

    if (events != null) {
      for (i in 0 until events.length()) {
        val ev = events.optJSONObject(i) ?: continue
        val id = ev.optString("id", "ev_$i")
        val competitions = ev.optJSONArray("competitions")
        val comp = competitions?.optJSONObject(0) ?: continue
        val competitors = comp.optJSONArray("competitors") ?: continue
        if (competitors.length() < 2) continue

        var homeObj = competitors.optJSONObject(0)
        var awayObj = competitors.optJSONObject(1)
        for (c in 0 until competitors.length()) {
          val obj = competitors.optJSONObject(c) ?: continue
          when (obj.optString("homeAway", "").lowercase(Locale.US)) {
            "home" -> homeObj = obj
            "away" -> awayObj = obj
          }
        }
        if (homeObj == null || awayObj == null) continue

        val homeName = extractTeamName(homeObj)
        val awayName = extractTeamName(awayObj)
        val homeLogo = extractTeamLogoUrl(homeObj)
        val awayLogo = extractTeamLogoUrl(awayObj)
        val homeAbbrev = extractTeamAbbrev(homeObj, homeName)
        val awayAbbrev = extractTeamAbbrev(awayObj, awayName)
        val homeScore = homeObj.optString("score", "0").toIntOrNull() ?: 0
        val awayScore = awayObj.optString("score", "0").toIntOrNull() ?: 0

        val statusObj = comp.optJSONObject("status") ?: ev.optJSONObject("status")
        val statusType = statusObj?.optJSONObject("type")
        val stateCode = statusType?.optString("state", "pre")?.lowercase(Locale.US) ?: "pre"
        val displayClock = statusObj?.optString("displayClock", "")?.trim().orEmpty()
        val shortDetail = statusType?.optString("shortDetail", "")?.trim().orEmpty()

        val isLive = stateCode == "in"
        val isFinished = stateCode == "post"
        val statusLabel = when {
          isLive -> when {
            shortDetail.contains("HT", ignoreCase = true) -> "استراحة"
            displayClock.isNotBlank() -> displayClock
            else -> shortDetail.ifBlank { "مباشر" }
          }
          isFinished -> "انتهت"
          else -> formatScheduledTime(ev.optString("date", "")) ?: shortDetail.ifBlank { "قريباً" }
        }

        parsed.add(
          FootballMatchItem(
            id = id,
            leagueNameAr = leagueNameAr,
            homeTeam = homeName,
            awayTeam = awayName,
            homeLogoUrl = homeLogo,
            awayLogoUrl = awayLogo,
            homeAbbrev = homeAbbrev,
            awayAbbrev = awayAbbrev,
            homeScore = homeScore,
            awayScore = awayScore,
            minuteOrStatus = statusLabel,
            isLive = isLive,
            isFinished = isFinished
          )
        )
      }
    }

    // Prioritize live matches first, then recently finished, then upcoming
    val ordered = parsed.sortedWith(
      compareByDescending<FootballMatchItem> { it.isLive }
        .thenByDescending { it.isFinished }
    ).take(12)

    return FootballState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = ordered.any { it.isLive },
      leagueCode = leagueCode,
      leagueNameAr = leagueNameAr,
      matches = ordered,
      selectedIndex = 0,
      errorMessage = if (ordered.isEmpty()) "لا توجد مباريات متاحة اليوم في $leagueNameAr" else null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  private fun extractTeamName(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return "فريق"
    return team.optString("shortDisplayName").takeIf { it.isNotBlank() }
      ?: team.optString("displayName").takeIf { it.isNotBlank() }
      ?: team.optString("abbreviation").takeIf { it.isNotBlank() }
      ?: "فريق"
  }

  private fun extractTeamLogoUrl(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return ""
    val direct = team.optString("logo").trim()
    val fromArray = team.optJSONArray("logos")
      ?.optJSONObject(0)
      ?.optString("href")
      ?.trim()
      .orEmpty()
    val raw = direct.ifBlank { fromArray }
    return if (raw.startsWith("http://", ignoreCase = true)) {
      "https://" + raw.removePrefix("http://")
    } else {
      raw
    }
  }

  private fun extractTeamAbbrev(competitor: JSONObject, fallbackName: String): String {
    val team = competitor.optJSONObject("team")
    val abbrev = team?.optString("abbreviation")?.trim().orEmpty()
    if (abbrev.isNotBlank()) return abbrev.take(3).uppercase(Locale.US)
    val clean = fallbackName.trim()
    return if (clean.isNotBlank()) clean.take(2).uppercase(Locale.US) else "FC"
  }

  private fun formatScheduledTime(isoUtc: String): String? {
    if (isoUtc.isBlank()) return null
    val patterns = listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")
    for (p in patterns) {
      try {
        val parser = SimpleDateFormat(p, Locale.US).apply {
          timeZone = TimeZone.getTimeZone("UTC")
        }
        val date = parser.parse(isoUtc) ?: continue
        val out = SimpleDateFormat("HH:mm", Locale.US)
        return out.format(date)
      } catch (_: Exception) {
      }
    }
    return null
  }

  private fun toFriendlyError(err: Throwable): String {
    val msg = err.message.orEmpty()
    return when {
      err is UnknownHostException ||
        err is ConnectException ||
        msg.contains("Unable to resolve host", ignoreCase = true) ||
        msg.contains("No address associated", ignoreCase = true) ->
        "لا يوجد اتصال بالإنترنت لعرض نتائج المباريات"
      err is SocketTimeoutException || msg.contains("timeout", ignoreCase = true) ->
        "انتهت مهلة الاتصال بخدمة المباريات، حاول مجدداً"
      err is IllegalStateException && msg.isNotBlank() -> msg
      else -> "تعذر جلب نتائج المباريات حالياً"
    }
  }
}
