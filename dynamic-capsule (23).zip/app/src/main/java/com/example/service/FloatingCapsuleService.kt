package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class FloatingCapsuleService : AccessibilityService() {

  private var windowManager: WindowManager? = null
  private var floatingView: ComposeView? = null
  private var lifecycleOwner: FloatingLifecycleOwner? = null
  private var windowParams: WindowManager.LayoutParams? = null

  private var isViewAttached = false
  private val _capsuleMode = MutableStateFlow(CapsuleMode.MINI)
  val capsuleMode: StateFlow<CapsuleMode> = _capsuleMode.asStateFlow()

  private val _isDismissedToNotification = MutableStateFlow(false)
  val isDismissedToNotification: StateFlow<Boolean> = _isDismissedToNotification.asStateFlow()

  private var dismissedEventSeq: Long = 0L
  private var dismissedPlayingTrackKey: String? = null

  private val _isLandscape = MutableStateFlow(false)

  private var serviceJob: Job? = null
  private var serviceScope: CoroutineScope? = null
  private var actionReceiverRegistered = false

  private val actionReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      when (intent?.action) {
        ACTION_STOP_SERVICE -> {
          CapsuleSettingsManager.getInstance(this@FloatingCapsuleService).updateServiceEnabled(false)
          cancelNotification()
        }
        ACTION_RESTORE_CAPSULE -> {
          restoreFromNotification()
        }
        ACTION_TOGGLE_PLAY_PAUSE -> {
          MediaSessionHolder.togglePlayPause()
        }
      }
    }
  }

  override fun onServiceConnected() {
    super.onServiceConnected()
    _isConnected.value = true
    _isLandscape.value = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    serviceJob?.cancel()
    val job = SupervisorJob()
    serviceJob = job
    serviceScope = CoroutineScope(Dispatchers.Main + job)

    IslandStateManager.initialize(this)
    lifecycleOwner?.destroy()
    lifecycleOwner = FloatingLifecycleOwner().apply { start() }
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    createNotificationChannel()
    registerNotificationActionReceiver()
    initFloatingCapsule()
    observeState()
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    // Overlay is rendered independently using TYPE_ACCESSIBILITY_OVERLAY without inspecting screen content.
  }

  override fun onInterrupt() {
    // No accessibility feedback streams are needed.
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    _isLandscape.value = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
  }

  private val overlayFlags: Int
    get() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
      WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
      WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
      WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

  private fun calculateYPosition(settings: CapsuleSettings): Int {
    val density = resources.displayMetrics.density
    val baseCutoutY = (12 * density).toInt()
    val userOffset = (settings.notchOffsetYDp * density).toInt()
    return baseCutoutY + userOffset
  }

  private fun registerNotificationActionReceiver() {
    if (actionReceiverRegistered) return
    val filter = IntentFilter().apply {
      addAction(ACTION_STOP_SERVICE)
      addAction(ACTION_RESTORE_CAPSULE)
      addAction(ACTION_TOGGLE_PLAY_PAUSE)
    }
    ContextCompat.registerReceiver(
      this,
      actionReceiver,
      filter,
      ContextCompat.RECEIVER_NOT_EXPORTED
    )
    actionReceiverRegistered = true
  }

  private fun unregisterNotificationActionReceiver() {
    if (!actionReceiverRegistered) return
    try {
      unregisterReceiver(actionReceiver)
    } catch (e: Exception) {
      Log.w(TAG, "Receiver already unregistered", e)
    } finally {
      actionReceiverRegistered = false
    }
  }

  private fun buildDismissedNotification(track: MediaTrackInfo? = null): Notification {
    val restoreIntent = Intent(ACTION_RESTORE_CAPSULE).setPackage(packageName)
    val restorePendingIntent = PendingIntent.getBroadcast(
      this, 101, restoreIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val openAppIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val openAppPendingIntent = PendingIntent.getActivity(
      this, 0, openAppIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val stopIntent = Intent(ACTION_STOP_SERVICE).setPackage(packageName)
    val stopPendingIntent = PendingIntent.getBroadcast(
      this, 1, stopIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val title: String
    val text: String
    if (track != null) {
      title = "🎵 ${track.title}"
      text = "${track.artist.ifEmpty { "Dynamic Capsule" }} • اضغط للاستعادة إلى الشاشة"
    } else {
      title = "Dynamic Capsule"
      text = "تم نقل الكبسولة إلى الإشعارات • اضغط للاستعادة"
    }

    val builder = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(text)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentIntent(restorePendingIntent)
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .addAction(
        android.R.drawable.ic_menu_upload,
        "إظهار الكبسولة",
        restorePendingIntent
      )
      .addAction(
        android.R.drawable.ic_menu_preferences,
        "الإعدادات",
        openAppPendingIntent
      )

    if (track != null) {
      val toggleIntent = Intent(ACTION_TOGGLE_PLAY_PAUSE).setPackage(packageName)
      val togglePendingIntent = PendingIntent.getBroadcast(
        this, 102, toggleIntent,
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
      )
      val playPauseIcon = if (track.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
      val playPauseTitle = if (track.isPlaying) "إيقاف مؤقت" else "تشغيل"
      builder.addAction(playPauseIcon, playPauseTitle, togglePendingIntent)
    }

    builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إخفاء", stopPendingIntent)

    return builder.build()
  }

  private fun updateNotification(isDismissed: Boolean, track: MediaTrackInfo? = null) {
    try {
      val manager = getSystemService(NotificationManager::class.java) ?: return
      if (isDismissed) {
        manager.notify(NOTIFICATION_ID, buildDismissedNotification(track))
      } else {
        manager.cancel(NOTIFICATION_ID)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error updating notification", e)
    }
  }

  private fun cancelNotification() {
    try {
      getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    } catch (e: Exception) {
      Log.e(TAG, "Error canceling notification", e)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Dynamic Capsule Notifications",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Restore capsule actions when swiped to notifications"
        setShowBadge(false)
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(channel)
    }
  }

  fun dismissToNotification() {
    dismissedEventSeq = IslandStateManager.activityEventSeq.value
    val curTrack = MediaSessionHolder.currentTrack.value
    dismissedPlayingTrackKey = curTrack?.takeIf { it.isPlaying }?.let { "${it.packageName}|${it.title}|${it.artist}" }
    _isDismissedToNotification.value = true
    if (_capsuleMode.value == CapsuleMode.EXPANDED) {
      _capsuleMode.value = CapsuleMode.MINI
    }
    detachView()
    updateNotification(true, curTrack)
  }

  fun restoreFromNotification() {
    dismissedPlayingTrackKey = null
    _isDismissedToNotification.value = false
    val track = MediaSessionHolder.currentTrack.value
    updateNotification(false, track)
  }

  private fun initFloatingCapsule() {
    val context = this
    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      OVERLAY_WINDOW_TYPE,
      overlayFlags,
      PixelFormat.TRANSLUCENT
    ).apply {
      gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }
      y = calculateYPosition(settings)
    }

    floatingView = ComposeView(this).apply {
      lifecycleOwner?.let { owner ->
        setViewTreeLifecycleOwner(owner)
        setViewTreeViewModelStoreOwner(owner)
        setViewTreeSavedStateRegistryOwner(owner)
      }

      setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
          if (_capsuleMode.value == CapsuleMode.EXPANDED) {
            setMode(CapsuleMode.MINI)
          }
          false
        } else {
          false
        }
      }

      setContent {
        val currentMode by capsuleMode.collectAsState()
        val track by MediaSessionHolder.currentTrack.collectAsState()
        val currentSettings by CapsuleSettingsManager.getInstance(context).settings.collectAsState()

        MyApplicationTheme(
          darkTheme = true,
          appThemeIndex = currentSettings.appThemeIndex,
          customSettings = currentSettings
        ) {
          Box(
            modifier = Modifier.wrapContentSize(),
            contentAlignment = Alignment.TopCenter
          ) {
            DynamicCapsuleView(
              trackInfo = track,
              settings = currentSettings,
              mode = currentMode,
              onModeChange = { newMode -> setMode(newMode) },
              onDismissToNotification = { dismissToNotification() }
            )
          }
        }
      }
    }
  }

  private fun observeState() {
    val scope = serviceScope ?: return
    val settingsManager = CapsuleSettingsManager.getInstance(this)

    val islandTriggers = combine(
      IslandStateManager.activeCard,
      combine(IslandStateManager.timerState, IslandStateManager.sleepTimerState, IslandStateManager.focusState) { _, _, _ -> Unit },
      IslandStateManager.downloadState,
      IslandStateManager.flashlightState,
      IslandStateManager.ringerState
    ) { _, _, _, _, _ -> Unit }

    val extraTriggers = combine(
      IslandStateManager.batteryState,
      IslandStateManager.bluetoothState,
      IslandStateManager.activeNotification,
      IslandStateManager.navigationState,
      combine(
        IslandStateManager.privacyState,
        IslandStateManager.weatherState,
        IslandStateManager.stepsState,
        IslandStateManager.compassState,
        combine(IslandStateManager.deliveryState, IslandStateManager.footballState) { _, _ -> Unit }
      ) { _, _, _, _, _ -> Unit }
    ) { _, _, _, _, _ -> Unit }

    val statusTriggers = combine(
      extraTriggers,
      IslandStateManager.networkState,
      IslandStateManager.volumeState,
      IslandStateManager.activityEventSeq,
      _isLandscape
    ) { _, _, _, eventSeq, landscape -> Pair(eventSeq, landscape) }

    scope.launch {
      combine(
        MediaSessionHolder.currentTrack,
        settingsManager.settings,
        IslandStateManager.callState,
        _isDismissedToNotification,
        combine(islandTriggers, statusTriggers) { _, pair -> pair }
      ) { track, settings, callState, isDismissed, (eventSeq, isLandscape) ->
        val hasActivity = IslandStateManager.hasRenderableActivity(track, settings)
        val currentPlayingKey = track?.takeIf { it.isPlaying }?.let { "${it.packageName}|${it.title}|${it.artist}" }

        if (isDismissed) {
          if (currentPlayingKey == null) {
            dismissedPlayingTrackKey = null
          }
          val newEventArrived = eventSeq > dismissedEventSeq
          val newMusicStarted = currentPlayingKey != null && currentPlayingKey != dismissedPlayingTrackKey
          val incomingCall = callState.isActive && callState.isIncoming
          val allEnded = !hasActivity

          if (incomingCall || newEventArrived || newMusicStarted || allEnded) {
            dismissedPlayingTrackKey = null
            _isDismissedToNotification.value = false
          }
        }

        val effectivelyDismissed = _isDismissedToNotification.value
        val allowedInOrientation = IslandStateManager.shouldShowInOrientation(
          isLandscape = isLandscape,
          hideInLandscape = settings.hideInLandscape,
          hasActiveCall = callState.isActive
        )
        val shouldShow = settings.serviceEnabled &&
          (hasActivity || settings.showWhenIdle) &&
          !effectivelyDismissed &&
          allowedInOrientation
        ServiceCapsuleState(track, settings, shouldShow, effectivelyDismissed)
      }.collect { state ->
        val track = state.track
        val settings = state.settings
        val shouldShow = state.shouldShow
        val isDismissed = state.isDismissed
        val hasActivity = IslandStateManager.hasRenderableActivity(track, settings)

        if (shouldShow && !isViewAttached) {
          attachView()
        } else if (!shouldShow && isViewAttached) {
          if (_capsuleMode.value == CapsuleMode.EXPANDED) {
            _capsuleMode.value = CapsuleMode.MINI
          }
          detachView()
        }

        if (!hasActivity && _capsuleMode.value == CapsuleMode.EXPANDED) {
          setMode(CapsuleMode.MINI)
        }

        if (isViewAttached) {
          windowParams?.y = calculateYPosition(settings)
          windowParams?.let { params ->
            try {
              windowManager?.updateViewLayout(floatingView, params)
            } catch (e: Exception) {
              Log.e(TAG, "Error updating window layout", e)
            }
          }
        }

        updateNotification(isDismissed && settings.serviceEnabled, track)
      }
    }
  }

  private fun setMode(mode: CapsuleMode) {
    if (_capsuleMode.value == mode) return
    _capsuleMode.value = mode

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams?.let { params ->
      params.width = WindowManager.LayoutParams.WRAP_CONTENT
      params.height = WindowManager.LayoutParams.WRAP_CONTENT
      params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      params.y = calculateYPosition(settings)
      params.flags = overlayFlags
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        params.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }

      try {
        if (isViewAttached && floatingView != null) {
          windowManager?.updateViewLayout(floatingView, params)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error updating mode in WindowManager", e)
      }
    }
  }

  private fun attachView() {
    val view = floatingView ?: return
    val params = windowParams ?: return
    if (!isViewAttached) {
      try {
        windowManager?.addView(view, params)
        isViewAttached = true
      } catch (e: Exception) {
        Log.e(TAG, "Error adding accessibility overlay view to WindowManager", e)
      }
    }
  }

  private fun detachView() {
    val view = floatingView ?: return
    if (isViewAttached) {
      try {
        windowManager?.removeView(view)
        isViewAttached = false
      } catch (e: Exception) {
        Log.e(TAG, "Error removing accessibility overlay view from WindowManager", e)
      }
    }
  }

  private fun cleanupResources() {
    _isConnected.value = false
    serviceJob?.cancel()
    serviceJob = null
    serviceScope = null
    unregisterNotificationActionReceiver()
    cancelNotification()
    detachView()
    lifecycleOwner?.destroy()
    lifecycleOwner = null
    floatingView = null
    windowManager = null
    windowParams = null
  }

  override fun onUnbind(intent: Intent?): Boolean {
    cleanupResources()
    return super.onUnbind(intent)
  }

  override fun onDestroy() {
    cleanupResources()
    super.onDestroy()
  }

  companion object {
    private const val TAG = "FloatingCapsuleService"
    private const val CHANNEL_ID = "dynamic_capsule_channel"
    private const val NOTIFICATION_ID = 2001
    const val OVERLAY_WINDOW_TYPE = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
    const val ACTION_RESTORE_CAPSULE = "com.example.action.RESTORE_CAPSULE"
    const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.action.TOGGLE_PLAY_PAUSE"

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
      if (_isConnected.value) return true

      val expectedFull = ComponentName(context, FloatingCapsuleService::class.java).flattenToString()
      val expectedShort = ComponentName(context, FloatingCapsuleService::class.java).flattenToShortString()
      val serviceClassName = FloatingCapsuleService::class.java.name

      try {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (enabledServices != null) {
          val foundInManager = enabledServices.any { info ->
            val id = info.id ?: ""
            val svcInfo = info.resolveInfo?.serviceInfo
            id.equals(expectedFull, ignoreCase = true) ||
              id.equals(expectedShort, ignoreCase = true) ||
              (svcInfo?.packageName == context.packageName && svcInfo?.name == serviceClassName)
          }
          if (foundInManager) return true
        }
      } catch (e: Exception) {
        Log.w(TAG, "Failed querying AccessibilityManager", e)
      }

      return try {
        val enabledSetting = Settings.Secure.getString(
          context.contentResolver,
          Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        enabledSetting.split(':').any { entry ->
          val trimmed = entry.trim()
          trimmed.equals(expectedFull, ignoreCase = true) ||
            trimmed.equals(expectedShort, ignoreCase = true)
        }
      } catch (e: Exception) {
        Log.w(TAG, "Failed reading ENABLED_ACCESSIBILITY_SERVICES", e)
        false
      }
    }

    fun openAccessibilitySettings(context: Context) {
      val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
        if (context !is Activity) {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      }
      try {
        context.startActivity(intent)
      } catch (e: Exception) {
        Log.e(TAG, "Failed to open Accessibility Settings", e)
      }
    }
  }
}

private data class ServiceCapsuleState(
  val track: MediaTrackInfo?,
  val settings: CapsuleSettings,
  val shouldShow: Boolean,
  val isDismissed: Boolean
)
