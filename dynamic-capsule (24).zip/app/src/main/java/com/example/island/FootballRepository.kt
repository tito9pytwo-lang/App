package com.example.island

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

enum class FootballLeague(val code: String, val labelAr: String) {
  UEFA_CL("uefa.champions", "دوري الأبطال"),
  EPL("eng.1", "الإنجليزي"),
  LALIGA("esp.1", "الإسباني"),
  SAUDI("ksa.1", "دوري روشن"),
  SERIE_A("ita.1", "الإيطالي"),
  BUNDESLIGA("ger.1", "الألماني"),
  ALL("all", "كل البطولات");

  companion object {
    fun fromCode(code: String): FootballLeague =
      entries.firstOrNull { it.code == code } ?: UEFA_CL
  }
}

object FootballRepository {

  private const val TAG = "FootballRepository"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .cache(null)
      .connectTimeout(8, TimeUnit.SECONDS)
      .readTimeout(8, TimeUnit.SECONDS)
      .build()
  }

  suspend fun fetchLiveMatches(leagueCode: String): Result<FootballState> = withContext(Dispatchers.IO) {
    val league = FootballLeague.fromCode(leagueCode)
    try {
      val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/${league.code}/scoreboard"
      val request = Request.Builder()
        .url(url)
        .cacheControl(CacheControl.FORCE_NETWORK)
        .header("Cache-Control", "no-cache, no-store, must-revalidate")
        .header("Pragma", "no-cache")
        .get()
        .build()
      val body = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(
            IllegalStateException("تعذر الاتصال بخدمة المباريات (${resp.code})")
          )
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة المباريات"))

      val state = parseEspnScoreboardJson(body, league.code, league.labelAr)
      Result.success(state)
    } catch (e: Exception) {
      Log.w(TAG, "Failed fetching live football scores for ${league.code}", e)
      Result.failure(IllegalStateException(toFriendlyError(e)))
    }
  }

  internal fun parseEspnScoreboardJson(
    jsonStr: String,
    leagueCode: String,
    leagueNameAr: String
  ): FootballState {
    val root = JSONObject(jsonStr)
    val events = root.optJSONArray("events")
    val parsed = mutableListOf<FootballMatchItem>()

    if (events != null) {
      for (i in 0 until events.length()) {
        val ev = events.optJSONObject(i) ?: continue
        val id = ev.optString("id", "ev_$i")
        val competitions = ev.optJSONArray("competitions")
        val comp = competitions?.optJSONObject(0) ?: continue
        val competitors = comp.optJSONArray("competitors") ?: continue
        if (competitors.length() < 2) continue

        var homeObj = competitors.optJSONObject(0)
        var awayObj = competitors.optJSONObject(1)
        for (c in 0 until competitors.length()) {
          val obj = competitors.optJSONObject(c) ?: continue
          when (obj.optString("homeAway", "").lowercase(Locale.US)) {
            "home" -> homeObj = obj
            "away" -> awayObj = obj
          }
        }
        if (homeObj == null || awayObj == null) continue

        val homeName = extractTeamName(homeObj)
        val awayName = extractTeamName(awayObj)
        val homeLogo = extractTeamLogoUrl(homeObj)
        val awayLogo = extractTeamLogoUrl(awayObj)
        val homeAbbrev = extractTeamAbbrev(homeObj, homeName)
        val awayAbbrev = extractTeamAbbrev(awayObj, awayName)
        val homeScore = homeObj.optString("score", "0").toIntOrNull() ?: 0
        val awayScore = awayObj.optString("score", "0").toIntOrNull() ?: 0

        val statusObj = comp.optJSONObject("status") ?: ev.optJSONObject("status")
        val statusType = statusObj?.optJSONObject("type")
        val stateCode = statusType?.optString("state", "pre")?.lowercase(Locale.US) ?: "pre"
        val typeName = statusType?.optString("name", "")?.uppercase(Locale.US).orEmpty()
        val displayClock = statusObj?.optString("displayClock", "")?.trim().orEmpty()
        val shortDetail = statusType?.optString("shortDetail", "")?.trim().orEmpty()
        val description = statusType?.optString("description", "")?.trim().orEmpty()

        val matchPhase = resolveMatchPhase(stateCode, typeName, shortDetail, description)
        val isLive = matchPhase == FootballMatchPhase.LIVE_PLAY ||
          matchPhase == FootballMatchPhase.HALFTIME ||
          matchPhase == FootballMatchPhase.STOPPED
        val isFinished = matchPhase == FootballMatchPhase.FINISHED

        val parsedServerClock = if (matchPhase == FootballMatchPhase.LIVE_PLAY) {
          extractClockSeconds(statusObj, displayClock)
        } else {
          -1
        }
        val isStoppage = displayClock.contains("+") || shortDetail.contains("+")

        val statusLabel = when (matchPhase) {
          FootballMatchPhase.HALFTIME -> "استراحة"
          FootballMatchPhase.STOPPED -> resolveStoppedLabelAr(typeName, shortDetail, description)
          FootballMatchPhase.FINISHED -> when {
            shortDetail.contains("PEN", ignoreCase = true) || typeName.contains("PEN") -> "انتهت (ركلات)"
            shortDetail.contains("AET", ignoreCase = true) || typeName.contains("AET") -> "انتهت (إضافي)"
            else -> "انتهت"
          }
          FootballMatchPhase.LIVE_PLAY -> when {
            displayClock.isNotBlank() -> displayClock
            shortDetail.isNotBlank() -> shortDetail
            else -> "مباشر"
          }
          FootballMatchPhase.SCHEDULED -> formatScheduledTime(ev.optString("date", "")) ?: shortDetail.ifBlank { "قريباً" }
        }

        parsed.add(
          FootballMatchItem(
            id = id,
            leagueNameAr = leagueNameAr,
            homeTeam = homeName,
            awayTeam = awayName,
            homeLogoUrl = homeLogo,
            awayLogoUrl = awayLogo,
            homeAbbrev = homeAbbrev,
            awayAbbrev = awayAbbrev,
            homeScore = homeScore,
            awayScore = awayScore,
            minuteOrStatus = statusLabel,
            isLive = isLive,
            isFinished = isFinished,
            matchPhase = matchPhase,
            clockSeconds = parsedServerClock,
            serverClockSeconds = parsedServerClock,
            isStoppageTime = isStoppage
          )
        )
      }
    }

    // Prioritize active play first, then halftime/stopped, then finished, then upcoming
    val ordered = parsed.sortedWith(
      compareBy<FootballMatchItem> {
        when (it.matchPhase) {
          FootballMatchPhase.LIVE_PLAY -> 0
          FootballMatchPhase.HALFTIME -> 1
          FootballMatchPhase.STOPPED -> 2
          FootballMatchPhase.FINISHED -> 3
          FootballMatchPhase.SCHEDULED -> 4
        }
      }
    ).take(12)

    return FootballState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = ordered.any { it.isLive },
      leagueCode = leagueCode,
      leagueNameAr = leagueNameAr,
      matches = ordered,
      selectedIndex = 0,
      errorMessage = if (ordered.isEmpty()) "لا توجد مباريات متاحة اليوم في $leagueNameAr" else null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  internal fun mergeLiveClocks(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>
  ): List<FootballMatchItem> {
    if (previous.isEmpty()) return fresh
    val prevById = previous.associateBy { it.id }
    return fresh.map { next ->
      val old = prevById[next.id] ?: return@map next
      if (next.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        old.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        next.serverClockSeconds >= 0 &&
        next.serverClockSeconds == old.serverClockSeconds &&
        old.clockSeconds >= next.serverClockSeconds
      ) {
        // Server clock hasn't flipped yet (many feeds update clock once per minute);
        // keep smooth local second ticker up to +59s without jumping backwards.
        val smoothSeconds = old.clockSeconds.coerceAtMost(next.serverClockSeconds + 59)
        next.copy(clockSeconds = smoothSeconds)
      } else {
        next
      }
    }
  }

  internal fun detectMatchEvent(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>,
    preferredMatchId: String? = null
  ): FootballMatchEvent? {
    if (previous.isEmpty() || fresh.isEmpty()) return null
    val prevById = previous.associateBy { it.id }
    val candidates = mutableListOf<Pair<Int, FootballMatchEvent>>()

    for (newItem in fresh) {
      val oldItem = prevById[newItem.id] ?: continue
      val homeScored = newItem.homeScore > oldItem.homeScore
      val awayScored = newItem.awayScore > oldItem.awayScore
      val isPreferredBoost = if (newItem.id == preferredMatchId) 0 else 10

      if (homeScored || awayScored) {
        val side = when {
          homeScored && awayScored -> FootballScoringSide.BOTH
          homeScored -> FootballScoringSide.HOME
          else -> FootballScoringSide.AWAY
        }
        val scorerTeam = when (side) {
          FootballScoringSide.HOME -> newItem.homeTeam
          FootballScoringSide.AWAY -> newItem.awayTeam
          FootballScoringSide.BOTH -> "${newItem.homeTeam} و${newItem.awayTeam}"
        }
        candidates.add(
          (0 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.GOAL,
            titleAr = "هدف!",
            subtitleAr = "$scorerTeam • ${newItem.homeScore} - ${newItem.awayScore}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore,
            scoringSide = side
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.STOPPED &&
        oldItem.matchPhase != FootballMatchPhase.STOPPED
      ) {
        candidates.add(
          (1 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.STOPPED,
            titleAr = "توقفت المباراة",
            subtitleAr = "${newItem.homeTeam} × ${newItem.awayTeam} (${newItem.minuteOrStatus})",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.FINISHED &&
        oldItem.matchPhase != FootballMatchPhase.FINISHED
      ) {
        candidates.add(
          (2 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.FULL_TIME,
            titleAr = "انتهت المباراة",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.HALFTIME &&
        oldItem.matchPhase != FootballMatchPhase.HALFTIME
      ) {
        candidates.add(
          (3 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.HALFTIME,
            titleAr = "استراحة الشوطين",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      }
    }

    return candidates.minByOrNull { it.first }?.second
  }

  private fun resolveMatchPhase(
    stateCode: String,
    typeName: String,
    shortDetail: String,
    description: String
  ): FootballMatchPhase {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    val isStoppedKeyword = combined.contains("suspend") ||
      combined.contains("delay") ||
      combined.contains("interrupt") ||
      combined.contains("postpon") ||
      combined.contains("abandon") ||
      combined.contains("cancel") ||
      combined.contains("rain")

    if (isStoppedKeyword) return FootballMatchPhase.STOPPED

    if (stateCode == "post" ||
      typeName.contains("FINAL") ||
      typeName.contains("FULL_TIME") ||
      shortDetail.equals("FT", ignoreCase = true) ||
      shortDetail.equals("AET", ignoreCase = true) ||
      shortDetail.equals("PEN", ignoreCase = true)
    ) {
      return FootballMatchPhase.FINISHED
    }

    if (stateCode == "in") {
      if (typeName.contains("HALFTIME") ||
        typeName.contains("END_OF_PERIOD") ||
        shortDetail.equals("HT", ignoreCase = true) ||
        combined.contains("halftime")
      ) {
        return FootballMatchPhase.HALFTIME
      }
      return FootballMatchPhase.LIVE_PLAY
    }

    return FootballMatchPhase.SCHEDULED
  }

  private fun resolveStoppedLabelAr(
    typeName: String,
    shortDetail: String,
    description: String
  ): String {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    return when {
      combined.contains("postpon") -> "مؤجلة"
      combined.contains("cancel") || combined.contains("abandon") -> "ملغاة"
      combined.contains("delay") || combined.contains("rain") -> "تأخر مؤقت"
      else -> "توقفت لحدث"
    }
  }

  private fun extractClockSeconds(statusObj: JSONObject?, displayClock: String): Int {
    val rawClock = statusObj?.optDouble("clock", -1.0) ?: -1.0
    if (rawClock > 0.0 && !rawClock.isNaN()) {
      return rawClock.toInt()
    }
    if (displayClock.isBlank() || displayClock.contains("+")) return -1
    val cleaned = displayClock.replace("'", "").trim()
    if (cleaned.contains(":")) {
      val parts = cleaned.split(":")
      val mins = parts.getOrNull(0)?.toIntOrNull() ?: return -1
      val secs = parts.getOrNull(1)?.toIntOrNull() ?: 0
      return (mins * 60) + secs.coerceIn(0, 59)
    }
    val minsOnly = cleaned.toIntOrNull() ?: return -1
    return minsOnly * 60
  }

  private fun extractTeamName(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return "فريق"
    return team.optString("shortDisplayName").takeIf { it.isNotBlank() }
      ?: team.optString("displayName").takeIf { it.isNotBlank() }
      ?: team.optString("abbreviation").takeIf { it.isNotBlank() }
      ?: "فريق"
  }

  private fun extractTeamLogoUrl(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return ""
    val direct = team.optString("logo").trim()
    val fromArray = team.optJSONArray("logos")
      ?.optJSONObject(0)
      ?.optString("href")
      ?.trim()
      .orEmpty()
    val raw = direct.ifBlank { fromArray }
    return if (raw.startsWith("http://", ignoreCase = true)) {
      "https://" + raw.removePrefix("http://")
    } else {
      raw
    }
  }

  private fun extractTeamAbbrev(competitor: JSONObject, fallbackName: String): String {
    val team = competitor.optJSONObject("team")
    val abbrev = team?.optString("abbreviation")?.trim().orEmpty()
    if (abbrev.isNotBlank()) return abbrev.take(3).uppercase(Locale.US)
    val clean = fallbackName.trim()
    return if (clean.isNotBlank()) clean.take(2).uppercase(Locale.US) else "FC"
  }

  private fun formatScheduledTime(isoUtc: String): String? {
    if (isoUtc.isBlank()) return null
    val patterns = listOf("yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")
    for (p in patterns) {
      try {
        val parser = SimpleDateFormat(p, Locale.US).apply {
          timeZone = TimeZone.getTimeZone("UTC")
        }
        val date = parser.parse(isoUtc) ?: continue
        val out = SimpleDateFormat("HH:mm", Locale.US)
        return out.format(date)
      } catch (_: Exception) {
      }
    }
    return null
  }

  private fun toFriendlyError(err: Throwable): String {
    val msg = err.message.orEmpty()
    return when {
      err is UnknownHostException ||
        err is ConnectException ||
        msg.contains("Unable to resolve host", ignoreCase = true) ||
        msg.contains("No address associated", ignoreCase = true) ->
        "لا يوجد اتصال بالإنترنت لعرض نتائج المباريات"
      err is SocketTimeoutException || msg.contains("timeout", ignoreCase = true) ->
        "انتهت مهلة الاتصال بخدمة المباريات، حاول مجدداً"
      err is IllegalStateException && msg.isNotBlank() -> msg
      else -> "تعذر جلب نتائج المباريات حالياً"
    }
  }
}
