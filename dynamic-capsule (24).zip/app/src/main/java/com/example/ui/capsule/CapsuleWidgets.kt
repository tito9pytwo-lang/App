package com.example.ui.capsule

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FreeBreakfast
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.island.BluetoothState
import com.example.island.CompassState
import com.example.island.DeliveryState
import com.example.island.FocusState
import com.example.island.FootballEventType
import com.example.island.FootballMatchPhase
import com.example.island.FootballScoringSide
import com.example.island.FootballState
import com.example.island.HourlyWeatherItem
import com.example.island.StepsState
import com.example.island.WeatherState
import kotlinx.coroutines.delay
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun weatherIconAndColor(weatherCode: Int, isDay: Boolean = true, isWarning: Boolean = false): Pair<ImageVector, Color> {
  if (isWarning) return Pair(Icons.Default.Warning, Color(0xFFFFB300))
  return when {
    weatherCode >= 95 -> Pair(Icons.Default.Thunderstorm, Color(0xFFFF9800))
    weatherCode in listOf(71, 73, 75, 77, 85, 86) -> Pair(Icons.Default.AcUnit, Color(0xFF81D4FA))
    weatherCode in listOf(51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82) -> Pair(Icons.Default.Grain, Color(0xFF4FC3F7))
    weatherCode in listOf(2, 3, 45, 48) -> Pair(Icons.Default.Cloud, Color(0xFFB0BEC5))
    !isDay -> Pair(Icons.Default.NightsStay, Color(0xFF90CAF9))
    else -> Pair(Icons.Default.WbSunny, Color(0xFFFFD54F))
  }
}

// =======================
// 1. BLUETOOTH MINI + EXPANDED
// =======================

@Composable
fun MiniBluetoothContent(
  bluetooth: BluetoothState,
  accentColor: Color
) {
  val btColor = when {
    bluetooth.batteryPct in 0..20 -> Color(0xFFFF453A)
    bluetooth.batteryPct in 21..100 -> RealmeGreen
    else -> Color(0xFF4285F4)
  }

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.20f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Headphones, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
      }
      MarqueeFadingText(
        text = bluetooth.deviceName,
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(10.dp))
        .background(btColor.copy(alpha = 0.18f))
        .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
      ) {
        if (bluetooth.batteryPct in 0..100) {
          Icon(Icons.Default.BatteryStd, contentDescription = null, tint = btColor, modifier = Modifier.size(13.dp))
          Text(
            text = "${bluetooth.batteryPct}%",
            color = btColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold
          )
        } else {
          Icon(Icons.Default.BluetoothConnected, contentDescription = null, tint = btColor, modifier = Modifier.size(13.dp))
          Text("متصل", color = btColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun ExpandedBluetoothView(
  bluetooth: BluetoothState,
  accentColor: Color,
  context: Context,
  onOpenSettings: () -> Unit
) {
  val hasBattery = bluetooth.batteryPct in 0..100
  val pctColor = when {
    !hasBattery -> Color(0xFF4285F4)
    bluetooth.batteryPct <= 20 -> Color(0xFFFF453A)
    bluetooth.batteryPct <= 50 -> Color(0xFFFFB74D)
    else -> RealmeGreen
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(pctColor.copy(alpha = 0.18f))
            .border(1.5.dp, pctColor.copy(alpha = 0.7f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Headphones, contentDescription = null, tint = pctColor, modifier = Modifier.size(25.dp))
        }
        Column {
          Text(
            text = if (bluetooth.isConnected) "جهاز بلوتوث متصل" else "سماعة بلوتوث",
            color = TextSecondary,
            fontSize = 11.sp
          )
          MarqueeFadingText(
            text = bluetooth.deviceName,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      if (hasBattery) {
        Text(
          text = "${bluetooth.batteryPct}%",
          color = pctColor,
          fontSize = 24.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    if (hasBattery) {
      LinearProgressIndicator(
        progress = { (bluetooth.batteryPct / 100f).coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(CircleShape),
        color = pctColor,
        trackColor = Color(0xFF222834)
      )
    } else {
      Text(
        text = "نسبة البطارية غير متوفرة من هذه السماعة أو نظام الهاتف حالياً.",
        color = TextMuted,
        fontSize = 11.sp
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.18f))
          .clickable {
            try {
              val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
              context.startActivity(intent)
            } catch (_: Exception) {}
            onOpenSettings()
          }
          .padding(horizontal = 14.dp, vertical = 7.dp)
      ) {
        Text("إعدادات البلوتوث", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }

      Text(
        text = if (hasBattery) "شحن السماعة المباشر" else "صوت لاسلكي",
        color = TextSecondary,
        fontSize = 11.sp
      )
    }
  }
}

// =======================
// 2. LIVE WEATHER MINI + EXPANDED (Inspired by Screenshot 1)
// =======================

@Composable
fun MiniWeatherContent(weatherState: WeatherState) {
  val (icon, tint) = weatherIconAndColor(
    weatherCode = weatherState.weatherCode,
    isDay = weatherState.isDay,
    isWarning = weatherState.isWarning
  )
  val ambientTransition = rememberInfiniteTransition(label = "mini_weather_ambient")
  val iconPulse by ambientTransition.animateFloat(
    initialValue = 0.94f,
    targetValue = 1.08f,
    animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
    label = "mini_weather_pulse"
  )

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(tint.copy(alpha = if (weatherState.isWarning) 0.92f else 0.22f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = weatherState.conditionAr,
          tint = if (weatherState.isWarning) Color.Black else tint,
          modifier = Modifier
            .size(16.dp)
            .graphicsLayer {
              scaleX = iconPulse
              scaleY = iconPulse
            }
        )
      }

      val label = buildString {
        append(weatherState.conditionAr.ifBlank { "الطقس" })
        if (weatherState.cityName.isNotBlank()) {
          append(" • ")
          append(weatherState.cityName)
        }
      }
      MarqueeFadingText(
        text = label,
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Text(
      text = "${weatherState.temperatureC}°",
      color = tint,
      fontSize = 14.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedWeatherView(
  weatherState: WeatherState,
  onRefresh: () -> Unit
) {
  val (icon, iconColor) = weatherIconAndColor(
    weatherCode = weatherState.weatherCode,
    isDay = weatherState.isDay,
    isWarning = weatherState.isWarning
  )

  // Continuous living animations so weather always feels alive without needing manual Refresh clicks
  val weatherAmbient = rememberInfiniteTransition(label = "expanded_weather_ambient")
  val iconFloatY by weatherAmbient.animateFloat(
    initialValue = -2.2f,
    targetValue = 2.2f,
    animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse),
    label = "weather_float_y"
  )
  val iconBreath by weatherAmbient.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.07f,
    animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Reverse),
    label = "weather_breath"
  )
  val loadingSpin by weatherAmbient.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(tween(950, easing = LinearEasing), RepeatMode.Restart),
    label = "weather_refresh_spin"
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_weather_view"),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    // Top location, date, wind/humidity & refresh button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
      ) {
        Icon(Icons.Default.LocationOn, contentDescription = null, tint = iconColor, modifier = Modifier.size(14.dp))
        Column {
          Text(
            text = weatherState.cityName.ifBlank { "الطقس المباشر" },
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          if (weatherState.dateLabel.isNotBlank()) {
            Text(weatherState.dateLabel, color = TextMuted, fontSize = 9.sp, maxLines = 1)
          }
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(horizontal = 7.dp, vertical = 3.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Icon(Icons.Default.WaterDrop, contentDescription = null, tint = Color(0xFF4FC3F7), modifier = Modifier.size(11.dp))
          Text("${weatherState.humidityPct}%", color = TextSecondary, fontSize = 10.sp)
          Icon(Icons.Default.Air, contentDescription = null, tint = Color(0xFF90CAF9), modifier = Modifier.size(11.dp))
          Text("${weatherState.windSpeedKmh}", color = TextSecondary, fontSize = 10.sp)
        }

        Box(
          modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onRefresh),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "تحديث الطقس",
            tint = iconColor,
            modifier = Modifier
              .size(15.dp)
              .graphicsLayer {
                rotationZ = if (weatherState.isLoading) loadingSpin else 0f
              }
          )
        }
      }
    }

    // Centerpiece Solar Horizon Arc + Sunrise/Sunset + Big Temperature
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(64.dp),
      contentAlignment = Alignment.Center
    ) {
      SolarArcCanvas(
        progress = weatherState.sunriseProgress,
        isDay = weatherState.isDay,
        modifier = Modifier
          .fillMaxWidth()
          .height(62.dp)
      )

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp)
          .align(Alignment.BottomCenter),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
      ) {
        Column(horizontalAlignment = Alignment.Start) {
          Text("الشروق", color = TextMuted, fontSize = 9.sp)
          Text(weatherState.sunriseText.ifBlank { "06:00" }, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = iconColor,
              modifier = Modifier
                .size(19.dp)
                .graphicsLayer {
                  translationY = iconFloatY
                  scaleX = iconBreath
                  scaleY = iconBreath
                }
            )
            Text(
              text = if (weatherState.isLoaded) "${weatherState.temperatureC}°C" else if (weatherState.isLoading) "..." else "--°C",
              color = Color.White,
              fontSize = 22.sp,
              fontWeight = FontWeight.ExtraBold
            )
          }
          Text(
            text = when {
              weatherState.isLoaded -> weatherState.conditionAr
              weatherState.isLoading -> "جاري تحديث الطقس تلقائياً..."
              !weatherState.errorMessage.isNullOrBlank() -> weatherState.errorMessage!!
              else -> "الطقس التلقائي"
            },
            color = iconColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("الغروب", color = TextMuted, fontSize = 9.sp)
          Text(weatherState.sunsetText.ifBlank { "18:00" }, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Bottom Hourly Forecast Strip (high-contrast, full unclipped icons & temperatures)
    if (weatherState.hourlyForecast.isNotEmpty()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("weather_hourly_strip")
          .clip(RoundedCornerShape(14.dp))
          .background(Color(0xFF131824))
          .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
          .padding(horizontal = 10.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        weatherState.hourlyForecast.take(6).forEach { item ->
          HourlyForecastSlot(item)
        }
      }
    }
  }
}

@Composable
private fun HourlyForecastSlot(item: HourlyWeatherItem) {
  val hourNum = item.hourLabel.take(2).toIntOrNull() ?: 12
  val slotIsDay = hourNum in 6..18
  val (icon, tint) = weatherIconAndColor(item.weatherCode, isDay = slotIsDay)
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(3.dp)
  ) {
    Text(
      text = item.hourLabel,
      color = Color(0xFFB4BED2),
      fontSize = 10.sp,
      fontWeight = FontWeight.Medium,
      maxLines = 1
    )
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = tint,
      modifier = Modifier.size(16.dp)
    )
    Text(
      text = "${item.tempC}°",
      color = Color.White,
      fontSize = 11.sp,
      fontWeight = FontWeight.ExtraBold,
      maxLines = 1
    )
  }
}

@Composable
fun SolarArcCanvas(
  progress: Float,
  isDay: Boolean,
  modifier: Modifier = Modifier
) {
  val clamped = progress.coerceIn(0.05f, 0.95f)
  val animatedPos by animateFloatAsState(
    targetValue = clamped,
    animationSpec = tween(durationMillis = 700),
    label = "sun_arc_pos"
  )

  // Continuous living solar/lunar animation (sunbeams, halo breathing, shimmering horizon / twinkling night stars)
  val skyTransition = rememberInfiniteTransition(label = "solar_arc_living")
  val haloPulse by skyTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.25f,
    animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Reverse),
    label = "solar_halo_pulse"
  )
  val raySpin by skyTransition.animateFloat(
    initialValue = 0f,
    targetValue = (2f * PI).toFloat(),
    animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
    label = "solar_ray_spin"
  )
  val arcSweep by skyTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing), RepeatMode.Restart),
    label = "solar_arc_sweep"
  )

  Canvas(modifier = modifier) {
    val startX = size.width * 0.12f
    val endX = size.width * 0.88f
    val baseY = size.height * 0.82f
    val peakY = size.height * 0.12f
    val midX = (startX + endX) / 2f

    val path = Path().apply {
      moveTo(startX, baseY)
      quadraticTo(midX, peakY - 18f, endX, baseY)
    }

    // Background arc with subtle live traveling highlight
    val arcBaseColor = if (isDay) Color(0xFF3E351A) else Color(0xFF1F2B3D)
    val arcGlowColor = if (isDay) Color(0xFFFFD54F) else Color(0xFF81D4FA)
    val shimmerX = startX + (endX - startX) * arcSweep
    drawPath(
      path = path,
      brush = Brush.horizontalGradient(
        colors = listOf(arcBaseColor, arcGlowColor.copy(alpha = 0.72f), arcBaseColor),
        startX = shimmerX - size.width * 0.35f,
        endX = shimmerX + size.width * 0.35f
      ),
      style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
    )

    // Twinkling stars in night sky mode
    if (!isDay) {
      val starPoints = listOf(
        Offset(size.width * 0.22f, size.height * 0.24f),
        Offset(size.width * 0.38f, size.height * 0.14f),
        Offset(size.width * 0.65f, size.height * 0.18f),
        Offset(size.width * 0.78f, size.height * 0.30f)
      )
      starPoints.forEachIndexed { idx, pt ->
        val twinkle = (0.35f + 0.55f * (0.5f + 0.5f * sin(raySpin * 2f + idx * 1.4f))).coerceIn(0.2f, 0.9f)
        drawCircle(
          color = Color(0xFFB3E5FC).copy(alpha = twinkle),
          radius = 1.6.dp.toPx(),
          center = pt
        )
      }
    }

    // Evaluate celestial orb point along quadratic bezier curve
    val t = animatedPos
    val oneMinusT = 1f - t
    val ctrlY = peakY - 18f
    val sunX = (oneMinusT * oneMinusT * startX) + (2f * oneMinusT * t * midX) + (t * t * endX)
    val sunY = (oneMinusT * oneMinusT * baseY) + (2f * oneMinusT * t * ctrlY) + (t * t * baseY)

    val haloColor = if (isDay) Color(0xFFFFD54F) else Color(0xFF81D4FA)
    val haloRadius = 18.dp.toPx() * haloPulse
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(haloColor.copy(alpha = 0.48f), Color.Transparent),
        center = Offset(sunX, sunY),
        radius = haloRadius
      ),
      radius = haloRadius,
      center = Offset(sunX, sunY)
    )

    // Rotating subtle sun rays during daytime
    if (isDay) {
      val innerR = 7.5.dp.toPx()
      val outerR = 11.dp.toPx()
      for (i in 0 until 8) {
        val a = raySpin + (i * PI.toFloat() / 4f)
        drawLine(
          color = haloColor.copy(alpha = 0.72f),
          start = Offset(sunX + cos(a) * innerR, sunY + sin(a) * innerR),
          end = Offset(sunX + cos(a) * outerR, sunY + sin(a) * outerR),
          strokeWidth = 1.4.dp.toPx(),
          cap = StrokeCap.Round
        )
      }
    }

    drawCircle(
      color = haloColor,
      radius = 6.dp.toPx(),
      center = Offset(sunX, sunY)
    )
  }
}

// =======================
// 3. STEP COUNTER & DISTANCE MINI + EXPANDED (Inspired by Screenshot 2)
// =======================

@Composable
fun MiniStepsContent(stepsState: StepsState) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      WindingStepPathCanvas(
        progress = stepsState.goalFraction,
        color = RealmeGreen,
        strokeWidth = 2.6.dp,
        modifier = Modifier.size(width = 34.dp, height = 18.dp)
      )
      Text(
        text = "${stepsState.steps} خطوة",
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1
      )
    }

    Text(
      text = String.format(Locale.US, "%.2f Km", stepsState.distanceKm),
      color = RealmeGreen,
      fontSize = 12.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
private fun AnimatedMilestoneStar(
  unlocked: Boolean,
  modifier: Modifier = Modifier
) {
  var celebrateBounce by remember { mutableStateOf(false) }
  var prevUnlocked by remember { mutableStateOf(unlocked) }

  LaunchedEffect(unlocked) {
    if (unlocked && !prevUnlocked) {
      celebrateBounce = true
      delay(480)
      celebrateBounce = false
    }
    prevUnlocked = unlocked
  }

  val starScale by animateFloatAsState(
    targetValue = when {
      celebrateBounce -> 1.48f
      unlocked -> 1.12f
      else -> 0.92f
    },
    animationSpec = spring(
      dampingRatio = 0.36f,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "step_star_unlock_scale"
  )
  val starTint by animateColorAsState(
    targetValue = if (unlocked) RealmeGreen else Color(0xFF333B4A),
    animationSpec = tween(durationMillis = 320),
    label = "step_star_unlock_tint"
  )
  val haloAlpha by animateFloatAsState(
    targetValue = when {
      celebrateBounce -> 0.55f
      unlocked -> 0.20f
      else -> 0f
    },
    animationSpec = tween(durationMillis = 320),
    label = "step_star_halo"
  )

  Box(
    modifier = modifier.size(20.dp),
    contentAlignment = Alignment.Center
  ) {
    if (haloAlpha > 0.01f) {
      Box(
        modifier = Modifier
          .size(18.dp)
          .clip(CircleShape)
          .background(RealmeGreen.copy(alpha = haloAlpha))
      )
    }
    Icon(
      imageVector = Icons.Default.Star,
      contentDescription = if (unlocked) "نجمة مكتسبة" else "نجمة قادمة",
      tint = starTint,
      modifier = Modifier
        .size(15.dp)
        .graphicsLayer {
          scaleX = starScale
          scaleY = starScale
          rotationZ = if (celebrateBounce) 14f else 0f
        }
    )
  }
}

@Composable
fun ExpandedStepsView(
  stepsState: StepsState,
  onCycleGoal: () -> Unit,
  onTogglePause: () -> Unit,
  onResetToday: () -> Unit
) {
  val frac = stepsState.goalFraction
  val starsCount = when {
    frac >= 1f -> 4
    frac >= 0.75f -> 3
    frac >= 0.50f -> 2
    frac >= 0.25f -> 1
    else -> 0
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_steps_view"),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Top Header: Title + Original 4 Animated Milestone Stars (bounce + glow on unlock)
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(16.dp))
        Text("خطوات اليوم", color = RealmeGreen, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
      }

      Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        for (i in 1..4) {
          AnimatedMilestoneStar(unlocked = i <= starsCount)
        }
      }
    }

    // Hero 3-column metrics + glowing winding S-path center graphic
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Steps + Duration
      Column(
        modifier = Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.Default.Timer, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(15.dp))
        Text(
          text = "${stepsState.steps}",
          color = Color.White,
          fontSize = 19.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (stepsState.activeSeconds > 0) stepsState.formatActiveDuration() else "الخطوات اليوم",
          color = TextMuted,
          fontSize = 10.sp
        )
      }

      // Center: Neon green winding step progress path
      WindingStepPathCanvas(
        progress = stepsState.goalFraction,
        color = RealmeGreen,
        strokeWidth = 5.5.dp,
        modifier = Modifier.size(width = 92.dp, height = 46.dp)
      )

      // Right: Distance + Calories + Goal
      Column(
        modifier = Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
        Text(
          text = String.format(Locale.US, "%.2f Km", stepsState.distanceKm),
          color = Color.White,
          fontSize = 16.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = "${stepsState.caloriesKcal} سعرة • هدف ${stepsState.dailyGoal}",
          color = TextMuted,
          fontSize = 10.sp,
          maxLines = 1
        )
      }
    }

    if (!stepsState.hasHardwareSensor) {
      Text(
        text = "لا يتوفر مستشعر خطوات مدمج في هذا الجهاز",
        color = Color(0xFFFFB74D),
        fontSize = 10.sp
      )
    }

    // Bottom Controls: Change Goal, Primary Green Pill Reset/Status, Pause/Resume
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(Color(0xFF1F242E))
          .clickable(onClick = onCycleGoal),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Flag, contentDescription = "تغيير الهدف", tint = TextPrimary, modifier = Modifier.size(16.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Box(
        modifier = Modifier
          .clip(CircleShape)
          .background(RealmeGreen)
          .clickable(onClick = onResetToday)
          .padding(horizontal = 24.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "تصفير اليوم",
          color = Color.Black,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(Color(0xFF1F242E))
          .clickable(onClick = onTogglePause),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (stepsState.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
          contentDescription = if (stepsState.isPaused) "استئناف العد" else "إيقاف مؤقت",
          tint = TextPrimary,
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

@Composable
fun WindingStepPathCanvas(
  progress: Float,
  color: Color,
  strokeWidth: Dp,
  modifier: Modifier = Modifier
) {
  val animFrac by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 550),
    label = "step_path_progress"
  )

  Canvas(modifier = modifier) {
    val pad = strokeWidth.toPx() * 1.4f
    val w = (size.width - pad * 2).coerceAtLeast(10f)
    val h = (size.height - pad * 2).coerceAtLeast(8f)
    val left = pad
    val top = pad
    val bottom = pad + h

    val fullPath = Path().apply {
      moveTo(left, bottom)
      lineTo(left, top + h * 0.25f)
      cubicTo(left, top, left + w * 0.33f, top, left + w * 0.33f, top + h * 0.35f)
      lineTo(left + w * 0.33f, bottom - h * 0.2f)
      cubicTo(left + w * 0.33f, bottom, left + w * 0.67f, bottom, left + w * 0.67f, bottom - h * 0.35f)
      lineTo(left + w * 0.67f, top + h * 0.25f)
      cubicTo(left + w * 0.67f, top, left + w, top, left + w, top + h * 0.4f)
      lineTo(left + w, bottom)
    }

    // Track path
    drawPath(
      path = fullPath,
      color = Color(0xFF282E3A),
      style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Progress sub-path via PathMeasure
    val measure = PathMeasure()
    measure.setPath(fullPath, false)
    val activePath = Path()
    val stopDist = measure.length * animFrac.coerceAtLeast(0.06f)
    measure.getSegment(0f, stopDist, activePath, true)

    drawPath(
      path = activePath,
      color = color,
      style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Start & end node dots
    val nodeR = (strokeWidth.toPx() * 0.85f).coerceAtLeast(2.5f)
    drawCircle(color = color, radius = nodeR, center = Offset(left, bottom))
    drawCircle(
      color = if (animFrac >= 0.99f) color else Color(0xFF3E4759),
      radius = nodeR,
      center = Offset(left + w, bottom)
    )
  }
}

// =======================
// 4. EXTRA REAL FEATURES: COMPASS + POMODORO FOCUS
// =======================

@Composable
fun MiniCompassContent(compass: CompassState, accentColor: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Explore, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
      }
      Text("البوصلة: ${compass.directionAr}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }

    Text(
      text = "${compass.azimuthDeg.toInt()}°",
      color = accentColor,
      fontSize = 13.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedCompassView(
  compass: CompassState,
  accentColor: Color,
  onStopCompass: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Canvas(modifier = Modifier.size(62.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f - 4f
        drawCircle(
          color = Color(0xFF1E2532),
          radius = radius,
          style = Stroke(width = 3.dp.toPx())
        )
        val angleRad = Math.toRadians((-compass.azimuthDeg).toDouble() - 90.0)
        val tipX = center.x + (cos(angleRad) * (radius - 6f)).toFloat()
        val tipY = center.y + (sin(angleRad) * (radius - 6f)).toFloat()
        val oppX = center.x - (cos(angleRad) * (radius * 0.45f)).toFloat()
        val oppY = center.y - (sin(angleRad) * (radius * 0.45f)).toFloat()

        drawLine(color = Color(0xFFFF453A), start = center, end = Offset(tipX, tipY), strokeWidth = 3.5.dp.toPx(), cap = StrokeCap.Round)
        drawLine(color = TextSecondary, start = center, end = Offset(oppX, oppY), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = center)
      }

      Column {
        Text(
          text = if (compass.hasSensor) "${compass.azimuthDeg.toInt()}° ${compass.directionAr}" else "غير مدعوم",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (compass.hasSensor) "مستشعر المغناطيسية الحقيقي" else "لا يتوفر مستشعر بوصلة",
          color = TextSecondary,
          fontSize = 11.sp
        )
      }
    }

    Box(
      modifier = Modifier
        .clip(CircleShape)
        .background(Color(0xFF2C2F38))
        .clickable(onClick = onStopCompass)
        .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
      Text("إغلاق", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
fun MiniFocusContent(focus: FocusState) {
  val color = if (focus.isBreak) Color(0xFF00E5FF) else Color(0xFFFF6E6E)
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(color.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
      }
      Text(
        text = if (focus.isBreak) "استراحة تركيز" else "جلسة تركيز",
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }
    Text(
      text = focus.formatRemaining(),
      color = color,
      fontSize = 13.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedFocusView(
  focus: FocusState,
  onTogglePause: () -> Unit,
  onStartFocus: (Int, Boolean) -> Unit,
  onCancel: () -> Unit
) {
  val color = if (focus.isBreak) Color(0xFF00E5FF) else Color(0xFFFF6E6E)
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.CenterFocusStrong, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
        }
        Column {
          Text(
            text = when {
              !focus.isActive -> "مؤقت التركيز (Pomodoro)"
              focus.isBreak -> "وقت الاستراحة"
              else -> "جلسة التركيز العميق"
            },
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = if (focus.isActive) "ركّز على مهامك بدون تشتيت" else "ابدأ جلسة 25 دقيقة أو استراحة",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
      }

      if (focus.isActive) {
        Text(
          text = focus.formatRemaining(),
          color = color,
          fontSize = 22.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    if (focus.isActive) {
      val frac = if (focus.totalSeconds > 0) (focus.remainingSeconds.toFloat() / focus.totalSeconds).coerceIn(0f, 1f) else 0f
      LinearProgressIndicator(
        progress = { frac },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
        color = color,
        trackColor = Color(0xFF222834)
      )
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(color)
            .clickable(onClick = onTogglePause)
            .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
          Text(if (focus.isRunning) "إيقاف مؤقت" else "استئناف", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFF2C2F38))
            .clickable(onClick = onCancel)
            .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
          Text("إنهاء", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    } else {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple(25, false, "25د تركيز"), Triple(50, false, "50د عميق"), Triple(5, true, "5د راحة")).forEach { (m, brk, lbl) ->
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF1F242E))
              .clickable { onStartFocus(m, brk) }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(lbl, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

// =======================
// 5. DELIVERY ORDERS TRACKING (MINI + EXPANDED)
// =======================

@Composable
fun MiniDeliveryContent(delivery: DeliveryState) {
  val deliveryTint = Color(0xFFFF9F0A)
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Box(
        modifier = Modifier
          .size(28.dp)
          .clip(CircleShape)
          .background(deliveryTint.copy(alpha = 0.22f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.DeliveryDining, contentDescription = null, tint = deliveryTint, modifier = Modifier.size(16.dp))
      }
      MarqueeFadingText(
        text = delivery.statusTitle.ifBlank { delivery.appName },
        color = TextPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    if (delivery.etaText.isNotBlank() || delivery.progressPct in 0..100) {
      Spacer(modifier = Modifier.width(6.dp))
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(deliveryTint.copy(alpha = 0.20f))
          .padding(horizontal = 7.dp, vertical = 2.dp)
      ) {
        Text(
          text = delivery.etaText.ifBlank { "${delivery.progressPct}%" },
          color = deliveryTint,
          fontSize = 10.sp,
          fontWeight = FontWeight.ExtraBold,
          maxLines = 1
        )
      }
    }
  }
}

@Composable
fun ExpandedDeliveryView(
  delivery: DeliveryState,
  onOpenApp: () -> Unit,
  onDismiss: () -> Unit
) {
  val deliveryTint = Color(0xFFFF9F0A)
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_delivery_view")
      .padding(vertical = 4.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(deliveryTint.copy(alpha = 0.20f))
            .border(1.2.dp, deliveryTint.copy(alpha = 0.6f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.DeliveryDining, contentDescription = null, tint = deliveryTint, modifier = Modifier.size(24.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = delivery.appName.ifBlank { "طلب توصيل" },
            color = deliveryTint,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
          MarqueeFadingText(
            text = delivery.statusTitle.ifBlank { "تتبع الطلب مباشر" },
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold
          )
          if (delivery.detailText.isNotBlank()) {
            Text(
              text = delivery.detailText,
              color = TextSecondary,
              fontSize = 11.sp,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }

      if (delivery.etaText.isNotBlank()) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(deliveryTint.copy(alpha = 0.18f))
            .padding(horizontal = 9.dp, vertical = 5.dp)
        ) {
          Text(
            text = delivery.etaText,
            color = deliveryTint,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }
    }

    if (delivery.progressPct in 0..100) {
      LinearProgressIndicator(
        progress = { (delivery.progressPct / 100f).coerceIn(0f, 1f) },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(CircleShape),
        color = deliveryTint,
        trackColor = Color(0xFF222834)
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      if (delivery.packageName.isNotBlank()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(CircleShape)
            .background(deliveryTint)
            .clickable(onClick = onOpenApp)
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
          ) {
            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
            Text("فتح التطبيق", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
          }
        }
      }

      Box(
        modifier = Modifier
          .weight(1f)
          .clip(CircleShape)
          .background(Color(0xFF2C2F38))
          .clickable(onClick = onDismiss)
          .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
      ) {
        Text("إخفاء", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

// =======================
// 6. LIVE FOOTBALL MATCH RESULTS (MINI + EXPANDED)
// =======================

@Composable
fun TeamCrestBadge(
  logoUrl: String,
  teamName: String,
  abbrev: String,
  accentColor: Color,
  size: Dp,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val monogram = remember(abbrev, teamName) {
    abbrev.ifBlank { teamName.trim().take(2) }.take(3).uppercase(Locale.US)
  }

  Box(
    modifier = modifier
      .size(size)
      .clip(CircleShape)
      .background(Color.White.copy(alpha = 0.09f))
      .border(1.dp, accentColor.copy(alpha = 0.40f), CircleShape),
    contentAlignment = Alignment.Center
  ) {
    if (logoUrl.isNotBlank()) {
      SubcomposeAsyncImage(
        model = ImageRequest.Builder(context)
          .data(logoUrl)
          .crossfade(true)
          .build(),
        contentDescription = teamName,
        contentScale = ContentScale.Fit,
        modifier = Modifier
          .size(size - 6.dp)
          .clip(CircleShape),
        loading = {
          Text(
            text = monogram,
            color = accentColor,
            fontSize = (size.value * 0.28f).coerceIn(8f, 13f).sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
          )
        },
        error = {
          Text(
            text = monogram,
            color = accentColor,
            fontSize = (size.value * 0.28f).coerceIn(8f, 13f).sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
          )
        }
      )
    } else {
      Text(
        text = monogram,
        color = accentColor,
        fontSize = (size.value * 0.28f).coerceIn(8f, 13f).sp,
        fontWeight = FontWeight.ExtraBold,
        maxLines = 1
      )
    }
  }
}

@Composable
fun MiniFootballContent(footballState: FootballState) {
  val match = footballState.currentMatch
  val activeEvent = footballState.activeEvent
  val liveColor = Color(0xFFFF453A)
  val goalGold = Color(0xFFFFD60A)
  val halftimeCyan = Color(0xFF38BDF8)
  val stoppedAmber = Color(0xFFFF9F0A)
  val pitchGreen = RealmeGreen

  val animTransition = rememberInfiniteTransition(label = "mini_football_fx")
  val fxProgress by animTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
    label = "mini_fx_progress"
  )
  val pulseAlpha by animTransition.animateFloat(
    initialValue = 0.45f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
    label = "mini_pulse_alpha"
  )

  val eventType = activeEvent?.type
  val phase = match?.matchPhase ?: FootballMatchPhase.SCHEDULED
  val isGoalBanner = eventType == FootballEventType.GOAL
  val isStoppedFx = eventType == FootballEventType.STOPPED || phase == FootballMatchPhase.STOPPED
  val isHalftimeFx = eventType == FootballEventType.HALFTIME || phase == FootballMatchPhase.HALFTIME
  val isFinishedFx = eventType == FootballEventType.FULL_TIME || phase == FootballMatchPhase.FINISHED

  val homeGoalBounce by animateFloatAsState(
    targetValue = if (isGoalBanner &&
      (activeEvent?.scoringSide == FootballScoringSide.HOME || activeEvent?.scoringSide == FootballScoringSide.BOTH)
    ) 1.18f else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "mini_home_bounce"
  )
  val awayGoalBounce by animateFloatAsState(
    targetValue = if (isGoalBanner &&
      (activeEvent?.scoringSide == FootballScoringSide.AWAY || activeEvent?.scoringSide == FootballScoringSide.BOTH)
    ) 1.18f else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "mini_away_bounce"
  )

  Box(modifier = Modifier.fillMaxWidth()) {
    // Background celebratory / phase FX canvas
    if (isGoalBanner || isFinishedFx || isStoppedFx || isHalftimeFx) {
      Canvas(
        modifier = Modifier
          .fillMaxWidth()
          .height(28.dp)
          .align(Alignment.Center)
      ) {
        when {
          isGoalBanner -> {
            // Radial golden-green goal celebration sparks
            val center = Offset(size.width * 0.25f, size.height * 0.5f)
            val maxR = size.width * 0.45f * fxProgress
            drawCircle(
              color = goalGold.copy(alpha = (1f - fxProgress) * 0.35f),
              radius = maxR,
              center = center,
              style = Stroke(width = 2.dp.toPx())
            )
            for (i in 0 until 7) {
              val angle = (i * 51.4f + fxProgress * 90f) * (PI / 180.0)
              val dist = (8f + fxProgress * 36f)
              val sx = center.x + (cos(angle) * dist).toFloat()
              val sy = center.y + (sin(angle) * dist * 0.45f).toFloat()
              drawCircle(
                color = (if (i % 2 == 0) goalGold else pitchGreen).copy(alpha = (1f - fxProgress) * 0.85f),
                radius = 2.dp.toPx(),
                center = Offset(sx.coerceIn(4f, size.width - 4f), sy.coerceIn(2f, size.height - 2f))
              )
            }
          }
          isFinishedFx -> {
            // Sweeping gold full-time shimmer
            val beamX = (fxProgress * 1.4f - 0.2f) * size.width
            drawRect(
              brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, goalGold.copy(alpha = 0.20f), Color.Transparent),
                startX = beamX - 40f,
                endX = beamX + 40f
              )
            )
          }
          isStoppedFx -> {
            drawRect(
              color = stoppedAmber.copy(alpha = pulseAlpha * 0.14f)
            )
          }
          isHalftimeFx -> {
            val waveOffset = fxProgress * 2f * PI.toFloat()
            val yWave = size.height - 2.dp.toPx() + sin(waveOffset) * 1.5f
            drawLine(
              color = halftimeCyan.copy(alpha = 0.45f),
              start = Offset(0f, yWave),
              end = Offset(size.width, yWave),
              strokeWidth = 1.5.dp.toPx()
            )
          }
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      if (match != null) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          TeamCrestBadge(
            logoUrl = match.homeLogoUrl,
            teamName = match.homeTeam,
            abbrev = match.homeAbbrev,
            accentColor = if (isGoalBanner &&
              (activeEvent?.scoringSide == FootballScoringSide.HOME || activeEvent?.scoringSide == FootballScoringSide.BOTH)
            ) goalGold else pitchGreen,
            size = 22.dp,
            modifier = Modifier.graphicsLayer {
              scaleX = homeGoalBounce
              scaleY = homeGoalBounce
            }
          )
          AnimatedContent(
            targetState = "${match.homeScore} - ${match.awayScore}",
            transitionSpec = {
              (slideInVertically { -it } + fadeIn() + scaleIn(initialScale = 0.85f))
                .togetherWith(slideOutVertically { it } + fadeOut())
            },
            label = "mini_score_pop"
          ) { scoreText ->
            Text(
              text = scoreText,
              color = if (isGoalBanner) goalGold else Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.ExtraBold,
              maxLines = 1
            )
          }
          TeamCrestBadge(
            logoUrl = match.awayLogoUrl,
            teamName = match.awayTeam,
            abbrev = match.awayAbbrev,
            accentColor = if (isGoalBanner &&
              (activeEvent?.scoringSide == FootballScoringSide.AWAY || activeEvent?.scoringSide == FootballScoringSide.BOTH)
            ) goalGold else Color(0xFF64D2FF),
            size = 22.dp,
            modifier = Modifier.graphicsLayer {
              scaleX = awayGoalBounce
              scaleY = awayGoalBounce
            }
          )
          MarqueeFadingText(
            text = if (isGoalBanner && activeEvent != null) {
              "⚽ هدف! ${activeEvent.subtitleAr}"
            } else {
              "${match.homeTeam} × ${match.awayTeam}"
            },
            color = if (isGoalBanner) goalGold else TextSecondary,
            fontSize = 10.5.sp,
            fontWeight = if (isGoalBanner) FontWeight.ExtraBold else FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
          )
        }
        Spacer(modifier = Modifier.width(6.dp))

        val pillBg = when {
          isGoalBanner -> goalGold.copy(alpha = 0.24f)
          isStoppedFx -> stoppedAmber.copy(alpha = 0.22f * pulseAlpha)
          isHalftimeFx -> halftimeCyan.copy(alpha = 0.20f)
          isFinishedFx -> goalGold.copy(alpha = 0.16f)
          phase == FootballMatchPhase.LIVE_PLAY -> liveColor.copy(alpha = 0.22f)
          else -> pitchGreen.copy(alpha = 0.18f)
        }
        val pillTextColor = when {
          isGoalBanner -> goalGold
          isStoppedFx -> stoppedAmber
          isHalftimeFx -> halftimeCyan
          isFinishedFx -> goalGold
          phase == FootballMatchPhase.LIVE_PLAY -> liveColor
          else -> pitchGreen
        }
        val pillLabel = when {
          isGoalBanner -> "⚽ هدف"
          isStoppedFx -> "⚠ ${match.minuteOrStatus}"
          isHalftimeFx -> "☕ استراحة"
          isFinishedFx -> "🏁 ${match.minuteOrStatus}"
          phase == FootballMatchPhase.LIVE_PLAY -> "● ${match.formattedLiveTime()}"
          else -> match.minuteOrStatus
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(pillBg)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = pillLabel,
            color = pillTextColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
          )
        }
      } else {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.SportsSoccer, contentDescription = null, tint = pitchGreen, modifier = Modifier.size(16.dp))
          Text(
            text = when {
              footballState.isLoading -> "جارٍ جلب نتائج المباريات..."
              !footballState.errorMessage.isNullOrBlank() -> footballState.errorMessage
              else -> footballState.leagueNameAr
            },
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
    }
  }
}

@Composable
fun ExpandedFootballView(
  footballState: FootballState,
  onPrevMatch: () -> Unit,
  onNextMatch: () -> Unit,
  onRefresh: () -> Unit
) {
  val match = footballState.currentMatch
  val activeEvent = footballState.activeEvent
  val pitchGreen = RealmeGreen
  val liveColor = Color(0xFFFF453A)
  val goalGold = Color(0xFFFFD60A)
  val halftimeCyan = Color(0xFF38BDF8)
  val stoppedAmber = Color(0xFFFF9F0A)

  val infiniteFx = rememberInfiniteTransition(label = "expanded_football_fx")
  val livePulse by infiniteFx.animateFloat(
    initialValue = 0.35f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
    label = "live_dot_alpha"
  )
  val fxCycle by infiniteFx.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart),
    label = "expanded_fx_cycle"
  )

  val eventType = activeEvent?.type
  val phase = match?.matchPhase ?: FootballMatchPhase.SCHEDULED
  val isGoal = eventType == FootballEventType.GOAL
  val isStopped = eventType == FootballEventType.STOPPED || phase == FootballMatchPhase.STOPPED
  val isHalftime = eventType == FootballEventType.HALFTIME || phase == FootballMatchPhase.HALFTIME
  val isFinished = eventType == FootballEventType.FULL_TIME || phase == FootballMatchPhase.FINISHED

  val homeScale by animateFloatAsState(
    targetValue = if (isGoal &&
      (activeEvent?.scoringSide == FootballScoringSide.HOME || activeEvent?.scoringSide == FootballScoringSide.BOTH)
    ) 1.18f else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "exp_home_goal_scale"
  )
  val awayScale by animateFloatAsState(
    targetValue = if (isGoal &&
      (activeEvent?.scoringSide == FootballScoringSide.AWAY || activeEvent?.scoringSide == FootballScoringSide.BOTH)
    ) 1.18f else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "exp_away_goal_scale"
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("expanded_football_view")
      .padding(vertical = 2.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Top bar: League badge + Live/Match count + Refresh button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(Icons.Default.SportsSoccer, contentDescription = null, tint = pitchGreen, modifier = Modifier.size(16.dp))
        Text(
          text = footballState.leagueNameAr,
          color = pitchGreen,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
        if (footballState.matches.size > 1) {
          Text(
            text = "(${footballState.selectedIndex + 1}/${footballState.matches.size})",
            color = TextMuted,
            fontSize = 10.sp
          )
        }
      }

      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.10f))
          .clickable(onClick = onRefresh),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = "تحديث المباريات",
          tint = TextPrimary,
          modifier = Modifier.size(16.dp)
        )
      }
    }

    // Event Alert / Celebration Banner (Goal, Halftime, Stopped/Suspended, Match Ended)
    AnimatedVisibility(
      visible = activeEvent != null,
      enter = fadeIn(tween(220)) + expandVertically() + scaleIn(initialScale = 0.92f),
      exit = fadeOut(tween(180)) + shrinkVertically() + scaleOut(targetScale = 0.94f)
    ) {
      activeEvent?.let { ev ->
        val (bannerAccent, bannerIcon) = when (ev.type) {
          FootballEventType.GOAL -> goalGold to Icons.Default.SportsSoccer
          FootballEventType.FULL_TIME -> goalGold to Icons.Default.EmojiEvents
          FootballEventType.STOPPED -> stoppedAmber to Icons.Default.Warning
          FootballEventType.HALFTIME -> halftimeCyan to Icons.Default.FreeBreakfast
        }
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bannerAccent.copy(alpha = if (ev.type == FootballEventType.STOPPED) 0.18f * livePulse + 0.06f else 0.18f))
            .border(1.dp, bannerAccent.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = bannerIcon,
              contentDescription = ev.titleAr,
              tint = bannerAccent,
              modifier = Modifier
                .size(16.dp)
                .graphicsLayer {
                  if (ev.type == FootballEventType.GOAL) {
                    val pulse = 1f + 0.16f * sin(fxCycle * 2f * PI).toFloat()
                    scaleX = pulse
                    scaleY = pulse
                  }
                }
            )
            Text(
              text = "${ev.titleAr} • ${ev.subtitleAr}",
              color = bannerAccent,
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    if (match != null) {
      val cardBorderColor = when {
        isGoal -> goalGold.copy(alpha = 0.65f)
        isStopped -> stoppedAmber.copy(alpha = 0.35f + 0.45f * livePulse)
        isHalftime -> halftimeCyan.copy(alpha = 0.48f)
        isFinished -> goalGold.copy(alpha = 0.36f)
        else -> Color.White.copy(alpha = 0.10f)
      }

      val homeWinner = isFinished && match.homeScore > match.awayScore
      val awayWinner = isFinished && match.awayScore > match.homeScore

      // Scoreboard center card with animated FX backdrop
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(Color.White.copy(alpha = 0.06f))
          .border(1.dp, cardBorderColor, RoundedCornerShape(16.dp))
      ) {
        // Animated Canvas overlay for Goal / Full-Time / Stopped / Halftime / Live Play
        Canvas(modifier = Modifier.matchParentSize()) {
          when {
            isGoal -> {
              // Expanding goal shockwaves + celebration particles
              val cx = when (activeEvent?.scoringSide) {
                FootballScoringSide.HOME -> size.width * 0.22f
                FootballScoringSide.AWAY -> size.width * 0.78f
                else -> size.width * 0.50f
              }
              val cy = size.height * 0.45f
              for (ring in 0..1) {
                val p = (fxCycle + ring * 0.5f) % 1f
                drawCircle(
                  color = goalGold.copy(alpha = (1f - p) * 0.35f),
                  radius = p * size.width * 0.48f,
                  center = Offset(cx, cy),
                  style = Stroke(width = 2.dp.toPx())
                )
              }
              for (i in 0 until 10) {
                val ang = (i * 36f + fxCycle * 120f) * (PI / 180.0)
                val dist = 16f + fxCycle * (size.width * 0.35f)
                val px = cx + (cos(ang) * dist).toFloat()
                val py = cy + (sin(ang) * dist * 0.55f).toFloat()
                drawCircle(
                  color = (if (i % 2 == 0) goalGold else pitchGreen).copy(alpha = (1f - fxCycle) * 0.8f),
                  radius = 2.5.dp.toPx(),
                  center = Offset(px.coerceIn(6f, size.width - 6f), py.coerceIn(6f, size.height - 6f))
                )
              }
            }
            isStopped -> {
              // Pulsing amber/red alert stripe along the bottom
              drawLine(
                color = stoppedAmber.copy(alpha = livePulse * 0.85f),
                start = Offset(14.dp.toPx(), size.height - 3.dp.toPx()),
                end = Offset(size.width - 14.dp.toPx(), size.height - 3.dp.toPx()),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
              )
            }
            isHalftime -> {
              // Calm cyan halftime wave line
              val wavePath = Path()
              val baseY = size.height - 5.dp.toPx()
              val step = 12f
              var x = 16f
              wavePath.moveTo(x, baseY)
              while (x <= size.width - 16f) {
                val y = baseY + sin((x / 36f) + fxCycle * 2f * PI.toFloat()) * 2.2f
                wavePath.lineTo(x, y)
                x += step
              }
              drawPath(
                path = wavePath,
                color = halftimeCyan.copy(alpha = 0.65f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
              )
            }
            isFinished -> {
              // Golden final whistle shimmer beam across card
              val beamX = (fxCycle * 1.4f - 0.2f) * size.width
              drawRect(
                brush = Brush.horizontalGradient(
                  colors = listOf(Color.Transparent, goalGold.copy(alpha = 0.14f), Color.Transparent),
                  startX = beamX - 50f,
                  endX = beamX + 50f
                )
              )
            }
            phase == FootballMatchPhase.LIVE_PLAY -> {
              // Live pitch-green sweep bar along bottom
              val sweepX = fxCycle * size.width
              drawLine(
                color = pitchGreen.copy(alpha = 0.22f),
                start = Offset(16.dp.toPx(), size.height - 3.dp.toPx()),
                end = Offset(size.width - 16.dp.toPx(), size.height - 3.dp.toPx()),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
              )
              drawLine(
                color = pitchGreen.copy(alpha = 0.85f),
                start = Offset((sweepX - 36f).coerceAtLeast(16.dp.toPx()), size.height - 3.dp.toPx()),
                end = Offset((sweepX + 36f).coerceAtMost(size.width - 16.dp.toPx()), size.height - 3.dp.toPx()),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
              )
            }
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
          ) {
            TeamCrestBadge(
              logoUrl = match.homeLogoUrl,
              teamName = match.homeTeam,
              abbrev = match.homeAbbrev,
              accentColor = when {
                isGoal && (activeEvent?.scoringSide == FootballScoringSide.HOME || activeEvent?.scoringSide == FootballScoringSide.BOTH) -> goalGold
                homeWinner -> goalGold
                else -> pitchGreen
              },
              size = 38.dp,
              modifier = Modifier.graphicsLayer {
                scaleX = homeScale
                scaleY = homeScale
              }
            )
            Text(
              text = match.homeTeam,
              color = if (homeWinner) goalGold else TextPrimary,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              textAlign = TextAlign.Center
            )
          }

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 6.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              AnimatedContent(
                targetState = match.homeScore,
                transitionSpec = {
                  (slideInVertically { -it } + fadeIn() + scaleIn(initialScale = 0.7f))
                    .togetherWith(slideOutVertically { it } + fadeOut())
                },
                label = "home_score_anim"
              ) { score ->
                Text(
                  text = "$score",
                  color = if (isGoal) goalGold else Color.White,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.ExtraBold
                )
              }
              Text(
                text = "-",
                color = TextMuted,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              AnimatedContent(
                targetState = match.awayScore,
                transitionSpec = {
                  (slideInVertically { -it } + fadeIn() + scaleIn(initialScale = 0.7f))
                    .togetherWith(slideOutVertically { it } + fadeOut())
                },
                label = "away_score_anim"
              ) { score ->
                Text(
                  text = "$score",
                  color = if (isGoal) goalGold else Color.White,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }

            val statusBg = when {
              isStopped -> stoppedAmber.copy(alpha = 0.22f)
              isHalftime -> halftimeCyan.copy(alpha = 0.20f)
              isFinished -> goalGold.copy(alpha = 0.16f)
              phase == FootballMatchPhase.LIVE_PLAY -> liveColor.copy(alpha = 0.20f)
              else -> pitchGreen.copy(alpha = 0.18f)
            }
            val statusFg = when {
              isStopped -> stoppedAmber
              isHalftime -> halftimeCyan
              isFinished -> goalGold
              phase == FootballMatchPhase.LIVE_PLAY -> liveColor
              else -> pitchGreen
            }
            val statusText = when (phase) {
              FootballMatchPhase.LIVE_PLAY -> "مباشر ${match.formattedLiveTime()}"
              FootballMatchPhase.HALFTIME -> "استراحة"
              FootballMatchPhase.STOPPED -> match.minuteOrStatus
              FootballMatchPhase.FINISHED -> match.minuteOrStatus
              FootballMatchPhase.SCHEDULED -> match.minuteOrStatus
            }

            Box(
              modifier = Modifier
                .clip(CircleShape)
                .background(statusBg)
                .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                when (phase) {
                  FootballMatchPhase.LIVE_PLAY -> {
                    Box(
                      modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(liveColor.copy(alpha = livePulse))
                    )
                  }
                  FootballMatchPhase.STOPPED -> {
                    Icon(
                      imageVector = Icons.Default.PauseCircle,
                      contentDescription = null,
                      tint = stoppedAmber.copy(alpha = livePulse),
                      modifier = Modifier.size(11.dp)
                    )
                  }
                  FootballMatchPhase.HALFTIME -> {
                    Icon(
                      imageVector = Icons.Default.FreeBreakfast,
                      contentDescription = null,
                      tint = halftimeCyan,
                      modifier = Modifier.size(11.dp)
                    )
                  }
                  FootballMatchPhase.FINISHED -> {
                    Icon(
                      imageVector = Icons.Default.EmojiEvents,
                      contentDescription = null,
                      tint = goalGold,
                      modifier = Modifier.size(11.dp)
                    )
                  }
                  FootballMatchPhase.SCHEDULED -> Unit
                }
                Text(
                  text = statusText,
                  color = statusFg,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.ExtraBold
                )
              }
            }
          }

          Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
          ) {
            TeamCrestBadge(
              logoUrl = match.awayLogoUrl,
              teamName = match.awayTeam,
              abbrev = match.awayAbbrev,
              accentColor = when {
                isGoal && (activeEvent?.scoringSide == FootballScoringSide.AWAY || activeEvent?.scoringSide == FootballScoringSide.BOTH) -> goalGold
                awayWinner -> goalGold
                else -> Color(0xFF64D2FF)
              },
              size = 38.dp,
              modifier = Modifier.graphicsLayer {
                scaleX = awayScale
                scaleY = awayScale
              }
            )
            Text(
              text = match.awayTeam,
              color = if (awayWinner) goalGold else TextPrimary,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              textAlign = TextAlign.Center
            )
          }
        }
      }

      // Match navigation controls if > 1 match
      if (footballState.matches.size > 1) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(Color(0xFF1F242E))
              .clickable(onClick = onPrevMatch),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "المباراة السابقة", tint = TextPrimary, modifier = Modifier.size(18.dp))
          }
          Spacer(modifier = Modifier.width(16.dp))
          Text(
            text = "تبديل المباراة",
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.width(16.dp))
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(Color(0xFF1F242E))
              .clickable(onClick = onNextMatch),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "المباراة التالية", tint = TextPrimary, modifier = Modifier.size(18.dp))
          }
        }
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(Color.White.copy(alpha = 0.05f))
          .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Text(
          text = when {
            footballState.isLoading -> "جارٍ تحميل نتائج ${footballState.leagueNameAr}..."
            !footballState.errorMessage.isNullOrBlank() -> footballState.errorMessage
            else -> "لا توجد مباريات معروضة حالياً"
          },
          color = TextSecondary,
          fontSize = 12.sp,
          textAlign = TextAlign.Center
        )
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(pitchGreen)
            .clickable(onClick = onRefresh)
            .padding(horizontal = 18.dp, vertical = 7.dp)
        ) {
          Text("تحديث الآن", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
      }
    }
  }
}
