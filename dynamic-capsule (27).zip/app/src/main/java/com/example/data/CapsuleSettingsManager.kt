package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CapsuleSettingsManager private constructor(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("dynamic_capsule_prefs", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(loadSettings())
  val settings: StateFlow<CapsuleSettings> = _settings.asStateFlow()

  private fun loadSettings(): CapsuleSettings {
    return CapsuleSettings(
      serviceEnabled = prefs.getBoolean(KEY_SERVICE_ENABLED, true),
      notchOffsetYDp = prefs.getInt(KEY_NOTCH_OFFSET_Y, 0),
      capsuleWidthDp = prefs.getInt(KEY_CAPSULE_WIDTH, 220),
      capsuleHeightDp = prefs.getInt(KEY_CAPSULE_HEIGHT, 46),
      accentColorIndex = prefs.getInt(KEY_ACCENT_COLOR, 0),
      autoCollapseSeconds = prefs.getInt(KEY_AUTO_COLLAPSE, 0),
      showWhenIdle = prefs.getBoolean(KEY_SHOW_WHEN_IDLE, false),
      hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true),
      enableBatteryAlerts = prefs.getBoolean(KEY_BATTERY_ALERTS, true),
      enableCallAlerts = prefs.getBoolean(KEY_CALL_ALERTS, true),
      enableTimer = prefs.getBoolean(KEY_TIMER, true),
      enableNotifications = prefs.getBoolean(KEY_NOTIFICATIONS, true),
      enableBluetoothAlerts = prefs.getBoolean(KEY_BLUETOOTH_ALERTS, true),
      enableFlashlightAlert = prefs.getBoolean(KEY_FLASHLIGHT_ALERT, true),
      enableRingerAlerts = prefs.getBoolean(KEY_RINGER_ALERTS, true),
      enableDownloadProgress = prefs.getBoolean(KEY_DOWNLOAD_PROGRESS, true),
      enableNavigationAlerts = prefs.getBoolean(KEY_NAVIGATION_ALERTS, true),
      enablePrivacyAlerts = prefs.getBoolean(KEY_PRIVACY_ALERTS, true),
      enableDualCapsule = prefs.getBoolean(KEY_DUAL_CAPSULE, true),
      enableDynamicAlbumColors = prefs.getBoolean(KEY_DYNAMIC_ALBUM_COLORS, true),
      capsuleStyleIndex = prefs.getInt(KEY_CAPSULE_STYLE, 0).coerceIn(0, 5),
      capsuleTransparent = prefs.getBoolean(KEY_CAPSULE_TRANSPARENT, true),
      capsuleOpacityPercent = prefs.getInt(KEY_CAPSULE_OPACITY, 88).coerceIn(40, 100),
      openAnimationIndex = prefs.getInt(KEY_OPEN_ANIMATION, 0),
      auraAnimationIndex = prefs.getInt(KEY_AURA_ANIMATION, 0),
      visualizerStyleIndex = prefs.getInt(KEY_VISUALIZER_STYLE, 0),
      hideInLandscape = prefs.getBoolean(KEY_HIDE_IN_LANDSCAPE, true),
      enableNetworkAlerts = prefs.getBoolean(KEY_NETWORK_ALERTS, true),
      enableVolumeAlerts = prefs.getBoolean(KEY_VOLUME_ALERTS, true),
      enableAlarmSync = prefs.getBoolean(KEY_ALARM_SYNC, true),
      enableStepsCounter = prefs.getBoolean(KEY_STEPS_COUNTER, true),
      pinStepsInCapsule = prefs.getBoolean(KEY_PIN_STEPS, false),
      enableWeatherAlerts = prefs.getBoolean(KEY_WEATHER_ALERTS, true),
      pinWeatherInCapsule = prefs.getBoolean(KEY_PIN_WEATHER, false),
      weatherCityQuery = prefs.getString(KEY_WEATHER_CITY, "") ?: "",
      weatherCityDisplayAlias = prefs.getString(KEY_WEATHER_CITY_ALIAS, "") ?: "",
      weatherCityLat = readOptionalDouble(KEY_WEATHER_CITY_LAT),
      weatherCityLon = readOptionalDouble(KEY_WEATHER_CITY_LON),
      enableCompass = prefs.getBoolean(KEY_COMPASS, true),
      enableFocusTimer = prefs.getBoolean(KEY_FOCUS_TIMER, true),
      enableDeliveryAlerts = prefs.getBoolean(KEY_DELIVERY_ALERTS, true),
      enableFootballScores = prefs.getBoolean(KEY_FOOTBALL_SCORES, true),
      footballLeagueCode = prefs.getString(KEY_FOOTBALL_LEAGUE, "uefa.champions") ?: "uefa.champions",
      pinFootballInCapsule = prefs.getBoolean(KEY_PIN_FOOTBALL, false),
      enablePreMatchReminder = prefs.getBoolean(KEY_PRE_MATCH_REMINDER, true),
      footballReminderMinutes = prefs.getInt(KEY_FOOTBALL_REMINDER_MINUTES, 15).coerceIn(5, 60),
      favoriteFootballTeam = prefs.getString(KEY_FAVORITE_FOOTBALL_TEAM, "") ?: "",
      enablePrayerAlerts = prefs.getBoolean(KEY_PRAYER_ALERTS, true),
      pinPrayerInCapsule = prefs.getBoolean(KEY_PIN_PRAYER, false),
      prayerReminderMinutes = prefs.getInt(KEY_PRAYER_REMINDER_MINUTES, 15).coerceIn(5, 45),
      appThemeIndex = prefs.getInt(KEY_APP_THEME, 0),
      useCustomColors = prefs.getBoolean(KEY_USE_CUSTOM_COLORS, false),
      customBackgroundColor = readOptionalColor(CustomColorSlot.BACKGROUND),
      customSurfaceColor = readOptionalColor(CustomColorSlot.SURFACE),
      customElevatedColor = readOptionalColor(CustomColorSlot.ELEVATED),
      customPrimaryColor = readOptionalColor(CustomColorSlot.PRIMARY),
      customSecondaryColor = readOptionalColor(CustomColorSlot.SECONDARY),
      customTextPrimaryColor = readOptionalColor(CustomColorSlot.TEXT_PRIMARY),
      customTextSecondaryColor = readOptionalColor(CustomColorSlot.TEXT_SECONDARY),
      customCapsuleBgColor = readOptionalColor(CustomColorSlot.CAPSULE_BG),
      excludedPackages = prefs.getStringSet(KEY_EXCLUDED_PACKAGES, emptySet())?.toSet() ?: emptySet(),
      githubUpdateRepo = prefs.getString(KEY_GITHUB_UPDATE_REPO, "") ?: "",
      autoCheckUpdatesOnLaunch = prefs.getBoolean(KEY_AUTO_CHECK_UPDATES, true)
    )
  }

  private fun readOptionalColor(slot: CustomColorSlot): Int? {
    return if (prefs.contains(slot.key)) prefs.getInt(slot.key, 0) else null
  }

  private fun readOptionalDouble(key: String): Double? {
    return if (prefs.contains(key)) Double.fromBits(prefs.getLong(key, 0L)) else null
  }

  fun updateServiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    _settings.value = _settings.value.copy(serviceEnabled = enabled)
  }

  fun updateNotchOffsetY(offset: Int) {
    prefs.edit().putInt(KEY_NOTCH_OFFSET_Y, offset).apply()
    _settings.value = _settings.value.copy(notchOffsetYDp = offset)
  }

  fun updateCapsuleWidth(width: Int) {
    prefs.edit().putInt(KEY_CAPSULE_WIDTH, width).apply()
    _settings.value = _settings.value.copy(capsuleWidthDp = width)
  }

  fun updateCapsuleHeight(height: Int) {
    prefs.edit().putInt(KEY_CAPSULE_HEIGHT, height).apply()
    _settings.value = _settings.value.copy(capsuleHeightDp = height)
  }

  fun updateAccentColorIndex(index: Int) {
    prefs.edit().putInt(KEY_ACCENT_COLOR, index).apply()
    _settings.value = _settings.value.copy(accentColorIndex = index)
  }

  fun updateAutoCollapseSeconds(seconds: Int) {
    prefs.edit().putInt(KEY_AUTO_COLLAPSE, seconds).apply()
    _settings.value = _settings.value.copy(autoCollapseSeconds = seconds)
  }

  fun updateShowWhenIdle(show: Boolean) {
    prefs.edit().putBoolean(KEY_SHOW_WHEN_IDLE, show).apply()
    _settings.value = _settings.value.copy(showWhenIdle = show)
  }

  fun toggleFeature(featureKey: String, enabled: Boolean) {
    prefs.edit().putBoolean(featureKey, enabled).apply()
    _settings.value = when (featureKey) {
      KEY_BATTERY_ALERTS -> _settings.value.copy(enableBatteryAlerts = enabled)
      KEY_CALL_ALERTS -> _settings.value.copy(enableCallAlerts = enabled)
      KEY_TIMER -> _settings.value.copy(enableTimer = enabled)
      KEY_NOTIFICATIONS -> _settings.value.copy(enableNotifications = enabled)
      KEY_BLUETOOTH_ALERTS -> _settings.value.copy(enableBluetoothAlerts = enabled)
      KEY_FLASHLIGHT_ALERT -> _settings.value.copy(enableFlashlightAlert = enabled)
      KEY_RINGER_ALERTS -> _settings.value.copy(enableRingerAlerts = enabled)
      KEY_DOWNLOAD_PROGRESS -> _settings.value.copy(enableDownloadProgress = enabled)
      KEY_NAVIGATION_ALERTS -> _settings.value.copy(enableNavigationAlerts = enabled)
      KEY_PRIVACY_ALERTS -> _settings.value.copy(enablePrivacyAlerts = enabled)
      KEY_DUAL_CAPSULE -> _settings.value.copy(enableDualCapsule = enabled)
      KEY_DYNAMIC_ALBUM_COLORS -> _settings.value.copy(enableDynamicAlbumColors = enabled)
      KEY_HIDE_IN_LANDSCAPE -> _settings.value.copy(hideInLandscape = enabled)
      KEY_NETWORK_ALERTS -> _settings.value.copy(enableNetworkAlerts = enabled)
      KEY_VOLUME_ALERTS -> _settings.value.copy(enableVolumeAlerts = enabled)
      KEY_ALARM_SYNC -> _settings.value.copy(enableAlarmSync = enabled)
      KEY_STEPS_COUNTER -> _settings.value.copy(enableStepsCounter = enabled)
      KEY_PIN_STEPS -> _settings.value.copy(pinStepsInCapsule = enabled)
      KEY_WEATHER_ALERTS -> _settings.value.copy(enableWeatherAlerts = enabled)
      KEY_PIN_WEATHER -> _settings.value.copy(pinWeatherInCapsule = enabled)
      KEY_COMPASS -> _settings.value.copy(enableCompass = enabled)
      KEY_FOCUS_TIMER -> _settings.value.copy(enableFocusTimer = enabled)
      KEY_DELIVERY_ALERTS -> _settings.value.copy(enableDeliveryAlerts = enabled)
      KEY_FOOTBALL_SCORES -> _settings.value.copy(enableFootballScores = enabled)
      KEY_PIN_FOOTBALL -> _settings.value.copy(pinFootballInCapsule = enabled)
      KEY_PRE_MATCH_REMINDER -> _settings.value.copy(enablePreMatchReminder = enabled)
      KEY_PRAYER_ALERTS -> _settings.value.copy(enablePrayerAlerts = enabled)
      KEY_PIN_PRAYER -> _settings.value.copy(pinPrayerInCapsule = enabled)
      KEY_AUTO_CHECK_UPDATES -> _settings.value.copy(autoCheckUpdatesOnLaunch = enabled)
      KEY_HAPTIC -> _settings.value.copy(hapticFeedback = enabled)
      else -> _settings.value
    }
  }

  fun updateFootballLeagueCode(code: String) {
    val clean = code.trim().ifBlank { "uefa.champions" }
    prefs.edit().putString(KEY_FOOTBALL_LEAGUE, clean).apply()
    _settings.value = _settings.value.copy(footballLeagueCode = clean)
  }

  fun updateFootballReminderMinutes(minutes: Int) {
    val safe = minutes.coerceIn(5, 60)
    prefs.edit().putInt(KEY_FOOTBALL_REMINDER_MINUTES, safe).apply()
    _settings.value = _settings.value.copy(footballReminderMinutes = safe)
  }

  fun updateFavoriteFootballTeam(team: String) {
    val clean = team.trim()
    prefs.edit().putString(KEY_FAVORITE_FOOTBALL_TEAM, clean).apply()
    _settings.value = _settings.value.copy(favoriteFootballTeam = clean)
  }

  fun updatePrayerReminderMinutes(minutes: Int) {
    val safe = minutes.coerceIn(5, 45)
    prefs.edit().putInt(KEY_PRAYER_REMINDER_MINUTES, safe).apply()
    _settings.value = _settings.value.copy(prayerReminderMinutes = safe)
  }

  fun updateWeatherCityQuery(city: String) {
    val clean = city.trim()
    val editor = prefs.edit().putString(KEY_WEATHER_CITY, clean)
    editor.remove(KEY_WEATHER_CITY_LAT).remove(KEY_WEATHER_CITY_LON)
    if (clean.isEmpty()) {
      editor.remove(KEY_WEATHER_CITY_ALIAS)
    }
    editor.apply()
    _settings.value = _settings.value.copy(
      weatherCityQuery = clean,
      weatherCityLat = null,
      weatherCityLon = null,
      weatherCityDisplayAlias = if (clean.isEmpty()) "" else _settings.value.weatherCityDisplayAlias
    )
  }

  fun updateWeatherCitySelection(
    query: String,
    lat: Double?,
    lon: Double?,
    displayAlias: String = ""
  ) {
    val cleanQuery = query.trim()
    val cleanAlias = displayAlias.trim()
    val editor = prefs.edit()
      .putString(KEY_WEATHER_CITY, cleanQuery)
      .putString(KEY_WEATHER_CITY_ALIAS, cleanAlias)
    if (lat != null && lon != null) {
      editor.putLong(KEY_WEATHER_CITY_LAT, lat.toBits())
      editor.putLong(KEY_WEATHER_CITY_LON, lon.toBits())
    } else {
      editor.remove(KEY_WEATHER_CITY_LAT).remove(KEY_WEATHER_CITY_LON)
    }
    editor.apply()
    _settings.value = _settings.value.copy(
      weatherCityQuery = cleanQuery,
      weatherCityDisplayAlias = cleanAlias,
      weatherCityLat = lat,
      weatherCityLon = lon
    )
  }

  fun renameWeatherCityDisplay(alias: String) {
    val clean = alias.trim()
    prefs.edit().putString(KEY_WEATHER_CITY_ALIAS, clean).apply()
    _settings.value = _settings.value.copy(weatherCityDisplayAlias = clean)
  }

  fun clearWeatherCity() {
    prefs.edit()
      .remove(KEY_WEATHER_CITY)
      .remove(KEY_WEATHER_CITY_ALIAS)
      .remove(KEY_WEATHER_CITY_LAT)
      .remove(KEY_WEATHER_CITY_LON)
      .apply()
    _settings.value = _settings.value.copy(
      weatherCityQuery = "",
      weatherCityDisplayAlias = "",
      weatherCityLat = null,
      weatherCityLon = null
    )
  }

  fun updateCapsuleStyleIndex(index: Int) {
    val safe = index.coerceIn(0, 5)
    prefs.edit().putInt(KEY_CAPSULE_STYLE, safe).apply()
    _settings.value = _settings.value.copy(capsuleStyleIndex = safe)
  }

  fun updateCapsuleTransparent(transparent: Boolean) {
    prefs.edit().putBoolean(KEY_CAPSULE_TRANSPARENT, transparent).apply()
    _settings.value = _settings.value.copy(capsuleTransparent = transparent)
  }

  fun updateCapsuleOpacityPercent(percent: Int) {
    val safe = percent.coerceIn(40, 100)
    prefs.edit().putInt(KEY_CAPSULE_OPACITY, safe).apply()
    _settings.value = _settings.value.copy(capsuleOpacityPercent = safe)
  }

  fun updateOpenAnimationIndex(index: Int) {
    val safe = index.coerceIn(0, 4)
    prefs.edit().putInt(KEY_OPEN_ANIMATION, safe).apply()
    _settings.value = _settings.value.copy(openAnimationIndex = safe)
  }

  fun updateAuraAnimationIndex(index: Int) {
    val safe = index.coerceIn(0, 4)
    prefs.edit().putInt(KEY_AURA_ANIMATION, safe).apply()
    _settings.value = _settings.value.copy(auraAnimationIndex = safe)
  }

  fun updateVisualizerStyleIndex(index: Int) {
    val safe = index.coerceIn(0, 3)
    prefs.edit().putInt(KEY_VISUALIZER_STYLE, safe).apply()
    _settings.value = _settings.value.copy(visualizerStyleIndex = safe)
  }

  fun updateAppThemeIndex(index: Int) {
    val safe = index.coerceIn(0, 8)
    prefs.edit().putInt(KEY_APP_THEME, safe).apply()
    _settings.value = _settings.value.copy(appThemeIndex = safe)
  }

  fun updateUseCustomColors(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_USE_CUSTOM_COLORS, enabled).apply()
    _settings.value = _settings.value.copy(useCustomColors = enabled)
  }

  fun updateCustomColor(slot: CustomColorSlot, colorArgb: Int?, enableCustom: Boolean = true) {
    val editor = prefs.edit()
    if (colorArgb != null) {
      editor.putInt(slot.key, colorArgb)
      if (enableCustom) editor.putBoolean(KEY_USE_CUSTOM_COLORS, true)
    } else {
      editor.remove(slot.key)
    }
    editor.apply()

    val cur = _settings.value
    val nextEnable = if (colorArgb != null && enableCustom) true else cur.useCustomColors
    _settings.value = when (slot) {
      CustomColorSlot.BACKGROUND -> cur.copy(useCustomColors = nextEnable, customBackgroundColor = colorArgb)
      CustomColorSlot.SURFACE -> cur.copy(useCustomColors = nextEnable, customSurfaceColor = colorArgb)
      CustomColorSlot.ELEVATED -> cur.copy(useCustomColors = nextEnable, customElevatedColor = colorArgb)
      CustomColorSlot.PRIMARY -> cur.copy(useCustomColors = nextEnable, customPrimaryColor = colorArgb)
      CustomColorSlot.SECONDARY -> cur.copy(useCustomColors = nextEnable, customSecondaryColor = colorArgb)
      CustomColorSlot.TEXT_PRIMARY -> cur.copy(useCustomColors = nextEnable, customTextPrimaryColor = colorArgb)
      CustomColorSlot.TEXT_SECONDARY -> cur.copy(useCustomColors = nextEnable, customTextSecondaryColor = colorArgb)
      CustomColorSlot.CAPSULE_BG -> cur.copy(useCustomColors = nextEnable, customCapsuleBgColor = colorArgb)
    }
  }

  fun resetAllCustomColors() {
    val editor = prefs.edit().putBoolean(KEY_USE_CUSTOM_COLORS, false)
    CustomColorSlot.entries.forEach { editor.remove(it.key) }
    editor.apply()
    _settings.value = _settings.value.copy(
      useCustomColors = false,
      customBackgroundColor = null,
      customSurfaceColor = null,
      customElevatedColor = null,
      customPrimaryColor = null,
      customSecondaryColor = null,
      customTextPrimaryColor = null,
      customTextSecondaryColor = null,
      customCapsuleBgColor = null
    )
  }

  fun setPackageExcluded(packageName: String, excluded: Boolean) {
    val updated = _settings.value.excludedPackages.toMutableSet()
    if (excluded) updated.add(packageName) else updated.remove(packageName)
    val immutable = updated.toSet()
    prefs.edit().putStringSet(KEY_EXCLUDED_PACKAGES, immutable).apply()
    _settings.value = _settings.value.copy(excludedPackages = immutable)
  }

  fun clearExcludedPackages() {
    prefs.edit().putStringSet(KEY_EXCLUDED_PACKAGES, emptySet()).apply()
    _settings.value = _settings.value.copy(excludedPackages = emptySet())
  }

  fun updateGithubUpdateRepo(repo: String) {
    val normalized = com.example.update.GitHubUpdateManager.normalizeRepo(repo)
    prefs.edit().putString(KEY_GITHUB_UPDATE_REPO, normalized).apply()
    _settings.value = _settings.value.copy(githubUpdateRepo = normalized)
  }

  companion object {
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_NOTCH_OFFSET_Y = "notch_offset_y"
    private const val KEY_CAPSULE_WIDTH = "capsule_width"
    private const val KEY_CAPSULE_HEIGHT = "capsule_height"
    private const val KEY_ACCENT_COLOR = "accent_color"
    private const val KEY_AUTO_COLLAPSE = "auto_collapse"
    private const val KEY_SHOW_WHEN_IDLE = "show_when_idle"
    const val KEY_HAPTIC = "haptic"

    const val KEY_BATTERY_ALERTS = "enable_battery_alerts"
    const val KEY_CALL_ALERTS = "enable_call_alerts"
    const val KEY_TIMER = "enable_timer"
    const val KEY_NOTIFICATIONS = "enable_notifications"
    const val KEY_BLUETOOTH_ALERTS = "enable_bluetooth_alerts"
    const val KEY_FLASHLIGHT_ALERT = "enable_flashlight_alert"
    const val KEY_RINGER_ALERTS = "enable_ringer_alerts"
    const val KEY_DOWNLOAD_PROGRESS = "enable_download_progress"
    const val KEY_NAVIGATION_ALERTS = "enable_navigation_alerts"
    const val KEY_PRIVACY_ALERTS = "enable_privacy_alerts"
    const val KEY_DUAL_CAPSULE = "enable_dual_capsule"
    const val KEY_DYNAMIC_ALBUM_COLORS = "enable_dynamic_album_colors"
    const val KEY_HIDE_IN_LANDSCAPE = "hide_in_landscape"
    const val KEY_NETWORK_ALERTS = "enable_network_alerts"
    const val KEY_VOLUME_ALERTS = "enable_volume_alerts"
    const val KEY_ALARM_SYNC = "enable_alarm_sync"
    const val KEY_STEPS_COUNTER = "enable_steps_counter"
    const val KEY_PIN_STEPS = "pin_steps_in_capsule"
    const val KEY_WEATHER_ALERTS = "enable_weather_alerts"
    const val KEY_PIN_WEATHER = "pin_weather_in_capsule"
    const val KEY_COMPASS = "enable_compass"
    const val KEY_FOCUS_TIMER = "enable_focus_timer"
    const val KEY_DELIVERY_ALERTS = "enable_delivery_alerts"
    const val KEY_FOOTBALL_SCORES = "enable_football_scores"
    const val KEY_PIN_FOOTBALL = "pin_football_in_capsule"
    const val KEY_PRE_MATCH_REMINDER = "enable_pre_match_reminder"
    private const val KEY_FOOTBALL_REMINDER_MINUTES = "football_reminder_minutes"
    private const val KEY_FAVORITE_FOOTBALL_TEAM = "favorite_football_team"
    const val KEY_PRAYER_ALERTS = "enable_prayer_alerts"
    const val KEY_PIN_PRAYER = "pin_prayer_in_capsule"
    private const val KEY_PRAYER_REMINDER_MINUTES = "prayer_reminder_minutes"
    private const val KEY_FOOTBALL_LEAGUE = "football_league_code"
    private const val KEY_WEATHER_CITY = "weather_city_query"
    private const val KEY_WEATHER_CITY_ALIAS = "weather_city_display_alias"
    private const val KEY_WEATHER_CITY_LAT = "weather_city_lat"
    private const val KEY_WEATHER_CITY_LON = "weather_city_lon"
    private const val KEY_CAPSULE_STYLE = "capsule_style_index"
    private const val KEY_CAPSULE_TRANSPARENT = "capsule_transparent"
    private const val KEY_CAPSULE_OPACITY = "capsule_opacity_percent"
    private const val KEY_OPEN_ANIMATION = "open_animation_index"
    private const val KEY_AURA_ANIMATION = "aura_animation_index"
    private const val KEY_VISUALIZER_STYLE = "visualizer_style_index"
    private const val KEY_APP_THEME = "app_theme_index"
    private const val KEY_USE_CUSTOM_COLORS = "use_custom_colors"
    private const val KEY_EXCLUDED_PACKAGES = "excluded_notif_packages"
    private const val KEY_GITHUB_UPDATE_REPO = "github_update_repo"
    const val KEY_AUTO_CHECK_UPDATES = "auto_check_updates_on_launch"

    @Volatile
    private var INSTANCE: CapsuleSettingsManager? = null

    fun getInstance(context: Context): CapsuleSettingsManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: CapsuleSettingsManager(context).also { INSTANCE = it }
      }
    }
  }
}
