package com.example.update

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.util.Log
import com.example.BuildConfig
import com.example.island.IslandStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AppUpdateState(
  val currentVersionName: String = BuildConfig.VERSION_NAME,
  val currentVersionCode: Int = BuildConfig.VERSION_CODE,
  val configuredRepo: String = "",
  val isChecking: Boolean = false,
  val hasChecked: Boolean = false,
  val isUpdateAvailable: Boolean = false,
  val latestVersionTag: String = "",
  val releaseTitle: String = "",
  val releaseNotes: String = "",
  val apkAssetName: String = "",
  val apkDownloadUrl: String = "",
  val apkSizeBytes: Long = -1L,
  val releaseHtmlUrl: String = "",
  val publishedAt: String = "",
  val errorMessage: String? = null,
  val statusMessageAr: String = "",
  val lastCheckedMs: Long = 0L,
  val isDismissedForSession: Boolean = false,
  // Real-time download progress tracking
  val isDownloading: Boolean = false,
  val isDownloadComplete: Boolean = false,
  val downloadId: Long = -1L,
  val downloadProgressPercent: Int = 0,
  val downloadedBytes: Long = 0L,
  val downloadTotalBytes: Long = -1L
)

object GitHubUpdateManager {

  private const val TAG = "GitHubUpdateManager"
  private const val CAPSULE_UPDATE_DOWNLOAD_KEY = "app_update_github"

  // مستودع GitHub المدمج للتحديثات التلقائية
  const val EMBEDDED_GITHUB_REPO = "tito9pytwo-lang/Dynamic_249"

  private val repoPattern = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var checkJob: Job? = null
  private var downloadMonitorJob: Job? = null

  private val client = OkHttpClient.Builder()
    .connectTimeout(12, TimeUnit.SECONDS)
    .readTimeout(15, TimeUnit.SECONDS)
    .build()

  private val _state = MutableStateFlow(
    AppUpdateState(configuredRepo = normalizeRepo(EMBEDDED_GITHUB_REPO))
  )
  val state: StateFlow<AppUpdateState> = _state.asStateFlow()

  fun isRepoConfigured(): Boolean = normalizeRepo(EMBEDDED_GITHUB_REPO).isNotBlank()

  fun normalizeRepo(raw: String): String {
    var s = raw.trim()
    if (s.isEmpty()) return ""

    if (s.startsWith("git@github.com:", ignoreCase = true)) {
      s = s.substringAfter("git@github.com:")
    }
    s = s.removePrefix("https://").removePrefix("http://").removePrefix("www.")
    if (s.startsWith("github.com/", ignoreCase = true)) {
      s = s.substringAfter("github.com/", "")
    }
    s = s.substringBefore('?').substringBefore('#').trim('/')
    if (s.endsWith(".git", ignoreCase = true)) {
      s = s.dropLast(4)
    }

    val segments = s.split('/').filter { it.isNotBlank() }
    if (segments.size < 2) return ""
    val candidate = "${segments[0]}/${segments[1]}"
    return if (repoPattern.matches(candidate)) candidate else ""
  }

  private fun extractVersionParts(raw: String): List<Int> {
    val clean = raw.trim().replaceFirst(Regex("^[^0-9]+"), "")
    val match = Regex("^(\\d+(?:\\.\\d+)*)").find(clean) ?: return emptyList()
    return match.groupValues[1].split('.').mapNotNull { it.toIntOrNull() }
  }

  fun compareVersionStrings(first: String, second: String): Int {
    val firstParts = extractVersionParts(first)
    val secondParts = extractVersionParts(second)
    if (firstParts.isEmpty() && secondParts.isEmpty()) return 0
    if (firstParts.isEmpty()) return -1
    if (secondParts.isEmpty()) return 1

    val maxLen = maxOf(firstParts.size, secondParts.size)
    for (i in 0 until maxLen) {
      val a = firstParts.getOrElse(i) { 0 }
      val b = secondParts.getOrElse(i) { 0 }
      if (a != b) return a.compareTo(b)
    }
    return 0
  }

  fun isNewerVersion(remoteTag: String, localVersionName: String): Boolean {
    val remoteParts = extractVersionParts(remoteTag)
    val localParts = extractVersionParts(localVersionName)
    if (remoteParts.isEmpty() || localParts.isEmpty()) return false
    return compareVersionStrings(remoteTag, localVersionName) > 0
  }

  fun formatFileSizeAr(bytes: Long): String {
    if (bytes <= 0L) return ""
    val kb = bytes / 1024.0
    if (kb < 1024.0) {
      return String.format(Locale.US, "%.0f KB", kb)
    }
    val mb = kb / 1024.0
    return String.format(Locale.US, "%.1f MB", mb)
  }

  fun computeProgressPercent(downloadedBytes: Long, totalBytes: Long): Int {
    if (totalBytes <= 0L || downloadedBytes < 0L) return -1
    return ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
  }

  fun isSafeHttpsUrl(url: String): Boolean {
    val trimmed = url.trim()
    if (!trimmed.startsWith("https://", ignoreCase = true)) return false
    val uri = runCatching { Uri.parse(trimmed) }.getOrNull() ?: return false
    val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return false
    val host = uri.host?.lowercase(Locale.ROOT) ?: return false
    return scheme == "https" && host.isNotBlank() && !host.contains("..")
  }

  fun parseReleaseJson(
    jsonStr: String,
    configuredRepo: String,
    currentVersionName: String = BuildConfig.VERSION_NAME
  ): AppUpdateState {
    val trimmed = jsonStr.trim()
    val releaseObj: JSONObject? = when {
      trimmed.startsWith("[") -> {
        val arr = JSONArray(trimmed)
        val published = buildList {
          for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (!obj.optBoolean("draft", false)) add(obj)
          }
        }
        published.maxWithOrNull { a, b ->
          val verA = a.optString("tag_name", "").ifBlank { a.optString("name", "") }
          val verB = b.optString("tag_name", "").ifBlank { b.optString("name", "") }
          compareVersionStrings(verA, verB)
        }
      }
      trimmed.startsWith("{") -> {
        val obj = JSONObject(trimmed)
        if (obj.optBoolean("draft", false)) null else obj
      }
      else -> null
    }

    if (releaseObj == null) {
      return AppUpdateState(
        currentVersionName = currentVersionName,
        currentVersionCode = BuildConfig.VERSION_CODE,
        configuredRepo = configuredRepo,
        hasChecked = true,
        isUpdateAvailable = false,
        statusMessageAr = "لا توجد إصدارات منشورة بعد",
        lastCheckedMs = System.currentTimeMillis()
      )
    }

    val tagName = releaseObj.optString("tag_name", "").trim()
    val releaseName = releaseObj.optString("name", "").trim().ifBlank { tagName }
    val body = releaseObj.optString("body", "").trim()
    val rawHtmlUrl = releaseObj.optString("html_url", "").trim()
    val htmlUrl = if (isSafeHttpsUrl(rawHtmlUrl)) rawHtmlUrl else ""
    val publishedAt = releaseObj.optString("published_at", "").trim().take(10)

    var bestApkName = ""
    var bestApkUrl = ""
    var bestApkSize = -1L

    var bestZipName = ""
    var bestZipUrl = ""
    var bestZipSize = -1L

    val assets = releaseObj.optJSONArray("assets")
    if (assets != null) {
      for (i in 0 until assets.length()) {
        val asset = assets.optJSONObject(i) ?: continue
        val assetName = asset.optString("name", "").trim()
        val downloadUrl = asset.optString("browser_download_url", "").trim()
        val size = asset.optLong("size", -1L)
        if (!isSafeHttpsUrl(downloadUrl)) continue

        if (assetName.endsWith(".apk", ignoreCase = true)) {
          val isPreferred = assetName.contains("release", ignoreCase = true) ||
            assetName.contains("signed", ignoreCase = true)
          if (bestApkUrl.isBlank() || isPreferred) {
            bestApkName = assetName
            bestApkUrl = downloadUrl
            bestApkSize = size
          }
        } else if (assetName.endsWith(".zip", ignoreCase = true)) {
          val isPreferredZip = assetName.contains("apk", ignoreCase = true) ||
            assetName.contains("signed", ignoreCase = true) ||
            assetName.contains("build", ignoreCase = true)
          if (bestZipUrl.isBlank() || isPreferredZip) {
            bestZipName = assetName
            bestZipUrl = downloadUrl
            bestZipSize = size
          }
        }
      }
    }

    val chosenAssetName = bestApkName.ifBlank { bestZipName }
    val chosenDownloadUrl = bestApkUrl.ifBlank { bestZipUrl }
    val chosenAssetSize = if (bestApkUrl.isNotBlank()) bestApkSize else bestZipSize

    val versionCandidate = tagName.ifBlank { releaseName }
    val hasDownloadTarget = chosenDownloadUrl.isNotBlank() || htmlUrl.isNotBlank()
    val updateAvailable = versionCandidate.isNotBlank() &&
      isNewerVersion(versionCandidate, currentVersionName) &&
      hasDownloadTarget

    val statusMsg = when {
      updateAvailable -> "يتوفر تحديث جديد: $versionCandidate"
      versionCandidate.isNotBlank() -> "أنت تستخدم أحدث إصدار ($versionCandidate)"
      else -> "تم الفحص بنجاح"
    }

    val prev = _state.value
    return AppUpdateState(
      currentVersionName = currentVersionName,
      currentVersionCode = BuildConfig.VERSION_CODE,
      configuredRepo = configuredRepo,
      isChecking = false,
      hasChecked = true,
      isUpdateAvailable = updateAvailable,
      latestVersionTag = versionCandidate,
      releaseTitle = releaseName,
      releaseNotes = body,
      apkAssetName = chosenAssetName,
      apkDownloadUrl = chosenDownloadUrl,
      apkSizeBytes = chosenAssetSize,
      releaseHtmlUrl = htmlUrl,
      publishedAt = publishedAt,
      errorMessage = null,
      statusMessageAr = statusMsg,
      lastCheckedMs = System.currentTimeMillis(),
      isDismissedForSession = false,
      isDownloading = prev.isDownloading,
      isDownloadComplete = prev.isDownloadComplete && prev.latestVersionTag == versionCandidate,
      downloadId = prev.downloadId,
      downloadProgressPercent = prev.downloadProgressPercent,
      downloadedBytes = prev.downloadedBytes,
      downloadTotalBytes = prev.downloadTotalBytes
    )
  }

  private fun executeGitHubGet(url: String): Pair<Int, String> {
    val req = Request.Builder()
      .url(url)
      .header("Accept", "application/vnd.github+json")
      .header("X-GitHub-Api-Version", "2022-11-28")
      .header("User-Agent", "DynamicCapsule-Android/${BuildConfig.VERSION_NAME}")
      .cacheControl(CacheControl.FORCE_NETWORK)
      .build()
    client.newCall(req).execute().use { resp ->
      val body = resp.body?.string().orEmpty()
      return resp.code to body
    }
  }

  fun checkForUpdates(
    context: Context,
    repoOverride: String? = null,
    forceRefresh: Boolean = false
  ) {
    val normalizedRepo = normalizeRepo(repoOverride ?: EMBEDDED_GITHUB_REPO)

    if (normalizedRepo.isEmpty()) {
      _state.value = _state.value.copy(
        isChecking = false,
        hasChecked = true,
        isUpdateAvailable = false,
        configuredRepo = "",
        errorMessage = "خدمة التحديث قيد الربط — أضف رابط المستودع في كود التطبيق أولاً",
        statusMessageAr = "بانتظار ربط مستودع التحديثات",
        lastCheckedMs = System.currentTimeMillis()
      )
      return
    }

    val cur = _state.value
    if (!forceRefresh && cur.isChecking) return
    if (!forceRefresh && cur.hasChecked && cur.configuredRepo == normalizedRepo &&
      System.currentTimeMillis() - cur.lastCheckedMs < 60_000L
    ) {
      return
    }

    checkJob?.cancel()
    _state.value = cur.copy(
      configuredRepo = normalizedRepo,
      isChecking = true,
      errorMessage = null,
      statusMessageAr = "جارٍ التحقق من توفر تحديثات..."
    )

    checkJob = scope.launch {
      val result = withContext(Dispatchers.IO) {
        runCatching {
          val latestUrl = "https://api.github.com/repos/$normalizedRepo/releases/latest"
          var (code, body) = executeGitHubGet(latestUrl)
          if (code == 404) {
            val listUrl = "https://api.github.com/repos/$normalizedRepo/releases?per_page=10"
            val fallback = executeGitHubGet(listUrl)
            code = fallback.first
            body = fallback.second
          }

          when (code) {
            in 200..299 -> parseReleaseJson(
              jsonStr = body,
              configuredRepo = normalizedRepo,
              currentVersionName = BuildConfig.VERSION_NAME
            )
            404 -> throw IllegalStateException("تعذر العثور على مصدر التحديثات أو لا توجد إصدارات منشورة بعد")
            403, 429 -> throw IllegalStateException("تم تجاوز حد الطلبات مؤقتاً، حاول بعد قليل")
            else -> throw IllegalStateException("استجابة غير متوقعة من الخادم ($code)")
          }
        }
      }

      result.onSuccess { parsed ->
        _state.value = parsed
      }.onFailure { err ->
        Log.w(TAG, "GitHub update check failed", err)
        val friendlyError = when (err) {
          is IllegalStateException -> err.message
          else -> "تعذر الاتصال للتحقق من التحديثات، تأكد من اتصال الإنترنت"
        }
        _state.value = _state.value.copy(
          isChecking = false,
          hasChecked = true,
          configuredRepo = normalizedRepo,
          errorMessage = friendlyError,
          statusMessageAr = friendlyError ?: "تعذر التحقق من التحديثات",
          lastCheckedMs = System.currentTimeMillis()
        )
      }
    }
  }

  fun dismissUpdateDialog() {
    _state.value = _state.value.copy(isDismissedForSession = true)
  }

  fun reopenUpdateDialog() {
    _state.value = _state.value.copy(isDismissedForSession = false)
  }

  fun startUpdateDownload(context: Context): Boolean {
    val st = _state.value
    if (st.isDownloading) return true

    val assetUrl = st.apkDownloadUrl.trim()
    if (!isSafeHttpsUrl(assetUrl)) {
      val html = st.releaseHtmlUrl.trim()
      return if (isSafeHttpsUrl(html)) launchExternalUrl(context, html) else false
    }

    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
    if (dm == null) {
      return launchExternalUrl(context, assetUrl)
    }

    val fileName = st.apkAssetName.ifBlank { "DynamicCapsule-${st.latestVersionTag}.apk" }
      .replace(Regex("[^A-Za-z0-9._-]"), "_")
    val mimeType = if (fileName.endsWith(".zip", ignoreCase = true)) {
      "application/zip"
    } else {
      "application/vnd.android.package-archive"
    }

    val enqueuedId = runCatching {
      val request = DownloadManager.Request(Uri.parse(assetUrl)).apply {
        setTitle("تحديث Dynamic Capsule (${st.latestVersionTag})")
        setDescription("جارٍ تنزيل $fileName")
        setMimeType(mimeType)
        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        setAllowedOverMetered(true)
        setAllowedOverRoaming(true)
        try {
          setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        } catch (_: Exception) {
          setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        }
      }
      dm.enqueue(request)
    }.getOrNull()

    if (enqueuedId == null || enqueuedId < 0L) {
      return launchExternalUrl(context, assetUrl)
    }

    val expectedTotal = st.apkSizeBytes
    _state.value = st.copy(
      isDownloading = true,
      isDownloadComplete = false,
      downloadId = enqueuedId,
      downloadProgressPercent = 0,
      downloadedBytes = 0L,
      downloadTotalBytes = expectedTotal,
      errorMessage = null,
      statusMessageAr = "بدأ تنزيل التحديث..."
    )

    IslandStateManager.updateDownloadProgress(
      key = CAPSULE_UPDATE_DOWNLOAD_KEY,
      appName = "Dynamic Capsule",
      title = "تنزيل تحديث ${st.latestVersionTag}",
      progress = 0,
      max = 100,
      indeterminate = true
    )

    monitorSystemDownload(context.applicationContext ?: context, dm, enqueuedId, expectedTotal, st.latestVersionTag)
    return true
  }

  private fun monitorSystemDownload(
    appContext: Context,
    dm: DownloadManager,
    downloadId: Long,
    fallbackTotalBytes: Long,
    versionTag: String
  ) {
    downloadMonitorJob?.cancel()
    downloadMonitorJob = scope.launch {
      while (isActive) {
        val snapshot = withContext(Dispatchers.IO) {
          queryDownloadSnapshot(dm, downloadId)
        }

        if (snapshot == null) {
          _state.value = _state.value.copy(
            isDownloading = false,
            downloadId = -1L,
            statusMessageAr = "تم إيقاف التنزيل"
          )
          IslandStateManager.clearDownloadProgress(CAPSULE_UPDATE_DOWNLOAD_KEY)
          break
        }

        val effectiveTotal = if (snapshot.totalBytes > 0L) snapshot.totalBytes else fallbackTotalBytes
        val pct = computeProgressPercent(snapshot.downloadedBytes, effectiveTotal)

        when (snapshot.status) {
          DownloadManager.STATUS_SUCCESSFUL -> {
            _state.value = _state.value.copy(
              isDownloading = false,
              isDownloadComplete = true,
              downloadProgressPercent = 100,
              downloadedBytes = if (effectiveTotal > 0L) effectiveTotal else snapshot.downloadedBytes,
              downloadTotalBytes = effectiveTotal,
              errorMessage = null,
              statusMessageAr = "اكتمل التنزيل ✓ افتح مجلد التنزيلات"
            )
            IslandStateManager.clearDownloadProgress(CAPSULE_UPDATE_DOWNLOAD_KEY)
            break
          }
          DownloadManager.STATUS_FAILED -> {
            _state.value = _state.value.copy(
              isDownloading = false,
              isDownloadComplete = false,
              downloadId = -1L,
              errorMessage = "فشل تنزيل التحديث (${snapshot.reason})، حاول مجدداً أو افتح عبر المتصفح",
              statusMessageAr = "تعذر إكمال التنزيل"
            )
            IslandStateManager.clearDownloadProgress(CAPSULE_UPDATE_DOWNLOAD_KEY)
            break
          }
          else -> {
            val isPaused = snapshot.status == DownloadManager.STATUS_PAUSED
            val sizeProgressText = buildString {
              append(if (isPaused) "متوقف مؤقتاً: " else "جارٍ التنزيل: ")
              val dlStr = formatFileSizeAr(snapshot.downloadedBytes).ifBlank { "0 KB" }
              append(dlStr)
              val totStr = formatFileSizeAr(effectiveTotal)
              if (totStr.isNotBlank()) {
                append(" / ").append(totStr)
              }
              if (pct >= 0) {
                append(" (").append(pct).append("%)")
              }
            }
            _state.value = _state.value.copy(
              isDownloading = true,
              isDownloadComplete = false,
              downloadProgressPercent = pct.coerceAtLeast(0),
              downloadedBytes = snapshot.downloadedBytes,
              downloadTotalBytes = effectiveTotal,
              statusMessageAr = sizeProgressText
            )
            IslandStateManager.updateDownloadProgress(
              key = CAPSULE_UPDATE_DOWNLOAD_KEY,
              appName = "Dynamic Capsule",
              title = "تحديث $versionTag",
              progress = pct.coerceAtLeast(0),
              max = 100,
              indeterminate = pct < 0
            )
          }
        }
        delay(250L)
      }
    }
  }

  private data class DownloadSnapshot(
    val status: Int,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val reason: Int
  )

  private fun queryDownloadSnapshot(dm: DownloadManager, downloadId: Long): DownloadSnapshot? {
    var cursor: Cursor? = null
    return try {
      cursor = dm.query(DownloadManager.Query().setFilterById(downloadId))
      if (cursor != null && cursor.moveToFirst()) {
        val statusIdx = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
        val dlIdx = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
        val totalIdx = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
        val reasonIdx = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
        DownloadSnapshot(
          status = if (statusIdx >= 0) cursor.getInt(statusIdx) else DownloadManager.STATUS_RUNNING,
          downloadedBytes = if (dlIdx >= 0) cursor.getLong(dlIdx) else 0L,
          totalBytes = if (totalIdx >= 0) cursor.getLong(totalIdx) else -1L,
          reason = if (reasonIdx >= 0) cursor.getInt(reasonIdx) else 0
        )
      } else {
        null
      }
    } catch (_: Exception) {
      null
    } finally {
      cursor?.close()
    }
  }

  fun cancelDownload(context: Context) {
    downloadMonitorJob?.cancel()
    downloadMonitorJob = null
    val cur = _state.value
    if (cur.downloadId >= 0L) {
      runCatching {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        dm?.remove(cur.downloadId)
      }
    }
    IslandStateManager.clearDownloadProgress(CAPSULE_UPDATE_DOWNLOAD_KEY)
    _state.value = cur.copy(
      isDownloading = false,
      isDownloadComplete = false,
      downloadId = -1L,
      downloadProgressPercent = 0,
      downloadedBytes = 0L,
      statusMessageAr = "تم إلغاء التنزيل"
    )
  }

  fun openDownloadsFolder(context: Context): Boolean {
    return try {
      val downloadsIntent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(downloadsIntent)
      true
    } catch (_: Exception) {
      openUpdateDownload(context)
    }
  }

  fun openUpdateDownload(context: Context): Boolean {
    val st = _state.value
    val targetUrl = st.apkDownloadUrl.ifBlank { st.releaseHtmlUrl }
    if (targetUrl.isBlank()) return false
    return launchExternalUrl(context, targetUrl)
  }

  fun openReleasePage(context: Context): Boolean {
    val st = _state.value
    val url = st.releaseHtmlUrl.ifBlank {
      if (st.configuredRepo.isNotBlank()) "https://github.com/${st.configuredRepo}/releases/latest" else ""
    }
    if (url.isBlank()) return false
    return launchExternalUrl(context, url)
  }

  private fun launchExternalUrl(context: Context, url: String): Boolean {
    val trimmed = url.trim()
    if (!isSafeHttpsUrl(trimmed)) {
      Log.w(TAG, "Blocked non-HTTPS external update URL")
      return false
    }
    return try {
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(trimmed)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      true
    } catch (e: Exception) {
      Log.e(TAG, "Failed opening update URL", e)
      false
    }
  }
}
