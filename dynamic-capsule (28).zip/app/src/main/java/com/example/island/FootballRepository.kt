package com.example.island

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

enum class FootballLeague(val code: String, val labelAr: String) {
  UEFA_CL("uefa.champions", "دوري الأبطال"),
  EPL("eng.1", "الإنجليزي"),
  LALIGA("esp.1", "الإسباني"),
  SAUDI("ksa.1", "دوري روشن"),
  SERIE_A("ita.1", "الإيطالي"),
  BUNDESLIGA("ger.1", "الألماني"),
  ALL("all", "كل البطولات");

  companion object {
    fun fromCode(code: String): FootballLeague =
      entries.firstOrNull { it.code == code } ?: UEFA_CL
  }
}

data class FootballTeamSuggestion(
  val arabicName: String,
  val englishName: String,
  val leagueLabelAr: String,
  val aliases: List<String> = emptyList()
)

object FootballRepository {

  private const val TAG = "FootballRepository"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .cache(null)
      .connectTimeout(8, TimeUnit.SECONDS)
      .readTimeout(8, TimeUnit.SECONDS)
      .build()
  }

  suspend fun fetchLiveMatches(leagueCode: String): Result<FootballState> = withContext(Dispatchers.IO) {
    val league = FootballLeague.fromCode(leagueCode)
    try {
      val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/${league.code}/scoreboard"
      val request = Request.Builder()
        .url(url)
        .cacheControl(CacheControl.FORCE_NETWORK)
        .header("Cache-Control", "no-cache, no-store, must-revalidate")
        .header("Pragma", "no-cache")
        .get()
        .build()
      val body = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(
            IllegalStateException("تعذر الاتصال بخدمة المباريات (${resp.code})")
          )
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة المباريات"))

      val state = parseEspnScoreboardJson(body, league.code, league.labelAr)
      Result.success(state)
    } catch (e: Exception) {
      Log.w(TAG, "Failed fetching live football scores for ${league.code}", e)
      Result.failure(IllegalStateException(toFriendlyError(e)))
    }
  }

  internal fun parseEspnScoreboardJson(
    jsonStr: String,
    leagueCode: String,
    leagueNameAr: String
  ): FootballState {
    val root = JSONObject(jsonStr)
    val events = root.optJSONArray("events")
    val parsed = mutableListOf<FootballMatchItem>()

    if (events != null) {
      for (i in 0 until events.length()) {
        val ev = events.optJSONObject(i) ?: continue
        val id = ev.optString("id", "ev_$i")
        val competitions = ev.optJSONArray("competitions")
        val comp = competitions?.optJSONObject(0) ?: continue
        val competitors = comp.optJSONArray("competitors") ?: continue
        if (competitors.length() < 2) continue

        var homeObj = competitors.optJSONObject(0)
        var awayObj = competitors.optJSONObject(1)
        for (c in 0 until competitors.length()) {
          val obj = competitors.optJSONObject(c) ?: continue
          when (obj.optString("homeAway", "").lowercase(Locale.US)) {
            "home" -> homeObj = obj
            "away" -> awayObj = obj
          }
        }
        if (homeObj == null || awayObj == null) continue

        val homeName = extractTeamName(homeObj)
        val awayName = extractTeamName(awayObj)
        val homeLogo = extractTeamLogoUrl(homeObj)
        val awayLogo = extractTeamLogoUrl(awayObj)
        val homeAbbrev = extractTeamAbbrev(homeObj, homeName)
        val awayAbbrev = extractTeamAbbrev(awayObj, awayName)
        val homeScore = homeObj.optString("score", "0").toIntOrNull() ?: 0
        val awayScore = awayObj.optString("score", "0").toIntOrNull() ?: 0

        val statusObj = comp.optJSONObject("status") ?: ev.optJSONObject("status")
        val statusType = statusObj?.optJSONObject("type")
        val stateCode = statusType?.optString("state", "pre")?.lowercase(Locale.US) ?: "pre"
        val typeName = statusType?.optString("name", "")?.uppercase(Locale.US).orEmpty()
        val displayClock = statusObj?.optString("displayClock", "")?.trim().orEmpty()
        val shortDetail = statusType?.optString("shortDetail", "")?.trim().orEmpty()
        val description = statusType?.optString("description", "")?.trim().orEmpty()

        val matchPhase = resolveMatchPhase(stateCode, typeName, shortDetail, description)
        val isLive = matchPhase == FootballMatchPhase.LIVE_PLAY ||
          matchPhase == FootballMatchPhase.HALFTIME ||
          matchPhase == FootballMatchPhase.STOPPED
        val isFinished = matchPhase == FootballMatchPhase.FINISHED

        val parsedServerClock = if (matchPhase == FootballMatchPhase.LIVE_PLAY) {
          extractClockSeconds(statusObj, displayClock)
        } else {
          -1
        }
        val isStoppage = displayClock.contains("+") || shortDetail.contains("+")

        val isoDate = ev.optString("date", "")
        val kickoffMs = parseIsoUtcMillis(isoDate)
        val statusLabel = when (matchPhase) {
          FootballMatchPhase.HALFTIME -> "استراحة"
          FootballMatchPhase.STOPPED -> resolveStoppedLabelAr(typeName, shortDetail, description)
          FootballMatchPhase.FINISHED -> when {
            shortDetail.contains("PEN", ignoreCase = true) || typeName.contains("PEN") -> "انتهت (ركلات)"
            shortDetail.contains("AET", ignoreCase = true) || typeName.contains("AET") -> "انتهت (إضافي)"
            else -> "انتهت"
          }
          FootballMatchPhase.LIVE_PLAY -> when {
            displayClock.isNotBlank() -> displayClock
            shortDetail.isNotBlank() -> shortDetail
            else -> "مباشر"
          }
          FootballMatchPhase.SCHEDULED -> formatScheduledTime(isoDate) ?: shortDetail.ifBlank { "قريباً" }
        }

        parsed.add(
          FootballMatchItem(
            id = id,
            leagueNameAr = leagueNameAr,
            homeTeam = homeName,
            awayTeam = awayName,
            homeLogoUrl = homeLogo,
            awayLogoUrl = awayLogo,
            homeAbbrev = homeAbbrev,
            awayAbbrev = awayAbbrev,
            homeScore = homeScore,
            awayScore = awayScore,
            minuteOrStatus = statusLabel,
            isLive = isLive,
            isFinished = isFinished,
            matchPhase = matchPhase,
            clockSeconds = parsedServerClock,
            serverClockSeconds = parsedServerClock,
            isStoppageTime = isStoppage,
            kickoffTimeMs = kickoffMs
          )
        )
      }
    }

    val ordered = sortMatchesForDisplay(parsed).take(12)

    return FootballState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = ordered.any { it.isLive },
      leagueCode = leagueCode,
      leagueNameAr = leagueNameAr,
      matches = ordered,
      selectedIndex = 0,
      errorMessage = if (ordered.isEmpty()) "لا توجد مباريات متاحة اليوم في $leagueNameAr" else null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  private val curatedTeams: List<FootballTeamSuggestion> = listOf(
    // Saudi Pro League & Arab Giants
    FootballTeamSuggestion("الهلال", "Al Hilal", "دوري روشن", listOf("الهلال السعودي", "الزعيم", "HIL", "Al-Hilal")),
    FootballTeamSuggestion("النصر", "Al Nassr", "دوري روشن", listOf("النصر السعودي", "العالمي", "NAS", "Al-Nassr")),
    FootballTeamSuggestion("الاتحاد", "Al Ittihad", "دوري روشن", listOf("الاتحاد السعودي", "العميد", "ITT", "Al-Ittihad")),
    FootballTeamSuggestion("الأهلي السعودي", "Al Ahli", "دوري روشن", listOf("الاهلي", "الأهلي", "الراقي", "AHL", "Al-Ahli")),
    FootballTeamSuggestion("الشباب", "Al Shabab", "دوري روشن", listOf("الشباب السعودي", "Al-Shabab")),
    FootballTeamSuggestion("الاتفاق", "Al Ettifaq", "دوري روشن", listOf("Al-Ettifaq")),
    FootballTeamSuggestion("القادسية", "Al Qadsiah", "دوري روشن", listOf("Al-Qadsiah")),
    FootballTeamSuggestion("التعاون", "Al Taawoun", "دوري روشن", listOf("Al-Taawoun")),
    FootballTeamSuggestion("الأهلي المصري", "Al Ahly", "أفريقيا / مصر", listOf("الأهلي", "الاهلي المصري", "الشياطين الحمر")),
    FootballTeamSuggestion("الزمالك", "Zamalek", "أفريقيا / مصر", listOf("القلعة البيضاء")),
    FootballTeamSuggestion("الوداد الرياضي", "Wydad AC", "أفريقيا / المغرب", listOf("الوداد", "Wydad")),
    FootballTeamSuggestion("الرجاء الرياضي", "Raja CA", "أفريقيا / المغرب", listOf("الرجاء", "Raja Casablanca")),
    FootballTeamSuggestion("الترجي التونسي", "Esperance Tunis", "أفريقيا / تونس", listOf("الترجي", "Esperance")),
    FootballTeamSuggestion("السد", "Al Sadd", "قطر / آسيا", listOf("السد القطري", "Al-Sadd")),
    FootballTeamSuggestion("العين", "Al Ain", "الإمارات / آسيا", listOf("العين الإماراتي", "Al-Ain")),

    // La Liga
    FootballTeamSuggestion("ريال مدريد", "Real Madrid", "الإسباني / الأبطال", listOf("الريال", "الملكي", "RMA", "Madrid")),
    FootballTeamSuggestion("برشلونة", "Barcelona", "الإسباني / الأبطال", listOf("البرسا", "البارسا", "BAR", "FC Barcelona", "Barca")),
    FootballTeamSuggestion("أتلتيكو مدريد", "Atletico Madrid", "الإسباني", listOf("اتلتيكو", "ATM", "Atlético")),
    FootballTeamSuggestion("إشبيلية", "Sevilla", "الإسباني", listOf("اشبيلية", "SEV")),
    FootballTeamSuggestion("أتلتيك بيلباو", "Athletic Club", "الإسباني", listOf("بيلباو", "Athletic Bilbao", "ATH")),
    FootballTeamSuggestion("ريال سوسيداد", "Real Sociedad", "الإسباني", listOf("سوسيداد", "RSO")),
    FootballTeamSuggestion("فالنسيا", "Valencia", "الإسباني", listOf("VAL")),
    FootballTeamSuggestion("فياريال", "Villarreal", "الإسباني", listOf("VIL")),
    FootballTeamSuggestion("ريال بيتيس", "Real Betis", "الإسباني", listOf("بيتيس", "BET")),
    FootballTeamSuggestion("جيرونا", "Girona", "الإسباني", listOf("GIR")),

    // Premier League
    FootballTeamSuggestion("ليفربول", "Liverpool", "الإنجليزي / الأبطال", listOf("الريدز", "LIV")),
    FootballTeamSuggestion("مانشستر سيتي", "Manchester City", "الإنجليزي / الأبطال", listOf("السيتي", "Man City", "MCI")),
    FootballTeamSuggestion("أرسنال", "Arsenal", "الإنجليزي / الأبطال", listOf("ارسنال", "أرسنل", "المدفعجية", "ARS")),
    FootballTeamSuggestion("مانشستر يونايتد", "Manchester United", "الإنجليزي", listOf("اليونايتد", "مان يونايتد", "Man United", "MUN", "Man Utd")),
    FootballTeamSuggestion("تشيلسي", "Chelsea", "الإنجليزي", listOf("البلوز", "CHE")),
    FootballTeamSuggestion("توتنهام", "Tottenham", "الإنجليزي", listOf("توتنهام هوتسبير", "Spurs", "TOT")),
    FootballTeamSuggestion("نيوكاسل يونايتد", "Newcastle", "الإنجليزي", listOf("نيوكاسل", "NEW")),
    FootballTeamSuggestion("أستون فيلا", "Aston Villa", "الإنجليزي", listOf("استون فيلا", "AVL")),
    FootballTeamSuggestion("برايتون", "Brighton", "الإنجليزي", listOf("BHA")),
    FootballTeamSuggestion("وست هام", "West Ham", "الإنجليزي", listOf("WHU")),

    // Serie A
    FootballTeamSuggestion("إنتر ميلان", "Inter", "الإيطالي / الأبطال", listOf("انتر ميلان", "الإنتر", "Inter Milan", "INT")),
    FootballTeamSuggestion("إي سي ميلان", "AC Milan", "الإيطالي / الأبطال", listOf("ميلان", "الميلان", "MIL", "Milan")),
    FootballTeamSuggestion("يوفنتوس", "Juventus", "الإيطالي", listOf("اليوفي", "JUV")),
    FootballTeamSuggestion("نابولي", "Napoli", "الإيطالي", listOf("NAP")),
    FootballTeamSuggestion("روما", "AS Roma", "الإيطالي", listOf("Roma", "ROM")),
    FootballTeamSuggestion("أتالانتا", "Atalanta", "الإيطالي", listOf("اتالانتا", "ATA")),
    FootballTeamSuggestion("لاتسيو", "Lazio", "الإيطالي", listOf("LAZ")),

    // Bundesliga & Ligue 1 & Europe
    FootballTeamSuggestion("بايرن ميونخ", "Bayern Munich", "الألماني / الأبطال", listOf("البايرن", "بايرن", "BAY", "FC Bayern")),
    FootballTeamSuggestion("بوروسيا دورتموند", "Borussia Dortmund", "الألماني / الأبطال", listOf("دورتموند", "Dortmund", "BVB")),
    FootballTeamSuggestion("باير ليفركوزن", "Bayer Leverkusen", "الألماني", listOf("ليفركوزن", "Leverkusen", "B04")),
    FootballTeamSuggestion("آر بي لايبزيغ", "RB Leipzig", "الألماني", listOf("لايبزيغ", "Leipzig", "RBL")),
    FootballTeamSuggestion("باريس سان جيرمان", "Paris Saint-Germain", "الأبطال / الفرنسي", listOf("باريس", "بي اس جي", "PSG")),
    FootballTeamSuggestion("مارسيليا", "Marseille", "الفرنسي", listOf("OM")),
    FootballTeamSuggestion("بنفيكا", "Benfica", "البرتغالي / الأبطال", listOf("BEN")),
    FootballTeamSuggestion("بورتو", "Porto", "البرتغالي / الأبطال", listOf("POR")),
    FootballTeamSuggestion("سبورتينغ لشبونة", "Sporting CP", "البرتغالي / الأبطال", listOf("سبورتينغ", "SCP")),
    FootballTeamSuggestion("أياكس", "Ajax", "الهولندي", listOf("اياكس", "AJX")),

    // National Teams
    FootballTeamSuggestion("السعودية", "Saudi Arabia", "منتخبات", listOf("المنتخب السعودي", "الأخضر", "KSA")),
    FootballTeamSuggestion("مصر", "Egypt", "منتخبات", listOf("منتخب مصر", "الفراعنة", "EGY")),
    FootballTeamSuggestion("المغرب", "Morocco", "منتخبات", listOf("منتخب المغرب", "أسود الأطلس", "MAR")),
    FootballTeamSuggestion("الجزائر", "Algeria", "منتخبات", listOf("منتخب الجزائر", "ALG")),
    FootballTeamSuggestion("تونس", "Tunisia", "منتخبات", listOf("منتخب تونس", "TUN")),
    FootballTeamSuggestion("العراق", "Iraq", "منتخبات", listOf("منتخب العراق", "IRQ")),
    FootballTeamSuggestion("الأردن", "Jordan", "منتخبات", listOf("منتخب الأردن", "النشامى", "JOR")),
    FootballTeamSuggestion("البرازيل", "Brazil", "منتخبات", listOf("منتخب البرازيل", "BRA")),
    FootballTeamSuggestion("الأرجنتين", "Argentina", "منتخبات", listOf("منتخب الأرجنتين", "ARG")),
    FootballTeamSuggestion("فرنسا", "France", "منتخبات", listOf("منتخب فرنسا", "FRA")),
    FootballTeamSuggestion("إسبانيا", "Spain", "منتخبات", listOf("منتخب إسبانيا", "ESP")),
    FootballTeamSuggestion("إنجلترا", "England", "منتخبات", listOf("منتخب إنجلترا", "ENG")),
    FootballTeamSuggestion("ألمانيا", "Germany", "منتخبات", listOf("منتخب ألمانيا", "GER")),
    FootballTeamSuggestion("البرتغال", "Portugal", "منتخبات", listOf("منتخب البرتغال", "POR"))
  )

  private fun normalizeTeamQuery(raw: String): String {
    return raw.trim()
      .lowercase(Locale.ROOT)
      .replace('أ', 'ا')
      .replace('إ', 'ا')
      .replace('آ', 'ا')
      .replace('ة', 'ه')
      .replace('ى', 'ي')
      .replace("-", " ")
  }

  fun suggestTeams(
    query: String,
    liveMatches: List<FootballMatchItem> = emptyList(),
    limit: Int = 8
  ): List<FootballTeamSuggestion> {
    val normQ = normalizeTeamQuery(query)
    if (normQ.isBlank()) return emptyList()

    // Merge live match teams first so active teams always show up too
    val liveSuggestions = buildList {
      for (m in liveMatches) {
        if (m.homeTeam.isNotBlank()) {
          val known = curatedTeams.firstOrNull {
            it.englishName.equals(m.homeTeam, ignoreCase = true) ||
              it.aliases.any { a -> a.equals(m.homeTeam, ignoreCase = true) || a.equals(m.homeAbbrev, ignoreCase = true) }
          }
          add(
            known ?: FootballTeamSuggestion(
              arabicName = m.homeTeam,
              englishName = m.homeTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباشر" },
              aliases = listOfNotNull(m.homeAbbrev.takeIf { it.isNotBlank() })
            )
          )
        }
        if (m.awayTeam.isNotBlank()) {
          val known = curatedTeams.firstOrNull {
            it.englishName.equals(m.awayTeam, ignoreCase = true) ||
              it.aliases.any { a -> a.equals(m.awayTeam, ignoreCase = true) || a.equals(m.awayAbbrev, ignoreCase = true) }
          }
          add(
            known ?: FootballTeamSuggestion(
              arabicName = m.awayTeam,
              englishName = m.awayTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباشر" },
              aliases = listOfNotNull(m.awayAbbrev.takeIf { it.isNotBlank() })
            )
          )
        }
      }
    }

    val combinedPool = (liveSuggestions + curatedTeams)
      .distinctBy { "${it.arabicName}|${it.englishName.lowercase(Locale.ROOT)}" }

    return combinedPool.mapNotNull { item ->
      val candidates = listOf(item.arabicName, item.englishName) + item.aliases
      val norms = candidates.map { normalizeTeamQuery(it) }
      val bestRank = when {
        norms.any { it.startsWith(normQ) } -> 0
        norms.any {
          it.split(' ').any { word ->
            word.startsWith(normQ) || (word.startsWith("ال") && word.removePrefix("ال").startsWith(normQ))
          }
        } -> 1
        norms.any { it.contains(normQ) } -> 2
        else -> return@mapNotNull null
      }
      bestRank to item
    }
      .sortedBy { it.first }
      .map { it.second }
      .take(limit)
  }

  internal fun matchesFavoriteTeam(match: FootballMatchItem, favoriteTeam: String): Boolean {
    val q = favoriteTeam.trim()
    if (q.isBlank()) return false
    val normQ = normalizeTeamQuery(q)

    val directMatch = match.homeTeam.contains(q, ignoreCase = true) ||
      match.awayTeam.contains(q, ignoreCase = true) ||
      match.homeAbbrev.equals(q, ignoreCase = true) ||
      match.awayAbbrev.equals(q, ignoreCase = true)
    if (directMatch) return true

    // Resolve Arabic / alias favorite names (e.g. "ريال مدريد" -> "Real Madrid")
    val matchingCatalogEntries = curatedTeams.filter { item ->
      val allTokens = (listOf(item.arabicName, item.englishName) + item.aliases).map { normalizeTeamQuery(it) }
      allTokens.any { it == normQ || (normQ.length >= 3 && it.contains(normQ)) }
    }
    return matchingCatalogEntries.any { entry ->
      val eng = normalizeTeamQuery(entry.englishName)
      val homeNorm = normalizeTeamQuery(match.homeTeam)
      val awayNorm = normalizeTeamQuery(match.awayTeam)
      homeNorm.contains(eng) || awayNorm.contains(eng) ||
        entry.aliases.any { alias ->
          val aNorm = normalizeTeamQuery(alias)
          aNorm.length >= 3 && (homeNorm.contains(aNorm) || awayNorm.contains(aNorm))
        }
    }
  }

  internal fun sortMatchesForDisplay(
    matches: List<FootballMatchItem>,
    favoriteTeam: String = ""
  ): List<FootballMatchItem> {
    return matches.sortedWith(
      compareBy<FootballMatchItem>(
        {
          when (it.matchPhase) {
            FootballMatchPhase.LIVE_PLAY -> 0
            FootballMatchPhase.HALFTIME -> 1
            FootballMatchPhase.STOPPED -> 2
            FootballMatchPhase.FINISHED -> 3
            FootballMatchPhase.SCHEDULED -> 4
          }
        },
        { if (matchesFavoriteTeam(it, favoriteTeam)) 0 else 1 },
        { if (it.kickoffTimeMs > 0L) it.kickoffTimeMs else Long.MAX_VALUE }
      )
    )
  }

  internal fun markPreMatchFlags(
    matches: List<FootballMatchItem>,
    reminderMinutes: Int,
    nowMs: Long = System.currentTimeMillis()
  ): List<FootballMatchItem> {
    val windowMs = reminderMinutes.coerceIn(5, 60) * 60_000L
    return matches.map { item ->
      val soon = item.matchPhase == FootballMatchPhase.SCHEDULED &&
        item.kickoffTimeMs > nowMs &&
        (item.kickoffTimeMs - nowMs) <= windowMs
      item.copy(isPreMatchSoon = soon)
    }
  }

  internal fun detectUpcomingMatchReminder(
    matches: List<FootballMatchItem>,
    reminderMinutes: Int,
    favoriteTeam: String = "",
    nowMs: Long = System.currentTimeMillis(),
    alreadyRemindedIds: Set<String> = emptySet()
  ): FootballMatchEvent? {
    val windowMs = reminderMinutes.coerceIn(5, 60) * 60_000L
    val candidates = matches.filter { item ->
      item.matchPhase == FootballMatchPhase.SCHEDULED &&
        item.kickoffTimeMs > nowMs &&
        (item.kickoffTimeMs - nowMs) <= windowMs &&
        !alreadyRemindedIds.contains(item.id)
    }.sortedWith(
      compareBy<FootballMatchItem>(
        { if (matchesFavoriteTeam(it, favoriteTeam)) 0 else 1 },
        { it.kickoffTimeMs }
      )
    )
    val match = candidates.firstOrNull() ?: return null
    val minsLeft = (((match.kickoffTimeMs - nowMs) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    return FootballMatchEvent(
      matchId = match.id,
      type = FootballEventType.KICKOFF_SOON,
      titleAr = "تبدأ قريباً!",
      subtitleAr = "خلال $minsLeft د • ${match.homeTeam} × ${match.awayTeam}",
      homeTeam = match.homeTeam,
      awayTeam = match.awayTeam,
      homeScore = match.homeScore,
      awayScore = match.awayScore,
      timestampMs = nowMs
    )
  }

  internal fun mergeLiveClocks(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>
  ): List<FootballMatchItem> {
    if (previous.isEmpty()) return fresh
    val prevById = previous.associateBy { it.id }
    return fresh.map { next ->
      val old = prevById[next.id] ?: return@map next
      if (next.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        old.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        next.serverClockSeconds >= 0 &&
        next.serverClockSeconds == old.serverClockSeconds &&
        old.clockSeconds >= next.serverClockSeconds
      ) {
        // Keep local second ticker tightly bounded (+12s max) so clock never drifts ahead of live match.
        val smoothSeconds = old.clockSeconds.coerceAtMost(next.serverClockSeconds + 12)
        next.copy(clockSeconds = smoothSeconds)
      } else {
        next
      }
    }
  }

  internal fun detectMatchEvent(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>,
    preferredMatchId: String? = null
  ): FootballMatchEvent? {
    if (previous.isEmpty() || fresh.isEmpty()) return null
    val prevById = previous.associateBy { it.id }
    val candidates = mutableListOf<Pair<Int, FootballMatchEvent>>()

    for (newItem in fresh) {
      val oldItem = prevById[newItem.id] ?: continue
      val homeScored = newItem.homeScore > oldItem.homeScore
      val awayScored = newItem.awayScore > oldItem.awayScore
      val homeDisallowed = newItem.homeScore < oldItem.homeScore
      val awayDisallowed = newItem.awayScore < oldItem.awayScore
      val isPreferredBoost = if (newItem.id == preferredMatchId) 0 else 10

      if (homeScored || awayScored) {
        val side = when {
          homeScored && awayScored -> FootballScoringSide.BOTH
          homeScored -> FootballScoringSide.HOME
          else -> FootballScoringSide.AWAY
        }
        val scorerTeam = when (side) {
          FootballScoringSide.HOME -> newItem.homeTeam
          FootballScoringSide.AWAY -> newItem.awayTeam
          FootballScoringSide.BOTH -> "${newItem.homeTeam} و${newItem.awayTeam}"
        }
        candidates.add(
          (0 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.GOAL,
            titleAr = "هدف!",
            subtitleAr = "$scorerTeam • ${newItem.homeScore} - ${newItem.awayScore}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore,
            scoringSide = side
          )
        )
      } else if (homeDisallowed || awayDisallowed) {
        val side = when {
          homeDisallowed && awayDisallowed -> FootballScoringSide.BOTH
          homeDisallowed -> FootballScoringSide.HOME
          else -> FootballScoringSide.AWAY
        }
        val disallowedTeam = when (side) {
          FootballScoringSide.HOME -> newItem.homeTeam
          FootballScoringSide.AWAY -> newItem.awayTeam
          FootballScoringSide.BOTH -> "${newItem.homeTeam} و${newItem.awayTeam}"
        }
        candidates.add(
          (0 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.GOAL_DISALLOWED,
            titleAr = "تم إلغاء الهدف (VAR)",
            subtitleAr = "$disallowedTeam • ${newItem.homeScore} - ${newItem.awayScore}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore,
            scoringSide = side
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.STOPPED &&
        oldItem.matchPhase != FootballMatchPhase.STOPPED
      ) {
        candidates.add(
          (1 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.STOPPED,
            titleAr = "توقفت المباراة",
            subtitleAr = "${newItem.homeTeam} × ${newItem.awayTeam} (${newItem.minuteOrStatus})",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.FINISHED &&
        oldItem.matchPhase != FootballMatchPhase.FINISHED
      ) {
        candidates.add(
          (2 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.FULL_TIME,
            titleAr = "انتهت المباراة",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.HALFTIME &&
        oldItem.matchPhase != FootballMatchPhase.HALFTIME
      ) {
        candidates.add(
          (3 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.HALFTIME,
            titleAr = "استراحة الشوطين",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      }
    }

    return candidates.minByOrNull { it.first }?.second
  }

  private fun resolveMatchPhase(
    stateCode: String,
    typeName: String,
    shortDetail: String,
    description: String
  ): FootballMatchPhase {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    val isStoppedKeyword = combined.contains("suspend") ||
      combined.contains("delay") ||
      combined.contains("interrupt") ||
      combined.contains("postpon") ||
      combined.contains("abandon") ||
      combined.contains("cancel") ||
      combined.contains("rain")

    if (isStoppedKeyword) return FootballMatchPhase.STOPPED

    if (stateCode == "post" ||
      typeName.contains("FINAL") ||
      typeName.contains("FULL_TIME") ||
      shortDetail.equals("FT", ignoreCase = true) ||
      shortDetail.equals("AET", ignoreCase = true) ||
      shortDetail.equals("PEN", ignoreCase = true)
    ) {
      return FootballMatchPhase.FINISHED
    }

    if (stateCode == "in") {
      if (typeName.contains("HALFTIME") ||
        typeName.contains("END_OF_PERIOD") ||
        shortDetail.equals("HT", ignoreCase = true) ||
        combined.contains("halftime")
      ) {
        return FootballMatchPhase.HALFTIME
      }
      return FootballMatchPhase.LIVE_PLAY
    }

    return FootballMatchPhase.SCHEDULED
  }

  private fun resolveStoppedLabelAr(
    typeName: String,
    shortDetail: String,
    description: String
  ): String {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    return when {
      combined.contains("postpon") -> "مؤجلة"
      combined.contains("cancel") || combined.contains("abandon") -> "ملغاة"
      combined.contains("delay") || combined.contains("rain") -> "تأخر مؤقت"
      else -> "توقفت لحدث"
    }
  }

  private fun extractClockSeconds(statusObj: JSONObject?, displayClock: String): Int {
    if (displayClock.contains("+")) return -1
    val cleaned = displayClock.replace("'", "").trim()
    // If displayClock already has MM:SS seconds, parse it directly.
    if (cleaned.contains(":")) {
      val parts = cleaned.split(":")
      val mins = parts.getOrNull(0)?.toIntOrNull() ?: return -1
      val secs = parts.getOrNull(1)?.toIntOrNull() ?: 0
      return (mins * 60) + secs.coerceIn(0, 59)
    }
    // Only use rawClock if ESPN provides genuine sub-minute seconds (not rounded ordinal minute * 60,
    // which otherwise puts whole-minute feeds 1–2 minutes ahead of actual elapsed match time).
    val rawClock = statusObj?.optDouble("clock", -1.0) ?: -1.0
    if (rawClock > 0.0 && !rawClock.isNaN()) {
      val intClock = rawClock.toInt()
      if (intClock % 60 != 0) {
        return intClock
      }
    }
    return -1
  }

  private fun extractTeamName(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return "فريق"
    return team.optString("shortDisplayName").takeIf { it.isNotBlank() }
      ?: team.optString("displayName").takeIf { it.isNotBlank() }
      ?: team.optString("abbreviation").takeIf { it.isNotBlank() }
      ?: "فريق"
  }

  private fun extractTeamLogoUrl(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return ""
    val direct = team.optString("logo").trim()
    val fromArray = team.optJSONArray("logos")
      ?.optJSONObject(0)
      ?.optString("href")
      ?.trim()
      .orEmpty()
    val raw = direct.ifBlank { fromArray }
    return if (raw.startsWith("http://", ignoreCase = true)) {
      "https://" + raw.removePrefix("http://")
    } else {
      raw
    }
  }

  private fun extractTeamAbbrev(competitor: JSONObject, fallbackName: String): String {
    val team = competitor.optJSONObject("team")
    val abbrev = team?.optString("abbreviation")?.trim().orEmpty()
    if (abbrev.isNotBlank()) return abbrev.take(3).uppercase(Locale.US)
    val clean = fallbackName.trim()
    return if (clean.isNotBlank()) clean.take(2).uppercase(Locale.US) else "FC"
  }

  internal fun parseIsoUtcMillis(isoUtc: String): Long {
    if (isoUtc.isBlank()) return -1L
    val patterns = listOf(
      "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      "yyyy-MM-dd'T'HH:mm:ss'Z'",
      "yyyy-MM-dd'T'HH:mm'Z'"
    )
    for (p in patterns) {
      try {
        val parser = SimpleDateFormat(p, Locale.US).apply {
          timeZone = TimeZone.getTimeZone("UTC")
        }
        val date = parser.parse(isoUtc)
        if (date != null) return date.time
      } catch (_: Exception) {
      }
    }
    return -1L
  }

  private fun formatScheduledTime(isoUtc: String): String? {
    val ms = parseIsoUtcMillis(isoUtc)
    if (ms <= 0L) return null
    val out = SimpleDateFormat("HH:mm", Locale.US)
    return out.format(java.util.Date(ms))
  }

  private fun toFriendlyError(err: Throwable): String {
    val msg = err.message.orEmpty()
    return when {
      err is UnknownHostException ||
        err is ConnectException ||
        msg.contains("Unable to resolve host", ignoreCase = true) ||
        msg.contains("No address associated", ignoreCase = true) ->
        "لا يوجد اتصال بالإنترنت لعرض نتائج المباريات"
      err is SocketTimeoutException || msg.contains("timeout", ignoreCase = true) ->
        "انتهت مهلة الاتصال بخدمة المباريات، حاول مجدداً"
      err is IllegalStateException && msg.isNotBlank() -> msg
      else -> "تعذر جلب نتائج المباريات حالياً"
    }
  }
}
