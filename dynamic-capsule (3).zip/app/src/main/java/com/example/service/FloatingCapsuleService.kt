package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class FloatingCapsuleService : Service() {

  private var windowManager: WindowManager? = null
  private var floatingView: ComposeView? = null
  private var lifecycleOwner: FloatingLifecycleOwner? = null
  private var windowParams: WindowManager.LayoutParams? = null

  private var isViewAttached = false
  private var currentMode = CapsuleMode.MINI
  private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    startForegroundServiceWithNotification()

    if (!Settings.canDrawOverlays(this)) {
      Log.w(TAG, "Overlay permission not granted, stopping service")
      stopSelf()
      return
    }

    IslandStateManager.initialize(this)
    lifecycleOwner = FloatingLifecycleOwner().apply { start() }
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    initFloatingCapsule()
    observeState()
  }

  private fun calculateYPosition(settings: CapsuleSettings): Int {
    val density = resources.displayMetrics.density
    var statusBarHeight = 0
    val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
    if (resourceId > 0) {
      statusBarHeight = resources.getDimensionPixelSize(resourceId)
    }
    if (statusBarHeight <= 0) {
      statusBarHeight = (32 * density).toInt()
    }
    // Place directly below the status bar to prevent touch interference and clock/battery overlap!
    val safeTopMargin = (8 * density).toInt()
    val userOffset = (settings.notchOffsetYDp * density).toInt()
    return statusBarHeight + safeTopMargin + userOffset
  }

  private fun startForegroundServiceWithNotification() {
    createNotificationChannel()

    val openAppIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      this, 0, openAppIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val stopIntent = Intent(this, FloatingCapsuleService::class.java).apply {
      action = ACTION_STOP_SERVICE
    }
    val stopPendingIntent = PendingIntent.getService(
      this, 1, stopIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("Dynamic Capsule")
      .setContentText("Active floating island below status bar")
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentIntent(pendingIntent)
      .setOngoing(true)
      .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Dynamic Island Overlay Service",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Background service keeping Dynamic Island running"
        setShowBadge(false)
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(channel)
    }
  }

  private fun initFloatingCapsule() {
    val context = this
    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
      PixelFormat.TRANSLUCENT
    ).apply {
      gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      y = calculateYPosition(settings)
    }

    floatingView = ComposeView(this).apply {
      lifecycleOwner?.let { owner ->
        setViewTreeLifecycleOwner(owner)
        setViewTreeViewModelStoreOwner(owner)
        setViewTreeSavedStateRegistryOwner(owner)
      }

      // Outside touch listener: immediately collapse on outside touch without blocking apps behind it
      setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
          if (currentMode == CapsuleMode.EXPANDED) {
            setMode(CapsuleMode.MINI)
          }
          false
        } else {
          false
        }
      }

      setContent {
        MyApplicationTheme {
          val track by MediaSessionHolder.currentTrack.collectAsState()
          val currentSettings by CapsuleSettingsManager.getInstance(context).settings.collectAsState()

          Box(
            modifier = Modifier.wrapContentSize(),
            contentAlignment = Alignment.TopCenter
          ) {
            DynamicCapsuleView(
              trackInfo = track,
              settings = currentSettings,
              mode = currentMode,
              onModeChange = { newMode -> setMode(newMode) }
            )
          }
        }
      }
    }
  }

  private fun observeState() {
    val settingsManager = CapsuleSettingsManager.getInstance(this)

    serviceScope.launch {
      combine(
        MediaSessionHolder.currentTrack,
        settingsManager.settings,
        IslandStateManager.flashlightState,
        IslandStateManager.callState,
        IslandStateManager.timerState
      ) { track, settings, flash, call, timer ->
        val hasActivity = IslandStateManager.hasAnyActiveActivity(track)
        val shouldShow = settings.serviceEnabled && (hasActivity || settings.showWhenIdle)
        Triple(track, settings, shouldShow)
      }.collect { (track, settings, shouldShow) ->
        val hasActivity = IslandStateManager.hasAnyActiveActivity(track)

        if (shouldShow && !isViewAttached) {
          attachView()
        } else if (!shouldShow && isViewAttached) {
          if (currentMode == CapsuleMode.EXPANDED) {
            currentMode = CapsuleMode.MINI
          }
          detachView()
        }

        // If expanded and active event finished, auto-collapse back to mini
        if (!hasActivity && currentMode == CapsuleMode.EXPANDED) {
          setMode(CapsuleMode.MINI)
        }

        // Update position below status bar if settings changed while attached
        if (isViewAttached) {
          windowParams?.y = calculateYPosition(settings)
          windowParams?.let { params ->
            try {
              windowManager?.updateViewLayout(floatingView, params)
            } catch (e: Exception) {
              Log.e(TAG, "Error updating window layout", e)
            }
          }
        }
      }
    }
  }

  private fun setMode(mode: CapsuleMode) {
    if (currentMode == mode) return
    currentMode = mode

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams?.let { params ->
      params.width = WindowManager.LayoutParams.WRAP_CONTENT
      params.height = WindowManager.LayoutParams.WRAP_CONTENT
      params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      params.y = calculateYPosition(settings)
      params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

      try {
        if (isViewAttached && floatingView != null) {
          windowManager?.updateViewLayout(floatingView, params)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error updating mode in WindowManager", e)
      }
    }
  }

  private fun attachView() {
    val view = floatingView ?: return
    val params = windowParams ?: return
    if (!isViewAttached) {
      try {
        windowManager?.addView(view, params)
        isViewAttached = true
      } catch (e: Exception) {
        Log.e(TAG, "Error adding view to WindowManager", e)
      }
    }
  }

  private fun detachView() {
    val view = floatingView ?: return
    if (isViewAttached) {
      try {
        windowManager?.removeView(view)
        isViewAttached = false
      } catch (e: Exception) {
        Log.e(TAG, "Error removing view from WindowManager", e)
      }
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP_SERVICE) {
      CapsuleSettingsManager.getInstance(this).updateServiceEnabled(false)
      stopSelf()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  override fun onDestroy() {
    super.onDestroy()
    detachView()
    lifecycleOwner?.destroy()
    lifecycleOwner = null
    floatingView = null
  }

  companion object {
    private const val TAG = "FloatingCapsuleService"
    private const val CHANNEL_ID = "dynamic_capsule_channel"
    private const val NOTIFICATION_ID = 2001
    const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
  }
}
