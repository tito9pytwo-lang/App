package com.example.ui.capsule

import android.content.Context
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CapsuleSettings
import com.example.island.BatteryState
import com.example.island.BluetoothState
import com.example.island.CallState
import com.example.island.FlashlightState
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NetSpeedState
import com.example.island.NotificationEvent
import com.example.island.SportsState
import com.example.island.TimerState
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CapsuleMode {
  MINI,
  EXPANDED
}

@Composable
fun DynamicCapsuleView(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  mode: CapsuleMode,
  onModeChange: (CapsuleMode) -> Unit,
  modifier: Modifier = Modifier,
  onPlayPauseClick: () -> Unit = { MediaSessionHolder.togglePlayPause() },
  onNextClick: () -> Unit = { MediaSessionHolder.skipToNext() },
  onPrevClick: () -> Unit = { MediaSessionHolder.skipToPrevious() },
  onSeek: (Long) -> Unit = { MediaSessionHolder.seekTo(it) }
) {
  val accentColor = settings.accentColor
  val activeCard by IslandStateManager.activeCard.collectAsState()
  val batteryState by IslandStateManager.batteryState.collectAsState()
  val callState by IslandStateManager.callState.collectAsState()
  val timerState by IslandStateManager.timerState.collectAsState()
  val netSpeed by IslandStateManager.netSpeedState.collectAsState()
  val notifEvent by IslandStateManager.activeNotification.collectAsState()
  val bluetooth by IslandStateManager.bluetoothState.collectAsState()
  val flashlight by IslandStateManager.flashlightState.collectAsState()
  val sports by IslandStateManager.sportsState.collectAsState()

  Box(
    modifier = modifier,
    contentAlignment = Alignment.TopCenter
  ) {
    if (mode == CapsuleMode.MINI) {
      MediumDynamicIsland(
        trackInfo = trackInfo,
        settings = settings,
        accentColor = accentColor,
        activeCard = activeCard,
        batteryState = batteryState,
        callState = callState,
        timerState = timerState,
        netSpeed = netSpeed,
        notifEvent = notifEvent,
        bluetooth = bluetooth,
        flashlight = flashlight,
        sports = sports,
        onClick = { onModeChange(CapsuleMode.EXPANDED) }
      )
    } else {
      ExpandedDynamicIsland(
        trackInfo = trackInfo,
        settings = settings,
        accentColor = accentColor,
        activeCard = activeCard,
        batteryState = batteryState,
        callState = callState,
        timerState = timerState,
        notifEvent = notifEvent,
        bluetooth = bluetooth,
        flashlight = flashlight,
        sports = sports,
        onCollapse = { onModeChange(CapsuleMode.MINI) },
        onPlayPauseClick = onPlayPauseClick,
        onNextClick = onNextClick,
        onPrevClick = onPrevClick,
        onSeek = onSeek
      )
    }
  }
}

/**
 * 1. الوضع الطبيعي: كبسولة متوسطة الحجم، في منتصف الشاشة أفقياً، أسفل شريط الحالة مباشرة،
 * لا تلامس حواف الشاشة، سوداء بحواف دائرية وتستقبل اللمسات مباشرة من أول ضغطة.
 */
@Composable
fun MediumDynamicIsland(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  netSpeed: NetSpeedState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  sports: SportsState,
  onClick: () -> Unit
) {
  val context = LocalContext.current
  val isPlaying = trackInfo?.isPlaying == true
  val interactionSource = remember { MutableInteractionSource() }

  Surface(
    modifier = Modifier
      .testTag("mini_capsule_surface")
      .widthIn(min = 210.dp, max = 260.dp)
      .height(settings.capsuleHeightDp.dp)
      .shadow(
        elevation = 16.dp,
        shape = RoundedCornerShape(24.dp),
        spotColor = accentColor.copy(alpha = 0.4f)
      )
      .clip(RoundedCornerShape(24.dp))
      .background(Color(0xFF07080A))
      .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
          listOf(
            Color.White.copy(alpha = 0.16f),
            Color(0xFF1B2230),
            accentColor.copy(alpha = 0.35f)
          )
        ),
        shape = RoundedCornerShape(24.dp)
      )
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick
      ),
    color = Color(0xFF07080A),
    shape = RoundedCornerShape(24.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      when {
        // 1. Flashlight ON: Yellow icon + label + direct turn off button
        flashlight.isOn && settings.enableFlashlightAlert -> {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFFFD600)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Default.FlashlightOn,
                contentDescription = null,
                tint = Color.Black,
                modifier = Modifier.size(17.dp)
              )
            }
            Text(
              text = "المصباح مفعّل",
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Box(
            modifier = Modifier
              .clip(CircleShape)
              .background(Color(0xFF332A00))
              .clickable { IslandStateManager.turnOffFlashlight(context) }
              .padding(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text("إطفاء", color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
          }
        }

        // 2. Call Ongoing / Incoming
        callState.isActive && settings.enableCallAlerts -> {
          if (callState.isIncoming) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.weight(1f, fill = false)
            ) {
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(RealmeGreen.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
              }
              Column {
                Text("mobile", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Normal)
                Text(callState.callerName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
              // Decline circular red button
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFF3B30))
                  .clickable { IslandStateManager.declineCall(context) },
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(15.dp))
              }
              // Answer circular green button
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF34C759))
                  .clickable { IslandStateManager.answerCall(context) },
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(15.dp))
              }
            }
          } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(CircleShape)
                  .background(RealmeGreen.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
              }
              Text(callState.callerName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
              Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFF3B30))
                  .clickable { IslandStateManager.declineCall(context) },
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(13.dp))
              }
            }
          }
        }

        // 3. Battery Charging Event (Matching Reference)
        batteryState.isCharging && settings.enableBatteryAlerts && (System.currentTimeMillis() - batteryState.lastEventTime < 7000L) -> {
          Text("Charging", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${batteryState.percentage}%", color = RealmeGreen, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(18.dp))
          }
        }

        // 4. App Notification Banner
        notifEvent != null && settings.enableNotifications -> {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Notifications, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
            Text(
              text = "${notifEvent.appName}: ${notifEvent.title}",
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        // 5. Timer Running
        timerState.isRunning && settings.enableTimer -> {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFFFB74D).copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFFFB74D), modifier = Modifier.size(16.dp))
            }
            Text(timerState.title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
          }
          Text(timerState.formatRemaining(), color = Color(0xFFFFB74D), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        }

        // 6. Bluetooth Connected
        bluetooth.isConnected && settings.enableBluetoothAlerts && (System.currentTimeMillis() - bluetooth.timestamp < 6000L) -> {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Headphones, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
            Text(bluetooth.deviceName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
          }
          Text("${bluetooth.batteryPct}%", color = accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        // 7. Sports Live Active
        sports.isActive && settings.enableSportsLive -> {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.SportsBaseball, contentDescription = null, tint = Color(0xFFFF8A80), modifier = Modifier.size(16.dp))
            Text("${sports.team1} ${sports.score1} - ${sports.score2} ${sports.team2}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          Text(sports.status, color = TextSecondary, fontSize = 11.sp)
        }

        // 8. Music Playing (Default Active Activity)
        trackInfo != null && isPlaying -> {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            if (trackInfo.albumArt != null) {
              Image(
                bitmap = trackInfo.albumArt.asImageBitmap(),
                contentDescription = "Album Thumbnail",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                  .size(28.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .border(0.8.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
              )
            } else {
              Box(
                modifier = Modifier
                  .size(28.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(accentColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.MusicNote,
                  contentDescription = null,
                  tint = accentColor,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = trackInfo.title,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = trackInfo.artist,
                color = TextSecondary,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }

          Spacer(modifier = Modifier.width(6.dp))

          MiniWaveformVisualizer(
            isPlaying = true,
            color = accentColor,
            barCount = 4,
            width = 18.dp,
            height = 14.dp
          )
        }

        // Idle state (only shown if showWhenIdle is enabled)
        else -> {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E2532))
            )
          }
        }
      }
    }
  }
}

/**
 * 2. الوضع الموسع: تتمدد للأسفل بسلاسة، تعرض صورة الألبوم واسم الأغنية والفنان،
 * أزرار التحكم وشريط التقدم، وأنشطة المصباح والمكالمات والمؤقت بوضوح تام.
 */
@Composable
fun ExpandedDynamicIsland(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  sports: SportsState,
  onCollapse: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val context = LocalContext.current
  var currentSelectedTab by remember { mutableStateOf(activeCard) }

  Surface(
    modifier = Modifier
      .testTag("expanded_capsule_card")
      .widthIn(min = 340.dp, max = 380.dp)
      .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
      .shadow(elevation = 24.dp, shape = RoundedCornerShape(28.dp), spotColor = accentColor.copy(alpha = 0.45f))
      .clip(RoundedCornerShape(28.dp))
      .background(Color(0xFF07080A))
      .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
          listOf(
            Color.White.copy(alpha = 0.18f),
            Color(0xFF202736),
            accentColor.copy(alpha = 0.35f)
          )
        ),
        shape = RoundedCornerShape(28.dp)
      ),
    color = Color(0xFF07080A),
    shape = RoundedCornerShape(28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Header: Multi-activity tabs + Immediate Collapse button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          TabIndicator(
            icon = Icons.Default.GraphicEq,
            isSelected = currentSelectedTab == IslandActiveCard.MUSIC,
            color = accentColor,
            onClick = { currentSelectedTab = IslandActiveCard.MUSIC }
          )

          if (flashlight.isOn) {
            TabIndicator(
              icon = Icons.Default.FlashlightOn,
              isSelected = currentSelectedTab == IslandActiveCard.FLASHLIGHT,
              color = Color(0xFFFFD600),
              onClick = { currentSelectedTab = IslandActiveCard.FLASHLIGHT }
            )
          }

          if (timerState.isRunning) {
            TabIndicator(
              icon = Icons.Default.HourglassTop,
              isSelected = currentSelectedTab == IslandActiveCard.TIMER,
              color = Color(0xFFFFB74D),
              onClick = { currentSelectedTab = IslandActiveCard.TIMER }
            )
          }

          if (callState.isActive) {
            TabIndicator(
              icon = Icons.Default.Call,
              isSelected = currentSelectedTab == IslandActiveCard.CALL,
              color = RealmeGreen,
              onClick = { currentSelectedTab = IslandActiveCard.CALL }
            )
          }

          if (sports.isActive) {
            TabIndicator(
              icon = Icons.Default.SportsBaseball,
              isSelected = currentSelectedTab == IslandActiveCard.SPORTS,
              color = Color(0xFFFF8A80),
              onClick = { currentSelectedTab = IslandActiveCard.SPORTS }
            )
          }

          if (batteryState.isCharging) {
            TabIndicator(
              icon = Icons.Default.BatteryChargingFull,
              isSelected = currentSelectedTab == IslandActiveCard.BATTERY,
              color = RealmeGreen,
              onClick = { currentSelectedTab = IslandActiveCard.BATTERY }
            )
          }
        }

        // Instant Collapse button (Arrow Up ^)
        IconButton(
          onClick = onCollapse,
          modifier = Modifier
            .testTag("collapse_capsule_button")
            .size(32.dp)
            .background(Color.White.copy(alpha = 0.12f), CircleShape)
        ) {
          Icon(
            imageVector = Icons.Rounded.KeyboardArrowUp,
            contentDescription = "Collapse Capsule",
            tint = TextPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Tab Content Views
      when (currentSelectedTab) {
        IslandActiveCard.FLASHLIGHT -> {
          ExpandedFlashlightView(
            flashlight = flashlight,
            onToggle = { IslandStateManager.toggleFlashlight(context) },
            onTurnOff = {
              IslandStateManager.turnOffFlashlight(context)
              if (trackInfo?.isPlaying == true) currentSelectedTab = IslandActiveCard.MUSIC
            }
          )
        }
        IslandActiveCard.TIMER -> {
          ExpandedTimerView(
            timerState = timerState,
            onTogglePause = { IslandStateManager.toggleTimerPause() },
            onCancel = { IslandStateManager.cancelTimer(); currentSelectedTab = IslandActiveCard.MUSIC }
          )
        }
        IslandActiveCard.CALL -> {
          ExpandedCallView(
            callState = callState,
            onAnswer = { IslandStateManager.answerCall(context) },
            onDecline = { IslandStateManager.declineCall(context); currentSelectedTab = IslandActiveCard.MUSIC }
          )
        }
        IslandActiveCard.BATTERY -> {
          ExpandedBatteryView(batteryState = batteryState)
        }
        IslandActiveCard.SPORTS -> {
          ExpandedSportsView(
            sports = sports,
            onDismiss = { IslandStateManager.dismissSports(); currentSelectedTab = IslandActiveCard.MUSIC }
          )
        }
        else -> {
          ExpandedMusicView(
            trackInfo = trackInfo,
            accentColor = accentColor,
            onPlayPauseClick = onPlayPauseClick,
            onNextClick = onNextClick,
            onPrevClick = onPrevClick,
            onSeek = onSeek
          )
        }
      }
    }
  }
}

@Composable
private fun TabIndicator(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isSelected: Boolean,
  color: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(28.dp)
      .clip(CircleShape)
      .background(if (isSelected) color.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f))
      .border(1.dp, if (isSelected) color else Color.Transparent, CircleShape)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isSelected) color else TextSecondary,
      modifier = Modifier.size(15.dp)
    )
  }
}

@Composable
fun ExpandedFlashlightView(
  flashlight: FlashlightState,
  onToggle: () -> Unit,
  onTurnOff: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF262D3D)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (flashlight.isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
          contentDescription = null,
          tint = if (flashlight.isOn) Color.Black else Color.White,
          modifier = Modifier.size(26.dp)
        )
      }

      Column {
        Text(
          text = if (flashlight.isOn) "المصباح مفعّل" else "المصباح متوقف",
          color = TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (flashlight.isOn) "Flashlight is ON" else "Flashlight is OFF",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    Button(
      onClick = onToggle,
      colors = ButtonDefaults.buttonColors(
        containerColor = if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF2E384D),
        contentColor = if (flashlight.isOn) Color.Black else Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text(
        text = if (flashlight.isOn) "إطفاء" else "تشغيل",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }
  }
}

@Composable
fun ExpandedMusicView(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val isPlaying = trackInfo?.isPlaying == true
  val duration = (trackInfo?.durationMs ?: 0L).coerceAtLeast(1L)
  val currentPos = trackInfo?.getEstimatedPositionMs() ?: 0L

  var isUserDragging by remember { mutableStateOf(false) }
  var dragPositionFraction by remember { mutableFloatStateOf(0f) }
  var isFavorite by remember { mutableStateOf(false) }
  var repeatMode by remember { mutableStateOf(0) }

  val effectiveFraction = if (isUserDragging) {
    dragPositionFraction
  } else {
    (currentPos.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
  }

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (trackInfo?.albumArt != null) {
        Image(
          bitmap = trackInfo.albumArt.asImageBitmap(),
          contentDescription = "Album Art",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(62.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .shadow(12.dp, RoundedCornerShape(16.dp), spotColor = accentColor.copy(alpha = 0.5f))
        )
      } else {
        Box(
          modifier = Modifier
            .size(62.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              Brush.linearGradient(
                listOf(Color(0xFF263248), Color(0xFF131926))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(32.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = trackInfo?.title ?: "Far closer",
          color = TextPrimary,
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = trackInfo?.artist ?: "David",
          color = TextSecondary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Normal,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Cast,
          contentDescription = "Cast",
          tint = TextSecondary,
          modifier = Modifier.size(17.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Waveform Visualizer
    ExpandedWaveformVisualizer(
      isPlaying = isPlaying,
      color = accentColor,
      barCount = 22,
      height = 22.dp,
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(6.dp))

    // Controls Row: Repeat, Previous, Play/Pause, Next, Favorite
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = { repeatMode = (repeatMode + 1) % 3 },
        modifier = Modifier.size(40.dp)
      ) {
        Icon(
          imageVector = if (repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
          contentDescription = "Repeat",
          tint = if (repeatMode > 0) accentColor else TextMuted,
          modifier = Modifier.size(20.dp)
        )
      }

      IconButton(
        onClick = onPrevClick,
        modifier = Modifier
          .testTag("prev_track_button")
          .size(44.dp)
          .background(Color.White.copy(alpha = 0.06f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipPrevious,
          contentDescription = "Previous Track",
          tint = TextPrimary,
          modifier = Modifier.size(24.dp)
        )
      }

      IconButton(
        onClick = onPlayPauseClick,
        modifier = Modifier
          .testTag("play_pause_button")
          .size(58.dp)
          .shadow(14.dp, CircleShape, spotColor = accentColor)
          .background(accentColor, CircleShape)
      ) {
        Icon(
          imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
          contentDescription = if (isPlaying) "Pause" else "Play",
          tint = Color.Black,
          modifier = Modifier.size(34.dp)
        )
      }

      IconButton(
        onClick = onNextClick,
        modifier = Modifier
          .testTag("next_track_button")
          .size(44.dp)
          .background(Color.White.copy(alpha = 0.06f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipNext,
          contentDescription = "Next Track",
          tint = TextPrimary,
          modifier = Modifier.size(24.dp)
        )
      }

      IconButton(
        onClick = { isFavorite = !isFavorite },
        modifier = Modifier.size(40.dp)
      ) {
        Icon(
          imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
          contentDescription = "Favorite",
          tint = if (isFavorite) Color(0xFFFF5252) else TextMuted,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Interactive Draggable Seek Slider
    Slider(
      value = effectiveFraction,
      onValueChange = { fraction ->
        isUserDragging = true
        dragPositionFraction = fraction
      },
      onValueChangeFinished = {
        val seekTargetMs = (dragPositionFraction * duration).toLong()
        onSeek(seekTargetMs)
        isUserDragging = false
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(22.dp)
        .testTag("track_progress_slider"),
      colors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color.White.copy(alpha = 0.18f)
      )
    )

    // Timestamp Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 2.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      val displayPos = if (isUserDragging) (dragPositionFraction * duration).toLong() else currentPos
      Text(
        text = trackInfo?.formatTime(displayPos) ?: "02:54",
        color = TextMuted,
        fontSize = 11.sp
      )
      Text(
        text = trackInfo?.formatTime(duration) ?: "03:56",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
fun ExpandedTimerView(
  timerState: TimerState,
  onTogglePause: () -> Unit,
  onCancel: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
      text = timerState.title,
      color = TextSecondary,
      fontSize = 13.sp,
      fontWeight = FontWeight.Medium
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = timerState.formatRemaining(),
      color = Color(0xFFFFB74D),
      fontSize = 38.sp,
      fontWeight = FontWeight.ExtraBold,
      letterSpacing = 1.sp
    )

    Spacer(modifier = Modifier.height(16.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      Surface(
        shape = CircleShape,
        color = Color(0xFF2C2F38),
        modifier = Modifier
          .clickable(onClick = onCancel)
          .padding(horizontal = 24.dp, vertical = 10.dp)
      ) {
        Text("Cancel", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      }

      Surface(
        shape = CircleShape,
        color = Color(0xFFFFB74D),
        modifier = Modifier
          .clickable(onClick = onTogglePause)
          .padding(horizontal = 24.dp, vertical = 10.dp)
      ) {
        Text(
          text = if (timerState.isRunning) "Pause" else "Resume",
          color = Color.Black,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}

@Composable
fun ExpandedCallView(
  callState: CallState,
  onAnswer: () -> Unit,
  onDecline: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Box(
      modifier = Modifier
        .size(52.dp)
        .clip(CircleShape)
        .background(Color(0xFF384358)),
      contentAlignment = Alignment.Center
    ) {
      Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = callState.callerNumber,
        color = TextSecondary,
        fontSize = 11.sp
      )
      Text(
        text = callState.callerName,
        color = TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold
      )
      if (!callState.isIncoming) {
        Text(
          text = callState.formatDuration(),
          color = RealmeGreen,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      IconButton(
        onClick = onDecline,
        modifier = Modifier
          .size(46.dp)
          .background(Color(0xFFFF3B30), CircleShape)
      ) {
        Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(22.dp))
      }

      if (callState.isIncoming) {
        IconButton(
          onClick = onAnswer,
          modifier = Modifier
            .size(46.dp)
            .background(Color(0xFF34C759), CircleShape)
        ) {
          Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(22.dp))
        }
      }
    }
  }
}

@Composable
fun ExpandedBatteryView(batteryState: BatteryState) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(RealmeGreen.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(24.dp))
      }
      Column {
        Text("Charging", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("SuperVOOC / Fast Charging", color = TextSecondary, fontSize = 12.sp)
      }
    }

    Text(
      text = "${batteryState.percentage}%",
      color = RealmeGreen,
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

@Composable
fun ExpandedSportsView(
  sports: SportsState,
  onDismiss: () -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(sports.team1, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(sports.score1.toString(), color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
      }

      Text(sports.status, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)

      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(sports.score2.toString(), color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(sports.team2, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Surface(
      color = Color(0xFF141A24),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .width(3.dp)
            .height(28.dp)
            .background(Color(0xFFFF9800), RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = sports.headline,
          color = TextSecondary,
          fontSize = 11.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}
