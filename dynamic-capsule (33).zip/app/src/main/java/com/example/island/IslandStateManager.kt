package com.example.island

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object IslandStateManager {

  private const val TAG = "IslandStateManager"
  private val scopeExceptionHandler = CoroutineExceptionHandler { _, throwable ->
    Log.e(TAG, "Uncaught exception in IslandStateManager scope", throwable)
  }
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + scopeExceptionHandler)

  // States
  private val _batteryState = MutableStateFlow(BatteryState())
  val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

  private val _callState = MutableStateFlow(CallState())
  val callState: StateFlow<CallState> = _callState.asStateFlow()

  private val _timerState = MutableStateFlow(TimerState())
  val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

  private val _activeNotification = MutableStateFlow<NotificationEvent?>(null)
  val activeNotification: StateFlow<NotificationEvent?> = _activeNotification.asStateFlow()

  private val _bluetoothState = MutableStateFlow(BluetoothState())
  val bluetoothState: StateFlow<BluetoothState> = _bluetoothState.asStateFlow()

  private val _flashlightState = MutableStateFlow(FlashlightState())
  val flashlightState: StateFlow<FlashlightState> = _flashlightState.asStateFlow()

  private val _ringerState = MutableStateFlow(RingerState())
  val ringerState: StateFlow<RingerState> = _ringerState.asStateFlow()

  private val _currentSoundMode = MutableStateFlow(SoundMode.RING)
  val currentSoundMode: StateFlow<SoundMode> = _currentSoundMode.asStateFlow()

  private val _downloadState = MutableStateFlow(DownloadState())
  val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

  private val _navigationState = MutableStateFlow(NavigationState())
  val navigationState: StateFlow<NavigationState> = _navigationState.asStateFlow()

  private val _privacyState = MutableStateFlow(PrivacyState())
  val privacyState: StateFlow<PrivacyState> = _privacyState.asStateFlow()

  private val _networkState = MutableStateFlow(NetworkState())
  val networkState: StateFlow<NetworkState> = _networkState.asStateFlow()

  private val _volumeState = MutableStateFlow(VolumeState())
  val volumeState: StateFlow<VolumeState> = _volumeState.asStateFlow()

  private val _sleepTimerState = MutableStateFlow(SleepTimerState())
  val sleepTimerState: StateFlow<SleepTimerState> = _sleepTimerState.asStateFlow()

  private val _nextAlarmState = MutableStateFlow(NextAlarmState())
  val nextAlarmState: StateFlow<NextAlarmState> = _nextAlarmState.asStateFlow()

  private val _weatherState = MutableStateFlow(WeatherState())
  val weatherState: StateFlow<WeatherState> = _weatherState.asStateFlow()

  private val _prayerState = MutableStateFlow(PrayerTimesState())
  val prayerState: StateFlow<PrayerTimesState> = _prayerState.asStateFlow()

  private val _stepsState = MutableStateFlow(StepsState())
  val stepsState: StateFlow<StepsState> = _stepsState.asStateFlow()

  private val _compassState = MutableStateFlow(CompassState())
  val compassState: StateFlow<CompassState> = _compassState.asStateFlow()

  private val _focusState = MutableStateFlow(FocusState())
  val focusState: StateFlow<FocusState> = _focusState.asStateFlow()

  private val _deliveryState = MutableStateFlow(DeliveryState())
  val deliveryState: StateFlow<DeliveryState> = _deliveryState.asStateFlow()

  private val _footballState = MutableStateFlow(FootballState())
  val footballState: StateFlow<FootballState> = _footballState.asStateFlow()

  private val _activityEventSeq = MutableStateFlow(0L)
  val activityEventSeq: StateFlow<Long> = _activityEventSeq.asStateFlow()

  private val _activeCard = MutableStateFlow(IslandActiveCard.MUSIC)
  val activeCard: StateFlow<IslandActiveCard> = _activeCard.asStateFlow()

  private val _suppressedCards = MutableStateFlow<Set<IslandActiveCard>>(emptySet())
  val suppressedCards: StateFlow<Set<IslandActiveCard>> = _suppressedCards.asStateFlow()

  private var timerJob: Job? = null
  private var sleepTimerJob: Job? = null
  private var focusTimerJob: Job? = null
  private var weatherAutoJob: Job? = null
  private var weatherFetchJob: Job? = null
  private var weatherAlertExpireJob: Job? = null
  private var prayerAutoJob: Job? = null
  private var prayerAlertExpireJob: Job? = null
  private var footballAutoJob: Job? = null
  private var footballFetchJob: Job? = null
  private var footballAlertExpireJob: Job? = null
  private var footballClockJob: Job? = null
  private var footballEventExpireJob: Job? = null
  private var deliveryExpireJob: Job? = null
  private var stepsAlertExpireJob: Job? = null
  private var callTickerJob: Job? = null
  private var recorderTickerJob: Job? = null
  private var notificationExpireJob: Job? = null
  private var batteryExpireJob: Job? = null
  private var batteryLiveTickerJob: Job? = null
  private var ringerExpireJob: Job? = null
  private var bluetoothExpireJob: Job? = null
  private var downloadExpireJob: Job? = null
  private var networkExpireJob: Job? = null
  private var networkLostCheckJob: Job? = null
  private var volumeExpireJob: Job? = null
  private val remindedPreMatchIds = mutableSetOf<String>()
  private var lastPreAdhanKey: String = ""
  private var lastTelephonyState: Int = TelephonyManager.CALL_STATE_IDLE
  private var lastNetworkType: NetworkEventType? = null
  private var lastHotspotEnabled: Boolean? = null
  private var lastMediaVolume: Int = -1
  private var lastTorchToggleTimeMs: Long = 0L

  private var stepCounterManager: StepCounterManager? = null
  private var compassSensorManager: CompassSensorManager? = null
  private var activeBluetoothAddress: String? = null

  private var timerPauseResumeIntent: PendingIntent? = null
  private var timerCancelIntent: PendingIntent? = null
  private var navContentIntent: PendingIntent? = null
  private var navStopIntent: PendingIntent? = null
  private var deliveryContentIntent: PendingIntent? = null
  private var notifContentIntent: PendingIntent? = null
  private var downloadContentIntent: PendingIntent? = null
  private var downloadPackageName: String = ""
  private var recorderPauseIntent: PendingIntent? = null
  private var recorderStopIntent: PendingIntent? = null
  private var lastLowAlertPct: Int = 100
  private var lastFullAlertShown: Boolean = false
  private var wasChargingState: Boolean? = null

  private var cameraManager: CameraManager? = null
  private var torchCallback: CameraManager.TorchCallback? = null
  private var availabilityCallback: CameraManager.AvailabilityCallback? = null
  private var audioRecordingCallback: AudioManager.AudioRecordingCallback? = null
  private val unavailableCameras = mutableSetOf<String>()
  private var flashCameraId: String? = null
  private var isInitialized = false
  private var appContextRef: Context? = null

  fun initialize(context: Context) {
    val appCtx = context.applicationContext ?: context
    appContextRef = appCtx
    if (isInitialized) return
    isInitialized = true

    registerBatteryReceiver(appCtx)
    initFlashlight(appCtx)
    initPrivacyMonitors(appCtx)
    registerNetworkAndConnectivityMonitors(appCtx)
    registerTelephony(appCtx)
    registerRingerReceiver(appCtx)
    registerBluetoothAndHeadsetReceiver(appCtx)
    registerNextAlarmMonitor(appCtx)
    initStepsAndCompass(appCtx)
    startWeatherAutoUpdater(appCtx)
    startPrayerAutoUpdater(appCtx)
    startFootballAutoUpdater(appCtx)
  }

  fun shouldShowInOrientation(isLandscape: Boolean, hideInLandscape: Boolean, hasActiveCall: Boolean): Boolean {
    if (!isLandscape || !hideInLandscape) return true
    // Always keep incoming/active calls visible so user never misses a call while gaming/watching video
    return hasActiveCall
  }

  fun shouldCapsuleRemainVisible(
    hasActivity: Boolean,
    isExpanded: Boolean,
    showWhenIdle: Boolean,
    serviceEnabled: Boolean,
    effectivelyDismissed: Boolean,
    allowedInOrientation: Boolean
  ): Boolean {
    return serviceEnabled &&
      (hasActivity || isExpanded || showWhenIdle) &&
      !effectivelyDismissed &&
      allowedInOrientation
  }

  private fun bumpActivityEvent() {
    _activityEventSeq.value = _activityEventSeq.value + 1L
  }

  private fun currentSettings(context: Context? = appContextRef): CapsuleSettings? {
    val ctx = context ?: appContextRef ?: return null
    return CapsuleSettingsManager.getInstance(ctx).settings.value
  }

  private val autoSuppressibleOnAudioSwitch = setOf(
    IslandActiveCard.WEATHER,
    IslandActiveCard.FOOTBALL,
    IslandActiveCard.PRAYER,
    IslandActiveCard.STEPS,
    IslandActiveCard.NOTIFICATION,
    IslandActiveCard.BATTERY,
    IslandActiveCard.BLUETOOTH,
    IslandActiveCard.NETWORK,
    IslandActiveCard.VOLUME
  )

  private val autoSuppressibleOnSwipeDismiss = autoSuppressibleOnAudioSwitch + IslandActiveCard.RINGER

  fun isCardSuppressed(card: IslandActiveCard): Boolean = _suppressedCards.value.contains(card)

  private fun clearTransientBannerForCard(card: IslandActiveCard) {
    when (card) {
      IslandActiveCard.FOOTBALL -> {
        footballAlertExpireJob?.cancel()
        footballEventExpireJob?.cancel()
        _footballState.value = _footballState.value.copy(isAlertActive = false, activeEvent = null)
      }
      IslandActiveCard.WEATHER -> {
        weatherAlertExpireJob?.cancel()
        _weatherState.value = _weatherState.value.copy(isAlertActive = false)
      }
      IslandActiveCard.PRAYER -> {
        prayerAlertExpireJob?.cancel()
        _prayerState.value = _prayerState.value.copy(isAlertActive = false)
      }
      IslandActiveCard.STEPS -> {
        stepsAlertExpireJob?.cancel()
        _stepsState.value = _stepsState.value.copy(isAlertActive = false)
      }
      IslandActiveCard.BATTERY -> {
        batteryExpireJob?.cancel()
        _batteryState.value = _batteryState.value.copy(isAlertActive = false, isLowAlert = false, isFullAlert = false)
      }
      IslandActiveCard.NOTIFICATION -> {
        notificationExpireJob?.cancel()
        _activeNotification.value = null
      }
      IslandActiveCard.BLUETOOTH -> {
        bluetoothExpireJob?.cancel()
        _bluetoothState.value = _bluetoothState.value.copy(isAlertActive = false)
      }
      IslandActiveCard.NETWORK -> {
        networkExpireJob?.cancel()
        _networkState.value = _networkState.value.copy(isActive = false)
      }
      IslandActiveCard.VOLUME -> {
        volumeExpireJob?.cancel()
        _volumeState.value = _volumeState.value.copy(isActive = false)
      }
      IslandActiveCard.RINGER -> {
        ringerExpireJob?.cancel()
        _ringerState.value = _ringerState.value.copy(isActive = false)
      }
      else -> Unit
    }
  }

  fun suppressCard(
    card: IslandActiveCard,
    trackInfo: MediaTrackInfo? = MediaSessionHolder.currentTrack.value
  ) {
    if (card == IslandActiveCard.MUSIC || card == IslandActiveCard.CALL || card == IslandActiveCard.QUICK_CONTROLS) {
      return
    }
    _suppressedCards.value = _suppressedCards.value + card
    clearTransientBannerForCard(card)
    if (_activeCard.value == card) {
      val settings = currentSettings()
      _activeCard.value = settings?.let { resolvePrimaryMiniCard(trackInfo, it) } ?: IslandActiveCard.MUSIC
    }
  }

  fun unsuppressCard(card: IslandActiveCard) {
    if (_suppressedCards.value.contains(card)) {
      _suppressedCards.value = _suppressedCards.value - card
    }
  }

  fun onExpandedTabSwitched(
    fromCard: IslandActiveCard,
    toCard: IslandActiveCard,
    trackInfo: MediaTrackInfo? = MediaSessionHolder.currentTrack.value
  ) {
    unsuppressCard(toCard)
    if (fromCard != toCard &&
      (toCard == IslandActiveCard.MUSIC || toCard == IslandActiveCard.RINGER) &&
      fromCard in autoSuppressibleOnAudioSwitch
    ) {
      suppressCard(fromCard, trackInfo)
    }
    if (toCard != IslandActiveCard.QUICK_CONTROLS) {
      _activeCard.value = toCard
    }
  }

  fun onCapsuleSwipedDismissed(
    trackInfo: MediaTrackInfo? = MediaSessionHolder.currentTrack.value,
    settings: CapsuleSettings? = currentSettings()
  ) {
    val resolvedSettings = settings ?: return
    val primary = resolvePrimaryMiniCard(trackInfo, resolvedSettings) ?: return
    if (primary in autoSuppressibleOnSwipeDismiss) {
      suppressCard(primary, trackInfo)
    }
  }

  private fun activateCardAndNotify(
    card: IslandActiveCard,
    context: Context? = appContextRef,
    bumpEvent: Boolean = true,
    respectCallPriority: Boolean = true
  ): Boolean {
    if (context != null && appContextRef == null) {
      appContextRef = context.applicationContext ?: context
    }
    unsuppressCard(card)
    if (!respectCallPriority || !_callState.value.isActive || card == IslandActiveCard.CALL) {
      _activeCard.value = card
    }
    if (bumpEvent) {
      bumpActivityEvent()
    }
    return true
  }

  fun hasAnyActiveActivity(trackInfo: MediaTrackInfo?): Boolean {
    val now = System.currentTimeMillis()
    val isMusicActive = trackInfo != null && trackInfo.isPlaying
    val isFlashlightActive = _flashlightState.value.isOn
    val isCallActive = _callState.value.isActive
    val isTimerActive = _timerState.value.isActive
    val isSleepTimerActive = _sleepTimerState.value.isActive
    val isFocusActive = _focusState.value.isActive
    val isCompassActive = _compassState.value.isActive
    val isDeliveryActive = _deliveryState.value.isActive
    val fb = _footballState.value
    val isFootballAlert = fb.isLoaded && (fb.activeEvent != null || fb.isAlertActive)
    val isPrayerAlert = _prayerState.value.isLoaded && _prayerState.value.isAlertActive
    val isWeatherAlert = _weatherState.value.isLoaded && _weatherState.value.isAlertActive
    val isStepsAlert = _stepsState.value.isAlertActive && (now - _stepsState.value.timestamp < 8000L)
    val isNavActive = _navigationState.value.isActive
    val isPrivacyActive = _privacyState.value.hasAnyActivity
    val isNetworkActive = _networkState.value.isActive && (now - _networkState.value.timestamp < 4000L)
    val isVolumeActive = _volumeState.value.isActive && (now - _volumeState.value.timestamp < 2500L)
    val isBatteryAlertActive = _batteryState.value.isAlertActive && (now - _batteryState.value.lastEventTime < 7000L)
    val isNotifActive = _activeNotification.value != null && (now - (_activeNotification.value?.timestamp ?: 0L) < 5000L)
    val isBluetoothActive = _bluetoothState.value.isAlertActive && (now - _bluetoothState.value.timestamp < 6000L)
    val isRingerActive = _ringerState.value.isActive && (now - _ringerState.value.timestamp < 3500L)
    val isDownloadActive = _downloadState.value.isActive && (now - _downloadState.value.timestamp < 30000L)

    return isMusicActive || isFlashlightActive || isCallActive || isTimerActive || isSleepTimerActive ||
      isFocusActive || isCompassActive || isDeliveryActive || isFootballAlert || isPrayerAlert || isWeatherAlert || isStepsAlert ||
      isNavActive || isPrivacyActive || isNetworkActive || isVolumeActive || isBatteryAlertActive ||
      isNotifActive || isBluetoothActive || isRingerActive || isDownloadActive
  }

  fun hasRenderableActivity(trackInfo: MediaTrackInfo?, settings: CapsuleSettings): Boolean {
    return resolvePrimaryMiniCard(trackInfo, settings) != null
  }

  fun isCardCurrentlyActive(card: IslandActiveCard, trackInfo: MediaTrackInfo?, settings: CapsuleSettings): Boolean {
    if (isCardSuppressed(card)) return false
    val now = System.currentTimeMillis()
    return when (card) {
      IslandActiveCard.RINGER -> _ringerState.value.isActive && settings.enableRingerAlerts && (now - _ringerState.value.timestamp < 3500L)
      IslandActiveCard.VOLUME -> _volumeState.value.isActive && settings.enableVolumeAlerts && (now - _volumeState.value.timestamp < 2500L)
      IslandActiveCard.CALL -> _callState.value.isActive && settings.enableCallAlerts
      IslandActiveCard.NETWORK -> _networkState.value.isActive && settings.enableNetworkAlerts && (now - _networkState.value.timestamp < 4000L)
      IslandActiveCard.BATTERY -> _batteryState.value.isAlertActive &&
        settings.enableBatteryAlerts && (now - _batteryState.value.lastEventTime < 7000L)
      IslandActiveCard.NOTIFICATION -> _activeNotification.value != null && settings.enableNotifications &&
        (now - (_activeNotification.value?.timestamp ?: 0L) < 5000L)
      IslandActiveCard.BLUETOOTH -> _bluetoothState.value.isAlertActive && settings.enableBluetoothAlerts &&
        (now - _bluetoothState.value.timestamp < 6000L)
      IslandActiveCard.PRAYER -> settings.enablePrayerAlerts &&
        (_prayerState.value.isLoaded && (_prayerState.value.isAlertActive || settings.pinPrayerInCapsule))
      IslandActiveCard.WEATHER -> settings.enableWeatherAlerts &&
        (settings.pinWeatherInCapsule ||
          (_weatherState.value.isLoaded && _weatherState.value.isAlertActive) ||
          _activeCard.value == IslandActiveCard.WEATHER)
      IslandActiveCard.STEPS -> settings.enableStepsCounter &&
        ((_stepsState.value.isAlertActive && now - _stepsState.value.timestamp < 8000L) || settings.pinStepsInCapsule)
      IslandActiveCard.DELIVERY -> _deliveryState.value.isActive && settings.enableDeliveryAlerts
      IslandActiveCard.FOOTBALL -> {
        val fb = _footballState.value
        val hasLiveMatch = fb.matches.any { !it.isFinished && it.isLive }
        val isCurrentLive = fb.currentMatch?.let { !it.isFinished && it.isLive } == true
        settings.enableFootballScores && (
          fb.activeEvent != null ||
            fb.isAlertActive ||
            (settings.pinFootballInCapsule && fb.isLoaded && (isCurrentLive || hasLiveMatch))
          )
      }
      IslandActiveCard.FOCUS -> settings.enableFocusTimer && _focusState.value.isActive
      IslandActiveCard.COMPASS -> settings.enableCompass && _compassState.value.isActive
      IslandActiveCard.NAVIGATION -> _navigationState.value.isActive && settings.enableNavigationAlerts
      IslandActiveCard.TIMER -> _timerState.value.isActive && settings.enableTimer
      IslandActiveCard.SLEEP_TIMER -> _sleepTimerState.value.isActive
      IslandActiveCard.DOWNLOAD -> _downloadState.value.isActive && settings.enableDownloadProgress &&
        (now - _downloadState.value.timestamp < 30000L)
      IslandActiveCard.FLASHLIGHT -> _flashlightState.value.isOn && settings.enableFlashlightAlert
      IslandActiveCard.PRIVACY -> _privacyState.value.hasAnyActivity && settings.enablePrivacyAlerts
      IslandActiveCard.MUSIC -> trackInfo != null && trackInfo.isPlaying
      IslandActiveCard.QUICK_CONTROLS, IslandActiveCard.CLOCK -> false
    }
  }

  fun resolvePrimaryMiniCard(trackInfo: MediaTrackInfo?, settings: CapsuleSettings): IslandActiveCard? {
    val urgentOrder = listOf(
      IslandActiveCard.CALL,
      IslandActiveCard.VOLUME,
      IslandActiveCard.RINGER,
      IslandActiveCard.NETWORK,
      IslandActiveCard.BATTERY,
      IslandActiveCard.NOTIFICATION,
      IslandActiveCard.BLUETOOTH
    )
    for (urgent in urgentOrder) {
      if (isCardCurrentlyActive(urgent, trackInfo, settings)) return urgent
    }

    val selected = _activeCard.value
    val persistentOrder = listOf(
      IslandActiveCard.NAVIGATION,
      IslandActiveCard.DELIVERY,
      IslandActiveCard.TIMER,
      IslandActiveCard.FOCUS,
      IslandActiveCard.DOWNLOAD,
      IslandActiveCard.FLASHLIGHT,
      IslandActiveCard.MUSIC,
      IslandActiveCard.FOOTBALL,
      IslandActiveCard.PRAYER,
      IslandActiveCard.COMPASS,
      IslandActiveCard.SLEEP_TIMER,
      IslandActiveCard.PRIVACY,
      IslandActiveCard.STEPS,
      IslandActiveCard.WEATHER
    )
    if (selected in persistentOrder && isCardCurrentlyActive(selected, trackInfo, settings)) {
      return selected
    }
    return persistentOrder.firstOrNull { isCardCurrentlyActive(it, trackInfo, settings) }
  }

  fun getSecondaryActiveCard(
    trackInfo: MediaTrackInfo?,
    settings: CapsuleSettings,
    primaryCard: IslandActiveCard?
  ): IslandActiveCard? {
    if (!settings.enableDualCapsule || primaryCard == null) return null
    val candidates = listOf(
      IslandActiveCard.CALL,
      IslandActiveCard.NAVIGATION,
      IslandActiveCard.DELIVERY,
      IslandActiveCard.TIMER,
      IslandActiveCard.FOCUS,
      IslandActiveCard.SLEEP_TIMER,
      IslandActiveCard.DOWNLOAD,
      IslandActiveCard.MUSIC,
      IslandActiveCard.FOOTBALL,
      IslandActiveCard.PRAYER,
      IslandActiveCard.FLASHLIGHT,
      IslandActiveCard.STEPS,
      IslandActiveCard.WEATHER,
      IslandActiveCard.PRIVACY
    )
    return candidates.firstOrNull { candidate ->
      if (candidate == primaryCard || !isCardCurrentlyActive(candidate, trackInfo, settings)) {
        return@firstOrNull false
      }
      if (candidate == IslandActiveCard.FOOTBALL) {
        val currentMatch = _footballState.value.currentMatch
        return@firstOrNull currentMatch != null && !currentMatch.isFinished && currentMatch.isLive
      }
      true
    }
  }

  fun cycleToNextCard(
    trackInfo: MediaTrackInfo?,
    settings: CapsuleSettings,
    fromCard: IslandActiveCard? = _activeCard.value
  ): IslandActiveCard? {
    val cycleOrder = listOf(
      IslandActiveCard.MUSIC,
      IslandActiveCard.NAVIGATION,
      IslandActiveCard.DELIVERY,
      IslandActiveCard.FOOTBALL,
      IslandActiveCard.PRAYER,
      IslandActiveCard.TIMER,
      IslandActiveCard.FOCUS,
      IslandActiveCard.DOWNLOAD,
      IslandActiveCard.FLASHLIGHT,
      IslandActiveCard.STEPS,
      IslandActiveCard.WEATHER,
      IslandActiveCard.COMPASS,
      IslandActiveCard.SLEEP_TIMER,
      IslandActiveCard.PRIVACY
    )
    val activeList = cycleOrder.filter { isCardCurrentlyActive(it, trackInfo, settings) }
    val pool = when {
      activeList.size >= 2 -> activeList
      else -> buildList {
        addAll(activeList)
        if (settings.enableWeatherAlerts && !isCardSuppressed(IslandActiveCard.WEATHER) && !contains(IslandActiveCard.WEATHER)) add(IslandActiveCard.WEATHER)
        if (settings.enablePrayerAlerts && !isCardSuppressed(IslandActiveCard.PRAYER) && !contains(IslandActiveCard.PRAYER)) add(IslandActiveCard.PRAYER)
        if (settings.enableStepsCounter && !isCardSuppressed(IslandActiveCard.STEPS) && !contains(IslandActiveCard.STEPS)) add(IslandActiveCard.STEPS)
        if (settings.enableFootballScores && !isCardSuppressed(IslandActiveCard.FOOTBALL) && !contains(IslandActiveCard.FOOTBALL)) add(IslandActiveCard.FOOTBALL)
        if (settings.enableDeliveryAlerts && !isCardSuppressed(IslandActiveCard.DELIVERY) && _deliveryState.value.isActive && !contains(IslandActiveCard.DELIVERY)) add(IslandActiveCard.DELIVERY)
        if (settings.enableFocusTimer && !isCardSuppressed(IslandActiveCard.FOCUS) && !contains(IslandActiveCard.FOCUS)) add(IslandActiveCard.FOCUS)
        if (trackInfo != null && !contains(IslandActiveCard.MUSIC)) add(IslandActiveCard.MUSIC)
      }.ifEmpty { return null }
    }
    if (pool.isEmpty()) return null
    val curIdx = pool.indexOf(fromCard)
    val next = pool[(curIdx + 1) % pool.size]
    unsuppressCard(next)
    when (next) {
      IslandActiveCard.STEPS -> {
        _stepsState.value = _stepsState.value.copy(
          isAlertActive = true,
          timestamp = System.currentTimeMillis()
        )
      }
      IslandActiveCard.WEATHER -> {
        _weatherState.value = _weatherState.value.copy(isAlertActive = true)
      }
      IslandActiveCard.PRAYER -> {
        _prayerState.value = _prayerState.value.copy(isAlertActive = true)
      }
      IslandActiveCard.FOOTBALL -> {
        val fb = _footballState.value
        _footballState.value = fb.copy(isAlertActive = true)
        if (fb.matches.none { !it.isFinished && it.isLive } && fb.activeEvent == null) {
          footballAlertExpireJob?.cancel()
          footballAlertExpireJob = scope.launch {
            delay(10_000L)
            val latest = _footballState.value
            val stillLive = latest.matches.any { !it.isFinished && it.isLive }
            _footballState.value = latest.copy(
              isAlertActive = stillLive || latest.activeEvent != null
            )
            if (_activeCard.value == IslandActiveCard.FOOTBALL && !stillLive && latest.activeEvent == null) {
              _activeCard.value = IslandActiveCard.MUSIC
            }
          }
        }
      }
      else -> Unit
    }
    _activeCard.value = next
    return next
  }

  fun normalizeBatteryCurrentMa(rawCurrent: Int): Int {
    if (rawCurrent == 0 || rawCurrent == Int.MIN_VALUE) return 0
    val absRaw = kotlin.math.abs(rawCurrent)
    return if (absRaw > 20_000) absRaw / 1000 else absRaw
  }

  fun classifyChargingTier(watts: Float, plugged: Int): Pair<Int, String> {
    return when {
      watts >= 45f -> 3 to "HyperCharge خارق"
      watts >= 18f -> 2 to "Mi Turbo Charge"
      watts >= 10f || plugged == BatteryManager.BATTERY_PLUGGED_AC -> 1 to "شحن سريع"
      plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS -> 1 to "شحن لاسلكي"
      else -> 0 to "شحن قياسي"
    }
  }

  private fun startBatteryLiveTicker(context: Context) {
    if (batteryLiveTickerJob?.isActive == true) return
    val appCtx = context.applicationContext ?: context
    batteryLiveTickerJob = scope.launch {
      while (isActive && _batteryState.value.isCharging) {
        delay(1500L)
        sampleLiveBatteryTelemetry(appCtx)
      }
    }
  }

  private fun stopBatteryLiveTicker() {
    batteryLiveTickerJob?.cancel()
    batteryLiveTickerJob = null
  }

  private fun sampleLiveBatteryTelemetry(context: Context) {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return
    val stickyIntent = try {
      context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    } catch (_: Exception) {
      null
    }
    val plugged = stickyIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
    val voltageMv = stickyIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: (_batteryState.value.voltageV * 1000f).toInt()
    val rawTemp = stickyIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    val tempC = if (rawTemp > 0) rawTemp / 10f else _batteryState.value.temperatureC

    val curNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val curAvg = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
    val currentMa = normalizeBatteryCurrentMa(if (curNow != 0 && curNow != Int.MIN_VALUE) curNow else curAvg)
    val volts = if (voltageMv > 0) voltageMv / 1000f else _batteryState.value.voltageV
    val watts = if (_batteryState.value.isCharging && currentMa > 0 && volts > 0f) {
      ((currentMa / 1000f) * volts).coerceIn(0f, 150f)
    } else 0f
    val (tierIdx, tierLabel) = classifyChargingTier(watts, plugged)
    val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).takeIf { it in 0..100 }
      ?: _batteryState.value.percentage

    _batteryState.value = _batteryState.value.copy(
      percentage = pct,
      temperatureC = tempC,
      chargingWatts = watts,
      currentMa = currentMa,
      voltageV = volts,
      chargeTierIndex = tierIdx,
      chargeSpeedLabel = tierLabel
    )
  }

  private fun registerBatteryReceiver(context: Context) {
    val pmInit = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    _batteryState.value = _batteryState.value.copy(
      isPowerSaveMode = pmInit?.isPowerSaveMode == true
    )

    val filter = IntentFilter().apply {
      addAction(Intent.ACTION_POWER_CONNECTED)
      addAction(Intent.ACTION_POWER_DISCONNECTED)
      addAction(Intent.ACTION_BATTERY_CHANGED)
      addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
          PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> {
            val c = ctx ?: context
            val pm = c.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val powerSave = pm?.isPowerSaveMode == true
            val batteryEnabled = CapsuleSettingsManager.getInstance(c).settings.value.enableBatteryAlerts
            if (batteryEnabled && powerSave) {
              unsuppressCard(IslandActiveCard.BATTERY)
            }
            _batteryState.value = _batteryState.value.copy(
              isPowerSaveMode = powerSave,
              pluggedType = if (powerSave) "وضع توفير الطاقة مفعل" else _batteryState.value.pluggedType,
              isAlertActive = batteryEnabled && powerSave,
              lastEventTime = System.currentTimeMillis()
            )
            if (batteryEnabled && powerSave && !_callState.value.isActive) {
              _activeCard.value = IslandActiveCard.BATTERY
              bumpActivityEvent()
              batteryExpireJob?.cancel()
              batteryExpireJob = scope.launch {
                delay(5000)
                _batteryState.value = _batteryState.value.copy(isAlertActive = false)
                if (_activeCard.value == IslandActiveCard.BATTERY) {
                  _activeCard.value = IslandActiveCard.MUSIC
                }
              }
            }
          }
          Intent.ACTION_POWER_CONNECTED -> {
            val c = ctx ?: context
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.takeIf { it in 0..100 }
              ?: _batteryState.value.percentage
            lastFullAlertShown = false
            lastLowAlertPct = 100
            showBatteryCharging(pct, context = c)
          }
          Intent.ACTION_POWER_DISCONNECTED -> {
            wasChargingState = false
            lastFullAlertShown = false
            batteryExpireJob?.cancel()
            stopBatteryLiveTicker()
            _batteryState.value = _batteryState.value.copy(
              isCharging = false,
              isFullAlert = false,
              isAlertActive = false,
              chargingWatts = 0f,
              currentMa = 0,
              chargeTierIndex = 0,
              chargeSpeedLabel = "",
              lastEventTime = System.currentTimeMillis()
            )
            if (_activeCard.value == IslandActiveCard.BATTERY) {
              _activeCard.value = IslandActiveCard.MUSIC
            }
          }
          Intent.ACTION_BATTERY_CHANGED -> {
            val c = ctx ?: context
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val rawTemp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
            val tempC = if (rawTemp > 0) rawTemp / 10f else _batteryState.value.temperatureC
            val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)

            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
              status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            val isLow = pct <= 20 && !isCharging
            val pluggedLabel = when (plugged) {
              BatteryManager.BATTERY_PLUGGED_AC -> "شاحن سريع (AC)"
              BatteryManager.BATTERY_PLUGGED_USB -> "شحن USB"
              BatteryManager.BATTERY_PLUGGED_WIRELESS -> "شحن لاسلكي"
              else -> if (isCharging) "متصل بالشاحن" else ""
            }

            val bm = c.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val curNow = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
            val curAvg = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) ?: 0
            val currentMa = if (isCharging) {
              normalizeBatteryCurrentMa(if (curNow != 0 && curNow != Int.MIN_VALUE) curNow else curAvg)
            } else 0
            val volts = if (voltageMv > 0) voltageMv / 1000f else _batteryState.value.voltageV
            val watts = if (isCharging && currentMa > 0 && volts > 0f) {
              ((currentMa / 1000f) * volts).coerceIn(0f, 150f)
            } else 0f
            val (tierIdx, tierLabel) = if (isCharging) classifyChargingTier(watts, plugged) else (0 to "")

            val prevCharging = wasChargingState
            wasChargingState = isCharging
            val batteryEnabled = CapsuleSettingsManager.getInstance(c).settings.value.enableBatteryAlerts

            _batteryState.value = _batteryState.value.copy(
              isCharging = isCharging,
              percentage = pct,
              isLow = isLow,
              pluggedType = pluggedLabel,
              temperatureC = tempC,
              chargingWatts = watts,
              currentMa = currentMa,
              voltageV = volts,
              chargeTierIndex = tierIdx,
              chargeSpeedLabel = tierLabel
            )

            if (isCharging) {
              startBatteryLiveTicker(c)
            } else {
              stopBatteryLiveTicker()
            }

            if (prevCharging == false && isCharging) {
              if (batteryEnabled) showBatteryCharging(pct, pluggedLabel, c)
              return
            }

            if (isCharging && (status == BatteryManager.BATTERY_STATUS_FULL || pct >= 100) && !lastFullAlertShown) {
              lastFullAlertShown = true
              if (batteryEnabled) showBatteryFullAlert(pct, pluggedLabel)
              return
            }

            if (isLow && pct < lastLowAlertPct && (pct == 20 || pct == 15 || pct == 10 || pct <= 5)) {
              lastLowAlertPct = pct
              if (batteryEnabled) showBatteryLowAlert(pct)
              return
            }
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering battery receiver", e)
    }
  }

  fun showBatteryCharging(pct: Int, pluggedType: String = "Mi Turbo Charge", context: Context? = null) {
    unsuppressCard(IslandActiveCard.BATTERY)
    val cur = _batteryState.value
    _batteryState.value = cur.copy(
      isCharging = true,
      percentage = pct,
      isLow = false,
      pluggedType = pluggedType,
      isLowAlert = false,
      isFullAlert = false,
      isAlertActive = true,
      lastEventTime = System.currentTimeMillis()
    )
    if (context != null) {
      sampleLiveBatteryTelemetry(context)
      startBatteryLiveTicker(context)
    }
    _activeCard.value = IslandActiveCard.BATTERY
    bumpActivityEvent()

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6500)
      _batteryState.value = _batteryState.value.copy(isAlertActive = false)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showBatteryLowAlert(pct: Int) {
    stopBatteryLiveTicker()
    unsuppressCard(IslandActiveCard.BATTERY)
    val cur = _batteryState.value
    _batteryState.value = cur.copy(
      isCharging = false,
      percentage = pct,
      isLow = true,
      pluggedType = "بطارية منخفضة",
      isLowAlert = true,
      isFullAlert = false,
      isAlertActive = true,
      chargingWatts = 0f,
      currentMa = 0,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY
    bumpActivityEvent()

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      _batteryState.value = _batteryState.value.copy(isLowAlert = false, isAlertActive = false)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showBatteryFullAlert(pct: Int, pluggedType: String) {
    unsuppressCard(IslandActiveCard.BATTERY)
    val cur = _batteryState.value
    _batteryState.value = cur.copy(
      isCharging = true,
      percentage = pct,
      isLow = false,
      pluggedType = pluggedType,
      isLowAlert = false,
      isFullAlert = true,
      isAlertActive = true,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY
    bumpActivityEvent()

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      _batteryState.value = _batteryState.value.copy(isFullAlert = false, isAlertActive = false)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Timer & Stopwatch Controls (Internal + Real Clock App Sync)
  fun startTimer(seconds: Int, title: String = "المؤقت") {
    timerPauseResumeIntent = null
    timerCancelIntent = null
    timerJob?.cancel()
    val targetEndMs = System.currentTimeMillis() + seconds * 1000L
    _timerState.value = TimerState(
      isActive = true,
      isRunning = true,
      remainingSeconds = seconds,
      totalSeconds = seconds.coerceAtLeast(1),
      title = title,
      isStopwatch = false,
      elapsedSeconds = 0,
      targetEndTimeMs = targetEndMs,
      sourcePackage = "",
      notificationKey = ""
    )
    activateCardAndNotify(IslandActiveCard.TIMER)
    launchTimerTicker()
  }

  fun updateExternalTimer(
    key: String,
    pkg: String,
    title: String,
    remainingSeconds: Int,
    targetEndTimeMs: Long,
    isRunning: Boolean,
    isStopwatch: Boolean = false,
    elapsedSeconds: Int = 0,
    pauseResumeIntent: PendingIntent? = null,
    cancelIntent: PendingIntent? = null
  ) {
    timerPauseResumeIntent = pauseResumeIntent ?: timerPauseResumeIntent
    timerCancelIntent = cancelIntent ?: timerCancelIntent

    val existing = _timerState.value
    val sameTimer = existing.isActive && existing.notificationKey == key && existing.isStopwatch == isStopwatch
    val effectiveTotal = if (sameTimer) {
      maxOf(existing.totalSeconds, remainingSeconds.coerceAtLeast(1))
    } else {
      remainingSeconds.coerceAtLeast(1)
    }

    val computedRemaining = if (!isStopwatch && isRunning && targetEndTimeMs > System.currentTimeMillis()) {
      ((targetEndTimeMs - System.currentTimeMillis() + 500L) / 1000L).toInt().coerceAtLeast(0)
    } else {
      remainingSeconds.coerceAtLeast(0)
    }

    val wasActive = existing.isActive && existing.notificationKey == key
    _timerState.value = TimerState(
      isActive = true,
      isRunning = isRunning,
      remainingSeconds = computedRemaining,
      totalSeconds = effectiveTotal,
      title = title.ifBlank { if (isStopwatch) "ساعة الإيقاف" else "مؤقت الساعة" },
      isStopwatch = isStopwatch,
      elapsedSeconds = elapsedSeconds.coerceAtLeast(0),
      targetEndTimeMs = targetEndTimeMs,
      sourcePackage = pkg,
      notificationKey = key
    )

    if (!wasActive) {
      activateCardAndNotify(IslandActiveCard.TIMER)
    }

    if (isRunning) {
      launchTimerTicker()
    } else {
      timerJob?.cancel()
    }
  }

  fun cancelExternalTimer(key: String? = null) {
    val cur = _timerState.value
    if (!cur.isActive) return
    if (key == null || cur.notificationKey == key || (cur.sourcePackage.isNotEmpty() && key.contains(cur.sourcePackage))) {
      timerJob?.cancel()
      timerPauseResumeIntent = null
      timerCancelIntent = null
      _timerState.value = TimerState()
      if (_activeCard.value == IslandActiveCard.TIMER) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  private fun launchTimerTicker() {
    timerJob?.cancel()
    timerJob = scope.launch {
      while (isActive && _timerState.value.isActive && _timerState.value.isRunning) {
        delay(1000)
        val current = _timerState.value
        if (!current.isActive || !current.isRunning) break

        if (current.isStopwatch) {
          _timerState.value = current.copy(elapsedSeconds = current.elapsedSeconds + 1)
        } else {
          val remaining = if (current.targetEndTimeMs > 0L) {
            ((current.targetEndTimeMs - System.currentTimeMillis() + 500L) / 1000L).toInt().coerceAtLeast(0)
          } else {
            (current.remainingSeconds - 1).coerceAtLeast(0)
          }
          _timerState.value = current.copy(remainingSeconds = remaining)
          if (remaining <= 0) {
            _timerState.value = current.copy(isRunning = false, remainingSeconds = 0)
            // If internal timer finished, clear after a short moment; external clock app handles its own alarm notification
            if (current.sourcePackage.isEmpty()) {
              delay(4000)
              if (_timerState.value.remainingSeconds == 0 && _timerState.value.sourcePackage.isEmpty()) {
                cancelTimer()
              }
            }
            break
          }
        }
      }
    }
  }

  fun toggleTimerPause() {
    val cur = _timerState.value
    if (!cur.isActive) return

    val pending = timerPauseResumeIntent
    if (pending != null) {
      try {
        pending.send()
      } catch (e: Exception) {
        Log.e(TAG, "Failed to send timer pause/resume intent", e)
      }
    }

    if (cur.isRunning) {
      timerJob?.cancel()
      _timerState.value = cur.copy(isRunning = false)
    } else if (cur.isStopwatch || cur.remainingSeconds > 0) {
      val newTarget = if (!cur.isStopwatch) System.currentTimeMillis() + cur.remainingSeconds * 1000L else 0L
      _timerState.value = cur.copy(isRunning = true, targetEndTimeMs = newTarget)
      launchTimerTicker()
    }
  }

  fun cancelTimer() {
    val pending = timerCancelIntent
    if (pending != null) {
      try {
        pending.send()
      } catch (e: Exception) {
        Log.e(TAG, "Failed to send timer cancel intent", e)
      }
    }
    timerJob?.cancel()
    timerPauseResumeIntent = null
    timerCancelIntent = null
    _timerState.value = TimerState()
    if (_activeCard.value == IslandActiveCard.TIMER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun isTelephonyRinging(): Boolean = lastTelephonyState == TelephonyManager.CALL_STATE_RINGING
  fun isTelephonyActive(): Boolean = lastTelephonyState == TelephonyManager.CALL_STATE_OFFHOOK

  // Call controls & actual answering / declining
  fun startCall(caller: String = "Incoming Call", number: String = "Mobile", isIncoming: Boolean = true) {
    val currentCall = _callState.value
    val isTelephonyRinging = lastTelephonyState == TelephonyManager.CALL_STATE_RINGING

    // If telephony is actively ringing or current call is already incoming and not explicitly answered,
    // force it to remain incoming to strictly prevent starting the duration timer before answering!
    val effectiveIncoming = if (isTelephonyRinging) {
      true
    } else if (currentCall.isActive && currentCall.isIncoming && !isIncoming) {
      currentCall.isIncoming
    } else {
      isIncoming
    }

    val wasActive = currentCall.isActive
    _callState.value = CallState(
      isActive = true,
      callerName = if (caller.isNotBlank() && caller != "Incoming Call") caller else currentCall.callerName.ifBlank { caller },
      callerNumber = if (number.isNotBlank() && number != "Mobile") number else currentCall.callerNumber.ifBlank { number },
      durationSeconds = if (effectiveIncoming) 0 else currentCall.durationSeconds,
      isIncoming = effectiveIncoming
    )
    activateCardAndNotify(
      card = IslandActiveCard.CALL,
      bumpEvent = !wasActive,
      respectCallPriority = false
    )

    if (effectiveIncoming) {
      // CRITICAL: NEVER run call duration ticker while the call is incoming / ringing!
      callTickerJob?.cancel()
      callTickerJob = null
    } else {
      startCallTicker()
    }
  }

  fun setCallAnswered() {
    val cur = _callState.value
    if (cur.isActive) {
      _callState.value = cur.copy(isIncoming = false, durationSeconds = 0)
      startCallTicker()
    }
  }

  fun answerCall(context: Context) {
    CallManager.answerCall(context)
    setCallAnswered()
  }

  fun declineCall(context: Context) {
    CallManager.declineCall(context)
    endCall()
  }

  private fun startCallTicker() {
    callTickerJob?.cancel()
    callTickerJob = scope.launch {
      while (isActive && _callState.value.isActive && !_callState.value.isIncoming) {
        delay(1000)
        val cur = _callState.value
        if (!cur.isIncoming && cur.isActive) {
          _callState.value = cur.copy(durationSeconds = cur.durationSeconds + 1)
        }
      }
    }
  }

  fun endCall() {
    callTickerJob?.cancel()
    callTickerJob = null
    CallManager.clearNotificationIntents()
    _callState.value = CallState(isActive = false)
    if (_activeCard.value == IslandActiveCard.CALL) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun handleTelephonyState(state: Int) {
    Log.d(TAG, "Telephony state changed: $state")
    lastTelephonyState = state
    when (state) {
      TelephonyManager.CALL_STATE_IDLE -> {
        // Immediate termination on IDLE without any lingering states or delays
        endCall()
      }
      TelephonyManager.CALL_STATE_OFFHOOK -> {
        // Active connected call: user answered the call or placed an active call
        if (_callState.value.isActive) {
          setCallAnswered()
        } else {
          startCall(caller = "Active Call", number = "Mobile", isIncoming = false)
        }
      }
      TelephonyManager.CALL_STATE_RINGING -> {
        // Phone is ringing: strictly incoming, NEVER answered
        startCall(caller = "Incoming Call", number = "Mobile", isIncoming = true)
      }
    }
  }

  private fun registerTelephony(context: Context) {
    try {
      val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
      if (tm != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          tm.registerTelephonyCallback(
            context.mainExecutor,
            object : TelephonyCallback(), TelephonyCallback.CallStateListener {
              override fun onCallStateChanged(state: Int) {
                handleTelephonyState(state)
              }
            }
          )
        } else {
          @Suppress("DEPRECATION")
          tm.listen(
            object : PhoneStateListener() {
              @Deprecated("Deprecated in Java")
              override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleTelephonyState(state)
              }
            },
            PhoneStateListener.LISTEN_CALL_STATE
          )
        }
      }
    } catch (e: SecurityException) {
      Log.w(TAG, "TelephonyManager permission not granted, listening via broadcast", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering TelephonyManager callback", e)
    }

    try {
      val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          val stateStr = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
          when (stateStr) {
            TelephonyManager.EXTRA_STATE_IDLE -> handleTelephonyState(TelephonyManager.CALL_STATE_IDLE)
            TelephonyManager.EXTRA_STATE_OFFHOOK -> handleTelephonyState(TelephonyManager.CALL_STATE_OFFHOOK)
            TelephonyManager.EXTRA_STATE_RINGING -> {
              val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Mobile"
              startCall(caller = "Incoming Call", number = incomingNumber, isIncoming = true)
            }
          }
        }
      }
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.w(TAG, "Error registering phone state broadcast receiver", e)
    }
  }

  // Notification Event & App Launch
  fun postNotificationEvent(
    appName: String,
    title: String,
    text: String,
    pkg: String = "",
    contentIntent: PendingIntent? = null
  ) {
    unsuppressCard(IslandActiveCard.NOTIFICATION)
    notifContentIntent = contentIntent
    val event = NotificationEvent(
      id = System.currentTimeMillis(),
      packageName = pkg,
      appName = appName,
      title = title,
      text = text,
      timestamp = System.currentTimeMillis()
    )
    _activeNotification.value = event
    _activeCard.value = IslandActiveCard.NOTIFICATION
    bumpActivityEvent()

    notificationExpireJob?.cancel()
    notificationExpireJob = scope.launch {
      delay(4500)
      if (_activeNotification.value?.id == event.id) {
        _activeNotification.value = null
        notifContentIntent = null
        if (_activeCard.value == IslandActiveCard.NOTIFICATION) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  fun openActiveNotificationApp(context: Context) {
    val pkg = _activeNotification.value?.packageName
    openSourceApp(context, pkg, notifContentIntent)
  }

  fun openSourceApp(context: Context, packageName: String?, pendingIntent: PendingIntent? = null) {
    if (pendingIntent != null) {
      try {
        pendingIntent.send()
        return
      } catch (e: Exception) {
        Log.w(TAG, "PendingIntent launch failed, falling back to package launch", e)
      }
    }
    if (!packageName.isNullOrBlank()) {
      try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
          launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(launchIntent)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Failed to launch app $packageName", e)
      }
    }
  }

  // Bluetooth Event & Real Receivers
  fun showBluetoothConnected(deviceName: String = "Bluetooth Audio", batteryPct: Int = -1) {
    unsuppressCard(IslandActiveCard.BLUETOOTH)
    _bluetoothState.value = BluetoothState(
      isConnected = true,
      isAlertActive = true,
      deviceName = deviceName,
      batteryPct = batteryPct,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BLUETOOTH
    bumpActivityEvent()

    bluetoothExpireJob?.cancel()
    bluetoothExpireJob = scope.launch {
      delay(5500)
      _bluetoothState.value = _bluetoothState.value.copy(isAlertActive = false)
      if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  private fun registerBluetoothAndHeadsetReceiver(context: Context) {
    refreshConnectedBluetoothDevices(context)

    val filter = IntentFilter().apply {
      addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
      addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
      addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
      addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
      addAction("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
      addAction(Intent.ACTION_HEADSET_PLUG)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        val appCtx = ctx ?: context
        when (action) {
          "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED" -> {
            val device: BluetoothDevice? = extractBluetoothDevice(intent)
            val batteryPct = intent.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
            if (batteryPct in 0..100) {
              val devName = resolveBluetoothDeviceName(appCtx, device)
              val cur = _bluetoothState.value
              if (!cur.isConnected || activeBluetoothAddress == null || device?.address == activeBluetoothAddress || devName == cur.deviceName) {
                activeBluetoothAddress = device?.address ?: activeBluetoothAddress
                val wasUnknown = cur.batteryPct < 0 && !cur.isAlertActive
                _bluetoothState.value = cur.copy(
                  isConnected = true,
                  deviceName = if (devName != "جهاز بلوتوث") devName else cur.deviceName.ifBlank { devName },
                  batteryPct = batteryPct,
                  isAlertActive = cur.isAlertActive || wasUnknown,
                  timestamp = if (wasUnknown) System.currentTimeMillis() else cur.timestamp
                )
              }
            }
          }
          BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
            activeBluetoothAddress = null
            bluetoothExpireJob?.cancel()
            _bluetoothState.value = BluetoothState()
            if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
              _activeCard.value = IslandActiveCard.MUSIC
            }
          }
          Intent.ACTION_HEADSET_PLUG -> {
            if (isInitialStickyBroadcast) return
            val state = intent.getIntExtra("state", 0)
            if (state == 1) {
              val hasMic = intent.getIntExtra("microphone", 0) == 1
              showBluetoothConnected(
                deviceName = if (hasMic) "سماعة سلكية مع مايك" else "سماعة سلكية",
                batteryPct = -1
              )
            } else if (state == 0) {
              bluetoothExpireJob?.cancel()
              _bluetoothState.value = BluetoothState()
              if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
                _activeCard.value = IslandActiveCard.MUSIC
              }
            }
          }
          BluetoothDevice.ACTION_ACL_CONNECTED,
          BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
          BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
            if (action != BluetoothDevice.ACTION_ACL_CONNECTED) {
              val connState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
              if (connState == BluetoothProfile.STATE_DISCONNECTED) {
                activeBluetoothAddress = null
                bluetoothExpireJob?.cancel()
                _bluetoothState.value = BluetoothState()
                if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
                  _activeCard.value = IslandActiveCard.MUSIC
                }
                return
              }
              if (connState != BluetoothProfile.STATE_CONNECTED) return
            }

            val device = extractBluetoothDevice(intent) ?: return
            activeBluetoothAddress = device.address
            val name = resolveBluetoothDeviceName(appCtx, device)
            val batteryPct = resolveBluetoothBatteryLevel(appCtx, device, intent)

            val btEnabled = CapsuleSettingsManager.getInstance(appCtx).settings.value.enableBluetoothAlerts
            if (btEnabled) {
              showBluetoothConnected(deviceName = name, batteryPct = batteryPct)
            } else {
              _bluetoothState.value = BluetoothState(
                isConnected = true,
                isAlertActive = false,
                deviceName = name,
                batteryPct = batteryPct,
                timestamp = System.currentTimeMillis()
              )
            }
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering Bluetooth/Headset receiver", e)
    }
  }

  private fun extractBluetoothDevice(intent: Intent): BluetoothDevice? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
    } else {
      @Suppress("DEPRECATION")
      intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
    }
  }

  private fun hasBluetoothConnectPermission(context: Context): Boolean {
    return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
      ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
  }

  @SuppressLint("MissingPermission")
  private fun resolveBluetoothDeviceName(context: Context, device: BluetoothDevice?): String {
    if (device == null || !hasBluetoothConnectPermission(context)) return "جهاز بلوتوث"
    return try {
      device.name?.takeIf { it.isNotBlank() } ?: "جهاز بلوتوث"
    } catch (_: SecurityException) {
      "جهاز بلوتوث"
    }
  }

  private fun resolveBluetoothBatteryLevel(context: Context, device: BluetoothDevice?, intent: Intent? = null): Int {
    val extraPct = intent?.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1) ?: -1
    if (extraPct in 0..100) return extraPct
    if (device == null || !hasBluetoothConnectPermission(context)) return -1
    return try {
      val method = device.javaClass.getMethod("getBatteryLevel")
      val level = (method.invoke(device) as? Int) ?: -1
      if (level in 0..100) level else -1
    } catch (_: Exception) {
      -1
    }
  }

  @SuppressLint("MissingPermission")
  fun refreshConnectedBluetoothDevices(context: Context) {
    if (!hasBluetoothConnectPermission(context)) return
    try {
      val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
      val adapter: BluetoothAdapter = bm?.adapter ?: return
      if (!adapter.isEnabled) {
        if (_bluetoothState.value.isConnected) {
          _bluetoothState.value = BluetoothState()
        }
        return
      }

      // Check bonded devices for an active ACL link + battery level
      val connectedBonded = adapter.bondedDevices?.firstOrNull { dev ->
        try {
          val m = dev.javaClass.getMethod("isConnected")
          (m.invoke(dev) as? Boolean) == true
        } catch (_: Exception) {
          false
        }
      }
      if (connectedBonded != null) {
        activeBluetoothAddress = connectedBonded.address
        val devName = resolveBluetoothDeviceName(context, connectedBonded)
        val pct = resolveBluetoothBatteryLevel(context, connectedBonded)
        _bluetoothState.value = _bluetoothState.value.copy(
          isConnected = true,
          deviceName = devName,
          batteryPct = if (pct in 0..100) pct else _bluetoothState.value.batteryPct
        )
        return
      }

      // Query A2DP & Headset profile proxies asynchronously for active audio headsets
      val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
          try {
            val activeDev = proxy?.connectedDevices?.firstOrNull()
            if (activeDev != null) {
              activeBluetoothAddress = activeDev.address
              val devName = resolveBluetoothDeviceName(context, activeDev)
              val pct = resolveBluetoothBatteryLevel(context, activeDev)
              _bluetoothState.value = _bluetoothState.value.copy(
                isConnected = true,
                deviceName = devName,
                batteryPct = if (pct in 0..100) pct else _bluetoothState.value.batteryPct
              )
            }
          } catch (_: Exception) {
          } finally {
            try {
              adapter.closeProfileProxy(profile, proxy)
            } catch (_: Exception) {}
          }
        }
        override fun onServiceDisconnected(profile: Int) {}
      }
      adapter.getProfileProxy(context.applicationContext, listener, BluetoothProfile.A2DP)
      adapter.getProfileProxy(context.applicationContext, listener, BluetoothProfile.HEADSET)
    } catch (e: Exception) {
      Log.w(TAG, "Unable to query connected Bluetooth devices", e)
    }
  }

  // Real Download / Install Progress
  fun updateDownloadProgress(
    key: String,
    appName: String,
    title: String,
    progress: Int,
    max: Int,
    indeterminate: Boolean,
    pkg: String = "",
    contentIntent: PendingIntent? = null
  ) {
    if (pkg.isNotBlank()) downloadPackageName = pkg
    if (contentIntent != null) downloadContentIntent = contentIntent

    val existing = _downloadState.value
    val isNew = !existing.isActive || existing.key != key
    _downloadState.value = DownloadState(
      isActive = true,
      key = key,
      appName = appName,
      title = title,
      progress = progress,
      max = max.coerceAtLeast(1),
      isIndeterminate = indeterminate,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !isCardSuppressed(IslandActiveCard.DOWNLOAD)) {
      if (!_callState.value.isActive && !_flashlightState.value.isOn) {
        _activeCard.value = IslandActiveCard.DOWNLOAD
      }
      bumpActivityEvent()
    }

    downloadExpireJob?.cancel()
    downloadExpireJob = scope.launch {
      delay(25000)
      if (_downloadState.value.key == key && System.currentTimeMillis() - _downloadState.value.timestamp >= 25000L) {
        clearDownloadProgress(key)
      }
    }
  }

  fun openDownloadApp(context: Context) {
    openSourceApp(context, downloadPackageName, downloadContentIntent)
  }

  fun clearDownloadProgress(key: String? = null) {
    val cur = _downloadState.value
    if (!cur.isActive) return
    if (key == null || cur.key == key) {
      downloadExpireJob?.cancel()
      downloadContentIntent = null
      downloadPackageName = ""
      _downloadState.value = DownloadState()
      if (_activeCard.value == IslandActiveCard.DOWNLOAD) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Live Navigation (Google Maps / Waze notifications without API keys)
  fun updateNavigation(
    key: String,
    pkg: String,
    appName: String,
    instruction: String,
    distanceOrStreet: String,
    etaText: String,
    directionIcon: Bitmap? = null,
    contentIntent: PendingIntent? = null,
    stopIntent: PendingIntent? = null
  ) {
    if (contentIntent != null) navContentIntent = contentIntent
    if (stopIntent != null) navStopIntent = stopIntent
    val isNew = !_navigationState.value.isActive || _navigationState.value.key != key

    _navigationState.value = NavigationState(
      isActive = true,
      key = key,
      packageName = pkg,
      appName = appName,
      instruction = instruction.ifBlank { "الملاحة جارية" },
      distanceOrStreet = distanceOrStreet,
      etaText = etaText,
      directionIcon = directionIcon ?: _navigationState.value.directionIcon,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !isCardSuppressed(IslandActiveCard.NAVIGATION)) {
      if (!_callState.value.isActive) {
        _activeCard.value = IslandActiveCard.NAVIGATION
      }
      bumpActivityEvent()
    }
  }

  fun openNavigationApp(context: Context) {
    openSourceApp(context, _navigationState.value.packageName.ifBlank { "com.google.android.apps.maps" }, navContentIntent)
  }

  fun stopNavigation() {
    val stopPi = navStopIntent
    if (stopPi != null) {
      try {
        stopPi.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending navigation stop intent", e)
      }
    }
    clearNavigation()
  }

  fun clearNavigation(key: String? = null) {
    val cur = _navigationState.value
    if (!cur.isActive) return
    if (key == null || cur.key == key) {
      navContentIntent = null
      navStopIntent = null
      _navigationState.value = NavigationState()
      if (_activeCard.value == IslandActiveCard.NAVIGATION) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Network, Wi-Fi, Airplane Mode & Hotspot Monitor
  private fun registerNetworkAndConnectivityMonitors(context: Context) {
    try {
      val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
      if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        val initCaps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        lastNetworkType = when {
          initCaps == null -> NetworkEventType.NO_INTERNET
          initCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkEventType.WIFI_CONNECTED
          initCaps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkEventType.MOBILE_DATA
          else -> lastNetworkType
        }

        val callback = object : ConnectivityManager.NetworkCallback() {
          override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            super.onCapabilitiesChanged(network, caps)
            networkLostCheckJob?.cancel()
            val detected = when {
              caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkEventType.WIFI_CONNECTED
              caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkEventType.MOBILE_DATA
              else -> return
            }
            if (detected != lastNetworkType) {
              lastNetworkType = detected
              val enabled = CapsuleSettingsManager.getInstance(context).settings.value.enableNetworkAlerts
              if (enabled) {
                when (detected) {
                  NetworkEventType.WIFI_CONNECTED -> {
                    val ssidName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                      val wifiInfo = caps.transportInfo as? WifiInfo
                      val raw = wifiInfo?.ssid?.removeSurrounding("\"")
                      if (!raw.isNullOrBlank() && !raw.equals("<unknown ssid>", ignoreCase = true)) raw else null
                    } else null
                    showNetworkAlert(
                      type = NetworkEventType.WIFI_CONNECTED,
                      title = ssidName ?: "متصل بشبكة Wi-Fi",
                      subtitle = "تم الاتصال بالشبكة اللاسلكية"
                    )
                  }
                  NetworkEventType.MOBILE_DATA -> {
                    showNetworkAlert(
                      type = NetworkEventType.MOBILE_DATA,
                      title = "بيانات الهاتف",
                      subtitle = "تم التحويل إلى شبكة الجوال"
                    )
                  }
                  else -> {}
                }
              }
            }
          }

          override fun onLost(network: Network) {
            super.onLost(network)
            networkLostCheckJob?.cancel()
            networkLostCheckJob = scope.launch {
              delay(800)
              val active = cm.activeNetwork
              val isAirplane = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON,
                0
              ) != 0
              if (active == null && !isAirplane && lastNetworkType != NetworkEventType.NO_INTERNET) {
                lastNetworkType = NetworkEventType.NO_INTERNET
                if (CapsuleSettingsManager.getInstance(context).settings.value.enableNetworkAlerts) {
                  showNetworkAlert(
                    type = NetworkEventType.NO_INTERNET,
                    title = "انقطع الاتصال",
                    subtitle = "لا يتوفر اتصال بالإنترنت"
                  )
                }
              }
            }
          }
        }
        cm.registerDefaultNetworkCallback(callback)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Error registering ConnectivityManager NetworkCallback", e)
    }

    try {
      val filter = IntentFilter().apply {
        addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
      }
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          val act = intent?.action ?: return
          val c = ctx ?: context
          if (!CapsuleSettingsManager.getInstance(c).settings.value.enableNetworkAlerts) return

          when (act) {
            Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
              if (isInitialStickyBroadcast) return
              val enabled = intent.getBooleanExtra("state", false)
              showNetworkAlert(
                type = if (enabled) NetworkEventType.AIRPLANE_ON else NetworkEventType.AIRPLANE_OFF,
                title = if (enabled) "وضع الطيران مفعّل" else "تم إيقاف وضع الطيران",
                subtitle = if (enabled) "تم إيقاف جميع الشبكات" else "جارٍ استعادة الاتصال"
              )
            }
            "android.net.wifi.WIFI_AP_STATE_CHANGED" -> {
              val state = intent.getIntExtra("wifi_state", -1)
              val enabled = when (state) {
                13 -> true // WIFI_AP_STATE_ENABLED
                11 -> false // WIFI_AP_STATE_DISABLED
                else -> return
              }
              if (isInitialStickyBroadcast) {
                lastHotspotEnabled = enabled
                return
              }
              if (lastHotspotEnabled != enabled) {
                lastHotspotEnabled = enabled
                showNetworkAlert(
                  type = if (enabled) NetworkEventType.HOTSPOT_ON else NetworkEventType.HOTSPOT_OFF,
                  title = if (enabled) "نقطة الاتصال مفعّلة" else "تم إيقاف نقطة الاتصال",
                  subtitle = if (enabled) "مشاركة Wi-Fi نشطة الآن" else "توقفت مشاركة الإنترنت"
                )
              }
            }
          }
        }
      }
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.w(TAG, "Error registering Airplane/Hotspot receiver", e)
    }
  }

  fun showNetworkAlert(type: NetworkEventType, title: String, subtitle: String) {
    unsuppressCard(IslandActiveCard.NETWORK)
    _networkState.value = NetworkState(
      isActive = true,
      type = type,
      title = title,
      subtitle = subtitle,
      timestamp = System.currentTimeMillis()
    )
    if (!_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.NETWORK
    }
    bumpActivityEvent()

    networkExpireJob?.cancel()
    networkExpireJob = scope.launch {
      delay(4000)
      _networkState.value = _networkState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.NETWORK) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun notifyHotspotFromSystemNotification(enabled: Boolean) {
    if (lastHotspotEnabled == enabled) return
    lastHotspotEnabled = enabled
    showNetworkAlert(
      type = if (enabled) NetworkEventType.HOTSPOT_ON else NetworkEventType.HOTSPOT_OFF,
      title = if (enabled) "نقطة الاتصال مفعّلة" else "تم إيقاف نقطة الاتصال",
      subtitle = if (enabled) "مشاركة Wi-Fi نشطة الآن" else "توقفت مشاركة الإنترنت"
    )
  }

  // Real Camera, Microphone & Voice Recorder Privacy Monitor
  private fun initPrivacyMonitors(context: Context) {
    try {
      val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
      if (cm != null) {
        availabilityCallback = object : CameraManager.AvailabilityCallback() {
          override fun onCameraAvailable(cameraId: String) {
            super.onCameraAvailable(cameraId)
            unavailableCameras.remove(cameraId)
            updateCameraUsageState()
          }

          override fun onCameraUnavailable(cameraId: String) {
            super.onCameraUnavailable(cameraId)
            val torchRecentlyToggled = System.currentTimeMillis() - lastTorchToggleTimeMs < 1500L
            val isFlashCamera = flashCameraId == null || cameraId == flashCameraId
            if ((_flashlightState.value.isOn || torchRecentlyToggled) && isFlashCamera) {
              return
            }
            unavailableCameras.add(cameraId)
            updateCameraUsageState()
          }
        }
        cm.registerAvailabilityCallback(availabilityCallback!!, null)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Could not register Camera AvailabilityCallback", e)
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      try {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null) {
          val initialMicActive = am.activeRecordingConfigurations.isNotEmpty()
          _privacyState.value = _privacyState.value.copy(isMicInUse = initialMicActive)

          audioRecordingCallback = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
              super.onRecordingConfigChanged(configs)
              val active = !configs.isNullOrEmpty()
              _privacyState.value = _privacyState.value.copy(
                isMicInUse = active,
                timestamp = System.currentTimeMillis()
              )
            }
          }
          am.registerAudioRecordingCallback(audioRecordingCallback!!, null)
        }
      } catch (e: Exception) {
        Log.w(TAG, "Could not register AudioRecordingCallback", e)
      }
    }
  }

  private fun updateCameraUsageState() {
    val active = unavailableCameras.isNotEmpty()
    _privacyState.value = _privacyState.value.copy(
      isCameraInUse = active,
      timestamp = System.currentTimeMillis()
    )
  }

  fun updateVoiceRecorder(
    key: String,
    pkg: String,
    appName: String,
    title: String,
    elapsedSeconds: Int,
    isRunning: Boolean,
    pauseIntent: PendingIntent? = null,
    stopIntent: PendingIntent? = null
  ) {
    if (pauseIntent != null) recorderPauseIntent = pauseIntent
    if (stopIntent != null) recorderStopIntent = stopIntent
    val isNew = !_privacyState.value.isVoiceRecorderActive || _privacyState.value.recorderKey != key

    _privacyState.value = _privacyState.value.copy(
      isVoiceRecorderActive = true,
      recorderKey = key,
      recorderPackage = pkg,
      recorderAppName = appName,
      recorderTitle = title.ifBlank { "تسجيل صوتي" },
      elapsedSeconds = elapsedSeconds.coerceAtLeast(0),
      isRecorderRunning = isRunning,
      timestamp = System.currentTimeMillis()
    )
    if (isNew && !isCardSuppressed(IslandActiveCard.PRIVACY)) {
      if (!_callState.value.isActive) {
        _activeCard.value = IslandActiveCard.PRIVACY
      }
      bumpActivityEvent()
    }

    if (isRunning) {
      launchRecorderTicker()
    } else {
      recorderTickerJob?.cancel()
    }
  }

  private fun launchRecorderTicker() {
    recorderTickerJob?.cancel()
    recorderTickerJob = scope.launch {
      while (isActive && _privacyState.value.isVoiceRecorderActive && _privacyState.value.isRecorderRunning) {
        delay(1000)
        val cur = _privacyState.value
        if (!cur.isVoiceRecorderActive || !cur.isRecorderRunning) break
        _privacyState.value = cur.copy(elapsedSeconds = cur.elapsedSeconds + 1)
      }
    }
  }

  fun toggleVoiceRecorderPause() {
    val cur = _privacyState.value
    if (!cur.isVoiceRecorderActive) return
    recorderPauseIntent?.let {
      try {
        it.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending recorder pause intent", e)
      }
    }
    if (cur.isRecorderRunning) {
      recorderTickerJob?.cancel()
      _privacyState.value = cur.copy(isRecorderRunning = false)
    } else {
      _privacyState.value = cur.copy(isRecorderRunning = true)
      launchRecorderTicker()
    }
  }

  fun stopVoiceRecorder() {
    recorderStopIntent?.let {
      try {
        it.send()
      } catch (e: Exception) {
        Log.w(TAG, "Failed sending recorder stop intent", e)
      }
    }
    clearVoiceRecorder()
  }

  fun clearVoiceRecorder(key: String? = null) {
    val cur = _privacyState.value
    if (!cur.isVoiceRecorderActive) return
    if (key == null || cur.recorderKey == key) {
      recorderTickerJob?.cancel()
      recorderPauseIntent = null
      recorderStopIntent = null
      _privacyState.value = cur.copy(
        isVoiceRecorderActive = false,
        recorderKey = "",
        recorderPackage = "",
        recorderAppName = "",
        recorderTitle = "",
        elapsedSeconds = 0,
        isRecorderRunning = false
      )
      if (_activeCard.value == IslandActiveCard.PRIVACY && !cur.isCameraInUse && !cur.isMicInUse) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Camera Torch / Flashlight implementation
  private fun initFlashlight(context: Context) {
    try {
      val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
      cameraManager = cm
      if (cm != null) {
        flashCameraId = findFlashCameraId(cm)
        torchCallback = object : CameraManager.TorchCallback() {
          override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            super.onTorchModeChanged(cameraId, enabled)
            if (cameraId == flashCameraId || flashCameraId == null) {
              val wasOn = _flashlightState.value.isOn
              lastTorchToggleTimeMs = System.currentTimeMillis()
              flashCameraId = cameraId
              unavailableCameras.remove(cameraId)
              updateCameraUsageState()
              _flashlightState.value = FlashlightState(isOn = enabled)
              if (enabled) {
                unsuppressCard(IslandActiveCard.FLASHLIGHT)
                if (!wasOn) bumpActivityEvent()
                _activeCard.value = IslandActiveCard.FLASHLIGHT
              } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
                _activeCard.value = IslandActiveCard.MUSIC
              }
            }
          }
        }
        cm.registerTorchCallback(torchCallback!!, null)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing camera torch callback", e)
    }
  }

  private fun findFlashCameraId(cm: CameraManager): String? {
    try {
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val facing = chars.get(CameraCharacteristics.LENS_FACING)
        if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
          return id
        }
      }
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        if (chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
          return id
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error finding flash camera id", e)
    }
    return cm.cameraIdList.firstOrNull()
  }

  fun toggleFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    val targetMode = !_flashlightState.value.isOn
    lastTorchToggleTimeMs = System.currentTimeMillis()
    try {
      cm?.setTorchMode(id, targetMode)
      unavailableCameras.remove(id)
      flashCameraId?.let { unavailableCameras.remove(it) }
      updateCameraUsageState()
      _flashlightState.value = FlashlightState(isOn = targetMode)
      if (targetMode) {
        activateCardAndNotify(IslandActiveCard.FLASHLIGHT, context, bumpEvent = true, respectCallPriority = false)
      } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error toggling torch on camera id $id", e)
      unavailableCameras.remove(id)
      updateCameraUsageState()
      _flashlightState.value = FlashlightState(isOn = false)
      if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun turnOffFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    lastTorchToggleTimeMs = System.currentTimeMillis()
    try {
      cm?.setTorchMode(id, false)
    } catch (e: Exception) {
      Log.e(TAG, "Error turning off torch", e)
    }
    unavailableCameras.remove(id)
    flashCameraId?.let { unavailableCameras.remove(it) }
    updateCameraUsageState()
    _flashlightState.value = FlashlightState(isOn = false)
    if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun turnOnFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    val wasOn = _flashlightState.value.isOn
    lastTorchToggleTimeMs = System.currentTimeMillis()
    try {
      cm?.setTorchMode(id, true)
    } catch (e: Exception) {
      Log.e(TAG, "Error turning on torch", e)
    }
    unavailableCameras.remove(id)
    updateCameraUsageState()
    _flashlightState.value = FlashlightState(isOn = true)
    activateCardAndNotify(IslandActiveCard.FLASHLIGHT, context, bumpEvent = !wasOn, respectCallPriority = false)
  }

  // Sound Mode Detection & Control (Ring / Vibrate / Silent / Muted DND)
  fun detectRealSoundMode(context: Context): SoundMode {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null) {
      val filter = nm.currentInterruptionFilter
      if (filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
        filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
      ) {
        return SoundMode.MUTED_DND
      }
    }

    return when (am?.ringerMode) {
      AudioManager.RINGER_MODE_VIBRATE -> SoundMode.VIBRATE
      AudioManager.RINGER_MODE_SILENT -> SoundMode.SILENT
      AudioManager.RINGER_MODE_NORMAL -> {
        val ringVol = am.getStreamVolume(AudioManager.STREAM_RING)
        if (ringVol == 0) SoundMode.SILENT else SoundMode.RING
      }
      else -> SoundMode.RING
    }
  }

  private fun registerRingerReceiver(context: Context) {
    _currentSoundMode.value = detectRealSoundMode(context)
    val amInit = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    lastMediaVolume = amInit?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1

    val filter = IntentFilter().apply {
      addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
      }
      addAction("android.media.VOLUME_CHANGED_ACTION")
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val act = intent?.action ?: return
        val c = ctx ?: context

        if (act == "android.media.VOLUME_CHANGED_ACTION") {
          val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
          if (streamType == AudioManager.STREAM_MUSIC) {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val newVol = intent.getIntExtra(
              "android.media.EXTRA_VOLUME_STREAM_VALUE",
              am.getStreamVolume(AudioManager.STREAM_MUSIC)
            ).coerceIn(0, maxVol)
            val volEnabled = CapsuleSettingsManager.getInstance(c).settings.value.enableVolumeAlerts
            if (volEnabled && !isInitialStickyBroadcast && newVol != lastMediaVolume) {
              lastMediaVolume = newVol
              showVolumeAlert(newVol, maxVol)
            } else {
              lastMediaVolume = newVol
            }
            return
          }
          if (streamType != AudioManager.STREAM_RING) return
        }

        val detected = detectRealSoundMode(c)
        val previous = _currentSoundMode.value
        _currentSoundMode.value = detected

        val ringerEnabled = CapsuleSettingsManager.getInstance(c).settings.value.enableRingerAlerts
        if (ringerEnabled && !isInitialStickyBroadcast && (detected != previous || act != "android.media.VOLUME_CHANGED_ACTION")) {
          showRingerMode(detected)
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering ringer receiver", e)
    }
  }

  fun showVolumeAlert(volume: Int, maxVolume: Int) {
    unsuppressCard(IslandActiveCard.VOLUME)
    val safeMax = maxVolume.coerceAtLeast(1)
    val safeVol = volume.coerceIn(0, safeMax)
    _volumeState.value = VolumeState(
      isActive = true,
      volume = safeVol,
      maxVolume = safeMax,
      isMuted = safeVol == 0,
      timestamp = System.currentTimeMillis()
    )
    if (!_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.VOLUME
    }
    bumpActivityEvent()

    volumeExpireJob?.cancel()
    volumeExpireJob = scope.launch {
      delay(2200)
      _volumeState.value = _volumeState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.VOLUME) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun setMediaVolume(context: Context, volume: Int) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    val safeVol = volume.coerceIn(0, maxVol)
    try {
      am.setStreamVolume(AudioManager.STREAM_MUSIC, safeVol, 0)
      lastMediaVolume = safeVol
      showVolumeAlert(safeVol, maxVol)
    } catch (_: Exception) {}
  }

  fun toggleMuteMedia(context: Context) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
    val target = if (cur > 0) 0 else (maxVol / 2).coerceAtLeast(1)
    setMediaVolume(context, target)
  }

  fun setSoundMode(context: Context, mode: SoundMode) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    val policyGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || (nm?.isNotificationPolicyAccessGranted == true)

    try {
      when (mode) {
        SoundMode.RING -> {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && policyGranted) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_NORMAL
          if (am.getStreamVolume(AudioManager.STREAM_RING) == 0) {
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_RING)
            am.setStreamVolume(AudioManager.STREAM_RING, (maxVol / 2).coerceAtLeast(1), 0)
          }
        }
        SoundMode.VIBRATE -> {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && policyGranted) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
        }
        SoundMode.SILENT -> {
          if (!policyGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            openNotificationPolicySettings(context)
            return
          }
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
          }
          am.ringerMode = AudioManager.RINGER_MODE_SILENT
        }
        SoundMode.MUTED_DND -> {
          if (!policyGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            openNotificationPolicySettings(context)
            return
          }
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            nm?.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
          }
        }
      }
      val actual = detectRealSoundMode(context)
      _currentSoundMode.value = actual
      showRingerMode(actual)
    } catch (e: SecurityException) {
      Log.w(TAG, "Policy access required for silent/DND", e)
      openNotificationPolicySettings(context)
    } catch (e: Exception) {
      Log.e(TAG, "Error setting sound mode", e)
    }
  }

  fun cycleSoundMode(context: Context) {
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    val policyGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || (nm?.isNotificationPolicyAccessGranted == true)
    val nextMode = when (_currentSoundMode.value) {
      SoundMode.RING -> SoundMode.VIBRATE
      SoundMode.VIBRATE -> if (policyGranted) SoundMode.SILENT else SoundMode.RING
      SoundMode.SILENT -> SoundMode.MUTED_DND
      SoundMode.MUTED_DND -> SoundMode.RING
    }
    setSoundMode(context, nextMode)
  }

  private fun openNotificationPolicySettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      try {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
      } catch (e: Exception) {
        Log.e(TAG, "Could not open DND policy settings", e)
      }
    }
  }

  fun showRingerMode(mode: SoundMode) {
    _currentSoundMode.value = mode
    unsuppressCard(IslandActiveCard.RINGER)
    _ringerState.value = RingerState(
      isActive = true,
      mode = mode,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.RINGER
    bumpActivityEvent()

    ringerExpireJob?.cancel()
    ringerExpireJob = scope.launch {
      delay(3500)
      _ringerState.value = _ringerState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.RINGER) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun showRingerMode(isSilent: Boolean) {
    showRingerMode(if (isSilent) SoundMode.SILENT else SoundMode.RING)
  }

  fun dismissRinger() {
    ringerExpireJob?.cancel()
    _ringerState.value = _ringerState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.RINGER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun dismissVolumeAlert() {
    volumeExpireJob?.cancel()
    _volumeState.value = _volumeState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.VOLUME) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun dismissNetworkAlert() {
    networkExpireJob?.cancel()
    _networkState.value = _networkState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.NETWORK) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun clearAllTransientStates() {
    timerJob?.cancel()
    sleepTimerJob?.cancel()
    focusTimerJob?.cancel()
    weatherAutoJob?.cancel()
    weatherAlertExpireJob?.cancel()
    footballAlertExpireJob?.cancel()
    deliveryExpireJob?.cancel()
    stepsAlertExpireJob?.cancel()
    callTickerJob?.cancel()
    recorderTickerJob?.cancel()
    notificationExpireJob?.cancel()
    batteryExpireJob?.cancel()
    ringerExpireJob?.cancel()
    bluetoothExpireJob?.cancel()
    downloadExpireJob?.cancel()
    networkExpireJob?.cancel()
    volumeExpireJob?.cancel()
    prayerAlertExpireJob?.cancel()
    stopBatteryLiveTicker()
    unavailableCameras.clear()
    _flashlightState.value = FlashlightState(isOn = false)
    _timerState.value = TimerState()
    _sleepTimerState.value = SleepTimerState()
    _focusState.value = FocusState()
    _deliveryState.value = DeliveryState()
    _footballState.value = _footballState.value.copy(isAlertActive = false, activeEvent = null)
    _prayerState.value = _prayerState.value.copy(isAlertActive = false)
    deliveryContentIntent = null
    _compassState.value = _compassState.value.copy(isActive = false)
    compassSensorManager?.stopListening()
    _weatherState.value = _weatherState.value.copy(isAlertActive = false)
    _stepsState.value = _stepsState.value.copy(isAlertActive = false)
    _callState.value = CallState()
    _batteryState.value = _batteryState.value.copy(isLowAlert = false, isFullAlert = false, isAlertActive = false)
    _bluetoothState.value = _bluetoothState.value.copy(isAlertActive = false)
    _ringerState.value = _ringerState.value.copy(isActive = false)
    _volumeState.value = _volumeState.value.copy(isActive = false)
    _networkState.value = _networkState.value.copy(isActive = false)
    _downloadState.value = DownloadState()
    _navigationState.value = NavigationState()
    _privacyState.value = PrivacyState()
    _activeNotification.value = null
    _suppressedCards.value = emptySet()
    _activeCard.value = IslandActiveCard.MUSIC
  }

  // Real Hardware Step Counter & Distance Tracking
  private fun initStepsAndCompass(context: Context) {
    stepCounterManager = StepCounterManager(context) { newState, milestoneHit ->
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      val suppressed = isCardSuppressed(IslandActiveCard.STEPS)
      val currentAlert = _stepsState.value.isAlertActive
      _stepsState.value = newState.copy(isAlertActive = !suppressed && (currentAlert || (milestoneHit && settings.enableStepsCounter)))
      if (!suppressed && milestoneHit && settings.enableStepsCounter && !_callState.value.isActive) {
        _activeCard.value = IslandActiveCard.STEPS
        bumpActivityEvent()
        stepsAlertExpireJob?.cancel()
        stepsAlertExpireJob = scope.launch {
          delay(7000)
          _stepsState.value = _stepsState.value.copy(isAlertActive = false)
        }
      }
    }.also { mgr ->
      _stepsState.value = mgr.currentState()
      if (CapsuleSettingsManager.getInstance(context).settings.value.enableStepsCounter) {
        mgr.startListening()
      }
    }

    compassSensorManager = CompassSensorManager(context) { newCompass ->
      _compassState.value = newCompass
    }
    val qibla = PrayerTimesCalculator.let {
      val (lat, lon, _) = it.resolveCoordinatesForLocation(context, CapsuleSettingsManager.getInstance(context).settings.value)
      it.computeQiblaBearing(lat, lon)
    }
    compassSensorManager?.updateQiblaBearing(qibla)
    _compassState.value = CompassState(
      isActive = false,
      hasSensor = compassSensorManager?.hasCompassSensor() == true,
      qiblaBearingDeg = qibla
    )
  }

  fun refreshStepTracking(context: Context) {
    if (stepCounterManager == null) {
      initStepsAndCompass(context)
    } else {
      val mgr = stepCounterManager ?: return
      _stepsState.value = mgr.currentState()
      if (CapsuleSettingsManager.getInstance(context).settings.value.enableStepsCounter) {
        mgr.startListening()
      } else {
        mgr.stopListening()
      }
    }
  }

  fun toggleStepsPause() {
    val mgr = stepCounterManager ?: return
    val nextPaused = !_stepsState.value.isPaused
    mgr.setPaused(nextPaused)
  }

  fun resetTodaySteps() {
    stepCounterManager?.resetToday()
  }

  fun cycleStepsGoal(): Int {
    return stepCounterManager?.cycleDailyGoal() ?: _stepsState.value.dailyGoal
  }

  fun showStepsCard(context: Context) {
    refreshStepTracking(context)
    unsuppressCard(IslandActiveCard.STEPS)
    _stepsState.value = _stepsState.value.copy(
      isAlertActive = true,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.STEPS
    bumpActivityEvent()
    stepsAlertExpireJob?.cancel()
    stepsAlertExpireJob = scope.launch {
      delay(8000)
      _stepsState.value = _stepsState.value.copy(isAlertActive = false)
      if (_activeCard.value == IslandActiveCard.STEPS &&
        !CapsuleSettingsManager.getInstance(context).settings.value.pinStepsInCapsule
      ) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Live Weather with Auto Refresh (Open-Meteo HTTPS)
  private fun startWeatherAutoUpdater(context: Context) {
    weatherAutoJob?.cancel()
    weatherAutoJob = scope.launch {
      while (isActive) {
        val settings = CapsuleSettingsManager.getInstance(context).settings.value
        if (settings.enableWeatherAlerts) {
          refreshWeather(context, showAlertBanner = false)
        }
        // Retry frequently (25s) until initial weather succeeds; refresh every 15 mins afterwards
        val nextDelayMs = if (_weatherState.value.isLoaded) 15 * 60_000L else 25_000L
        delay(nextDelayMs)
      }
    }
  }

  fun ensureWeatherFresh(context: Context, staleMs: Long = 10 * 60_000L) {
    val cur = _weatherState.value
    if (cur.isLoading) return
    val isStale = !cur.isLoaded || (System.currentTimeMillis() - cur.lastUpdatedMs > staleMs)
    if (isStale) {
      refreshWeather(context, showAlertBanner = false)
    }
  }

  fun refreshWeather(
    context: Context,
    showAlertBanner: Boolean = false,
    forceRefresh: Boolean = false
  ) {
    val settings = CapsuleSettingsManager.getInstance(context).settings.value
    if (_weatherState.value.isLoading && !forceRefresh) return
    weatherFetchJob?.cancel()
    _weatherState.value = _weatherState.value.copy(isLoading = true, errorMessage = null)

    weatherFetchJob = scope.launch {
      val result = WeatherRepository.fetchLiveWeather(
        context = context,
        explicitCityQuery = settings.weatherCityQuery,
        explicitLat = settings.weatherCityLat,
        explicitLon = settings.weatherCityLon,
        customDisplayAlias = settings.weatherCityDisplayAlias
      )
      result.onSuccess { fetched ->
        if (showAlertBanner) {
          unsuppressCard(IslandActiveCard.WEATHER)
        }
        val latestSettings = CapsuleSettingsManager.getInstance(context).settings.value
        val weatherSuppressed = isCardSuppressed(IslandActiveCard.WEATHER)
        val activateBanner = !weatherSuppressed && (showAlertBanner || fetched.isWarning)
        _weatherState.value = fetched.copy(isAlertActive = activateBanner)
        refreshPrayerTimes(context, showAlertBanner = false)
        if (activateBanner && latestSettings.enableWeatherAlerts && !_callState.value.isActive) {
          _activeCard.value = IslandActiveCard.WEATHER
          bumpActivityEvent()
          weatherAlertExpireJob?.cancel()
          weatherAlertExpireJob = scope.launch {
            delay(8000)
            _weatherState.value = _weatherState.value.copy(isAlertActive = false)
            if (_activeCard.value == IslandActiveCard.WEATHER &&
              !CapsuleSettingsManager.getInstance(context).settings.value.pinWeatherInCapsule
            ) {
              _activeCard.value = IslandActiveCard.MUSIC
            }
          }
        }
      }.onFailure { err ->
        _weatherState.value = _weatherState.value.copy(
          isLoading = false,
          errorMessage = err.message ?: "تعذر تحديث الطقس"
        )
      }
    }
  }

  // Islamic Prayer Times & Kaaba Qibla Synchronization
  private fun startPrayerAutoUpdater(context: Context) {
    prayerAutoJob?.cancel()
    prayerAutoJob = scope.launch {
      while (isActive) {
        val settings = CapsuleSettingsManager.getInstance(context).settings.value
        if (settings.enablePrayerAlerts) {
          refreshPrayerTimes(context, showAlertBanner = false)
        }
        delay(20_000L)
      }
    }
  }

  fun refreshPrayerTimes(context: Context, showAlertBanner: Boolean = false) {
    if (showAlertBanner) {
      unsuppressCard(IslandActiveCard.PRAYER)
    }
    val settings = CapsuleSettingsManager.getInstance(context).settings.value
    val prayerSuppressed = isCardSuppressed(IslandActiveCard.PRAYER)
    val (lat, lon, cityLabel) = PrayerTimesCalculator.resolveCoordinatesForLocation(context, settings)
    val computed = PrayerTimesCalculator.calculate(
      lat = lat,
      lon = lon,
      cityName = cityLabel,
      nowMs = System.currentTimeMillis(),
      reminderWindowMinutes = settings.prayerReminderMinutes,
      offsets = PrayerTimeOffsets(
        fajrMinutes = settings.prayerOffsetFajr,
        sunriseMinutes = settings.prayerOffsetSunrise,
        dhuhrMinutes = settings.prayerOffsetDhuhr,
        asrMinutes = settings.prayerOffsetAsr,
        maghribMinutes = settings.prayerOffsetMaghrib,
        ishaMinutes = settings.prayerOffsetIsha
      )
    )
    compassSensorManager?.updateQiblaBearing(computed.qiblaBearingDeg)
    if (_compassState.value.isActive) {
      _compassState.value = _compassState.value.copy(
        qiblaBearingDeg = computed.qiblaBearingDeg,
        isFacingQibla = PrayerTimesCalculator.isAlignedWithQibla(_compassState.value.azimuthDeg, computed.qiblaBearingDeg)
      )
    }

    val preAdhanTriggerKey = if (computed.isPreAdhanAlert) "${computed.nextPrayerNameAr}|${computed.nextPrayerTimeFormatted}" else ""
    val isNewPreAdhanAlert = !prayerSuppressed &&
      settings.enablePrayerAlerts &&
      computed.isPreAdhanAlert &&
      preAdhanTriggerKey.isNotBlank() &&
      preAdhanTriggerKey != lastPreAdhanKey
    if (isNewPreAdhanAlert) {
      lastPreAdhanKey = preAdhanTriggerKey
    }

    val keepTemporaryBanner = !prayerSuppressed && (showAlertBanner || isNewPreAdhanAlert || (prayerAlertExpireJob?.isActive == true))
    _prayerState.value = computed.copy(isAlertActive = keepTemporaryBanner)

    if (!prayerSuppressed && (showAlertBanner || isNewPreAdhanAlert) && !_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.PRAYER
      bumpActivityEvent()
      prayerAlertExpireJob?.cancel()
      prayerAlertExpireJob = scope.launch {
        delay(9_000L)
        _prayerState.value = _prayerState.value.copy(isAlertActive = false)
        if (_activeCard.value == IslandActiveCard.PRAYER &&
          !CapsuleSettingsManager.getInstance(context).settings.value.pinPrayerInCapsule
        ) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  fun showPrayerCard(context: Context) {
    unsuppressCard(IslandActiveCard.PRAYER)
    refreshPrayerTimes(context, showAlertBanner = true)
  }

  fun selectWeatherCity(context: Context, suggestion: WeatherRepository.CitySuggestion) {
    CapsuleSettingsManager.getInstance(context).updateWeatherCitySelection(
      query = suggestion.name,
      lat = suggestion.latitude,
      lon = suggestion.longitude,
      displayAlias = ""
    )
    refreshWeather(context, showAlertBanner = true, forceRefresh = true)
    refreshPrayerTimes(context, showAlertBanner = false)
  }

  fun applyWeatherCityQuery(context: Context, query: String) {
    val clean = query.trim()
    val mgr = CapsuleSettingsManager.getInstance(context)
    if (clean.isEmpty()) {
      deleteWeatherCity(context)
    } else {
      mgr.updateWeatherCityQuery(clean)
      refreshWeather(context, showAlertBanner = true, forceRefresh = true)
    }
  }

  fun renameWeatherCityDisplay(context: Context, alias: String) {
    val clean = alias.trim()
    CapsuleSettingsManager.getInstance(context).renameWeatherCityDisplay(clean)
    val cur = _weatherState.value
    if (cur.isLoaded) {
      val resolvedName = clean.ifBlank { cur.actualCityName.ifBlank { cur.cityName } }
      _weatherState.value = cur.copy(cityName = resolvedName)
    }
    refreshPrayerTimes(context, showAlertBanner = false)
  }

  fun deleteWeatherCity(context: Context) {
    CapsuleSettingsManager.getInstance(context).clearWeatherCity()
    WeatherRepository.clearSavedLocation(context)
    _weatherState.value = WeatherState(isLoading = true)
    refreshWeather(context, showAlertBanner = true, forceRefresh = true)
    refreshPrayerTimes(context, showAlertBanner = false)
  }

  fun showWeatherCard(context: Context) {
    unsuppressCard(IslandActiveCard.WEATHER)
    if (_weatherState.value.isLoaded) {
      _weatherState.value = _weatherState.value.copy(isAlertActive = true)
      _activeCard.value = IslandActiveCard.WEATHER
      bumpActivityEvent()
      weatherAlertExpireJob?.cancel()
      weatherAlertExpireJob = scope.launch {
        delay(8000)
        _weatherState.value = _weatherState.value.copy(isAlertActive = false)
        if (_activeCard.value == IslandActiveCard.WEATHER &&
          !CapsuleSettingsManager.getInstance(context).settings.value.pinWeatherInCapsule
        ) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
      ensureWeatherFresh(context)
    } else {
      _activeCard.value = IslandActiveCard.WEATHER
      bumpActivityEvent()
      refreshWeather(context, showAlertBanner = true)
    }
  }

  // Real Hardware Digital Compass
  fun openCompassCard(context: Context) {
    unsuppressCard(IslandActiveCard.COMPASS)
    val settings = CapsuleSettingsManager.getInstance(context).settings.value
    val (lat, lon, _) = PrayerTimesCalculator.resolveCoordinatesForLocation(context, settings)
    val qibla = PrayerTimesCalculator.computeQiblaBearing(lat, lon)
    if (compassSensorManager == null) {
      compassSensorManager = CompassSensorManager(context) { _compassState.value = it }
    }
    compassSensorManager?.updateQiblaBearing(qibla)
    compassSensorManager?.startListening()
    _compassState.value = _compassState.value.copy(
      isActive = true,
      hasSensor = compassSensorManager?.hasCompassSensor() == true,
      qiblaBearingDeg = qibla,
      isFacingQibla = PrayerTimesCalculator.isAlignedWithQibla(_compassState.value.azimuthDeg, qibla)
    )
    _activeCard.value = IslandActiveCard.COMPASS
    bumpActivityEvent()
  }

  fun stopCompassCard() {
    compassSensorManager?.stopListening()
    _compassState.value = _compassState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.COMPASS) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Pomodoro / Smart Focus Session
  fun startFocusSession(minutes: Int = 25, isBreak: Boolean = false) {
    val totalSec = minutes.coerceIn(1, 120) * 60
    focusTimerJob?.cancel()
    _focusState.value = FocusState(
      isActive = true,
      isRunning = true,
      isBreak = isBreak,
      totalSeconds = totalSec,
      remainingSeconds = totalSec
    )
    activateCardAndNotify(IslandActiveCard.FOCUS)
    launchFocusTicker()
  }

  fun toggleFocusPause() {
    val cur = _focusState.value
    if (!cur.isActive) return
    if (cur.isRunning) {
      focusTimerJob?.cancel()
      _focusState.value = cur.copy(isRunning = false)
    } else {
      _focusState.value = cur.copy(isRunning = true)
      launchFocusTicker()
    }
  }

  private fun launchFocusTicker() {
    focusTimerJob?.cancel()
    focusTimerJob = scope.launch {
      while (isActive && _focusState.value.isActive && _focusState.value.isRunning) {
        delay(1000)
        val cur = _focusState.value
        val next = (cur.remainingSeconds - 1).coerceAtLeast(0)
        _focusState.value = cur.copy(remainingSeconds = next)
        if (next <= 0) {
          val wasBreak = cur.isBreak
          _focusState.value = FocusState()
          if (_activeCard.value == IslandActiveCard.FOCUS) {
            _activeCard.value = IslandActiveCard.MUSIC
          }
          postNotificationEvent(
            appName = "مؤقت التركيز",
            title = if (wasBreak) "انتهت الاستراحة" else "أحسنت! انتهت جلسة التركيز",
            text = if (wasBreak) "جاهز للعودة إلى العمل" else "يمكنك الآن أخذ استراحة قصيرة"
          )
          break
        }
      }
    }
  }

  fun cancelFocusSession() {
    focusTimerJob?.cancel()
    _focusState.value = FocusState()
    if (_activeCard.value == IslandActiveCard.FOCUS) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Sleep Timer for Media (auto-pauses active music at 00:00)
  fun startSleepTimer(minutes: Int) {
    val totalSec = (minutes.coerceIn(1, 240)) * 60
    sleepTimerJob?.cancel()
    _sleepTimerState.value = SleepTimerState(
      isActive = true,
      totalSeconds = totalSec,
      remainingSeconds = totalSec
    )
    activateCardAndNotify(IslandActiveCard.SLEEP_TIMER)

    sleepTimerJob = scope.launch {
      var remaining = totalSec
      while (isActive && remaining > 0) {
        delay(1000)
        remaining--
        _sleepTimerState.value = _sleepTimerState.value.copy(
          isActive = true,
          remainingSeconds = remaining
        )
      }
      if (isActive && remaining <= 0) {
        _sleepTimerState.value = SleepTimerState()
        MediaSessionHolder.pause()
        postNotificationEvent(
          appName = "مؤقت النوم",
          title = "تم إيقاف التشغيل تلقائياً",
          text = "انتهى مؤقت النوم (${minutes} دقيقة) وتم إيقاف الموسيقى"
        )
      }
    }
  }

  fun cancelSleepTimer() {
    sleepTimerJob?.cancel()
    _sleepTimerState.value = SleepTimerState()
    if (_activeCard.value == IslandActiveCard.SLEEP_TIMER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Real System Next Alarm Sync via AlarmManager
  private fun registerNextAlarmMonitor(context: Context) {
    refreshNextAlarm(context)
    val filter = IntentFilter(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val c = ctx ?: context
        refreshNextAlarm(c)
        val alarm = _nextAlarmState.value
        val enabled = CapsuleSettingsManager.getInstance(c).settings.value.enableAlarmSync
        if (enabled && alarm.hasAlarm && !isInitialStickyBroadcast) {
          postNotificationEvent(
            appName = "المنبه القادم",
            title = "تم ضبط منبه على الساعة ${alarm.formattedTime}",
            text = "متزامن تلقائياً مع تطبيق الساعة"
          )
        }
      }
    }
    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering next alarm receiver", e)
    }
  }

  fun refreshNextAlarm(context: Context) {
    try {
      val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
      val info = am?.nextAlarmClock
      if (info != null && info.triggerTime > System.currentTimeMillis()) {
        val formatter = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val formatted = formatter.format(Date(info.triggerTime))
        val diffMs = info.triggerTime - System.currentTimeMillis()
        val urgent = diffMs in 1L..(30 * 60_000L)
        _nextAlarmState.value = NextAlarmState(
          hasAlarm = true,
          triggerTimeMs = info.triggerTime,
          formattedTime = formatted,
          isUrgent = urgent
        )
      } else {
        _nextAlarmState.value = NextAlarmState()
      }
    } catch (e: Exception) {
      Log.w(TAG, "Unable to read next alarm clock", e)
      _nextAlarmState.value = NextAlarmState()
    }
  }

  fun openAlarmApp(context: Context) {
    try {
      val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
      val showIntent = am?.nextAlarmClock?.showIntent
      if (showIntent != null) {
        showIntent.send()
        return
      }
    } catch (_: Exception) {}

    try {
      val alarmIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(alarmIntent)
    } catch (_: Exception) {}
  }

  fun getAudioOutputSummary(context: Context): String {
    try {
      val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
      val extDisplay = dm?.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)?.firstOrNull()
      if (extDisplay != null) {
        val displayLabel = extDisplay.name?.takeIf { it.isNotBlank() } ?: "شاشة خارجية"
        return "بث شاشة: $displayLabel"
      }
    } catch (_: Exception) {}

    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return "مكبر صوت الهاتف"
    val devices = try {
      am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    } catch (_: Exception) {
      emptyArray()
    }

    val hdmiDevice = devices.firstOrNull {
      it.type == AudioDeviceInfo.TYPE_HDMI || it.type == AudioDeviceInfo.TYPE_HDMI_ARC
    }
    if (hdmiDevice != null) {
      val label = hdmiDevice.productName?.toString()?.takeIf { it.isNotBlank() } ?: "شاشة / HDMI"
      return label
    }

    val btDevice = devices.firstOrNull { device ->
      device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
        device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
        (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
          (device.type == AudioDeviceInfo.TYPE_BLE_HEADSET || device.type == AudioDeviceInfo.TYPE_BLE_SPEAKER))
    }
    if (btDevice != null) {
      val name = btDevice.productName?.toString()?.takeIf { it.isNotBlank() }
      return name ?: _bluetoothState.value.deviceName.takeIf { _bluetoothState.value.isConnected && it.isNotBlank() } ?: "سماعة بلوتوث"
    }

    val wiredDevice = devices.firstOrNull { device ->
      device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
        device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
        (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && device.type == AudioDeviceInfo.TYPE_USB_HEADSET) ||
        device.type == AudioDeviceInfo.TYPE_USB_DEVICE
    }
    if (wiredDevice != null) {
      val name = wiredDevice.productName?.toString()?.takeIf { it.isNotBlank() }
      return name ?: "سماعة سلكية / USB"
    }

    return "مكبر صوت الهاتف"
  }

  fun hasExternalCastOrAudio(context: Context): Boolean {
    try {
      val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
      if (dm?.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)?.isNotEmpty() == true) {
        return true
      }
    } catch (_: Exception) {}

    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
    val devices = try {
      am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    } catch (_: Exception) {
      return false
    }
    return devices.any { device ->
      device.type == AudioDeviceInfo.TYPE_HDMI ||
        device.type == AudioDeviceInfo.TYPE_HDMI_ARC ||
        device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
        device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
        device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
        (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && device.type == AudioDeviceInfo.TYPE_USB_HEADSET) ||
        (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
          (device.type == AudioDeviceInfo.TYPE_BLE_HEADSET || device.type == AudioDeviceInfo.TYPE_BLE_SPEAKER))
    }
  }

  fun openScreenCastSettings(context: Context): Boolean {
    val candidates = listOf(
      Intent(Settings.ACTION_CAST_SETTINGS),
      Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
      Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
      Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )
    for (intent in candidates) {
      try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) != null) {
          context.startActivity(intent)
          return true
        }
      } catch (_: Exception) {}
    }
    return false
  }

  fun openMediaOutputSwitcher(context: Context, packageName: String?): Boolean {
    val systemUiOutput = Intent("com.android.systemui.action.LAUNCH_MEDIA_OUTPUT_DIALOG").apply {
      if (!packageName.isNullOrBlank()) {
        putExtra("package_name", packageName)
      }
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    val settingsPanelOutput = Intent("com.android.settings.panel.action.MEDIA_OUTPUT").apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    val bluetoothFallback = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    val soundFallback = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    for (intent in listOf(systemUiOutput, settingsPanelOutput, bluetoothFallback, soundFallback)) {
      try {
        if (intent.resolveActivity(context.packageManager) != null) {
          context.startActivity(intent)
          return true
        }
      } catch (_: Exception) {}
    }
    return false
  }

  fun shareTrack(context: Context, title: String, artist: String) {
    val cleanTitle = title.ifBlank { "مقطع صوتي" }
    val shareBody = if (artist.isNotBlank()) {
      "🎵 أستمع الآن إلى: $cleanTitle — $artist"
    } else {
      "🎵 أستمع الآن إلى: $cleanTitle"
    }
    try {
      val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareBody)
      }
      val chooser = Intent.createChooser(sendIntent, "مشاركة الأغنية").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(chooser)
    } catch (e: Exception) {
      Log.e(TAG, "Error sharing track", e)
    }
  }

  fun selectCard(card: IslandActiveCard) {
    unsuppressCard(card)
    _activeCard.value = card
  }

  // Delivery Orders Tracking (NotificationListener + UI preview)
  fun updateDeliveryOrder(
    key: String,
    pkg: String,
    appName: String,
    statusTitle: String,
    detailText: String,
    etaText: String = "",
    progressPct: Int = -1,
    contentIntent: PendingIntent? = null,
    autoExpireMs: Long = 0L
  ) {
    deliveryContentIntent = contentIntent
    val wasActive = _deliveryState.value.isActive
    _deliveryState.value = DeliveryState(
      isActive = true,
      key = key,
      packageName = pkg,
      appName = appName,
      statusTitle = statusTitle,
      detailText = detailText,
      etaText = etaText,
      progressPct = progressPct,
      timestamp = System.currentTimeMillis()
    )
    activateCardAndNotify(
      card = IslandActiveCard.DELIVERY,
      bumpEvent = !wasActive || key == "preview_delivery"
    )
    deliveryExpireJob?.cancel()
    if (autoExpireMs > 0L) {
      deliveryExpireJob = scope.launch {
        delay(autoExpireMs)
        stopDeliveryTracking()
      }
    }
  }

  fun showDeliveryPreview() {
    updateDeliveryOrder(
      key = "preview_delivery",
      pkg = "",
      appName = "طلبات / التوصيل",
      statusTitle = "المندوب في الطريق إليك",
      detailText = "تم استلام طلبك وهو يقترب الآن",
      etaText = "خلال 8 د",
      progressPct = 72,
      contentIntent = null,
      autoExpireMs = 15_000L
    )
  }

  fun clearDeliveryOrder(key: String) {
    if (_deliveryState.value.key == key) {
      stopDeliveryTracking()
    }
  }

  fun stopDeliveryTracking() {
    deliveryExpireJob?.cancel()
    deliveryContentIntent = null
    _deliveryState.value = DeliveryState()
    if (_activeCard.value == IslandActiveCard.DELIVERY) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun openDeliveryApp(context: Context) {
    try {
      deliveryContentIntent?.send()
      return
    } catch (_: Exception) {}
    val pkg = _deliveryState.value.packageName
    if (pkg.isNotBlank()) {
      openSourceApp(context, pkg)
    }
  }

  // Real Live Football Match Results (ESPN Public Scoreboard HTTPS API)
  private fun startFootballAutoUpdater(context: Context) {
    footballAutoJob?.cancel()
    footballAutoJob = scope.launch {
      while (isActive) {
        val settings = CapsuleSettingsManager.getInstance(context).settings.value
        if (settings.enableFootballScores) {
          refreshFootballScores(context, showAlertBanner = false)
        }
        val state = _footballState.value
        val hasLive = state.matches.any { it.isLive }
        val activelyViewed = _activeCard.value == IslandActiveCard.FOOTBALL || settings.pinFootballInCapsule
        val nextDelayMs = when {
          hasLive || activelyViewed -> 10_000L
          !state.isLoaded || !state.errorMessage.isNullOrBlank() -> 15_000L
          else -> 60_000L
        }
        delay(nextDelayMs)
      }
    }
  }

  fun ensureFootballFresh(context: Context, maxAgeMs: Long = 10_000L) {
    val cur = _footballState.value
    if (!cur.isLoaded || (!cur.isLoading && System.currentTimeMillis() - cur.lastUpdatedMs >= maxAgeMs)) {
      refreshFootballScores(context, showAlertBanner = false, forceRefresh = false)
    }
  }

  private fun launchFootballClockTicker() {
    val needsTicker = _footballState.value.matches.any {
      it.matchPhase == FootballMatchPhase.LIVE_PLAY && it.clockSeconds >= 0 && !it.isStoppageTime
    }
    if (!needsTicker) {
      footballClockJob?.cancel()
      footballClockJob = null
      return
    }
    if (footballClockJob?.isActive == true) return

    footballClockJob = scope.launch {
      while (isActive) {
        delay(1000L)
        val cur = _footballState.value
        var anyChanged = false
        val tickedMatches = cur.matches.map { match ->
          if (match.matchPhase == FootballMatchPhase.LIVE_PLAY &&
            match.clockSeconds >= 0 &&
            !match.isStoppageTime &&
            (match.serverClockSeconds < 0 || match.clockSeconds < match.serverClockSeconds + 12)
          ) {
            anyChanged = true
            match.copy(clockSeconds = match.clockSeconds + 1)
          } else {
            match
          }
        }
        if (!anyChanged) break
        _footballState.value = cur.copy(matches = tickedMatches)
      }
    }
  }

  internal fun shouldVibrateForFootballEvent(
    event: FootballMatchEvent,
    settings: CapsuleSettings
  ): Boolean {
    return settings.enableFootballScores &&
      !isCardSuppressed(IslandActiveCard.FOOTBALL) &&
      settings.hapticFeedback &&
      (event.type == FootballEventType.GOAL || event.type == FootballEventType.GOAL_DISALLOWED)
  }

  internal fun buildGoalVibrationTimings(type: FootballEventType): LongArray {
    return when (type) {
      FootballEventType.GOAL -> longArrayOf(0L, 140L, 80L, 220L, 90L, 140L)
      FootballEventType.GOAL_DISALLOWED -> longArrayOf(0L, 90L, 70L, 90L)
      else -> longArrayOf()
    }
  }

  @SuppressLint("MissingPermission")
  private fun triggerGoalVibration(context: Context, eventType: FootballEventType) {
    val timings = buildGoalVibrationTimings(eventType)
    if (timings.isEmpty()) return
    runCatching {
      val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java)?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      }
      if (vibrator == null || !vibrator.hasVibrator()) return
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val amplitudes = when (eventType) {
          FootballEventType.GOAL -> intArrayOf(0, 235, 0, 255, 0, 200)
          FootballEventType.GOAL_DISALLOWED -> intArrayOf(0, 175, 0, 175)
          else -> intArrayOf(0, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(timings, -1)
      }
    }
  }

  private fun triggerFootballEventBanner(context: Context, event: FootballMatchEvent) {
    val mgr = CapsuleSettingsManager.getInstance(context)
    val latestSettings = mgr.settings.value
    if (isCardSuppressed(IslandActiveCard.FOOTBALL)) return

    val cur = _footballState.value
    val matchIdx = cur.matches.indexOfFirst { it.id == event.matchId }
    _footballState.value = cur.copy(
      activeEvent = event,
      isAlertActive = true,
      selectedIndex = if (matchIdx >= 0) matchIdx else cur.selectedIndex
    )
    if (shouldVibrateForFootballEvent(event, latestSettings)) {
      triggerGoalVibration(context, event.type)
    }
    if (latestSettings.enableFootballScores && !_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.FOOTBALL
      bumpActivityEvent()
    }
    footballEventExpireJob?.cancel()
    footballEventExpireJob = scope.launch {
      delay(9_000L)
      val latest = _footballState.value
      if (latest.activeEvent?.id == event.id) {
        val liveIdx = latest.matches.indexOfFirst { !it.isFinished && it.isLive }
        val stillLive = liveIdx >= 0 && !isCardSuppressed(IslandActiveCard.FOOTBALL)
        val nextIdx = if (stillLive && latest.currentMatch?.isFinished == true) liveIdx else latest.selectedIndex
        _footballState.value = latest.copy(
          activeEvent = null,
          isAlertActive = stillLive,
          selectedIndex = nextIdx
        )
        if (_activeCard.value == IslandActiveCard.FOOTBALL && !stillLive) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  fun refreshFootballScores(
    context: Context,
    leagueCode: String? = null,
    showAlertBanner: Boolean = false,
    forceRefresh: Boolean = false
  ) {
    val mgr = CapsuleSettingsManager.getInstance(context)
    val chosenLeague = leagueCode?.takeIf { it.isNotBlank() } ?: mgr.settings.value.footballLeagueCode
    val leagueObj = FootballLeague.fromCode(chosenLeague)
    if (_footballState.value.isLoading && !forceRefresh) return

    if (showAlertBanner) {
      unsuppressCard(IslandActiveCard.FOOTBALL)
    }

    val previousState = _footballState.value
    val previousSelectedMatchId = previousState.currentMatch?.id
    val sameLeague = previousState.isLoaded && previousState.leagueCode == leagueObj.code

    footballFetchJob?.cancel()
    _footballState.value = previousState.copy(
      isLoading = true,
      leagueCode = leagueObj.code,
      leagueNameAr = leagueObj.labelAr,
      errorMessage = null
    )

    footballFetchJob = scope.launch {
      val result = FootballRepository.fetchLiveMatches(leagueObj.code)
      result.onSuccess { fetched ->
        val latestSettings = mgr.settings.value
        val footballSuppressed = isCardSuppressed(IslandActiveCard.FOOTBALL)
        val sortedMatches = FootballRepository.sortMatchesForDisplay(
          fetched.matches,
          latestSettings.effectiveFavoriteFootballTeams
        )
        val flaggedMatches = FootballRepository.markPreMatchFlags(
          sortedMatches,
          latestSettings.footballReminderMinutes
        )
        val mergedMatches = if (sameLeague) {
          FootballRepository.mergeLiveClocks(previousState.matches, flaggedMatches)
        } else {
          flaggedMatches
        }

        val preservedIdx = if (sameLeague && previousSelectedMatchId != null) {
          mergedMatches.indexOfFirst { it.id == previousSelectedMatchId }.takeIf { it >= 0 } ?: 0
        } else {
          0
        }

        val detectedMatchChange = if (sameLeague && !footballSuppressed) {
          FootballRepository.detectMatchEvent(previousState.matches, mergedMatches, previousSelectedMatchId)
        } else {
          null
        }
        val upcomingReminder = if (latestSettings.enablePreMatchReminder && !footballSuppressed) {
          FootballRepository.detectUpcomingMatchReminder(
            matches = mergedMatches,
            reminderMinutes = latestSettings.footballReminderMinutes,
            favoriteTeams = latestSettings.effectiveFavoriteFootballTeams,
            alreadyRemindedIds = remindedPreMatchIds
          )?.also { remindedPreMatchIds.add(it.matchId) }
        } else null

        val detectedEvent = detectedMatchChange ?: upcomingReminder
        val activeBanner = if (footballSuppressed) {
          null
        } else {
          detectedEvent ?: _footballState.value.activeEvent?.takeIf {
            System.currentTimeMillis() - it.timestampMs < 9_000L && sameLeague
          }
        }

        val liveIdx = mergedMatches.indexOfFirst { !it.isFinished && it.isLive }
        val hasLiveMatch = liveIdx >= 0
        val effectiveIdx = if (detectedEvent == null &&
          activeBanner == null &&
          liveIdx >= 0 &&
          mergedMatches.getOrNull(preservedIdx)?.isFinished == true
        ) {
          liveIdx
        } else {
          preservedIdx
        }

        val keepAlert = !footballSuppressed && (showAlertBanner || hasLiveMatch || activeBanner != null)
        _footballState.value = fetched.copy(
          matches = mergedMatches,
          selectedIndex = effectiveIdx,
          isAlertActive = keepAlert,
          activeEvent = activeBanner
        )

        if (!footballSuppressed) {
          launchFootballClockTicker()
        }

        if (footballSuppressed) {
          if (_activeCard.value == IslandActiveCard.FOOTBALL) {
            _activeCard.value = IslandActiveCard.MUSIC
          }
        } else if (detectedEvent != null) {
          triggerFootballEventBanner(context, detectedEvent)
        } else if (showAlertBanner && !_callState.value.isActive) {
          _activeCard.value = IslandActiveCard.FOOTBALL
          bumpActivityEvent()
          footballAlertExpireJob?.cancel()
          footballAlertExpireJob = scope.launch {
            delay(10_000)
            val latest = _footballState.value
            val stillLive = latest.matches.any { !it.isFinished && it.isLive }
            _footballState.value = latest.copy(
              isAlertActive = stillLive || latest.activeEvent != null
            )
            if (_activeCard.value == IslandActiveCard.FOOTBALL &&
              !stillLive &&
              latest.activeEvent == null
            ) {
              _activeCard.value = IslandActiveCard.MUSIC
            }
          }
        } else if (!keepAlert && _activeCard.value == IslandActiveCard.FOOTBALL) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }.onFailure { err ->
        val footballSuppressed = isCardSuppressed(IslandActiveCard.FOOTBALL)
        val stillLive = !footballSuppressed && _footballState.value.matches.any { !it.isFinished && it.isLive }
        _footballState.value = _footballState.value.copy(
          isLoading = false,
          errorMessage = err.message ?: "تعذر جلب نتائج المباريات",
          isAlertActive = !footballSuppressed && (showAlertBanner || stillLive || _footballState.value.activeEvent != null)
        )
      }
    }
  }

  fun selectFootballLeague(context: Context, leagueCode: String) {
    unsuppressCard(IslandActiveCard.FOOTBALL)
    CapsuleSettingsManager.getInstance(context).updateFootballLeagueCode(leagueCode)
    refreshFootballScores(context, leagueCode = leagueCode, showAlertBanner = true, forceRefresh = true)
  }

  fun cycleFootballMatch(delta: Int = 1) {
    val cur = _footballState.value
    if (cur.matches.isEmpty()) return
    val size = cur.matches.size
    val nextIdx = ((cur.selectedIndex + delta) % size + size) % size
    _footballState.value = cur.copy(selectedIndex = nextIdx)
  }

  fun showFootballCard(context: Context) {
    unsuppressCard(IslandActiveCard.FOOTBALL)
    val cur = _footballState.value
    _footballState.value = cur.copy(isAlertActive = true)
    _activeCard.value = IslandActiveCard.FOOTBALL
    bumpActivityEvent()
    if (!cur.isLoaded || System.currentTimeMillis() - cur.lastUpdatedMs > 12_000L) {
      refreshFootballScores(context, showAlertBanner = true, forceRefresh = true)
    } else {
      launchFootballClockTicker()
      footballAlertExpireJob?.cancel()
      footballAlertExpireJob = scope.launch {
        delay(10_000)
        val latest = _footballState.value
        val hasLive = latest.matches.any { !it.isFinished && it.isLive }
        _footballState.value = latest.copy(
          isAlertActive = hasLive || latest.activeEvent != null
        )
        if (_activeCard.value == IslandActiveCard.FOOTBALL &&
          !hasLive &&
          latest.activeEvent == null
        ) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  /**
   * Immediately locates the favorite team's active or scheduled match in the loaded state, selects
   * it, and surfaces the Football card in the Dynamic Capsule. Returns true if found locally.
   */
  fun focusFavoriteTeamMatch(context: Context, teamQuery: String): Boolean {
    unsuppressCard(IslandActiveCard.FOOTBALL)
    val clean = teamQuery.trim()
    if (clean.isBlank()) return false
    val cur = _footballState.value
    val targetMatch = FootballRepository.findMatchForTeam(clean, cur.matches) ?: return false
    val targetIdx = cur.matches.indexOfFirst { it.id == targetMatch.id }.coerceAtLeast(0)
    _footballState.value = cur.copy(
      selectedIndex = targetIdx,
      isAlertActive = true
    )
    if (!_callState.value.isActive) {
      _activeCard.value = IslandActiveCard.FOOTBALL
    }
    bumpActivityEvent()
    launchFootballClockTicker()
    footballAlertExpireJob?.cancel()
    footballAlertExpireJob = scope.launch {
      delay(12_000)
      val latest = _footballState.value
      val hasLive = latest.matches.any { !it.isFinished && it.isLive }
      _footballState.value = latest.copy(
        isAlertActive = hasLive || latest.activeEvent != null
      )
      if (_activeCard.value == IslandActiveCard.FOOTBALL &&
        !hasLive &&
        latest.activeEvent == null
      ) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
    return true
  }

  /**
   * Focuses a favorite team's match immediately if already present, or fetches across "all"
   * competitions to locate and display any live/today match for that team in the capsule.
   */
  fun searchAndFocusFavoriteTeamMatch(
    context: Context,
    teamQuery: String,
    onResult: (Boolean) -> Unit = {}
  ) {
    unsuppressCard(IslandActiveCard.FOOTBALL)
    if (focusFavoriteTeamMatch(context, teamQuery)) {
      onResult(true)
      return
    }
    val clean = teamQuery.trim()
    if (clean.isBlank()) {
      onResult(false)
      return
    }
    scope.launch {
      val mgr = CapsuleSettingsManager.getInstance(context)
      val leaguesToScan = listOf(mgr.settings.value.footballLeagueCode, "all").distinct()
      for (code in leaguesToScan) {
        val result = FootballRepository.fetchLiveMatches(code).getOrNull() ?: continue
        val sortedMatches = FootballRepository.sortMatchesForDisplay(
          result.matches,
          mgr.settings.value.effectiveFavoriteFootballTeams
        )
        val flagged = FootballRepository.markPreMatchFlags(
          sortedMatches,
          mgr.settings.value.footballReminderMinutes
        )
        val targetMatch = FootballRepository.findMatchForTeam(clean, flagged)
        if (targetMatch != null && !isCardSuppressed(IslandActiveCard.FOOTBALL)) {
          val idx = flagged.indexOfFirst { it.id == targetMatch.id }.coerceAtLeast(0)
          _footballState.value = result.copy(
            matches = flagged,
            selectedIndex = idx,
            isAlertActive = true
          )
          if (!_callState.value.isActive) {
            _activeCard.value = IslandActiveCard.FOOTBALL
          }
          bumpActivityEvent()
          launchFootballClockTicker()
          onResult(true)
          return@launch
        }
      }
      onResult(false)
    }
  }
}
