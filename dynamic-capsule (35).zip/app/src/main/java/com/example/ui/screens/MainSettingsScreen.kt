package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Splitscreen
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Update
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.data.CustomColorSlot
import com.example.data.FavoriteTrack
import com.example.data.FavoriteTracksManager
import com.example.island.BluetoothState
import com.example.island.CompassState
import com.example.island.DeliveryState
import com.example.island.FocusState
import com.example.island.FootballLeague
import com.example.island.FootballRepository
import com.example.island.FootballState
import com.example.island.FootballTeamSuggestion
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NetworkEventType
import com.example.island.NextAlarmState
import com.example.island.PrayerTimesState
import com.example.island.SleepTimerState
import com.example.island.SoundMode
import com.example.island.StepsState
import com.example.island.WeatherRepository
import com.example.island.WeatherState
import java.util.Locale
import com.example.BuildConfig
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.service.FloatingCapsuleService
import com.example.service.OverlayCapsuleService
import com.example.update.AppUpdateState
import com.example.update.GitHubUpdateManager
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.capsule.TeamCrestBadge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import com.example.ui.theme.AppTheme
import com.example.ui.theme.AppThemeBackdrop
import com.example.ui.theme.AppThemeOption
import com.example.ui.theme.CardVariant
import com.example.ui.theme.ObsidianPrimary
import com.example.ui.theme.ObsidianSecondary
import com.example.ui.theme.ObsidianSuccess
import com.example.ui.theme.ObsidianTertiary
import com.example.ui.theme.ObsidianWarning
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.ThemedCard
import com.example.ui.theme.paletteForThemeIndex
import androidx.compose.ui.graphics.luminance

private fun contrastOn(background: Color): Color =
  if (background.luminance() > 0.55f) Color(0xFF121214) else Color.White

private val DarkBackground: Color
  @Composable get() = AppTheme.colors.background

private val DarkSurface: Color
  @Composable get() = AppTheme.colors.surface

private val DarkSurfaceCard: Color
  @Composable get() = AppTheme.colors.surfaceElevated

private val DarkSurfaceBorder: Color
  @Composable get() = AppTheme.colors.border

private val PalettePrimary: Color
  @Composable get() = AppTheme.colors.primary

private val PaletteSecondary: Color
  @Composable get() = AppTheme.colors.secondary

private val PaletteTertiary: Color
  @Composable get() = AppTheme.colors.tertiary

private val PaletteSuccess: Color
  @Composable get() = AppTheme.colors.success

private val PaletteWarning: Color
  @Composable get() = AppTheme.colors.warning

private val PaletteError: Color
  @Composable get() = AppTheme.colors.error

private val TextPrimary: Color
  @Composable get() = AppTheme.colors.textPrimary

private val TextSecondary: Color
  @Composable get() = AppTheme.colors.textSecondary

private val TextMuted: Color
  @Composable get() = AppTheme.colors.textMuted

@Composable
private fun SectionIconBadge(
  icon: ImageVector,
  tint: Color,
  size: androidx.compose.ui.unit.Dp = 36.dp,
  iconSize: androidx.compose.ui.unit.Dp = 19.dp
) {
  Box(
    modifier = Modifier
      .size(size)
      .clip(RoundedCornerShape(11.dp))
      .background(tint.copy(alpha = 0.14f))
      .border(1.dp, tint.copy(alpha = 0.32f), RoundedCornerShape(11.dp)),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = tint,
      modifier = Modifier.size(iconSize)
    )
  }
}

enum class SettingsTab(
  val labelAr: String,
  val icon: ImageVector,
  val testTag: String
) {
  PREVIEW("المعاينة", Icons.Default.GraphicEq, "nav_tab_preview"),
  FEATURES("الميزات", Icons.Default.Widgets, "nav_tab_features"),
  CUSTOMIZE("التخصيص", Icons.Default.Palette, "nav_tab_customize"),
  PERMISSIONS("الأذونات", Icons.Default.Security, "nav_tab_permissions")
}

@Composable
fun MainSettingsScreen(
  settingsManager: CapsuleSettingsManager,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val settings by settingsManager.settings.collectAsState()
  val favoritesManager = remember(context) { FavoriteTracksManager.getInstance(context) }
  val favoriteTracks by favoritesManager.favorites.collectAsState()
  val trackInfo by MediaSessionHolder.currentTrack.collectAsState()
  val flashlightState by IslandStateManager.flashlightState.collectAsState()
  val currentSoundMode by IslandStateManager.currentSoundMode.collectAsState()
  val sleepTimerState by IslandStateManager.sleepTimerState.collectAsState()
  val nextAlarmState by IslandStateManager.nextAlarmState.collectAsState()
  val bluetoothState by IslandStateManager.bluetoothState.collectAsState()
  val weatherState by IslandStateManager.weatherState.collectAsState()
  val stepsState by IslandStateManager.stepsState.collectAsState()
  val compassState by IslandStateManager.compassState.collectAsState()
  val focusState by IslandStateManager.focusState.collectAsState()
  val deliveryState by IslandStateManager.deliveryState.collectAsState()
  val footballState by IslandStateManager.footballState.collectAsState()
  val prayerState by IslandStateManager.prayerState.collectAsState()
  val updateState by GitHubUpdateManager.state.collectAsState()

  // Track live permissions state
  var canDrawOverlay by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
  var isNotifListenerGranted by remember {
    mutableStateOf(NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName))
  }
  var isPostNotifGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isCallPermissionGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isActivityRecGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isLocationGranted by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  var isBluetoothConnectGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isBatteryOptIgnored by remember {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    mutableStateOf(pm?.isIgnoringBatteryOptimizations(context.packageName) == true)
  }
  var isWriteSettingsGranted by remember { mutableStateOf(Settings.System.canWrite(context)) }
  var isInstallPackagesGranted by remember { mutableStateOf(GitHubUpdateManager.canRequestPackageInstalls(context)) }
  var showAppFilterDialog by remember { mutableStateOf(false) }
  var showFavoritesWindow by remember { mutableStateOf(false) }
  var showFavoriteTeamsWindow by remember { mutableStateOf(false) }
  var showColorStudioDialog by remember { mutableStateOf(false) }
  var showWeatherWindow by remember { mutableStateOf(false) }

  // Refresh permissions, sensors, Bluetooth, weather, football logos & installed release status on startup
  LaunchedEffect(Unit) {
    GitHubUpdateManager.syncConfirmedInstalledRelease(context)
    FootballRepository.ensureTeamMediaLoaded()
    IslandStateManager.refreshNextAlarm(context)
    IslandStateManager.refreshConnectedBluetoothDevices(context)
    IslandStateManager.refreshStepTracking(context)
    if (!IslandStateManager.weatherState.value.isLoaded) {
      IslandStateManager.refreshWeather(context, showAlertBanner = false)
    }
    if (!IslandStateManager.prayerState.value.isLoaded) {
      IslandStateManager.refreshPrayerTimes(context, showAlertBanner = false)
    }
  }

  LaunchedEffect(settings.autoCheckUpdatesOnLaunch) {
    if (settings.autoCheckUpdatesOnLaunch && GitHubUpdateManager.isRepoConfigured()) {
      GitHubUpdateManager.checkForUpdates(context)
    }
  }

  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        canDrawOverlay = Settings.canDrawOverlays(context)
        isNotifListenerGranted =
          NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          isPostNotifGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
          ) == PackageManager.PERMISSION_GRANTED
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          isCallPermissionGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
          ) == PackageManager.PERMISSION_GRANTED
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          isActivityRecGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACTIVITY_RECOGNITION
          ) == PackageManager.PERMISSION_GRANTED
        }
        isLocationGranted = ContextCompat.checkSelfPermission(
          context,
          Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          isBluetoothConnectGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH_CONNECT
          ) == PackageManager.PERMISSION_GRANTED
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        isBatteryOptIgnored = pm?.isIgnoringBatteryOptimizations(context.packageName) == true
        isWriteSettingsGranted = Settings.System.canWrite(context)
        isInstallPackagesGranted = GitHubUpdateManager.canRequestPackageInstalls(context)
        GitHubUpdateManager.syncConfirmedInstalledRelease(context)
        IslandStateManager.refreshNextAlarm(context)
        IslandStateManager.refreshConnectedBluetoothDevices(context)
        IslandStateManager.refreshStepTracking(context)

        if (canDrawOverlay && settings.serviceEnabled) {
          startCapsuleService(context)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  val postNotifLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isPostNotifGranted = granted
  }

  val callPermLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { perms ->
    isCallPermissionGranted = perms[Manifest.permission.ANSWER_PHONE_CALLS] == true
  }

  val activityRecLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isActivityRecGranted = granted
    if (granted) IslandStateManager.refreshStepTracking(context)
  }

  val locationLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isLocationGranted = granted
    if (granted) IslandStateManager.refreshWeather(context, showAlertBanner = true)
  }

  val bluetoothPermLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isBluetoothConnectGranted = granted
    if (granted) IslandStateManager.refreshConnectedBluetoothDevices(context)
  }

  var previewMode by remember { mutableStateOf(CapsuleMode.MINI) }
  var currentTab by rememberSaveable { mutableStateOf(SettingsTab.PREVIEW) }
  var showThemeDialog by remember { mutableStateOf(false) }

  if (currentTab != SettingsTab.PREVIEW && !showFavoritesWindow && !showFavoriteTeamsWindow && !showAppFilterDialog && !showThemeDialog && !showColorStudioDialog && !showWeatherWindow) {
    BackHandler { currentTab = SettingsTab.PREVIEW }
  }

  val grantedPermissionsCount = listOf(
    canDrawOverlay,
    isNotifListenerGranted,
    isBluetoothConnectGranted,
    isActivityRecGranted,
    isLocationGranted,
    isCallPermissionGranted,
    isPostNotifGranted,
    isBatteryOptIgnored,
    isWriteSettingsGranted,
    isInstallPackagesGranted
  ).count { it }
  val totalPermissionsCount = 10
  val corePermissionsMissing = !canDrawOverlay || !isNotifListenerGranted
  val palette = AppTheme.colors

  AppThemeBackdrop(
    palette = palette,
    accentColor = settings.accentColor,
    modifier = modifier.fillMaxSize()
  ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = Color.Transparent,
      topBar = {
        val topBarShape = RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp)
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .then(
              if (palette.isGlass) {
                Modifier
                  .clip(topBarShape)
                  .background(palette.navBarContainer)
                  .background(
                    Brush.verticalGradient(
                      colors = listOf(palette.glossHighlight, Color.Transparent)
                    )
                  )
                  .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                      colors = listOf(palette.specularTopLeft.copy(alpha = 0.45f), palette.specularBottomRight)
                    ),
                    shape = topBarShape
                  )
              } else {
                Modifier
                  .background(palette.navBarContainer)
                  .border(width = 0.8.dp, color = palette.border, shape = topBarShape)
              }
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(modifier = Modifier.widthIn(max = 680.dp).fillMaxWidth()) {
            HeaderBanner(
              serviceEnabled = settings.serviceEnabled && !corePermissionsMissing,
              coreMissing = corePermissionsMissing,
              accentColor = settings.accentColor,
              currentTheme = palette.option,
              hasUpdateAvailable = updateState.isUpdateAvailable,
              onUpdateBadgeClick = { GitHubUpdateManager.reopenUpdateDialog() },
              onThemeClick = { showThemeDialog = true },
              onStatusClick = { currentTab = SettingsTab.PERMISSIONS }
            )
          }
        }
      },
      bottomBar = {
        // Unified Floating Sculpted Pill Dock across all themes
        val dockShape = RoundedCornerShape(28.dp)
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          contentAlignment = Alignment.Center
        ) {
          Row(
            modifier = Modifier
              .widthIn(max = 680.dp)
              .fillMaxWidth()
              .shadow(
                elevation = if (palette.isLight) 14.dp else 22.dp,
                shape = dockShape,
                spotColor = palette.primary.copy(alpha = 0.24f),
                ambientColor = Color.Black.copy(alpha = 0.35f)
              )
              .clip(dockShape)
              .background(palette.navBarContainer)
              .then(
                if (palette.isGlass) {
                  Modifier.background(
                    Brush.verticalGradient(
                      colors = listOf(palette.glossHighlight, Color.Transparent)
                    )
                  )
                } else Modifier
              )
              .border(
                width = 1.15.dp,
                brush = if (palette.isGlass) {
                  Brush.linearGradient(
                    colors = listOf(palette.specularTopLeft, palette.border.copy(alpha = 0.25f), palette.specularBottomRight)
                  )
                } else {
                  Brush.verticalGradient(
                    colors = listOf(palette.primary.copy(alpha = 0.28f), palette.border)
                  )
                },
                shape = dockShape
              )
              .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
          ) {
            SettingsTab.entries.forEach { tab ->
              val selected = currentTab == tab
              val pillShape = RoundedCornerShape(20.dp)
              val pillBg by animateColorAsState(
                targetValue = if (selected) palette.primary.copy(alpha = if (palette.isLight) 0.16f else 0.20f) else Color.Transparent,
                animationSpec = tween(230),
                label = "nav_pill_bg"
              )
              val pillBorder by animateColorAsState(
                targetValue = if (selected) palette.primary.copy(alpha = 0.45f) else Color.Transparent,
                animationSpec = tween(230),
                label = "nav_pill_border"
              )
              val contentTint by animateColorAsState(
                targetValue = if (selected) palette.primary else palette.textSecondary,
                animationSpec = tween(220),
                label = "nav_content_tint"
              )
              Column(
                modifier = Modifier
                  .weight(1f)
                  .testTag(tab.testTag)
                  .clip(pillShape)
                  .background(pillBg)
                  .border(width = 1.dp, color = pillBorder, shape = pillShape)
                  .clickable { currentTab = tab }
                  .padding(vertical = 7.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp)
              ) {
                Box(
                  modifier = Modifier
                    .width(if (selected) 20.dp else 0.dp)
                    .height(2.5.dp)
                    .clip(CircleShape)
                    .background(if (selected) palette.primary else Color.Transparent)
                )
                Box {
                  Icon(
                    imageVector = tab.icon,
                    contentDescription = tab.labelAr,
                    tint = contentTint,
                    modifier = Modifier.size(20.dp)
                  )
                  if (tab == SettingsTab.PERMISSIONS && corePermissionsMissing) {
                    Box(
                      modifier = Modifier
                        .size(8.dp)
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(palette.warning)
                    )
                  }
                }
                Text(
                  text = tab.labelAr,
                  color = contentTint,
                  fontSize = 10.sp,
                  fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                  maxLines = 1
                )
              }
            }
          }
        }
      }
    ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentAlignment = Alignment.TopCenter
    ) {
      AnimatedContent(
        targetState = currentTab,
        transitionSpec = {
          val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
          (fadeIn(tween(220)) + slideInHorizontally(
            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
          ) { it / 14 * direction })
            .togetherWith(
              fadeOut(tween(140)) + slideOutHorizontally(tween(160)) { -it / 16 * direction }
            )
        },
        modifier = Modifier
          .widthIn(max = 680.dp)
          .fillMaxSize(),
        label = "settings_tab_transition"
      ) { tab ->
      when (tab) {
        SettingsTab.PREVIEW -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              QuickStatusBentoRow(
                serviceActive = settings.serviceEnabled && !corePermissionsMissing,
                coreMissing = corePermissionsMissing,
                currentTheme = palette.option,
                grantedCount = grantedPermissionsCount,
                totalCount = totalPermissionsCount,
                onToggleService = {
                  val next = !settings.serviceEnabled
                  settingsManager.updateServiceEnabled(next)
                  if (next) startCapsuleService(context) else stopCapsuleService(context)
                },
                onOpenThemePicker = { showThemeDialog = true }
              )
            }

            item {
              FreeColorStudioBannerButton(
                isCustomActive = settings.useCustomColors,
                onClick = { showColorStudioDialog = true },
                modifier = Modifier.testTag("open_free_color_studio_button")
              )
            }

            item {
              LivePreviewCard(
                trackInfo = trackInfo,
                settings = settings,
                previewMode = previewMode,
                onModeToggle = {
                  previewMode = if (previewMode == CapsuleMode.MINI) CapsuleMode.EXPANDED else CapsuleMode.MINI
                },
                onPreviewWeather = {
                  IslandStateManager.showWeatherCard(context)
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewSteps = {
                  IslandStateManager.showStepsCard(context)
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewMusic = {
                  if (MediaSessionHolder.currentTrack.value == null) {
                    MediaSessionHolder.startDemoTrack()
                  }
                  IslandStateManager.selectCard(com.example.island.IslandActiveCard.MUSIC)
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewFocus = {
                  IslandStateManager.startFocusSession(25, false)
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewDelivery = {
                  IslandStateManager.showDeliveryPreview()
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewFootball = {
                  IslandStateManager.showFootballCard(context)
                  previewMode = CapsuleMode.EXPANDED
                },
                onPreviewPrayer = {
                  IslandStateManager.showPrayerCard(context)
                  previewMode = CapsuleMode.EXPANDED
                },
                onOpenWeatherWindow = { showWeatherWindow = true }
              )
            }

            item {
              DailyStepsRewardsCard(
                stepsState = stepsState,
                onShowCapsule = {
                  IslandStateManager.showStepsCard(context)
                  previewMode = CapsuleMode.EXPANDED
                },
                onCycleGoal = { IslandStateManager.cycleStepsGoal() }
              )
            }

            item {
              AnimationStudioCard(
                settings = settings,
                accentColor = settings.accentColor,
                onSelectOpenAnimation = { idx -> settingsManager.updateOpenAnimationIndex(idx) },
                onSelectAuraAnimation = { idx -> settingsManager.updateAuraAnimationIndex(idx) },
                onSelectVisualizerStyle = { idx -> settingsManager.updateVisualizerStyleIndex(idx) },
                onPreviewAnimation = {
                  previewMode = if (previewMode == CapsuleMode.MINI) CapsuleMode.EXPANDED else CapsuleMode.MINI
                }
              )
            }

            item {
              ActivePlayerCard(
                trackInfo = trackInfo,
                isListenerConnected = isNotifListenerGranted,
                accentColor = settings.accentColor,
                onStartDemo = { MediaSessionHolder.startDemoTrack() },
                onStartLongTitleDemo = { MediaSessionHolder.startLongTitleDemoTrack() },
                onStopDemo = { MediaSessionHolder.stopDemoTrack() }
              )
            }

            item {
              FavoriteTracksLauncherCard(
                favorites = favoriteTracks,
                accentColor = settings.accentColor,
                onOpenLibrary = { showFavoritesWindow = true }
              )
            }

            item {
              FavoriteTeamsLauncherCard(
                favoriteTeams = settings.effectiveFavoriteFootballTeams,
                accentColor = PaletteSuccess,
                onOpenWindow = { showFavoriteTeamsWindow = true }
              )
            }

            item {
              FlashlightQuickCard(
                isOn = flashlightState.isOn,
                onToggle = { IslandStateManager.toggleFlashlight(context) }
              )
            }

            item {
              GitHubUpdatesCard(
                settings = settings,
                updateState = updateState,
                isInstallPackagesGranted = isInstallPackagesGranted,
                onToggleAutoCheck = { enabled ->
                  settingsManager.toggleFeature(CapsuleSettingsManager.KEY_AUTO_CHECK_UPDATES, enabled)
                },
                onCheckNow = {
                  GitHubUpdateManager.checkForUpdates(
                    context = context,
                    forceRefresh = true
                  )
                },
                onDownloadUpdate = {
                  GitHubUpdateManager.startUpdateDownload(context)
                },
                onInstallUpdate = {
                  GitHubUpdateManager.installDownloadedUpdate(context)
                },
                onRequestInstallPermission = {
                  GitHubUpdateManager.openInstallUnknownAppsSettings(context)
                },
                onCancelDownload = {
                  GitHubUpdateManager.cancelDownload(context)
                },
                onOpenDownloads = {
                  GitHubUpdateManager.openDownloadsFolder(context)
                },
                onOpenReleasePage = {
                  GitHubUpdateManager.openReleasePage(context)
                }
              )
            }
          }
        }

        SettingsTab.FEATURES -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              FeaturesHubCard(
                settings = settings,
                currentSoundMode = currentSoundMode,
                sleepTimerState = sleepTimerState,
                nextAlarmState = nextAlarmState,
                bluetoothState = bluetoothState,
                weatherState = weatherState,
                stepsState = stepsState,
                compassState = compassState,
                focusState = focusState,
                deliveryState = deliveryState,
                footballState = footballState,
                prayerState = prayerState,
                accentColor = settings.accentColor,
                onToggleFeature = { key, enabled ->
                  settingsManager.toggleFeature(key, enabled)
                  if (enabled && key == CapsuleSettingsManager.KEY_PIN_WEATHER) {
                    IslandStateManager.showWeatherCard(context)
                  } else if (enabled && key == CapsuleSettingsManager.KEY_WEATHER_ALERTS) {
                    IslandStateManager.ensureWeatherFresh(context)
                  }
                  if (enabled && key == CapsuleSettingsManager.KEY_PIN_FOOTBALL) {
                    IslandStateManager.showFootballCard(context)
                  } else if (enabled && key == CapsuleSettingsManager.KEY_FOOTBALL_SCORES) {
                    IslandStateManager.refreshFootballScores(context, showAlertBanner = false)
                  }
                  if (enabled && key == CapsuleSettingsManager.KEY_PIN_PRAYER) {
                    IslandStateManager.showPrayerCard(context)
                  } else if (enabled && key == CapsuleSettingsManager.KEY_PRAYER_ALERTS) {
                    IslandStateManager.refreshPrayerTimes(context, showAlertBanner = false)
                  }
                  if (enabled && key == CapsuleSettingsManager.KEY_PIN_STEPS) {
                    IslandStateManager.showStepsCard(context)
                  }
                },
                onOpenAppFilter = { showAppFilterDialog = true },
                onTestBattery = { IslandStateManager.showBatteryCharging(85, context = context) },
                onTestCall = { IslandStateManager.startCall("مكالمة تجريبية", "Mobile", isIncoming = true) },
                onTestTimer = { IslandStateManager.startTimer(180, "مؤقت 3 دقائق") },
                onTestNotif = { IslandStateManager.postNotificationEvent("WhatsApp", "رسالة تجريبية", "مرحباً! هذه معاينة للإشعار") },
                onRefreshBluetooth = { IslandStateManager.refreshConnectedBluetoothDevices(context) },
                onTestNetwork = {
                  IslandStateManager.showNetworkAlert(
                    type = NetworkEventType.WIFI_CONNECTED,
                    title = "متصل بشبكة Wi-Fi",
                    subtitle = "تم الاتصال بالشبكة اللاسلكية"
                  )
                },
                onToggleFlashlight = { IslandStateManager.toggleFlashlight(context) },
                onTestVolume = { IslandStateManager.showVolumeAlert(10, 15) },
                onSelectSoundMode = { mode -> IslandStateManager.setSoundMode(context, mode) },
                onCycleSoundMode = { IslandStateManager.cycleSoundMode(context) },
                onStartSleepTimer = { mins -> IslandStateManager.startSleepTimer(mins) },
                onCancelSleepTimer = { IslandStateManager.cancelSleepTimer() },
                onOpenAlarmApp = { IslandStateManager.openAlarmApp(context) },
                onShowStepsCapsule = { IslandStateManager.showStepsCard(context) },
                onResetStepsToday = { IslandStateManager.resetTodaySteps() },
                onCycleStepsGoal = { IslandStateManager.cycleStepsGoal() },
                onUpdateWeatherCity = { city ->
                  settingsManager.updateWeatherCityQuery(city)
                  IslandStateManager.refreshWeather(context, showAlertBanner = true)
                },
                onRefreshWeatherNow = { IslandStateManager.refreshWeather(context, showAlertBanner = true, forceRefresh = true) },
                onShowWeatherCapsule = { IslandStateManager.showWeatherCard(context) },
                onOpenWeatherWindow = { showWeatherWindow = true },
                onDeleteWeatherCity = { IslandStateManager.deleteWeatherCity(context) },
                onOpenCompass = { IslandStateManager.openCompassCard(context) },
                onStartFocus = { IslandStateManager.startFocusSession(25, false) },
                onCancelFocus = { IslandStateManager.cancelFocusSession() },
                onTestDelivery = { IslandStateManager.showDeliveryPreview() },
                onSelectFootballLeague = { code -> IslandStateManager.selectFootballLeague(context, code) },
                onRefreshFootballNow = { IslandStateManager.refreshFootballScores(context, showAlertBanner = true, forceRefresh = true) },
                onShowFootballCapsule = { IslandStateManager.showFootballCard(context) },
                onUpdateFootballReminderMinutes = { mins -> settingsManager.updateFootballReminderMinutes(mins) },
                onAddFavoriteFootballTeam = { team ->
                  val added = settingsManager.addFavoriteFootballTeam(team)
                  if (added) {
                    IslandStateManager.refreshFootballScores(context, showAlertBanner = false, forceRefresh = true)
                  }
                  added
                },
                onRemoveFavoriteFootballTeam = { team ->
                  val removed = settingsManager.removeFavoriteFootballTeam(team)
                  if (removed) {
                    IslandStateManager.refreshFootballScores(context, showAlertBanner = false, forceRefresh = true)
                  }
                  removed
                },
                onFocusTeamInCapsule = { team, onResult ->
                  IslandStateManager.searchAndFocusFavoriteTeamMatch(context, team) { found ->
                    if (found) {
                      previewMode = CapsuleMode.EXPANDED
                      currentTab = SettingsTab.PREVIEW
                    }
                    onResult(found)
                  }
                },
                onOpenFavoriteTeamsWindow = { showFavoriteTeamsWindow = true },
                onShowPrayerCapsule = { IslandStateManager.showPrayerCard(context) },
                onRefreshPrayerNow = { IslandStateManager.refreshPrayerTimes(context, showAlertBanner = true) },
                onUpdatePrayerReminderMinutes = { mins ->
                  settingsManager.updatePrayerReminderMinutes(mins)
                  IslandStateManager.refreshPrayerTimes(context, showAlertBanner = false)
                },
                onUpdatePrayerOffset = { key, offsetMins ->
                  settingsManager.updatePrayerTimeOffset(key, offsetMins)
                  IslandStateManager.refreshPrayerTimes(context, showAlertBanner = false)
                },
                onResetPrayerOffsets = {
                  settingsManager.resetPrayerTimeOffsets()
                  IslandStateManager.refreshPrayerTimes(context, showAlertBanner = false)
                }
              )
            }
          }
        }

        SettingsTab.CUSTOMIZE -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              FreeColorStudioBannerButton(
                isCustomActive = settings.useCustomColors,
                onClick = { showColorStudioDialog = true }
              )
            }
            item {
              AppThemeGalleryCard(
                selectedThemeIndex = settings.appThemeIndex,
                accentColor = settings.effectiveAccentColor,
                onSelectTheme = { themeIdx -> settingsManager.updateAppThemeIndex(themeIdx) }
              )
            }
            item {
              CustomizationCard(
                settings = settings,
                onUpdateSettings = { newSettings ->
                  settingsManager.updateNotchOffsetY(newSettings.notchOffsetYDp)
                  settingsManager.updateCapsuleWidth(newSettings.capsuleWidthDp)
                  settingsManager.updateCapsuleHeight(newSettings.capsuleHeightDp)
                  settingsManager.updateAccentColorIndex(newSettings.accentColorIndex)
                  settingsManager.updateCapsuleStyleIndex(newSettings.capsuleStyleIndex)
                  settingsManager.updateCapsuleTransparent(newSettings.capsuleTransparent)
                  settingsManager.updateCapsuleOpacityPercent(newSettings.capsuleOpacityPercent)
                  settingsManager.updateShowWhenIdle(newSettings.showWhenIdle)
                },
                onToggleService = { enabled ->
                  settingsManager.updateServiceEnabled(enabled)
                  if (enabled) {
                    startCapsuleService(context)
                  } else {
                    stopCapsuleService(context)
                  }
                }
              )
            }
          }
        }

        SettingsTab.PERMISSIONS -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            item {
              PermissionsReadinessCard(
                grantedCount = grantedPermissionsCount,
                totalCount = totalPermissionsCount,
                accentColor = settings.accentColor
              )
            }
            item {
              PermissionsCard(
                canDrawOverlay = canDrawOverlay,
                isNotifListenerGranted = isNotifListenerGranted,
                isPostNotifGranted = isPostNotifGranted,
                isCallPermissionGranted = isCallPermissionGranted,
                isActivityRecGranted = isActivityRecGranted,
                isLocationGranted = isLocationGranted,
                isBluetoothConnectGranted = isBluetoothConnectGranted,
                isBatteryOptIgnored = isBatteryOptIgnored,
                isWriteSettingsGranted = isWriteSettingsGranted,
                isInstallPackagesGranted = isInstallPackagesGranted,
                accentColor = settings.accentColor,
                onGrantOverlay = {
                  val packageIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                  ).apply {
                    if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                  }
                  try {
                    context.startActivity(packageIntent)
                  } catch (_: Exception) {
                    try {
                      val generalIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                      }
                      context.startActivity(generalIntent)
                    } catch (_: Exception) {
                    }
                  }
                },
                onGrantListener = {
                  try {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                      if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                  } catch (_: Exception) {
                    try {
                      val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                        if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                      }
                      context.startActivity(fallback)
                    } catch (_: Exception) {}
                  }
                },
                onRequestPostNotif = {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    postNotifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                  }
                },
                onRequestCallPerm = {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    callPermLauncher.launch(
                      arrayOf(Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE)
                    )
                  }
                },
                onRequestActivityRec = {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    activityRecLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                  }
                },
                onRequestLocation = {
                  locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                },
                onRequestBluetoothConnect = {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    bluetoothPermLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                  }
                },
                onRequestBatteryOpt = {
                  try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                      data = Uri.parse("package:${context.packageName}")
                      if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                  } catch (_: Exception) {
                    try {
                      val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                        if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                      }
                      context.startActivity(fallback)
                    } catch (_: Exception) {
                      try {
                        val appDetails = Intent(
                          Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                          Uri.parse("package:${context.packageName}")
                        ).apply {
                          if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(appDetails)
                      } catch (_: Exception) {}
                    }
                  }
                },
                onRequestWriteSettings = {
                  try {
                    val intent = Intent(
                      Settings.ACTION_MANAGE_WRITE_SETTINGS,
                      Uri.parse("package:${context.packageName}")
                    ).apply {
                      if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                  } catch (_: Exception) {
                    try {
                      val fallback = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                        if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                      }
                      context.startActivity(fallback)
                    } catch (_: Exception) {
                      try {
                        val general = Intent(Settings.ACTION_SETTINGS).apply {
                          if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(general)
                      } catch (_: Exception) {}
                    }
                  }
                },
                onRequestInstallPackages = {
                  GitHubUpdateManager.openInstallUnknownAppsSettings(context)
                }
              )
            }
          }
        }
      }
      }
    }
    }
  } // Close AppThemeBackdrop

  if (showThemeDialog) {
    QuickThemePickerDialog(
      selectedThemeIndex = settings.appThemeIndex,
      accentColor = settings.effectiveAccentColor,
      onSelectTheme = { idx ->
        settingsManager.updateAppThemeIndex(idx)
        showThemeDialog = false
      },
      onOpenCustomStudio = {
        showThemeDialog = false
        showColorStudioDialog = true
      },
      onDismiss = { showThemeDialog = false }
    )
  }

  if (showColorStudioDialog) {
    FreeColorStudioDialog(
      settings = settings,
      onToggleCustomColors = { enabled -> settingsManager.updateUseCustomColors(enabled) },
      onUpdateCustomColor = { slot, argb -> settingsManager.updateCustomColor(slot, argb, enableCustom = true) },
      onResetAllColors = { settingsManager.resetAllCustomColors() },
      onDismiss = { showColorStudioDialog = false }
    )
  }

  if (showAppFilterDialog) {
    AppFilterDialog(
      excludedPackages = settings.excludedPackages,
      accentColor = settings.effectiveAccentColor,
      onTogglePackage = { pkg, excluded -> settingsManager.setPackageExcluded(pkg, excluded) },
      onResetAll = { settingsManager.clearExcludedPackages() },
      onDismiss = { showAppFilterDialog = false }
    )
  }

  if (showFavoritesWindow) {
    FavoritesLibraryWindow(
      favorites = favoriteTracks,
      accentColor = settings.effectiveAccentColor,
      onPlayTrack = { fav -> favoritesManager.openOrSearchTrack(context, fav) },
      onShareTrack = { fav -> IslandStateManager.shareTrack(context, fav.title, fav.artist) },
      onRemoveTrack = { fav -> favoritesManager.removeFavorite(fav.id) },
      onClearAll = { favoritesManager.clearAll() },
      onDismiss = { showFavoritesWindow = false }
    )
  }

  if (showFavoriteTeamsWindow) {
    FavoriteTeamsWindow(
      favoriteTeams = settings.effectiveFavoriteFootballTeams,
      liveMatches = footballState.matches,
      accentColor = PaletteSuccess,
      onAddTeam = { team ->
        val added = settingsManager.addFavoriteFootballTeam(team)
        if (added) {
          IslandStateManager.refreshFootballScores(context, showAlertBanner = false, forceRefresh = true)
        }
        added
      },
      onRemoveTeam = { team ->
        val removed = settingsManager.removeFavoriteFootballTeam(team)
        if (removed) {
          IslandStateManager.refreshFootballScores(context, showAlertBanner = false, forceRefresh = true)
        }
        removed
      },
      onOpenTeamInCapsule = { team, onResult ->
        IslandStateManager.searchAndFocusFavoriteTeamMatch(context, team) { found ->
          if (found) {
            showFavoriteTeamsWindow = false
            previewMode = CapsuleMode.EXPANDED
            currentTab = SettingsTab.PREVIEW
          }
          onResult(found)
        }
      },
      onClearAll = {
        settingsManager.clearFavoriteFootballTeams()
        IslandStateManager.refreshFootballScores(context, showAlertBanner = false, forceRefresh = true)
      },
      onDismiss = { showFavoriteTeamsWindow = false }
    )
  }

  if (showWeatherWindow) {
    WeatherCenterDialog(
      weatherState = weatherState,
      settings = settings,
      onSelectSuggestion = { suggestion ->
        IslandStateManager.selectWeatherCity(context, suggestion)
      },
      onSearchCityQuery = { query ->
        IslandStateManager.applyWeatherCityQuery(context, query)
      },
      onRenameDisplayCity = { alias ->
        IslandStateManager.renameWeatherCityDisplay(context, alias)
      },
      onDeleteCity = {
        IslandStateManager.deleteWeatherCity(context)
      },
      onRefreshNow = {
        IslandStateManager.refreshWeather(context, showAlertBanner = true, forceRefresh = true)
      },
      onShowInCapsule = {
        IslandStateManager.showWeatherCard(context)
      },
      onDismiss = { showWeatherWindow = false }
    )
  }

  if (updateState.isUpdateAvailable && !updateState.isDismissedForSession) {
    GitHubUpdateAvailableDialog(
      updateState = updateState,
      isInstallPackagesGranted = isInstallPackagesGranted,
      onDownloadNow = {
        GitHubUpdateManager.startUpdateDownload(context)
      },
      onInstallNow = {
        GitHubUpdateManager.installDownloadedUpdate(context)
      },
      onRequestInstallPermission = {
        GitHubUpdateManager.openInstallUnknownAppsSettings(context)
      },
      onCancelDownload = {
        GitHubUpdateManager.cancelDownload(context)
      },
      onOpenDownloads = {
        GitHubUpdateManager.openDownloadsFolder(context)
      },
      onOpenReleasePage = {
        GitHubUpdateManager.openReleasePage(context)
      },
      onDismiss = {
        GitHubUpdateManager.dismissUpdateDialog()
      }
    )
  }
}

@Composable
private fun HeaderBanner(
  serviceEnabled: Boolean,
  coreMissing: Boolean,
  accentColor: Color,
  currentTheme: AppThemeOption,
  hasUpdateAvailable: Boolean = false,
  onUpdateBadgeClick: () -> Unit = {},
  onThemeClick: () -> Unit,
  onStatusClick: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(
      modifier = Modifier.weight(1f),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        modifier = Modifier
          .width(4.dp)
          .height(30.dp)
          .clip(CircleShape)
          .background(Brush.verticalGradient(listOf(PalettePrimary, PaletteSecondary)))
      )
      Column {
        Text(
          text = "Dynamic Capsule",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = if (coreMissing) "أكمل الصلاحيات الأساسية لتشغيل الكبسولة" else "تطوير: مصطفى • ${currentTheme.titleAr}",
          color = if (coreMissing) PaletteWarning else PalettePrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      if (hasUpdateAvailable) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = PaletteSuccess.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, PaletteSuccess.copy(alpha = 0.55f)),
          modifier = Modifier
            .testTag("header_update_available_badge")
            .clickable(onClick = onUpdateBadgeClick)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Download,
              contentDescription = "يتوفر تحديث جديد",
              tint = PaletteSuccess,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = "تحديث",
              color = PaletteSuccess,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = PalettePrimary.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.45f)),
        modifier = Modifier
          .testTag("header_theme_button")
          .clickable(onClick = onThemeClick)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Palette,
            contentDescription = "تغيير الثيم",
            tint = PalettePrimary,
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = currentTheme.badgeAr,
            color = PalettePrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      val statusColor = when {
        serviceEnabled -> PaletteSuccess
        coreMissing -> PaletteWarning
        else -> PaletteError
      }
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = statusColor.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.55f)),
        modifier = Modifier.clickable(onClick = onStatusClick)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(statusColor)
          )
          Text(
            text = if (serviceEnabled) "نشطة" else if (coreMissing) "ناقص" else "متوقفة",
            color = statusColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

@Composable
private fun QuickStatusBentoRow(
  serviceActive: Boolean,
  coreMissing: Boolean,
  currentTheme: AppThemeOption,
  grantedCount: Int,
  totalCount: Int,
  onToggleService: () -> Unit,
  onOpenThemePicker: () -> Unit
) {
  val serviceTint = when {
    serviceActive -> PaletteSuccess
    coreMissing -> PaletteWarning
    else -> PaletteError
  }
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    ThemedCard(
      modifier = Modifier
        .weight(1f)
        .clickable(onClick = onToggleService),
      variant = CardVariant.UTILITY_COMPACT,
      cornerRadius = 18.dp
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.Default.Tune, tint = serviceTint, size = 32.dp, iconSize = 17.dp)
          Box(
            modifier = Modifier
              .clip(CircleShape)
              .background(serviceTint.copy(alpha = 0.16f))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = if (serviceActive) "تعمل" else "متوقفة",
              color = serviceTint,
              fontSize = 10.sp,
              fontWeight = FontWeight.ExtraBold
            )
          }
        }
        Text("الكبسولة العائمة", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(
          text = "الصلاحيات: $grantedCount/$totalCount",
          color = TextSecondary,
          fontSize = 11.sp
        )
      }
    }

    ThemedCard(
      modifier = Modifier
        .weight(1f)
        .clickable(onClick = onOpenThemePicker),
      variant = CardVariant.UTILITY_COMPACT,
      cornerRadius = 18.dp
    ) {
      Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.Default.Palette, tint = PalettePrimary, size = 32.dp, iconSize = 17.dp)
          Box(
            modifier = Modifier
              .size(14.dp)
              .clip(CircleShape)
              .background(currentTheme.previewAccent)
              .border(1.dp, TextPrimary.copy(alpha = 0.45f), CircleShape)
          )
        }
        Text("المظهر الحالي", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(
          text = currentTheme.titleAr,
          color = PalettePrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
private fun FreeColorStudioBannerButton(
  isCustomActive: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ThemedCard(
    modifier = modifier.clickable(onClick = onClick),
    variant = CardVariant.STUDIO_CREATIVE,
    cornerRadius = 18.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SectionIconBadge(icon = Icons.Default.ColorLens, tint = PaletteSecondary, size = 36.dp, iconSize = 19.dp)
        Column {
          Text(
            text = "استوديو الألوان الحر (تخصيص شامل)",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold
          )
          Text(
            text = if (isCustomActive) "مفعّل: ألوانك الحرة مطبقة على الأزرار والخلفية والكبسولة"
            else "غيّر كل ألوان الأزرار والخلفيات والنصوص والكبسولة بحرية تامة",
            color = if (isCustomActive) PaletteSecondary else TextSecondary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
      Spacer(modifier = Modifier.width(8.dp))
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = PaletteSecondary,
        contentColor = contrastOn(PaletteSecondary)
      ) {
        Text(
          text = if (isCustomActive) "تعديل" else "ألوان حرة",
          color = contrastOn(PaletteSecondary),
          fontSize = 11.sp,
          fontWeight = FontWeight.ExtraBold,
          modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
        )
      }
    }
  }
}

@Composable
private fun PermissionsReadinessCard(
  grantedCount: Int,
  totalCount: Int,
  accentColor: Color
) {
  val fraction = (grantedCount.toFloat() / totalCount.coerceAtLeast(1)).coerceIn(0f, 1f)
  val readinessColor = when {
    grantedCount == totalCount -> PaletteSuccess
    grantedCount >= 5 -> PalettePrimary
    else -> PaletteWarning
  }
  ThemedCard(
    variant = CardVariant.STATUS_REACTIVE,
    statusColor = readinessColor
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          SectionIconBadge(icon = Icons.Default.Security, tint = readinessColor, size = 34.dp, iconSize = 18.dp)
          Text("جاهزية صلاحيات النظام", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Surface(
          shape = CircleShape,
          color = readinessColor.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, readinessColor.copy(alpha = 0.40f))
        ) {
          Text(
            text = "$grantedCount / $totalCount مفعلة",
            color = readinessColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }
      LinearProgressIndicator(
        progress = { fraction },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(CircleShape),
        color = readinessColor,
        trackColor = DarkSurfaceCard
      )
    }
  }
}

@Composable
private fun LivePreviewCard(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  previewMode: CapsuleMode,
  onModeToggle: () -> Unit,
  onPreviewWeather: () -> Unit = {},
  onPreviewSteps: () -> Unit = {},
  onPreviewMusic: () -> Unit = {},
  onPreviewFocus: () -> Unit = {},
  onPreviewDelivery: () -> Unit = {},
  onPreviewFootball: () -> Unit = {},
  onPreviewPrayer: () -> Unit = {},
  onOpenWeatherWindow: () -> Unit = {}
) {
  ThemedCard(variant = CardVariant.HERO_PREVIEW) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          SectionIconBadge(icon = Icons.Default.GraphicEq, tint = PalettePrimary)
          Text(
            text = "معاينة Dynamic Island",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }

        OutlinedButton(
          onClick = onModeToggle,
          modifier = Modifier.testTag("toggle_preview_mode_button"),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.5f)),
          colors = ButtonDefaults.outlinedButtonColors(
            containerColor = PalettePrimary.copy(alpha = 0.12f),
            contentColor = PalettePrimary
          )
        ) {
          Text(
            text = if (previewMode == CapsuleMode.MINI) "تبديل للموسعة" else "تبديل للمصغرة",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Simulated phone stage with live theme-matched mesh wallpaper
      val stagePalette = AppTheme.colors
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(Color(0xFF070709))
          .border(1.2.dp, stagePalette.primary.copy(alpha = 0.30f), RoundedCornerShape(24.dp))
      ) {
        Canvas(modifier = Modifier.matchParentSize()) {
          val w = size.width
          val h = size.height
          drawRect(
            brush = Brush.verticalGradient(
              colors = listOf(
                Color(0xFF0A0A0D),
                stagePalette.heroGradientStart.copy(alpha = 0.55f),
                Color(0xFF070709)
              )
            )
          )
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(stagePalette.primary.copy(alpha = 0.32f), Color.Transparent),
              center = Offset(w * 0.22f, h * 0.28f),
              radius = w * 0.60f
            ),
            center = Offset(w * 0.22f, h * 0.28f),
            radius = w * 0.60f
          )
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(stagePalette.secondary.copy(alpha = 0.26f), Color.Transparent),
              center = Offset(w * 0.80f, h * 0.72f),
              radius = w * 0.58f
            ),
            center = Offset(w * 0.80f, h * 0.72f),
            radius = w * 0.58f
          )
        }
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 22.dp, start = 12.dp, end = 12.dp),
          contentAlignment = Alignment.TopCenter
        ) {
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
          // System Status Bar (Clock on left, Signal/Battery on right - untouched and visible)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "9:41",
              color = Color.White.copy(alpha = 0.9f),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )

            // Small camera punch-hole indicator
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(Color(0xFF000000))
                .border(1.dp, Color(0xFF1E2532), CircleShape)
            )

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = "100%",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
              Box(
                modifier = Modifier
                  .width(18.dp)
                  .height(9.dp)
                  .border(1.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(2.dp))
                  .padding(1.dp)
              ) {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .background(RealmeGreen, RoundedCornerShape(1.dp))
                )
              }
            }
          }

          // Dynamic preview offset: shifts capsule position in real time with the slider
          val previewSpacing = (8 + (settings.notchOffsetYDp * 0.35f)).coerceIn(0f, 45f).dp
          Spacer(modifier = Modifier.height(previewSpacing))

          // Medium / Expanded Dynamic Capsule directly below status bar
          DynamicCapsuleView(
            trackInfo = trackInfo ?: MediaTrackInfo(
              title = "Far closer",
              artist = "David",
              isPlaying = true,
              durationMs = 236000L,
              currentPositionMs = 174000L
            ),
            settings = settings,
            mode = previewMode,
            onModeChange = { onModeToggle() }
          )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Quick Switcher Pills to preview Weather, Steps, Music & Focus directly inside the mockup
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf(
          Triple("موسيقى", PalettePrimary, onPreviewMusic),
          Triple("مواقيت الصلاة", PaletteSuccess, onPreviewPrayer),
          Triple("المباريات", PaletteSuccess, onPreviewFootball),
          Triple("التوصيل", PaletteWarning, onPreviewDelivery),
          Triple("الطقس", PaletteWarning, onPreviewWeather),
          Triple("نافذة الطقس", PaletteSecondary, onOpenWeatherWindow),
          Triple("الخطوات", PaletteSuccess, onPreviewSteps),
          Triple("التركيز", PaletteTertiary, onPreviewFocus)
        ).forEach { (label, col, action) ->
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(col.copy(alpha = 0.14f))
              .border(1.dp, col.copy(alpha = 0.42f), RoundedCornerShape(10.dp))
              .clickable(onClick = action)
              .padding(horizontal = 12.dp, vertical = 7.dp)
          ) {
            Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "اسحب للأعلى داخل الكبسولة للتبديل بين الأنشطة، أو يميناً/يساراً للإخفاء.",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
private fun DailyStepsRewardsCard(
  stepsState: StepsState,
  onShowCapsule: () -> Unit,
  onCycleGoal: () -> Unit
) {
  val starGold = Color(0xFFFFC107)
  val starsToday = stepsState.starsToday.coerceIn(0, 5)
  ThemedCard(
    variant = CardVariant.STATUS_REACTIVE,
    statusColor = PaletteSuccess,
    modifier = Modifier.testTag("daily_steps_rewards_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Top Row: Title + Cumulative Reward Stars Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(icon = Icons.AutoMirrored.Filled.DirectionsRun, tint = PaletteSuccess, size = 36.dp, iconSize = 19.dp)
          Column {
            Text("خطواتك اليوم ونجوم المكافأة", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            Text(
              text = "${stepsState.steps} / ${stepsState.dailyGoal} خطوة • ${String.format(Locale.US, "%.2f", stepsState.distanceKm)} كم • ${stepsState.caloriesKcal} سعرة",
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = starGold.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, starGold.copy(alpha = 0.50f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(Icons.Default.Star, contentDescription = null, tint = starGold, modifier = Modifier.size(14.dp))
            Text(
              text = "الرصيد: ${stepsState.totalRewardStars}",
              color = starGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold
            )
          }
        }
      }

      // Progress Bar
      LinearProgressIndicator(
        progress = { stepsState.goalFraction },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(CircleShape),
        color = PaletteSuccess,
        trackColor = DarkSurfaceCard
      )

      // 5 Daily Reward Star Tiers Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text = "نجوم اليوم: $starsToday من 5 ★",
            color = starGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold
          )
          Text(
            text = if (starsToday >= 5) "بطل اليوم! جمعت كل نجوم المكافأة"
            else "باقي ${stepsState.nextStarStepsRemaining} خطوة لفتح النجمة ${starsToday + 1}",
            color = TextSecondary,
            fontSize = 10.sp
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          for (i in 1..5) {
            val unlocked = i <= starsToday
            Box(
              modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(if (unlocked) starGold.copy(alpha = 0.22f) else DarkSurface)
                .border(1.dp, if (unlocked) starGold else DarkSurfaceBorder, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = if (unlocked) starGold else TextMuted,
                modifier = Modifier.size(15.dp)
              )
            }
          }
        }
      }

      // Recent Daily Step & Star Records (if > 1 day or today has progress)
      if (stepsState.recentHistory.size > 1) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          stepsState.recentHistory.forEachIndexed { idx, rec ->
            val isToday = idx == stepsState.recentHistory.lastIndex
            Column(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (isToday) PaletteSuccess.copy(alpha = 0.14f) else DarkSurfaceCard)
                .border(1.dp, if (isToday) PaletteSuccess.copy(alpha = 0.45f) else DarkSurfaceBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = if (isToday) "اليوم" else rec.dateKey.takeLast(5),
                color = if (isToday) PaletteSuccess else TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
              )
              Text("${rec.steps}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
              Text("${rec.stars}★", color = starGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedButton(
          onClick = onCycleGoal,
          modifier = Modifier.weight(1f),
          border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.45f)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("هدف: ${stepsState.dailyGoal}", color = PalettePrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Button(
          onClick = onShowCapsule,
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = PaletteSuccess, contentColor = contrastOn(PaletteSuccess)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("عرض بالكبسولة", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
      }
    }
  }
}

@Composable
private fun FlashlightQuickCard(
  isOn: Boolean,
  onToggle: () -> Unit
) {
  ThemedCard(
    variant = CardVariant.UTILITY_COMPACT,
    statusColor = if (isOn) PaletteWarning else null
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(if (isOn) PaletteWarning.copy(alpha = 0.22f) else DarkSurfaceCard)
            .border(1.dp, if (isOn) PaletteWarning.copy(alpha = 0.55f) else DarkSurfaceBorder, RoundedCornerShape(13.dp)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
            contentDescription = null,
            tint = if (isOn) PaletteWarning else PaletteWarning.copy(alpha = 0.78f),
            modifier = Modifier.size(22.dp)
          )
        }

        Column {
          Text("مصباح الهاتف (Flashlight)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text(if (isOn) "المصباح مضاء الآن" else "المصباح مطفأ", color = if (isOn) PaletteWarning else TextSecondary, fontSize = 12.sp)
        }
      }

      Button(
        onClick = onToggle,
        colors = if (isOn) {
          ButtonDefaults.buttonColors(
            containerColor = PaletteError.copy(alpha = 0.18f),
            contentColor = PaletteError
          )
        } else {
          ButtonDefaults.buttonColors(
            containerColor = PaletteSuccess,
            contentColor = Color(0xFF041D0E)
          )
        },
        border = if (isOn) BorderStroke(1.dp, PaletteError.copy(alpha = 0.55f)) else null,
        shape = RoundedCornerShape(12.dp)
      ) {
        Text(if (isOn) "إطفاء" else "تشغيل", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }
  }
}

@Composable
private fun AnimationStudioCard(
  settings: CapsuleSettings,
  accentColor: Color,
  onSelectOpenAnimation: (Int) -> Unit,
  onSelectAuraAnimation: (Int) -> Unit,
  onSelectVisualizerStyle: (Int) -> Unit,
  onPreviewAnimation: () -> Unit
) {
  ThemedCard(
    modifier = Modifier.testTag("animation_studio_card"),
    variant = CardVariant.STUDIO_CREATIVE
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(icon = Icons.Default.AutoAwesome, tint = PaletteSecondary)
          Column {
            Text(
              text = "أستوديو الأنميشن والحركة",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "اختر ومزج أنميشن الفتح، توهج الإطار، والموجات بحرية كاملة",
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
        }

        Button(
          onClick = onPreviewAnimation,
          modifier = Modifier.testTag("preview_animation_button"),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = PalettePrimary.copy(alpha = 0.16f),
            contentColor = PalettePrimary
          ),
          border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.45f)),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("تجربة الآن", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      // 1. Open / Expand Physics
      AnimationCategoryRow(
        title = "حركة فتح وتمدد الكبسولة (5 أنماط)",
        options = listOf(
          "نابض مرن",
          "نبضة سائلة",
          "انزلاق عمودي",
          "تكبير 3D",
          "فوري حاد"
        ),
        selectedIndex = settings.openAnimationIndex,
        accentColor = PalettePrimary,
        tagPrefix = "open_anim_chip",
        onSelect = onSelectOpenAnimation
      )

      // 2. Live Border / Aura Effects
      AnimationCategoryRow(
        title = "أنميشن الإضاءة والإطار الحي (5 تأثيرات)",
        options = listOf(
          "كلاسيكي هادئ",
          "قوس قزح دوّار",
          "نبض مضيء",
          "ليزر مزدوج",
          "تفاعل صوتي"
        ),
        selectedIndex = settings.auraAnimationIndex,
        accentColor = PaletteSecondary,
        tagPrefix = "aura_anim_chip",
        onSelect = onSelectAuraAnimation
      )

      // 3. Visualizer Waveform Styles
      AnimationCategoryRow(
        title = "شكل الموجات الصوتية (4 أنماط)",
        options = listOf(
          "أعمدة كلاسيكية",
          "موجة ناعمة",
          "نقاط نبضية",
          "طيف متماثل"
        ),
        selectedIndex = settings.visualizerStyleIndex,
        accentColor = PaletteSecondary,
        tagPrefix = "viz_anim_chip",
        onSelect = onSelectVisualizerStyle
      )
    }
  }
}

@Composable
private fun AnimationCategoryRow(
  title: String,
  options: List<String>,
  selectedIndex: Int,
  accentColor: Color,
  tagPrefix: String,
  onSelect: (Int) -> Unit
) {
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Text(
      text = title,
      color = TextPrimary,
      fontSize = 12.sp,
      fontWeight = FontWeight.SemiBold
    )
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      options.forEachIndexed { idx, label ->
        val selected = selectedIndex == idx
        Box(
          modifier = Modifier
            .testTag("${tagPrefix}_$idx")
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accentColor.copy(alpha = 0.22f) else DarkSurfaceCard)
            .border(
              width = 1.dp,
              color = if (selected) accentColor else DarkSurfaceBorder,
              shape = RoundedCornerShape(12.dp)
            )
            .clickable { onSelect(idx) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = label,
            color = if (selected) accentColor else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
          )
        }
      }
    }
  }
}

@Composable
private fun FavoriteTracksLauncherCard(
  favorites: List<FavoriteTrack>,
  accentColor: Color,
  onOpenLibrary: () -> Unit
) {
  ThemedCard(
    modifier = Modifier.testTag("favorites_card"),
    variant = CardVariant.UTILITY_COMPACT
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(
            icon = Icons.Default.Favorite,
            tint = PaletteError,
            size = 42.dp,
            iconSize = 21.dp
          )
          Column {
            Text(
              text = "مكتبة الأغاني المفضلة",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (favorites.isEmpty()) {
                "اضغط ♥ داخل الكبسولة لحفظ أغانيك هنا"
              } else {
                "آخر محفوظة: ${favorites.first().title}"
              },
              color = TextSecondary,
              fontSize = 11.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = PaletteError.copy(alpha = 0.14f),
          border = BorderStroke(1.dp, PaletteError.copy(alpha = 0.42f))
        ) {
          Text(
            text = "${favorites.size} أغنية",
            color = PaletteError,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
          )
        }
      }

      Button(
        onClick = onOpenLibrary,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("open_favorites_window_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = PalettePrimary.copy(alpha = 0.18f),
          contentColor = PalettePrimary
        ),
        border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(14.dp)
      ) {
        Icon(
          imageVector = Icons.Default.MusicNote,
          contentDescription = null,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "فتح نافذة الأغاني المحفوظة (${favorites.size})",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}

@Composable
private fun FavoritesLibraryWindow(
  favorites: List<FavoriteTrack>,
  accentColor: Color,
  onPlayTrack: (FavoriteTrack) -> Unit,
  onShareTrack: (FavoriteTrack) -> Unit,
  onRemoveTrack: (FavoriteTrack) -> Unit,
  onClearAll: () -> Unit,
  onDismiss: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedAppFilter by remember { mutableStateOf<String?>(null) }

  val availableApps = remember(favorites) {
    favorites.map { it.appName.trim() }.filter { it.isNotEmpty() }.distinct()
  }

  val filteredFavorites = remember(favorites, searchQuery, selectedAppFilter) {
    val q = searchQuery.trim().lowercase()
    favorites.filter { track ->
      val matchesApp = selectedAppFilter == null || track.appName.equals(selectedAppFilter, ignoreCase = true)
      val matchesQuery = q.isEmpty() ||
        track.title.lowercase().contains(q) ||
        track.artist.lowercase().contains(q) ||
        track.appName.lowercase().contains(q)
      matchesApp && matchesQuery
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    BackHandler { onDismiss() }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("favorites_library_window"),
      color = DarkBackground
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Window Top Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(DarkSurfaceCard)
                .testTag("close_favorites_window_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "إغلاق نافذة المفضلة",
                tint = TextPrimary
              )
            }

            Column {
              Text(
                text = "مكتبة الأغاني المفضلة",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${favorites.size} أغنية محفوظة",
                color = accentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          if (favorites.isNotEmpty()) {
            TextButton(onClick = onClearAll) {
              Text(
                text = "مسح الكل",
                color = PaletteError,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Search Bar
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = {
            Text("ابحث باسم الأغنية أو الفنان أو التطبيق...", color = TextMuted, fontSize = 13.sp)
          },
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = null, tint = accentColor)
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Close, contentDescription = "مسح البحث", tint = TextSecondary)
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = DarkSurfaceBorder,
            focusedContainerColor = DarkSurface,
            unfocusedContainerColor = DarkSurface,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("favorites_search_input")
        )

        // Source App Filter Chips
        if (availableApps.isNotEmpty()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val allSelected = selectedAppFilter == null
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (allSelected) accentColor.copy(alpha = 0.22f) else DarkSurface)
                .border(
                  1.dp,
                  if (allSelected) accentColor else DarkSurfaceBorder,
                  RoundedCornerShape(10.dp)
                )
                .clickable { selectedAppFilter = null }
                .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
              Text(
                text = "الكل (${favorites.size})",
                color = if (allSelected) accentColor else TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }

            availableApps.forEach { appName ->
              val isSelected = selectedAppFilter.equals(appName, ignoreCase = true)
              val count = favorites.count { it.appName.equals(appName, ignoreCase = true) }
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) accentColor.copy(alpha = 0.22f) else DarkSurface)
                  .border(
                    1.dp,
                    if (isSelected) accentColor else DarkSurfaceBorder,
                    RoundedCornerShape(10.dp)
                  )
                  .clickable { selectedAppFilter = if (isSelected) null else appName }
                  .padding(horizontal = 12.dp, vertical = 7.dp)
              ) {
                Text(
                  text = "$appName ($count)",
                  color = if (isSelected) accentColor else TextSecondary,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }

        // Scrollable Song Library List
        if (filteredFavorites.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
              modifier = Modifier.padding(24.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(64.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFF5252).copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Favorite,
                  contentDescription = null,
                  tint = Color(0xFFFF5252),
                  modifier = Modifier.size(30.dp)
                )
              }
              Text(
                text = if (favorites.isEmpty()) "لا توجد أغاني مفضلة بعد" else "لا توجد نتائج مطابقة لبحثك",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = if (favorites.isEmpty()) {
                  "عند تشغيل أي موسيقى أو فيديو، كبّر الكبسولة واضغط على أيقونة القلب ♥ ليتم حفظها هنا تلقائياً."
                } else {
                  "جرّب تغيير كلمة البحث أو إزالة فلتر التطبيق."
                },
                color = TextSecondary,
                fontSize = 12.sp
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
          ) {
            items(filteredFavorites, key = { it.id }) { fav ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(16.dp))
                  .background(DarkSurface)
                  .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                  .clickable { onPlayTrack(fav) }
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.16f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                  )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = fav.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  val subParts = listOfNotNull(
                    fav.artist.takeIf { it.isNotBlank() },
                    fav.appName.takeIf { it.isNotBlank() },
                    fav.formatDuration().takeIf { it != "--:--" }
                  )
                  Text(
                    text = subParts.joinToString(" • ").ifBlank { "مقطع محفوظ" },
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }

                IconButton(
                  onClick = { onPlayTrack(fav) },
                  modifier = Modifier.size(48.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "تشغيل الأغنية",
                    tint = PaletteSuccess,
                    modifier = Modifier.size(22.dp)
                  )
                }

                IconButton(
                  onClick = { onShareTrack(fav) },
                  modifier = Modifier.size(48.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "مشاركة الأغنية",
                    tint = PalettePrimary,
                    modifier = Modifier.size(19.dp)
                  )
                }

                IconButton(
                  onClick = { onRemoveTrack(fav) },
                  modifier = Modifier.size(48.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "إزالة من المفضلة",
                    tint = PaletteError,
                    modifier = Modifier.size(19.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FavoriteTeamsLauncherCard(
  favoriteTeams: List<String>,
  accentColor: Color,
  onOpenWindow: () -> Unit
) {
  ThemedCard(
    modifier = Modifier.fillMaxWidth(),
    variant = CardVariant.UTILITY_COMPACT
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(
            icon = Icons.Default.SportsSoccer,
            tint = accentColor,
            size = 42.dp,
            iconSize = 21.dp
          )
          Column {
            Text(
              text = "الفرق المفضلة (كرة القدم)",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (favoriteTeams.isEmpty()) {
                "أضف أنديتك المفضلة لإعطاء الأولوية لمبارياتها وتنبيهاتها"
              } else {
                "المحفوظة: ${favoriteTeams.joinToString(" • ")}"
              },
              color = TextSecondary,
              fontSize = 11.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = accentColor.copy(alpha = 0.14f),
          border = BorderStroke(1.dp, accentColor.copy(alpha = 0.42f))
        ) {
          Text(
            text = "${favoriteTeams.size} فريق",
            color = accentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
          )
        }
      }

      Button(
        onClick = onOpenWindow,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("open_favorite_teams_window_button_preview"),
        colors = ButtonDefaults.buttonColors(
          containerColor = accentColor.copy(alpha = 0.18f),
          contentColor = accentColor
        ),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(14.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Star,
          contentDescription = null,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "فتح نافذة الفرق المفضلة (${favoriteTeams.size})",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}

@Composable
private fun FavoriteTeamsWindow(
  favoriteTeams: List<String>,
  liveMatches: List<com.example.island.FootballMatchItem>,
  accentColor: Color,
  onAddTeam: (String) -> Boolean,
  onRemoveTeam: (String) -> Boolean,
  onOpenTeamInCapsule: (String, (Boolean) -> Unit) -> Unit,
  onClearAll: () -> Unit,
  onDismiss: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf<String?>(null) }
  var feedbackState by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
  var selectedDetailTeam by remember { mutableStateOf<String?>(null) }
  val discoveredTeamMedia by FootballRepository.teamMediaFlow.collectAsState()

  val categories = remember {
    listOf("الكل", "مباريات اليوم", "دوري روشن", "الإسباني", "الإنجليزي", "الإيطالي", "الألماني / الأبطال", "منتخبات")
  }

  val catalogPool = remember(liveMatches) {
    val liveTeams = buildList {
      liveMatches.forEach { m ->
        if (m.homeTeam.isNotBlank()) {
          val resolved = FootballRepository.resolveTeamCatalogEntry(m.homeTeam)
          add(
            resolved ?: FootballTeamSuggestion(
              arabicName = m.homeTeam,
              englishName = m.homeTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباريات اليوم" },
              aliases = listOfNotNull(m.homeAbbrev.takeIf { it.isNotBlank() }),
              logoUrl = m.homeLogoUrl,
              shortCode = m.homeAbbrev
            )
          )
        }
        if (m.awayTeam.isNotBlank()) {
          val resolved = FootballRepository.resolveTeamCatalogEntry(m.awayTeam)
          add(
            resolved ?: FootballTeamSuggestion(
              arabicName = m.awayTeam,
              englishName = m.awayTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباريات اليوم" },
              aliases = listOfNotNull(m.awayAbbrev.takeIf { it.isNotBlank() }),
              logoUrl = m.awayLogoUrl,
              shortCode = m.awayAbbrev
            )
          )
        }
      }
    }
    (liveTeams + FootballRepository.getCatalogTeams())
      .distinctBy { "${it.arabicName}|${it.englishName.lowercase()}" }
  }

  val suggestedTeams = remember(searchQuery, selectedCategory, liveMatches, catalogPool, discoveredTeamMedia) {
    val q = searchQuery.trim()
    val base = if (q.isNotBlank()) {
      FootballRepository.suggestTeams(query = q, liveMatches = liveMatches, limit = 24)
    } else {
      catalogPool
    }
    when (selectedCategory) {
      null, "الكل" -> base
      "مباريات اليوم" -> base.filter { item ->
        liveMatches.any { m ->
          FootballRepository.areSameTeam(m.homeTeam, item.englishName) ||
            FootballRepository.areSameTeam(m.awayTeam, item.englishName)
        }
      }
      "الألماني / الأبطال" -> base.filter {
        it.leagueLabelAr.contains("الألماني") || it.leagueLabelAr.contains("الأبطال") || it.leagueLabelAr.contains("الفرنسي") || it.leagueLabelAr.contains("البرتغالي") || it.leagueLabelAr.contains("الهولندي")
      }
      else -> base.filter { it.leagueLabelAr.contains(selectedCategory!!) }
    }
  }

  val filteredFavorites = remember(favoriteTeams, searchQuery) {
    val q = searchQuery.trim()
    if (q.isBlank()) {
      favoriteTeams
    } else {
      favoriteTeams.filter { saved ->
        val entry = FootballRepository.resolveTeamCatalogEntry(saved)
        saved.contains(q, ignoreCase = true) ||
          (entry != null && (entry.arabicName.contains(q, ignoreCase = true) ||
            entry.englishName.contains(q, ignoreCase = true) ||
            entry.aliases.any { it.contains(q, ignoreCase = true) }))
      }
    }
  }

  fun handleAdd(displayName: String) {
    val clean = displayName.trim()
    if (clean.isBlank()) return
    val added = onAddTeam(clean)
    selectedDetailTeam = clean
    feedbackState = if (added) {
      "✓ تم حفظ \"$clean\" في الفرق المفضلة" to true
    } else {
      "\"$clean\" مضاف بالفعل في الفرق المفضلة" to true
    }
  }

  fun handleRemove(teamName: String) {
    val removed = onRemoveTeam(teamName)
    if (removed) {
      if (selectedDetailTeam != null && FootballRepository.areSameTeam(selectedDetailTeam!!, teamName)) {
        selectedDetailTeam = null
      }
      feedbackState = "تمت إزالة \"$teamName\" من الفرق المفضلة" to false
    }
  }

  fun handleFocusInCapsule(teamName: String) {
    selectedDetailTeam = teamName
    onOpenTeamInCapsule(teamName) { found ->
      if (!found) {
        feedbackState = "لا توجد مباراة لـ \"$teamName\" قيد اللعب أو مجدولة اليوم في البطولات" to false
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    BackHandler { onDismiss() }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("favorite_teams_window"),
      color = DarkBackground
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Window Top Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(DarkSurfaceCard)
                .testTag("close_favorite_teams_window_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "إغلاق نافذة الفرق المفضلة",
                tint = TextPrimary
              )
            }

            Column {
              Text(
                text = "الفرق المفضلة (كرة القدم)",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${favoriteTeams.size} فريق محفوظ • اضغط على اسم الفريق لعرضه بالكبسولة",
                color = accentColor,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }

          if (favoriteTeams.isNotEmpty()) {
            TextButton(
              onClick = {
                onClearAll()
                selectedDetailTeam = null
                feedbackState = "تم مسح جميع الفرق المفضلة" to false
              },
              modifier = Modifier.testTag("clear_all_favorite_teams_button")
            ) {
              Text(
                text = "مسح الكل",
                color = PaletteError,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Visible Feedback Status Banner
        AnimatedVisibility(visible = feedbackState != null) {
          val (msg, isPositive) = feedbackState ?: ("" to true)
          val bannerColor = if (isPositive) PaletteSuccess else PaletteWarning
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("favorite_teams_window_feedback")
              .clip(RoundedCornerShape(12.dp))
              .background(bannerColor.copy(alpha = 0.16f))
              .border(1.dp, bannerColor.copy(alpha = 0.50f), RoundedCornerShape(12.dp))
              .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = if (isPositive) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = null,
                tint = bannerColor,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = msg,
                color = bannerColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
            IconButton(
              onClick = { feedbackState = null },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إخفاء الرسالة",
                tint = TextSecondary,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }

        // Search & Add Bar with Live Matching Team Crest inside LeadingIcon
        val topMatchedTeam = if (searchQuery.isNotBlank()) suggestedTeams.firstOrNull() else null
        val topMatchedVisual = topMatchedTeam?.let {
          FootballRepository.resolveTeamVisual(it.arabicName, liveMatches, discoveredTeamMedia)
        }
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = {
            Text("ابحث عن فريق لإضافته أو إدارته (مثال: ريال، الهلال، برشلونة)...", color = TextMuted, fontSize = 12.sp)
          },
          leadingIcon = {
            if (topMatchedTeam != null && topMatchedVisual != null) {
              TeamCrestBadge(
                logoUrl = topMatchedVisual.logoUrl,
                teamName = topMatchedTeam.englishName,
                abbrev = topMatchedVisual.shortCode,
                accentColor = Color(topMatchedVisual.badgeColorHex),
                size = 28.dp
              )
            } else {
              Icon(Icons.Default.Search, contentDescription = null, tint = accentColor)
            }
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Close, contentDescription = "مسح البحث", tint = TextSecondary)
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = DarkSurfaceBorder,
            focusedContainerColor = DarkSurface,
            unfocusedContainerColor = DarkSurface,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("favorite_teams_window_search_input")
        )

        // Category Filter Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { category ->
            val selected = (selectedCategory == null && category == "الكل") || selectedCategory == category
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (selected) accentColor.copy(alpha = 0.22f) else DarkSurface)
                .border(
                  1.dp,
                  if (selected) accentColor else DarkSurfaceBorder,
                  RoundedCornerShape(10.dp)
                )
                .clickable { selectedCategory = if (category == "الكل") null else category }
                .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
              Text(
                text = category,
                color = if (selected) accentColor else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold
              )
            }
          }
        }

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 24.dp)
        ) {
          // Inspected / Newly Added Favorite Team Details Card
          val detailTeamName = selectedDetailTeam ?: favoriteTeams.firstOrNull()
          if (detailTeamName != null) {
            item(key = "team_details_card_$detailTeamName") {
              val details = FootballRepository.resolveTeamDetails(detailTeamName, liveMatches, discoveredTeamMedia)
              val badgeColor = Color(details.badgeColorHex)
              val match = details.liveOrTodayMatch
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("favorite_team_details_card")
                  .clip(RoundedCornerShape(16.dp))
                  .background(badgeColor.copy(alpha = 0.11f))
                  .border(1.dp, badgeColor.copy(alpha = 0.48f), RoundedCornerShape(16.dp))
                  .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                  TeamCrestBadge(
                    logoUrl = details.logoUrl,
                    teamName = details.englishName,
                    abbrev = details.shortCode,
                    accentColor = badgeColor,
                    size = 46.dp
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                      Text(
                        text = details.displayNameAr,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(6.dp))
                          .background(badgeColor.copy(alpha = 0.22f))
                          .padding(horizontal = 6.dp, vertical = 2.dp)
                      ) {
                        Text(
                          text = details.shortCode,
                          color = badgeColor,
                          fontSize = 10.sp,
                          fontWeight = FontWeight.ExtraBold
                        )
                      }
                    }
                    val metaParts = listOfNotNull(
                      details.englishName.takeIf { !it.equals(details.displayNameAr, ignoreCase = true) },
                      details.leagueLabelAr.takeIf { it.isNotBlank() },
                      details.countryAr.takeIf { it.isNotBlank() }
                    )
                    if (metaParts.isNotEmpty()) {
                      Text(
                        text = metaParts.joinToString(" • "),
                        color = TextSecondary,
                        fontSize = 11.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                    }
                    if (details.infoAr.isNotBlank()) {
                      Text(
                        text = "الملعب / النبذة: ${details.infoAr}",
                        color = TextMuted,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                    }
                  }
                }

                if (match != null) {
                  val isActivePlay = match.isLive && !match.isFinished
                  val matchStatusText = if (isActivePlay) {
                    "تلعب الآن: ${match.homeTeam} ${match.homeScore} - ${match.awayScore} ${match.awayTeam} (${match.formattedLiveTime()})"
                  } else if (match.isFinished) {
                    "آخر نتيجة اليوم: ${match.homeTeam} ${match.homeScore} - ${match.awayScore} ${match.awayTeam} (${match.minuteOrStatus})"
                  } else {
                    "مباراة اليوم: ${match.homeTeam} × ${match.awayTeam} (${match.minuteOrStatus})"
                  }
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(12.dp))
                      .background(DarkSurface.copy(alpha = 0.85f))
                      .clickable { handleFocusInCapsule(detailTeamName) }
                      .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = matchStatusText,
                      color = if (isActivePlay) PaletteSuccess else TextPrimary,
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.weight(1f),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "عرض بالكبسولة ←",
                      color = accentColor,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.ExtraBold
                    )
                  }
                } else {
                  Text(
                    text = "لا توجد مباراة نشطة الآن؛ سيتم إظهارها وتنبيهك بالأهداف تلقائياً فور بدايتها.",
                    color = TextSecondary,
                    fontSize = 11.sp
                  )
                }
              }
            }
          }

          // Section 1: Saved Favorite Teams
          item(key = "saved_header") {
            Text(
              text = "الفرق المحفوظة في المفضلة (${favoriteTeams.size})",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.ExtraBold,
              modifier = Modifier.padding(top = 4.dp)
            )
          }

          if (filteredFavorites.isEmpty()) {
            item(key = "saved_empty") {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(16.dp))
                  .background(DarkSurface)
                  .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                  .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.SportsSoccer,
                  contentDescription = null,
                  tint = accentColor.copy(alpha = 0.75f),
                  modifier = Modifier.size(30.dp)
                )
                Text(
                  text = if (favoriteTeams.isEmpty()) "لا توجد فرق مفضلة محفوظة بعد" else "لا يوجد فريق محفوظ يطابق البحث",
                  color = TextPrimary,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = if (favoriteTeams.isEmpty()) {
                    "ابحث عن فريقك المفضل بالأعلى أو اضغط \"إضافة\" على أي نادٍ في القائمة أدناه لحفظه."
                  } else {
                    "جرّب مسح البحث لعرض فرقك المحفوظة أو أضف فريقاً جديداً من القائمة بالأسفل."
                  },
                  color = TextSecondary,
                  fontSize = 11.5.sp
                )
              }
            }
          } else {
            items(
              items = filteredFavorites,
              key = { "saved_$it" }
            ) { savedTeam ->
              val idx = favoriteTeams.indexOf(savedTeam).coerceAtLeast(0)
              val details = FootballRepository.resolveTeamDetails(savedTeam, liveMatches, discoveredTeamMedia)
              val teamColor = Color(details.badgeColorHex)
              val liveMatch = details.liveOrTodayMatch
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("saved_favorite_team_row_$idx")
                  .clip(RoundedCornerShape(16.dp))
                  .background(teamColor.copy(alpha = 0.10f))
                  .border(1.dp, teamColor.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(
                  modifier = Modifier
                    .weight(1f)
                    .clickable { handleFocusInCapsule(savedTeam) },
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  TeamCrestBadge(
                    logoUrl = details.logoUrl,
                    teamName = details.englishName,
                    abbrev = details.shortCode,
                    accentColor = teamColor,
                    size = 42.dp
                  )

                  Spacer(modifier = Modifier.width(12.dp))

                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = savedTeam,
                      color = TextPrimary,
                      fontSize = 14.sp,
                      fontWeight = FontWeight.Bold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                    val sub = listOfNotNull(
                      details.leagueLabelAr.takeIf { it.isNotBlank() },
                      details.countryAr.takeIf { it.isNotBlank() },
                      details.infoAr.takeIf { it.isNotBlank() }
                    ).joinToString(" • ").ifBlank { "أولوية في النتائج والتنبيهات" }
                    Text(
                      text = sub,
                      color = TextSecondary,
                      fontSize = 11.sp,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                    val matchLine = when {
                      liveMatch != null && liveMatch.isLive && !liveMatch.isFinished ->
                        "🔴 مباشر: ${liveMatch.homeTeam} ${liveMatch.homeScore}-${liveMatch.awayScore} ${liveMatch.awayTeam} • اضغط للعرض"
                      liveMatch != null ->
                        "📅 ${liveMatch.homeTeam} × ${liveMatch.awayTeam} (${liveMatch.minuteOrStatus}) • اضغط للعرض"
                      else -> "اضغط للبحث وعرض المباراة بالكبسولة"
                    }
                    Text(
                      text = matchLine,
                      color = if (liveMatch != null && liveMatch.isLive && !liveMatch.isFinished) PaletteSuccess else teamColor,
                      fontSize = 10.5.sp,
                      fontWeight = FontWeight.SemiBold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedButton(
                  onClick = { handleRemove(savedTeam) },
                  modifier = Modifier
                    .height(48.dp)
                    .testTag("remove_favorite_team_window_button_$idx"),
                  border = BorderStroke(1.dp, PaletteError.copy(alpha = 0.55f)),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = PaletteError),
                  shape = RoundedCornerShape(12.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "إزالة $savedTeam من المفضلة",
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("إزالة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }

          // Section 2: Quick Add Custom Team when typing
          val trimmedQ = searchQuery.trim()
          val exactMatchExists = trimmedQ.isNotBlank() && suggestedTeams.any {
            it.arabicName.equals(trimmedQ, ignoreCase = true) ||
              it.englishName.equals(trimmedQ, ignoreCase = true)
          }
          if (trimmedQ.isNotBlank() && !exactMatchExists && favoriteTeams.none { FootballRepository.areSameTeam(it, trimmedQ) }) {
            item(key = "custom_add_team") {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("add_custom_favorite_team_button")
                  .clip(RoundedCornerShape(14.dp))
                  .background(PalettePrimary.copy(alpha = 0.14f))
                  .border(1.dp, PalettePrimary.copy(alpha = 0.50f), RoundedCornerShape(14.dp))
                  .clickable {
                    handleAdd(trimmedQ)
                    searchQuery = ""
                  }
                  .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "إضافة \"$trimmedQ\" كفريق مفضل",
                    color = PalettePrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "حفظ الاسم كما كتبته مباشرة في قائمة فرقك المفضلة",
                    color = TextSecondary,
                    fontSize = 11.sp
                  )
                }
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "إضافة الفريق",
                  tint = PalettePrimary
                )
              }
            }
          }

          // Section 3: Browse & Search Teams Catalog
          item(key = "catalog_header") {
            Text(
              text = if (searchQuery.isBlank()) "الأندية والمنتخبات المتاحة للإضافة" else "نتائج البحث عن الفرق",
              color = TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(top = 6.dp)
            )
          }

          items(
            items = suggestedTeams,
            key = { "cat_${it.arabicName}_${it.englishName}" }
          ) { item ->
            val matchingSavedName = favoriteTeams.firstOrNull { saved ->
              FootballRepository.areSameTeam(saved, item.arabicName) ||
                FootballRepository.areSameTeam(saved, item.englishName)
            }
            val isSaved = matchingSavedName != null
            val visual = FootballRepository.resolveTeamVisual(item.arabicName, liveMatches, discoveredTeamMedia)
            val clubColor = Color(visual.badgeColorHex)

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(DarkSurface)
                .border(
                  1.dp,
                  if (isSaved) accentColor.copy(alpha = 0.50f) else DarkSurfaceBorder,
                  RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                TeamCrestBadge(
                  logoUrl = visual.logoUrl.ifBlank { item.logoUrl },
                  teamName = item.englishName,
                  abbrev = visual.shortCode.ifBlank { item.shortCode },
                  accentColor = clubColor,
                  size = 38.dp
                )

                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = item.arabicName,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  val sub = listOfNotNull(
                    item.englishName.takeIf { !it.equals(item.arabicName, ignoreCase = true) },
                    item.leagueLabelAr.takeIf { it.isNotBlank() },
                    item.countryAr.takeIf { it.isNotBlank() }
                  ).joinToString(" • ")
                  if (sub.isNotBlank()) {
                    Text(
                      text = sub,
                      color = TextSecondary,
                      fontSize = 11.sp,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                  if (item.venueOrInfoAr.isNotBlank()) {
                    Text(
                      text = item.venueOrInfoAr,
                      color = TextMuted,
                      fontSize = 10.sp,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.width(8.dp))

              if (isSaved) {
                OutlinedButton(
                  onClick = { handleRemove(matchingSavedName!!) },
                  modifier = Modifier.height(48.dp),
                  border = BorderStroke(1.dp, PaletteError.copy(alpha = 0.45f)),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = PaletteError),
                  shape = RoundedCornerShape(10.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                  Icon(Icons.Default.Delete, contentDescription = "إزالة من المفضلة", modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("إزالة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              } else {
                Button(
                  onClick = { handleAdd(item.arabicName) },
                  modifier = Modifier.height(48.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor.copy(alpha = 0.18f),
                    contentColor = accentColor
                  ),
                  border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
                  shape = RoundedCornerShape(10.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                  Icon(Icons.Default.Add, contentDescription = "إضافة إلى المفضلة", modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("إضافة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ActivePlayerCard(
  trackInfo: MediaTrackInfo?,
  isListenerConnected: Boolean,
  accentColor: Color,
  onStartDemo: () -> Unit,
  onStartLongTitleDemo: () -> Unit,
  onStopDemo: () -> Unit
) {
  ThemedCard(variant = CardVariant.UTILITY_COMPACT) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SectionIconBadge(icon = Icons.Default.Tune, tint = PalettePrimary)
        Text(
          text = "مشغل الوسائط الحقيقي (Media Session)",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 2
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (trackInfo != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(PalettePrimary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.GraphicEq,
              contentDescription = null,
              tint = PalettePrimary,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            Text(
              text = "${trackInfo.artist} • ${trackInfo.appName}",
              color = TextSecondary,
              fontSize = 12.sp,
              maxLines = 1
            )
          }

          if (trackInfo.appName.contains("Demo")) {
            OutlinedButton(
              onClick = onStopDemo,
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              border = BorderStroke(1.dp, PaletteError.copy(alpha = 0.55f)),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = PaletteError.copy(alpha = 0.14f),
                contentColor = PaletteError
              )
            ) {
              Text("إيقاف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      } else {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (isListenerConnected)
              "جاهز للاتصال بمشغلات الموسيقى مثل Spotify وYouTube Music تلقائياً"
            else
              "يرجى منح صلاحية الإشعارات أدناه لقراءة الموسيقى",
            color = TextSecondary,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = onStartDemo,
              modifier = Modifier
                .weight(1f)
                .testTag("start_demo_track_button"),
              colors = ButtonDefaults.buttonColors(containerColor = PaletteSuccess, contentColor = Color(0xFF041D0E)),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("مقطع قياسي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = onStartLongTitleDemo,
              modifier = Modifier
                .weight(1f)
                .testTag("start_long_title_track_button"),
              colors = ButtonDefaults.buttonColors(
                containerColor = PalettePrimary.copy(alpha = 0.16f),
                contentColor = PalettePrimary
              ),
              border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.45f)),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("اسم طويل متحرك", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionsCard(
  canDrawOverlay: Boolean,
  isNotifListenerGranted: Boolean,
  isPostNotifGranted: Boolean,
  isCallPermissionGranted: Boolean,
  isActivityRecGranted: Boolean,
  isLocationGranted: Boolean,
  isBluetoothConnectGranted: Boolean,
  isBatteryOptIgnored: Boolean,
  isWriteSettingsGranted: Boolean,
  isInstallPackagesGranted: Boolean,
  accentColor: Color,
  onGrantOverlay: () -> Unit,
  onGrantListener: () -> Unit,
  onRequestPostNotif: () -> Unit,
  onRequestCallPerm: () -> Unit,
  onRequestActivityRec: () -> Unit,
  onRequestLocation: () -> Unit,
  onRequestBluetoothConnect: () -> Unit,
  onRequestBatteryOpt: () -> Unit,
  onRequestWriteSettings: () -> Unit,
  onRequestInstallPackages: () -> Unit
) {
  ThemedCard(variant = CardVariant.CONTROL_PANEL) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SectionIconBadge(icon = Icons.Default.Settings, tint = PaletteSuccess)
        Text(
          text = "صلاحيات النظام المطلوبة",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      PermissionItem(
        title = "الظهور فوق التطبيقات (Overlay)",
        description = "مطلوبة لعرض الكبسولة أعلى الشاشة دون حجب التطبيقات",
        isGranted = canDrawOverlay,
        icon = Icons.Default.Widgets,
        accentColor = PalettePrimary,
        onActionClick = onGrantOverlay
      )

      PermissionItem(
        title = "جلسات الوسائط والإشعارات (Media Listener)",
        description = "مطلوبة لقراءة الموسيقى والمؤقت والخرائط والتنزيلات والمكالمات",
        isGranted = isNotifListenerGranted,
        icon = Icons.Default.GraphicEq,
        accentColor = PaletteSecondary,
        onActionClick = onGrantListener
      )

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        PermissionItem(
          title = "قراءة اسم وبطارية البلوتوث (BLUETOOTH_CONNECT)",
          description = "تتيح عرض اسم السماعة المتصلة ونسبة بطاريتها داخل الكبسولة",
          isGranted = isBluetoothConnectGranted,
          icon = Icons.Default.BluetoothConnected,
          accentColor = PaletteSecondary,
          onActionClick = onRequestBluetoothConnect
        )
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        PermissionItem(
          title = "تتبع النشاط والخطوات (ACTIVITY_RECOGNITION)",
          description = "مطلوبة لقراءة مستشعر الخطوات وحساب المسافة اليومية بدقة",
          isGranted = isActivityRecGranted,
          icon = Icons.AutoMirrored.Filled.DirectionsRun,
          accentColor = PaletteSuccess,
          onActionClick = onRequestActivityRec
        )
      }

      PermissionItem(
        title = "الموقع الجغرافي للطقس المباشر (Location)",
        description = "مطلوبة لتحديد مدينتك وجلب درجة الحرارة والتوقعات تلقائياً",
        isGranted = isLocationGranted,
        icon = Icons.Default.LocationOn,
        accentColor = PaletteWarning,
        onActionClick = onRequestLocation
      )

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        PermissionItem(
          title = "الرد على المكالمات (ANSWER_PHONE_CALLS)",
          description = "تتيح الرد ورفض المكالمات مباشرة من الكبسولة عبر واجهات Android الرسمية",
          isGranted = isCallPermissionGranted,
          icon = Icons.Default.PhoneInTalk,
          accentColor = PaletteSuccess,
          onActionClick = onRequestCallPerm
        )
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        PermissionItem(
          title = "إشعارات الخدمة (Notifications)",
          description = "مطلوبة لتشغيل خدمة الكبسولة في الخلفية بثبات تام",
          isGranted = isPostNotifGranted,
          icon = Icons.Default.Notifications,
          accentColor = PalettePrimary,
          onActionClick = onRequestPostNotif
        )
      }

      PermissionItem(
        title = "استثناء توفير الطاقة (Battery Exemption)",
        description = "يمنع إغلاق خدمة الكبسولة بواسطة نظام إدارة الطاقة",
        isGranted = isBatteryOptIgnored,
        icon = Icons.Default.BatteryChargingFull,
        accentColor = PaletteSuccess,
        onActionClick = onRequestBatteryOpt
      )

      PermissionItem(
        title = "تعديل سطوع الشاشة (Write Settings)",
        description = "تتيح التحكم المباشر بسطوع الشاشة من شريط التحكم السريع بالكبسولة",
        isGranted = isWriteSettingsGranted,
        icon = Icons.Default.LightMode,
        accentColor = PaletteWarning,
        onActionClick = onRequestWriteSettings
      )

      PermissionItem(
        title = "تثبيت تحديثات التطبيق مباشرة (Install Packages)",
        description = "يتيح تثبيت تحديث APK مباشرة من داخل التطبيق دون فتح مدير الملفات",
        isGranted = isInstallPackagesGranted,
        icon = Icons.Default.Update,
        accentColor = PaletteSuccess,
        onActionClick = onRequestInstallPackages
      )
    }
  }
}

@Composable
private fun FeaturesHubCard(
  settings: CapsuleSettings,
  currentSoundMode: SoundMode,
  sleepTimerState: SleepTimerState,
  nextAlarmState: NextAlarmState,
  bluetoothState: BluetoothState,
  weatherState: WeatherState,
  stepsState: StepsState,
  compassState: CompassState,
  focusState: FocusState,
  deliveryState: DeliveryState,
  footballState: FootballState,
  prayerState: PrayerTimesState,
  accentColor: Color,
  onToggleFeature: (String, Boolean) -> Unit,
  onOpenAppFilter: () -> Unit,
  onTestBattery: () -> Unit,
  onTestCall: () -> Unit,
  onTestTimer: () -> Unit,
  onTestNotif: () -> Unit,
  onRefreshBluetooth: () -> Unit,
  onTestNetwork: () -> Unit,
  onToggleFlashlight: () -> Unit,
  onTestVolume: () -> Unit,
  onSelectSoundMode: (SoundMode) -> Unit,
  onCycleSoundMode: () -> Unit,
  onStartSleepTimer: (Int) -> Unit,
  onCancelSleepTimer: () -> Unit,
  onOpenAlarmApp: () -> Unit,
  onShowStepsCapsule: () -> Unit,
  onResetStepsToday: () -> Unit,
  onCycleStepsGoal: () -> Unit,
  onUpdateWeatherCity: (String) -> Unit,
  onRefreshWeatherNow: () -> Unit,
  onShowWeatherCapsule: () -> Unit,
  onOpenWeatherWindow: () -> Unit,
  onDeleteWeatherCity: () -> Unit,
  onOpenCompass: () -> Unit,
  onStartFocus: () -> Unit,
  onCancelFocus: () -> Unit,
  onTestDelivery: () -> Unit,
  onSelectFootballLeague: (String) -> Unit,
  onRefreshFootballNow: () -> Unit,
  onShowFootballCapsule: () -> Unit,
  onUpdateFootballReminderMinutes: (Int) -> Unit,
  onAddFavoriteFootballTeam: (String) -> Boolean,
  onRemoveFavoriteFootballTeam: (String) -> Boolean,
  onFocusTeamInCapsule: (String, (Boolean) -> Unit) -> Unit,
  onOpenFavoriteTeamsWindow: () -> Unit,
  onShowPrayerCapsule: () -> Unit,
  onRefreshPrayerNow: () -> Unit,
  onUpdatePrayerReminderMinutes: (Int) -> Unit,
  onUpdatePrayerOffset: (String, Int) -> Unit,
  onResetPrayerOffsets: () -> Unit
) {
  ThemedCard(variant = CardVariant.CONTROL_PANEL) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SectionIconBadge(icon = Icons.Default.Tune, tint = PaletteSecondary)
        Text(
          text = "ميزات النظام والأجهزة الحقيقية (Real Features)",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 1. Battery & Charging + Xiaomi HyperOS Speed & Telemetry
      FeatureRow(
        icon = Icons.Default.Bolt,
        title = "سرعة الشحن (واجهة شاومي Turbo) والبطارية",
        subtitle = "قياس الواط (W) والتيار الحقيقي (mA) والحرارة أثناء الشحن، وتنبيهات ≤20% والاكتمال 100%",
        isChecked = settings.enableBatteryAlerts,
        accentColor = PaletteSuccess,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_BATTERY_ALERTS, it) },
        testActionLabel = "معاينة الشحن",
        onTestAction = onTestBattery
      )

      // 2. Incoming & Ongoing Calls
      FeatureRow(
        icon = Icons.Default.Call,
        title = "المكالمات الجارية ومدتها",
        subtitle = "أزرار الرد والإغلاق وحساب المدة بعد الرد فقط",
        isChecked = settings.enableCallAlerts,
        accentColor = PaletteSuccess,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_CALL_ALERTS, it) },
        testActionLabel = "معاينة مكالمة",
        onTestAction = onTestCall
      )

      // 3. Sound Mode Indicator & Switcher (Ring, Vibrate, Silent, Muted DND)
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(
            icon = when (currentSoundMode) {
              SoundMode.RING -> Icons.Default.NotificationsActive
              SoundMode.VIBRATE -> Icons.Default.Vibration
              SoundMode.SILENT -> Icons.Default.NotificationsOff
              SoundMode.MUTED_DND -> Icons.Default.DoNotDisturbOn
            },
            tint = PaletteWarning,
            size = 38.dp,
            iconSize = 19.dp
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "وضع الصوت (رنين / اهتزاز / صامت / مكتوم)",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "الوضع الحالي: ${currentSoundMode.labelAr}",
              color = PaletteWarning,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
          Switch(
            checked = settings.enableRingerAlerts,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_RINGER_ALERTS, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteWarning)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          val modeItems = listOf(
            Triple(SoundMode.RING, "رنين", PaletteSuccess),
            Triple(SoundMode.VIBRATE, "اهتزاز", PaletteWarning),
            Triple(SoundMode.SILENT, "صامت", PaletteSecondary),
            Triple(SoundMode.MUTED_DND, "مكتوم", PaletteError)
          )
          modeItems.forEach { (mode, label, color) ->
            val selected = currentSoundMode == mode
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (selected) color.copy(alpha = 0.20f) else DarkSurface)
                .border(
                  width = 1.dp,
                  color = if (selected) color else DarkSurfaceBorder,
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { onSelectSoundMode(mode) }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                color = if (selected) color else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
              )
            }
          }
        }
      }

      // 4. Real Clock Timer & Stopwatch Sync
      FeatureRow(
        icon = Icons.Default.HourglassTop,
        title = "المؤقت وساعة الإيقاف (Clock Sync)",
        subtitle = "يتزامن تلقائياً مع أي مؤقت أو ساعة إيقاف تضبطها في تطبيق الساعة",
        isChecked = settings.enableTimer,
        accentColor = PaletteWarning,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_TIMER, it) },
        testActionLabel = "معاينة مؤقت 3د",
        onTestAction = onTestTimer
      )

      // 5. Real Download & Install Progress
      FeatureRow(
        icon = Icons.Default.Download,
        title = "تقدم التنزيلات والتثبيت (Downloads)",
        subtitle = "يعرض نسبة التحميل المباشرة من المتجر والمتصفح والنظام",
        isChecked = settings.enableDownloadProgress,
        accentColor = PaletteSecondary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_DOWNLOAD_PROGRESS, it) }
      )

      // 6. Live Navigation (Google Maps / Waze - Zero API)
      FeatureRow(
        icon = Icons.Default.Navigation,
        title = "الملاحة المباشرة (خرائط جوجل)",
        subtitle = "يعرض الاتجاه والوقت المتبقي للوصول تلقائياً دون الحاجة لأي API",
        isChecked = settings.enableNavigationAlerts,
        accentColor = PalettePrimary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_NAVIGATION_ALERTS, it) }
      )

      // 7. Camera, Mic & Voice Recorder Privacy Indicator
      FeatureRow(
        icon = Icons.Default.Security,
        title = "مؤشر الأمان (الكاميرا والميكروفون)",
        subtitle = "نقاط تنبيه خضراء/برتقالية فورية + تتبع مسجل الصوت عند التسجيل",
        isChecked = settings.enablePrivacyAlerts,
        accentColor = PaletteSuccess,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PRIVACY_ALERTS, it) }
      )

      // 8. Dual Split Capsule
      FeatureRow(
        icon = Icons.Default.Splitscreen,
        title = "الكبسولة المزدوجة (تعدد الأنشطة)",
        subtitle = "إظهار فقاعة دائرية جانبية عند تشغيل نشاطين معاً كالموسيقى والمؤقت",
        isChecked = settings.enableDualCapsule,
        accentColor = PaletteSecondary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_DUAL_CAPSULE, it) }
      )

      // 9. App Notifications + Excluded Apps Filter
      FeatureRow(
        icon = Icons.Default.Notifications,
        title = "إشعارات التطبيقات",
        subtitle = "بانر أنيق للرسائل مع إمكانية فتح التطبيق بالضغط",
        isChecked = settings.enableNotifications,
        accentColor = PalettePrimary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_NOTIFICATIONS, it) },
        testActionLabel = "معاينة إشعار",
        onTestAction = onTestNotif
      )

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .clickable(onClick = onOpenAppFilter)
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(icon = Icons.Default.FilterList, tint = PalettePrimary, size = 38.dp, iconSize = 19.dp)
          Column {
            Text("تصفية إشعارات التطبيقات", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = if (settings.excludedPackages.isEmpty())
                "جميع التطبيقات مفعّلة حالياً"
              else
                "تم استثناء ${settings.excludedPackages.size} تطبيق من الظهور",
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
        }
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = PalettePrimary.copy(alpha = 0.14f),
          border = BorderStroke(1.dp, PalettePrimary.copy(alpha = 0.40f))
        ) {
          Text(
            text = "تخصيص",
            color = PalettePrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
          )
        }
      }

      // 10. Bluetooth & Wired Headsets (Real Device Name & Battery %)
      FeatureRow(
        icon = Icons.Default.Headphones,
        title = "سماعات البلوتوث ونسبة البطارية",
        subtitle = when {
          bluetoothState.isConnected && bluetoothState.batteryPct in 0..100 ->
            "متصل الآن: ${bluetoothState.deviceName} (${bluetoothState.batteryPct}%)"
          bluetoothState.isConnected ->
            "متصل الآن: ${bluetoothState.deviceName}"
          else ->
            "يعرض اسم السماعة المتصلة ونسبة بطاريتها تلقائياً عند توفرها"
        },
        isChecked = settings.enableBluetoothAlerts,
        accentColor = PaletteSecondary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_BLUETOOTH_ALERTS, it) },
        testActionLabel = "فحص السماعة المتصلة",
        onTestAction = onRefreshBluetooth
      )

      // 10b. Daily Step Counter & Distance (Real Sensor)
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.AutoMirrored.Filled.DirectionsRun, tint = PaletteSuccess, size = 38.dp, iconSize = 19.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("عداد الخطوات اليومي ونجوم المكافأة", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = if (stepsState.hasHardwareSensor) {
                "${stepsState.steps} خطوة • ${String.format(Locale.US, "%.2f Km", stepsState.distanceKm)} • ${stepsState.starsToday}/5 ★ (الرصيد ${stepsState.totalRewardStars}★)"
              } else {
                "يتطلب مستشعر خطوات مدمج في الجهاز • الرصيد ${stepsState.totalRewardStars}★"
              },
              color = if (stepsState.hasHardwareSensor) PaletteSuccess else PaletteWarning,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
          Switch(
            checked = settings.enableStepsCounter,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_STEPS_COUNTER, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تثبيت الخطوات في الكبسولة المصغرة", color = TextSecondary, fontSize = 11.sp)
          Switch(
            checked = settings.pinStepsInCapsule,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PIN_STEPS, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf(
            Triple("عرض بالكبسولة", PaletteSuccess, onShowStepsCapsule),
            Triple("تغيير الهدف", PalettePrimary, onCycleStepsGoal),
            Triple("تصفير اليوم", PaletteError, onResetStepsToday)
          ).forEach { (label, col, action) ->
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(col.copy(alpha = 0.14f))
                .border(1.dp, col.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .clickable(onClick = action)
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // 10c. Live Auto-Updating Weather + Dedicated Weather & Cities Window Launcher
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.Default.WbSunny, tint = PaletteWarning, size = 38.dp, iconSize = 19.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("الطقس المباشر والمدن", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = when {
                weatherState.isLoaded -> buildString {
                  append("${weatherState.cityName}: ${weatherState.temperatureC}°C • ${weatherState.conditionAr}")
                  if (weatherState.resolvedCoordinatesLabel.isNotBlank()) {
                    append(" (${weatherState.resolvedCoordinatesLabel})")
                  }
                }
                !weatherState.errorMessage.isNullOrBlank() ->
                  weatherState.errorMessage!!
                else ->
                  "تنبؤ تلقائي بالمدينة + طقس حقيقي لحظي"
              },
              color = if (weatherState.isLoaded) PaletteWarning else TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
          Switch(
            checked = settings.enableWeatherAlerts,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_WEATHER_ALERTS, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteWarning)
          )
        }

        Button(
          onClick = onOpenWeatherWindow,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("open_weather_window_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = PalettePrimary,
            contentColor = contrastOn(PalettePrimary)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("فتح نافذة الطقس والمدن (تنبؤ / تعديل / حذف)", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تثبيت الطقس في الكبسولة المصغرة", color = TextSecondary, fontSize = 11.sp)
          Switch(
            checked = settings.pinWeatherInCapsule,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PIN_WEATHER, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteWarning)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(PaletteWarning.copy(alpha = 0.14f))
              .border(1.dp, PaletteWarning.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onRefreshWeatherNow)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("تحديث الطقس الآن", color = PaletteWarning, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(PalettePrimary.copy(alpha = 0.14f))
              .border(1.dp, PalettePrimary.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onShowWeatherCapsule)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("عرض بالكبسولة", color = PalettePrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          if (settings.hasCustomWeatherCity) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(PaletteError.copy(alpha = 0.14f))
                .border(1.dp, PaletteError.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .clickable(onClick = onDeleteWeatherCity)
                .padding(horizontal = 10.dp, vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("حذف المدينة", color = PaletteError, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // 10d. Real Digital Compass + Qibla Direction
      FeatureRow(
        icon = Icons.Default.Explore,
        title = "البوصلة الرقمية واتجاه القبلة",
        subtitle = if (compassState.isActive) {
          "الاتجاه: ${compassState.azimuthDeg.toInt()}° ${compassState.directionAr} • القبلة ${compassState.qiblaBearingDeg.toInt()}°"
        } else {
          "تحديد اتجاه الشمال والقبلة الحقيقي بالاعتماد على مستشعر المغناطيسية"
        },
        isChecked = settings.enableCompass,
        accentColor = PaletteSecondary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_COMPASS, it) },
        testActionLabel = "فتح البوصلة والقبلة",
        onTestAction = onOpenCompass
      )

      // 10d2. Islamic Prayer Times, Friday Jumu'ah & Manual Minute Offsets
      var showPrayerOffsets by remember { mutableStateOf(false) }
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.Default.Mosque, tint = PaletteSuccess, size = 38.dp, iconSize = 19.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Text(
                text = "مواقيت الصلاة والتنبيه قبل الأذان",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
              if (prayerState.isFriday) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(PaletteWarning.copy(alpha = 0.20f))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                  Text(
                    text = "الجمعة",
                    color = PaletteWarning,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.ExtraBold
                  )
                }
              }
            }
            Text(
              text = if (prayerState.isLoaded) {
                "القادمة: ${prayerState.nextPrayerNameAr} ${prayerState.nextPrayerTimeFormatted} (${prayerState.remainingLabel}) • ${prayerState.cityName}"
              } else {
                "حساب فلكي محلي دقيق للصلوات الخمس وصلاة الجمعة واتجاه القبلة"
              },
              color = if (prayerState.isLoaded) PaletteSuccess else TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
          Switch(
            checked = settings.enablePrayerAlerts,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PRAYER_ALERTS, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        if (prayerState.isLoaded && prayerState.prayers.isNotEmpty()) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            prayerState.prayers.chunked(3).forEach { rowItems ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                rowItems.forEach { item ->
                  val offsetVal = settings.prayerOffsetFor(item.key)
                  val isJumuah = prayerState.isFriday && item.key == "dhuhr"
                  val chipAccent = when {
                    item.isNext -> PaletteSuccess
                    isJumuah -> PaletteWarning
                    else -> TextSecondary
                  }
                  Column(
                    modifier = Modifier
                      .weight(1f)
                      .clip(RoundedCornerShape(10.dp))
                      .background(if (item.isNext) PaletteSuccess.copy(alpha = 0.14f) else DarkSurface)
                      .border(
                        width = 1.dp,
                        color = if (item.isNext) PaletteSuccess.copy(alpha = 0.55f) else DarkSurfaceBorder,
                        shape = RoundedCornerShape(10.dp)
                      )
                      .padding(vertical = 6.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = if (offsetVal != 0) "${item.nameAr} (${if (offsetVal > 0) "+$offsetVal" else "$offsetVal"})" else item.nameAr,
                      color = chipAccent,
                      fontSize = 9.5.sp,
                      fontWeight = if (item.isNext || isJumuah) FontWeight.ExtraBold else FontWeight.Medium,
                      maxLines = 1
                    )
                    Text(
                      text = item.timeFormatted,
                      color = TextPrimary,
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.ExtraBold,
                      maxLines = 1
                    )
                  }
                }
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تثبيت الصلاة القادمة في الكبسولة المصغرة", color = TextSecondary, fontSize = 11.sp)
          Switch(
            checked = settings.pinPrayerInCapsule,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PIN_PRAYER, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("التنبيه قبل الأذان:", color = TextSecondary, fontSize = 11.sp)
          listOf(5, 10, 15, 30).forEach { mins ->
            val selected = settings.prayerReminderMinutes == mins
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (selected) PaletteSuccess.copy(alpha = 0.22f) else DarkSurface)
                .border(
                  width = 1.dp,
                  color = if (selected) PaletteSuccess else DarkSurfaceBorder,
                  shape = RoundedCornerShape(8.dp)
                )
                .clickable { onUpdatePrayerReminderMinutes(mins) }
                .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${mins}د",
                color = if (selected) PaletteSuccess else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
              )
            }
          }
        }

        // Toggle Manual Prayer Time Adjustment Drawer
        val totalOffsetsActive = listOf("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha")
          .count { settings.prayerOffsetFor(it) != 0 }
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("toggle_prayer_offsets_button")
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurface)
            .border(1.dp, if (showPrayerOffsets) PaletteSuccess.copy(alpha = 0.55f) else DarkSurfaceBorder, RoundedCornerShape(10.dp))
            .clickable { showPrayerOffsets = !showPrayerOffsets }
            .padding(horizontal = 12.dp, vertical = 9.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Tune, contentDescription = null, tint = PaletteSuccess, modifier = Modifier.size(16.dp))
            Text(
              text = if (totalOffsetsActive > 0) {
                "تعديل أوقات الصلاة يدوياً ($totalOffsetsActive معدّلة)"
              } else {
                "تعديل أوقات الصلاة يدوياً (± دقائق)"
              },
              color = TextPrimary,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Text(
            text = if (showPrayerOffsets) "إخفاء" else "تعديل",
            color = PaletteSuccess,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }

        AnimatedVisibility(visible = showPrayerOffsets) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("prayer_offsets_editor")
              .clip(RoundedCornerShape(12.dp))
              .background(DarkSurface)
              .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
              .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val editablePrayers = listOf(
              "fajr" to "الفجر",
              "sunrise" to "الشروق",
              "dhuhr" to if (prayerState.isFriday) "الجمعة" else "الظهر / الجمعة",
              "asr" to "العصر",
              "maghrib" to "المغرب",
              "isha" to "العشاء"
            )
            editablePrayers.forEach { (key, label) ->
              val offset = settings.prayerOffsetFor(key)
              val currentItem = prayerState.prayers.firstOrNull { it.key == key }
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = label,
                    color = TextPrimary,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                  )
                  if (currentItem != null) {
                    Text(
                      text = currentItem.timeFormatted,
                      color = TextSecondary,
                      fontSize = 10.5.sp
                    )
                  }
                }
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .size(34.dp)
                      .testTag("prayer_offset_minus_$key")
                      .clip(RoundedCornerShape(9.dp))
                      .background(DarkSurfaceCard)
                      .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(9.dp))
                      .clickable { onUpdatePrayerOffset(key, offset - 1) },
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(Icons.Default.Remove, contentDescription = "إنقاص دقيقة", tint = TextPrimary, modifier = Modifier.size(16.dp))
                  }
                  Text(
                    text = when {
                      offset > 0 -> "+${offset}د"
                      offset < 0 -> "${offset}د"
                      else -> "0د"
                    },
                    color = if (offset == 0) TextSecondary else PaletteSuccess,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.width(38.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                  )
                  Box(
                    modifier = Modifier
                      .size(34.dp)
                      .testTag("prayer_offset_plus_$key")
                      .clip(RoundedCornerShape(9.dp))
                      .background(DarkSurfaceCard)
                      .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(9.dp))
                      .clickable { onUpdatePrayerOffset(key, offset + 1) },
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(Icons.Default.Add, contentDescription = "زيادة دقيقة", tint = TextPrimary, modifier = Modifier.size(16.dp))
                  }
                }
              }
            }

            if (totalOffsetsActive > 0) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("reset_prayer_offsets_button")
                  .clip(RoundedCornerShape(9.dp))
                  .background(PaletteError.copy(alpha = 0.14f))
                  .border(1.dp, PaletteError.copy(alpha = 0.45f), RoundedCornerShape(9.dp))
                  .clickable(onClick = onResetPrayerOffsets)
                  .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, tint = PaletteError, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "إعادة ضبط جميع التعديلات (0د)",
                  color = PaletteError,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .testTag("show_prayer_capsule_button")
              .clip(RoundedCornerShape(10.dp))
              .background(PaletteSuccess.copy(alpha = 0.14f))
              .border(1.dp, PaletteSuccess.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onShowPrayerCapsule)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("عرض بالكبسولة", color = PaletteSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          Box(
            modifier = Modifier
              .weight(1f)
              .testTag("open_qibla_compass_button")
              .clip(RoundedCornerShape(10.dp))
              .background(PalettePrimary.copy(alpha = 0.14f))
              .border(1.dp, PalettePrimary.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onOpenCompass)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("بوصلة القبلة (${prayerState.qiblaBearingDeg.toInt()}°)", color = PalettePrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      // 10e. Pomodoro Focus Timer
      FeatureRow(
        icon = Icons.Default.CenterFocusStrong,
        title = "مؤقت التركيز الذكي (Pomodoro Focus)",
        subtitle = if (focusState.isActive) {
          "جلسة نشطة: ${focusState.formatRemaining()}"
        } else {
          "جلسات تركيز 25/50 دقيقة + استراحة 5 دقائق مباشرة من الكبسولة"
        },
        isChecked = settings.enableFocusTimer,
        accentColor = PaletteTertiary,
        actionColor = if (focusState.isActive) PaletteError else PaletteSuccess,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_FOCUS_TIMER, it) },
        testActionLabel = if (focusState.isActive) "إنهاء الجلسة" else "بدء 25د تركيز",
        onTestAction = { if (focusState.isActive) onCancelFocus() else onStartFocus() }
      )

      // 10f. Live Delivery Orders Tracking (Talabat / HungerStation / Jahez / Noon / Courier)
      FeatureRow(
        icon = Icons.Default.DeliveryDining,
        title = "تتبع طلبات التوصيل (Delivery Live)",
        subtitle = if (deliveryState.isActive) {
          "${deliveryState.appName}: ${deliveryState.statusTitle}"
        } else {
          "يعرض حالة طلبك والوقت المتبقي لوصول المندوب تلقائياً من الإشعارات، واسحب للأعلى للتبديل"
        },
        isChecked = settings.enableDeliveryAlerts,
        accentColor = PaletteWarning,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_DELIVERY_ALERTS, it) },
        testActionLabel = "معاينة طلب توصيل",
        onTestAction = onTestDelivery
      )

      // 10g. Live Football Match Results & League Selector
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          val matchPreview = footballState.currentMatch
          if (matchPreview != null) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              TeamCrestBadge(
                logoUrl = matchPreview.homeLogoUrl,
                teamName = matchPreview.homeTeam,
                abbrev = matchPreview.homeAbbrev,
                accentColor = PaletteSuccess,
                size = 24.dp
              )
              TeamCrestBadge(
                logoUrl = matchPreview.awayLogoUrl,
                teamName = matchPreview.awayTeam,
                abbrev = matchPreview.awayAbbrev,
                accentColor = PaletteSecondary,
                size = 24.dp
              )
            }
          } else {
            SectionIconBadge(icon = Icons.Default.SportsSoccer, tint = PaletteSuccess, size = 38.dp, iconSize = 19.dp)
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("نتائج مباريات كرة القدم المباشرة", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = when {
                matchPreview != null -> "${matchPreview.homeTeam} ${matchPreview.homeScore}-${matchPreview.awayScore} ${matchPreview.awayTeam} (${matchPreview.formattedLiveTime()})"
                footballState.isLoading -> "جارٍ جلب المباريات..."
                !footballState.errorMessage.isNullOrBlank() -> footballState.errorMessage
                else -> "تحديث تلقائي للمباريات والنتائج الحية"
              },
              color = if (matchPreview != null) PaletteSuccess else TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
          Switch(
            checked = settings.enableFootballScores,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_FOOTBALL_SCORES, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        // League Selector Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          FootballLeague.entries.forEach { league ->
            val selected = settings.footballLeagueCode == league.code
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (selected) PaletteSuccess.copy(alpha = 0.22f) else DarkSurface)
                .border(
                  width = 1.dp,
                  color = if (selected) PaletteSuccess else DarkSurfaceBorder,
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { onSelectFootballLeague(league.code) }
                .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
              Text(
                text = league.labelAr,
                color = if (selected) PaletteSuccess else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
              )
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تثبيت المباريات في الكبسولة المصغرة", color = TextSecondary, fontSize = 11.sp)
          Switch(
            checked = settings.pinFootballInCapsule,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PIN_FOOTBALL, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteSuccess)
          )
        }

        // Pre-Match Kickoff Reminder Toggle + Lead Time Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("تذكير تلقائي قبل بداية المباراة", color = TextSecondary, fontSize = 11.sp)
          Switch(
            checked = settings.enablePreMatchReminder,
            onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_PRE_MATCH_REMINDER, it) },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PaletteWarning)
          )
        }

        if (settings.enablePreMatchReminder) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Text("وقت التذكير:", color = TextSecondary, fontSize = 11.sp)
            listOf(10, 15, 30, 45).forEach { mins ->
              val selected = settings.footballReminderMinutes == mins
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (selected) PaletteWarning.copy(alpha = 0.22f) else DarkSurface)
                  .border(
                    width = 1.dp,
                    color = if (selected) PaletteWarning else DarkSurfaceBorder,
                    shape = RoundedCornerShape(8.dp)
                  )
                  .clickable { onUpdateFootballReminderMinutes(mins) }
                  .padding(horizontal = 9.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "${mins}د",
                  color = if (selected) PaletteWarning else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
                )
              }
            }
          }
        }

        // Favorite Football Teams Manager + Instant Autocomplete + Crests + Details & Tap-to-Capsule
        val savedTeams = settings.effectiveFavoriteFootballTeams
        val discoveredTeamMedia by FootballRepository.teamMediaFlow.collectAsState()
        var favoriteTeamDraft by remember { mutableStateOf("") }
        var showTeamSuggestions by remember { mutableStateOf(false) }
        var teamActionFeedback by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
        var inspectedFavoriteTeam by remember { mutableStateOf<String?>(null) }
        val teamSuggestions = remember(favoriteTeamDraft, footballState.matches, discoveredTeamMedia) {
          FootballRepository.suggestTeams(
            query = favoriteTeamDraft,
            liveMatches = footballState.matches,
            limit = 8
          )
        }

        fun submitAddTeam(teamDisplayName: String) {
          val clean = teamDisplayName.trim()
          if (clean.isBlank()) return
          val added = onAddFavoriteFootballTeam(clean)
          favoriteTeamDraft = ""
          showTeamSuggestions = false
          inspectedFavoriteTeam = clean
          teamActionFeedback = if (added) {
            "✓ تم حفظ \"$clean\" في الفرق المفضلة" to true
          } else {
            "\"$clean\" مضاف بالفعل في المفضلة" to true
          }
        }

        fun triggerFocusSavedTeam(teamName: String) {
          inspectedFavoriteTeam = teamName
          onFocusTeamInCapsule(teamName) { found ->
            if (!found) {
              teamActionFeedback = "لا توجد مباراة لـ \"$teamName\" تلعب الآن أو مجدولة اليوم" to false
            }
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val inlineTopSuggestion = if (favoriteTeamDraft.isNotBlank()) teamSuggestions.firstOrNull() else null
            val inlineTopVisual = inlineTopSuggestion?.let {
              FootballRepository.resolveTeamVisual(it.arabicName, footballState.matches, discoveredTeamMedia)
            }
            OutlinedTextField(
              value = favoriteTeamDraft,
              onValueChange = { next ->
                favoriteTeamDraft = next
                showTeamSuggestions = next.isNotBlank()
              },
              modifier = Modifier
                .weight(1f)
                .testTag("favorite_team_input"),
              singleLine = true,
              label = { Text("ابحث لإضافة فريق مفضل", fontSize = 11.sp) },
              placeholder = { Text("مثال: ريال، برشلونة، الهلال، الأهلي...", fontSize = 11.sp) },
              leadingIcon = {
                if (inlineTopSuggestion != null && inlineTopVisual != null) {
                  TeamCrestBadge(
                    logoUrl = inlineTopVisual.logoUrl,
                    teamName = inlineTopSuggestion.englishName,
                    abbrev = inlineTopVisual.shortCode,
                    accentColor = Color(inlineTopVisual.badgeColorHex),
                    size = 26.dp
                  )
                } else {
                  Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = PaletteSuccess,
                    modifier = Modifier.size(18.dp)
                  )
                }
              },
              trailingIcon = {
                if (favoriteTeamDraft.isNotBlank()) {
                  IconButton(
                    onClick = {
                      favoriteTeamDraft = ""
                      showTeamSuggestions = false
                    }
                  ) {
                    Icon(
                      imageVector = Icons.Default.Close,
                      contentDescription = "مسح البحث",
                      tint = TextSecondary,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PaletteSuccess,
                unfocusedBorderColor = DarkSurfaceBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedLabelColor = PaletteSuccess,
                unfocusedLabelColor = TextSecondary
              ),
              shape = RoundedCornerShape(10.dp)
            )
            Box(
              modifier = Modifier
                .testTag("save_favorite_team_button")
                .clip(RoundedCornerShape(10.dp))
                .background(PaletteSuccess.copy(alpha = 0.16f))
                .border(1.dp, PaletteSuccess.copy(alpha = 0.50f), RoundedCornerShape(10.dp))
                .clickable {
                  val query = favoriteTeamDraft.trim()
                  if (query.isNotEmpty()) {
                    val resolved = teamSuggestions.firstOrNull()?.takeIf {
                      it.arabicName.equals(query, ignoreCase = true) ||
                        it.englishName.equals(query, ignoreCase = true)
                    }?.arabicName ?: query
                    submitAddTeam(resolved)
                  }
                }
                .padding(horizontal = 12.dp, vertical = 14.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("إضافة", color = PaletteSuccess, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
          }

          AnimatedVisibility(visible = teamActionFeedback != null) {
            val (msg, isPositive) = teamActionFeedback ?: ("" to true)
            val feedbackColor = if (isPositive) PaletteSuccess else PaletteWarning
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("favorite_team_feedback_banner")
                .clip(RoundedCornerShape(10.dp))
                .background(feedbackColor.copy(alpha = 0.15f))
                .border(1.dp, feedbackColor.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = if (isPositive) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = null,
                tint = feedbackColor,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = msg,
                color = feedbackColor,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
              )
            }
          }

          AnimatedVisibility(visible = showTeamSuggestions && teamSuggestions.isNotEmpty()) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("favorite_team_suggestions_list")
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurface)
                .border(1.dp, PaletteSuccess.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                .padding(6.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              teamSuggestions.forEachIndexed { index, suggestion ->
                val alreadySaved = savedTeams.any { FootballRepository.areSameTeam(it, suggestion.arabicName) }
                val vis = FootballRepository.resolveTeamVisual(suggestion.arabicName, footballState.matches, discoveredTeamMedia)
                val clubTint = Color(vis.badgeColorHex)
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("favorite_team_suggestion_$index")
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceCard.copy(alpha = 0.72f))
                    .clickable { submitAddTeam(suggestion.arabicName) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                  ) {
                    TeamCrestBadge(
                      logoUrl = vis.logoUrl.ifBlank { suggestion.logoUrl },
                      teamName = suggestion.englishName,
                      abbrev = vis.shortCode.ifBlank { suggestion.shortCode },
                      accentColor = clubTint,
                      size = 32.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = suggestion.arabicName,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                      val subMeta = listOfNotNull(
                        suggestion.englishName.takeIf { !it.equals(suggestion.arabicName, ignoreCase = true) },
                        suggestion.venueOrInfoAr.takeIf { it.isNotBlank() }
                      ).joinToString(" • ")
                      if (subMeta.isNotBlank()) {
                        Text(
                          text = subMeta,
                          color = TextSecondary,
                          fontSize = 10.sp,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis
                        )
                      }
                    }
                  }
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    if (suggestion.leagueLabelAr.isNotBlank()) {
                      Box(
                        modifier = Modifier
                          .clip(RoundedCornerShape(6.dp))
                          .background(PaletteSuccess.copy(alpha = 0.14f))
                          .padding(horizontal = 6.dp, vertical = 3.dp)
                      ) {
                        Text(
                          text = suggestion.leagueLabelAr,
                          color = PaletteSuccess,
                          fontSize = 9.5.sp,
                          fontWeight = FontWeight.Bold,
                          maxLines = 1
                        )
                      }
                    }
                    Text(
                      text = if (alreadySaved) "مضاف ✓" else "+ إضافة",
                      color = if (alreadySaved) PalettePrimary else PaletteSuccess,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.ExtraBold
                    )
                  }
                }
              }
            }
          }

          if (savedTeams.isNotEmpty()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "المفضلة (${savedTeams.size}):",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
              savedTeams.forEachIndexed { idx, team ->
                val vis = FootballRepository.resolveTeamVisual(team, footballState.matches, discoveredTeamMedia)
                val chipColor = Color(vis.badgeColorHex)
                Row(
                  modifier = Modifier
                    .testTag("inline_favorite_team_chip_$idx")
                    .clip(RoundedCornerShape(10.dp))
                    .background(chipColor.copy(alpha = 0.14f))
                    .border(1.dp, chipColor.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                    .padding(start = 7.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                  Row(
                    modifier = Modifier.clickable { triggerFocusSavedTeam(team) },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                  ) {
                    TeamCrestBadge(
                      logoUrl = vis.logoUrl,
                      teamName = team,
                      abbrev = vis.shortCode,
                      accentColor = chipColor,
                      size = 20.dp
                    )
                    Text(
                      text = team,
                      color = TextPrimary,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      maxLines = 1
                    )
                  }
                  Box(
                    modifier = Modifier
                      .testTag("remove_inline_favorite_team_btn_$idx")
                      .clip(CircleShape)
                      .clickable {
                        if (onRemoveFavoriteFootballTeam(team)) {
                          if (inspectedFavoriteTeam != null && FootballRepository.areSameTeam(inspectedFavoriteTeam!!, team)) {
                            inspectedFavoriteTeam = null
                          }
                          teamActionFeedback = "تمت إزالة \"$team\" من المفضلة" to false
                        }
                      }
                      .padding(4.dp),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(
                      imageVector = Icons.Default.Close,
                      contentDescription = "إزالة $team",
                      tint = PaletteError,
                      modifier = Modifier.size(13.dp)
                    )
                  }
                }
              }
            }

            // Rich Favorite Team Details Card & Quick Launch
            val activeDetailTeam = inspectedFavoriteTeam?.takeIf { sel ->
              savedTeams.any { FootballRepository.areSameTeam(it, sel) }
            } ?: savedTeams.first()
            val details = FootballRepository.resolveTeamDetails(activeDetailTeam, footballState.matches, discoveredTeamMedia)
            val detailColor = Color(details.badgeColorHex)
            val liveMatch = details.liveOrTodayMatch

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("inline_favorite_team_details_card")
                .clip(RoundedCornerShape(12.dp))
                .background(detailColor.copy(alpha = 0.10f))
                .border(1.dp, detailColor.copy(alpha = 0.40f), RoundedCornerShape(12.dp))
                .clickable { triggerFocusSavedTeam(activeDetailTeam) }
                .padding(horizontal = 10.dp, vertical = 9.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              TeamCrestBadge(
                logoUrl = details.logoUrl,
                teamName = details.englishName,
                abbrev = details.shortCode,
                accentColor = detailColor,
                size = 38.dp
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "${details.displayNameAr} (${details.shortCode})",
                  color = TextPrimary,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                val infoParts = listOfNotNull(
                  details.leagueLabelAr.takeIf { it.isNotBlank() },
                  details.countryAr.takeIf { it.isNotBlank() },
                  details.infoAr.takeIf { it.isNotBlank() }
                )
                if (infoParts.isNotEmpty()) {
                  Text(
                    text = infoParts.joinToString(" • "),
                    color = TextSecondary,
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
                val matchHint = when {
                  liveMatch != null && liveMatch.isLive && !liveMatch.isFinished ->
                    "🔴 تلعب الآن: ${liveMatch.homeTeam} ${liveMatch.homeScore}-${liveMatch.awayScore} ${liveMatch.awayTeam} (${liveMatch.formattedLiveTime()})"
                  liveMatch != null ->
                    "📅 ${liveMatch.homeTeam} × ${liveMatch.awayTeam} (${liveMatch.minuteOrStatus})"
                  else -> "اضغط على اسم الفريق لعرض مباراته في الكبسولة"
                }
                Text(
                  text = matchHint,
                  color = if (liveMatch != null && liveMatch.isLive && !liveMatch.isFinished) PaletteSuccess else detailColor,
                  fontSize = 10.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
              Text(
                text = "كبسولة ←",
                color = detailColor,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.ExtraBold
              )
            }
          }

          OutlinedButton(
            onClick = onOpenFavoriteTeamsWindow,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("open_favorite_teams_window_button"),
            border = BorderStroke(1.dp, PaletteSuccess.copy(alpha = 0.50f)),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = PaletteSuccess.copy(alpha = 0.10f),
              contentColor = PaletteSuccess
            ),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = null,
              modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "فتح نافذة الفرق المفضلة (${savedTeams.size})",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(PaletteWarning.copy(alpha = 0.14f))
              .border(1.dp, PaletteWarning.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onRefreshFootballNow)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("تحديث النتائج الآن", color = PaletteWarning, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(10.dp))
              .background(PaletteSuccess.copy(alpha = 0.14f))
              .border(1.dp, PaletteSuccess.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
              .clickable(onClick = onShowFootballCapsule)
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("عرض بالكبسولة", color = PaletteSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      // 11. Network, Wi-Fi, Airplane Mode & Hotspot Alerts
      FeatureRow(
        icon = Icons.Default.Wifi,
        title = "تنبيهات الشبكة والإنترنت",
        subtitle = "Wi-Fi، بيانات الهاتف، انقطاع الإنترنت، وضع الطيران ونقطة الاتصال",
        isChecked = settings.enableNetworkAlerts,
        accentColor = PalettePrimary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_NETWORK_ALERTS, it) },
        testActionLabel = "معاينة شبكة",
        onTestAction = onTestNetwork
      )

      // 12. Dynamic Album Art Colors
      FeatureRow(
        icon = Icons.Default.Palette,
        title = "ألوان متكيفة مع غلاف الأغنية",
        subtitle = "تغيير لون التوهج والموجات تلقائياً حسب ألوان غلاف الألبوم",
        isChecked = settings.enableDynamicAlbumColors,
        accentColor = PaletteSecondary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_DYNAMIC_ALBUM_COLORS, it) }
      )

      // 13. Auto-Hide in Landscape Mode
      FeatureRow(
        icon = Icons.Default.ScreenRotation,
        title = "الإخفاء التلقائي في الوضع الأفقي",
        subtitle = "إخفاء الكبسولة في الألعاب والفيديو بملء الشاشة مع استثناء المكالمات",
        isChecked = settings.hideInLandscape,
        accentColor = PalettePrimary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_HIDE_IN_LANDSCAPE, it) }
      )

      // 14. Flashlight Alert
      FeatureRow(
        icon = Icons.Default.FlashlightOn,
        title = "التحكم الكامل بالمصباح",
        subtitle = "تشغيل وإطفاء المصباح الفعلي من الكبسولة",
        isChecked = settings.enableFlashlightAlert,
        accentColor = PaletteWarning,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_FLASHLIGHT_ALERT, it) },
        testActionLabel = "تبديل المصباح",
        onTestAction = onToggleFlashlight
      )

      // 15. Smart Media Volume Bar Alert
      FeatureRow(
        icon = Icons.AutoMirrored.Filled.VolumeUp,
        title = "شريط مستوى الصوت الذكي",
        subtitle = "عرض شريط أنيق داخل الكبسولة عند رفع أو خفض صوت الوسائط مع زر كتم سريع",
        isChecked = settings.enableVolumeAlerts,
        accentColor = PalettePrimary,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_VOLUME_ALERTS, it) },
        testActionLabel = "معاينة الصوت",
        onTestAction = onTestVolume
      )

      // 16. Sleep Timer Auto-Pause Media
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          SectionIconBadge(icon = Icons.Default.Bedtime, tint = PaletteSecondary, size = 38.dp, iconSize = 19.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("مؤقت النوم التلقائي للموسيقى", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
              text = if (sleepTimerState.isActive) {
                "متبقي: ${sleepTimerState.formatRemaining()} لإيقاف الموسيقى تلقائياً"
              } else {
                "إيقاف الموسيقى تلقائياً بعد انتهاء المدة المحددة"
              },
              color = if (sleepTimerState.isActive) PaletteSecondary else TextSecondary,
              fontSize = 11.sp
            )
          }
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf(15 to "15 د", 30 to "30 د", 45 to "45 د").forEach { (mins, label) ->
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(PaletteSecondary.copy(alpha = 0.14f))
                .border(1.dp, PaletteSecondary.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .clickable { onStartSleepTimer(mins) }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(label, color = PaletteSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
          if (sleepTimerState.isActive) {
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(PaletteError.copy(alpha = 0.16f))
                .border(1.dp, PaletteError.copy(alpha = 0.50f), RoundedCornerShape(10.dp))
                .clickable { onCancelSleepTimer() }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("إلغاء", color = PaletteError, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // 17. Real System Next Alarm Sync
      FeatureRow(
        icon = Icons.Default.Alarm,
        title = "مزامنة المنبه القادم (Next Alarm)",
        subtitle = if (nextAlarmState.hasAlarm) {
          "المنبه القادم مضبوط: ${nextAlarmState.formattedTime}"
        } else {
          "يعرض موعد المنبه القادم من ساعة النظام تلقائياً داخل لوحة التحكم"
        },
        isChecked = settings.enableAlarmSync,
        accentColor = PaletteWarning,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_ALARM_SYNC, it) },
        testActionLabel = "فتح المنبه",
        onTestAction = onOpenAlarmApp
      )

      // 18. Interactive Haptic Feedback
      FeatureRow(
        icon = Icons.Default.Vibration,
        title = "الاهتزاز اللمسي التفاعلي",
        subtitle = "اهتزاز خفيف عند فتح وتوسيع الكبسولة والتفاعل مع الأزرار",
        isChecked = settings.hapticFeedback,
        accentColor = PaletteSuccess,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_HAPTIC, it) }
      )
    }
  }
}

@Composable
private fun FeatureRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  isChecked: Boolean,
  accentColor: Color,
  onCheckedChange: (Boolean) -> Unit,
  actionColor: Color = accentColor,
  testActionLabel: String? = null,
  onTestAction: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceCard)
      .border(
        width = 1.dp,
        color = DarkSurfaceBorder,
        shape = RoundedCornerShape(14.dp)
      )
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    SectionIconBadge(icon = icon, tint = accentColor, size = 38.dp, iconSize = 19.dp)
    Spacer(modifier = Modifier.width(10.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
      Text(subtitle, color = TextSecondary, fontSize = 11.sp)
      if (testActionLabel != null && onTestAction != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Box(
          modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clickable(onClick = onTestAction),
          contentAlignment = Alignment.CenterStart
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = actionColor.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, actionColor.copy(alpha = 0.40f))
          ) {
            Text(
              text = testActionLabel,
              color = actionColor,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    Switch(
      checked = isChecked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(checkedThumbColor = contrastOn(accentColor), checkedTrackColor = accentColor)
    )
  }
}

@Composable
private fun CustomizationCard(
  settings: CapsuleSettings,
  onUpdateSettings: (CapsuleSettings) -> Unit,
  onToggleService: (Boolean) -> Unit
) {
  ThemedCard(variant = CardVariant.CONTROL_PANEL) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(icon = Icons.Default.Settings, tint = PalettePrimary)
          Column {
            Text(
              text = "تشغيل الكبسولة العائمة",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "تثبيت الكبسولة أعلى الشاشة بنمط Dynamic Island",
              color = TextSecondary,
              fontSize = 11.sp
            )
          }
        }
        Switch(
          checked = settings.serviceEnabled,
          onCheckedChange = onToggleService,
          modifier = Modifier.testTag("service_toggle_switch"),
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = PaletteSuccess
          )
        )
      }

      HorizontalDivider(color = DarkSurfaceBorder)

      // Advanced Y Offset Controller: -150dp to +150dp with live preview and manual input
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
          .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "معايرة ارتفاع وموضع الكبسولة (Y Offset)",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = when {
                settings.notchOffsetYDp < 0 -> "${settings.notchOffsetYDp} dp (أعلى الشاشة / فوق الكاميرا ↑)"
                settings.notchOffsetYDp == 0 -> "0 dp (محاذاة ثقب الكاميرا الافتراضية)"
                else -> "+${settings.notchOffsetYDp} dp (أسفل الكاميرا ↓)"
              },
              color = if (settings.notchOffsetYDp == 0) PalettePrimary else TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Reset to default button
          TextButton(
            onClick = { onUpdateSettings(settings.copy(notchOffsetYDp = 0)) },
            enabled = settings.notchOffsetYDp != 0,
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.RestartAlt,
              contentDescription = "إعادة ضبط",
              tint = if (settings.notchOffsetYDp != 0) PaletteError else TextMuted,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "إعادة ضبط",
              fontSize = 11.sp,
              color = if (settings.notchOffsetYDp != 0) PaletteError else TextMuted,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Expanded Slider from -150dp to +150dp (Full Unrestricted Freedom)
        Slider(
          value = settings.notchOffsetYDp.toFloat().coerceIn(-150f, 150f),
          onValueChange = { onUpdateSettings(settings.copy(notchOffsetYDp = it.toInt())) },
          valueRange = -150f..150f,
          colors = SliderDefaults.colors(
            thumbColor = PalettePrimary,
            activeTrackColor = PalettePrimary,
            inactiveTrackColor = AppTheme.colors.sliderInactiveTrack
          )
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("-150 dp (أعلى)", color = TextMuted, fontSize = 10.sp)
          Text("0 dp (فوق الكاميرا)", color = TextMuted, fontSize = 10.sp)
          Text("+150 dp (أسفل)", color = TextMuted, fontSize = 10.sp)
        }

        // Fine-tuning row: -10, -5, -1, Manual Input text field, +1, +5, +10
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          StepButton(text = "-10", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 10).coerceIn(-150, 150)))
          })
          StepButton(text = "-5", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 5).coerceIn(-150, 150)))
          })
          StepButton(text = "-1", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 1).coerceIn(-150, 150)))
          })

          var manualText by remember(settings.notchOffsetYDp) {
            mutableStateOf(settings.notchOffsetYDp.toString())
          }
          OutlinedTextField(
            value = manualText,
            onValueChange = { str ->
              manualText = str
              val parsed = str.trim().toIntOrNull()
              if (parsed != null && parsed in -150..150) {
                onUpdateSettings(settings.copy(notchOffsetYDp = parsed))
              }
            },
            placeholder = { Text("dp", fontSize = 11.sp, color = TextMuted) },
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .height(48.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = PalettePrimary,
              unfocusedBorderColor = DarkSurfaceBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            )
          )

          StepButton(text = "+1", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 1).coerceIn(-150, 150)))
          })
          StepButton(text = "+5", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 5).coerceIn(-150, 150)))
          })
          StepButton(text = "+10", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 10).coerceIn(-150, 150)))
          })
        }

        // Quick Preset Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          val presets = listOf(
            Pair("فوق الكاميرا (0)", 0),
            Pair("أعلى (-12)", -12),
            Pair("قمة (-40)", -40),
            Pair("تحت (+25)", 25),
            Pair("منخفض (+60)", 60)
          )
          presets.forEach { (label, presetVal) ->
            PresetChip(
              label = label,
              isSelected = settings.notchOffsetYDp == presetVal,
              accentColor = PalettePrimary,
              onClick = { onUpdateSettings(settings.copy(notchOffsetYDp = presetVal)) }
            )
          }
        }
      }

      // Capsule Visual Style Picker (6 distinct capsule themes + opaque/transparent switch + opacity slider)
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "ثيم وتصميم الكبسولة (6 ثيمات)",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
        val styleOptions = listOf(
          "متوهج",
          "نيون متدرج",
          "بسيط هادئ",
          "زجاج آيفون",
          "كروم معدني",
          "ماتريكس ثنائي"
        )
        styleOptions.chunked(3).forEachIndexed { rowIdx, rowItems ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            rowItems.forEachIndexed { colIdx, styleLabel ->
              val styleIdx = rowIdx * 3 + colIdx
              val selected = settings.capsuleStyleIndex == styleIdx
              Box(
                modifier = Modifier
                  .weight(1f)
                  .testTag("capsule_style_$styleIdx")
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (selected) PalettePrimary.copy(alpha = 0.20f) else DarkSurfaceCard)
                  .border(
                    width = if (selected) 1.3.dp else 0.9.dp,
                    color = if (selected) PalettePrimary else DarkSurfaceBorder,
                    shape = RoundedCornerShape(12.dp)
                  )
                  .clickable { onUpdateSettings(settings.copy(capsuleStyleIndex = styleIdx)) }
                  .padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = styleLabel,
                  color = if (selected) PalettePrimary else TextSecondary,
                  fontSize = 11.sp,
                  fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                  maxLines = 1
                )
              }
            }
          }
        }

        // Opaque vs Transparent Capsule Mode Selector
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "شفافية الكبسولة",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val isTrans = settings.capsuleTransparent
            Box(
              modifier = Modifier
                .weight(1f)
                .testTag("capsule_transparent_btn")
                .clip(RoundedCornerShape(10.dp))
                .background(if (isTrans) PalettePrimary.copy(alpha = 0.20f) else DarkSurface)
                .border(1.1.dp, if (isTrans) PalettePrimary else DarkSurfaceBorder, RoundedCornerShape(10.dp))
                .clickable { onUpdateSettings(settings.copy(capsuleTransparent = true)) }
                .padding(vertical = 9.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "شفافة (زجاجية)",
                color = if (isTrans) PalettePrimary else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (isTrans) FontWeight.ExtraBold else FontWeight.Medium
              )
            }
            Box(
              modifier = Modifier
                .weight(1f)
                .testTag("capsule_opaque_btn")
                .clip(RoundedCornerShape(10.dp))
                .background(if (!isTrans) PalettePrimary.copy(alpha = 0.20f) else DarkSurface)
                .border(1.1.dp, if (!isTrans) PalettePrimary else DarkSurfaceBorder, RoundedCornerShape(10.dp))
                .clickable { onUpdateSettings(settings.copy(capsuleTransparent = false)) }
                .padding(vertical = 9.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "غير شفافة (معتمة)",
                color = if (!isTrans) PalettePrimary else TextSecondary,
                fontSize = 11.sp,
                fontWeight = if (!isTrans) FontWeight.ExtraBold else FontWeight.Medium
              )
            }
          }

          AnimatedVisibility(visible = settings.capsuleTransparent) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("درجة وضوح الكبسولة", color = TextSecondary, fontSize = 11.sp)
                Text(
                  text = "${settings.capsuleOpacityPercent}%",
                  color = PalettePrimary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
              Slider(
                value = settings.capsuleOpacityPercent.toFloat().coerceIn(40f, 100f),
                onValueChange = { onUpdateSettings(settings.copy(capsuleOpacityPercent = it.toInt())) },
                valueRange = 40f..100f,
                modifier = Modifier.testTag("capsule_opacity_slider"),
                colors = SliderDefaults.colors(
                  thumbColor = PalettePrimary,
                  activeTrackColor = PalettePrimary,
                  inactiveTrackColor = AppTheme.colors.sliderInactiveTrack
                )
              )
            }
          }
        }
      }

      // Accent Color Picker
      Column {
        Text(
          text = "لون التوهج والموجات (Theme Accent)",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          val colors = listOf(
            Pair("Amber Gold", ObsidianPrimary),
            Pair("Emerald Jade", ObsidianSecondary),
            Pair("Terracotta Coral", ObsidianTertiary),
            Pair("Tangerine", ObsidianWarning),
            Pair("Warm Ivory", Color(0xFFFAF6F0)),
            Pair("Classic Blue", Color(0xFF0A84FF)),
            Pair("Vivid Mint", ObsidianSuccess)
          )
          colors.forEachIndexed { index, (_, color) ->
            val isSelected = settings.accentColorIndex == index
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) TextPrimary else DarkSurfaceBorder,
                  shape = CircleShape
                )
                .clickable { onUpdateSettings(settings.copy(accentColorIndex = index)) }
            )
          }
        }
      }

      // Compact Capsule Width Slider
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "عرض الكبسولة المصغرة",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "${settings.capsuleWidthDp} dp",
            color = PalettePrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Slider(
          value = settings.capsuleWidthDp.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(capsuleWidthDp = it.toInt())) },
          valueRange = 150f..240f,
          colors = SliderDefaults.colors(
            thumbColor = PalettePrimary,
            activeTrackColor = PalettePrimary,
            inactiveTrackColor = AppTheme.colors.sliderInactiveTrack
          )
        )
      }

      // Show when idle toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "إبقاء الكبسولة ظاهرة في وضع الخمول",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "إظهار نقطة الكاميرا السوداء حتى عند عدم وجود أي نشاط",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.showWhenIdle,
          onCheckedChange = { onUpdateSettings(settings.copy(showWhenIdle = it)) },
          colors = SwitchDefaults.colors(
            checkedThumbColor = contrastOn(PalettePrimary),
            checkedTrackColor = PalettePrimary
          )
        )
      }
    }
  }
}

@Composable
private fun PermissionItem(
  title: String,
  description: String,
  isGranted: Boolean,
  icon: ImageVector,
  accentColor: Color,
  onActionClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceCard)
      .border(1.dp, if (isGranted) DarkSurfaceBorder else PaletteWarning.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    SectionIconBadge(
      icon = icon,
      tint = if (isGranted) accentColor else PaletteWarning,
      size = 38.dp,
      iconSize = 19.dp
    )

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = description,
        color = TextSecondary,
        fontSize = 11.sp
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    if (isGranted) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = "Granted",
        tint = PaletteSuccess,
        modifier = Modifier.size(22.dp)
      )
    } else {
      Button(
        onClick = onActionClick,
        colors = ButtonDefaults.buttonColors(
          containerColor = PaletteWarning,
          contentColor = Color(0xFF1F1202)
        ),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Text("تفعيل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

private fun startCapsuleService(context: Context) {
  try {
    if (!Settings.canDrawOverlays(context)) return
    if (FloatingCapsuleService.isAccessibilityServiceEnabled(context)) return
    val intent = Intent(context, OverlayCapsuleService::class.java)
    ContextCompat.startForegroundService(context, intent)
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to start OverlayCapsuleService", e)
  }
}

private fun stopCapsuleService(context: Context) {
  try {
    val intent = Intent(context, OverlayCapsuleService::class.java)
    context.stopService(intent)
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to stop OverlayCapsuleService", e)
  }
}

@Composable
private fun StepButton(
  text: String,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(width = 38.dp, height = 38.dp)
      .clip(RoundedCornerShape(10.dp))
      .background(DarkSurfaceCard)
      .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = TextPrimary,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun PresetChip(
  label: String,
  isSelected: Boolean,
  accentColor: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) accentColor.copy(alpha = 0.2f) else DarkSurfaceCard)
      .border(1.dp, if (isSelected) accentColor else DarkSurfaceBorder, RoundedCornerShape(8.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 5.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = if (isSelected) accentColor else TextSecondary,
      fontSize = 10.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
    )
  }
}

private data class InstalledAppEntry(
  val appName: String,
  val packageName: String
)

@Composable
private fun AppFilterDialog(
  excludedPackages: Set<String>,
  accentColor: Color,
  onTogglePackage: (String, Boolean) -> Unit,
  onResetAll: () -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var query by remember { mutableStateOf("") }
  var apps by remember { mutableStateOf<List<InstalledAppEntry>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }

  LaunchedEffect(Unit) {
    val loaded = withContext(Dispatchers.IO) {
      val pm = context.packageManager
      val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      val resolveList = pm.queryIntentActivities(intent, 0)
      resolveList
        .mapNotNull { info ->
          val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
          if (pkg == context.packageName) return@mapNotNull null
          val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
          InstalledAppEntry(appName = label, packageName = pkg)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.appName.lowercase() }
    }
    apps = loaded
    isLoading = false
  }

  val filteredApps = remember(apps, query) {
    if (query.isBlank()) apps
    else apps.filter {
      it.appName.contains(query, ignoreCase = true) ||
        it.packageName.contains(query, ignoreCase = true)
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurface,
    titleContentColor = TextPrimary,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("تصفية إشعارات التطبيقات", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        if (excludedPackages.isNotEmpty()) {
          TextButton(onClick = onResetAll) {
            Text("تفعيل الكل", color = accentColor, fontSize = 12.sp)
          }
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .height(360.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it },
          placeholder = { Text("ابحث عن تطبيق...", fontSize = 12.sp, color = TextMuted) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accentColor,
            unfocusedBorderColor = DarkSurfaceBorder,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        if (isLoading) {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("جارٍ تحميل التطبيقات...", color = TextSecondary, fontSize = 13.sp)
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(filteredApps.size) { idx ->
              val app = filteredApps[idx]
              val isAllowed = !excludedPackages.contains(app.packageName)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(DarkSurfaceCard)
                  .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Icon(Icons.Default.Apps, contentDescription = null, tint = if (isAllowed) accentColor else TextMuted, modifier = Modifier.size(20.dp))
                  Column {
                    Text(app.appName, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(app.packageName, color = TextMuted, fontSize = 10.sp, maxLines = 1)
                  }
                }
                Switch(
                  checked = isAllowed,
                  onCheckedChange = { allowed -> onTogglePackage(app.packageName, !allowed) },
                  colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = accentColor)
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black)
      ) {
        Text("تم", fontWeight = FontWeight.Bold)
      }
    }
  )
}

@Composable
private fun AppThemeGalleryCard(
  selectedThemeIndex: Int,
  accentColor: Color,
  onSelectTheme: (Int) -> Unit
) {
  ThemedCard(
    modifier = Modifier.testTag("app_theme_gallery_card"),
    variant = CardVariant.STUDIO_CREATIVE
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        SectionIconBadge(icon = Icons.Default.Palette, tint = PaletteSecondary)
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "ثيمات ومظهر التطبيق (App Themes)",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "التصميم الكلاسيكي القديم + أحدث ثيمات السوشيال ميديا العصرية",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
      }

      AppThemeOption.entries.chunked(2).forEach { rowOptions ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          rowOptions.forEach { option ->
            ThemePreviewTile(
              option = option,
              isSelected = selectedThemeIndex == option.index,
              accentColor = PalettePrimary,
              onClick = { onSelectTheme(option.index) },
              modifier = Modifier.weight(1f)
            )
          }
          if (rowOptions.size == 1) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }
  }
}

@Composable
private fun ThemePreviewTile(
  option: AppThemeOption,
  isSelected: Boolean,
  accentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val optionPalette = remember(option) { paletteForThemeIndex(option.index) }
  val isGlassOption = optionPalette.isGlass
  val isLightOption = optionPalette.isLight
  val borderColor = if (isSelected) accentColor else DarkSurfaceBorder

  Column(
    modifier = modifier
      .testTag("theme_option_${option.index}")
      .clip(RoundedCornerShape(18.dp))
      .background(if (isSelected) accentColor.copy(alpha = 0.14f) else DarkSurfaceCard)
      .border(width = if (isSelected) 1.5.dp else 0.9.dp, color = borderColor, shape = RoundedCornerShape(18.dp))
      .clickable(onClick = onClick)
      .padding(10.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Live miniature theme window + capsule preview
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(72.dp)
        .clip(RoundedCornerShape(13.dp))
        .background(option.previewBg)
        .border(
          width = 0.8.dp,
          color = if (isGlassOption) Color.White.copy(alpha = 0.25f) else optionPalette.border,
          shape = RoundedCornerShape(13.dp)
        )
        .padding(8.dp)
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(
              option.previewAccent.copy(alpha = if (isGlassOption) 0.45f else 0.22f),
              Color.Transparent
            ),
            center = Offset(size.width * 0.25f, size.height * 0.25f),
            radius = size.width * 0.72f
          ),
          radius = size.width * 0.72f,
          center = Offset(size.width * 0.25f, size.height * 0.25f)
        )
      }

      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Mini floating capsule pill inside preview
        Box(
          modifier = Modifier
            .width(56.dp)
            .height(12.dp)
            .clip(CircleShape)
            .background(Color(0xFF070A12))
            .border(
              width = 0.9.dp,
              brush = if (isGlassOption) {
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.78f), option.previewAccent))
              } else {
                Brush.linearGradient(listOf(option.previewAccent, optionPalette.secondary))
              },
              shape = CircleShape
            )
        )

        // Mini frosted card bar inside preview
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(option.previewCard)
            .border(
              width = 0.8.dp,
              color = if (isGlassOption) Color.White.copy(alpha = 0.45f) else optionPalette.border,
              shape = RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 6.dp),
          contentAlignment = Alignment.CenterStart
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(option.previewAccent)
            )
            Box(
              modifier = Modifier
                .width(34.dp)
                .height(4.dp)
                .clip(CircleShape)
                .background(if (isLightOption) Color(0xFF1E293B).copy(alpha = 0.65f) else Color.White.copy(alpha = 0.65f))
            )
          }
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = option.titleAr,
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        Text(
          text = option.badgeAr,
          color = option.previewAccent,
          fontSize = 10.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1
        )
      }
      if (isSelected) {
        Icon(
          imageVector = Icons.Default.CheckCircle,
          contentDescription = "Selected theme",
          tint = accentColor,
          modifier = Modifier.size(16.dp)
        )
      }
    }
  }
}

@Composable
private fun QuickThemePickerDialog(
  selectedThemeIndex: Int,
  accentColor: Color,
  onSelectTheme: (Int) -> Unit,
  onOpenCustomStudio: () -> Unit,
  onDismiss: () -> Unit
) {
  val uiHighlight = AppTheme.colors.primary
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = if (AppTheme.colors.isGlass) AppTheme.colors.navBarContainer else DarkSurface,
    titleContentColor = TextPrimary,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(Icons.Default.Palette, contentDescription = null, tint = uiHighlight)
        Column {
          Text("اختر ثيم التطبيق", fontSize = 16.sp, fontWeight = FontWeight.Bold)
          Text("التصميم القديم + أحدث ثيمات السوشيال ميديا", color = TextSecondary, fontSize = 11.sp)
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .height(380.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        AppThemeOption.entries.forEach { option ->
          val isSelected = selectedThemeIndex == option.index
          val optPalette = remember(option) { paletteForThemeIndex(option.index) }
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .background(if (isSelected) uiHighlight.copy(alpha = 0.14f) else DarkSurfaceCard)
              .border(
                width = if (isSelected) 1.4.dp else 0.9.dp,
                color = if (isSelected) uiHighlight else DarkSurfaceBorder,
                shape = RoundedCornerShape(16.dp)
              )
              .clickable { onSelectTheme(option.index) }
              .padding(11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Mini stacked UI card thumbnail
              Box(
                modifier = Modifier
                  .size(width = 42.dp, height = 36.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(option.previewBg)
                  .border(1.dp, option.previewAccent.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                  .padding(4.dp),
                contentAlignment = Alignment.Center
              ) {
                Column(
                  verticalArrangement = Arrangement.spacedBy(3.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Box(
                    modifier = Modifier
                      .width(20.dp)
                      .height(5.dp)
                      .clip(CircleShape)
                      .background(Color.Black)
                      .border(0.6.dp, option.previewAccent, CircleShape)
                  )
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(12.dp)
                      .clip(RoundedCornerShape(4.dp))
                      .background(option.previewCard),
                    contentAlignment = Alignment.CenterStart
                  ) {
                    Box(
                      modifier = Modifier
                        .padding(start = 3.dp)
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(optPalette.secondary)
                    )
                  }
                }
              }
              Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Text(option.titleAr, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Box(
                    modifier = Modifier
                      .clip(CircleShape)
                      .background(option.previewAccent.copy(alpha = 0.16f))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = option.badgeAr,
                      color = option.previewAccent,
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                  Text(
                    text = option.subtitleAr,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }
            }
            if (isSelected) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = uiHighlight, modifier = Modifier.size(20.dp))
            }
          }
        }
      }
    },
    dismissButton = {
      TextButton(onClick = onOpenCustomStudio) {
        Icon(Icons.Default.ColorLens, contentDescription = null, tint = PaletteSecondary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("ألوان حرة", color = PaletteSecondary, fontWeight = FontWeight.Bold)
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("إغلاق", color = uiHighlight, fontWeight = FontWeight.Bold)
      }
    }
  )
}

@Composable
private fun GitHubUpdatesCard(
  settings: CapsuleSettings,
  updateState: AppUpdateState,
  isInstallPackagesGranted: Boolean,
  onToggleAutoCheck: (Boolean) -> Unit,
  onCheckNow: () -> Unit,
  onDownloadUpdate: () -> Unit,
  onInstallUpdate: () -> Unit,
  onRequestInstallPermission: () -> Unit,
  onCancelDownload: () -> Unit,
  onOpenDownloads: () -> Unit,
  onOpenReleasePage: () -> Unit
) {
  ThemedCard(variant = CardVariant.UTILITY_COMPACT) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          SectionIconBadge(icon = Icons.Default.Update, tint = PalettePrimary)
          Column {
            Text(
              text = "تحديثات التطبيق",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            val installedTagSuffix = updateState.confirmedInstalledTag
              .takeIf { it.isNotBlank() && !it.equals("v${updateState.currentVersionName}", ignoreCase = true) && !it.equals(updateState.currentVersionName, ignoreCase = true) }
            Text(
              text = if (installedTagSuffix != null) {
                "الإصدار المثبت: $installedTagSuffix (v${updateState.currentVersionName})"
              } else {
                "الإصدار المثبت: v${updateState.currentVersionName}"
              },
              color = TextSecondary,
              fontSize = 11.sp
            )
            val compactSig = GitHubUpdateManager.compactSha256Label(updateState.installedSigningSha256)
            if (compactSig.isNotBlank()) {
              Text(
                text = "توقيع التطبيق (SHA-256): $compactSig",
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (updateState.isUpdateAvailable) PaletteSuccess.copy(alpha = 0.16f) else PalettePrimary.copy(alpha = 0.14f),
          border = BorderStroke(
            1.dp,
            if (updateState.isUpdateAvailable) PaletteSuccess.copy(alpha = 0.55f) else PalettePrimary.copy(alpha = 0.45f)
          )
        ) {
          Text(
            text = when {
              updateState.isDownloading -> "${updateState.downloadProgressPercent}%"
              updateState.isDownloadComplete -> "تم التنزيل"
              updateState.isChecking -> "جارٍ الفحص"
              updateState.isUpdateAvailable -> updateState.latestVersionTag
              updateState.hasChecked && updateState.errorMessage == null && GitHubUpdateManager.isRepoConfigured() -> "محدّث"
              updateState.confirmedInstalledTag.isNotBlank() -> updateState.confirmedInstalledTag
              else -> "v${updateState.currentVersionName}"
            },
            color = if (updateState.isUpdateAvailable || updateState.isDownloading || updateState.isDownloadComplete) PaletteSuccess else PalettePrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
          )
        }
      }

      Text(
        text = "تحقق من توفر أحدث إصدار للتطبيق واحصل على آخر الميزات والإصلاحات مباشرة من داخل التطبيق.",
        color = TextSecondary,
        fontSize = 12.sp,
        lineHeight = 18.sp
      )

      Button(
        onClick = onCheckNow,
        enabled = !updateState.isChecking && !updateState.isDownloading,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("check_updates_now_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = PalettePrimary,
          contentColor = contrastOn(PalettePrimary)
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Update,
          contentDescription = null,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (updateState.isChecking) "جارٍ التحقق من التحديثات..." else "التحقق من توفر تحديثات",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
      }

      if (updateState.isChecking) {
        LinearProgressIndicator(
          modifier = Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(CircleShape),
          color = PalettePrimary,
          trackColor = DarkSurfaceBorder
        )
      }

      // Auto-check toggle
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .background(DarkSurfaceCard)
          .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
          .clickable { onToggleAutoCheck(!settings.autoCheckUpdatesOnLaunch) }
          .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "التحقق التلقائي عند فتح التطبيق",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
          Text(
            text = "تنبيه تلقائي فور نشر إصدار أحدث",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.autoCheckUpdatesOnLaunch,
          onCheckedChange = onToggleAutoCheck,
          modifier = Modifier.testTag("auto_check_updates_switch"),
          colors = SwitchDefaults.colors(
            checkedThumbColor = contrastOn(PalettePrimary),
            checkedTrackColor = PalettePrimary
          )
        )
      }

      // Status / Available Update Panel + Live Download Progress Bar
      if (updateState.isUpdateAvailable || updateState.isDownloading || updateState.isDownloadComplete) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(PaletteSuccess.copy(alpha = 0.12f))
            .border(1.dp, PaletteSuccess.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
            .padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "يتوفر إصدار جديد: ${updateState.releaseTitle.ifBlank { updateState.latestVersionTag }}",
              color = PaletteSuccess,
              fontSize = 13.sp,
              fontWeight = FontWeight.ExtraBold,
              modifier = Modifier.weight(1f)
            )
            val sizeText = GitHubUpdateManager.formatFileSizeAr(updateState.apkSizeBytes)
            if (sizeText.isNotBlank()) {
              Text(
                text = sizeText,
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          if (updateState.releaseNotes.isNotBlank()) {
            Text(
              text = updateState.releaseNotes,
              color = TextPrimary,
              fontSize = 12.sp,
              maxLines = 4,
              overflow = TextOverflow.Ellipsis
            )
          }

          UpdateDownloadProgressSection(
            updateState = updateState,
            isInstallPackagesGranted = isInstallPackagesGranted,
            onDownloadUpdate = onDownloadUpdate,
            onInstallUpdate = onInstallUpdate,
            onRequestInstallPermission = onRequestInstallPermission,
            onCancelDownload = onCancelDownload,
            onOpenDownloads = onOpenDownloads,
            onOpenReleasePage = onOpenReleasePage
          )
        }
      } else if (updateState.errorMessage != null) {
        Text(
          text = updateState.errorMessage,
          color = PaletteError,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
      } else if (updateState.statusMessageAr.isNotBlank()) {
        Text(
          text = updateState.statusMessageAr,
          color = PaletteSuccess,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}

@Composable
private fun UpdateDownloadProgressSection(
  updateState: AppUpdateState,
  isInstallPackagesGranted: Boolean,
  onDownloadUpdate: () -> Unit,
  onInstallUpdate: () -> Unit,
  onRequestInstallPermission: () -> Unit,
  onCancelDownload: () -> Unit,
  onOpenDownloads: () -> Unit,
  onOpenReleasePage: (() -> Unit)? = null
) {
  if (updateState.isDownloading) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("update_download_progress_box"),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      val effectiveTotal = if (updateState.downloadTotalBytes > 0L) updateState.downloadTotalBytes else updateState.apkSizeBytes
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        val dlStr = GitHubUpdateManager.formatFileSizeAr(updateState.downloadedBytes).ifBlank { "0 KB" }
        val totStr = GitHubUpdateManager.formatFileSizeAr(effectiveTotal)
        Text(
          text = if (totStr.isNotBlank()) "جارٍ التنزيل: $dlStr / $totStr" else "جارٍ التنزيل: $dlStr",
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
        Text(
          text = "${updateState.downloadProgressPercent.coerceIn(0, 100)}%",
          color = PaletteSuccess,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      if (effectiveTotal > 0L) {
        LinearProgressIndicator(
          progress = { updateState.downloadProgressPercent.coerceIn(0, 100) / 100f },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .testTag("update_download_progress_bar"),
          color = PaletteSuccess,
          trackColor = DarkSurfaceBorder
        )
      } else {
        LinearProgressIndicator(
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
            .testTag("update_download_progress_bar"),
          color = PaletteSuccess,
          trackColor = DarkSurfaceBorder
        )
      }

      OutlinedButton(
        onClick = onCancelDownload,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("cancel_update_download_button"),
        border = BorderStroke(1.dp, PaletteError.copy(alpha = 0.55f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = PaletteError),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("إلغاء التنزيل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }
  } else if (updateState.isDownloadComplete) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("update_download_complete_box"),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "اكتمل التنزيل بنجاح ✓",
          color = PaletteSuccess,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "100%",
          color = PaletteSuccess,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }

      LinearProgressIndicator(
        progress = { 1f },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(CircleShape),
        color = PaletteSuccess,
        trackColor = DarkSurfaceBorder
      )

      if (updateState.hasSignatureMismatch && updateState.signatureMismatchMessage.isNotBlank()) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("signature_mismatch_warning_banner")
            .clip(RoundedCornerShape(12.dp))
            .background(PaletteError.copy(alpha = 0.14f))
            .border(1.dp, PaletteError.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(10.dp),
          verticalAlignment = Alignment.Top,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = "تنبيه اختلاف التوقيع",
            tint = PaletteError,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = updateState.signatureMismatchMessage,
            color = PaletteError,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
          )
        }
      }

      if (!isInstallPackagesGranted || updateState.needsInstallPermission) {
        Text(
          text = "للتثبيت التلقائي المباشر من داخل التطبيق، فعّل إذن تثبيت التطبيقات ثم اضغط تثبيت الآن.",
          color = PaletteWarning,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
        Button(
          onClick = onRequestInstallPermission,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("install_update_permission_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = PaletteWarning,
            contentColor = contrastOn(PaletteWarning)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("منح إذن تثبيت التطبيقات", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = onInstallUpdate,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("install_github_update_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = PaletteSuccess,
            contentColor = contrastOn(PaletteSuccess)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("تثبيت التحديث الآن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onOpenDownloads,
          modifier = Modifier
            .height(48.dp)
            .testTag("open_downloads_button"),
          border = BorderStroke(1.dp, DarkSurfaceBorder),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("التنزيلات", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  } else {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Button(
        onClick = onDownloadUpdate,
        modifier = Modifier
          .weight(1f)
          .height(48.dp)
          .testTag("download_github_update_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = PaletteSuccess,
          contentColor = contrastOn(PaletteSuccess)
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("تحميل التحديث الآن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }

      if (onOpenReleasePage != null && updateState.releaseHtmlUrl.isNotBlank()) {
        OutlinedButton(
          onClick = onOpenReleasePage,
          modifier = Modifier.height(48.dp),
          border = BorderStroke(1.dp, DarkSurfaceBorder),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("التفاصيل", fontSize = 12.sp)
        }
      }
    }
  }
}

@Composable
private fun GitHubUpdateAvailableDialog(
  updateState: AppUpdateState,
  isInstallPackagesGranted: Boolean,
  onDownloadNow: () -> Unit,
  onInstallNow: () -> Unit,
  onRequestInstallPermission: () -> Unit,
  onCancelDownload: () -> Unit,
  onOpenDownloads: () -> Unit,
  onOpenReleasePage: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = if (AppTheme.colors.isGlass) AppTheme.colors.navBarContainer else DarkSurface,
    titleContentColor = TextPrimary,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(Icons.Default.Update, contentDescription = null, tint = PaletteSuccess)
        Column {
          Text("يتوفر تحديث جديد للتطبيق", fontSize = 16.sp, fontWeight = FontWeight.Bold)
          Text(
            text = "من v${updateState.currentVersionName} إلى ${updateState.latestVersionTag}",
            color = PaletteSuccess,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        if (updateState.releaseTitle.isNotBlank()) {
          Text(
            text = updateState.releaseTitle,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
        }
        val sizeText = GitHubUpdateManager.formatFileSizeAr(updateState.apkSizeBytes)
        val infoParts = listOfNotNull(
          updateState.apkAssetName.takeIf { it.isNotBlank() },
          sizeText.takeIf { it.isNotBlank() },
          updateState.publishedAt.takeIf { it.isNotBlank() }
        )
        if (infoParts.isNotEmpty()) {
          Text(
            text = infoParts.joinToString(" • "),
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        if (updateState.releaseNotes.isNotBlank()) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(DarkSurfaceCard)
              .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
              .padding(10.dp)
          ) {
            Text(
              text = "ما الجديد في هذا التحديث:",
              color = PalettePrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = updateState.releaseNotes,
              color = TextPrimary,
              fontSize = 12.sp,
              maxLines = 6,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        if (updateState.isDownloading || updateState.isDownloadComplete) {
          UpdateDownloadProgressSection(
            updateState = updateState,
            isInstallPackagesGranted = isInstallPackagesGranted,
            onDownloadUpdate = onDownloadNow,
            onInstallUpdate = onInstallNow,
            onRequestInstallPermission = onRequestInstallPermission,
            onCancelDownload = onCancelDownload,
            onOpenDownloads = onOpenDownloads
          )
        }
      }
    },
    dismissButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = onDismiss) {
          Text(if (updateState.isDownloading) "تصغير" else "لاحقاً", color = TextSecondary)
        }
        if (updateState.releaseHtmlUrl.isNotBlank()) {
          TextButton(onClick = onOpenReleasePage) {
            Text("GitHub", color = PalettePrimary)
          }
        }
      }
    },
    confirmButton = {
      if (!updateState.isDownloading && !updateState.isDownloadComplete) {
        Button(
          onClick = onDownloadNow,
          colors = ButtonDefaults.buttonColors(
            containerColor = PaletteSuccess,
            contentColor = contrastOn(PaletteSuccess)
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("تحميل التحديث", fontWeight = FontWeight.Bold)
        }
      } else if (updateState.isDownloadComplete) {
        Button(
          onClick = if (isInstallPackagesGranted) onInstallNow else onRequestInstallPermission,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isInstallPackagesGranted) PaletteSuccess else PaletteWarning,
            contentColor = contrastOn(if (isInstallPackagesGranted) PaletteSuccess else PaletteWarning)
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(
            imageVector = if (isInstallPackagesGranted) Icons.Default.CheckCircle else Icons.Default.Security,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isInstallPackagesGranted) "تثبيت الآن" else "إذن التثبيت",
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  )
}


