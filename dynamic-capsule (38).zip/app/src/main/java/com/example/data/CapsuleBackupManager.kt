package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.example.island.FootballRepository
import com.example.update.GitHubUpdateManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupSummary(
  val exportedAtMs: Long,
  val appVersionName: String,
  val favoriteTeamsCount: Int,
  val prayerAdjustmentsCount: Int,
  val hasCustomColors: Boolean,
  val customColorsCount: Int,
  val excludedAppsCount: Int
)

data class BackupImportResult(
  val settings: CapsuleSettings,
  val summary: BackupSummary
)

object CapsuleBackupManager {

  const val BACKUP_FORMAT_ID = "dynamic_capsule_backup"
  const val BACKUP_FORMAT_VERSION = 1
  private const val MAX_IMPORT_BYTES = 1024 * 1024 // 1 MB safety guard

  fun defaultBackupFileName(nowMs: Long = System.currentTimeMillis()): String {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(nowMs))
    return "DynamicCapsule_Backup_$stamp.json"
  }

  fun summarize(
    settings: CapsuleSettings,
    exportedAtMs: Long = System.currentTimeMillis(),
    appVersionName: String = BuildConfig.VERSION_NAME
  ): BackupSummary {
    val prayerOffsets = listOf(
      settings.prayerOffsetFajr,
      settings.prayerOffsetSunrise,
      settings.prayerOffsetDhuhr,
      settings.prayerOffsetAsr,
      settings.prayerOffsetMaghrib,
      settings.prayerOffsetIsha
    )
    val customColorCount = CustomColorSlot.entries.count { settings.customColorFor(it) != null }
    return BackupSummary(
      exportedAtMs = exportedAtMs,
      appVersionName = appVersionName,
      favoriteTeamsCount = settings.effectiveFavoriteFootballTeams.size,
      prayerAdjustmentsCount = prayerOffsets.count { it != 0 },
      hasCustomColors = settings.useCustomColors && customColorCount > 0,
      customColorsCount = customColorCount,
      excludedAppsCount = settings.excludedPackages.size
    )
  }

  fun exportToJsonString(
    settings: CapsuleSettings,
    nowMs: Long = System.currentTimeMillis(),
    appVersionName: String = BuildConfig.VERSION_NAME
  ): String {
    val root = JSONObject().apply {
      put("format", BACKUP_FORMAT_ID)
      put("version", BACKUP_FORMAT_VERSION)
      put("exportedAtMs", nowMs)
      put("appVersionName", appVersionName)

      put("capsule", JSONObject().apply {
        put("serviceEnabled", settings.serviceEnabled)
        put("notchOffsetYDp", settings.notchOffsetYDp)
        put("capsuleWidthDp", settings.capsuleWidthDp)
        put("capsuleHeightDp", settings.capsuleHeightDp)
        put("autoCollapseSeconds", settings.autoCollapseSeconds)
        put("showWhenIdle", settings.showWhenIdle)
        put("hapticFeedback", settings.hapticFeedback)
        put("hideInLandscape", settings.hideInLandscape)
        put("capsuleStyleIndex", settings.capsuleStyleIndex)
        put("capsuleTransparent", settings.capsuleTransparent)
        put("capsuleOpacityPercent", settings.capsuleOpacityPercent)
        put("openAnimationIndex", settings.openAnimationIndex)
        put("auraAnimationIndex", settings.auraAnimationIndex)
        put("visualizerStyleIndex", settings.visualizerStyleIndex)
        put("enableDualCapsule", settings.enableDualCapsule)
        put("enableDynamicAlbumColors", settings.enableDynamicAlbumColors)
      })

      put("colors", JSONObject().apply {
        put("appThemeIndex", settings.appThemeIndex)
        put("accentColorIndex", settings.accentColorIndex)
        put("useCustomColors", settings.useCustomColors)
        CustomColorSlot.entries.forEach { slot ->
          val col = settings.customColorFor(slot)
          if (col != null) {
            put(slot.key, col)
          } else {
            put(slot.key, JSONObject.NULL)
          }
        }
      })

      put("features", JSONObject().apply {
        put("enableBatteryAlerts", settings.enableBatteryAlerts)
        put("enableCallAlerts", settings.enableCallAlerts)
        put("enableTimer", settings.enableTimer)
        put("enableNotifications", settings.enableNotifications)
        put("enableBluetoothAlerts", settings.enableBluetoothAlerts)
        put("enableFlashlightAlert", settings.enableFlashlightAlert)
        put("enableRingerAlerts", settings.enableRingerAlerts)
        put("enableDownloadProgress", settings.enableDownloadProgress)
        put("enableNavigationAlerts", settings.enableNavigationAlerts)
        put("enablePrivacyAlerts", settings.enablePrivacyAlerts)
        put("enableNetworkAlerts", settings.enableNetworkAlerts)
        put("enableVolumeAlerts", settings.enableVolumeAlerts)
        put("enableAlarmSync", settings.enableAlarmSync)
        put("enableStepsCounter", settings.enableStepsCounter)
        put("pinStepsInCapsule", settings.pinStepsInCapsule)
        put("enableWeatherAlerts", settings.enableWeatherAlerts)
        put("pinWeatherInCapsule", settings.pinWeatherInCapsule)
        put("enableCompass", settings.enableCompass)
        put("enableFocusTimer", settings.enableFocusTimer)
        put("enableDeliveryAlerts", settings.enableDeliveryAlerts)
        put("enableFootballScores", settings.enableFootballScores)
        put("pinFootballInCapsule", settings.pinFootballInCapsule)
        put("enablePreMatchReminder", settings.enablePreMatchReminder)
        put("enablePrayerAlerts", settings.enablePrayerAlerts)
        put("pinPrayerInCapsule", settings.pinPrayerInCapsule)
        put("autoCheckUpdatesOnLaunch", settings.autoCheckUpdatesOnLaunch)
      })

      put("weather", JSONObject().apply {
        put("weatherCityQuery", settings.weatherCityQuery)
        put("weatherCityDisplayAlias", settings.weatherCityDisplayAlias)
        if (settings.weatherCityLat != null && settings.weatherCityLon != null) {
          put("weatherCityLat", settings.weatherCityLat)
          put("weatherCityLon", settings.weatherCityLon)
        }
      })

      put("football", JSONObject().apply {
        put("footballLeagueCode", settings.footballLeagueCode)
        put("footballReminderMinutes", settings.footballReminderMinutes)
        val arr = JSONArray()
        settings.effectiveFavoriteFootballTeams.forEach { arr.put(it) }
        put("favoriteFootballTeams", arr)
      })

      put("prayer", JSONObject().apply {
        put("prayerReminderMinutes", settings.prayerReminderMinutes)
        put("prayerOffsetFajr", settings.prayerOffsetFajr)
        put("prayerOffsetSunrise", settings.prayerOffsetSunrise)
        put("prayerOffsetDhuhr", settings.prayerOffsetDhuhr)
        put("prayerOffsetAsr", settings.prayerOffsetAsr)
        put("prayerOffsetMaghrib", settings.prayerOffsetMaghrib)
        put("prayerOffsetIsha", settings.prayerOffsetIsha)
      })

      put("excludedPackages", JSONArray().apply {
        settings.excludedPackages.sorted().forEach { put(it) }
      })

      put("githubUpdateRepo", settings.githubUpdateRepo)
    }
    return root.toString(2)
  }

  fun parseAndValidateBackupJson(
    jsonStr: String,
    fallback: CapsuleSettings = CapsuleSettings()
  ): Result<BackupImportResult> {
    return runCatching {
      val trimmed = jsonStr.trim()
      if (trimmed.isEmpty() || !trimmed.startsWith("{")) {
        throw IllegalArgumentException("الملف المختار لا يحتوي على بيانات JSON صالحة")
      }
      val root = JSONObject(trimmed)
      val format = root.optString("format", "")
      if (format != BACKUP_FORMAT_ID) {
        throw IllegalArgumentException("هذا الملف ليس نسخة احتياطية خاصة بتطبيق Dynamic Capsule")
      }

      val capsule = root.optJSONObject("capsule") ?: JSONObject()
      val colors = root.optJSONObject("colors") ?: JSONObject()
      val features = root.optJSONObject("features") ?: JSONObject()
      val weather = root.optJSONObject("weather") ?: JSONObject()
      val football = root.optJSONObject("football") ?: JSONObject()
      val prayer = root.optJSONObject("prayer") ?: JSONObject()

      val rawTeams = mutableListOf<String>()
      val teamsArr = football.optJSONArray("favoriteFootballTeams")
      if (teamsArr != null) {
        for (i in 0 until teamsArr.length()) {
          val item = teamsArr.optString(i, "").trim()
          if (item.isNotBlank() && rawTeams.none { FootballRepository.areSameTeam(it, item) }) {
            rawTeams.add(item)
          }
        }
      } else {
        val single = football.optString("favoriteFootballTeam", "").trim()
        if (single.isNotBlank()) rawTeams.add(single)
      }
      val importedTeams = rawTeams.take(25)

      val excluded = linkedSetOf<String>()
      val exArr = root.optJSONArray("excludedPackages")
      if (exArr != null) {
        for (i in 0 until exArr.length()) {
          val pkg = exArr.optString(i, "").trim()
          if (pkg.isNotBlank()) excluded.add(pkg)
        }
      }

      val latOpt = if (weather.has("weatherCityLat") && !weather.isNull("weatherCityLat")) {
        weather.optDouble("weatherCityLat").takeIf { !it.isNaN() }
      } else null
      val lonOpt = if (weather.has("weatherCityLon") && !weather.isNull("weatherCityLon")) {
        weather.optDouble("weatherCityLon").takeIf { !it.isNaN() }
      } else null

      fun optColor(slot: CustomColorSlot): Int? {
        if (!colors.has(slot.key) || colors.isNull(slot.key)) return null
        return colors.optInt(slot.key)
      }

      val parsedSettings = fallback.copy(
        serviceEnabled = capsule.optBoolean("serviceEnabled", fallback.serviceEnabled),
        notchOffsetYDp = capsule.optInt("notchOffsetYDp", fallback.notchOffsetYDp).coerceIn(-150, 200),
        capsuleWidthDp = capsule.optInt("capsuleWidthDp", fallback.capsuleWidthDp).coerceIn(140, 360),
        capsuleHeightDp = capsule.optInt("capsuleHeightDp", fallback.capsuleHeightDp).coerceIn(30, 84),
        autoCollapseSeconds = capsule.optInt("autoCollapseSeconds", fallback.autoCollapseSeconds).coerceIn(0, 120),
        showWhenIdle = capsule.optBoolean("showWhenIdle", fallback.showWhenIdle),
        hapticFeedback = capsule.optBoolean("hapticFeedback", fallback.hapticFeedback),
        hideInLandscape = capsule.optBoolean("hideInLandscape", fallback.hideInLandscape),
        capsuleStyleIndex = capsule.optInt("capsuleStyleIndex", fallback.capsuleStyleIndex).coerceIn(0, 5),
        capsuleTransparent = capsule.optBoolean("capsuleTransparent", fallback.capsuleTransparent),
        capsuleOpacityPercent = capsule.optInt("capsuleOpacityPercent", fallback.capsuleOpacityPercent).coerceIn(40, 100),
        openAnimationIndex = capsule.optInt("openAnimationIndex", fallback.openAnimationIndex).coerceIn(0, 4),
        auraAnimationIndex = capsule.optInt("auraAnimationIndex", fallback.auraAnimationIndex).coerceIn(0, 4),
        visualizerStyleIndex = capsule.optInt("visualizerStyleIndex", fallback.visualizerStyleIndex).coerceIn(0, 3),
        enableDualCapsule = capsule.optBoolean("enableDualCapsule", fallback.enableDualCapsule),
        enableDynamicAlbumColors = capsule.optBoolean("enableDynamicAlbumColors", fallback.enableDynamicAlbumColors),

        appThemeIndex = colors.optInt("appThemeIndex", fallback.appThemeIndex).coerceIn(0, 8),
        accentColorIndex = colors.optInt("accentColorIndex", fallback.accentColorIndex).coerceIn(0, 6),
        useCustomColors = colors.optBoolean("useCustomColors", fallback.useCustomColors),
        customBackgroundColor = optColor(CustomColorSlot.BACKGROUND),
        customSurfaceColor = optColor(CustomColorSlot.SURFACE),
        customElevatedColor = optColor(CustomColorSlot.ELEVATED),
        customPrimaryColor = optColor(CustomColorSlot.PRIMARY),
        customSecondaryColor = optColor(CustomColorSlot.SECONDARY),
        customTextPrimaryColor = optColor(CustomColorSlot.TEXT_PRIMARY),
        customTextSecondaryColor = optColor(CustomColorSlot.TEXT_SECONDARY),
        customCapsuleBgColor = optColor(CustomColorSlot.CAPSULE_BG),

        enableBatteryAlerts = features.optBoolean("enableBatteryAlerts", fallback.enableBatteryAlerts),
        enableCallAlerts = features.optBoolean("enableCallAlerts", fallback.enableCallAlerts),
        enableTimer = features.optBoolean("enableTimer", fallback.enableTimer),
        enableNotifications = features.optBoolean("enableNotifications", fallback.enableNotifications),
        enableBluetoothAlerts = features.optBoolean("enableBluetoothAlerts", fallback.enableBluetoothAlerts),
        enableFlashlightAlert = features.optBoolean("enableFlashlightAlert", fallback.enableFlashlightAlert),
        enableRingerAlerts = features.optBoolean("enableRingerAlerts", fallback.enableRingerAlerts),
        enableDownloadProgress = features.optBoolean("enableDownloadProgress", fallback.enableDownloadProgress),
        enableNavigationAlerts = features.optBoolean("enableNavigationAlerts", fallback.enableNavigationAlerts),
        enablePrivacyAlerts = features.optBoolean("enablePrivacyAlerts", fallback.enablePrivacyAlerts),
        enableNetworkAlerts = features.optBoolean("enableNetworkAlerts", fallback.enableNetworkAlerts),
        enableVolumeAlerts = features.optBoolean("enableVolumeAlerts", fallback.enableVolumeAlerts),
        enableAlarmSync = features.optBoolean("enableAlarmSync", fallback.enableAlarmSync),
        enableStepsCounter = features.optBoolean("enableStepsCounter", fallback.enableStepsCounter),
        pinStepsInCapsule = features.optBoolean("pinStepsInCapsule", fallback.pinStepsInCapsule),
        enableWeatherAlerts = features.optBoolean("enableWeatherAlerts", fallback.enableWeatherAlerts),
        pinWeatherInCapsule = features.optBoolean("pinWeatherInCapsule", fallback.pinWeatherInCapsule),
        enableCompass = features.optBoolean("enableCompass", fallback.enableCompass),
        enableFocusTimer = features.optBoolean("enableFocusTimer", fallback.enableFocusTimer),
        enableDeliveryAlerts = features.optBoolean("enableDeliveryAlerts", fallback.enableDeliveryAlerts),
        enableFootballScores = features.optBoolean("enableFootballScores", fallback.enableFootballScores),
        pinFootballInCapsule = features.optBoolean("pinFootballInCapsule", fallback.pinFootballInCapsule),
        enablePreMatchReminder = features.optBoolean("enablePreMatchReminder", fallback.enablePreMatchReminder),
        enablePrayerAlerts = features.optBoolean("enablePrayerAlerts", fallback.enablePrayerAlerts),
        pinPrayerInCapsule = features.optBoolean("pinPrayerInCapsule", fallback.pinPrayerInCapsule),
        autoCheckUpdatesOnLaunch = features.optBoolean("autoCheckUpdatesOnLaunch", fallback.autoCheckUpdatesOnLaunch),

        weatherCityQuery = weather.optString("weatherCityQuery", "").trim(),
        weatherCityDisplayAlias = weather.optString("weatherCityDisplayAlias", "").trim(),
        weatherCityLat = if (latOpt != null && lonOpt != null) latOpt else null,
        weatherCityLon = if (latOpt != null && lonOpt != null) lonOpt else null,

        footballLeagueCode = football.optString("footballLeagueCode", fallback.footballLeagueCode)
          .trim()
          .ifBlank { "uefa.champions" },
        footballReminderMinutes = football.optInt("footballReminderMinutes", fallback.footballReminderMinutes)
          .coerceIn(5, 60),
        favoriteFootballTeam = importedTeams.firstOrNull().orEmpty(),
        favoriteFootballTeams = importedTeams,

        prayerReminderMinutes = prayer.optInt("prayerReminderMinutes", fallback.prayerReminderMinutes)
          .coerceIn(5, 45),
        prayerOffsetFajr = prayer.optInt("prayerOffsetFajr", 0).coerceIn(-60, 60),
        prayerOffsetSunrise = prayer.optInt("prayerOffsetSunrise", 0).coerceIn(-60, 60),
        prayerOffsetDhuhr = prayer.optInt("prayerOffsetDhuhr", 0).coerceIn(-60, 60),
        prayerOffsetAsr = prayer.optInt("prayerOffsetAsr", 0).coerceIn(-60, 60),
        prayerOffsetMaghrib = prayer.optInt("prayerOffsetMaghrib", 0).coerceIn(-60, 60),
        prayerOffsetIsha = prayer.optInt("prayerOffsetIsha", 0).coerceIn(-60, 60),

        excludedPackages = excluded,
        githubUpdateRepo = GitHubUpdateManager.normalizeRepo(
          root.optString("githubUpdateRepo", fallback.githubUpdateRepo)
        )
      )

      val exportedAtMs = root.optLong("exportedAtMs", System.currentTimeMillis())
      val appVersion = root.optString("appVersionName", BuildConfig.VERSION_NAME)
      BackupImportResult(
        settings = parsedSettings,
        summary = summarize(parsedSettings, exportedAtMs = exportedAtMs, appVersionName = appVersion)
      )
    }
  }

  suspend fun exportBackupToUri(context: Context, uri: Uri): Result<BackupSummary> = withContext(Dispatchers.IO) {
    runCatching {
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      val now = System.currentTimeMillis()
      val json = exportToJsonString(settings, nowMs = now)
      val os = context.contentResolver.openOutputStream(uri, "wt")
        ?: context.contentResolver.openOutputStream(uri)
        ?: throw IllegalStateException("تعذر فتح مسار الحفظ المختار")
      os.use { stream ->
        stream.write(json.toByteArray(Charsets.UTF_8))
        stream.flush()
      }
      summarize(settings, exportedAtMs = now)
    }
  }

  suspend fun importBackupFromUri(context: Context, uri: Uri): Result<BackupImportResult> = withContext(Dispatchers.IO) {
    runCatching {
      val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val raw = input.readBytes()
        if (raw.size > MAX_IMPORT_BYTES) {
          throw IllegalArgumentException("حجم الملف كبير جداً ولا يطابق ملف إعدادات")
        }
        raw
      } ?: throw IllegalStateException("تعذر قراءة الملف المختار")
      val content = bytes.toString(Charsets.UTF_8)
      val mgr = CapsuleSettingsManager.getInstance(context)
      val parsed = parseAndValidateBackupJson(content, fallback = mgr.settings.value).getOrThrow()
      mgr.importAllSettings(parsed.settings)
      parsed
    }
  }

  suspend fun exportAndShareBackupFile(context: Context): Result<BackupSummary> = withContext(Dispatchers.IO) {
    runCatching {
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      val now = System.currentTimeMillis()
      val json = exportToJsonString(settings, nowMs = now)
      val file = File(context.cacheDir, defaultBackupFileName(now))
      FileOutputStream(file).use { out ->
        out.write(json.toByteArray(Charsets.UTF_8))
        out.flush()
      }
      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      val summary = summarize(settings, exportedAtMs = now)
      withContext(Dispatchers.Main) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
          type = "application/json"
          putExtra(Intent.EXTRA_STREAM, uri)
          putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية لإعدادات Dynamic Capsule")
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "حفظ أو إرسال ملف الإعدادات").apply {
          if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
      }
      summary
    }
  }

  fun buildShareAppText(latestReleaseUrl: String? = null): String {
    val repoUrl = latestReleaseUrl?.takeIf { it.startsWith("https://") }
      ?: "https://github.com/${GitHubUpdateManager.EMBEDDED_GITHUB_REPO}/releases/latest"
    return buildString {
      appendLine("جرّب تطبيق Dynamic Capsule (الإصدار v${BuildConfig.VERSION_NAME}) ✨")
      appendLine("كبسولة تفاعلية احترافية لأندرويد تعرض الموسيقى، الطقس، أوقات الصلاة، نتائج المباريات المباشرة، الشحن بتصميم شاومي، والمكالمات.")
      appendLine()
      append("رابط التحميل المباشر:\n$repoUrl")
    }
  }

  fun shareAppLink(context: Context, latestReleaseUrl: String? = null): Boolean {
    return runCatching {
      val text = buildShareAppText(latestReleaseUrl)
      val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Dynamic Capsule")
        putExtra(Intent.EXTRA_TEXT, text)
      }
      val chooser = Intent.createChooser(intent, "مشاركة تطبيق Dynamic Capsule").apply {
        if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(chooser)
      true
    }.getOrDefault(false)
  }

  suspend fun shareAppApk(context: Context, fallbackReleaseUrl: String? = null): Result<Boolean> =
    withContext(Dispatchers.IO) {
      runCatching {
        val appInfo = context.applicationInfo
        val splits = appInfo.splitPublicSourceDirs
        if (splits != null && splits.isNotEmpty()) {
          throw IllegalStateException("التطبيق مثبت بحزمة مقسمة — ستتم مشاركة رابط التحميل بدلاً من ذلك")
        }
        val sourceApk = File(appInfo.sourceDir)
        if (!sourceApk.exists() || !sourceApk.canRead()) {
          throw IllegalStateException("تعذر الوصول إلى ملف التثبيت المحلي")
        }
        val outApk = File(context.cacheDir, "DynamicCapsule_v${BuildConfig.VERSION_NAME}.apk")
        sourceApk.inputStream().use { input ->
          FileOutputStream(outApk).use { output ->
            input.copyTo(output, bufferSize = 64 * 1024)
            output.flush()
          }
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outApk)
        withContext(Dispatchers.Main) {
          val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Dynamic Capsule v${BuildConfig.VERSION_NAME}")
            putExtra(Intent.EXTRA_TEXT, buildShareAppText(fallbackReleaseUrl))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
          }
          val chooser = Intent.createChooser(intent, "إرسال ملف تطبيق Dynamic Capsule").apply {
            if (context !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
          context.startActivity(chooser)
        }
        true
      }
    }
}
