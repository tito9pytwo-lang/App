package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ObsidianPrimary
import com.example.ui.theme.ObsidianSecondary
import com.example.ui.theme.ObsidianSuccess
import com.example.ui.theme.ObsidianTertiary
import com.example.ui.theme.ObsidianWarning

enum class CustomColorSlot(val key: String, val labelAr: String) {
  BACKGROUND("custom_bg_color", "الخلفية"),
  SURFACE("custom_surface_color", "البطاقات"),
  ELEVATED("custom_elevated_color", "الشريط والحاويات"),
  PRIMARY("custom_primary_color", "الأزرار والأساسي"),
  SECONDARY("custom_secondary_color", "اللون الثانوي"),
  TEXT_PRIMARY("custom_text_primary_color", "النصوص الرئيسية"),
  TEXT_SECONDARY("custom_text_secondary_color", "النصوص الفرعية"),
  CAPSULE_BG("custom_capsule_bg_color", "خلفية الكبسولة")
}

data class CapsuleSettings(
  val serviceEnabled: Boolean = true,
  val notchOffsetYDp: Int = 0, // Extra offset below status bar
  val capsuleWidthDp: Int = 220, // Medium size, easy to see and touch
  val capsuleHeightDp: Int = 46, // Medium height, comfortable touch target
  val accentColorIndex: Int = 0,
  val autoCollapseSeconds: Int = 0,
  val showWhenIdle: Boolean = false, // Hidden when idle so no window is visible without activity
  val hapticFeedback: Boolean = true,
  // Feature toggles
  val enableBatteryAlerts: Boolean = true,
  val enableCallAlerts: Boolean = true,
  val enableTimer: Boolean = true,
  val enableNotifications: Boolean = true,
  val enableBluetoothAlerts: Boolean = true,
  val enableFlashlightAlert: Boolean = true,
  val enableRingerAlerts: Boolean = true,
  val enableDownloadProgress: Boolean = true,
  val enableNavigationAlerts: Boolean = true,
  val enablePrivacyAlerts: Boolean = true,
  val enableDualCapsule: Boolean = true,
  val enableDynamicAlbumColors: Boolean = true,
  val capsuleStyleIndex: Int = 0, // 0 = Glow, 1 = Neon Gradient, 2 = Minimal, 3 = Liquid Glass, 4 = Metallic Chrome, 5 = Dual Neon Matrix
  val capsuleTransparent: Boolean = true, // true = Transparent/Glass, false = Solid Opaque
  val capsuleOpacityPercent: Int = 88, // 40..100 opacity when transparent
  val openAnimationIndex: Int = 0, // 0 = Elastic Spring, 1 = Liquid Pop, 2 = Drop Slide, 3 = 3D Flip Zoom, 4 = Snappy Crisp
  val auraAnimationIndex: Int = 0, // 0 = Static, 1 = Spinning Aura, 2 = Breathing Pulse, 3 = Dual Sweep, 4 = Reactive EQ Halo
  val visualizerStyleIndex: Int = 0, // 0 = Classic Bars, 1 = Smooth Sine Wave, 2 = Sonic Pulse Dots, 3 = Mirror EQ
  val hideInLandscape: Boolean = true,
  val enableNetworkAlerts: Boolean = true,
  val enableVolumeAlerts: Boolean = true,
  val enableAlarmSync: Boolean = true,
  val enableStepsCounter: Boolean = true,
  val pinStepsInCapsule: Boolean = false,
  val enableWeatherAlerts: Boolean = true,
  val pinWeatherInCapsule: Boolean = false,
  val weatherCityQuery: String = "",
  val weatherCityDisplayAlias: String = "",
  val weatherCityLat: Double? = null,
  val weatherCityLon: Double? = null,
  val enableCompass: Boolean = true,
  val enableFocusTimer: Boolean = true,
  val enableDeliveryAlerts: Boolean = true,
  val enableFootballScores: Boolean = true,
  val footballLeagueCode: String = "uefa.champions",
  val pinFootballInCapsule: Boolean = false,
  val enablePreMatchReminder: Boolean = true,
  val footballReminderMinutes: Int = 15,
  val favoriteFootballTeam: String = "",
  val favoriteFootballTeams: List<String> = emptyList(),
  val enablePrayerAlerts: Boolean = true,
  val pinPrayerInCapsule: Boolean = false,
  val prayerReminderMinutes: Int = 15,
  val prayerOffsetFajr: Int = 0,
  val prayerOffsetSunrise: Int = 0,
  val prayerOffsetDhuhr: Int = 0,
  val prayerOffsetAsr: Int = 0,
  val prayerOffsetMaghrib: Int = 0,
  val prayerOffsetIsha: Int = 0,
  val appThemeIndex: Int = 0, // 0..8 preset themes
  val useCustomColors: Boolean = false,
  val customBackgroundColor: Int? = null,
  val customSurfaceColor: Int? = null,
  val customElevatedColor: Int? = null,
  val customPrimaryColor: Int? = null,
  val customSecondaryColor: Int? = null,
  val customTextPrimaryColor: Int? = null,
  val customTextSecondaryColor: Int? = null,
  val customCapsuleBgColor: Int? = null,
  val excludedPackages: Set<String> = emptySet(),
  val githubUpdateRepo: String = "",
  val autoCheckUpdatesOnLaunch: Boolean = true
) {
  val hasCustomWeatherCity: Boolean
    get() = weatherCityQuery.isNotBlank() || (weatherCityLat != null && weatherCityLon != null)

  val effectiveFavoriteFootballTeams: List<String>
    get() = if (favoriteFootballTeams.isNotEmpty()) {
      favoriteFootballTeams
    } else {
      listOfNotNull(favoriteFootballTeam.trim().takeIf { it.isNotBlank() })
    }

  val accentColor: Color
    get() = when (accentColorIndex) {
      0 -> ObsidianPrimary       // Burnished Amber Gold
      1 -> ObsidianSecondary     // Emerald Jade
      2 -> ObsidianTertiary      // Terracotta Rose Coral
      3 -> ObsidianWarning       // Burnt Tangerine
      4 -> Color(0xFFFAF6F0)     // Warm Ivory
      5 -> Color(0xFF0A84FF)     // Optional Apple Blue swatch
      6 -> ObsidianSuccess       // Vivid Mint Green
      else -> ObsidianPrimary
    }

  val effectiveAccentColor: Color
    get() = if (useCustomColors && customPrimaryColor != null) Color(customPrimaryColor) else accentColor

  val isLiquidGlassCapsule: Boolean
    get() = capsuleTransparent && (appThemeIndex == 1 || appThemeIndex == 2 || capsuleStyleIndex == 3)

  fun customColorFor(slot: CustomColorSlot): Int? = when (slot) {
    CustomColorSlot.BACKGROUND -> customBackgroundColor
    CustomColorSlot.SURFACE -> customSurfaceColor
    CustomColorSlot.ELEVATED -> customElevatedColor
    CustomColorSlot.PRIMARY -> customPrimaryColor
    CustomColorSlot.SECONDARY -> customSecondaryColor
    CustomColorSlot.TEXT_PRIMARY -> customTextPrimaryColor
    CustomColorSlot.TEXT_SECONDARY -> customTextSecondaryColor
    CustomColorSlot.CAPSULE_BG -> customCapsuleBgColor
  }

  fun prayerOffsetFor(key: String): Int = when (key) {
    "fajr" -> prayerOffsetFajr
    "sunrise" -> prayerOffsetSunrise
    "dhuhr" -> prayerOffsetDhuhr
    "asr" -> prayerOffsetAsr
    "maghrib" -> prayerOffsetMaghrib
    "isha" -> prayerOffsetIsha
    else -> 0
  }
}
