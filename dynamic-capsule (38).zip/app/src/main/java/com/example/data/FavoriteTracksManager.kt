package com.example.data

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.MediaStore
import com.example.media.MediaTrackInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class FavoriteTrack(
  val id: String,
  val title: String,
  val artist: String,
  val album: String = "",
  val packageName: String = "",
  val appName: String = "",
  val durationMs: Long = 0L,
  val addedAtMs: Long = System.currentTimeMillis()
) {
  fun formatDuration(): String {
    if (durationMs <= 0L) return "--:--"
    val totalSeconds = (durationMs / 1000L).toInt().coerceAtLeast(0)
    val mins = totalSeconds / 60
    val secs = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", mins, secs)
  }
}

class FavoriteTracksManager private constructor(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  private val _favorites = MutableStateFlow(loadFavorites())
  val favorites: StateFlow<List<FavoriteTrack>> = _favorites.asStateFlow()

  private fun loadFavorites(): List<FavoriteTrack> {
    val raw = prefs.getString(KEY_FAVORITES_JSON, null) ?: return emptyList()
    return try {
      val array = JSONArray(raw)
      buildList {
        for (i in 0 until array.length()) {
          val obj = array.optJSONObject(i) ?: continue
          val title = obj.optString("title", "").trim()
          if (title.isEmpty()) continue
          val artist = obj.optString("artist", "").trim()
          val id = obj.optString("id", "").ifBlank { buildTrackId(title, artist) }
          add(
            FavoriteTrack(
              id = id,
              title = title,
              artist = artist,
              album = obj.optString("album", ""),
              packageName = obj.optString("packageName", ""),
              appName = obj.optString("appName", ""),
              durationMs = obj.optLong("durationMs", 0L),
              addedAtMs = obj.optLong("addedAtMs", System.currentTimeMillis())
            )
          )
        }
      }
    } catch (_: Exception) {
      emptyList()
    }
  }

  private fun saveFavorites(list: List<FavoriteTrack>) {
    val array = JSONArray()
    list.forEach { fav ->
      val obj = JSONObject().apply {
        put("id", fav.id)
        put("title", fav.title)
        put("artist", fav.artist)
        put("album", fav.album)
        put("packageName", fav.packageName)
        put("appName", fav.appName)
        put("durationMs", fav.durationMs)
        put("addedAtMs", fav.addedAtMs)
      }
      array.put(obj)
    }
    prefs.edit().putString(KEY_FAVORITES_JSON, array.toString()).apply()
    _favorites.value = list
  }

  fun isFavorite(track: MediaTrackInfo?): Boolean {
    if (track == null || track.title.isBlank()) return false
    val id = buildTrackId(track.title, track.artist)
    return _favorites.value.any { it.id == id }
  }

  fun toggleFavorite(track: MediaTrackInfo): Boolean {
    if (track.title.isBlank()) return false
    val id = buildTrackId(track.title, track.artist)
    val current = _favorites.value.toMutableList()
    val existingIdx = current.indexOfFirst { it.id == id }
    return if (existingIdx >= 0) {
      current.removeAt(existingIdx)
      saveFavorites(current)
      false
    } else {
      val item = FavoriteTrack(
        id = id,
        title = track.title.trim(),
        artist = track.artist.trim(),
        album = track.album.trim(),
        packageName = track.packageName,
        appName = track.appName,
        durationMs = track.durationMs,
        addedAtMs = System.currentTimeMillis()
      )
      current.add(0, item)
      saveFavorites(current)
      true
    }
  }

  fun removeFavorite(trackId: String) {
    val updated = _favorites.value.filterNot { it.id == trackId }
    if (updated.size != _favorites.value.size) {
      saveFavorites(updated)
    }
  }

  fun clearAll() {
    saveFavorites(emptyList())
  }

  fun openOrSearchTrack(context: Context, fav: FavoriteTrack) {
    val query = listOf(fav.title, fav.artist).filter { it.isNotBlank() }.joinToString(" ")
    if (fav.packageName.isNotBlank()) {
      try {
        val searchIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
          `package` = fav.packageName
          putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Media.ENTRY_CONTENT_TYPE)
          putExtra(SearchManager.QUERY, query)
          putExtra(MediaStore.EXTRA_MEDIA_TITLE, fav.title)
          if (fav.artist.isNotBlank()) {
            putExtra(MediaStore.EXTRA_MEDIA_ARTIST, fav.artist)
          }
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (searchIntent.resolveActivity(context.packageManager) != null) {
          context.startActivity(searchIntent)
          return
        }
      } catch (_: Exception) {}

      try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(fav.packageName)
        if (launchIntent != null) {
          launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          context.startActivity(launchIntent)
          return
        }
      } catch (_: Exception) {}
    }

    try {
      val genericSearch = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
        putExtra(SearchManager.QUERY, query)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(genericSearch)
    } catch (_: Exception) {}
  }

  companion object {
    private const val PREFS_NAME = "dynamic_capsule_favorites"
    private const val KEY_FAVORITES_JSON = "favorites_json"

    @Volatile
    private var INSTANCE: FavoriteTracksManager? = null

    fun buildTrackId(title: String, artist: String): String {
      return "${title.trim().lowercase(Locale.ROOT)}|${artist.trim().lowercase(Locale.ROOT)}"
    }

    fun getInstance(context: Context): FavoriteTracksManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: FavoriteTracksManager(context).also { INSTANCE = it }
      }
    }
  }
}
