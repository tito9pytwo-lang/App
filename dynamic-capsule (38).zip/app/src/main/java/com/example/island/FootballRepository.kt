package com.example.island

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

enum class FootballLeague(val code: String, val labelAr: String) {
  UEFA_CL("uefa.champions", "دوري الأبطال"),
  EPL("eng.1", "الإنجليزي"),
  LALIGA("esp.1", "الإسباني"),
  SAUDI("ksa.1", "دوري روشن"),
  SERIE_A("ita.1", "الإيطالي"),
  BUNDESLIGA("ger.1", "الألماني"),
  ALL("all", "كل البطولات");

  companion object {
    fun fromCode(code: String): FootballLeague =
      entries.firstOrNull { it.code == code } ?: UEFA_CL
  }
}

data class FootballTeamSuggestion(
  val arabicName: String,
  val englishName: String,
  val leagueLabelAr: String,
  val aliases: List<String> = emptyList(),
  val logoUrl: String = "",
  val shortCode: String = "",
  val badgeColorHex: Long = 0xFF22C55EL,
  val countryAr: String = "",
  val venueOrInfoAr: String = ""
)

data class FootballTeamVisual(
  val logoUrl: String,
  val shortCode: String,
  val badgeColorHex: Long
)

data class FootballTeamDetailInfo(
  val displayNameAr: String,
  val englishName: String,
  val shortCode: String,
  val leagueLabelAr: String,
  val countryAr: String,
  val infoAr: String,
  val logoUrl: String,
  val badgeColorHex: Long,
  val liveOrTodayMatch: FootballMatchItem?
)

object FootballRepository {

  private const val TAG = "FootballRepository"

  private val httpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .cache(null)
      .connectTimeout(8, TimeUnit.SECONDS)
      .readTimeout(8, TimeUnit.SECONDS)
      .build()
  }

  private val _teamMedia = MutableStateFlow<Map<String, Pair<String, String>>>(emptyMap())
  val teamMediaFlow: StateFlow<Map<String, Pair<String, String>>> = _teamMedia.asStateFlow()
  private val directoryPrefetched = AtomicBoolean(false)

  private fun espnLogo(id: Int): String = "https://a.espncdn.com/i/teamlogos/soccer/500/$id.png"

  private fun normalizeMediaHttps(url: String): String {
    val trimmed = url.trim()
    return if (trimmed.startsWith("http://", ignoreCase = true)) {
      "https://" + trimmed.removePrefix("http://")
    } else {
      trimmed
    }
  }

  private fun recordDiscoveredMedia(entries: List<Triple<String, String, String>>) {
    if (entries.isEmpty()) return
    val updated = _teamMedia.value.toMutableMap()
    var changed = false
    for ((rawName, rawLogo, rawAbbrev) in entries) {
      val key = normalizeTeamQuery(rawName)
      val logo = normalizeMediaHttps(rawLogo)
      val abbr = rawAbbrev.trim().take(3).uppercase(Locale.US)
      if (key.isNotBlank() && (logo.isNotBlank() || abbr.isNotBlank())) {
        val prev = updated[key]
        val mergedLogo = logo.ifBlank { prev?.first.orEmpty() }
        val mergedAbbr = abbr.ifBlank { prev?.second.orEmpty() }
        if (prev?.first != mergedLogo || prev?.second != mergedAbbr) {
          updated[key] = mergedLogo to mergedAbbr
          changed = true
        }
      }
    }
    if (changed) {
      _teamMedia.value = updated
    }
  }

  internal fun parseEspnTeamsDirectoryJson(jsonStr: String): List<Triple<String, String, String>> {
    val results = mutableListOf<Triple<String, String, String>>()
    val root = runCatching { JSONObject(jsonStr) }.getOrNull() ?: return emptyList()

    fun collectFromTeamsArray(teamsArr: org.json.JSONArray?) {
      if (teamsArr == null) return
      for (i in 0 until teamsArr.length()) {
        val item = teamsArr.optJSONObject(i) ?: continue
        val teamObj = item.optJSONObject("team") ?: item
        val shortName = teamObj.optString("shortDisplayName", "").trim()
        val displayName = teamObj.optString("displayName", "").trim()
        val abbrev = teamObj.optString("abbreviation", "").trim()
        val directLogo = teamObj.optString("logo", "").trim()
        val arrayLogo = teamObj.optJSONArray("logos")?.optJSONObject(0)?.optString("href", "")?.trim().orEmpty()
        val logo = normalizeMediaHttps(directLogo.ifBlank { arrayLogo })
        if (logo.isNotBlank() || abbrev.isNotBlank()) {
          if (shortName.isNotBlank()) results.add(Triple(shortName, logo, abbrev))
          if (displayName.isNotBlank() && !displayName.equals(shortName, ignoreCase = true)) {
            results.add(Triple(displayName, logo, abbrev))
          }
        }
      }
    }

    collectFromTeamsArray(root.optJSONArray("teams"))
    val sports = root.optJSONArray("sports")
    if (sports != null) {
      for (s in 0 until sports.length()) {
        val leagues = sports.optJSONObject(s)?.optJSONArray("leagues") ?: continue
        for (l in 0 until leagues.length()) {
          collectFromTeamsArray(leagues.optJSONObject(l)?.optJSONArray("teams"))
        }
      }
    }
    if (results.isNotEmpty()) {
      recordDiscoveredMedia(results)
    }
    return results
  }

  suspend fun ensureTeamMediaLoaded() = withContext(Dispatchers.IO) {
    if (!directoryPrefetched.compareAndSet(false, true)) return@withContext
    val leagues = listOf("ksa.1", "esp.1", "eng.1", "uefa.champions", "ita.1", "ger.1")
    for (code in leagues) {
      runCatching {
        val req = Request.Builder()
          .url("https://site.api.espn.com/apis/site/v2/sports/soccer/$code/teams")
          .get()
          .build()
        httpClient.newCall(req).execute().use { resp ->
          if (resp.isSuccessful) {
            val body = resp.body?.string()
            if (!body.isNullOrBlank()) {
              parseEspnTeamsDirectoryJson(body)
            }
          }
        }
      }
    }
  }

  suspend fun fetchLiveMatches(leagueCode: String): Result<FootballState> = withContext(Dispatchers.IO) {
    val league = FootballLeague.fromCode(leagueCode)
    try {
      val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/${league.code}/scoreboard"
      val request = Request.Builder()
        .url(url)
        .cacheControl(CacheControl.FORCE_NETWORK)
        .header("Cache-Control", "no-cache, no-store, must-revalidate")
        .header("Pragma", "no-cache")
        .get()
        .build()
      val body = httpClient.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) {
          return@withContext Result.failure(
            IllegalStateException("تعذر الاتصال بخدمة المباريات (${resp.code})")
          )
        }
        resp.body?.string()
      } ?: return@withContext Result.failure(IllegalStateException("استجابة فارغة من خدمة المباريات"))

      val state = parseEspnScoreboardJson(body, league.code, league.labelAr)
      Result.success(state)
    } catch (e: Exception) {
      Log.w(TAG, "Failed fetching live football scores for ${league.code}", e)
      Result.failure(IllegalStateException(toFriendlyError(e)))
    }
  }

  internal fun parseEspnScoreboardJson(
    jsonStr: String,
    leagueCode: String,
    leagueNameAr: String
  ): FootballState {
    val root = JSONObject(jsonStr)
    val events = root.optJSONArray("events")
    val parsed = mutableListOf<FootballMatchItem>()

    if (events != null) {
      for (i in 0 until events.length()) {
        val ev = events.optJSONObject(i) ?: continue
        val id = ev.optString("id", "ev_$i")
        val competitions = ev.optJSONArray("competitions")
        val comp = competitions?.optJSONObject(0) ?: continue
        val competitors = comp.optJSONArray("competitors") ?: continue
        if (competitors.length() < 2) continue

        var homeObj = competitors.optJSONObject(0)
        var awayObj = competitors.optJSONObject(1)
        for (c in 0 until competitors.length()) {
          val obj = competitors.optJSONObject(c) ?: continue
          when (obj.optString("homeAway", "").lowercase(Locale.US)) {
            "home" -> homeObj = obj
            "away" -> awayObj = obj
          }
        }
        if (homeObj == null || awayObj == null) continue

        val homeName = extractTeamName(homeObj)
        val awayName = extractTeamName(awayObj)
        val homeLogo = extractTeamLogoUrl(homeObj)
        val awayLogo = extractTeamLogoUrl(awayObj)
        val homeAbbrev = extractTeamAbbrev(homeObj, homeName)
        val awayAbbrev = extractTeamAbbrev(awayObj, awayName)
        val homeScore = homeObj.optString("score", "0").toIntOrNull() ?: 0
        val awayScore = awayObj.optString("score", "0").toIntOrNull() ?: 0

        val statusObj = comp.optJSONObject("status") ?: ev.optJSONObject("status")
        val statusType = statusObj?.optJSONObject("type")
        val stateCode = statusType?.optString("state", "pre")?.lowercase(Locale.US) ?: "pre"
        val typeName = statusType?.optString("name", "")?.uppercase(Locale.US).orEmpty()
        val displayClock = statusObj?.optString("displayClock", "")?.trim().orEmpty()
        val shortDetail = statusType?.optString("shortDetail", "")?.trim().orEmpty()
        val description = statusType?.optString("description", "")?.trim().orEmpty()

        val matchPhase = resolveMatchPhase(stateCode, typeName, shortDetail, description)
        val isLive = matchPhase == FootballMatchPhase.LIVE_PLAY ||
          matchPhase == FootballMatchPhase.HALFTIME ||
          matchPhase == FootballMatchPhase.STOPPED
        val isFinished = matchPhase == FootballMatchPhase.FINISHED

        val parsedServerClock = if (matchPhase == FootballMatchPhase.LIVE_PLAY) {
          extractClockSeconds(statusObj, displayClock)
        } else {
          -1
        }
        val isStoppage = displayClock.contains("+") || shortDetail.contains("+")

        val isoDate = ev.optString("date", "")
        val kickoffMs = parseIsoUtcMillis(isoDate)
        val statusLabel = when (matchPhase) {
          FootballMatchPhase.HALFTIME -> "استراحة"
          FootballMatchPhase.STOPPED -> resolveStoppedLabelAr(typeName, shortDetail, description)
          FootballMatchPhase.FINISHED -> when {
            shortDetail.contains("PEN", ignoreCase = true) || typeName.contains("PEN") -> "انتهت (ركلات)"
            shortDetail.contains("AET", ignoreCase = true) || typeName.contains("AET") -> "انتهت (إضافي)"
            else -> "انتهت"
          }
          FootballMatchPhase.LIVE_PLAY -> when {
            displayClock.isNotBlank() -> displayClock
            shortDetail.isNotBlank() -> shortDetail
            else -> "مباشر"
          }
          FootballMatchPhase.SCHEDULED -> formatScheduledTime(isoDate) ?: shortDetail.ifBlank { "قريباً" }
        }

        parsed.add(
          FootballMatchItem(
            id = id,
            leagueNameAr = leagueNameAr,
            homeTeam = homeName,
            awayTeam = awayName,
            homeLogoUrl = homeLogo,
            awayLogoUrl = awayLogo,
            homeAbbrev = homeAbbrev,
            awayAbbrev = awayAbbrev,
            homeScore = homeScore,
            awayScore = awayScore,
            minuteOrStatus = statusLabel,
            isLive = isLive,
            isFinished = isFinished,
            matchPhase = matchPhase,
            clockSeconds = parsedServerClock,
            serverClockSeconds = parsedServerClock,
            isStoppageTime = isStoppage,
            kickoffTimeMs = kickoffMs
          )
        )
      }
    }

    if (parsed.isNotEmpty()) {
      val mediaBatch = buildList {
        parsed.forEach { m ->
          add(Triple(m.homeTeam, m.homeLogoUrl, m.homeAbbrev))
          add(Triple(m.awayTeam, m.awayLogoUrl, m.awayAbbrev))
        }
      }
      recordDiscoveredMedia(mediaBatch)
    }

    val ordered = sortMatchesForDisplay(parsed).take(12)

    return FootballState(
      isLoaded = true,
      isLoading = false,
      isAlertActive = ordered.any { it.isLive },
      leagueCode = leagueCode,
      leagueNameAr = leagueNameAr,
      matches = ordered,
      selectedIndex = 0,
      errorMessage = if (ordered.isEmpty()) "لا توجد مباريات متاحة اليوم في $leagueNameAr" else null,
      lastUpdatedMs = System.currentTimeMillis()
    )
  }

  private val curatedTeams: List<FootballTeamSuggestion> = listOf(
    // Saudi Pro League & Arab Giants
    FootballTeamSuggestion("الهلال", "Al Hilal", "دوري روشن", listOf("الهلال السعودي", "الزعيم", "HIL", "Al-Hilal"), shortCode = "HIL", badgeColorHex = 0xFF0EA5E9L, countryAr = "السعودية", venueOrInfoAr = "المملكة أرينا • الرياض"),
    FootballTeamSuggestion("النصر", "Al Nassr", "دوري روشن", listOf("النصر السعودي", "العالمي", "NAS", "Al-Nassr"), shortCode = "NAS", badgeColorHex = 0xFFFACC15L, countryAr = "السعودية", venueOrInfoAr = "الأول بارك • الرياض"),
    FootballTeamSuggestion("الاتحاد", "Al Ittihad", "دوري روشن", listOf("الاتحاد السعودي", "العميد", "ITT", "Al-Ittihad"), shortCode = "ITT", badgeColorHex = 0xFFF59E0BL, countryAr = "السعودية", venueOrInfoAr = "الجوهرة المشعة • جدة"),
    FootballTeamSuggestion("الأهلي السعودي", "Al Ahli", "دوري روشن", listOf("الاهلي", "الأهلي", "الراقي", "AHL", "Al-Ahli"), shortCode = "AHL", badgeColorHex = 0xFF10B981L, countryAr = "السعودية", venueOrInfoAr = "ملعب مدينة الملك عبدالله • جدة"),
    FootballTeamSuggestion("الشباب", "Al Shabab", "دوري روشن", listOf("الشباب السعودي", "Al-Shabab"), shortCode = "SHB", badgeColorHex = 0xFF94A3B8L, countryAr = "السعودية", venueOrInfoAr = "نادي الشباب • الرياض"),
    FootballTeamSuggestion("الاتفاق", "Al Ettifaq", "دوري روشن", listOf("Al-Ettifaq"), shortCode = "ETT", badgeColorHex = 0xFF22C55EL, countryAr = "السعودية", venueOrInfoAr = "نادي الاتفاق • الدمام"),
    FootballTeamSuggestion("القادسية", "Al Qadsiah", "دوري روشن", listOf("Al-Qadsiah"), shortCode = "QAD", badgeColorHex = 0xFFEF4444L, countryAr = "السعودية", venueOrInfoAr = "الخبر • المنطقة الشرقية"),
    FootballTeamSuggestion("التعاون", "Al Taawoun", "دوري روشن", listOf("Al-Taawoun"), shortCode = "TAA", badgeColorHex = 0xFFFACC15L, countryAr = "السعودية", venueOrInfoAr = "بريدة • القصيم"),
    FootballTeamSuggestion("الأهلي المصري", "Al Ahly", "أفريقيا / مصر", listOf("الأهلي", "الاهلي المصري", "الشياطين الحمر"), shortCode = "ALY", badgeColorHex = 0xFFEF4444L, countryAr = "مصر", venueOrInfoAr = "ستاد القاهرة الدولي • مصر"),
    FootballTeamSuggestion("الزمالك", "Zamalek", "أفريقيا / مصر", listOf("القلعة البيضاء"), shortCode = "ZAM", badgeColorHex = 0xFFF8FAACL, countryAr = "مصر", venueOrInfoAr = "ميت عقبة • القاهرة"),
    FootballTeamSuggestion("الوداد الرياضي", "Wydad AC", "أفريقيا / المغرب", listOf("الوداد", "Wydad"), shortCode = "WAC", badgeColorHex = 0xFFDC2626L, countryAr = "المغرب", venueOrInfoAr = "مركب محمد الخامس • الدار البيضاء"),
    FootballTeamSuggestion("الرجاء الرياضي", "Raja CA", "أفريقيا / المغرب", listOf("الرجاء", "Raja Casablanca"), shortCode = "RCA", badgeColorHex = 0xFF16A34AL, countryAr = "المغرب", venueOrInfoAr = "الدار البيضاء • المغرب"),
    FootballTeamSuggestion("الترجي التونسي", "Esperance Tunis", "أفريقيا / تونس", listOf("الترجي", "Esperance"), shortCode = "EST", badgeColorHex = 0xFFF97316L, countryAr = "تونس", venueOrInfoAr = "ملعب رادس • تونس"),
    FootballTeamSuggestion("السد", "Al Sadd", "قطر / آسيا", listOf("السد القطري", "Al-Sadd"), shortCode = "SAD", badgeColorHex = 0xFFE2E8F0L, countryAr = "قطر", venueOrInfoAr = "ملعب جاسم بن حمد • الدوحة"),
    FootballTeamSuggestion("العين", "Al Ain", "الإمارات / آسيا", listOf("العين الإماراتي", "Al-Ain"), shortCode = "AIN", badgeColorHex = 0xFFA855F7L, countryAr = "الإمارات", venueOrInfoAr = "استاد هزاع بن زايد • العين"),

    // La Liga
    FootballTeamSuggestion("ريال مدريد", "Real Madrid", "الإسباني / الأبطال", listOf("الريال", "الملكي", "RMA", "Madrid"), logoUrl = espnLogo(86), shortCode = "RMA", badgeColorHex = 0xFFF59E0BL, countryAr = "إسبانيا", venueOrInfoAr = "سانتياغو برنابيو • مدريد"),
    FootballTeamSuggestion("برشلونة", "Barcelona", "الإسباني / الأبطال", listOf("البرسا", "البارسا", "BAR", "FC Barcelona", "Barca"), logoUrl = espnLogo(83), shortCode = "BAR", badgeColorHex = 0xFFE11D48L, countryAr = "إسبانيا", venueOrInfoAr = "سبوتيفاي كامب نو • برشلونة"),
    FootballTeamSuggestion("أتلتيكو مدريد", "Atletico Madrid", "الإسباني", listOf("اتلتيكو", "ATM", "Atlético"), logoUrl = espnLogo(1068), shortCode = "ATM", badgeColorHex = 0xFFEF4444L, countryAr = "إسبانيا", venueOrInfoAr = "سيفيتاس ميتروبوليتانو • مدريد"),
    FootballTeamSuggestion("إشبيلية", "Sevilla", "الإسباني", listOf("اشبيلية", "SEV"), logoUrl = espnLogo(243), shortCode = "SEV", badgeColorHex = 0xFFDC2626L, countryAr = "إسبانيا", venueOrInfoAr = "رامون سانشيز بيزخوان"),
    FootballTeamSuggestion("أتلتيك بيلباو", "Athletic Club", "الإسباني", listOf("بيلباو", "Athletic Bilbao", "ATH"), shortCode = "ATH", badgeColorHex = 0xFFEF4444L, countryAr = "إسبانيا", venueOrInfoAr = "سان ماميس • بلباو"),
    FootballTeamSuggestion("ريال سوسيداد", "Real Sociedad", "الإسباني", listOf("سوسيداد", "RSO"), shortCode = "RSO", badgeColorHex = 0xFF38BDF8L, countryAr = "إسبانيا", venueOrInfoAr = "ريالي أرينا • سان سيباستيان"),
    FootballTeamSuggestion("فالنسيا", "Valencia", "الإسباني", listOf("VAL"), shortCode = "VAL", badgeColorHex = 0xFFF97316L, countryAr = "إسبانيا", venueOrInfoAr = "ميستايا • فالنسيا"),
    FootballTeamSuggestion("فياريال", "Villarreal", "الإسباني", listOf("VIL"), shortCode = "VIL", badgeColorHex = 0xFFFACC15L, countryAr = "إسبانيا", venueOrInfoAr = "لا سيراميكا • فياريال"),
    FootballTeamSuggestion("ريال بيتيس", "Real Betis", "الإسباني", listOf("بيتيس", "BET"), shortCode = "BET", badgeColorHex = 0xFF22C55EL, countryAr = "إسبانيا", venueOrInfoAr = "بينيتو فيامارين • إشبيلية"),
    FootballTeamSuggestion("جيرونا", "Girona", "الإسباني", listOf("GIR"), shortCode = "GIR", badgeColorHex = 0xFFEF4444L, countryAr = "إسبانيا", venueOrInfoAr = "مونتيليفي • جيرونا"),

    // Premier League
    FootballTeamSuggestion("ليفربول", "Liverpool", "الإنجليزي / الأبطال", listOf("الريدز", "LIV"), logoUrl = espnLogo(364), shortCode = "LIV", badgeColorHex = 0xFFEF4444L, countryAr = "إنجلترا", venueOrInfoAr = "أنفيلد • ليفربول"),
    FootballTeamSuggestion("مانشستر سيتي", "Manchester City", "الإنجليزي / الأبطال", listOf("السيتي", "Man City", "MCI"), logoUrl = espnLogo(382), shortCode = "MCI", badgeColorHex = 0xFF38BDF8L, countryAr = "إنجلترا", venueOrInfoAr = "ملعب الاتحاد • مانشستر"),
    FootballTeamSuggestion("أرسنال", "Arsenal", "الإنجليزي / الأبطال", listOf("ارسنال", "أرسنل", "المدفعجية", "ARS"), logoUrl = espnLogo(359), shortCode = "ARS", badgeColorHex = 0xFFDC2626L, countryAr = "إنجلترا", venueOrInfoAr = "ملعب الإمارات • لندن"),
    FootballTeamSuggestion("مانشستر يونايتد", "Manchester United", "الإنجليزي", listOf("اليونايتد", "مان يونايتد", "Man United", "MUN", "Man Utd"), logoUrl = espnLogo(360), shortCode = "MUN", badgeColorHex = 0xFFEF4444L, countryAr = "إنجلترا", venueOrInfoAr = "أولد ترافورد • مانشستر"),
    FootballTeamSuggestion("تشيلسي", "Chelsea", "الإنجليزي", listOf("البلوز", "CHE"), logoUrl = espnLogo(363), shortCode = "CHE", badgeColorHex = 0xFF3B82F6L, countryAr = "إنجلترا", venueOrInfoAr = "ستامفورد بريدج • لندن"),
    FootballTeamSuggestion("توتنهام", "Tottenham", "الإنجليزي", listOf("توتنهام هوتسبير", "Spurs", "TOT"), logoUrl = espnLogo(367), shortCode = "TOT", badgeColorHex = 0xFFE2E8F0L, countryAr = "إنجلترا", venueOrInfoAr = "توتنهام هوتسبير • لندن"),
    FootballTeamSuggestion("نيوكاسل يونايتد", "Newcastle", "الإنجليزي", listOf("نيوكاسل", "NEW"), logoUrl = espnLogo(361), shortCode = "NEW", badgeColorHex = 0xFF94A3B8L, countryAr = "إنجلترا", venueOrInfoAr = "سانت جيمس بارك"),
    FootballTeamSuggestion("أستون فيلا", "Aston Villa", "الإنجليزي", listOf("استون فيلا", "AVL"), logoUrl = espnLogo(362), shortCode = "AVL", badgeColorHex = 0xFFA855F7L, countryAr = "إنجلترا", venueOrInfoAr = "فيلا بارك • برمنغهام"),
    FootballTeamSuggestion("برايتون", "Brighton", "الإنجليزي", listOf("BHA"), shortCode = "BHA", badgeColorHex = 0xFF38BDF8L, countryAr = "إنجلترا", venueOrInfoAr = "أميكس ستاديوم"),
    FootballTeamSuggestion("وست هام", "West Ham", "الإنجليزي", listOf("WHU"), shortCode = "WHU", badgeColorHex = 0xFFFB7185L, countryAr = "إنجلترا", venueOrInfoAr = "ملعب لندن الأولمبي"),

    // Serie A
    FootballTeamSuggestion("إنتر ميلان", "Inter", "الإيطالي / الأبطال", listOf("انتر ميلان", "الإنتر", "Inter Milan", "INT"), logoUrl = espnLogo(110), shortCode = "INT", badgeColorHex = 0xFF2563EBL, countryAr = "إيطاليا", venueOrInfoAr = "جوزيبي مياتزا • ميلانو"),
    FootballTeamSuggestion("إي سي ميلان", "AC Milan", "الإيطالي / الأبطال", listOf("ميلان", "الميلان", "MIL", "Milan"), logoUrl = espnLogo(103), shortCode = "MIL", badgeColorHex = 0xFFDC2626L, countryAr = "إيطاليا", venueOrInfoAr = "سان سيرو • ميلانو"),
    FootballTeamSuggestion("يوفنتوس", "Juventus", "الإيطالي", listOf("اليوفي", "JUV"), logoUrl = espnLogo(111), shortCode = "JUV", badgeColorHex = 0xFFE2E8F0L, countryAr = "إيطاليا", venueOrInfoAr = "أليانز ستاديوم • تورينو"),
    FootballTeamSuggestion("نابولي", "Napoli", "الإيطالي", listOf("NAP"), logoUrl = espnLogo(114), shortCode = "NAP", badgeColorHex = 0xFF0EA5E9L, countryAr = "إيطاليا", venueOrInfoAr = "دييغو أرماندو مارادونا • نابولي"),
    FootballTeamSuggestion("روما", "AS Roma", "الإيطالي", listOf("Roma", "ROM"), logoUrl = espnLogo(104), shortCode = "ROM", badgeColorHex = 0xFFF97316L, countryAr = "إيطاليا", venueOrInfoAr = "الأولمبيكو • روما"),
    FootballTeamSuggestion("أتالانتا", "Atalanta", "الإيطالي", listOf("اتالانتا", "ATA"), shortCode = "ATA", badgeColorHex = 0xFF38BDF8L, countryAr = "إيطاليا", venueOrInfoAr = "جيويس ستاديوم • بيرغامو"),
    FootballTeamSuggestion("لاتسيو", "Lazio", "الإيطالي", listOf("LAZ"), shortCode = "LAZ", badgeColorHex = 0xFF38BDF8L, countryAr = "إيطاليا", venueOrInfoAr = "الأولمبيكو • روما"),

    // Bundesliga & Ligue 1 & Europe
    FootballTeamSuggestion("بايرن ميونخ", "Bayern Munich", "الألماني / الأبطال", listOf("البايرن", "بايرن", "BAY", "FC Bayern"), logoUrl = espnLogo(132), shortCode = "BAY", badgeColorHex = 0xFFDC2626L, countryAr = "ألمانيا", venueOrInfoAr = "أليانز أرينا • ميونخ"),
    FootballTeamSuggestion("بوروسيا دورتموند", "Borussia Dortmund", "الألماني / الأبطال", listOf("دورتموند", "Dortmund", "BVB"), logoUrl = espnLogo(124), shortCode = "BVB", badgeColorHex = 0xFFFACC15L, countryAr = "ألمانيا", venueOrInfoAr = "سيغنال إيدونا بارك"),
    FootballTeamSuggestion("باير ليفركوزن", "Bayer Leverkusen", "الألماني", listOf("ليفركوزن", "Leverkusen", "B04"), shortCode = "B04", badgeColorHex = 0xFFEF4444L, countryAr = "ألمانيا", venueOrInfoAr = "باي أرينا • ليفركوزن"),
    FootballTeamSuggestion("آر بي لايبزيغ", "RB Leipzig", "الألماني", listOf("لايبزيغ", "Leipzig", "RBL"), shortCode = "RBL", badgeColorHex = 0xFFFB7185L, countryAr = "ألمانيا", venueOrInfoAr = "ريد بول أرينا"),
    FootballTeamSuggestion("باريس سان جيرمان", "Paris Saint-Germain", "الأبطال / الفرنسي", listOf("باريس", "بي اس جي", "PSG"), logoUrl = espnLogo(160), shortCode = "PSG", badgeColorHex = 0xFF2563EBL, countryAr = "فرنسا", venueOrInfoAr = "حديقة الأمراء • باريس"),
    FootballTeamSuggestion("مارسيليا", "Marseille", "الفرنسي", listOf("OM"), shortCode = "OM", badgeColorHex = 0xFF38BDF8L, countryAr = "فرنسا", venueOrInfoAr = "فيلودروم • مارسيليا"),
    FootballTeamSuggestion("بنفيكا", "Benfica", "البرتغالي / الأبطال", listOf("BEN"), shortCode = "BEN", badgeColorHex = 0xFFDC2626L, countryAr = "البرتغال", venueOrInfoAr = "إستاديو دا لوز • لشبونة"),
    FootballTeamSuggestion("بورتو", "Porto", "البرتغالي / الأبطال", listOf("POR"), shortCode = "POR", badgeColorHex = 0xFF0EA5E9L, countryAr = "البرتغال", venueOrInfoAr = "إستاديو دو دراغاو"),
    FootballTeamSuggestion("سبورتينغ لشبونة", "Sporting CP", "البرتغالي / الأبطال", listOf("سبورتينغ", "SCP"), shortCode = "SCP", badgeColorHex = 0xFF22C55EL, countryAr = "البرتغال", venueOrInfoAr = "جوزيه ألفالادي • لشبونة"),
    FootballTeamSuggestion("أياكس", "Ajax", "الهولندي", listOf("اياكس", "AJX"), logoUrl = espnLogo(139), shortCode = "AJX", badgeColorHex = 0xFFEF4444L, countryAr = "هولندا", venueOrInfoAr = "يوهان كرويف أرينا • أمستردام"),

    // National Teams
    FootballTeamSuggestion("السعودية", "Saudi Arabia", "منتخبات", listOf("المنتخب السعودي", "الأخضر", "KSA"), shortCode = "KSA", badgeColorHex = 0xFF16A34AL, countryAr = "آسيا", venueOrInfoAr = "الأخضر السعودي"),
    FootballTeamSuggestion("مصر", "Egypt", "منتخبات", listOf("منتخب مصر", "الفراعنة", "EGY"), shortCode = "EGY", badgeColorHex = 0xFFDC2626L, countryAr = "أفريقيا", venueOrInfoAr = "منتخب الفراعنة"),
    FootballTeamSuggestion("المغرب", "Morocco", "منتخبات", listOf("منتخب المغرب", "أسود الأطلس", "MAR"), shortCode = "MAR", badgeColorHex = 0xFFDC2626L, countryAr = "أفريقيا", venueOrInfoAr = "أسود الأطلس"),
    FootballTeamSuggestion("الجزائر", "Algeria", "منتخبات", listOf("منتخب الجزائر", "ALG"), shortCode = "ALG", badgeColorHex = 0xFF22C55EL, countryAr = "أفريقيا", venueOrInfoAr = "محاربو الصحراء"),
    FootballTeamSuggestion("تونس", "Tunisia", "منتخبات", listOf("منتخب تونس", "TUN"), shortCode = "TUN", badgeColorHex = 0xFFEF4444L, countryAr = "أفريقيا", venueOrInfoAr = "نسور قرطاج"),
    FootballTeamSuggestion("العراق", "Iraq", "منتخبات", listOf("منتخب العراق", "IRQ"), shortCode = "IRQ", badgeColorHex = 0xFF16A34AL, countryAr = "آسيا", venueOrInfoAr = "أسود الرافدين"),
    FootballTeamSuggestion("الأردن", "Jordan", "منتخبات", listOf("منتخب الأردن", "النشامى", "JOR"), shortCode = "JOR", badgeColorHex = 0xFFDC2626L, countryAr = "آسيا", venueOrInfoAr = "النشامى"),
    FootballTeamSuggestion("البرازيل", "Brazil", "منتخبات", listOf("منتخب البرازيل", "BRA"), shortCode = "BRA", badgeColorHex = 0xFFFACC15L, countryAr = "أمريكا الجنوبية", venueOrInfoAr = "السيليساو البرازيلي"),
    FootballTeamSuggestion("الأرجنتين", "Argentina", "منتخبات", listOf("منتخب الأرجنتين", "ARG"), shortCode = "ARG", badgeColorHex = 0xFF38BDF8L, countryAr = "أمريكا الجنوبية", venueOrInfoAr = "التانغو الأرجنتيني"),
    FootballTeamSuggestion("فرنسا", "France", "منتخبات", listOf("منتخب فرنسا", "FRA"), shortCode = "FRA", badgeColorHex = 0xFF2563EBL, countryAr = "أوروبا", venueOrInfoAr = "الديوك الفرنسية"),
    FootballTeamSuggestion("إسبانيا", "Spain", "منتخبات", listOf("منتخب إسبانيا", "ESP"), shortCode = "ESP", badgeColorHex = 0xFFEF4444L, countryAr = "أوروبا", venueOrInfoAr = "لاروخا الإسباني"),
    FootballTeamSuggestion("إنجلترا", "England", "منتخبات", listOf("منتخب إنجلترا", "ENG"), shortCode = "ENG", badgeColorHex = 0xFFE2E8F0L, countryAr = "أوروبا", venueOrInfoAr = "الأسود الثلاثة"),
    FootballTeamSuggestion("ألمانيا", "Germany", "منتخبات", listOf("منتخب ألمانيا", "GER"), shortCode = "GER", badgeColorHex = 0xFFE2E8F0L, countryAr = "أوروبا", venueOrInfoAr = "المانشافت الألماني"),
    FootballTeamSuggestion("البرتغال", "Portugal", "منتخبات", listOf("منتخب البرتغال", "POR"), shortCode = "POR", badgeColorHex = 0xFFDC2626L, countryAr = "أوروبا", venueOrInfoAr = "برازيل أوروبا")
  )

  private fun normalizeTeamQuery(raw: String): String {
    return raw.trim()
      .lowercase(Locale.ROOT)
      .replace('أ', 'ا')
      .replace('إ', 'ا')
      .replace('آ', 'ا')
      .replace('ة', 'ه')
      .replace('ى', 'ي')
      .replace("-", " ")
  }

  fun resolveTeamVisual(
    teamNameOrQuery: String,
    liveMatches: List<FootballMatchItem> = emptyList(),
    discoveredMedia: Map<String, Pair<String, String>> = _teamMedia.value
  ): FootballTeamVisual {
    val clean = teamNameOrQuery.trim()
    val normQ = normalizeTeamQuery(clean)
    val entry = resolveTeamCatalogEntry(clean)

    // 1. Live match logo takes precedence if currently available
    for (m in liveMatches) {
      if (m.homeTeam.isNotBlank() && areSameTeam(m.homeTeam, clean)) {
        val logo = normalizeMediaHttps(m.homeLogoUrl).ifBlank { entry?.logoUrl.orEmpty() }
        val abbr = m.homeAbbrev.ifBlank { entry?.shortCode.orEmpty() }.ifBlank { clean.take(2).uppercase(Locale.US) }
        return FootballTeamVisual(logo, abbr, entry?.badgeColorHex ?: 0xFF22C55EL)
      }
      if (m.awayTeam.isNotBlank() && areSameTeam(m.awayTeam, clean)) {
        val logo = normalizeMediaHttps(m.awayLogoUrl).ifBlank { entry?.logoUrl.orEmpty() }
        val abbr = m.awayAbbrev.ifBlank { entry?.shortCode.orEmpty() }.ifBlank { clean.take(2).uppercase(Locale.US) }
        return FootballTeamVisual(logo, abbr, entry?.badgeColorHex ?: 0xFF22C55EL)
      }
    }

    // 2. Discovered media cache from scoreboard / ESPN teams directory
    val lookupTokens = buildList {
      if (normQ.isNotBlank()) add(normQ)
      if (entry != null) {
        add(normalizeTeamQuery(entry.englishName))
        entry.aliases.forEach { add(normalizeTeamQuery(it)) }
      }
    }
    var mediaLogo = ""
    var mediaAbbr = ""
    for (tok in lookupTokens) {
      val hit = discoveredMedia[tok]
      if (hit != null) {
        if (mediaLogo.isBlank() && hit.first.isNotBlank()) mediaLogo = hit.first
        if (mediaAbbr.isBlank() && hit.second.isNotBlank()) mediaAbbr = hit.second
      }
    }

    val finalLogo = mediaLogo.ifBlank { entry?.logoUrl.orEmpty() }
    val finalCode = entry?.shortCode?.ifBlank { null }
      ?: mediaAbbr.ifBlank { null }
      ?: (entry?.englishName ?: clean).take(3).uppercase(Locale.US)
    val finalColor = entry?.badgeColorHex ?: 0xFF22C55EL
    return FootballTeamVisual(
      logoUrl = finalLogo,
      shortCode = finalCode,
      badgeColorHex = finalColor
    )
  }

  fun findMatchForTeam(
    teamQuery: String,
    matches: List<FootballMatchItem>
  ): FootballMatchItem? {
    if (teamQuery.isBlank() || matches.isEmpty()) return null
    return matches.firstOrNull { !it.isFinished && it.isLive && matchesFavoriteTeam(it, teamQuery) }
      ?: matches.firstOrNull { it.matchPhase == FootballMatchPhase.SCHEDULED && matchesFavoriteTeam(it, teamQuery) }
      ?: matches.firstOrNull { matchesFavoriteTeam(it, teamQuery) }
  }

  fun resolveTeamDetails(
    teamQuery: String,
    liveMatches: List<FootballMatchItem> = emptyList(),
    discoveredMedia: Map<String, Pair<String, String>> = _teamMedia.value
  ): FootballTeamDetailInfo {
    val clean = teamQuery.trim()
    val entry = resolveTeamCatalogEntry(clean)
    val visual = resolveTeamVisual(clean, liveMatches, discoveredMedia)
    val match = findMatchForTeam(clean, liveMatches)
    return FootballTeamDetailInfo(
      displayNameAr = entry?.arabicName ?: clean,
      englishName = entry?.englishName ?: clean,
      shortCode = visual.shortCode,
      leagueLabelAr = entry?.leagueLabelAr?.ifBlank { match?.leagueNameAr.orEmpty() } ?: match?.leagueNameAr.orEmpty(),
      countryAr = entry?.countryAr.orEmpty(),
      infoAr = entry?.venueOrInfoAr.orEmpty(),
      logoUrl = visual.logoUrl,
      badgeColorHex = visual.badgeColorHex,
      liveOrTodayMatch = match
    )
  }

  fun suggestTeams(
    query: String,
    liveMatches: List<FootballMatchItem> = emptyList(),
    limit: Int = 8
  ): List<FootballTeamSuggestion> {
    val normQ = normalizeTeamQuery(query)
    if (normQ.isBlank()) return emptyList()

    val mediaMap = _teamMedia.value
    // Merge live match teams first so active teams always show up with crests
    val liveSuggestions = buildList {
      for (m in liveMatches) {
        if (m.homeTeam.isNotBlank()) {
          val known = curatedTeams.firstOrNull {
            it.englishName.equals(m.homeTeam, ignoreCase = true) ||
              it.aliases.any { a -> a.equals(m.homeTeam, ignoreCase = true) || a.equals(m.homeAbbrev, ignoreCase = true) }
          }
          add(
            known?.copy(
              logoUrl = normalizeMediaHttps(m.homeLogoUrl).ifBlank { known.logoUrl },
              shortCode = known.shortCode.ifBlank { m.homeAbbrev }
            ) ?: FootballTeamSuggestion(
              arabicName = m.homeTeam,
              englishName = m.homeTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباشر" },
              aliases = listOfNotNull(m.homeAbbrev.takeIf { it.isNotBlank() }),
              logoUrl = normalizeMediaHttps(m.homeLogoUrl),
              shortCode = m.homeAbbrev
            )
          )
        }
        if (m.awayTeam.isNotBlank()) {
          val known = curatedTeams.firstOrNull {
            it.englishName.equals(m.awayTeam, ignoreCase = true) ||
              it.aliases.any { a -> a.equals(m.awayTeam, ignoreCase = true) || a.equals(m.awayAbbrev, ignoreCase = true) }
          }
          add(
            known?.copy(
              logoUrl = normalizeMediaHttps(m.awayLogoUrl).ifBlank { known.logoUrl },
              shortCode = known.shortCode.ifBlank { m.awayAbbrev }
            ) ?: FootballTeamSuggestion(
              arabicName = m.awayTeam,
              englishName = m.awayTeam,
              leagueLabelAr = m.leagueNameAr.ifBlank { "مباشر" },
              aliases = listOfNotNull(m.awayAbbrev.takeIf { it.isNotBlank() }),
              logoUrl = normalizeMediaHttps(m.awayLogoUrl),
              shortCode = m.awayAbbrev
            )
          )
        }
      }
    }

    val combinedPool = (liveSuggestions + curatedTeams)
      .distinctBy { "${it.arabicName}|${it.englishName.lowercase(Locale.ROOT)}" }
      .map { item ->
        if (item.logoUrl.isNotBlank()) item else {
          val vis = resolveTeamVisual(item.englishName, emptyList(), mediaMap)
          item.copy(
            logoUrl = vis.logoUrl,
            shortCode = item.shortCode.ifBlank { vis.shortCode }
          )
        }
      }

    return combinedPool.mapNotNull { item ->
      val candidates = listOf(item.arabicName, item.englishName) + item.aliases
      val norms = candidates.map { normalizeTeamQuery(it) }
      val bestRank = when {
        norms.any { it.startsWith(normQ) } -> 0
        norms.any {
          it.split(' ').any { word ->
            word.startsWith(normQ) || (word.startsWith("ال") && word.removePrefix("ال").startsWith(normQ))
          }
        } -> 1
        norms.any { it.contains(normQ) } -> 2
        else -> return@mapNotNull null
      }
      bestRank to item
    }
      .sortedBy { it.first }
      .map { it.second }
      .take(limit)
  }

  fun getCatalogTeams(): List<FootballTeamSuggestion> = curatedTeams

  fun resolveTeamCatalogEntry(teamQuery: String): FootballTeamSuggestion? {
    val normQ = normalizeTeamQuery(teamQuery)
    if (normQ.isBlank()) return null
    curatedTeams.firstOrNull { item ->
      val exactTokens = (listOf(item.arabicName, item.englishName) + item.aliases).map { normalizeTeamQuery(it) }
      exactTokens.any { it == normQ }
    }?.let { return it }
    if (normQ.length < 3) return null
    return curatedTeams.firstOrNull { item ->
      val tokens = (listOf(item.arabicName, item.englishName) + item.aliases).map { normalizeTeamQuery(it) }
      tokens.any { it.contains(normQ) }
    }
  }

  fun areSameTeam(first: String, second: String): Boolean {
    val n1 = normalizeTeamQuery(first)
    val n2 = normalizeTeamQuery(second)
    if (n1.isBlank() || n2.isBlank()) return false
    if (n1 == n2) return true
    val e1 = resolveTeamCatalogEntry(first)
    val e2 = resolveTeamCatalogEntry(second)
    return e1 != null && e2 != null && e1.englishName.equals(e2.englishName, ignoreCase = true)
  }

  internal fun matchesFavoriteTeam(match: FootballMatchItem, favoriteTeam: String): Boolean {
    val q = favoriteTeam.trim()
    if (q.isBlank()) return false
    val normQ = normalizeTeamQuery(q)

    val directMatch = match.homeTeam.contains(q, ignoreCase = true) ||
      match.awayTeam.contains(q, ignoreCase = true) ||
      match.homeAbbrev.equals(q, ignoreCase = true) ||
      match.awayAbbrev.equals(q, ignoreCase = true)
    if (directMatch) return true

    // Resolve Arabic / alias favorite names (e.g. "ريال مدريد" -> "Real Madrid")
    val matchingCatalogEntries = curatedTeams.filter { item ->
      val allTokens = (listOf(item.arabicName, item.englishName) + item.aliases).map { normalizeTeamQuery(it) }
      allTokens.any { it == normQ || (normQ.length >= 3 && it.contains(normQ)) }
    }
    return matchingCatalogEntries.any { entry ->
      val eng = normalizeTeamQuery(entry.englishName)
      val homeNorm = normalizeTeamQuery(match.homeTeam)
      val awayNorm = normalizeTeamQuery(match.awayTeam)
      homeNorm.contains(eng) || awayNorm.contains(eng) ||
        entry.aliases.any { alias ->
          val aNorm = normalizeTeamQuery(alias)
          aNorm.length >= 3 && (homeNorm.contains(aNorm) || awayNorm.contains(aNorm))
        }
    }
  }

  internal fun matchesFavoriteTeam(match: FootballMatchItem, favoriteTeams: List<String>): Boolean {
    return favoriteTeams.any { team -> matchesFavoriteTeam(match, team) }
  }

  internal fun sortMatchesForDisplay(
    matches: List<FootballMatchItem>,
    favoriteTeam: String = ""
  ): List<FootballMatchItem> {
    val teams = if (favoriteTeam.isBlank()) emptyList() else listOf(favoriteTeam)
    return sortMatchesForDisplay(matches, teams)
  }

  internal fun sortMatchesForDisplay(
    matches: List<FootballMatchItem>,
    favoriteTeams: List<String>
  ): List<FootballMatchItem> {
    return matches.sortedWith(
      compareBy<FootballMatchItem>(
        {
          when (it.matchPhase) {
            FootballMatchPhase.LIVE_PLAY -> 0
            FootballMatchPhase.HALFTIME -> 1
            FootballMatchPhase.STOPPED -> 2
            FootballMatchPhase.FINISHED -> 3
            FootballMatchPhase.SCHEDULED -> 4
          }
        },
        { if (matchesFavoriteTeam(it, favoriteTeams)) 0 else 1 },
        { if (it.kickoffTimeMs > 0L) it.kickoffTimeMs else Long.MAX_VALUE }
      )
    )
  }

  internal fun markPreMatchFlags(
    matches: List<FootballMatchItem>,
    reminderMinutes: Int,
    nowMs: Long = System.currentTimeMillis()
  ): List<FootballMatchItem> {
    val windowMs = reminderMinutes.coerceIn(5, 60) * 60_000L
    return matches.map { item ->
      val soon = item.matchPhase == FootballMatchPhase.SCHEDULED &&
        item.kickoffTimeMs > nowMs &&
        (item.kickoffTimeMs - nowMs) <= windowMs
      item.copy(isPreMatchSoon = soon)
    }
  }

  internal fun detectUpcomingMatchReminder(
    matches: List<FootballMatchItem>,
    reminderMinutes: Int,
    favoriteTeam: String = "",
    nowMs: Long = System.currentTimeMillis(),
    alreadyRemindedIds: Set<String> = emptySet()
  ): FootballMatchEvent? {
    val teams = if (favoriteTeam.isBlank()) emptyList() else listOf(favoriteTeam)
    return detectUpcomingMatchReminder(
      matches = matches,
      reminderMinutes = reminderMinutes,
      favoriteTeams = teams,
      nowMs = nowMs,
      alreadyRemindedIds = alreadyRemindedIds
    )
  }

  internal fun detectUpcomingMatchReminder(
    matches: List<FootballMatchItem>,
    reminderMinutes: Int,
    favoriteTeams: List<String>,
    nowMs: Long = System.currentTimeMillis(),
    alreadyRemindedIds: Set<String> = emptySet()
  ): FootballMatchEvent? {
    val windowMs = reminderMinutes.coerceIn(5, 60) * 60_000L
    val candidates = matches.filter { item ->
      item.matchPhase == FootballMatchPhase.SCHEDULED &&
        item.kickoffTimeMs > nowMs &&
        (item.kickoffTimeMs - nowMs) <= windowMs &&
        !alreadyRemindedIds.contains(item.id)
    }.sortedWith(
      compareBy<FootballMatchItem>(
        { if (matchesFavoriteTeam(it, favoriteTeams)) 0 else 1 },
        { it.kickoffTimeMs }
      )
    )
    val match = candidates.firstOrNull() ?: return null
    val minsLeft = (((match.kickoffTimeMs - nowMs) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    return FootballMatchEvent(
      matchId = match.id,
      type = FootballEventType.KICKOFF_SOON,
      titleAr = "تبدأ قريباً!",
      subtitleAr = "خلال $minsLeft د • ${match.homeTeam} × ${match.awayTeam}",
      homeTeam = match.homeTeam,
      awayTeam = match.awayTeam,
      homeScore = match.homeScore,
      awayScore = match.awayScore,
      timestampMs = nowMs
    )
  }

  internal fun mergeLiveClocks(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>
  ): List<FootballMatchItem> {
    if (previous.isEmpty()) return fresh
    val prevById = previous.associateBy { it.id }
    return fresh.map { next ->
      val old = prevById[next.id] ?: return@map next
      if (next.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        old.matchPhase == FootballMatchPhase.LIVE_PLAY &&
        next.serverClockSeconds >= 0 &&
        next.serverClockSeconds == old.serverClockSeconds &&
        old.clockSeconds >= next.serverClockSeconds
      ) {
        // Keep local second ticker tightly bounded (+12s max) so clock never drifts ahead of live match.
        val smoothSeconds = old.clockSeconds.coerceAtMost(next.serverClockSeconds + 12)
        next.copy(clockSeconds = smoothSeconds)
      } else {
        next
      }
    }
  }

  internal fun detectMatchEvent(
    previous: List<FootballMatchItem>,
    fresh: List<FootballMatchItem>,
    preferredMatchId: String? = null
  ): FootballMatchEvent? {
    if (previous.isEmpty() || fresh.isEmpty()) return null
    val prevById = previous.associateBy { it.id }
    val candidates = mutableListOf<Pair<Int, FootballMatchEvent>>()

    for (newItem in fresh) {
      val oldItem = prevById[newItem.id] ?: continue
      val homeScored = newItem.homeScore > oldItem.homeScore
      val awayScored = newItem.awayScore > oldItem.awayScore
      val homeDisallowed = newItem.homeScore < oldItem.homeScore
      val awayDisallowed = newItem.awayScore < oldItem.awayScore
      val isPreferredBoost = if (newItem.id == preferredMatchId) 0 else 10

      if (homeScored || awayScored) {
        val side = when {
          homeScored && awayScored -> FootballScoringSide.BOTH
          homeScored -> FootballScoringSide.HOME
          else -> FootballScoringSide.AWAY
        }
        val scorerTeam = when (side) {
          FootballScoringSide.HOME -> newItem.homeTeam
          FootballScoringSide.AWAY -> newItem.awayTeam
          FootballScoringSide.BOTH -> "${newItem.homeTeam} و${newItem.awayTeam}"
        }
        candidates.add(
          (0 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.GOAL,
            titleAr = "هدف!",
            subtitleAr = "$scorerTeam • ${newItem.homeScore} - ${newItem.awayScore}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore,
            scoringSide = side
          )
        )
      } else if (homeDisallowed || awayDisallowed) {
        val side = when {
          homeDisallowed && awayDisallowed -> FootballScoringSide.BOTH
          homeDisallowed -> FootballScoringSide.HOME
          else -> FootballScoringSide.AWAY
        }
        val disallowedTeam = when (side) {
          FootballScoringSide.HOME -> newItem.homeTeam
          FootballScoringSide.AWAY -> newItem.awayTeam
          FootballScoringSide.BOTH -> "${newItem.homeTeam} و${newItem.awayTeam}"
        }
        candidates.add(
          (0 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.GOAL_DISALLOWED,
            titleAr = "تم إلغاء الهدف (VAR)",
            subtitleAr = "$disallowedTeam • ${newItem.homeScore} - ${newItem.awayScore}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore,
            scoringSide = side
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.STOPPED &&
        oldItem.matchPhase != FootballMatchPhase.STOPPED
      ) {
        candidates.add(
          (1 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.STOPPED,
            titleAr = "توقفت المباراة",
            subtitleAr = "${newItem.homeTeam} × ${newItem.awayTeam} (${newItem.minuteOrStatus})",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.FINISHED &&
        oldItem.matchPhase != FootballMatchPhase.FINISHED
      ) {
        candidates.add(
          (2 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.FULL_TIME,
            titleAr = "انتهت المباراة",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      } else if (newItem.matchPhase == FootballMatchPhase.HALFTIME &&
        oldItem.matchPhase != FootballMatchPhase.HALFTIME
      ) {
        candidates.add(
          (3 + isPreferredBoost) to FootballMatchEvent(
            matchId = newItem.id,
            type = FootballEventType.HALFTIME,
            titleAr = "استراحة الشوطين",
            subtitleAr = "${newItem.homeTeam} ${newItem.homeScore} - ${newItem.awayScore} ${newItem.awayTeam}",
            homeTeam = newItem.homeTeam,
            awayTeam = newItem.awayTeam,
            homeScore = newItem.homeScore,
            awayScore = newItem.awayScore
          )
        )
      }
    }

    return candidates.minByOrNull { it.first }?.second
  }

  private fun resolveMatchPhase(
    stateCode: String,
    typeName: String,
    shortDetail: String,
    description: String
  ): FootballMatchPhase {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    val isStoppedKeyword = combined.contains("suspend") ||
      combined.contains("delay") ||
      combined.contains("interrupt") ||
      combined.contains("postpon") ||
      combined.contains("abandon") ||
      combined.contains("cancel") ||
      combined.contains("rain")

    if (isStoppedKeyword) return FootballMatchPhase.STOPPED

    if (stateCode == "post" ||
      typeName.contains("FINAL") ||
      typeName.contains("FULL_TIME") ||
      shortDetail.equals("FT", ignoreCase = true) ||
      shortDetail.equals("AET", ignoreCase = true) ||
      shortDetail.equals("PEN", ignoreCase = true)
    ) {
      return FootballMatchPhase.FINISHED
    }

    if (stateCode == "in") {
      if (typeName.contains("HALFTIME") ||
        typeName.contains("END_OF_PERIOD") ||
        shortDetail.equals("HT", ignoreCase = true) ||
        combined.contains("halftime")
      ) {
        return FootballMatchPhase.HALFTIME
      }
      return FootballMatchPhase.LIVE_PLAY
    }

    return FootballMatchPhase.SCHEDULED
  }

  private fun resolveStoppedLabelAr(
    typeName: String,
    shortDetail: String,
    description: String
  ): String {
    val combined = "$typeName $shortDetail $description".lowercase(Locale.US)
    return when {
      combined.contains("postpon") -> "مؤجلة"
      combined.contains("cancel") || combined.contains("abandon") -> "ملغاة"
      combined.contains("delay") || combined.contains("rain") -> "تأخر مؤقت"
      else -> "توقفت لحدث"
    }
  }

  private fun extractClockSeconds(statusObj: JSONObject?, displayClock: String): Int {
    if (displayClock.contains("+")) return -1
    val cleaned = displayClock.replace("'", "").trim()
    // If displayClock already has MM:SS seconds, parse it directly.
    if (cleaned.contains(":")) {
      val parts = cleaned.split(":")
      val mins = parts.getOrNull(0)?.toIntOrNull() ?: return -1
      val secs = parts.getOrNull(1)?.toIntOrNull() ?: 0
      return (mins * 60) + secs.coerceIn(0, 59)
    }
    // Only use rawClock if ESPN provides genuine sub-minute seconds (not rounded ordinal minute * 60,
    // which otherwise puts whole-minute feeds 1–2 minutes ahead of actual elapsed match time).
    val rawClock = statusObj?.optDouble("clock", -1.0) ?: -1.0
    if (rawClock > 0.0 && !rawClock.isNaN()) {
      val intClock = rawClock.toInt()
      if (intClock % 60 != 0) {
        return intClock
      }
    }
    return -1
  }

  private fun extractTeamName(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return "فريق"
    return team.optString("shortDisplayName").takeIf { it.isNotBlank() }
      ?: team.optString("displayName").takeIf { it.isNotBlank() }
      ?: team.optString("abbreviation").takeIf { it.isNotBlank() }
      ?: "فريق"
  }

  private fun extractTeamLogoUrl(competitor: JSONObject): String {
    val team = competitor.optJSONObject("team") ?: return ""
    val direct = team.optString("logo").trim()
    val fromArray = team.optJSONArray("logos")
      ?.optJSONObject(0)
      ?.optString("href")
      ?.trim()
      .orEmpty()
    val raw = direct.ifBlank { fromArray }
    return if (raw.startsWith("http://", ignoreCase = true)) {
      "https://" + raw.removePrefix("http://")
    } else {
      raw
    }
  }

  private fun extractTeamAbbrev(competitor: JSONObject, fallbackName: String): String {
    val team = competitor.optJSONObject("team")
    val abbrev = team?.optString("abbreviation")?.trim().orEmpty()
    if (abbrev.isNotBlank()) return abbrev.take(3).uppercase(Locale.US)
    val clean = fallbackName.trim()
    return if (clean.isNotBlank()) clean.take(2).uppercase(Locale.US) else "FC"
  }

  internal fun parseIsoUtcMillis(isoUtc: String): Long {
    if (isoUtc.isBlank()) return -1L
    val patterns = listOf(
      "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      "yyyy-MM-dd'T'HH:mm:ss'Z'",
      "yyyy-MM-dd'T'HH:mm'Z'"
    )
    for (p in patterns) {
      try {
        val parser = SimpleDateFormat(p, Locale.US).apply {
          timeZone = TimeZone.getTimeZone("UTC")
        }
        val date = parser.parse(isoUtc)
        if (date != null) return date.time
      } catch (_: Exception) {
      }
    }
    return -1L
  }

  private fun formatScheduledTime(isoUtc: String): String? {
    val ms = parseIsoUtcMillis(isoUtc)
    if (ms <= 0L) return null
    val out = SimpleDateFormat("HH:mm", Locale.US)
    return out.format(java.util.Date(ms))
  }

  private fun toFriendlyError(err: Throwable): String {
    val msg = err.message.orEmpty()
    return when {
      err is UnknownHostException ||
        err is ConnectException ||
        msg.contains("Unable to resolve host", ignoreCase = true) ||
        msg.contains("No address associated", ignoreCase = true) ->
        "لا يوجد اتصال بالإنترنت لعرض نتائج المباريات"
      err is SocketTimeoutException || msg.contains("timeout", ignoreCase = true) ->
        "انتهت مهلة الاتصال بخدمة المباريات، حاول مجدداً"
      err is IllegalStateException && msg.isNotBlank() -> msg
      else -> "تعذر جلب نتائج المباريات حالياً"
    }
  }
}
