package com.example.island

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import com.example.data.CapsuleSettings
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

data class PrayerTimeOffsets(
  val fajrMinutes: Int = 0,
  val sunriseMinutes: Int = 0,
  val dhuhrMinutes: Int = 0,
  val asrMinutes: Int = 0,
  val maghribMinutes: Int = 0,
  val ishaMinutes: Int = 0
)

object PrayerTimesCalculator {

  private const val KAABA_LAT = 21.4225
  private const val KAABA_LON = 39.8262

  private const val FAJR_ANGLE = 18.5
  private const val ISHA_ANGLE = 17.5

  fun computeQiblaBearing(lat: Double, lon: Double): Float {
    val phi1 = Math.toRadians(lat)
    val phi2 = Math.toRadians(KAABA_LAT)
    val deltaLon = Math.toRadians(KAABA_LON - lon)
    val y = sin(deltaLon) * cos(phi2)
    val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(deltaLon)
    val deg = Math.toDegrees(atan2(y, x))
    return (((deg % 360.0) + 360.0) % 360.0).toFloat()
  }

  fun shortestAngularDiffDeg(a: Float, b: Float): Float {
    val diff = ((a - b + 540f) % 360f) - 180f
    return diff
  }

  fun isAlignedWithQibla(azimuthDeg: Float, qiblaBearingDeg: Float, toleranceDeg: Float = 8f): Boolean {
    return abs(shortestAngularDiffDeg(azimuthDeg, qiblaBearingDeg)) <= toleranceDeg
  }

  fun resolveCoordinatesForLocation(context: Context, settings: CapsuleSettings): Triple<Double, Double, String> {
    if (settings.weatherCityLat != null && settings.weatherCityLon != null) {
      val label = settings.weatherCityDisplayAlias.trim()
        .ifBlank { settings.weatherCityQuery.trim() }
        .ifBlank { "المدينة المختارة" }
      return Triple(settings.weatherCityLat, settings.weatherCityLon, label)
    }

    WeatherRepository.getCachedCoordinatesOrNull(context)?.let { (lat, lon, city) ->
      val label = settings.weatherCityDisplayAlias.trim().ifBlank { city }
      return Triple(lat, lon, label)
    }

    getLastKnownDeviceCoordinates(context)?.let { (lat, lon) ->
      return Triple(lat, lon, "موقعي الحالي")
    }

    return Triple(KAABA_LAT, KAABA_LON, "مكة المكرمة")
  }

  @SuppressLint("MissingPermission")
  private fun getLastKnownDeviceCoordinates(context: Context): Pair<Double, Double>? {
    val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
      PackageManager.PERMISSION_GRANTED
    if (!hasCoarse && !hasFine) return null

    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
    for (p in providers) {
      try {
        val loc = lm.getLastKnownLocation(p)
        if (loc != null) return loc.latitude to loc.longitude
      } catch (_: Exception) {
      }
    }
    return null
  }

  fun calculate(
    lat: Double,
    lon: Double,
    cityName: String,
    nowMs: Long = System.currentTimeMillis(),
    timeZone: TimeZone = TimeZone.getDefault(),
    reminderWindowMinutes: Int = 15,
    offsets: PrayerTimeOffsets = PrayerTimeOffsets()
  ): PrayerTimesState {
    val cal = Calendar.getInstance(timeZone).apply { timeInMillis = nowMs }
    val tzHours = timeZone.getOffset(nowMs) / 3_600_000.0
    val dayStartCal = (cal.clone() as Calendar).apply {
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }

    val isFriday = dayStartCal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
    val dhuhrLabelAr = if (isFriday) "الجمعة" else "الظهر"

    val todayHours = computeDayPrayerHours(
      year = dayStartCal.get(Calendar.YEAR),
      month = dayStartCal.get(Calendar.MONTH) + 1,
      day = dayStartCal.get(Calendar.DAY_OF_MONTH),
      lat = lat,
      lon = lon,
      tzHours = tzHours
    )

    val dayBaseMs = dayStartCal.timeInMillis
    val defs = listOf(
      Triple("fajr", "الفجر", (todayHours.fajrHours + offsets.fajrMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)),
      Triple("sunrise", "الشروق", (todayHours.sunriseHours + offsets.sunriseMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)),
      Triple("dhuhr", dhuhrLabelAr, (todayHours.dhuhrHours + offsets.dhuhrMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)),
      Triple("asr", "العصر", (todayHours.asrHours + offsets.asrMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)),
      Triple("maghrib", "المغرب", (todayHours.maghribHours + offsets.maghribMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)),
      Triple("isha", "العشاء", (todayHours.ishaHours + offsets.ishaMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98))
    )

    val rawItems = defs.map { (key, nameAr, h) ->
      val ms = dayBaseMs + (h * 3_600_000.0).roundToInt() * 1L
      PrayerTimeItem(
        key = key,
        nameAr = nameAr,
        timeFormatted = formatHoursAsTime(h),
        triggerTimeMs = ms,
        isPassed = ms <= nowMs,
        isNext = false
      )
    }

    val nextTodayIdx = rawItems.indexOfFirst { it.triggerTimeMs > nowMs }
    val items: List<PrayerTimeItem>
    val nextName: String
    val nextFormatted: String
    val remainingMin: Int

    if (nextTodayIdx >= 0) {
      items = rawItems.mapIndexed { idx, item -> item.copy(isNext = idx == nextTodayIdx) }
      val nextItem = items[nextTodayIdx]
      nextName = nextItem.nameAr
      nextFormatted = nextItem.timeFormatted
      remainingMin = (((nextItem.triggerTimeMs - nowMs) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    } else {
      val tomorrowCal = (dayStartCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
      val tomorrowHours = computeDayPrayerHours(
        year = tomorrowCal.get(Calendar.YEAR),
        month = tomorrowCal.get(Calendar.MONTH) + 1,
        day = tomorrowCal.get(Calendar.DAY_OF_MONTH),
        lat = lat,
        lon = lon,
        tzHours = tzHours
      )
      val tomorrowFajrHours = (tomorrowHours.fajrHours + offsets.fajrMinutes.coerceIn(-60, 60) / 60.0).coerceIn(0.0, 23.98)
      val tomorrowFajrMs = tomorrowCal.timeInMillis + (tomorrowFajrHours * 3_600_000.0).roundToInt() * 1L
      items = rawItems
      nextName = "الفجر"
      nextFormatted = formatHoursAsTime(tomorrowFajrHours)
      remainingMin = (((tomorrowFajrMs - nowMs) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    }

    val remLabel = formatRemainingArabic(remainingMin)
    val qiblaDeg = computeQiblaBearing(lat, lon)
    val isPreAdhan = nextName != "الشروق" && remainingMin in 1..reminderWindowMinutes.coerceIn(5, 45)

    return PrayerTimesState(
      isLoaded = true,
      isAlertActive = isPreAdhan,
      isPreAdhanAlert = isPreAdhan,
      isFriday = isFriday,
      cityName = cityName.ifBlank { "مكة المكرمة" },
      nextPrayerNameAr = nextName,
      nextPrayerTimeFormatted = nextFormatted,
      remainingMinutes = remainingMin,
      remainingLabel = remLabel,
      qiblaBearingDeg = qiblaDeg,
      prayers = items,
      lastUpdatedMs = nowMs
    )
  }

  private data class DayPrayerHours(
    val fajrHours: Double,
    val sunriseHours: Double,
    val dhuhrHours: Double,
    val asrHours: Double,
    val maghribHours: Double,
    val ishaHours: Double
  )

  private fun computeDayPrayerHours(
    year: Int,
    month: Int,
    day: Int,
    lat: Double,
    lon: Double,
    tzHours: Double
  ): DayPrayerHours {
    val jd = julianDate(year, month, day) - lon / (15.0 * 24.0)
    val d = jd - 2451545.0
    val g = normalizeAngle(357.529 + 0.98560028 * d)
    val q = normalizeAngle(280.459 + 0.98564736 * d)
    val l = normalizeAngle(q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g)))
    val e = 23.439 - 0.00000036 * d

    val raRad = atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l)))
    val raHours = normalizeHours(Math.toDegrees(raRad) / 15.0)
    val declRad = asin(sin(Math.toRadians(e)) * sin(Math.toRadians(l)))
    val declDeg = Math.toDegrees(declRad)
    val eqt = (q / 15.0) - raHours

    val dhuhr = normalizeHours(12.0 + tzHours - (lon / 15.0) - eqt)

    val sunriseAngle = 0.8333
    val sunriseDiff = hourAngleHours(lat, declDeg, -sunriseAngle) ?: 6.0
    val fajrDiff = hourAngleHours(lat, declDeg, -FAJR_ANGLE) ?: (sunriseDiff + 1.4)
    val asrAltDeg = Math.toDegrees(atan(1.0 / (1.0 + tan(Math.toRadians(abs(lat - declDeg))))))
    val asrDiff = hourAngleHours(lat, declDeg, asrAltDeg) ?: 3.5
    val ishaDiff = hourAngleHours(lat, declDeg, -ISHA_ANGLE) ?: (sunriseDiff + 1.35)

    return DayPrayerHours(
      fajrHours = (dhuhr - fajrDiff).coerceIn(0.0, 23.98),
      sunriseHours = (dhuhr - sunriseDiff).coerceIn(0.0, 23.98),
      dhuhrHours = dhuhr.coerceIn(0.0, 23.98),
      asrHours = (dhuhr + asrDiff).coerceIn(0.0, 23.98),
      maghribHours = (dhuhr + sunriseDiff).coerceIn(0.0, 23.98),
      ishaHours = (dhuhr + ishaDiff).coerceIn(0.0, 23.98)
    )
  }

  private fun hourAngleHours(latDeg: Double, declDeg: Double, elevationDeg: Double): Double? {
    val latRad = Math.toRadians(latDeg)
    val declRad = Math.toRadians(declDeg)
    val altRad = Math.toRadians(elevationDeg)
    val cosH = (sin(altRad) - sin(latRad) * sin(declRad)) / (cos(latRad) * cos(declRad))
    if (cosH < -1.0 || cosH > 1.0) return null
    return Math.toDegrees(acos(cosH)) / 15.0
  }

  private fun julianDate(year: Int, month: Int, day: Int): Double {
    var y = year
    var m = month
    if (m <= 2) {
      y -= 1
      m += 12
    }
    val a = floor(y / 100.0)
    val b = 2.0 - a + floor(a / 4.0)
    return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
  }

  private fun normalizeAngle(deg: Double): Double {
    val res = deg % 360.0
    return if (res < 0.0) res + 360.0 else res
  }

  private fun normalizeHours(hours: Double): Double {
    val res = hours % 24.0
    return if (res < 0.0) res + 24.0 else res
  }

  fun formatHoursAsTime(hours: Double): String {
    val totalMinutes = (hours * 60.0).roundToInt().coerceIn(0, 23 * 60 + 59)
    val h = totalMinutes / 60
    val m = totalMinutes % 60
    return String.format(Locale.US, "%02d:%02d", h, m)
  }

  fun formatRemainingArabic(minutes: Int): String {
    val safe = minutes.coerceAtLeast(1)
    val hrs = safe / 60
    val mins = safe % 60
    return when {
      hrs > 0 && mins > 0 -> "بعد ${hrs}س ${mins}د"
      hrs > 0 -> "بعد ${hrs}س"
      else -> "بعد ${mins} د"
    }
  }
}
