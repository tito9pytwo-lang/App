package com.example.media

import android.graphics.Bitmap
import android.os.SystemClock

data class MediaTrackInfo(
  val title: String,
  val artist: String,
  val album: String = "",
  val durationMs: Long = 0L,
  val currentPositionMs: Long = 0L,
  val isPlaying: Boolean = false,
  val albumArt: Bitmap? = null,
  val packageName: String = "",
  val appName: String = "",
  val playbackSpeed: Float = 1.0f,
  val lastUpdateTime: Long = SystemClock.elapsedRealtime(),
  val canSeek: Boolean = true,
  val canSkipNext: Boolean = true,
  val canSkipPrevious: Boolean = true
) {
  fun getEstimatedPositionMs(): Long {
    if (!isPlaying || playbackSpeed <= 0f) return currentPositionMs
    val now = SystemClock.elapsedRealtime()
    val elapsed = if (lastUpdateTime in 1L..now) {
      now - lastUpdateTime
    } else {
      0L
    }
    val estimated = currentPositionMs + (elapsed * playbackSpeed).toLong()
    return if (durationMs > 0L) estimated.coerceIn(0L, durationMs) else estimated.coerceAtLeast(0L)
  }

  fun formatTime(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
  }
}
