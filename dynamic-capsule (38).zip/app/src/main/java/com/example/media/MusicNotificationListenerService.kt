package com.example.media

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandStateManager

class MusicNotificationListenerService : NotificationListenerService() {

  private var mediaSessionManager: MediaSessionManager? = null
  private var currentController: MediaController? = null
  private var sessionComponent: ComponentName? = null

  private val sessionCallback = object : MediaController.Callback() {
    override fun onPlaybackStateChanged(state: PlaybackState?) {
      super.onPlaybackStateChanged(state)
      syncCurrentSession()
    }

    override fun onMetadataChanged(metadata: MediaMetadata?) {
      super.onMetadataChanged(metadata)
      syncCurrentSession()
    }

    override fun onSessionDestroyed() {
      super.onSessionDestroyed()
      currentController = null
      MediaSessionHolder.updateActiveController(null)
      refreshActiveSessions()
    }
  }

  private val sessionsChangedListener =
    MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
      updateActiveControllerFromList(controllers)
    }

  override fun onCreate() {
    super.onCreate()
    sessionComponent = ComponentName(this, MusicNotificationListenerService::class.java)
    mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    IslandStateManager.initialize(this)
  }

  override fun onListenerConnected() {
    super.onListenerConnected()
    MediaSessionHolder.setListenerConnected(true)
    try {
      sessionComponent?.let { comp ->
        mediaSessionManager?.addOnActiveSessionsChangedListener(sessionsChangedListener, comp)
        refreshActiveSessions()
      }
      syncExistingNotifications()
    } catch (e: SecurityException) {
      Log.e(TAG, "SecurityException registering session listener", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering session listener", e)
    }
  }

  private fun syncExistingNotifications() {
    try {
      val currentNotifs = activeNotifications ?: return
      for (sbn in currentNotifs) {
        val pkg = sbn?.packageName ?: continue
        if (pkg == packageName) continue
        val notif = sbn.notification ?: continue
        val extras = notif.extras ?: continue
        val settings = CapsuleSettingsManager.getInstance(this).settings.value
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""

        if (settings.enableTimer && handleClockTimerNotification(sbn, notif, extras, pkg, title, text, subText, bigText)) {
          continue
        }
        if (settings.enableNavigationAlerts && handleNavigationNotification(sbn, notif, pkg, title, text, subText)) {
          continue
        }
        if (settings.enableDeliveryAlerts && handleDeliveryNotification(sbn, notif, extras, pkg, title, text, subText, bigText)) {
          continue
        }
        if (settings.enablePrivacyAlerts && handleVoiceRecorderNotification(sbn, notif, extras, pkg, title, text)) {
          continue
        }
        if (settings.enableDownloadProgress) {
          handleDownloadProgressNotification(sbn, notif, extras, pkg, title, text)
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "Could not sync existing notifications", e)
    }
  }

  override fun onListenerDisconnected() {
    super.onListenerDisconnected()
    MediaSessionHolder.setListenerConnected(false)
    cleanupController()
    try {
      mediaSessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
    } catch (e: Exception) {
      Log.e(TAG, "Error removing session listener", e)
    }
  }

  override fun onNotificationPosted(sbn: StatusBarNotification?) {
    super.onNotificationPosted(sbn)
    if (sbn == null) return

    val pkg = sbn.packageName ?: ""
    if (pkg == packageName) return

    val notif = sbn.notification ?: return
    val extras = notif.extras ?: return

    refreshActiveSessions()

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    // Real Call handling
    val title = extras.getString(Notification.EXTRA_TITLE)
      ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      ?: ""
    val text = extras.getString(Notification.EXTRA_TEXT)
      ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
      ?: ""

    val lowerTitle = title.lowercase()
    val lowerText = text.lowercase()

    // Explicit check: Only end call state when the notification actually belongs to a call/dialer/comm context
    val isMissedOrEndedCall = isCallTerminationNotification(
      pkg = pkg,
      category = notif.category,
      title = title,
      text = text,
      hasActiveCall = IslandStateManager.callState.value.isActive
    )

    if (isMissedOrEndedCall) {
      IslandStateManager.endCall()
      return
    }

    var ansIntent: PendingIntent? = null
    var decIntent: PendingIntent? = null

    // 1. Check CallStyle Extras (Android 12+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      @Suppress("DEPRECATION")
      ansIntent = extras.getParcelable(Notification.EXTRA_ANSWER_INTENT)
      @Suppress("DEPRECATION")
      decIntent = extras.getParcelable(Notification.EXTRA_DECLINE_INTENT)
    }

    // 2. Scan Actions
    val actions = notif.actions ?: emptyArray()
    for (action in actions) {
      val t = action.title?.toString()?.lowercase() ?: ""
      val isAnswerTitle = t.contains("answer") || t.contains("رد") || t.contains("accept") ||
        t.contains("اجابة") || t.contains("إجابة") || t.contains("قبول") || t.contains("موافقة") ||
        t.contains("pickup") || t.contains("pick up")
      val isDeclineTitle = t.contains("decline") || t.contains("reject") || t.contains("رفض") ||
        t.contains("hang") || t.contains("انهاء") || t.contains("إنهاء") || t.contains("dismiss") ||
        t.contains("end") || t.contains("قطع") || t.contains("تجاهل")

      if (isAnswerTitle && ansIntent == null) {
        ansIntent = action.actionIntent
      } else if (isDeclineTitle && decIntent == null) {
        decIntent = action.actionIntent
      }
    }

    // Fallback: If 2 actions exist on a call notification and only one was matched
    if (actions.size >= 2) {
      if (ansIntent != null && decIntent == null) {
        decIntent = actions.firstOrNull { it.actionIntent != ansIntent }?.actionIntent
      } else if (decIntent != null && ansIntent == null) {
        ansIntent = actions.firstOrNull { it.actionIntent != decIntent }?.actionIntent
      }
    }

    val isCallCategory = notif.category == Notification.CATEGORY_CALL
    val isKnownPhoneApp = pkg.contains("dialer") ||
      pkg.contains("telecom") ||
      pkg.contains("incall") ||
      pkg.contains("phone")
    val hasCallActions = ansIntent != null || decIntent != null
    val isOngoingEvent = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0

    // Only treat as call if it is CATEGORY_CALL with call actions/ongoing, or known phone app with explicit call actions
    val isRealActiveCall = (isCallCategory && (hasCallActions || isOngoingEvent)) || (isKnownPhoneApp && hasCallActions)

    if (settings.enableCallAlerts && isRealActiveCall) {
      CallManager.setCallNotificationIntents(ansIntent, decIntent)

      val callerName = if (title.isNotBlank()) title else "Incoming Call"
      val callerNumber = if (text.isNotBlank()) text else "Mobile"

      val isIncomingByExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        extras.getInt(Notification.EXTRA_CALL_TYPE, -1) == Notification.CallStyle.CALL_TYPE_INCOMING
      } else false

      val isOngoingByExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        extras.getInt(Notification.EXTRA_CALL_TYPE, -1) == Notification.CallStyle.CALL_TYPE_ONGOING
      } else false

      val textIndicatesIncoming = lowerTitle.contains("incoming") ||
        lowerTitle.contains("وارد") ||
        lowerTitle.contains("calling") ||
        lowerTitle.contains("يرن") ||
        lowerTitle.contains("يتصل") ||
        lowerText.contains("incoming") ||
        lowerText.contains("وارد") ||
        lowerText.contains("ringing") ||
        lowerText.contains("يرن")

      val textIndicatesOngoing = lowerTitle.contains("ongoing") ||
        lowerTitle.contains("جارية") ||
        lowerTitle.contains("in call") ||
        lowerText.contains("ongoing") ||
        lowerText.contains("جارية") ||
        lowerText.contains("in call")

      val isTelephonyRinging = IslandStateManager.isTelephonyRinging()

      // The call is strictly INCOMING (ringing) if:
      // - Telephony is ringing
      // - Or CallStyle indicates CALL_TYPE_INCOMING
      // - Or there is an Answer button (ansIntent != null)
      // - Or text indicates incoming
      // - Or it's a new call (not already connected/ongoing)
      val isRinging = when {
        isTelephonyRinging -> true
        isIncomingByExtra -> true
        ansIntent != null -> true
        textIndicatesIncoming -> true
        isOngoingByExtra -> false
        textIndicatesOngoing -> false
        ansIntent == null && decIntent != null && isOngoingEvent -> false
        else -> true // Crucial: default to incoming/ringing for any new call!
      }

      if (isRinging) {
        IslandStateManager.startCall(caller = callerName, number = callerNumber, isIncoming = true)
      } else {
        // If it was already incoming and now transitioned to ongoing (answered)
        if (IslandStateManager.callState.value.isActive && IslandStateManager.callState.value.isIncoming) {
          IslandStateManager.setCallAnswered()
        } else if (!IslandStateManager.callState.value.isActive) {
          IslandStateManager.startCall(caller = callerName, number = callerNumber, isIncoming = false)
        }
      }
      return
    }

    // 2. Real Clock Timer & Stopwatch Interception
    val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
    val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
    if (settings.enableTimer && handleClockTimerNotification(sbn, notif, extras, pkg, title, text, subText, bigText)) {
      return
    }

    // 3. Real Live Navigation (Google Maps / Waze notifications, zero API required)
    if (settings.enableNavigationAlerts && handleNavigationNotification(sbn, notif, pkg, title, text, subText)) {
      return
    }

    // 3b. Real Delivery Orders & Ride-Delivery Tracking (Talabat, HungerStation, Jahez, Careem, Noon, Aramex, etc.)
    if (settings.enableDeliveryAlerts && handleDeliveryNotification(sbn, notif, extras, pkg, title, text, subText, bigText)) {
      return
    }

    // 4. Real Voice Recorder Ongoing Notification
    if (settings.enablePrivacyAlerts && handleVoiceRecorderNotification(sbn, notif, extras, pkg, title, text)) {
      return
    }

    // 5. Real System / App Download & Install Progress
    if (settings.enableDownloadProgress && handleDownloadProgressNotification(sbn, notif, extras, pkg, title, text)) {
      return
    }

    // 5b. Real System Hotspot / Tethering Notification Fallback
    if (settings.enableNetworkAlerts && (pkg == "com.android.systemui" || pkg == "android" || pkg.contains("tether"))) {
      val combinedLower = "$title $text".lowercase()
      if (combinedLower.contains("hotspot") || combinedLower.contains("نقطة الاتصال") || combinedLower.contains("tethering")) {
        IslandStateManager.notifyHotspotFromSystemNotification(true)
        return
      }
    }

    // 6. App message notifications (respect excludedPackages filter, exclude ongoing services)
    if (settings.enableNotifications &&
      notif.category != Notification.CATEGORY_SERVICE &&
      !isOngoingEvent &&
      !settings.excludedPackages.contains(pkg)
    ) {
      if (title.isNotBlank() && text.isNotBlank()) {
        val appName = try {
          val appInfo = packageManager.getApplicationInfo(pkg, 0)
          packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
          pkg
        }
        IslandStateManager.postNotificationEvent(appName, title, text, pkg, notif.contentIntent)
      }
    }
  }

  private fun handleClockTimerNotification(
    sbn: StatusBarNotification,
    notif: Notification,
    extras: android.os.Bundle,
    pkg: String,
    title: String,
    text: String,
    subText: String,
    bigText: String
  ): Boolean {
    val lowerPkg = pkg.lowercase()
    val isClockPkg = lowerPkg.contains("deskclock") ||
      lowerPkg.contains("alarmclock") ||
      lowerPkg.contains("clockpackage") ||
      lowerPkg.contains(".clock") ||
      lowerPkg.contains("clock") ||
      lowerPkg.contains("timer") ||
      lowerPkg.contains("stopwatch")
    val isAlarmCat = notif.category == Notification.CATEGORY_ALARM || notif.category == "stopwatch"
    if (!isClockPkg && !isAlarmCat) return false

    val combined = "$title $text $subText $bigText ${notif.tickerText ?: ""}".lowercase()
    val channelId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) (notif.channelId ?: "").lowercase() else ""

    // Ignore upcoming alarm reminders ("Upcoming alarm at 7:00 AM") so they don't pretend to be a timer
    val isUpcomingAlarm = combined.contains("upcoming alarm") ||
      combined.contains("next alarm") ||
      combined.contains("منبه قادم") ||
      combined.contains("المنبه القادم") ||
      combined.contains("المنبه التالي") ||
      channelId.contains("upcoming")
    if (isUpcomingAlarm) return false

    val showChronometer = extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
    val isCountDownExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false)
    } else false

    var pauseResumeIntent: PendingIntent? = null
    var cancelIntent: PendingIntent? = null
    var hasResumeAction = false
    var hasPauseAction = false

    val actions = notif.actions ?: emptyArray()
    for (action in actions) {
      val t = action.title?.toString()?.lowercase() ?: ""
      when {
        t.contains("pause") || t.contains("إيقاف مؤقت") || t.contains("ايقاف مؤقت") -> {
          hasPauseAction = true
          pauseResumeIntent = action.actionIntent
        }
        t.contains("resume") || t.contains("start") || t.contains("استئناف") || t.contains("متابعة") || t.contains("تشغيل") -> {
          hasResumeAction = true
          pauseResumeIntent = action.actionIntent
        }
        t.contains("cancel") || t.contains("delete") || t.contains("stop") || t.contains("dismiss") ||
          t.contains("إلغاء") || t.contains("الغاء") || t.contains("حذف") || t.contains("إيقاف") || t.contains("ايقاف") -> {
          if (cancelIntent == null) cancelIntent = action.actionIntent
        }
      }
    }

    val isStopwatch = channelId.contains("stopwatch") ||
      combined.contains("stopwatch") ||
      combined.contains("ساعة إيقاف") ||
      combined.contains("ساعة الإيقاف")

    val hasTimerKeywords = channelId.contains("timer") ||
      combined.contains("timer") ||
      combined.contains("countdown") ||
      combined.contains("مؤقت") ||
      combined.contains("المؤقت") ||
      combined.contains("عد تنازلي") ||
      combined.contains("متبقي") ||
      combined.contains("remaining") ||
      combined.contains("time's up") ||
      combined.contains("انتهى الوقت")

    val parsedSeconds = parseDurationSeconds(title, allowWordUnits = hasTimerKeywords)
      ?: parseDurationSeconds(text, allowWordUnits = hasTimerKeywords)
      ?: parseDurationSeconds(subText, allowWordUnits = hasTimerKeywords)
      ?: parseDurationSeconds(bigText, allowWordUnits = hasTimerKeywords)
      ?: parseDurationSeconds(notif.tickerText?.toString() ?: "", allowWordUnits = hasTimerKeywords)

    val now = System.currentTimeMillis()
    val notifWhen = notif.`when`
    val whenIsFuture = notifWhen > now + 500L

    val looksLikeTimerOrStopwatch = isCountDownExtra ||
      isStopwatch ||
      hasTimerKeywords ||
      whenIsFuture ||
      (showChronometer && (hasPauseAction || hasResumeAction || cancelIntent != null)) ||
      ((hasPauseAction || hasResumeAction) && parsedSeconds != null)

    if (!looksLikeTimerOrStopwatch) return false

    val isPausedText = combined.contains("paused") || combined.contains("متوقف مؤقت") || combined.contains("موقوف")
    val isRunning = when {
      hasResumeAction -> false
      isPausedText -> false
      hasPauseAction -> true
      showChronometer -> true
      else -> true
    }

    if (isStopwatch) {
      val elapsed = if (isRunning && notifWhen in 1L..now) {
        ((now - notifWhen) / 1000L).toInt().coerceAtLeast(0)
      } else {
        parsedSeconds ?: 0
      }
      IslandStateManager.updateExternalTimer(
        key = sbn.key,
        pkg = pkg,
        title = title.ifBlank { "ساعة الإيقاف" },
        remainingSeconds = 0,
        targetEndTimeMs = 0L,
        isRunning = isRunning,
        isStopwatch = true,
        elapsedSeconds = elapsed,
        pauseResumeIntent = pauseResumeIntent,
        cancelIntent = cancelIntent
      )
      return true
    }

    // Countdown Timer
    val targetEndMs: Long
    val remainingSec: Int
    if (isRunning && (isCountDownExtra || whenIsFuture) && notifWhen > now) {
      targetEndMs = notifWhen
      remainingSec = ((notifWhen - now + 500L) / 1000L).toInt().coerceAtLeast(0)
    } else if (parsedSeconds != null) {
      remainingSec = parsedSeconds
      targetEndMs = if (isRunning) now + parsedSeconds * 1000L else 0L
    } else {
      return false
    }

    val displayTitle = when {
      title.isNotBlank() && parseDurationSeconds(title, allowWordUnits = false) == null -> title
      text.isNotBlank() && parseDurationSeconds(text, allowWordUnits = false) == null -> text
      else -> "مؤقت الساعة"
    }

    IslandStateManager.updateExternalTimer(
      key = sbn.key,
      pkg = pkg,
      title = displayTitle,
      remainingSeconds = remainingSec,
      targetEndTimeMs = targetEndMs,
      isRunning = isRunning,
      isStopwatch = false,
      elapsedSeconds = 0,
      pauseResumeIntent = pauseResumeIntent,
      cancelIntent = cancelIntent
    )
    return true
  }

  private fun parseDurationSeconds(raw: String, allowWordUnits: Boolean = false): Int? {
    if (raw.isBlank()) return null
    val normalized = normalizeDigits(raw)
      .replace(Regex("[\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069]"), "")
    // Match H:MM:SS or MM:SS safely even next to Arabic text
    val colonRegex = Regex("""(?<!\d)(\d{1,2}):(\d{2})(?::(\d{2}))?(?!\d)""")
    colonRegex.find(normalized)?.let { match ->
      val p1 = match.groupValues[1].toIntOrNull() ?: return@let
      val p2 = match.groupValues[2].toIntOrNull() ?: return@let
      val p3 = match.groupValues.getOrNull(3)?.takeIf { it.isNotEmpty() }?.toIntOrNull()
      return if (p3 != null) {
        p1 * 3600 + p2 * 60 + p3
      } else {
        p1 * 60 + p2
      }
    }
    if (allowWordUnits) {
      var total = 0
      var found = false
      val hourMatch = Regex("""(\d+)\s*(?:h|hr|hrs|hour|hours|ساعة|ساعات|س)\b""", RegexOption.IGNORE_CASE).find(normalized)
      val minMatch = Regex("""(\d+)\s*(?:m|min|mins|minute|minutes|دقيقة|دقائق|د)\b""", RegexOption.IGNORE_CASE).find(normalized)
      val secMatch = Regex("""(\d+)\s*(?:s|sec|secs|second|seconds|ثانية|ثوان|ثواني|ث)\b""", RegexOption.IGNORE_CASE).find(normalized)
      hourMatch?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { total += it * 3600; found = true }
      minMatch?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { total += it * 60; found = true }
      secMatch?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { total += it; found = true }
      if (found && total > 0) return total
    }
    return null
  }

  private fun normalizeDigits(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
      when (ch) {
        in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
        in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
        else -> sb.append(ch)
      }
    }
    return sb.toString()
  }

  private fun handleDownloadProgressNotification(
    sbn: StatusBarNotification,
    notif: Notification,
    extras: android.os.Bundle,
    pkg: String,
    title: String,
    text: String
  ): Boolean {
    if (notif.category == Notification.CATEGORY_CALL || notif.category == Notification.CATEGORY_TRANSPORT) {
      return false
    }
    val max = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
    val progress = extras.getInt(Notification.EXTRA_PROGRESS, -1)
    val indeterminate = extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)

    if (max <= 0 || progress < 0) return false

    if (progress >= max && !indeterminate) {
      IslandStateManager.clearDownloadProgress(sbn.key)
      return true
    }

    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      pkg
    }

    IslandStateManager.updateDownloadProgress(
      key = sbn.key,
      appName = appName,
      title = title.ifBlank { text.ifBlank { "جارٍ التنزيل..." } },
      progress = progress,
      max = max,
      indeterminate = indeterminate,
      pkg = pkg,
      contentIntent = notif.contentIntent
    )
    return true
  }

  private fun handleNavigationNotification(
    sbn: StatusBarNotification,
    notif: Notification,
    pkg: String,
    title: String,
    text: String,
    subText: String
  ): Boolean {
    val isNavPkg = pkg == "com.google.android.apps.maps" || pkg == "com.waze"
    val isNavCategory = notif.category == Notification.CATEGORY_NAVIGATION
    if (!isNavPkg && !isNavCategory) return false

    val isOngoing = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0
    var stopIntent: PendingIntent? = null
    val actions = notif.actions ?: emptyArray()
    for (action in actions) {
      val t = action.title?.toString()?.lowercase() ?: ""
      if (t.contains("exit") || t.contains("stop") || t.contains("إنهاء") || t.contains("خروج") || t.contains("إيقاف")) {
        stopIntent = action.actionIntent
        break
      }
    }

    if (!isNavCategory && !isOngoing && stopIntent == null) return false
    if (title.isBlank() && text.isBlank()) return false

    val directionBitmap = extractNotificationLargeBitmap(notif)
    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      "Maps"
    }

    IslandStateManager.updateNavigation(
      key = sbn.key,
      pkg = pkg,
      appName = appName,
      instruction = title,
      distanceOrStreet = text,
      etaText = subText,
      directionIcon = directionBitmap,
      contentIntent = notif.contentIntent,
      stopIntent = stopIntent
    )
    return true
  }

  private fun handleDeliveryNotification(
    sbn: StatusBarNotification,
    notif: Notification,
    extras: android.os.Bundle,
    pkg: String,
    title: String,
    text: String,
    subText: String,
    bigText: String
  ): Boolean {
    if (notif.category == Notification.CATEGORY_CALL || notif.category == Notification.CATEGORY_TRANSPORT) {
      return false
    }
    val lowerPkg = pkg.lowercase()
    val deliveryPackages = listOf(
      "talabat", "hungerstation", "jahez", "toyou", "mrsool", "marsool",
      "careem", "ubereats", "deliveroo", "glovo", "doordash", "grubhub",
      "noon", "amazon", "aramex", "dhl", "fedex", "smsa", "naqel",
      "toters", "elmenus", "otlob", "thechefz", "shgardi", "indrive"
    )
    val isKnownDeliveryPkg = deliveryPackages.any { lowerPkg.contains(it) }

    val combined = "$title $text $subText $bigText".lowercase()
    val deliveryKeywords = listOf(
      "في الطريق", "جاري التوصيل", "توصيل طلب", "تحضير طلبك", "تم استلام طلب",
      "وصل المندوب", "مندوب التوصيل", "يقترب المندوب", "شحنتك", "خارج للتوصيل",
      "طلبك جاهز", "سيصل خلال", "الكابتن في الطريق",
      "out for delivery", "on the way", "preparing your order", "order is being prepared",
      "driver is heading", "courier", "order arrived", "arriving in", "picked up your order",
      "heading to you", "tracking order"
    )
    val hasDeliveryKeywords = deliveryKeywords.any { combined.contains(it) }
    val isOngoing = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0

    if (!isKnownDeliveryPkg && !(hasDeliveryKeywords && (isOngoing || combined.contains("دقيق") || combined.contains("min")))) {
      return false
    }
    if (isKnownDeliveryPkg && !hasDeliveryKeywords && !isOngoing) {
      // Ignore promotional ads from delivery apps
      return false
    }
    if (title.isBlank() && text.isBlank()) return false

    val normalized = normalizeDigits("$title $text $subText")
    val etaMatch = Regex("""(\d{1,3})\s*(?:min|mins|minute|minutes|دقيقة|دقائق|د)""", RegexOption.IGNORE_CASE).find(normalized)
    val etaText = if (etaMatch != null) {
      "خلال ${etaMatch.groupValues[1]} د"
    } else if (subText.isNotBlank() && subText.length <= 22) {
      subText
    } else {
      ""
    }

    val max = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
    val progress = extras.getInt(Notification.EXTRA_PROGRESS, -1)
    val progressPct = if (max > 0 && progress >= 0) ((progress * 100f) / max).toInt().coerceIn(0, 100) else -1

    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (_: Exception) {
      "توصيل الطلب"
    }

    IslandStateManager.updateDeliveryOrder(
      key = sbn.key,
      pkg = pkg,
      appName = appName,
      statusTitle = title.ifBlank { "تتبع الطلب" },
      detailText = bigText.ifBlank { text }.ifBlank { "طلبك قيد المتابعة الآن" },
      etaText = etaText,
      progressPct = progressPct,
      contentIntent = notif.contentIntent
    )
    return true
  }

  private fun handleVoiceRecorderNotification(
    sbn: StatusBarNotification,
    notif: Notification,
    extras: android.os.Bundle,
    pkg: String,
    title: String,
    text: String
  ): Boolean {
    val lowerPkg = pkg.lowercase()
    val isAudioRecorderPkg = lowerPkg.contains("soundrecorder") ||
      lowerPkg.contains("voicerecorder") ||
      lowerPkg.contains("audiorecorder") ||
      lowerPkg == "com.google.android.apps.recorder" ||
      (lowerPkg.contains("recorder") && !lowerPkg.contains("screen"))
    if (!isAudioRecorderPkg) return false

    val isOngoing = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0
    val showChronometer = extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
    if (!isOngoing && !showChronometer) return false

    var pauseIntent: PendingIntent? = null
    var stopIntent: PendingIntent? = null
    var hasResume = false
    val actions = notif.actions ?: emptyArray()
    for (action in actions) {
      val t = action.title?.toString()?.lowercase() ?: ""
      when {
        t.contains("pause") || t.contains("إيقاف مؤقت") -> pauseIntent = action.actionIntent
        t.contains("resume") || t.contains("استئناف") -> {
          hasResume = true
          pauseIntent = action.actionIntent
        }
        t.contains("stop") || t.contains("save") || t.contains("done") ||
          t.contains("إيقاف") || t.contains("حفظ") || t.contains("إنهاء") -> {
          if (stopIntent == null) stopIntent = action.actionIntent
        }
      }
    }

    val combined = "$title $text".lowercase()
    val isRunning = !hasResume && !combined.contains("paused") && !combined.contains("متوقف")
    val now = System.currentTimeMillis()
    val elapsed = if (isRunning && notif.`when` in 1L..now) {
      ((now - notif.`when`) / 1000L).toInt().coerceAtLeast(0)
    } else {
      parseDurationSeconds(text) ?: parseDurationSeconds(title) ?: 0
    }

    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      "مسجل الصوت"
    }

    IslandStateManager.updateVoiceRecorder(
      key = sbn.key,
      pkg = pkg,
      appName = appName,
      title = title.ifBlank { "تسجيل صوتي جارٍ" },
      elapsedSeconds = elapsed,
      isRunning = isRunning,
      pauseIntent = pauseIntent,
      stopIntent = stopIntent
    )
    return true
  }

  private fun extractNotificationLargeBitmap(notif: Notification): Bitmap? {
    return try {
      val drawable: Drawable? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        notif.getLargeIcon()?.loadDrawable(this)
      } else null

      val rawBitmap: Bitmap? = when {
        drawable is BitmapDrawable -> drawable.bitmap
        drawable != null -> {
          val w = drawable.intrinsicWidth.coerceIn(24, 96)
          val h = drawable.intrinsicHeight.coerceIn(24, 96)
          val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
          val canvas = Canvas(bmp)
          drawable.setBounds(0, 0, w, h)
          drawable.draw(canvas)
          bmp
        }
        else -> {
          @Suppress("DEPRECATION")
          notif.extras?.getParcelable(Notification.EXTRA_LARGE_ICON)
        }
      }
      rawBitmap?.let {
        if (it.width > 96 || it.height > 96) {
          Bitmap.createScaledBitmap(it, 72, 72, true)
        } else it
      }
    } catch (e: Exception) {
      null
    }
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification?) {
    super.onNotificationRemoved(sbn)
    if (sbn != null) {
      val notif = sbn.notification
      val pkg = sbn.packageName ?: ""
      val isCallCategory = notif?.category == Notification.CATEGORY_CALL ||
        pkg.contains("dialer") ||
        pkg.contains("telecom") ||
        pkg.contains("incall") ||
        pkg.contains("phone")
      if (isCallCategory) {
        // If telephony is still active (OFFHOOK), don't kill call state prematurely
        if (!IslandStateManager.isTelephonyActive()) {
          IslandStateManager.endCall()
        }
      }

      // Clear real Clock Timer, Navigation, Delivery, Voice Recorder, or Download progress if removed
      IslandStateManager.cancelExternalTimer(sbn.key)
      IslandStateManager.clearDownloadProgress(sbn.key)
      IslandStateManager.clearNavigation(sbn.key)
      IslandStateManager.clearDeliveryOrder(sbn.key)
      IslandStateManager.clearVoiceRecorder(sbn.key)

      val nExtras = notif?.extras
      val removedTitle = nExtras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.lowercase() ?: ""
      val removedText = nExtras?.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.lowercase() ?: ""
      if ((pkg == "com.android.systemui" || pkg == "android" || pkg.contains("tether")) &&
        (removedTitle.contains("hotspot") || removedText.contains("hotspot") ||
          removedTitle.contains("نقطة الاتصال") || removedText.contains("نقطة الاتصال"))
      ) {
        val settings = CapsuleSettingsManager.getInstance(this).settings.value
        if (settings.enableNetworkAlerts) {
          IslandStateManager.notifyHotspotFromSystemNotification(false)
        }
      }
    }
    refreshActiveSessions()
  }

  private fun refreshActiveSessions() {
    try {
      sessionComponent?.let { comp ->
        val controllers = mediaSessionManager?.getActiveSessions(comp)
        updateActiveControllerFromList(controllers)
      }
    } catch (e: SecurityException) {
      Log.e(TAG, "Permission denied fetching active sessions", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching active sessions", e)
    }
  }

  private fun updateActiveControllerFromList(controllers: List<MediaController>?) {
    if (controllers.isNullOrEmpty()) {
      cleanupController()
      MediaSessionHolder.updateActiveController(null)
      MediaSessionHolder.updateTrackInfo(null)
      return
    }

    val playingController = controllers.firstOrNull {
      val s = it.playbackState?.state
      s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    if (playingController != null) {
      if (playingController != currentController) {
        cleanupController()
        currentController = playingController
        try {
          currentController?.registerCallback(sessionCallback)
        } catch (e: Exception) {
          Log.e(TAG, "Error registering callback", e)
        }
        MediaSessionHolder.updateActiveController(playingController)
      }
      syncCurrentSession()
    } else {
      val curState = currentController?.playbackState?.state
      if (curState == PlaybackState.STATE_PLAYING || curState == PlaybackState.STATE_BUFFERING) {
        syncCurrentSession()
      } else {
        cleanupController()
        MediaSessionHolder.updateActiveController(null)
        MediaSessionHolder.updateTrackInfo(null)
      }
    }
  }

  private fun syncCurrentSession() {
    val controller = currentController ?: return
    val state = controller.playbackState
    val metadata = controller.metadata

    val isPlaying = state?.state == PlaybackState.STATE_PLAYING
    if (!isPlaying && (state == null || state.state == PlaybackState.STATE_NONE || state.state == PlaybackState.STATE_STOPPED || state.state == PlaybackState.STATE_ERROR)) {
      cleanupController()
      MediaSessionHolder.updateActiveController(null)
      MediaSessionHolder.updateTrackInfo(null)
      return
    }

    val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
      ?: "Unknown Track"

    val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
      ?: "Unknown Artist"

    val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
    val durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    val albumArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    val currentPosition = state?.position ?: 0L
    val speed = if (state != null && state.playbackSpeed > 0f) state.playbackSpeed else 1.0f

    val actions = state?.actions ?: 0L
    val canSeek = (actions and PlaybackState.ACTION_SEEK_TO) != 0L
    val canSkipNext = (actions and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L
    val canSkipPrev = (actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L

    val pkg = controller.packageName ?: ""
    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      pkg
    }

    val now = SystemClock.elapsedRealtime()
    val rawUpdateTime = state?.lastPositionUpdateTime ?: 0L
    val validUpdateTime = if (rawUpdateTime in (now - 60_000L)..now) {
      rawUpdateTime
    } else {
      now
    }

    val trackInfo = MediaTrackInfo(
      title = title,
      artist = artist,
      album = album,
      durationMs = durationMs,
      currentPositionMs = currentPosition,
      isPlaying = isPlaying,
      albumArt = albumArt,
      packageName = pkg,
      appName = appName,
      playbackSpeed = speed,
      lastUpdateTime = validUpdateTime,
      canSeek = canSeek,
      canSkipNext = canSkipNext,
      canSkipPrevious = canSkipPrev
    )

    MediaSessionHolder.updateTrackInfo(trackInfo)
  }

  private fun cleanupController() {
    currentController?.unregisterCallback(sessionCallback)
    currentController = null
  }

  override fun onDestroy() {
    super.onDestroy()
    cleanupController()
  }

  companion object {
    private const val TAG = "MusicNotifListener"

    internal fun isCallTerminationNotification(
      pkg: String,
      category: String?,
      title: String,
      text: String,
      hasActiveCall: Boolean
    ): Boolean {
      if (category == Notification.CATEGORY_MISSED_CALL || category == "missed_call") {
        return true
      }
      val lowerPkg = pkg.lowercase()
      val lowerTitle = title.lowercase()
      val lowerText = text.lowercase()

      val explicitCallPhrase =
        lowerTitle.contains("missed call") ||
        lowerTitle.contains("call ended") ||
        lowerTitle.contains("مكالمة لم يرد") ||
        lowerTitle.contains("لم يرد عليها") ||
        lowerTitle.contains("مكالمة فائتة") ||
        lowerTitle.contains("مكالمة مفقودة") ||
        lowerTitle.contains("انتهت المكالمة") ||
        lowerText.contains("missed call") ||
        lowerText.contains("call ended") ||
        lowerText.contains("انتهت المكالمة") ||
        lowerText.contains("مكالمة لم يرد") ||
        lowerText.contains("مكالمة فائتة")

      if (explicitCallPhrase) return true

      val isDialerOrPhoneApp = lowerPkg.contains("dialer") ||
        lowerPkg.contains("telecom") ||
        lowerPkg.contains("incall") ||
        lowerPkg.contains("phone") ||
        lowerPkg.contains("contacts")

      val isCommOrVoipApp = isDialerOrPhoneApp ||
        lowerPkg.contains("whatsapp") ||
        lowerPkg.contains("telegram") ||
        lowerPkg.contains("messenger") ||
        lowerPkg.contains("viber") ||
        lowerPkg.contains("skype") ||
        lowerPkg.contains("discord") ||
        lowerPkg.contains("signal") ||
        lowerPkg.contains("imo") ||
        lowerPkg.contains("botim") ||
        lowerPkg.contains("zoom") ||
        lowerPkg.contains("teams") ||
        lowerPkg.contains("meet")

      val isCallCategory = category == Notification.CATEGORY_CALL

      val genericEndOrDecline =
        lowerTitle.contains("missed") ||
        lowerTitle.contains("ended") ||
        lowerTitle.contains("انتهت") ||
        lowerTitle.contains("declined") ||
        lowerTitle.contains("مرفوضة") ||
        lowerTitle.contains("cancelled") ||
        lowerTitle.contains("canceled") ||
        lowerTitle.contains("ملغاة")

      return genericEndOrDecline && (isCallCategory || isDialerOrPhoneApp || (hasActiveCall && isCommOrVoipApp))
    }
  }
}
