package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Standard Foreground Overlay Service powered by SYSTEM_ALERT_WINDOW (TYPE_APPLICATION_OVERLAY).
 * Ensures the Dynamic Capsule floats over all apps as soon as the user grants
 * "Display over other apps", without requiring Accessibility Service activation.
 * Automatically yields if FloatingCapsuleService (AccessibilityService) is active.
 */
class OverlayCapsuleService : Service() {

  private var windowManager: WindowManager? = null
  private var floatingView: ComposeView? = null
  private var lifecycleOwner: FloatingLifecycleOwner? = null
  private var windowParams: WindowManager.LayoutParams? = null

  private var isViewAttached = false
  private val _capsuleMode = MutableStateFlow(CapsuleMode.MINI)
  val capsuleMode: StateFlow<CapsuleMode> = _capsuleMode.asStateFlow()

  private val _isDismissedToNotification = MutableStateFlow(false)
  private var dismissedEventSeq: Long = 0L
  private var dismissedPlayingTrackKey: String? = null
  private val _isLandscape = MutableStateFlow(false)

  private var serviceJob: Job? = null
  private var pendingCollapseDetachJob: Job? = null
  private var postCollapseGraceJob: Job? = null
  private val _postCollapseGraceActive = MutableStateFlow(false)
  private var lastObservedMode: CapsuleMode = CapsuleMode.MINI
  private var lastAppliedLayoutY: Int? = null
  private var lastNotificationRenderKey: OverlayNotificationRenderKey? = null
  private var serviceScope: CoroutineScope? = null
  private var actionReceiverRegistered = false

  private val actionReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      when (intent?.action) {
        ACTION_STOP_SERVICE -> {
          CapsuleSettingsManager.getInstance(this@OverlayCapsuleService).updateServiceEnabled(false)
          stopSelf()
        }
        ACTION_RESTORE_CAPSULE -> {
          restoreFromNotification()
        }
        ACTION_TOGGLE_PLAY_PAUSE -> {
          MediaSessionHolder.togglePlayPause()
        }
      }
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    _isRunning.value = true
    _isLandscape.value = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    serviceJob?.cancel()
    val job = SupervisorJob()
    serviceJob = job
    serviceScope = CoroutineScope(Dispatchers.Main + job)

    IslandStateManager.initialize(this)
    lifecycleOwner?.destroy()
    lifecycleOwner = FloatingLifecycleOwner().apply { start() }
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    createNotificationChannel()
    promoteToForeground()
    registerNotificationActionReceiver()
    initFloatingCapsule()
    observeState()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (!Settings.canDrawOverlays(this)) {
      stopSelf()
      return START_NOT_STICKY
    }
    promoteToForeground()
    return START_STICKY
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    _isLandscape.value = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
  }

  private fun promoteToForeground() {
    try {
      val isDismissed = _isDismissedToNotification.value
      val track = MediaSessionHolder.currentTrack.value
      val renderKey = buildNotificationRenderKey(isDismissed, track)
      val notification = buildServiceNotification(
        isDismissed = isDismissed,
        track = track
      )
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        ServiceCompat.startForeground(
          this,
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
      lastNotificationRenderKey = renderKey
    } catch (e: Exception) {
      Log.e(TAG, "Failed starting foreground notification", e)
    }
  }

  private val overlayWindowType: Int
    get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION")
      WindowManager.LayoutParams.TYPE_PHONE
    }

  private val overlayFlags: Int
    get() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
      WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
      WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
      WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

  private fun calculateYPosition(settings: CapsuleSettings): Int {
    val density = resources.displayMetrics.density
    val baseCutoutY = (12 * density).toInt()
    val userOffset = (settings.notchOffsetYDp * density).toInt()
    return baseCutoutY + userOffset
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Dynamic Capsule Overlay",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Keeps Dynamic Capsule active above other applications"
        setShowBadge(false)
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(channel)
    }
  }

  private fun buildServiceNotification(isDismissed: Boolean, track: MediaTrackInfo?): Notification {
    val restoreIntent = Intent(ACTION_RESTORE_CAPSULE).setPackage(packageName)
    val restorePendingIntent = PendingIntent.getBroadcast(
      this, 201, restoreIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val openAppIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val openAppPendingIntent = PendingIntent.getActivity(
      this, 200, openAppIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val stopIntent = Intent(ACTION_STOP_SERVICE).setPackage(packageName)
    val stopPendingIntent = PendingIntent.getBroadcast(
      this, 202, stopIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val title: String
    val text: String
    if (isDismissed && track != null) {
      title = "🎵 ${track.title}"
      text = "${track.artist.ifEmpty { "Dynamic Capsule" }} • اضغط للاستعادة إلى الشاشة"
    } else if (isDismissed) {
      title = "Dynamic Capsule"
      text = "تم نقل الكبسولة إلى الإشعارات • اضغط للاستعادة"
    } else {
      title = "Dynamic Capsule نشط"
      text = "الكبسولة التفاعلية تعمل فوق التطبيقات"
    }

    val builder = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(text)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentIntent(if (isDismissed) restorePendingIntent else openAppPendingIntent)
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)

    if (isDismissed) {
      builder.addAction(android.R.drawable.ic_menu_upload, "إظهار الكبسولة", restorePendingIntent)
      if (track != null) {
        val toggleIntent = Intent(ACTION_TOGGLE_PLAY_PAUSE).setPackage(packageName)
        val togglePendingIntent = PendingIntent.getBroadcast(
          this, 203, toggleIntent,
          PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = if (track.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val label = if (track.isPlaying) "إيقاف مؤقت" else "تشغيل"
        builder.addAction(icon, label, togglePendingIntent)
      }
    } else {
      builder.addAction(android.R.drawable.ic_menu_preferences, "الإعدادات", openAppPendingIntent)
    }

    builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPendingIntent)
    return builder.build()
  }

  private fun buildNotificationRenderKey(
    isDismissed: Boolean,
    track: MediaTrackInfo?
  ): OverlayNotificationRenderKey {
    return if (isDismissed && track != null) {
      OverlayNotificationRenderKey(
        isDismissed = true,
        title = track.title,
        artist = track.artist,
        isPlaying = track.isPlaying
      )
    } else {
      OverlayNotificationRenderKey(
        isDismissed = isDismissed,
        title = "",
        artist = "",
        isPlaying = false
      )
    }
  }

  private fun updateNotification(isDismissed: Boolean, track: MediaTrackInfo? = null) {
    val key = buildNotificationRenderKey(isDismissed, track)
    if (key == lastNotificationRenderKey) return
    try {
      val manager = getSystemService(NotificationManager::class.java) ?: return
      manager.notify(NOTIFICATION_ID, buildServiceNotification(isDismissed, track))
      lastNotificationRenderKey = key
    } catch (e: Exception) {
      Log.e(TAG, "Error updating overlay notification", e)
    }
  }

  private fun registerNotificationActionReceiver() {
    if (actionReceiverRegistered) return
    val filter = IntentFilter().apply {
      addAction(ACTION_STOP_SERVICE)
      addAction(ACTION_RESTORE_CAPSULE)
      addAction(ACTION_TOGGLE_PLAY_PAUSE)
    }
    ContextCompat.registerReceiver(
      this,
      actionReceiver,
      filter,
      ContextCompat.RECEIVER_NOT_EXPORTED
    )
    actionReceiverRegistered = true
  }

  private fun unregisterNotificationActionReceiver() {
    if (!actionReceiverRegistered) return
    try {
      unregisterReceiver(actionReceiver)
    } catch (_: Exception) {
    } finally {
      actionReceiverRegistered = false
    }
  }

  fun dismissToNotification() {
    pendingCollapseDetachJob?.cancel()
    pendingCollapseDetachJob = null
    cancelPostCollapseGrace()
    val curTrack = MediaSessionHolder.currentTrack.value
    IslandStateManager.onCapsuleSwipedDismissed(
      trackInfo = curTrack,
      settings = CapsuleSettingsManager.getInstance(this).settings.value
    )
    dismissedEventSeq = IslandStateManager.activityEventSeq.value
    dismissedPlayingTrackKey = curTrack?.takeIf { it.isPlaying }?.let { "${it.packageName}|${it.title}|${it.artist}" }
    _isDismissedToNotification.value = true
    if (_capsuleMode.value == CapsuleMode.EXPANDED) {
      _capsuleMode.value = CapsuleMode.MINI
    }
    lastObservedMode = CapsuleMode.MINI
    detachView()
    updateNotification(true, curTrack)
  }

  fun restoreFromNotification() {
    dismissedPlayingTrackKey = null
    _isDismissedToNotification.value = false
    updateNotification(false, MediaSessionHolder.currentTrack.value)
  }

  private fun startPostCollapseGrace() {
    val scope = serviceScope ?: return
    postCollapseGraceJob?.cancel()
    _postCollapseGraceActive.value = true
    postCollapseGraceJob = scope.launch {
      delay(3000L)
      _postCollapseGraceActive.value = false
      postCollapseGraceJob = null
    }
  }

  private fun cancelPostCollapseGrace() {
    postCollapseGraceJob?.cancel()
    postCollapseGraceJob = null
    if (_postCollapseGraceActive.value) {
      _postCollapseGraceActive.value = false
    }
  }

  private fun initFloatingCapsule() {
    val context = this
    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      overlayWindowType,
      overlayFlags,
      PixelFormat.TRANSLUCENT
    ).apply {
      gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }
      y = calculateYPosition(settings)
    }

    floatingView = ComposeView(this).apply {
      lifecycleOwner?.let { owner ->
        setViewTreeLifecycleOwner(owner)
        setViewTreeViewModelStoreOwner(owner)
        setViewTreeSavedStateRegistryOwner(owner)
      }

      setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_OUTSIDE && _capsuleMode.value == CapsuleMode.EXPANDED) {
          setMode(CapsuleMode.MINI)
        }
        false
      }

      setContent {
        val currentMode by capsuleMode.collectAsState()
        val track by MediaSessionHolder.currentTrack.collectAsState()
        val currentSettings by CapsuleSettingsManager.getInstance(context).settings.collectAsState()
        val isPostCollapseHold by _postCollapseGraceActive.collectAsState()

        MyApplicationTheme(
          darkTheme = true,
          appThemeIndex = currentSettings.appThemeIndex,
          customSettings = currentSettings
        ) {
          Box(
            modifier = Modifier.wrapContentSize(),
            contentAlignment = Alignment.TopCenter
          ) {
            DynamicCapsuleView(
              trackInfo = track,
              settings = currentSettings,
              mode = currentMode,
              onModeChange = { newMode -> setMode(newMode) },
              onDismissToNotification = { dismissToNotification() },
              isPostCollapseMusicHold = isPostCollapseHold
            )
          }
        }
      }
    }
  }

  private fun observeState() {
    val scope = serviceScope ?: return
    val settingsManager = CapsuleSettingsManager.getInstance(this)

    val islandTriggers = combine(
      IslandStateManager.activeCard,
      combine(IslandStateManager.timerState, IslandStateManager.sleepTimerState, IslandStateManager.focusState) { _, _, _ -> Unit },
      IslandStateManager.downloadState,
      IslandStateManager.flashlightState,
      combine(IslandStateManager.ringerState, IslandStateManager.prayerState, IslandStateManager.suppressedCards) { _, _, _ -> Unit }
    ) { _, _, _, _, _ -> Unit }

    val extraTriggers = combine(
      IslandStateManager.batteryState,
      IslandStateManager.bluetoothState,
      IslandStateManager.activeNotification,
      IslandStateManager.navigationState,
      combine(
        IslandStateManager.privacyState,
        IslandStateManager.weatherState,
        IslandStateManager.stepsState,
        IslandStateManager.compassState,
        combine(IslandStateManager.deliveryState, IslandStateManager.footballState) { _, _ -> Unit }
      ) { _, _, _, _, _ -> Unit }
    ) { _, _, _, _, _ -> Unit }

    val statusTriggers = combine(
      extraTriggers,
      IslandStateManager.networkState,
      IslandStateManager.volumeState,
      IslandStateManager.activityEventSeq,
      combine(_isLandscape, FloatingCapsuleService.isConnected, _postCollapseGraceActive) { l, acc, grace ->
        Triple(l, acc, grace)
      }
    ) { _, _, _, eventSeq, envTriple ->
      OverlayStatusSnapshot(
        eventSeq = eventSeq,
        isLandscape = envTriple.first,
        accessibilityConnected = envTriple.second,
        postCollapseGraceActive = envTriple.third
      )
    }

    scope.launch {
      combine(
        MediaSessionHolder.currentTrack,
        settingsManager.settings,
        IslandStateManager.callState,
        _isDismissedToNotification,
        combine(islandTriggers, statusTriggers, _capsuleMode) { _, status, mode -> Pair(status, mode) }
      ) { track, settings, callState, isDismissed, (status, currentMode) ->
        val hasActivity = IslandStateManager.hasRenderableActivity(track, settings)
        val effectiveHasActivity = hasActivity || status.postCollapseGraceActive
        val isExpanded = currentMode == CapsuleMode.EXPANDED
        val currentPlayingKey = track?.takeIf { it.isPlaying }?.let { "${it.packageName}|${it.title}|${it.artist}" }

        var shouldClearDismissed = false
        var shouldResetTrackKey = false
        if (isDismissed) {
          if (currentPlayingKey == null) {
            shouldResetTrackKey = true
          }
          val newEventArrived = status.eventSeq > dismissedEventSeq
          val newMusicStarted = currentPlayingKey != null && currentPlayingKey != dismissedPlayingTrackKey
          val incomingCall = callState.isActive && callState.isIncoming
          val allEnded = !hasActivity && !isExpanded

          if (incomingCall || newEventArrived || newMusicStarted || allEnded) {
            shouldClearDismissed = true
            shouldResetTrackKey = true
          }
        }

        val effectivelyDismissed = isDismissed && !shouldClearDismissed
        val allowedInOrientation = IslandStateManager.shouldShowInOrientation(
          isLandscape = status.isLandscape,
          hideInLandscape = settings.hideInLandscape,
          hasActiveCall = callState.isActive
        )
        val canOverlay = Settings.canDrawOverlays(this@OverlayCapsuleService)
        val shouldShow = !status.accessibilityConnected &&
          canOverlay &&
          IslandStateManager.shouldCapsuleRemainVisible(
            hasActivity = effectiveHasActivity,
            isExpanded = isExpanded,
            showWhenIdle = settings.showWhenIdle,
            serviceEnabled = settings.serviceEnabled,
            effectivelyDismissed = effectivelyDismissed,
            allowedInOrientation = allowedInOrientation
          )
        OverlayCapsuleUiState(
          track = track,
          settings = settings,
          shouldShow = shouldShow,
          isDismissed = effectivelyDismissed,
          rawHasActivity = hasActivity,
          shouldClearDismissed = shouldClearDismissed,
          shouldResetTrackKey = shouldResetTrackKey
        )
      }.collect { state ->
        if (state.shouldResetTrackKey) {
          dismissedPlayingTrackKey = null
        }
        if (state.shouldClearDismissed && _isDismissedToNotification.value) {
          _isDismissedToNotification.value = false
        }
        val track = state.track
        val settings = state.settings
        val shouldShow = state.shouldShow
        val isDismissed = state.isDismissed
        val currentMode = _capsuleMode.value
        IslandStateManager.onObservedMediaPlayback(
          trackInfo = track,
          isExpanded = currentMode == CapsuleMode.EXPANDED,
          settings = settings
        )

        if (!settings.serviceEnabled || !Settings.canDrawOverlays(this@OverlayCapsuleService)) {
          cancelPostCollapseGrace()
          pendingCollapseDetachJob?.cancel()
          pendingCollapseDetachJob = null
          detachView()
          stopSelf()
          return@collect
        }

        val justCollapsedFromExpanded = lastObservedMode == CapsuleMode.EXPANDED && currentMode == CapsuleMode.MINI
        lastObservedMode = currentMode

        if (state.rawHasActivity || isDismissed || currentMode == CapsuleMode.EXPANDED || FloatingCapsuleService.isConnected.value) {
          cancelPostCollapseGrace()
        } else if (justCollapsedFromExpanded && postCollapseGraceJob?.isActive != true) {
          startPostCollapseGrace()
        }

        if (shouldShow) {
          pendingCollapseDetachJob?.cancel()
          pendingCollapseDetachJob = null
          if (!isViewAttached) {
            attachView()
          }
        } else if (isViewAttached) {
          if (isDismissed || FloatingCapsuleService.isConnected.value) {
            pendingCollapseDetachJob?.cancel()
            pendingCollapseDetachJob = null
            if (_capsuleMode.value == CapsuleMode.EXPANDED) {
              _capsuleMode.value = CapsuleMode.MINI
            }
            detachView()
          } else if (justCollapsedFromExpanded && pendingCollapseDetachJob?.isActive != true) {
            pendingCollapseDetachJob = scope.launch {
              delay(230L)
              if (_capsuleMode.value == CapsuleMode.MINI) {
                detachView()
              }
            }
          } else if (pendingCollapseDetachJob?.isActive != true) {
            detachView()
          }
        }

        if (isViewAttached) {
          val targetY = calculateYPosition(settings)
          if (targetY != lastAppliedLayoutY) {
            windowParams?.y = targetY
            windowParams?.let { params ->
              try {
                windowManager?.updateViewLayout(floatingView, params)
                lastAppliedLayoutY = targetY
              } catch (e: Exception) {
                Log.e(TAG, "Error updating overlay window layout", e)
              }
            }
          }
        }

        updateNotification(isDismissed && settings.serviceEnabled, track)
      }
    }
  }

  private fun setMode(mode: CapsuleMode) {
    val previousMode = _capsuleMode.value
    if (previousMode == mode) return
    _capsuleMode.value = mode

    val settings = CapsuleSettingsManager.getInstance(this).settings.value
    if (previousMode == CapsuleMode.EXPANDED && mode == CapsuleMode.MINI) {
      val curTrack = MediaSessionHolder.currentTrack.value
      if (!IslandStateManager.hasRenderableActivity(curTrack, settings) &&
        !_isDismissedToNotification.value &&
        !FloatingCapsuleService.isConnected.value
      ) {
        startPostCollapseGrace()
      }
    } else if (mode == CapsuleMode.EXPANDED) {
      cancelPostCollapseGrace()
    }
    windowParams?.let { params ->
      val targetY = calculateYPosition(settings)
      params.width = WindowManager.LayoutParams.WRAP_CONTENT
      params.height = WindowManager.LayoutParams.WRAP_CONTENT
      params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      params.y = targetY
      params.flags = overlayFlags
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        params.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }
      try {
        if (isViewAttached && floatingView != null) {
          windowManager?.updateViewLayout(floatingView, params)
          lastAppliedLayoutY = targetY
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error updating overlay mode", e)
      }
    }
  }

  private fun attachView() {
    val view = floatingView ?: return
    val params = windowParams ?: return
    if (!isViewAttached && Settings.canDrawOverlays(this)) {
      try {
        val targetY = calculateYPosition(CapsuleSettingsManager.getInstance(this).settings.value)
        params.y = targetY
        windowManager?.addView(view, params)
        isViewAttached = true
        lastAppliedLayoutY = targetY
      } catch (e: Exception) {
        Log.e(TAG, "Error adding overlay capsule view", e)
      }
    }
  }

  private fun detachView() {
    val view = floatingView ?: return
    if (isViewAttached) {
      try {
        windowManager?.removeView(view)
      } catch (e: Exception) {
        Log.e(TAG, "Error removing overlay capsule view", e)
      } finally {
        isViewAttached = false
        lastAppliedLayoutY = null
      }
    }
  }

  override fun onDestroy() {
    _isRunning.value = false
    cancelPostCollapseGrace()
    pendingCollapseDetachJob?.cancel()
    pendingCollapseDetachJob = null
    serviceJob?.cancel()
    serviceJob = null
    serviceScope = null
    lastNotificationRenderKey = null
    unregisterNotificationActionReceiver()
    detachView()
    lifecycleOwner?.destroy()
    lifecycleOwner = null
    floatingView = null
    windowManager = null
    windowParams = null
    super.onDestroy()
  }

  companion object {
    private const val TAG = "OverlayCapsuleService"
    private const val CHANNEL_ID = "dynamic_capsule_overlay_channel"
    private const val NOTIFICATION_ID = 2002
    const val ACTION_STOP_SERVICE = "com.example.overlay.action.STOP_SERVICE"
    const val ACTION_RESTORE_CAPSULE = "com.example.overlay.action.RESTORE_CAPSULE"
    const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.overlay.action.TOGGLE_PLAY_PAUSE"

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
  }
}

private data class OverlayCapsuleUiState(
  val track: MediaTrackInfo?,
  val settings: CapsuleSettings,
  val shouldShow: Boolean,
  val isDismissed: Boolean,
  val rawHasActivity: Boolean = false,
  val shouldClearDismissed: Boolean = false,
  val shouldResetTrackKey: Boolean = false
)

private data class OverlayStatusSnapshot(
  val eventSeq: Long,
  val isLandscape: Boolean,
  val accessibilityConnected: Boolean,
  val postCollapseGraceActive: Boolean
)

private data class OverlayNotificationRenderKey(
  val isDismissed: Boolean,
  val title: String,
  val artist: String,
  val isPlaying: Boolean
)
