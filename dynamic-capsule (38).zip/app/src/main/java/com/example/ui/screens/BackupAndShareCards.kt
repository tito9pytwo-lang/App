package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.CapsuleBackupManager
import com.example.data.CapsuleSettings
import com.example.ui.theme.AppTheme
import com.example.ui.theme.CardVariant
import com.example.ui.theme.ThemedCard

private fun contrastColorOn(background: Color): Color =
  if (background.luminance() > 0.55f) Color(0xFF121214) else Color.White

@Composable
private fun BackupIconBadge(
  icon: ImageVector,
  tint: Color
) {
  Box(
    modifier = Modifier
      .size(36.dp)
      .clip(RoundedCornerShape(11.dp))
      .background(tint.copy(alpha = 0.14f))
      .border(1.dp, tint.copy(alpha = 0.32f), RoundedCornerShape(11.dp)),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = tint,
      modifier = Modifier.size(19.dp)
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsBackupRestoreCard(
  settings: CapsuleSettings,
  isBusy: Boolean,
  statusMessage: String?,
  isStatusError: Boolean,
  onExportToFile: () -> Unit,
  onImportFromFile: () -> Unit,
  onShareBackupFile: () -> Unit
) {
  val palette = AppTheme.colors
  val summary = CapsuleBackupManager.summarize(settings)

  ThemedCard(
    variant = CardVariant.UTILITY_COMPACT,
    modifier = Modifier.testTag("settings_backup_restore_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          BackupIconBadge(icon = Icons.Default.Backup, tint = palette.secondary)
          Column {
            Text(
              text = "النسخ الاحتياطي للإعدادات",
              color = palette.textPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "حفظ واستعادة الكبسولة والألوان والصلاة والفرق في ملف واحد",
              color = palette.textSecondary,
              fontSize = 11.sp,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        BackupSummaryPill(
          label = "الفرق المفضلة: ${summary.favoriteTeamsCount}",
          tint = palette.success
        )
        BackupSummaryPill(
          label = "تعديلات الصلاة: ${summary.prayerAdjustmentsCount}",
          tint = palette.primary
        )
        BackupSummaryPill(
          label = if (summary.hasCustomColors) "ألوان مخصصة (${summary.customColorsCount})" else "ألوان الثيم",
          tint = palette.secondary
        )
        if (summary.excludedAppsCount > 0) {
          BackupSummaryPill(
            label = "تطبيقات مستثناة: ${summary.excludedAppsCount}",
            tint = palette.textSecondary
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = onExportToFile,
          enabled = !isBusy,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("export_settings_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = palette.primary,
            contentColor = contrastColorOn(palette.primary)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("تصدير لملف", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }

        OutlinedButton(
          onClick = onImportFromFile,
          enabled = !isBusy,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("import_settings_button"),
          border = BorderStroke(1.2.dp, palette.secondary.copy(alpha = 0.7f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.secondary),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("استيراد ملف", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
      }

      OutlinedButton(
        onClick = onShareBackupFile,
        enabled = !isBusy,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("share_backup_file_button"),
        border = BorderStroke(1.dp, palette.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.textPrimary),
        shape = RoundedCornerShape(12.dp)
      ) {
        if (isBusy) {
          CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = palette.primary
          )
        } else {
          Icon(Icons.Default.Send, contentDescription = null, tint = palette.primary, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isBusy) "جاري تجهيز الملف..." else "إرسال / مشاركة ملف النسخة الاحتياطية",
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      AnimatedVisibility(visible = !statusMessage.isNullOrBlank()) {
        val statusColor = if (isStatusError) palette.error else palette.success
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(statusColor.copy(alpha = 0.12f))
            .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp)
            .testTag("backup_status_banner"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = if (isStatusError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
            contentDescription = null,
            tint = statusColor,
            modifier = Modifier.size(17.dp)
          )
          Text(
            text = statusMessage.orEmpty(),
            color = statusColor,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }
  }
}

@Composable
private fun BackupSummaryPill(
  label: String,
  tint: Color
) {
  Surface(
    shape = RoundedCornerShape(9.dp),
    color = tint.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, tint.copy(alpha = 0.32f))
  ) {
    Text(
      text = label,
      color = tint,
      fontSize = 10.5.sp,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}

@Composable
fun ShareAppCard(
  isPreparingApk: Boolean,
  shareError: String?,
  onShareLink: () -> Unit,
  onShareApk: () -> Unit
) {
  val palette = AppTheme.colors

  ThemedCard(
    variant = CardVariant.UTILITY_COMPACT,
    modifier = Modifier.testTag("share_app_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.weight(1f)
        ) {
          BackupIconBadge(icon = Icons.Default.Share, tint = palette.primary)
          Column {
            Text(
              text = "مشاركة التطبيق",
              color = palette.textPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "شارك Dynamic Capsule مع أصدقائك برابط مباشر أو بملف التثبيت",
              color = palette.textSecondary,
              fontSize = 11.sp,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = palette.primary.copy(alpha = 0.14f),
          border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.42f))
        ) {
          Text(
            text = "v${BuildConfig.VERSION_NAME}",
            color = palette.primary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = onShareLink,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("share_app_link_button"),
          colors = ButtonDefaults.buttonColors(
            containerColor = palette.primary,
            contentColor = contrastColorOn(palette.primary)
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(17.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("مشاركة الرابط", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }

        OutlinedButton(
          onClick = onShareApk,
          enabled = !isPreparingApk,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("share_app_apk_button"),
          border = BorderStroke(1.2.dp, palette.success.copy(alpha = 0.7f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.success),
          shape = RoundedCornerShape(12.dp)
        ) {
          if (isPreparingApk) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp,
              color = palette.success
            )
          } else {
            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(17.dp))
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isPreparingApk) "جاري التجهيز..." else "إرسال APK",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
          )
        }
      }

      AnimatedVisibility(visible = !shareError.isNullOrBlank()) {
        Text(
          text = shareError.orEmpty(),
          color = palette.warning,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}
