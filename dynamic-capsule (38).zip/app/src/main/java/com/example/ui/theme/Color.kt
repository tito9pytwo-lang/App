package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =================================================
// Obsidian Amber & Jade Core Design Tokens (Dark)
// Zero Blue, Zero Purple — Warm Espresso Charcoal + Burnished Gold + Emerald Jade
// =================================================
val ObsidianBackground = Color(0xFF0E0C0A)
val ObsidianCardBackground = Color(0xFF181512)
val ObsidianElevatedSurface = Color(0xFF241F1A)

val ObsidianPrimary = Color(0xFFF59E0B)     // Burnished Amber Gold
val ObsidianSecondary = Color(0xFF10B981)   // Crisp Emerald Jade
val ObsidianTertiary = Color(0xFFFB7185)    // Terracotta Rose Coral
val ObsidianSuccess = Color(0xFF22C55E)     // Vivid Emerald Green (Start / Active)
val ObsidianWarning = Color(0xFFF97316)     // Burnt Tangerine (Warnings / Permissions)
val ObsidianError = Color(0xFFEF4444)       // Crimson Coral (Stop / End / Delete)

val ObsidianTextPrimary = Color(0xFFFAF6F0) // Warm Cream Ivory
val ObsidianTextSecondary = Color(0xFFC4B9A8) // Warm Sandstone
val ObsidianTextMuted = Color(0xFF8C8173)   // Muted Taupe
val ObsidianBorder = Color(0xFF352D24)      // Warm Bronze Hairline

// Light Mode Companion Tokens (Warm Sandstone Ivory)
val SandstoneLightBackground = Color(0xFFF5EFE4)
val SandstoneLightCardBackground = Color(0xFFFFFDF9)
val SandstoneLightElevatedSurface = Color(0xFFEDE4D5)
val SandstoneLightPrimary = Color(0xFFC26D00)
val SandstoneLightSecondary = Color(0xFF059669)
val SandstoneLightTertiary = Color(0xFFE11D48)
val SandstoneLightSuccess = Color(0xFF16A34A)
val SandstoneLightWarning = Color(0xFFEA580C)
val SandstoneLightError = Color(0xFFDC2626)
val SandstoneLightTextPrimary = Color(0xFF1E1915)
val SandstoneLightTextSecondary = Color(0xFF5E5448)
val SandstoneLightTextMuted = Color(0xFF8A7E70)
val SandstoneLightBorder = Color(0xFFDCD0BE)

// Semantic Token Aliases (centralized single source of truth)
val AuroraBackground = ObsidianBackground
val AuroraCardBackground = ObsidianCardBackground
val AuroraElevatedSurface = ObsidianElevatedSurface
val AuroraPrimary = ObsidianPrimary
val AuroraSecondary = ObsidianSecondary
val AuroraTertiary = ObsidianTertiary
val AuroraSuccess = ObsidianSuccess
val AuroraWarning = ObsidianWarning
val AuroraError = ObsidianError
val AuroraTextPrimary = ObsidianTextPrimary
val AuroraTextSecondary = ObsidianTextSecondary
val AuroraTextMuted = ObsidianTextMuted
val AuroraBorder = ObsidianBorder

val AuroraLightBackground = SandstoneLightBackground
val AuroraLightCardBackground = SandstoneLightCardBackground
val AuroraLightElevatedSurface = SandstoneLightElevatedSurface
val AuroraLightPrimary = SandstoneLightPrimary
val AuroraLightSecondary = SandstoneLightSecondary
val AuroraLightTertiary = SandstoneLightTertiary
val AuroraLightSuccess = SandstoneLightSuccess
val AuroraLightWarning = SandstoneLightWarning
val AuroraLightError = SandstoneLightError
val AuroraLightTextPrimary = SandstoneLightTextPrimary
val AuroraLightTextSecondary = SandstoneLightTextSecondary
val AuroraLightTextMuted = SandstoneLightTextMuted
val AuroraLightBorder = SandstoneLightBorder

// Capsule Swatches & Helper Aliases
val RealmeGreen = ObsidianSuccess
val RealmeGreenDark = SandstoneLightSuccess
val RealmeGreenGlow = Color(0x6622C55E)

val JadeTeal = ObsidianSecondary
val TerracottaCoral = ObsidianTertiary
val SunsetAmber = ObsidianPrimary
val CyberCyan = JadeTeal
val ElectricPurple = TerracottaCoral

val CapsuleBlack = Color(0xFF090806)
val CapsuleCardBlack = Color(0xFF15120F)
val DarkBackground = ObsidianBackground
val DarkSurface = ObsidianCardBackground
val DarkSurfaceCard = ObsidianElevatedSurface
val DarkSurfaceBorder = ObsidianBorder

val TextPrimary = ObsidianTextPrimary
val TextSecondary = ObsidianTextSecondary
val TextMuted = ObsidianTextMuted
