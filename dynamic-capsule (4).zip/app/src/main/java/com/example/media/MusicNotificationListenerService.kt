package com.example.media

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandStateManager
import com.example.service.FloatingCapsuleService

class MusicNotificationListenerService : NotificationListenerService() {

  private var mediaSessionManager: MediaSessionManager? = null
  private var currentController: MediaController? = null
  private var sessionComponent: ComponentName? = null

  private val sessionCallback = object : MediaController.Callback() {
    override fun onPlaybackStateChanged(state: PlaybackState?) {
      super.onPlaybackStateChanged(state)
      syncCurrentSession()
    }

    override fun onMetadataChanged(metadata: MediaMetadata?) {
      super.onMetadataChanged(metadata)
      syncCurrentSession()
    }

    override fun onSessionDestroyed() {
      super.onSessionDestroyed()
      currentController = null
      MediaSessionHolder.updateActiveController(null)
      refreshActiveSessions()
    }
  }

  private val sessionsChangedListener =
    MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
      updateActiveControllerFromList(controllers)
    }

  override fun onCreate() {
    super.onCreate()
    sessionComponent = ComponentName(this, MusicNotificationListenerService::class.java)
    mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    IslandStateManager.initialize(this)
  }

  override fun onListenerConnected() {
    super.onListenerConnected()
    MediaSessionHolder.setListenerConnected(true)
    try {
      sessionComponent?.let { comp ->
        mediaSessionManager?.addOnActiveSessionsChangedListener(sessionsChangedListener, comp)
        refreshActiveSessions()
      }
    } catch (e: SecurityException) {
      Log.e(TAG, "SecurityException registering session listener", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering session listener", e)
    }
  }

  override fun onListenerDisconnected() {
    super.onListenerDisconnected()
    MediaSessionHolder.setListenerConnected(false)
    cleanupController()
    try {
      mediaSessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
    } catch (e: Exception) {
      Log.e(TAG, "Error removing session listener", e)
    }
  }

  override fun onNotificationPosted(sbn: StatusBarNotification?) {
    super.onNotificationPosted(sbn)
    if (sbn == null) return

    val pkg = sbn.packageName ?: ""
    if (pkg == packageName) return

    val notif = sbn.notification ?: return
    val extras = notif.extras ?: return

    refreshActiveSessions()

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    // Real Call handling
    val isCallCategory = notif.category == Notification.CATEGORY_CALL ||
      pkg.contains("dialer") ||
      pkg.contains("telecom") ||
      pkg.contains("incall") ||
      pkg.contains("phone")

    if (settings.enableCallAlerts && isCallCategory) {
      var ansIntent: PendingIntent? = null
      var decIntent: PendingIntent? = null
      for (action in notif.actions ?: emptyArray()) {
        val t = action.title?.toString()?.lowercase() ?: ""
        if (t.contains("answer") || t.contains("رد") || t.contains("accept") || t.contains("اجابة")) {
          ansIntent = action.actionIntent
        } else if (t.contains("decline") || t.contains("reject") || t.contains("رفض") || t.contains("hang") || t.contains("انهاء") || t.contains("dismiss")) {
          decIntent = action.actionIntent
        }
      }
      CallManager.setCallNotificationIntents(ansIntent, decIntent)

      val title = extras.getString(Notification.EXTRA_TITLE)
        ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        ?: "Incoming Call"
      val number = extras.getString(Notification.EXTRA_TEXT)
        ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        ?: "Mobile"

      IslandStateManager.startCall(caller = title, number = number, isIncoming = true)
      return
    }

    // App message notifications
    if (settings.enableNotifications && notif.category != Notification.CATEGORY_SERVICE) {
      val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()

      if (!title.isNullOrBlank() && !text.isNullOrBlank()) {
        val appName = try {
          val appInfo = packageManager.getApplicationInfo(pkg, 0)
          packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
          pkg
        }
        IslandStateManager.postNotificationEvent(appName, title, text, pkg)
      }
    }
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification?) {
    super.onNotificationRemoved(sbn)
    if (sbn != null) {
      val notif = sbn.notification
      val pkg = sbn.packageName ?: ""
      val isCallCategory = notif?.category == Notification.CATEGORY_CALL ||
        pkg.contains("dialer") ||
        pkg.contains("telecom") ||
        pkg.contains("phone")
      if (isCallCategory) {
        IslandStateManager.endCall()
      }
    }
    refreshActiveSessions()
  }

  private fun refreshActiveSessions() {
    try {
      sessionComponent?.let { comp ->
        val controllers = mediaSessionManager?.getActiveSessions(comp)
        updateActiveControllerFromList(controllers)
      }
    } catch (e: SecurityException) {
      Log.e(TAG, "Permission denied fetching active sessions", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching active sessions", e)
    }
  }

  private fun updateActiveControllerFromList(controllers: List<MediaController>?) {
    if (controllers.isNullOrEmpty()) {
      cleanupController()
      MediaSessionHolder.updateActiveController(null)
      return
    }

    val playingController = controllers.firstOrNull {
      it.playbackState?.state == PlaybackState.STATE_PLAYING
    } ?: controllers.firstOrNull()

    if (playingController != null && playingController != currentController) {
      cleanupController()
      currentController = playingController
      currentController?.registerCallback(sessionCallback)
      MediaSessionHolder.updateActiveController(playingController)
      syncCurrentSession()
    } else if (playingController != null) {
      syncCurrentSession()
    }
  }

  private fun syncCurrentSession() {
    val controller = currentController ?: return
    val metadata = controller.metadata
    val state = controller.playbackState

    val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
      ?: "Unknown Track"

    val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
      ?: "Unknown Artist"

    val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
    val durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    val albumArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    val isPlaying = state?.state == PlaybackState.STATE_PLAYING
    val currentPosition = state?.position ?: 0L
    val speed = if (state != null && state.playbackSpeed > 0f) state.playbackSpeed else 1.0f

    val pkg = controller.packageName ?: ""
    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      pkg
    }

    val now = SystemClock.elapsedRealtime()
    val rawUpdateTime = state?.lastPositionUpdateTime ?: 0L
    val validUpdateTime = if (rawUpdateTime in (now - 60_000L)..now) {
      rawUpdateTime
    } else {
      now
    }

    val trackInfo = MediaTrackInfo(
      title = title,
      artist = artist,
      album = album,
      durationMs = durationMs,
      currentPositionMs = currentPosition,
      isPlaying = isPlaying,
      albumArt = albumArt,
      packageName = pkg,
      appName = appName,
      playbackSpeed = speed,
      lastUpdateTime = validUpdateTime
    )

    MediaSessionHolder.updateTrackInfo(trackInfo)

    val settings = CapsuleSettingsManager.getInstance(this).settings.value
    if (settings.serviceEnabled && isPlaying) {
      startCapsuleService()
    }
  }

  private fun startCapsuleService() {
    try {
      val intent = Intent(this, FloatingCapsuleService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(intent)
      } else {
        startService(intent)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to start FloatingCapsuleService", e)
    }
  }

  private fun cleanupController() {
    currentController?.unregisterCallback(sessionCallback)
    currentController = null
  }

  override fun onDestroy() {
    super.onDestroy()
    cleanupController()
  }

  companion object {
    private const val TAG = "MusicNotifListener"
  }
}
