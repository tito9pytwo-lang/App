package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence with negative and positive offset`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(-35)
    assertEquals(-35, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(85)
    assertEquals(85, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(0)
    assertEquals(0, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateShowWhenIdle(false)
    assertFalse(settingsManager.settings.value.showWhenIdle)

    settingsManager.updateAccentColorIndex(2)
    assertEquals(2, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test estimated position bounds and stability`() {
    val now = android.os.SystemClock.elapsedRealtime()
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Artist",
      durationMs = 200000L,
      currentPositionMs = 50000L,
      isPlaying = true,
      lastUpdateTime = now
    )

    // Position at now should be close to base
    val estimated = track.getEstimatedPositionMs()
    assertTrue(estimated in 50000L..50050L)

    // When paused, estimated position should equal currentPositionMs exactly
    val pausedTrack = track.copy(isPlaying = false)
    assertEquals(50000L, pausedTrack.getEstimatedPositionMs())
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Far closer",
      artist = "David",
      durationMs = 236000L,
      currentPositionMs = 174000L,
      isPlaying = false
    )

    assertEquals("03:56", track.formatTime(track.durationMs))
    assertEquals("02:54", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }

  @Test
  fun `test island state manager and activity detection`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // When idle and no music
    assertFalse(IslandStateManager.hasAnyActiveActivity(null))

    // When torch is turned on
    IslandStateManager.turnOnFlashlight(context)
    assertTrue(IslandStateManager.flashlightState.value.isOn)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Turn torch off
    IslandStateManager.turnOffFlashlight(context)
    assertFalse(IslandStateManager.flashlightState.value.isOn)

    // When timer is started
    IslandStateManager.startTimer(60, "Tea Timer")
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.cancelTimer()

    // When call is active
    IslandStateManager.startCall("John Doe", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.endCall()
    assertFalse(IslandStateManager.callState.value.isActive)
  }
}
