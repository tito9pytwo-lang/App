package com.example.media

import android.content.Context
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object MediaSessionHolder {

  private val _currentTrack = MutableStateFlow<MediaTrackInfo?>(null)
  val currentTrack: StateFlow<MediaTrackInfo?> = _currentTrack.asStateFlow()

  private val _isListenerConnected = MutableStateFlow(false)
  val isListenerConnected: StateFlow<Boolean> = _isListenerConnected.asStateFlow()

  private var activeController: MediaController? = null
  private var isDemoMode: Boolean = false

  private val scope = CoroutineScope(Dispatchers.Main + Job())
  private var progressTickerJob: Job? = null

  fun setListenerConnected(connected: Boolean) {
    _isListenerConnected.value = connected
  }

  fun updateActiveController(controller: MediaController?) {
    if (isDemoMode && controller != null) {
      isDemoMode = false
    }
    activeController = controller
    if (controller == null && !isDemoMode) {
      _currentTrack.value = null
      stopTicker()
    }
  }

  fun updateTrackInfo(trackInfo: MediaTrackInfo?) {
    if (isDemoMode && trackInfo != null) {
      isDemoMode = false
    }
    _currentTrack.value = trackInfo
    if (trackInfo?.isPlaying == true) {
      startTicker()
    } else {
      stopTicker()
    }
  }

  private fun startTicker() {
    progressTickerJob?.cancel()
    progressTickerJob = scope.launch {
      while (isActive) {
        delay(1000)
        val current = _currentTrack.value ?: break
        if (!current.isPlaying) break
        val now = SystemClock.elapsedRealtime()
        val estimated = current.getEstimatedPositionMs()
        _currentTrack.value = current.copy(
          currentPositionMs = estimated,
          lastUpdateTime = now
        )
      }
    }
  }

  private fun stopTicker() {
    progressTickerJob?.cancel()
    progressTickerJob = null
  }

  fun play() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(isPlaying = true, lastUpdateTime = SystemClock.elapsedRealtime())
      startTicker()
      return
    }
    activeController?.transportControls?.play()
  }

  fun pause() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        isPlaying = false,
        currentPositionMs = cur.getEstimatedPositionMs(),
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      stopTicker()
      return
    }
    activeController?.transportControls?.pause()
  }

  fun togglePlayPause() {
    val cur = _currentTrack.value
    if (cur?.isPlaying == true) {
      pause()
    } else {
      play()
    }
  }

  fun skipToNext() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        title = "Neon Skyline",
        artist = "Realme Sound Lab",
        currentPositionMs = 0L,
        durationMs = 210000L,
        isPlaying = true,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    activeController?.transportControls?.skipToNext()
  }

  fun skipToPrevious() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        title = "Pulse Horizon",
        artist = "Realme Sound Lab",
        currentPositionMs = 0L,
        durationMs = 195000L,
        isPlaying = true,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    activeController?.transportControls?.skipToPrevious()
  }

  fun seekTo(positionMs: Long) {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        currentPositionMs = positionMs,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    activeController?.transportControls?.seekTo(positionMs)
    val cur = _currentTrack.value
    if (cur != null) {
      _currentTrack.value = cur.copy(
        currentPositionMs = positionMs,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
    }
  }

  fun startDemoTrack() {
    isDemoMode = true
    _currentTrack.value = MediaTrackInfo(
      title = "Realme Cyber Pulse",
      artist = "Dynamic Sound Lab",
      album = "Mini Capsule Beats",
      durationMs = 225000L, // 3m 45s
      currentPositionMs = 45000L, // 0m 45s
      isPlaying = true,
      packageName = "com.spotify.music",
      appName = "Spotify Demo",
      playbackSpeed = 1.0f,
      lastUpdateTime = SystemClock.elapsedRealtime()
    )
    startTicker()
  }

  fun stopDemoTrack() {
    if (isDemoMode) {
      isDemoMode = false
      _currentTrack.value = null
      stopTicker()
    }
  }
}
