package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.service.FloatingCapsuleService
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainSettingsScreen(
  settingsManager: CapsuleSettingsManager,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val settings by settingsManager.settings.collectAsState()
  val trackInfo by MediaSessionHolder.currentTrack.collectAsState()
  val flashlightState by IslandStateManager.flashlightState.collectAsState()

  // Track live permissions state
  var canDrawOverlay by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
  var isNotifListenerGranted by remember {
    mutableStateOf(NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName))
  }
  var isPostNotifGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isCallPermissionGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isBatteryOptIgnored by remember {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    mutableStateOf(pm?.isIgnoringBatteryOptimizations(context.packageName) == true)
  }

  // Refresh permissions on resume
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        canDrawOverlay = Settings.canDrawOverlays(context)
        isNotifListenerGranted =
          NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          isPostNotifGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
          ) == PackageManager.PERMISSION_GRANTED
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          isCallPermissionGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ANSWER_PHONE_CALLS
          ) == PackageManager.PERMISSION_GRANTED
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        isBatteryOptIgnored = pm?.isIgnoringBatteryOptimizations(context.packageName) == true

        if (canDrawOverlay && settings.serviceEnabled) {
          startCapsuleService(context)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  val postNotifLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isPostNotifGranted = granted
  }

  val callPermLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { perms ->
    isCallPermissionGranted = perms[Manifest.permission.ANSWER_PHONE_CALLS] == true
  }

  var previewMode by remember { mutableStateOf(CapsuleMode.MINI) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      HeaderBanner(
        serviceEnabled = settings.serviceEnabled && canDrawOverlay && isNotifListenerGranted,
        accentColor = settings.accentColor
      )
    }

    // Live In-App Capsule Preview Card
    item {
      LivePreviewCard(
        trackInfo = trackInfo,
        settings = settings,
        previewMode = previewMode,
        onModeToggle = {
          previewMode = if (previewMode == CapsuleMode.MINI) CapsuleMode.EXPANDED else CapsuleMode.MINI
        }
      )
    }

    // Active Media Session Card & Demo Player
    item {
      ActivePlayerCard(
        trackInfo = trackInfo,
        isListenerConnected = isNotifListenerGranted,
        accentColor = settings.accentColor,
        onStartDemo = { MediaSessionHolder.startDemoTrack() },
        onStopDemo = { MediaSessionHolder.stopDemoTrack() }
      )
    }

    // Real Flashlight Quick Widget
    item {
      FlashlightQuickCard(
        isOn = flashlightState.isOn,
        onToggle = { IslandStateManager.toggleFlashlight(context) }
      )
    }

    // Required Permissions Checklist
    item {
      PermissionsCard(
        canDrawOverlay = canDrawOverlay,
        isNotifListenerGranted = isNotifListenerGranted,
        isPostNotifGranted = isPostNotifGranted,
        isCallPermissionGranted = isCallPermissionGranted,
        isBatteryOptIgnored = isBatteryOptIgnored,
        accentColor = settings.accentColor,
        onGrantOverlay = {
          val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
          )
          context.startActivity(intent)
        },
        onGrantListener = {
          val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
          context.startActivity(intent)
        },
        onRequestPostNotif = {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            postNotifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
          }
        },
        onRequestCallPerm = {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            callPermLauncher.launch(
              arrayOf(Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE)
            )
          }
        },
        onRequestBatteryOpt = {
          val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
          }
          context.startActivity(intent)
        }
      )
    }

    // 10 Dynamic Island Features Hub
    item {
      FeaturesHubCard(
        settings = settings,
        accentColor = settings.accentColor,
        onToggleFeature = { key, enabled ->
          settingsManager.toggleFeature(key, enabled)
          if (key == CapsuleSettingsManager.KEY_NET_SPEED) {
            IslandStateManager.setNetSpeedEnabled(enabled)
          }
        },
        onTestBattery = { IslandStateManager.showBatteryCharging(85) },
        onTestCall = { IslandStateManager.startCall("Tania Castillo", "Mobile", isIncoming = true) },
        onTestTimer = { IslandStateManager.startTimer(180, "Pasta Timer") },
        onTestNotif = { IslandStateManager.postNotificationEvent("WhatsApp", "Sarah", "Hey! Are we still meeting at 5?") },
        onTestBluetooth = { IslandStateManager.showBluetoothConnected("AirPods Pro", 95) },
        onToggleFlashlight = { IslandStateManager.toggleFlashlight(context) },
        onTestSports = { IslandStateManager.showSportsScore() }
      )
    }

    // Customization & Position Calibration Card
    item {
      CustomizationCard(
        settings = settings,
        onUpdateSettings = { newSettings ->
          settingsManager.updateNotchOffsetY(newSettings.notchOffsetYDp)
          settingsManager.updateCapsuleWidth(newSettings.capsuleWidthDp)
          settingsManager.updateCapsuleHeight(newSettings.capsuleHeightDp)
          settingsManager.updateAccentColorIndex(newSettings.accentColorIndex)
          settingsManager.updateShowWhenIdle(newSettings.showWhenIdle)
        },
        onToggleService = { enabled ->
          settingsManager.updateServiceEnabled(enabled)
          if (enabled) {
            startCapsuleService(context)
          } else {
            stopCapsuleService(context)
          }
        }
      )
    }
  }
}

@Composable
private fun HeaderBanner(
  serviceEnabled: Boolean,
  accentColor: Color
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Dynamic Island Pro",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "الكبسولة الذكية المتطورة • متوافقة مع Android 15",
            color = TextSecondary,
            fontSize = 13.sp
          )
        }

        Surface(
          shape = CircleShape,
          color = if (serviceEnabled) accentColor.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
          border = BorderStroke(
            1.dp,
            if (serviceEnabled) accentColor else Color.Red.copy(alpha = 0.5f)
          )
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (serviceEnabled) accentColor else Color.Red)
            )
            Text(
              text = if (serviceEnabled) "نشطة (Active)" else "غير مفعلة",
              color = if (serviceEnabled) accentColor else Color.Red,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LivePreviewCard(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  previewMode: CapsuleMode,
  onModeToggle: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.GraphicEq,
            contentDescription = null,
            tint = settings.accentColor,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "معاينة Dynamic Island",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }

        OutlinedButton(
          onClick = onModeToggle,
          modifier = Modifier.testTag("toggle_preview_mode_button"),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = settings.accentColor)
        ) {
          Text(
            text = if (previewMode == CapsuleMode.MINI) "تبديل للموسعة" else "تبديل للمصغرة",
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Simulated phone camera and screen top bezel with status bar
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(22.dp))
          .background(Color(0xFF040508))
          .border(1.dp, Color(0xFF1B202D), RoundedCornerShape(22.dp))
          .padding(top = 8.dp, bottom = 20.dp, start = 12.dp, end = 12.dp),
        contentAlignment = Alignment.TopCenter
      ) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // System Status Bar (Clock on left, Signal/Battery on right - untouched and visible)
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "9:41",
              color = Color.White.copy(alpha = 0.9f),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )

            // Small camera punch-hole indicator
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(Color(0xFF000000))
                .border(1.dp, Color(0xFF1E2532), CircleShape)
            )

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = "100%",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
              Box(
                modifier = Modifier
                  .width(18.dp)
                  .height(9.dp)
                  .border(1.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(2.dp))
                  .padding(1.dp)
              ) {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .background(RealmeGreen, RoundedCornerShape(1.dp))
                )
              }
            }
          }

          // Dynamic preview offset: shifts capsule position in real time with the slider
          val previewSpacing = (8 + (settings.notchOffsetYDp * 0.35f)).coerceIn(0f, 45f).dp
          Spacer(modifier = Modifier.height(previewSpacing))

          // Medium Dynamic Capsule directly below status bar
          DynamicCapsuleView(
            trackInfo = trackInfo ?: MediaTrackInfo(
              title = "Far closer",
              artist = "David",
              isPlaying = true,
              durationMs = 236000L,
              currentPositionMs = 174000L
            ),
            settings = settings,
            mode = previewMode,
            onModeChange = { /* Preview mode controlled by toggle button */ }
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "المعاينة تستجيب فوراً لضبط الارتفاع (Y Offset). يتم تحديث موضع الكبسولة العائمة على الشاشة بالكامل في الوقت الفعلي وحفظه.",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
private fun FlashlightQuickCard(
  isOn: Boolean,
  onToggle: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (isOn) Color(0xFFFFD600) else Color(0xFF262D3D)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
            contentDescription = null,
            tint = if (isOn) Color.Black else Color.White,
            modifier = Modifier.size(24.dp)
          )
        }

        Column {
          Text("مصباح الهاتف (Flashlight)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
          Text(if (isOn) "المصباح مضاء الآن" else "المصباح مطفأ", color = if (isOn) Color(0xFFFFD600) else TextSecondary, fontSize = 12.sp)
        }
      }

      Button(
        onClick = onToggle,
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isOn) Color(0xFFFFD600) else Color(0xFF2D364A),
          contentColor = if (isOn) Color.Black else Color.White
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text(if (isOn) "إطفاء" else "تشغيل", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    }
  }
}

@Composable
private fun ActivePlayerCard(
  trackInfo: MediaTrackInfo?,
  isListenerConnected: Boolean,
  accentColor: Color,
  onStartDemo: () -> Unit,
  onStopDemo: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Tune,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "مشغل الوسائط الحقيقي (Media Session)",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (trackInfo != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.GraphicEq,
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            Text(
              text = "${trackInfo.artist} • ${trackInfo.appName}",
              color = TextSecondary,
              fontSize = 12.sp,
              maxLines = 1
            )
          }

          if (trackInfo.appName.contains("Demo")) {
            OutlinedButton(
              onClick = onStopDemo,
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("إيقاف", fontSize = 11.sp)
            }
          }
        }
      } else {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (isListenerConnected)
              "جاهز للاتصال بمشغلات الموسيقى مثل Spotify وYouTube Music تلقائياً"
            else
              "يرجى منح صلاحية الإشعارات أدناه لقراءة الموسيقى",
            color = TextSecondary,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = onStartDemo,
            modifier = Modifier.testTag("start_demo_track_button"),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black)
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("تشغيل مقطع تجريبي لفحص الكبسولة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionsCard(
  canDrawOverlay: Boolean,
  isNotifListenerGranted: Boolean,
  isPostNotifGranted: Boolean,
  isCallPermissionGranted: Boolean,
  isBatteryOptIgnored: Boolean,
  accentColor: Color,
  onGrantOverlay: () -> Unit,
  onGrantListener: () -> Unit,
  onRequestPostNotif: () -> Unit,
  onRequestCallPerm: () -> Unit,
  onRequestBatteryOpt: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Settings,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(20.dp)
        )
        Text(
          text = "صلاحيات النظام المطلوبة",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      PermissionItem(
        title = "الظهور فوق التطبيقات (Overlay)",
        description = "مطلوبة لعرض الكبسولة أعلى الشاشة دون حجب التطبيقات",
        isGranted = canDrawOverlay,
        icon = Icons.Default.Widgets,
        accentColor = accentColor,
        onActionClick = onGrantOverlay
      )

      PermissionItem(
        title = "جلسات الوسائط والإشعارات (Media Listener)",
        description = "مطلوبة لقراءة بيانات الأغاني والتحكم الكامل بالموسيقى والمكالمات",
        isGranted = isNotifListenerGranted,
        icon = Icons.Default.GraphicEq,
        accentColor = accentColor,
        onActionClick = onGrantListener
      )

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        PermissionItem(
          title = "الرد على المكالمات (ANSWER_PHONE_CALLS)",
          description = "تتيح الرد ورفض المكالمات مباشرة من الكبسولة عبر واجهات Android الرسمية",
          isGranted = isCallPermissionGranted,
          icon = Icons.Default.PhoneInTalk,
          accentColor = accentColor,
          onActionClick = onRequestCallPerm
        )
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        PermissionItem(
          title = "إشعارات الخدمة (Notifications)",
          description = "مطلوبة لتشغيل خدمة الكبسولة في الخلفية بثبات تام",
          isGranted = isPostNotifGranted,
          icon = Icons.Default.Notifications,
          accentColor = accentColor,
          onActionClick = onRequestPostNotif
        )
      }

      PermissionItem(
        title = "استثناء توفير الطاقة (Battery Exemption)",
        description = "يمنع إغلاق خدمة الكبسولة بواسطة نظام إدارة الطاقة",
        isGranted = isBatteryOptIgnored,
        icon = Icons.Default.BatteryChargingFull,
        accentColor = accentColor,
        onActionClick = onRequestBatteryOpt
      )
    }
  }
}

@Composable
private fun FeaturesHubCard(
  settings: CapsuleSettings,
  accentColor: Color,
  onToggleFeature: (String, Boolean) -> Unit,
  onTestBattery: () -> Unit,
  onTestCall: () -> Unit,
  onTestTimer: () -> Unit,
  onTestNotif: () -> Unit,
  onTestBluetooth: () -> Unit,
  onToggleFlashlight: () -> Unit,
  onTestSports: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Tune,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(20.dp)
        )
        Text(
          text = "ميزات Dynamic Island المتطورة",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 1. Battery & Charging
      FeatureRow(
        icon = Icons.Default.BatteryChargingFull,
        title = "حالة البطارية والشحن",
        subtitle = "تنبيه شحن الكبسولة بنمط iOS",
        isChecked = settings.enableBatteryAlerts,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_BATTERY_ALERTS, it) },
        testActionLabel = "تجربة الشحن",
        onTestAction = onTestBattery
      )

      // 2. Incoming & Ongoing Calls
      FeatureRow(
        icon = Icons.Default.Call,
        title = "المكالمات الجارية ومدتها",
        subtitle = "أزرار الرد والإغلاق الفعلية وحساب الوقت",
        isChecked = settings.enableCallAlerts,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_CALL_ALERTS, it) },
        testActionLabel = "تجربة مكالمة",
        onTestAction = onTestCall
      )

      // 3. Timer & Countdown
      FeatureRow(
        icon = Icons.Default.HourglassTop,
        title = "المؤقت والعد التنازلي",
        subtitle = "مؤقت تفاعلي مع الإيقاف المؤقت والإلغاء",
        isChecked = settings.enableTimer,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_TIMER, it) },
        testActionLabel = "بدء مؤقت 3د",
        onTestAction = onTestTimer
      )

      // 4. Real-time Internet Speed
      FeatureRow(
        icon = Icons.Default.Speed,
        title = "سرعة الإنترنت لحظياً",
        subtitle = "مقياس سرعة التنزيل والرفع المباشر",
        isChecked = settings.enableNetSpeed,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_NET_SPEED, it) }
      )

      // 5. App Notifications
      FeatureRow(
        icon = Icons.Default.Notifications,
        title = "إشعارات التطبيقات",
        subtitle = "بانر أنيق للرسائل مع إشعار مختصر",
        isChecked = settings.enableNotifications,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_NOTIFICATIONS, it) },
        testActionLabel = "تجربة إشعار",
        onTestAction = onTestNotif
      )

      // 6. Bluetooth Headphones
      FeatureRow(
        icon = Icons.Default.Headphones,
        title = "سماعات البلوتوث",
        subtitle = "تنبيه اتصال AirPods وسماعات الرأس",
        isChecked = settings.enableBluetoothAlerts,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_BLUETOOTH_ALERTS, it) },
        testActionLabel = "تجربة سماعة",
        onTestAction = onTestBluetooth
      )

      // 7. Flashlight Alert
      FeatureRow(
        icon = Icons.Default.FlashlightOn,
        title = "التحكم الكامل بالمصباح",
        subtitle = "تشغيل وإطفاء المصباح الفعلي من الكبسولة",
        isChecked = settings.enableFlashlightAlert,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_FLASHLIGHT_ALERT, it) },
        testActionLabel = "تبديل المصباح",
        onTestAction = onToggleFlashlight
      )

      // 8. Live Sports Scores
      FeatureRow(
        icon = Icons.Default.SportsBaseball,
        title = "نتائج المباريات المباشرة",
        subtitle = "شريط النتائج الحية والأحداث اللحظية",
        isChecked = settings.enableSportsLive,
        accentColor = accentColor,
        onCheckedChange = { onToggleFeature(CapsuleSettingsManager.KEY_SPORTS_LIVE, it) },
        testActionLabel = "تجربة مباراة",
        onTestAction = onTestSports
      )
    }
  }
}

@Composable
private fun FeatureRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  isChecked: Boolean,
  accentColor: Color,
  onCheckedChange: (Boolean) -> Unit,
  testActionLabel: String? = null,
  onTestAction: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceCard)
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
    Spacer(modifier = Modifier.width(10.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
      Text(subtitle, color = TextSecondary, fontSize = 11.sp)
      if (testActionLabel != null && onTestAction != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "[$testActionLabel]",
          color = accentColor,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.clickable(onClick = onTestAction)
        )
      }
    }

    Switch(
      checked = isChecked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = accentColor)
    )
  }
}

@Composable
private fun CustomizationCard(
  settings: CapsuleSettings,
  onUpdateSettings: (CapsuleSettings) -> Unit,
  onToggleService: (Boolean) -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "تشغيل الكبسولة العائمة",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "تثبيت الكبسولة أعلى الشاشة بنمط Dynamic Island",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.serviceEnabled,
          onCheckedChange = onToggleService,
          modifier = Modifier.testTag("service_toggle_switch"),
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.Black,
            checkedTrackColor = settings.accentColor
          )
        )
      }

      HorizontalDivider(color = DarkSurfaceBorder)

      // Advanced Y Offset Controller: -150dp to +150dp with live preview and manual input
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(DarkSurfaceCard)
          .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "معايرة ارتفاع وموضع الكبسولة (Y Offset)",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = when {
                settings.notchOffsetYDp < 0 -> "${settings.notchOffsetYDp} dp (أعلى الشاشة / فوق الكاميرا ↑)"
                settings.notchOffsetYDp == 0 -> "0 dp (محاذاة ثقب الكاميرا الافتراضية)"
                else -> "+${settings.notchOffsetYDp} dp (أسفل الكاميرا ↓)"
              },
              color = if (settings.notchOffsetYDp == 0) settings.accentColor else TextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Reset to default button
          TextButton(
            onClick = { onUpdateSettings(settings.copy(notchOffsetYDp = 0)) },
            enabled = settings.notchOffsetYDp != 0,
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.RestartAlt,
              contentDescription = "إعادة ضبط",
              tint = if (settings.notchOffsetYDp != 0) settings.accentColor else TextMuted,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "إعادة ضبط",
              fontSize = 11.sp,
              color = if (settings.notchOffsetYDp != 0) settings.accentColor else TextMuted,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Expanded Slider from -150dp to +150dp (Full Unrestricted Freedom)
        Slider(
          value = settings.notchOffsetYDp.toFloat().coerceIn(-150f, 150f),
          onValueChange = { onUpdateSettings(settings.copy(notchOffsetYDp = it.toInt())) },
          valueRange = -150f..150f,
          colors = SliderDefaults.colors(
            thumbColor = settings.accentColor,
            activeTrackColor = settings.accentColor,
            inactiveTrackColor = Color(0xFF262E3E)
          )
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("-150 dp (أعلى)", color = TextMuted, fontSize = 10.sp)
          Text("0 dp (فوق الكاميرا)", color = TextMuted, fontSize = 10.sp)
          Text("+150 dp (أسفل)", color = TextMuted, fontSize = 10.sp)
        }

        // Fine-tuning row: -10, -5, -1, Manual Input text field, +1, +5, +10
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          StepButton(text = "-10", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 10).coerceIn(-150, 150)))
          })
          StepButton(text = "-5", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 5).coerceIn(-150, 150)))
          })
          StepButton(text = "-1", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp - 1).coerceIn(-150, 150)))
          })

          var manualText by remember(settings.notchOffsetYDp) {
            mutableStateOf(settings.notchOffsetYDp.toString())
          }
          OutlinedTextField(
            value = manualText,
            onValueChange = { str ->
              manualText = str
              val parsed = str.trim().toIntOrNull()
              if (parsed != null && parsed in -150..150) {
                onUpdateSettings(settings.copy(notchOffsetYDp = parsed))
              }
            },
            placeholder = { Text("dp", fontSize = 11.sp, color = TextMuted) },
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .height(48.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = settings.accentColor,
              unfocusedBorderColor = Color(0xFF2C374D),
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            )
          )

          StepButton(text = "+1", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 1).coerceIn(-150, 150)))
          })
          StepButton(text = "+5", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 5).coerceIn(-150, 150)))
          })
          StepButton(text = "+10", onClick = {
            onUpdateSettings(settings.copy(notchOffsetYDp = (settings.notchOffsetYDp + 10).coerceIn(-150, 150)))
          })
        }

        // Quick Preset Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          val presets = listOf(
            Pair("فوق الكاميرا (0)", 0),
            Pair("أعلى (-12)", -12),
            Pair("قمة (-40)", -40),
            Pair("تحت (+25)", 25),
            Pair("منخفض (+60)", 60)
          )
          presets.forEach { (label, presetVal) ->
            PresetChip(
              label = label,
              isSelected = settings.notchOffsetYDp == presetVal,
              accentColor = settings.accentColor,
              onClick = { onUpdateSettings(settings.copy(notchOffsetYDp = presetVal)) }
            )
          }
        }
      }

      // Accent Color Picker
      Column {
        Text(
          text = "لون التوهج والموجات (Theme Accent)",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          val colors = listOf(
            Pair("Realme Green", RealmeGreen),
            Pair("Cyber Cyan", CyberCyan),
            Pair("Purple", ElectricPurple),
            Pair("Amber", SunsetAmber),
            Pair("Apple Silver", Color(0xFFFFFFFF))
          )
          colors.forEachIndexed { index, (label, color) ->
            val isSelected = settings.accentColorIndex == index
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) Color(0xFF00E676) else Color.Transparent,
                  shape = CircleShape
                )
                .clickable { onUpdateSettings(settings.copy(accentColorIndex = index)) }
            )
          }
        }
      }

      // Compact Capsule Width Slider
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "عرض الكبسولة المصغرة",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "${settings.capsuleWidthDp} dp",
            color = settings.accentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Slider(
          value = settings.capsuleWidthDp.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(capsuleWidthDp = it.toInt())) },
          valueRange = 150f..240f,
          colors = SliderDefaults.colors(
            thumbColor = settings.accentColor,
            activeTrackColor = settings.accentColor
          )
        )
      }

      // Show when idle toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "إبقاء الكبسولة ظاهرة في وضع الخمول",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "إظهار نقطة الكاميرا السوداء حتى عند عدم وجود أي نشاط",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.showWhenIdle,
          onCheckedChange = { onUpdateSettings(settings.copy(showWhenIdle = it)) },
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.Black,
            checkedTrackColor = settings.accentColor
          )
        )
      }
    }
  }
}

@Composable
private fun PermissionItem(
  title: String,
  description: String,
  isGranted: Boolean,
  icon: ImageVector,
  accentColor: Color,
  onActionClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceCard)
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isGranted) accentColor else Color(0xFFFFB74D),
      modifier = Modifier.size(24.dp)
    )

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = description,
        color = TextSecondary,
        fontSize = 11.sp
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    if (isGranted) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = "Granted",
        tint = accentColor,
        modifier = Modifier.size(22.dp)
      )
    } else {
      Button(
        onClick = onActionClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B3347), contentColor = TextPrimary),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text("تفعيل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

private fun startCapsuleService(context: Context) {
  try {
    val intent = Intent(context, FloatingCapsuleService::class.java)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      context.startForegroundService(intent)
    } else {
      context.startService(intent)
    }
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to start FloatingCapsuleService", e)
  }
}

private fun stopCapsuleService(context: Context) {
  try {
    val intent = Intent(context, FloatingCapsuleService::class.java)
    context.stopService(intent)
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to stop FloatingCapsuleService", e)
  }
}

@Composable
private fun StepButton(
  text: String,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(width = 38.dp, height = 38.dp)
      .clip(RoundedCornerShape(10.dp))
      .background(Color(0xFF1E2536))
      .border(1.dp, Color(0xFF2C374D), RoundedCornerShape(10.dp))
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = TextPrimary,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun PresetChip(
  label: String,
  isSelected: Boolean,
  accentColor: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(8.dp))
      .background(if (isSelected) accentColor.copy(alpha = 0.2f) else Color(0xFF161C27))
      .border(1.dp, if (isSelected) accentColor else Color(0xFF273142), RoundedCornerShape(8.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 8.dp, vertical = 5.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = if (isSelected) accentColor else TextSecondary,
      fontSize = 10.sp,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
    )
  }
}
