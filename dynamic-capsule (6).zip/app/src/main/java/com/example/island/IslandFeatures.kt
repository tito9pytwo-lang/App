package com.example.island

import android.graphics.Bitmap

data class BatteryState(
  val isCharging: Boolean = false,
  val percentage: Int = 85,
  val isLow: Boolean = false,
  val lastEventTime: Long = 0L
)

data class CallState(
  val isActive: Boolean = false,
  val callerName: String = "Tania Castillo",
  val callerNumber: String = "Mobile",
  val durationSeconds: Int = 0,
  val isIncoming: Boolean = true
) {
  fun formatDuration(): String {
    val mins = durationSeconds / 60
    val secs = durationSeconds % 60
    return String.format("%02d:%02d", mins, secs)
  }
}

data class TimerState(
  val isRunning: Boolean = false,
  val remainingSeconds: Int = 0,
  val totalSeconds: Int = 0,
  val title: String = "Timer"
) {
  fun formatRemaining(): String {
    val mins = remainingSeconds / 60
    val secs = remainingSeconds % 60
    return String.format("%02d:%02d", mins, secs)
  }
}

data class NetSpeedState(
  val downloadSpeedText: String = "2.4 MB/s",
  val uploadSpeedText: String = "350 KB/s",
  val isEnabled: Boolean = false
)

data class NotificationEvent(
  val id: Long = System.currentTimeMillis(),
  val packageName: String = "",
  val appName: String = "WhatsApp",
  val title: String = "",
  val text: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

data class BluetoothState(
  val isConnected: Boolean = false,
  val deviceName: String = "AirPods Pro",
  val batteryPct: Int = 90,
  val timestamp: Long = 0L
)

data class FlashlightState(
  val isOn: Boolean = false
)

data class SportsState(
  val isActive: Boolean = false,
  val team1: String = "SF",
  val score1: Int = 5,
  val team2: String = "COL",
  val score2: Int = 1,
  val status: String = "7th • 0-0",
  val headline: String = "Joc Pederson singles on a soft ground ball to first base."
)

data class NavigationState(
  val isActive: Boolean = false,
  val maneuver: String = "Turn left",
  val roadName: String = "Church St",
  val distanceText: String = "In 20 m",
  val etaText: String = "7, 22 min",
  val timestamp: Long = 0L
)

data class RingerState(
  val isActive: Boolean = false,
  val isSilent: Boolean = true,
  val timestamp: Long = 0L
)

data class RecordingState(
  val isRecording: Boolean = false,
  val durationSeconds: Int = 0,
  val type: String = "Voice Memo",
  val timestamp: Long = 0L
) {
  fun formatDuration(): String {
    val mins = durationSeconds / 60
    val secs = durationSeconds % 60
    return String.format("%02d:%02d", mins, secs)
  }
}

data class AirDropState(
  val isActive: Boolean = false,
  val fileName: String = "Photo.jpg",
  val senderName: String = "iPhone (David)",
  val progress: Int = 78,
  val isComplete: Boolean = false,
  val timestamp: Long = 0L
)

enum class IslandActiveCard {
  MUSIC,
  BATTERY,
  CALL,
  TIMER,
  NOTIFICATION,
  BLUETOOTH,
  SPORTS,
  FLASHLIGHT,
  NAVIGATION,
  RINGER,
  RECORDING,
  AIRDROP,
  CLOCK
}
