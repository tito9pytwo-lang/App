package com.example.ui.capsule

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CapsuleSettings
import com.example.island.AirDropState
import com.example.island.BatteryState
import com.example.island.BluetoothState
import com.example.island.CallState
import com.example.island.FlashlightState
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NavigationState
import com.example.island.NetSpeedState
import com.example.island.NotificationEvent
import com.example.island.RecordingState
import com.example.island.RingerState
import com.example.island.SportsState
import com.example.island.TimerState
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CapsuleMode {
  MINI,
  EXPANDED
}

/**
 * Reusable Marquee Text with soft edge fade ("يتحرك و يختفي")
 * Scrolls horizontally if text is longer than container, and fades at both ends.
 */
@Composable
fun MarqueeFadingText(
  text: String,
  modifier: Modifier = Modifier,
  color: Color = Color.White,
  fontSize: TextUnit = 12.sp,
  fontWeight: FontWeight = FontWeight.Bold,
  maxLines: Int = 1,
  edgeFadeWidth: Dp = 8.dp,
  textAlign: TextAlign? = null
) {
  val edgePx = with(LocalDensity.current) { edgeFadeWidth.toPx() }
  Text(
    text = text,
    color = color,
    fontSize = fontSize,
    fontWeight = fontWeight,
    maxLines = maxLines,
    textAlign = textAlign,
    modifier = modifier
      .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
      .drawWithContent {
        drawContent()
        if (size.width > edgePx * 2) {
          // Left soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Transparent, Color.Black),
              startX = 0f,
              endX = edgePx
            ),
            blendMode = BlendMode.DstIn
          )
          // Right soft fade
          drawRect(
            brush = Brush.horizontalGradient(
              colors = listOf(Color.Black, Color.Transparent),
              startX = size.width - edgePx,
              endX = size.width
            ),
            blendMode = BlendMode.DstIn
          )
        }
      }
      .basicMarquee(
        iterations = Int.MAX_VALUE,
        repeatDelayMillis = 1400,
        initialDelayMillis = 900,
        velocity = 32.dp
      )
  )
}

@Composable
fun DynamicCapsuleView(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  mode: CapsuleMode,
  onModeChange: (CapsuleMode) -> Unit,
  modifier: Modifier = Modifier,
  onPlayPauseClick: () -> Unit = { MediaSessionHolder.togglePlayPause() },
  onNextClick: () -> Unit = { MediaSessionHolder.skipToNext() },
  onPrevClick: () -> Unit = { MediaSessionHolder.skipToPrevious() },
  onSeek: (Long) -> Unit = { MediaSessionHolder.seekTo(it) }
) {
  val accentColor = settings.accentColor
  val activeCard by IslandStateManager.activeCard.collectAsState()
  val batteryState by IslandStateManager.batteryState.collectAsState()
  val callState by IslandStateManager.callState.collectAsState()
  val timerState by IslandStateManager.timerState.collectAsState()
  val netSpeed by IslandStateManager.netSpeedState.collectAsState()
  val notifEvent by IslandStateManager.activeNotification.collectAsState()
  val bluetooth by IslandStateManager.bluetoothState.collectAsState()
  val flashlight by IslandStateManager.flashlightState.collectAsState()
  val sports by IslandStateManager.sportsState.collectAsState()
  val navigation by IslandStateManager.navigationState.collectAsState()
  val ringer by IslandStateManager.ringerState.collectAsState()
  val recording by IslandStateManager.recordingState.collectAsState()
  val airDrop by IslandStateManager.airDropState.collectAsState()

  val isExpanded = mode == CapsuleMode.EXPANDED

  // Apple-grade fluid spring morphing dimensions
  val targetWidth = if (isExpanded) 364.dp else 236.dp
  val targetHeight = if (isExpanded) 206.dp else settings.capsuleHeightDp.dp
  val targetCornerRadius = if (isExpanded) 32.dp else 24.dp

  val animatedWidth by animateDpAsState(
    targetValue = targetWidth,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioLowBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_width"
  )
  val animatedHeight by animateDpAsState(
    targetValue = targetHeight,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioLowBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_height"
  )
  val animatedCornerRadius by animateDpAsState(
    targetValue = targetCornerRadius,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "capsule_corners"
  )

  Surface(
    modifier = modifier
      .testTag(if (isExpanded) "expanded_capsule_card" else "mini_capsule_surface")
      .width(animatedWidth)
      .height(animatedHeight)
      .shadow(
        elevation = if (isExpanded) 24.dp else 16.dp,
        shape = RoundedCornerShape(animatedCornerRadius),
        spotColor = accentColor.copy(alpha = if (isExpanded) 0.5f else 0.4f)
      )
      .clip(RoundedCornerShape(animatedCornerRadius))
      .background(Color(0xFF07080A))
      .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
          listOf(
            Color.White.copy(alpha = if (isExpanded) 0.22f else 0.16f),
            Color(0xFF1B2230),
            accentColor.copy(alpha = 0.35f)
          )
        ),
        shape = RoundedCornerShape(animatedCornerRadius)
      )
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = {
          if (!isExpanded) {
            onModeChange(CapsuleMode.EXPANDED)
          }
        }
      ),
    color = Color(0xFF07080A),
    shape = RoundedCornerShape(animatedCornerRadius)
  ) {
    AnimatedContent(
      targetState = isExpanded,
      transitionSpec = {
        (fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
          scaleIn(initialScale = 0.94f, animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy)))
          .togetherWith(
            fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
              scaleOut(targetScale = 0.94f, animationSpec = spring())
          )
      },
      label = "capsule_morphing_content"
    ) { expanded ->
      if (expanded) {
        ExpandedDynamicContent(
          trackInfo = trackInfo,
          settings = settings,
          accentColor = accentColor,
          activeCard = activeCard,
          batteryState = batteryState,
          callState = callState,
          timerState = timerState,
          notifEvent = notifEvent,
          bluetooth = bluetooth,
          flashlight = flashlight,
          sports = sports,
          navigation = navigation,
          ringer = ringer,
          recording = recording,
          airDrop = airDrop,
          onCollapse = { onModeChange(CapsuleMode.MINI) },
          onPlayPauseClick = onPlayPauseClick,
          onNextClick = onNextClick,
          onPrevClick = onPrevClick,
          onSeek = onSeek
        )
      } else {
        MediumDynamicContent(
          trackInfo = trackInfo,
          settings = settings,
          accentColor = accentColor,
          activeCard = activeCard,
          batteryState = batteryState,
          callState = callState,
          timerState = timerState,
          netSpeed = netSpeed,
          notifEvent = notifEvent,
          bluetooth = bluetooth,
          flashlight = flashlight,
          sports = sports,
          navigation = navigation,
          ringer = ringer,
          recording = recording,
          airDrop = airDrop
        )
      }
    }
  }
}

/**
 * Collapsed / Mini Dynamic Island Content
 */
@Composable
fun MediumDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  netSpeed: NetSpeedState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  sports: SportsState,
  navigation: NavigationState,
  ringer: RingerState,
  recording: RecordingState,
  airDrop: AirDropState
) {
  val context = LocalContext.current
  val isPlaying = trackInfo?.isPlaying == true

  // Pulsing animation for active recording
  val infiniteTransition = rememberInfiniteTransition(label = "recording_pulse")
  val recPulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(600),
      repeatMode = RepeatMode.Reverse
    ),
    label = "rec_pulse"
  )

  Row(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    when {
      // 1. Ringer Switch Alert (iOS Dynamic Island signature alert)
      ringer.isActive && (System.currentTimeMillis() - ringer.timestamp < 3500L) -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(if (ringer.isSilent) Color(0xFFFF9500).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (ringer.isSilent) Icons.Default.NotificationsOff else Icons.Default.NotificationsActive,
              contentDescription = null,
              tint = if (ringer.isSilent) Color(0xFFFF9500) else Color.White,
              modifier = Modifier.size(16.dp)
            )
          }
          Text(
            text = if (ringer.isSilent) "صامت • Silent" else "رنين • Ring",
            color = if (ringer.isSilent) Color(0xFFFF9500) else TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (ringer.isSilent) Color(0xFFFF9500) else RealmeGreen)
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text(
            text = if (ringer.isSilent) "MUTE" else "SOUND",
            color = Color.Black,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold
          )
        }
      }

      // 2. Navigation Turn-by-Turn Alert (Screenshot 6)
      navigation.isActive -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFF007AFF).copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Navigation,
              contentDescription = null,
              tint = Color(0xFF0A84FF),
              modifier = Modifier.size(16.dp)
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = navigation.distanceText,
              color = Color.White.copy(alpha = 0.75f),
              fontSize = 9.sp,
              fontWeight = FontWeight.Normal
            )
            MarqueeFadingText(
              text = "${navigation.maneuver} • ${navigation.roadName}",
              color = TextPrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFFFF9500))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(navigation.etaText, color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
      }

      // 3. Audio / Voice Recording Active
      recording.isRecording -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(12.dp)
              .clip(CircleShape)
              .background(Color(0xFFFF3B30).copy(alpha = recPulseAlpha))
          )
          Text(
            text = recording.type,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = recording.formatDuration(),
            color = Color(0xFFFF453A),
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold
          )
          MiniWaveformVisualizer(
            isPlaying = true,
            color = Color(0xFFFF453A),
            barCount = 3,
            width = 14.dp,
            height = 12.dp
          )
        }
      }

      // 4. AirDrop / Quick Share File Transfer
      airDrop.isActive -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFF007AFF).copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (airDrop.isComplete) Icons.Default.Check else Icons.Default.Share,
              contentDescription = null,
              tint = if (airDrop.isComplete) RealmeGreen else Color(0xFF0A84FF),
              modifier = Modifier.size(15.dp)
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("AirDrop", color = Color(0xFF0A84FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            MarqueeFadingText(
              text = if (airDrop.isComplete) "Transferred!" else airDrop.fileName,
              color = TextPrimary,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
        Text(
          text = if (airDrop.isComplete) "Done" else "${airDrop.progress}%",
          color = if (airDrop.isComplete) RealmeGreen else Color(0xFF0A84FF),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 5. Flashlight ON: Yellow icon + label + direct turn off button
      flashlight.isOn && settings.enableFlashlightAlert -> {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFD600)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.FlashlightOn,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(17.dp)
            )
          }
          Text(
            text = "المصباح مفعّل",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(Color(0xFF332A00))
            .clickable { IslandStateManager.turnOffFlashlight(context) }
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text("إطفاء", color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
      }

      // 6. Call Ongoing / Incoming (Screenshot 4)
      callState.isActive && settings.enableCallAlerts -> {
        if (callState.isIncoming) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f, fill = false)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            Column {
              Text("mobile", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Normal)
              MarqueeFadingText(
                text = callState.callerName,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(15.dp))
            }
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFF34C759))
                .clickable { IslandStateManager.answerCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(15.dp))
            }
          }
        } else {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(RealmeGreen.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Call, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(15.dp))
            }
            MarqueeFadingText(
              text = callState.callerName,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Box(
              modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFFFF3B30))
                .clickable { IslandStateManager.declineCall(context) },
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(13.dp))
            }
          }
        }
      }

      // 7. Battery Charging Event (Screenshot 3)
      batteryState.isCharging && settings.enableBatteryAlerts && (System.currentTimeMillis() - batteryState.lastEventTime < 7000L) -> {
        Text("Charging", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("${batteryState.percentage}%", color = RealmeGreen, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
          Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = RealmeGreen, modifier = Modifier.size(18.dp))
        }
      }

      // 8. App Notification Banner
      notifEvent != null && settings.enableNotifications -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Notifications, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
          MarqueeFadingText(
            text = "${notifEvent.appName}: ${notifEvent.title}",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      // 9. Timer Running (Screenshot 2)
      timerState.isRunning && settings.enableTimer -> {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(Color(0xFFFFB74D).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFFFB74D), modifier = Modifier.size(16.dp))
          }
          MarqueeFadingText(
            text = timerState.title,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Text(timerState.formatRemaining(), color = Color(0xFFFFB74D), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
      }

      // 10. Bluetooth Connected
      bluetooth.isConnected && settings.enableBluetoothAlerts && (System.currentTimeMillis() - bluetooth.timestamp < 6000L) -> {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.Headphones, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
          MarqueeFadingText(
            text = bluetooth.deviceName,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Text("${bluetooth.batteryPct}%", color = accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }

      // 11. Sports Live Active (Screenshot 5)
      sports.isActive && settings.enableSportsLive -> {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.SportsBaseball, contentDescription = null, tint = Color(0xFFFF8A80), modifier = Modifier.size(16.dp))
          Text("${sports.team1} ${sports.score1} - ${sports.score2} ${sports.team2}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text(sports.status, color = TextSecondary, fontSize = 11.sp)
      }

      // 12. Music Playing (Default Active Activity with Marquee Fading Text)
      trackInfo != null && isPlaying -> {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (trackInfo.albumArt != null) {
            Image(
              bitmap = trackInfo.albumArt.asImageBitmap(),
              contentDescription = "Album Thumbnail",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(0.8.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
            )
          } else {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(accentColor.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Column(modifier = Modifier.weight(1f)) {
            MarqueeFadingText(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            MarqueeFadingText(
              text = trackInfo.artist,
              color = TextSecondary,
              fontSize = 10.sp,
              fontWeight = FontWeight.Normal
            )
          }
        }

        Spacer(modifier = Modifier.width(6.dp))

        MiniWaveformVisualizer(
          isPlaying = true,
          color = accentColor,
          barCount = 4,
          width = 18.dp,
          height = 14.dp
        )
      }

      // Idle state
      else -> {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(Color(0xFF1E2532))
          )
        }
      }
    }
  }
}

/**
 * Expanded Dynamic Island Content
 */
@Composable
fun ExpandedDynamicContent(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  accentColor: Color,
  activeCard: IslandActiveCard,
  batteryState: BatteryState,
  callState: CallState,
  timerState: TimerState,
  notifEvent: NotificationEvent?,
  bluetooth: BluetoothState,
  flashlight: FlashlightState,
  sports: SportsState,
  navigation: NavigationState,
  ringer: RingerState,
  recording: RecordingState,
  airDrop: AirDropState,
  onCollapse: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val context = LocalContext.current
  var currentSelectedTab by remember { mutableStateOf(activeCard) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(14.dp)
  ) {
    // Header Bar: Activity Tabs + Immediate Collapse Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        TabIndicator(
          icon = Icons.Default.GraphicEq,
          isSelected = currentSelectedTab == IslandActiveCard.MUSIC,
          color = accentColor,
          onClick = { currentSelectedTab = IslandActiveCard.MUSIC }
        )

        if (navigation.isActive) {
          TabIndicator(
            icon = Icons.Default.Navigation,
            isSelected = currentSelectedTab == IslandActiveCard.NAVIGATION,
            color = Color(0xFF0A84FF),
            onClick = { currentSelectedTab = IslandActiveCard.NAVIGATION }
          )
        }

        if (recording.isRecording) {
          TabIndicator(
            icon = Icons.Default.Mic,
            isSelected = currentSelectedTab == IslandActiveCard.RECORDING,
            color = Color(0xFFFF453A),
            onClick = { currentSelectedTab = IslandActiveCard.RECORDING }
          )
        }

        if (airDrop.isActive) {
          TabIndicator(
            icon = Icons.Default.Share,
            isSelected = currentSelectedTab == IslandActiveCard.AIRDROP,
            color = Color(0xFF0A84FF),
            onClick = { currentSelectedTab = IslandActiveCard.AIRDROP }
          )
        }

        if (flashlight.isOn) {
          TabIndicator(
            icon = Icons.Default.FlashlightOn,
            isSelected = currentSelectedTab == IslandActiveCard.FLASHLIGHT,
            color = Color(0xFFFFD600),
            onClick = { currentSelectedTab = IslandActiveCard.FLASHLIGHT }
          )
        }

        if (timerState.isRunning) {
          TabIndicator(
            icon = Icons.Default.HourglassTop,
            isSelected = currentSelectedTab == IslandActiveCard.TIMER,
            color = Color(0xFFFFB74D),
            onClick = { currentSelectedTab = IslandActiveCard.TIMER }
          )
        }

        if (callState.isActive) {
          TabIndicator(
            icon = Icons.Default.Call,
            isSelected = currentSelectedTab == IslandActiveCard.CALL,
            color = RealmeGreen,
            onClick = { currentSelectedTab = IslandActiveCard.CALL }
          )
        }

        if (sports.isActive) {
          TabIndicator(
            icon = Icons.Default.SportsBaseball,
            isSelected = currentSelectedTab == IslandActiveCard.SPORTS,
            color = Color(0xFFFF8A80),
            onClick = { currentSelectedTab = IslandActiveCard.SPORTS }
          )
        }
      }

      // Collapse Button
      IconButton(
        onClick = onCollapse,
        modifier = Modifier
          .testTag("collapse_capsule_button")
          .size(30.dp)
          .background(Color.White.copy(alpha = 0.12f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Rounded.KeyboardArrowUp,
          contentDescription = "Collapse Capsule",
          tint = TextPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Active Card View
    when (currentSelectedTab) {
      IslandActiveCard.NAVIGATION -> {
        ExpandedNavigationView(
          navigation = navigation,
          onDismiss = {
            IslandStateManager.stopNavigation()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.RECORDING -> {
        ExpandedRecordingView(
          recording = recording,
          onStop = {
            IslandStateManager.stopRecording()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.AIRDROP -> {
        ExpandedAirDropView(
          airDrop = airDrop,
          onCancel = {
            IslandStateManager.cancelAirDrop()
            currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.FLASHLIGHT -> {
        ExpandedFlashlightView(
          flashlight = flashlight,
          onToggle = { IslandStateManager.toggleFlashlight(context) },
          onTurnOff = {
            IslandStateManager.turnOffFlashlight(context)
            if (trackInfo?.isPlaying == true) currentSelectedTab = IslandActiveCard.MUSIC
          }
        )
      }
      IslandActiveCard.TIMER -> {
        ExpandedTimerView(
          timerState = timerState,
          onTogglePause = { IslandStateManager.toggleTimerPause() },
          onCancel = { IslandStateManager.cancelTimer(); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      IslandActiveCard.CALL -> {
        ExpandedCallView(
          callState = callState,
          onAnswer = { IslandStateManager.answerCall(context) },
          onDecline = { IslandStateManager.declineCall(context); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      IslandActiveCard.SPORTS -> {
        ExpandedSportsView(
          sports = sports,
          onDismiss = { IslandStateManager.dismissSports(); currentSelectedTab = IslandActiveCard.MUSIC }
        )
      }
      else -> {
        ExpandedMusicView(
          trackInfo = trackInfo,
          accentColor = accentColor,
          onPlayPauseClick = onPlayPauseClick,
          onNextClick = onNextClick,
          onPrevClick = onPrevClick,
          onSeek = onSeek
        )
      }
    }
  }
}

@Composable
private fun TabIndicator(
  icon: ImageVector,
  isSelected: Boolean,
  color: Color,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .size(26.dp)
      .clip(CircleShape)
      .background(if (isSelected) color.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f))
      .border(1.dp, if (isSelected) color else Color.Transparent, CircleShape)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isSelected) color else TextSecondary,
      modifier = Modifier.size(14.dp)
    )
  }
}

/**
 * Music Expanded Player (Screenshot 1 & Screenshot 7)
 */
@Composable
fun ExpandedMusicView(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val isPlaying = trackInfo?.isPlaying == true
  val duration = (trackInfo?.durationMs ?: 0L).coerceAtLeast(1L)
  val currentPos = trackInfo?.getEstimatedPositionMs() ?: 0L

  var isUserDragging by remember { mutableStateOf(false) }
  var dragPositionFraction by remember { mutableFloatStateOf(0f) }
  var isFavorite by remember { mutableStateOf(false) }
  var repeatMode by remember { mutableIntStateOf(0) }

  val effectiveFraction = if (isUserDragging) {
    dragPositionFraction
  } else {
    (currentPos.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
  }

  Column(modifier = Modifier.fillMaxWidth()) {
    // Top Row: Album Cover + Track Title (Marquee) + Artist + Cast Icon
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (trackInfo?.albumArt != null) {
        Image(
          bitmap = trackInfo.albumArt.asImageBitmap(),
          contentDescription = "Album Art",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
            .shadow(10.dp, RoundedCornerShape(14.dp), spotColor = accentColor.copy(alpha = 0.5f))
        )
      } else {
        Box(
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
              Brush.linearGradient(
                listOf(Color(0xFF263248), Color(0xFF131926))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(28.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        MarqueeFadingText(
          text = trackInfo?.title ?: "Far closer",
          color = TextPrimary,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        MarqueeFadingText(
          text = trackInfo?.artist ?: "David",
          color = TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Normal
        )
      }

      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Cast,
          contentDescription = "AirPlay / Cast",
          tint = TextSecondary,
          modifier = Modifier.size(16.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Controls Row: Repeat, Previous, Play/Pause, Next, Favorite
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = { repeatMode = (repeatMode + 1) % 3 },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = if (repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
          contentDescription = "Repeat",
          tint = if (repeatMode > 0) accentColor else TextMuted,
          modifier = Modifier.size(19.dp)
        )
      }

      IconButton(
        onClick = onPrevClick,
        modifier = Modifier
          .testTag("prev_track_button")
          .size(40.dp)
          .background(Color.White.copy(alpha = 0.06f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipPrevious,
          contentDescription = "Previous Track",
          tint = TextPrimary,
          modifier = Modifier.size(22.dp)
        )
      }

      IconButton(
        onClick = onPlayPauseClick,
        modifier = Modifier
          .testTag("play_pause_button")
          .size(52.dp)
          .shadow(12.dp, CircleShape, spotColor = accentColor)
          .background(accentColor, CircleShape)
      ) {
        Icon(
          imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
          contentDescription = if (isPlaying) "Pause" else "Play",
          tint = Color.Black,
          modifier = Modifier.size(30.dp)
        )
      }

      IconButton(
        onClick = onNextClick,
        modifier = Modifier
          .testTag("next_track_button")
          .size(40.dp)
          .background(Color.White.copy(alpha = 0.06f), CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.SkipNext,
          contentDescription = "Next Track",
          tint = TextPrimary,
          modifier = Modifier.size(22.dp)
        )
      }

      IconButton(
        onClick = { isFavorite = !isFavorite },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
          contentDescription = "Favorite",
          tint = if (isFavorite) Color(0xFFFF5252) else TextMuted,
          modifier = Modifier.size(19.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Interactive Draggable Seek Slider
    Slider(
      value = effectiveFraction,
      onValueChange = { fraction ->
        isUserDragging = true
        dragPositionFraction = fraction
      },
      onValueChangeFinished = {
        val seekTargetMs = (dragPositionFraction * duration).toLong()
        onSeek(seekTargetMs)
        isUserDragging = false
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(18.dp)
        .testTag("track_progress_slider"),
      colors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color.White.copy(alpha = 0.18f)
      )
    )

    // Timestamp Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 2.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      val displayPos = if (isUserDragging) (dragPositionFraction * duration).toLong() else currentPos
      Text(
        text = trackInfo?.formatTime(displayPos) ?: "02:54",
        color = TextMuted,
        fontSize = 11.sp
      )
      Text(
        text = trackInfo?.formatTime(duration) ?: "03:56",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

/**
 * Navigation Expanded Card (Screenshot 6)
 */
@Composable
fun ExpandedNavigationView(
  navigation: NavigationState,
  onDismiss: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.weight(1f)
    ) {
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
          .background(Color(0xFF007AFF)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = null,
          tint = Color.White,
          modifier = Modifier.size(28.dp)
        )
      }

      Column {
        Text(
          text = navigation.distanceText,
          color = TextSecondary,
          fontSize = 12.sp
        )
        Text(
          text = "${navigation.maneuver} onto ${navigation.roadName}",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.padding(top = 4.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(Color(0xFFFF9500))
          )
          Text(navigation.etaText, color = TextMuted, fontSize = 11.sp)
        }
      }
    }

    IconButton(
      onClick = onDismiss,
      modifier = Modifier
        .size(36.dp)
        .background(Color.White.copy(alpha = 0.1f), CircleShape)
    ) {
      Icon(Icons.Default.Stop, contentDescription = "End Route", tint = Color(0xFFFF453A))
    }
  }
}

/**
 * Voice / Screen Recording Expanded Card
 */
@Composable
fun ExpandedRecordingView(
  recording: RecordingState,
  onStop: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "rec_pulse_exp")
  val recAlpha by infiniteTransition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(600),
      repeatMode = RepeatMode.Reverse
    ),
    label = "rec_alpha"
  )

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(Color(0xFFFF3B30).copy(alpha = recAlpha)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
      }

      Column {
        Text(
          text = recording.type,
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = recording.formatDuration(),
          color = Color(0xFFFF453A),
          fontSize = 18.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    Button(
      onClick = onStop,
      colors = ButtonDefaults.buttonColors(
        containerColor = Color(0xFFFF3B30),
        contentColor = Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text("إيقاف", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
  }
}

/**
 * AirDrop / Quick Share Expanded Card
 */
@Composable
fun ExpandedAirDropView(
  airDrop: AirDropState,
  onCancel: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0xFF007AFF).copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (airDrop.isComplete) Icons.Default.Check else Icons.Default.Share,
            contentDescription = null,
            tint = if (airDrop.isComplete) RealmeGreen else Color(0xFF0A84FF),
            modifier = Modifier.size(22.dp)
          )
        }

        Column {
          Text(
            text = airDrop.fileName,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${if (airDrop.isComplete) "From" else "Receiving from"} ${airDrop.senderName}",
            color = TextSecondary,
            fontSize = 12.sp
          )
        }
      }

      Text(
        text = if (airDrop.isComplete) "100%" else "${airDrop.progress}%",
        color = if (airDrop.isComplete) RealmeGreen else Color(0xFF0A84FF),
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Progress Bar
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp))
        .background(Color.White.copy(alpha = 0.12f))
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth(fraction = (airDrop.progress / 100f).coerceIn(0f, 1f))
          .fillMaxSize()
          .background(if (airDrop.isComplete) RealmeGreen else Color(0xFF0A84FF))
      )
    }
  }
}

/**
 * Timer Expanded View with Circular Progress Ring (Screenshot 2)
 */
@Composable
fun ExpandedTimerView(
  timerState: TimerState,
  onTogglePause: () -> Unit,
  onCancel: () -> Unit
) {
  val remaining = timerState.remainingSeconds
  val total = if (timerState.totalSeconds > 0) timerState.totalSeconds else remaining.coerceAtLeast(1)
  val progress = (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceAround
  ) {
    // Left: Circular Progress Ring with Countdown
    Box(
      modifier = Modifier.size(92.dp),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 5.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
        val arcSize = Size(diameter, diameter)

        // Background Circle
        drawArc(
          color = Color(0xFF2C2F38),
          startAngle = -90f,
          sweepAngle = 360f,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth)
        )

        // Progress Arc
        drawArc(
          color = Color(0xFFFF9F0A),
          startAngle = -90f,
          sweepAngle = 360f * progress,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = timerState.formatRemaining(),
          color = Color.White,
          fontSize = 16.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    // Right: Action Buttons
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        shape = CircleShape,
        color = Color(0xFFFF9F0A),
        modifier = Modifier
          .clickable(onClick = onTogglePause)
          .padding(horizontal = 24.dp, vertical = 8.dp)
      ) {
        Text(
          text = if (timerState.isRunning) "Pause" else "Resume",
          color = Color.Black,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Surface(
        shape = CircleShape,
        color = Color(0xFF2C2F38),
        modifier = Modifier
          .clickable(onClick = onCancel)
          .padding(horizontal = 24.dp, vertical = 8.dp)
      ) {
        Text("Cancel", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/**
 * Flashlight Expanded Card
 */
@Composable
fun ExpandedFlashlightView(
  flashlight: FlashlightState,
  onToggle: () -> Unit,
  onTurnOff: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF262D3D)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (flashlight.isOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
          contentDescription = null,
          tint = if (flashlight.isOn) Color.Black else Color.White,
          modifier = Modifier.size(26.dp)
        )
      }

      Column {
        Text(
          text = if (flashlight.isOn) "المصباح مفعّل" else "المصباح متوقف",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = if (flashlight.isOn) "Flashlight is ON" else "Flashlight is OFF",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    Button(
      onClick = onToggle,
      colors = ButtonDefaults.buttonColors(
        containerColor = if (flashlight.isOn) Color(0xFFFFD600) else Color(0xFF2E384D),
        contentColor = if (flashlight.isOn) Color.Black else Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text(
        text = if (flashlight.isOn) "إطفاء" else "تشغيل",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
      )
    }
  }
}

/**
 * Phone Call Expanded Card (Screenshot 4)
 */
@Composable
fun ExpandedCallView(
  callState: CallState,
  onAnswer: () -> Unit,
  onDecline: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Box(
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(Color(0xFF384358)),
      contentAlignment = Alignment.Center
    ) {
      Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = callState.callerNumber,
        color = TextSecondary,
        fontSize = 11.sp
      )
      MarqueeFadingText(
        text = callState.callerName,
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
      if (!callState.isIncoming) {
        Text(callState.formatDuration(), color = RealmeGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(Color(0xFFFF3B30))
          .clickable(onClick = onDecline),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(18.dp))
      }

      if (callState.isIncoming) {
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF34C759))
            .clickable(onClick = onAnswer),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Call, contentDescription = "Answer", tint = Color.White, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

/**
 * Battery Charging Expanded Card (Screenshot 3)
 */
@Composable
fun ExpandedBatteryView(batteryState: BatteryState) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(RealmeGreen.copy(alpha = 0.2f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          Icons.Default.BatteryChargingFull,
          contentDescription = null,
          tint = RealmeGreen,
          modifier = Modifier.size(24.dp)
        )
      }

      Column {
        Text("Charging", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text("Ultra Fast Dart Charge", color = TextSecondary, fontSize = 12.sp)
      }
    }

    Text(
      text = "${batteryState.percentage}%",
      color = RealmeGreen,
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold
    )
  }
}

/**
 * Sports Live Expanded Card (Screenshot 5)
 */
@Composable
fun ExpandedSportsView(
  sports: SportsState,
  onDismiss: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Text(
          text = "${sports.team2} ${sports.score2}",
          color = TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Text("•", color = TextMuted)
        Text(
          text = "${sports.team1} ${sports.score1}",
          color = TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Text(
        text = sports.status,
        color = Color(0xFFFF8A80),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    MarqueeFadingText(
      text = sports.headline,
      color = TextSecondary,
      fontSize = 12.sp,
      fontWeight = FontWeight.Normal
    )
  }
}

/**
 * Mini Waveform Bars
 */
@Composable
fun MiniWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  barCount: Int = 4,
  width: Dp = 18.dp,
  height: Dp = 14.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "mini_wave")

  val animValues = List(barCount) { index ->
    val duration = 400 + (index * 130)
    infiniteTransition.animateFloat(
      initialValue = 0.25f,
      targetValue = 1.0f,
      animationSpec = infiniteRepeatable(
        animation = tween(durationMillis = duration),
        repeatMode = RepeatMode.Reverse
      ),
      label = "bar_$index"
    )
  }

  Canvas(modifier = Modifier.size(width, height)) {
    val barWidth = size.width / (barCount * 1.8f)
    val gap = barWidth * 0.8f

    for (i in 0 until barCount) {
      val hFraction = if (isPlaying) animValues[i].value else 0.25f
      val barHeight = size.height * hFraction
      val x = i * (barWidth + gap)
      val y = (size.height - barHeight) / 2f

      drawRoundRect(
        color = color,
        topLeft = Offset(x, y),
        size = Size(barWidth, barHeight),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2)
      )
    }
  }
}
