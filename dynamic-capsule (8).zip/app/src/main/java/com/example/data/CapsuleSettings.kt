package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber

data class CapsuleSettings(
  val serviceEnabled: Boolean = true,
  val notchOffsetYDp: Int = 0, // Extra offset below status bar
  val capsuleWidthDp: Int = 220, // Medium size, easy to see and touch
  val capsuleHeightDp: Int = 46, // Medium height, comfortable touch target
  val accentColorIndex: Int = 0,
  val autoCollapseSeconds: Int = 0,
  val showWhenIdle: Boolean = false, // Hidden when idle so no window is visible without activity
  val hapticFeedback: Boolean = true,
  // Feature toggles
  val enableBatteryAlerts: Boolean = true,
  val enableCallAlerts: Boolean = true,
  val enableTimer: Boolean = true,
  val enableNetSpeed: Boolean = false,
  val enableNotifications: Boolean = true,
  val enableBluetoothAlerts: Boolean = true,
  val enableFlashlightAlert: Boolean = true,
  val enableSportsLive: Boolean = false
) {
  val accentColor: Color
    get() = when (accentColorIndex) {
      0 -> RealmeGreen
      1 -> CyberCyan
      2 -> ElectricPurple
      3 -> SunsetAmber
      4 -> Color(0xFFFFFFFF)
      else -> RealmeGreen
    }
}
