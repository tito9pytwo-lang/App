package com.example.island

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat

object CallManager {

  private const val TAG = "CallManager"

  private var answerPendingIntent: PendingIntent? = null
  private var declinePendingIntent: PendingIntent? = null

  fun setCallNotificationIntents(answer: PendingIntent?, decline: PendingIntent?) {
    answerPendingIntent = answer
    declinePendingIntent = decline
  }

  fun clearNotificationIntents() {
    answerPendingIntent = null
    declinePendingIntent = null
  }

  fun answerCall(context: Context): Boolean {
    // 1. Try Notification PendingIntent first (works for WhatsApp, Telegram, Meet, Dialer heads-up)
    try {
      if (answerPendingIntent != null) {
        answerPendingIntent?.send()
        return true
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error executing answer PendingIntent", e)
    }

    // 2. Try TelecomManager.acceptRingingCall (API 26+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      try {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
          PackageManager.PERMISSION_GRANTED
        ) {
          telecomManager?.acceptRingingCall()
          return true
        }
      } catch (e: Exception) {
        Log.e(TAG, "TelecomManager.acceptRingingCall error", e)
      }
    }
    return false
  }

  fun declineCall(context: Context): Boolean {
    // 1. Try Notification PendingIntent first
    try {
      if (declinePendingIntent != null) {
        declinePendingIntent?.send()
        return true
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error executing decline PendingIntent", e)
    }

    // 2. Try TelecomManager.endCall (API 28+)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      try {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
          PackageManager.PERMISSION_GRANTED
        ) {
          telecomManager?.endCall()
          return true
        }
      } catch (e: Exception) {
        Log.e(TAG, "TelecomManager.endCall error", e)
      }
    }
    return false
  }
}
