package com.example.island

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import com.example.media.MediaTrackInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

object IslandStateManager {

  private const val TAG = "IslandStateManager"
  private val scope = CoroutineScope(Dispatchers.Main + Job())

  // States
  private val _batteryState = MutableStateFlow(BatteryState())
  val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

  private val _callState = MutableStateFlow(CallState())
  val callState: StateFlow<CallState> = _callState.asStateFlow()

  private val _timerState = MutableStateFlow(TimerState())
  val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

  private val _netSpeedState = MutableStateFlow(NetSpeedState())
  val netSpeedState: StateFlow<NetSpeedState> = _netSpeedState.asStateFlow()

  private val _activeNotification = MutableStateFlow<NotificationEvent?>(null)
  val activeNotification: StateFlow<NotificationEvent?> = _activeNotification.asStateFlow()

  private val _bluetoothState = MutableStateFlow(BluetoothState())
  val bluetoothState: StateFlow<BluetoothState> = _bluetoothState.asStateFlow()

  private val _flashlightState = MutableStateFlow(FlashlightState())
  val flashlightState: StateFlow<FlashlightState> = _flashlightState.asStateFlow()

  private val _ringerState = MutableStateFlow(RingerState())
  val ringerState: StateFlow<RingerState> = _ringerState.asStateFlow()

  private val _recordingState = MutableStateFlow(RecordingState())
  val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

  // Active overlay card in expanded mode
  private val _activeCard = MutableStateFlow(IslandActiveCard.MUSIC)
  val activeCard: StateFlow<IslandActiveCard> = _activeCard.asStateFlow()

  private var timerJob: Job? = null
  private var callTickerJob: Job? = null
  private var netSpeedJob: Job? = null
  private var notificationExpireJob: Job? = null
  private var batteryExpireJob: Job? = null
  private var recordingJob: Job? = null
  private var ringerExpireJob: Job? = null

  private var lastRxBytes: Long = 0L
  private var lastSpeedCheckTime: Long = 0L

  private var cameraManager: CameraManager? = null
  private var torchCallback: CameraManager.TorchCallback? = null
  private var flashCameraId: String? = null
  private var isInitialized = false

  fun initialize(context: Context) {
    if (isInitialized) return
    isInitialized = true

    registerBatteryReceiver(context)
    initFlashlight(context)
    registerTelephony(context)
    registerRingerReceiver(context)
  }

  fun hasAnyActiveActivity(trackInfo: MediaTrackInfo?): Boolean {
    val isMusicActive = trackInfo != null && trackInfo.isPlaying
    val isFlashlightActive = _flashlightState.value.isOn
    val isCallActive = _callState.value.isActive
    val isTimerActive = _timerState.value.isRunning && _timerState.value.remainingSeconds > 0
    val isChargingActive = _batteryState.value.isCharging && (System.currentTimeMillis() - _batteryState.value.lastEventTime < 7000L)
    val isNotifActive = _activeNotification.value != null && (System.currentTimeMillis() - (_activeNotification.value?.timestamp ?: 0L) < 5000L)
    val isBluetoothActive = _bluetoothState.value.isConnected && (System.currentTimeMillis() - _bluetoothState.value.timestamp < 5000L)
    val isRingerActive = _ringerState.value.isActive && (System.currentTimeMillis() - _ringerState.value.timestamp < 3500L)
    val isRecordingActive = _recordingState.value.isRecording

    return isMusicActive || isFlashlightActive || isCallActive || isTimerActive ||
      isChargingActive || isNotifActive || isBluetoothActive ||
      isRingerActive || isRecordingActive
  }

  private fun registerBatteryReceiver(context: Context) {
    val filter = IntentFilter().apply {
      addAction(Intent.ACTION_POWER_CONNECTED)
      addAction(Intent.ACTION_POWER_DISCONNECTED)
      addAction(Intent.ACTION_BATTERY_CHANGED)
    }

    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
          Intent.ACTION_POWER_CONNECTED -> {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            showBatteryCharging(pct)
          }
          Intent.ACTION_POWER_DISCONNECTED -> {
            _batteryState.value = _batteryState.value.copy(
              isCharging = false,
              lastEventTime = System.currentTimeMillis()
            )
          }
          Intent.ACTION_BATTERY_CHANGED -> {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
              status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85
            val isLow = pct <= 20 && !isCharging

            _batteryState.value = _batteryState.value.copy(
              isCharging = isCharging,
              percentage = pct,
              isLow = isLow
            )
          }
        }
      }
    }

    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering battery receiver", e)
    }
  }

  fun showBatteryCharging(pct: Int) {
    _batteryState.value = BatteryState(
      isCharging = true,
      percentage = pct,
      isLow = false,
      lastEventTime = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BATTERY

    batteryExpireJob?.cancel()
    batteryExpireJob = scope.launch {
      delay(6000)
      if (_activeCard.value == IslandActiveCard.BATTERY) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Timer controls
  fun startTimer(seconds: Int, title: String = "Timer") {
    timerJob?.cancel()
    _timerState.value = TimerState(
      isRunning = true,
      remainingSeconds = seconds,
      totalSeconds = seconds,
      title = title
    )
    _activeCard.value = IslandActiveCard.TIMER

    timerJob = scope.launch {
      while (isActive && _timerState.value.remainingSeconds > 0) {
        delay(1000)
        val current = _timerState.value
        if (!current.isRunning) break
        val remaining = current.remainingSeconds - 1
        _timerState.value = current.copy(remainingSeconds = remaining)
        if (remaining <= 0) {
          _timerState.value = current.copy(isRunning = false, remainingSeconds = 0)
          break
        }
      }
    }
  }

  fun toggleTimerPause() {
    val cur = _timerState.value
    if (cur.isRunning) {
      _timerState.value = cur.copy(isRunning = false)
    } else if (cur.remainingSeconds > 0) {
      startTimer(cur.remainingSeconds, cur.title)
    }
  }

  fun cancelTimer() {
    timerJob?.cancel()
    _timerState.value = TimerState()
    if (_activeCard.value == IslandActiveCard.TIMER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  // Call controls & actual answering / declining
  fun startCall(caller: String = "Tania Castillo", number: String = "Mobile", isIncoming: Boolean = true) {
    callTickerJob?.cancel()
    _callState.value = CallState(
      isActive = true,
      callerName = caller,
      callerNumber = number,
      durationSeconds = 0,
      isIncoming = isIncoming
    )
    _activeCard.value = IslandActiveCard.CALL

    if (!isIncoming) {
      startCallTicker()
    }
  }

  fun answerCall(context: Context) {
    val answered = CallManager.answerCall(context)
    val cur = _callState.value
    _callState.value = cur.copy(isIncoming = false)
    startCallTicker()
  }

  fun declineCall(context: Context) {
    CallManager.declineCall(context)
    endCall()
  }

  private fun startCallTicker() {
    callTickerJob?.cancel()
    callTickerJob = scope.launch {
      while (isActive && _callState.value.isActive) {
        delay(1000)
        val cur = _callState.value
        _callState.value = cur.copy(durationSeconds = cur.durationSeconds + 1)
      }
    }
  }

  fun endCall() {
    callTickerJob?.cancel()
    CallManager.clearNotificationIntents()
    _callState.value = CallState(isActive = false)
    if (_activeCard.value == IslandActiveCard.CALL) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun handleTelephonyState(state: Int) {
    Log.d(TAG, "Telephony state changed: $state")
    when (state) {
      TelephonyManager.CALL_STATE_IDLE -> {
        // Immediate termination on IDLE without any lingering states or delays
        endCall()
      }
      TelephonyManager.CALL_STATE_OFFHOOK -> {
        // Active connected call
        if (_callState.value.isActive && _callState.value.isIncoming) {
          _callState.value = _callState.value.copy(isIncoming = false)
          startCallTicker()
        }
      }
      TelephonyManager.CALL_STATE_RINGING -> {
        if (!_callState.value.isActive) {
          startCall(caller = "Incoming Call", number = "Mobile", isIncoming = true)
        }
      }
    }
  }

  private fun registerTelephony(context: Context) {
    try {
      val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
      if (tm != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
          tm.registerTelephonyCallback(
            context.mainExecutor,
            object : TelephonyCallback(), TelephonyCallback.CallStateListener {
              override fun onCallStateChanged(state: Int) {
                handleTelephonyState(state)
              }
            }
          )
        } else {
          @Suppress("DEPRECATION")
          tm.listen(
            object : PhoneStateListener() {
              @Deprecated("Deprecated in Java")
              override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleTelephonyState(state)
              }
            },
            PhoneStateListener.LISTEN_CALL_STATE
          )
        }
      }
    } catch (e: SecurityException) {
      Log.w(TAG, "TelephonyManager permission not granted, listening via broadcast", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering TelephonyManager callback", e)
    }

    try {
      val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          val stateStr = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
          when (stateStr) {
            TelephonyManager.EXTRA_STATE_IDLE -> handleTelephonyState(TelephonyManager.CALL_STATE_IDLE)
            TelephonyManager.EXTRA_STATE_OFFHOOK -> handleTelephonyState(TelephonyManager.CALL_STATE_OFFHOOK)
            TelephonyManager.EXTRA_STATE_RINGING -> {
              val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Mobile"
              startCall(caller = "Incoming Call", number = incomingNumber, isIncoming = true)
            }
          }
        }
      }
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.w(TAG, "Error registering phone state broadcast receiver", e)
    }
  }

  // Notification Event
  fun postNotificationEvent(appName: String, title: String, text: String, pkg: String = "") {
    val event = NotificationEvent(
      id = System.currentTimeMillis(),
      packageName = pkg,
      appName = appName,
      title = title,
      text = text,
      timestamp = System.currentTimeMillis()
    )
    _activeNotification.value = event
    _activeCard.value = IslandActiveCard.NOTIFICATION

    notificationExpireJob?.cancel()
    notificationExpireJob = scope.launch {
      delay(4500)
      if (_activeNotification.value?.id == event.id) {
        _activeNotification.value = null
        if (_activeCard.value == IslandActiveCard.NOTIFICATION) {
          _activeCard.value = IslandActiveCard.MUSIC
        }
      }
    }
  }

  // Bluetooth Event
  fun showBluetoothConnected(deviceName: String = "AirPods Pro", batteryPct: Int = 90) {
    _bluetoothState.value = BluetoothState(
      isConnected = true,
      deviceName = deviceName,
      batteryPct = batteryPct,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.BLUETOOTH

    scope.launch {
      delay(5500)
      if (_activeCard.value == IslandActiveCard.BLUETOOTH) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  // Real Camera Torch / Flashlight implementation
  private fun initFlashlight(context: Context) {
    try {
      val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
      cameraManager = cm
      if (cm != null) {
        flashCameraId = findFlashCameraId(cm)
        torchCallback = object : CameraManager.TorchCallback() {
          override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            super.onTorchModeChanged(cameraId, enabled)
            if (cameraId == flashCameraId || flashCameraId == null) {
              flashCameraId = cameraId
              _flashlightState.value = FlashlightState(isOn = enabled)
              if (enabled) {
                _activeCard.value = IslandActiveCard.FLASHLIGHT
              } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
                _activeCard.value = IslandActiveCard.MUSIC
              }
            }
          }
        }
        cm.registerTorchCallback(torchCallback!!, null)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing camera torch callback", e)
    }
  }

  private fun findFlashCameraId(cm: CameraManager): String? {
    try {
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val facing = chars.get(CameraCharacteristics.LENS_FACING)
        if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
          return id
        }
      }
      for (id in cm.cameraIdList) {
        val chars = cm.getCameraCharacteristics(id)
        if (chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
          return id
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error finding flash camera id", e)
    }
    return cm.cameraIdList.firstOrNull()
  }

  fun toggleFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    val targetMode = !_flashlightState.value.isOn
    try {
      cm?.setTorchMode(id, targetMode)
      _flashlightState.value = FlashlightState(isOn = targetMode)
      if (targetMode) {
        _activeCard.value = IslandActiveCard.FLASHLIGHT
      } else if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error toggling torch on camera id $id", e)
      _flashlightState.value = FlashlightState(isOn = targetMode)
    }
  }

  fun turnOffFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    try {
      cm?.setTorchMode(id, false)
      _flashlightState.value = FlashlightState(isOn = false)
      if (_activeCard.value == IslandActiveCard.FLASHLIGHT) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error turning off torch", e)
      _flashlightState.value = FlashlightState(isOn = false)
    }
  }

  fun turnOnFlashlight(context: Context) {
    val cm = cameraManager ?: (context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager)
    val id = flashCameraId ?: (if (cm != null) findFlashCameraId(cm) else "0") ?: "0"
    try {
      cm?.setTorchMode(id, true)
      _flashlightState.value = FlashlightState(isOn = true)
      _activeCard.value = IslandActiveCard.FLASHLIGHT
    } catch (e: Exception) {
      Log.e(TAG, "Error turning on torch", e)
      _flashlightState.value = FlashlightState(isOn = true)
    }
  }



  // Network Speed Ticker
  fun setNetSpeedEnabled(enabled: Boolean) {
    netSpeedJob?.cancel()
    if (!enabled) {
      _netSpeedState.value = _netSpeedState.value.copy(isEnabled = false)
      return
    }

    _netSpeedState.value = _netSpeedState.value.copy(isEnabled = true)
    lastRxBytes = TrafficStats.getTotalRxBytes()
    lastSpeedCheckTime = SystemClock.elapsedRealtime()

    netSpeedJob = scope.launch {
      while (isActive) {
        delay(1500)
        val now = SystemClock.elapsedRealtime()
        val currentRx = TrafficStats.getTotalRxBytes()
        val elapsedSec = (now - lastSpeedCheckTime) / 1000f

        if (elapsedSec > 0 && currentRx >= lastRxBytes && lastRxBytes > 0) {
          val bytesPerSec = ((currentRx - lastRxBytes) / elapsedSec).toLong()
          val speedText = formatSpeed(bytesPerSec)
          _netSpeedState.value = _netSpeedState.value.copy(downloadSpeedText = speedText)
        }

        lastRxBytes = currentRx
        lastSpeedCheckTime = now
      }
    }
  }

  private fun formatSpeed(bytesPerSec: Long): String {
    return when {
      bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024f * 1024f))
      bytesPerSec >= 1024 -> String.format(Locale.US, "%d KB/s", bytesPerSec / 1024)
      else -> String.format(Locale.US, "%d B/s", bytesPerSec)
    }
  }

  private fun registerRingerReceiver(context: Context) {
    val filter = IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION)
    val receiver = object : BroadcastReceiver() {
      override fun onReceive(ctx: Context?, intent: Intent?) {
        if (intent?.action == AudioManager.RINGER_MODE_CHANGED_ACTION) {
          val audioManager = ctx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
          val mode = audioManager?.ringerMode ?: intent.getIntExtra(AudioManager.EXTRA_RINGER_MODE, AudioManager.RINGER_MODE_NORMAL)
          val isSilent = mode == AudioManager.RINGER_MODE_SILENT || mode == AudioManager.RINGER_MODE_VIBRATE
          showRingerMode(isSilent)
        }
      }
    }
    try {
      context.registerReceiver(receiver, filter)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering ringer receiver", e)
    }
  }

  // Ringer Alert (iOS Dynamic Island Signature Feature)
  fun showRingerMode(isSilent: Boolean) {
    _ringerState.value = RingerState(
      isActive = true,
      isSilent = isSilent,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.RINGER

    ringerExpireJob?.cancel()
    ringerExpireJob = scope.launch {
      delay(3500)
      _ringerState.value = _ringerState.value.copy(isActive = false)
      if (_activeCard.value == IslandActiveCard.RINGER) {
        _activeCard.value = IslandActiveCard.MUSIC
      }
    }
  }

  fun dismissRinger() {
    _ringerState.value = _ringerState.value.copy(isActive = false)
    if (_activeCard.value == IslandActiveCard.RINGER) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }



  // Voice / Audio Recording
  fun startRecording(type: String = "Voice Memo") {
    recordingJob?.cancel()
    _recordingState.value = RecordingState(
      isRecording = true,
      durationSeconds = 0,
      type = type,
      timestamp = System.currentTimeMillis()
    )
    _activeCard.value = IslandActiveCard.RECORDING

    recordingJob = scope.launch {
      while (isActive && _recordingState.value.isRecording) {
        delay(1000)
        _recordingState.value = _recordingState.value.copy(
          durationSeconds = _recordingState.value.durationSeconds + 1
        )
      }
    }
  }

  fun stopRecording() {
    recordingJob?.cancel()
    _recordingState.value = _recordingState.value.copy(isRecording = false)
    if (_activeCard.value == IslandActiveCard.RECORDING) {
      _activeCard.value = IslandActiveCard.MUSIC
    }
  }

  fun selectCard(card: IslandActiveCard) {
    _activeCard.value = card
  }
}
