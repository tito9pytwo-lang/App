package com.example.media

import android.content.Context
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object MediaSessionHolder {
  private const val TAG = "MediaSessionHolder"

  private val _currentTrack = MutableStateFlow<MediaTrackInfo?>(null)
  val currentTrack: StateFlow<MediaTrackInfo?> = _currentTrack.asStateFlow()

  private val _isListenerConnected = MutableStateFlow(false)
  val isListenerConnected: StateFlow<Boolean> = _isListenerConnected.asStateFlow()

  private var activeController: MediaController? = null
  private var isDemoMode: Boolean = false

  private val scope = CoroutineScope(Dispatchers.Main + Job())
  private var progressTickerJob: Job? = null

  fun setListenerConnected(connected: Boolean) {
    _isListenerConnected.value = connected
  }

  fun updateActiveController(controller: MediaController?) {
    if (isDemoMode && controller != null) {
      isDemoMode = false
    }
    activeController = controller
    if (controller == null && !isDemoMode) {
      _currentTrack.value = null
      stopTicker()
    }
  }

  fun updateTrackInfo(trackInfo: MediaTrackInfo?) {
    if (isDemoMode && trackInfo != null) {
      isDemoMode = false
    }
    _currentTrack.value = trackInfo
    if (trackInfo?.isPlaying == true) {
      startTicker()
    } else {
      stopTicker()
    }
  }

  private fun startTicker() {
    progressTickerJob?.cancel()
    progressTickerJob = scope.launch {
      while (isActive) {
        delay(1000)
        val current = _currentTrack.value ?: break
        if (!current.isPlaying) break
        val now = SystemClock.elapsedRealtime()
        val estimated = current.getEstimatedPositionMs()
        _currentTrack.value = current.copy(
          currentPositionMs = estimated,
          lastUpdateTime = now
        )
      }
    }
  }

  private fun stopTicker() {
    progressTickerJob?.cancel()
    progressTickerJob = null
  }

  fun canSeek(): Boolean {
    if (isDemoMode) return true
    val actions = activeController?.playbackState?.actions ?: 0L
    return (actions and PlaybackState.ACTION_SEEK_TO) != 0L
  }

  fun canSkipNext(): Boolean {
    if (isDemoMode) return true
    val actions = activeController?.playbackState?.actions ?: 0L
    return (actions and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L
  }

  fun canSkipPrevious(): Boolean {
    if (isDemoMode) return true
    val actions = activeController?.playbackState?.actions ?: 0L
    return (actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L
  }

  fun play() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(isPlaying = true, lastUpdateTime = SystemClock.elapsedRealtime())
      startTicker()
      return
    }
    try {
      activeController?.transportControls?.play()
    } catch (e: Exception) {
      Log.e(TAG, "play() error", e)
    }
  }

  fun pause() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        isPlaying = false,
        currentPositionMs = cur.getEstimatedPositionMs(),
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      stopTicker()
      return
    }
    try {
      activeController?.transportControls?.pause()
    } catch (e: Exception) {
      Log.e(TAG, "pause() error", e)
    }
  }

  fun togglePlayPause() {
    val cur = _currentTrack.value
    if (cur?.isPlaying == true) {
      pause()
    } else {
      play()
    }
  }

  fun skipToNext() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        title = "Neon Skyline",
        artist = "Realme Sound Lab",
        currentPositionMs = 0L,
        durationMs = 210000L,
        isPlaying = true,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    val controller = activeController ?: return
    val actions = controller.playbackState?.actions ?: 0L
    if ((actions and PlaybackState.ACTION_SKIP_TO_NEXT) == 0L) {
      Log.w(TAG, "skipToNext not permitted by active media player (e.g. Spotify Free restriction)")
      return
    }
    try {
      controller.transportControls?.skipToNext()
    } catch (e: Exception) {
      Log.e(TAG, "skipToNext() error", e)
    }
  }

  fun skipToPrevious() {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        title = "Pulse Horizon",
        artist = "Realme Sound Lab",
        currentPositionMs = 0L,
        durationMs = 195000L,
        isPlaying = true,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    val controller = activeController ?: return
    val actions = controller.playbackState?.actions ?: 0L
    if ((actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) == 0L) {
      Log.w(TAG, "skipToPrevious not permitted by active media player")
      return
    }
    try {
      controller.transportControls?.skipToPrevious()
    } catch (e: Exception) {
      Log.e(TAG, "skipToPrevious() error", e)
    }
  }

  fun seekTo(positionMs: Long) {
    if (isDemoMode) {
      val cur = _currentTrack.value ?: return
      _currentTrack.value = cur.copy(
        currentPositionMs = positionMs,
        lastUpdateTime = SystemClock.elapsedRealtime()
      )
      return
    }
    val controller = activeController ?: return
    val actions = controller.playbackState?.actions ?: 0L
    if ((actions and PlaybackState.ACTION_SEEK_TO) == 0L) {
      Log.w(TAG, "seekTo not permitted by active media player (e.g. Spotify Free does not allow seeking)")
      return
    }
    try {
      controller.transportControls?.seekTo(positionMs)
      val cur = _currentTrack.value
      if (cur != null) {
        _currentTrack.value = cur.copy(
          currentPositionMs = positionMs,
          lastUpdateTime = SystemClock.elapsedRealtime()
        )
      }
    } catch (e: Exception) {
      Log.e(TAG, "seekTo() error", e)
    }
  }

  fun startDemoTrack() {
    isDemoMode = true
    _currentTrack.value = MediaTrackInfo(
      title = "Realme Cyber Pulse",
      artist = "Dynamic Sound Lab",
      album = "Mini Capsule Beats",
      durationMs = 225000L, // 3m 45s
      currentPositionMs = 45000L, // 0m 45s
      isPlaying = true,
      packageName = "com.spotify.music",
      appName = "Spotify Demo",
      playbackSpeed = 1.0f,
      lastUpdateTime = SystemClock.elapsedRealtime()
    )
    startTicker()
  }

  fun startLongTitleDemoTrack() {
    isDemoMode = true
    _currentTrack.value = MediaTrackInfo(
      title = "Living Life, In The Night (Official Extended Mix) - Real-time Marquee Scrolling",
      artist = "Cheriimoya, Sierra Kidd & Dynamic Sound International Studio",
      album = "Night Vibes 2026",
      durationMs = 284000L,
      currentPositionMs = 92000L,
      isPlaying = true,
      packageName = "com.spotify.music",
      appName = "Spotify",
      playbackSpeed = 1.0f,
      lastUpdateTime = SystemClock.elapsedRealtime()
    )
    startTicker()
  }

  fun stopDemoTrack() {
    if (isDemoMode) {
      isDemoMode = false
      _currentTrack.value = null
      stopTicker()
    }
  }
}
