package com.example.media

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.CapsuleSettingsManager
import com.example.island.CallManager
import com.example.island.IslandStateManager
import com.example.service.FloatingCapsuleService

class MusicNotificationListenerService : NotificationListenerService() {

  private var mediaSessionManager: MediaSessionManager? = null
  private var currentController: MediaController? = null
  private var sessionComponent: ComponentName? = null

  private val sessionCallback = object : MediaController.Callback() {
    override fun onPlaybackStateChanged(state: PlaybackState?) {
      super.onPlaybackStateChanged(state)
      syncCurrentSession()
    }

    override fun onMetadataChanged(metadata: MediaMetadata?) {
      super.onMetadataChanged(metadata)
      syncCurrentSession()
    }

    override fun onSessionDestroyed() {
      super.onSessionDestroyed()
      currentController = null
      MediaSessionHolder.updateActiveController(null)
      refreshActiveSessions()
    }
  }

  private val sessionsChangedListener =
    MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
      updateActiveControllerFromList(controllers)
    }

  override fun onCreate() {
    super.onCreate()
    sessionComponent = ComponentName(this, MusicNotificationListenerService::class.java)
    mediaSessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    IslandStateManager.initialize(this)
  }

  override fun onListenerConnected() {
    super.onListenerConnected()
    MediaSessionHolder.setListenerConnected(true)
    try {
      sessionComponent?.let { comp ->
        mediaSessionManager?.addOnActiveSessionsChangedListener(sessionsChangedListener, comp)
        refreshActiveSessions()
      }
    } catch (e: SecurityException) {
      Log.e(TAG, "SecurityException registering session listener", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error registering session listener", e)
    }
  }

  override fun onListenerDisconnected() {
    super.onListenerDisconnected()
    MediaSessionHolder.setListenerConnected(false)
    cleanupController()
    try {
      mediaSessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
    } catch (e: Exception) {
      Log.e(TAG, "Error removing session listener", e)
    }
  }

  override fun onNotificationPosted(sbn: StatusBarNotification?) {
    super.onNotificationPosted(sbn)
    if (sbn == null) return

    val pkg = sbn.packageName ?: ""
    if (pkg == packageName) return

    val notif = sbn.notification ?: return
    val extras = notif.extras ?: return

    refreshActiveSessions()

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    // Real Call handling
    val title = extras.getString(Notification.EXTRA_TITLE)
      ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
      ?: ""
    val text = extras.getString(Notification.EXTRA_TEXT)
      ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
      ?: ""

    val lowerTitle = title.lowercase()
    val lowerText = text.lowercase()

    // Explicit check: If notification is for a missed, declined, or ended call, terminate call state immediately
    val isMissedOrEndedCall = notif.category == Notification.CATEGORY_MISSED_CALL ||
      notif.category == "missed_call" ||
      lowerTitle.contains("missed") ||
      lowerTitle.contains("لم يرد عليها") ||
      lowerTitle.contains("مكالمة لم يرد") ||
      lowerTitle.contains("ended") ||
      lowerTitle.contains("انتهت") ||
      lowerTitle.contains("declined") ||
      lowerTitle.contains("مرفوضة") ||
      lowerTitle.contains("cancelled") ||
      lowerTitle.contains("ملغاة") ||
      lowerText.contains("missed call") ||
      lowerText.contains("call ended")

    if (isMissedOrEndedCall) {
      IslandStateManager.endCall()
      return
    }

    var ansIntent: PendingIntent? = null
    var decIntent: PendingIntent? = null
    for (action in notif.actions ?: emptyArray()) {
      val t = action.title?.toString()?.lowercase() ?: ""
      if (t.contains("answer") || t.contains("رد") || t.contains("accept") || t.contains("اجابة")) {
        ansIntent = action.actionIntent
      } else if (t.contains("decline") || t.contains("reject") || t.contains("رفض") || t.contains("hang") || t.contains("انهاء") || t.contains("dismiss") || t.contains("end")) {
        decIntent = action.actionIntent
      }
    }

    val isCallCategory = notif.category == Notification.CATEGORY_CALL
    val isKnownPhoneApp = pkg.contains("dialer") ||
      pkg.contains("telecom") ||
      pkg.contains("incall") ||
      pkg.contains("phone")
    val hasCallActions = ansIntent != null || decIntent != null
    val isOngoingEvent = (notif.flags and Notification.FLAG_ONGOING_EVENT) != 0

    // Only treat as call if it is CATEGORY_CALL with call actions/ongoing, or known phone app with explicit call actions
    val isRealActiveCall = (isCallCategory && (hasCallActions || isOngoingEvent)) || (isKnownPhoneApp && hasCallActions)

    if (settings.enableCallAlerts && isRealActiveCall) {
      CallManager.setCallNotificationIntents(ansIntent, decIntent)

      val callerName = if (title.isNotBlank()) title else "Incoming Call"
      val callerNumber = if (text.isNotBlank()) text else "Mobile"
      val isRinging = ansIntent != null

      IslandStateManager.startCall(caller = callerName, number = callerNumber, isIncoming = isRinging)
      return
    }

    // App message notifications
    if (settings.enableNotifications && notif.category != Notification.CATEGORY_SERVICE) {
      if (title.isNotBlank() && text.isNotBlank()) {
        val appName = try {
          val appInfo = packageManager.getApplicationInfo(pkg, 0)
          packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
          pkg
        }
        IslandStateManager.postNotificationEvent(appName, title, text, pkg)
      }
    }
  }

  override fun onNotificationRemoved(sbn: StatusBarNotification?) {
    super.onNotificationRemoved(sbn)
    if (sbn != null) {
      val notif = sbn.notification
      val pkg = sbn.packageName ?: ""
      val isCallCategory = notif?.category == Notification.CATEGORY_CALL ||
        pkg.contains("dialer") ||
        pkg.contains("telecom") ||
        pkg.contains("incall") ||
        pkg.contains("phone")
      if (isCallCategory) {
        IslandStateManager.endCall()
      }

      val activePkg = currentController?.packageName ?: MediaSessionHolder.currentTrack.value?.packageName
      if (pkg.isNotBlank() && pkg == activePkg) {
        cleanupController()
        MediaSessionHolder.updateActiveController(null)
        MediaSessionHolder.updateTrackInfo(null)
      }
    }
    refreshActiveSessions()
  }

  private fun refreshActiveSessions() {
    try {
      sessionComponent?.let { comp ->
        val controllers = mediaSessionManager?.getActiveSessions(comp)
        updateActiveControllerFromList(controllers)
      }
    } catch (e: SecurityException) {
      Log.e(TAG, "Permission denied fetching active sessions", e)
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching active sessions", e)
    }
  }

  private fun updateActiveControllerFromList(controllers: List<MediaController>?) {
    if (controllers.isNullOrEmpty()) {
      cleanupController()
      MediaSessionHolder.updateActiveController(null)
      MediaSessionHolder.updateTrackInfo(null)
      return
    }

    val playingController = controllers.firstOrNull {
      val s = it.playbackState?.state
      s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    if (playingController != null) {
      if (playingController != currentController) {
        cleanupController()
        currentController = playingController
        try {
          currentController?.registerCallback(sessionCallback)
        } catch (e: Exception) {
          Log.e(TAG, "Error registering callback", e)
        }
        MediaSessionHolder.updateActiveController(playingController)
      }
      syncCurrentSession()
    } else {
      val curState = currentController?.playbackState?.state
      if (curState == PlaybackState.STATE_PLAYING || curState == PlaybackState.STATE_BUFFERING) {
        syncCurrentSession()
      } else {
        cleanupController()
        MediaSessionHolder.updateActiveController(null)
        MediaSessionHolder.updateTrackInfo(null)
      }
    }
  }

  private fun syncCurrentSession() {
    val controller = currentController ?: return
    val state = controller.playbackState
    val metadata = controller.metadata

    val isPlaying = state?.state == PlaybackState.STATE_PLAYING
    if (!isPlaying && (state == null || state.state == PlaybackState.STATE_NONE || state.state == PlaybackState.STATE_STOPPED || state.state == PlaybackState.STATE_ERROR)) {
      cleanupController()
      MediaSessionHolder.updateActiveController(null)
      MediaSessionHolder.updateTrackInfo(null)
      return
    }

    val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
      ?: "Unknown Track"

    val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
      ?: metadata?.getString(MediaMetadata.METADATA_KEY_AUTHOR)
      ?: "Unknown Artist"

    val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
    val durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    val albumArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
      ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    val currentPosition = state?.position ?: 0L
    val speed = if (state != null && state.playbackSpeed > 0f) state.playbackSpeed else 1.0f

    val actions = state?.actions ?: 0L
    val canSeek = (actions and PlaybackState.ACTION_SEEK_TO) != 0L
    val canSkipNext = (actions and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L
    val canSkipPrev = (actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L

    val pkg = controller.packageName ?: ""
    val appName = try {
      val appInfo = packageManager.getApplicationInfo(pkg, 0)
      packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: Exception) {
      pkg
    }

    val now = SystemClock.elapsedRealtime()
    val rawUpdateTime = state?.lastPositionUpdateTime ?: 0L
    val validUpdateTime = if (rawUpdateTime in (now - 60_000L)..now) {
      rawUpdateTime
    } else {
      now
    }

    val trackInfo = MediaTrackInfo(
      title = title,
      artist = artist,
      album = album,
      durationMs = durationMs,
      currentPositionMs = currentPosition,
      isPlaying = isPlaying,
      albumArt = albumArt,
      packageName = pkg,
      appName = appName,
      playbackSpeed = speed,
      lastUpdateTime = validUpdateTime,
      canSeek = canSeek,
      canSkipNext = canSkipNext,
      canSkipPrevious = canSkipPrev
    )

    MediaSessionHolder.updateTrackInfo(trackInfo)

    val settings = CapsuleSettingsManager.getInstance(this).settings.value
    if (settings.serviceEnabled && isPlaying) {
      startCapsuleService()
    }
  }

  private fun startCapsuleService() {
    try {
      val intent = Intent(this, FloatingCapsuleService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(intent)
      } else {
        startService(intent)
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to start FloatingCapsuleService", e)
    }
  }

  private fun cleanupController() {
    currentController?.unregisterCallback(sessionCallback)
    currentController = null
  }

  override fun onDestroy() {
    super.onDestroy()
    cleanupController()
  }

  companion object {
    private const val TAG = "MusicNotifListener"
  }
}
