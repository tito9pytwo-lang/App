package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.island.CallState
import com.example.island.IslandStateManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class FloatingCapsuleService : Service() {

  private var windowManager: WindowManager? = null
  private var floatingView: ComposeView? = null
  private var lifecycleOwner: FloatingLifecycleOwner? = null
  private var windowParams: WindowManager.LayoutParams? = null

  private var isViewAttached = false
  private val _capsuleMode = MutableStateFlow(CapsuleMode.MINI)
  val capsuleMode: StateFlow<CapsuleMode> = _capsuleMode.asStateFlow()

  private val _isDismissedToNotification = MutableStateFlow(false)
  val isDismissedToNotification: StateFlow<Boolean> = _isDismissedToNotification.asStateFlow()

  private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    startForegroundServiceWithNotification()

    if (!Settings.canDrawOverlays(this)) {
      Log.w(TAG, "Overlay permission not granted, stopping service")
      stopSelf()
      return
    }

    IslandStateManager.initialize(this)
    lifecycleOwner = FloatingLifecycleOwner().apply { start() }
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    initFloatingCapsule()
    observeState()
  }

  private val overlayFlags: Int
    get() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
      WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
      WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
      WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

  private fun calculateYPosition(settings: CapsuleSettings): Int {
    val density = resources.displayMetrics.density
    val baseCutoutY = (12 * density).toInt()
    val userOffset = (settings.notchOffsetYDp * density).toInt()
    return baseCutoutY + userOffset
  }

  private fun buildNotification(isDismissed: Boolean = false, track: MediaTrackInfo? = null): Notification {
    val restoreIntent = Intent(this, FloatingCapsuleService::class.java).apply {
      action = ACTION_RESTORE_CAPSULE
    }
    val restorePendingIntent = PendingIntent.getService(
      this, 101, restoreIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val openAppIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val openAppPendingIntent = PendingIntent.getActivity(
      this, 0, openAppIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val contentPendingIntent = if (isDismissed) restorePendingIntent else openAppPendingIntent

    val stopIntent = Intent(this, FloatingCapsuleService::class.java).apply {
      action = ACTION_STOP_SERVICE
    }
    val stopPendingIntent = PendingIntent.getService(
      this, 1, stopIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val title: String
    val text: String
    if (isDismissed) {
      if (track != null) {
        title = "🎵 ${track.title}"
        text = "${track.artist.ifEmpty { "Dynamic Capsule" }} • اضغط للاستعادة إلى الشاشة"
      } else {
        title = "Dynamic Capsule"
        text = "تم نقل الكبسولة إلى الإشعارات • اضغط للاستعادة"
      }
    } else {
      if (track != null) {
        title = "Dynamic Capsule • 🎵 ${track.title}"
        text = "${track.artist} - نشط على الشاشة"
      } else {
        title = "Dynamic Capsule"
        text = "Active floating island below status bar"
      }
    }

    val builder = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle(title)
      .setContentText(text)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentIntent(contentPendingIntent)
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)

    if (isDismissed) {
      builder.addAction(
        android.R.drawable.ic_menu_upload,
        "إظهار الكبسولة",
        restorePendingIntent
      )
    }

    if (track != null) {
      val toggleIntent = Intent(this, FloatingCapsuleService::class.java).apply {
        action = ACTION_TOGGLE_PLAY_PAUSE
      }
      val togglePendingIntent = PendingIntent.getService(
        this, 102, toggleIntent,
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
      )
      val playPauseIcon = if (track.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
      val playPauseTitle = if (track.isPlaying) "إيقاف مؤقت" else "تشغيل"
      builder.addAction(playPauseIcon, playPauseTitle, togglePendingIntent)
    }

    builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPendingIntent)

    return builder.build()
  }

  private fun updateNotification(isDismissed: Boolean, track: MediaTrackInfo? = null) {
    try {
      val notification = buildNotification(isDismissed, track)
      val manager = getSystemService(NotificationManager::class.java)
      manager?.notify(NOTIFICATION_ID, notification)
    } catch (e: Exception) {
      Log.e(TAG, "Error updating notification", e)
    }
  }

  private fun startForegroundServiceWithNotification() {
    createNotificationChannel()
    val notification = buildNotification(isDismissed = false, track = null)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Dynamic Island Overlay Service",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Background service keeping Dynamic Island running"
        setShowBadge(false)
      }
      val manager = getSystemService(NotificationManager::class.java)
      manager?.createNotificationChannel(channel)
    }
  }

  fun dismissToNotification() {
    _isDismissedToNotification.value = true
    if (_capsuleMode.value == CapsuleMode.EXPANDED) {
      _capsuleMode.value = CapsuleMode.MINI
    }
    detachView()
    updateNotification(true, MediaSessionHolder.currentTrack.value)
  }

  fun restoreFromNotification() {
    _isDismissedToNotification.value = false
    val track = MediaSessionHolder.currentTrack.value
    updateNotification(false, track)
  }

  private fun initFloatingCapsule() {
    val context = this
    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      overlayFlags,
      PixelFormat.TRANSLUCENT
    ).apply {
      gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }
      y = calculateYPosition(settings)
    }

    floatingView = ComposeView(this).apply {
      lifecycleOwner?.let { owner ->
        setViewTreeLifecycleOwner(owner)
        setViewTreeViewModelStoreOwner(owner)
        setViewTreeSavedStateRegistryOwner(owner)
      }

      setOnTouchListener { _, event ->
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
          if (_capsuleMode.value == CapsuleMode.EXPANDED) {
            setMode(CapsuleMode.MINI)
          }
          false
        } else {
          false
        }
      }

      setContent {
        MyApplicationTheme {
          val currentMode by capsuleMode.collectAsState()
          val track by MediaSessionHolder.currentTrack.collectAsState()
          val currentSettings by CapsuleSettingsManager.getInstance(context).settings.collectAsState()

          Box(
            modifier = Modifier.wrapContentSize(),
            contentAlignment = Alignment.TopCenter
          ) {
            DynamicCapsuleView(
              trackInfo = track,
              settings = currentSettings,
              mode = currentMode,
              onModeChange = { newMode -> setMode(newMode) },
              onDismissToNotification = { dismissToNotification() }
            )
          }
        }
      }
    }
  }

  private fun observeState() {
    val settingsManager = CapsuleSettingsManager.getInstance(this)

    serviceScope.launch {
      combine(
        MediaSessionHolder.currentTrack,
        settingsManager.settings,
        IslandStateManager.activeCard,
        IslandStateManager.callState,
        _isDismissedToNotification
      ) { track, settings, _, callState, isDismissed ->
        // If an incoming call arrives, automatically restore so user can see and answer/decline
        if (isDismissed && callState.isActive && callState.isIncoming) {
          _isDismissedToNotification.value = false
        }
        val effectivelyDismissed = _isDismissedToNotification.value
        val hasActivity = IslandStateManager.hasAnyActiveActivity(track)
        val shouldShow = settings.serviceEnabled && (hasActivity || settings.showWhenIdle) && !effectivelyDismissed
        ServiceCapsuleState(track, settings, shouldShow, effectivelyDismissed)
      }.collect { state ->
        val track = state.track
        val settings = state.settings
        val shouldShow = state.shouldShow
        val isDismissed = state.isDismissed
        val hasActivity = IslandStateManager.hasAnyActiveActivity(track)

        if (shouldShow && !isViewAttached) {
          attachView()
        } else if (!shouldShow && isViewAttached) {
          if (_capsuleMode.value == CapsuleMode.EXPANDED) {
            _capsuleMode.value = CapsuleMode.MINI
          }
          detachView()
        }

        if (!hasActivity && _capsuleMode.value == CapsuleMode.EXPANDED) {
          setMode(CapsuleMode.MINI)
        }

        if (isViewAttached) {
          windowParams?.y = calculateYPosition(settings)
          windowParams?.let { params ->
            try {
              windowManager?.updateViewLayout(floatingView, params)
            } catch (e: Exception) {
              Log.e(TAG, "Error updating window layout", e)
            }
          }
        }

        updateNotification(isDismissed, track)
      }
    }
  }

  private fun setMode(mode: CapsuleMode) {
    if (_capsuleMode.value == mode) return
    _capsuleMode.value = mode

    val settings = CapsuleSettingsManager.getInstance(this).settings.value

    windowParams?.let { params ->
      params.width = WindowManager.LayoutParams.WRAP_CONTENT
      params.height = WindowManager.LayoutParams.WRAP_CONTENT
      params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      params.y = calculateYPosition(settings)
      params.flags = overlayFlags
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        params.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
      }

      try {
        if (isViewAttached && floatingView != null) {
          windowManager?.updateViewLayout(floatingView, params)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error updating mode in WindowManager", e)
      }
    }
  }

  private fun attachView() {
    val view = floatingView ?: return
    val params = windowParams ?: return
    if (!isViewAttached) {
      try {
        windowManager?.addView(view, params)
        isViewAttached = true
      } catch (e: Exception) {
        Log.e(TAG, "Error adding view to WindowManager", e)
      }
    }
  }

  private fun detachView() {
    val view = floatingView ?: return
    if (isViewAttached) {
      try {
        windowManager?.removeView(view)
        isViewAttached = false
      } catch (e: Exception) {
        Log.e(TAG, "Error removing view from WindowManager", e)
      }
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP_SERVICE -> {
        CapsuleSettingsManager.getInstance(this).updateServiceEnabled(false)
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_RESTORE_CAPSULE -> {
        restoreFromNotification()
        return START_STICKY
      }
      ACTION_TOGGLE_PLAY_PAUSE -> {
        MediaSessionHolder.togglePlayPause()
        return START_STICKY
      }
    }
    return START_STICKY
  }

  override fun onDestroy() {
    super.onDestroy()
    detachView()
    lifecycleOwner?.destroy()
    lifecycleOwner = null
    floatingView = null
  }

  companion object {
    private const val TAG = "FloatingCapsuleService"
    private const val CHANNEL_ID = "dynamic_capsule_channel"
    private const val NOTIFICATION_ID = 2001
    const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
    const val ACTION_RESTORE_CAPSULE = "com.example.action.RESTORE_CAPSULE"
    const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.action.TOGGLE_PLAY_PAUSE"
  }
}

private data class ServiceCapsuleState(
  val track: MediaTrackInfo?,
  val settings: CapsuleSettings,
  val shouldShow: Boolean,
  val isDismissed: Boolean
)
