package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.data.CapsuleSettingsManager
import com.example.ui.screens.MainSettingsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val settingsManager = CapsuleSettingsManager.getInstance(applicationContext)

    setContent {
      MyApplicationTheme(darkTheme = true) {
        Scaffold(
          modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
          MainSettingsScreen(
            settingsManager = settingsManager,
            modifier = Modifier.padding(innerPadding)
          )
        }
      }
    }
  }
}
