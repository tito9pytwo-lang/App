package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber

data class CapsuleSettings(
  val serviceEnabled: Boolean = true,
  val notchOffsetYDp: Int = 12,
  val capsuleWidthDp: Int = 190,
  val capsuleHeightDp: Int = 38,
  val accentColorIndex: Int = 0,
  val autoCollapseSeconds: Int = 8,
  val showWhenIdle: Boolean = false,
  val hapticFeedback: Boolean = true
) {
  val accentColor: Color
    get() = when (accentColorIndex) {
      0 -> RealmeGreen
      1 -> CyberCyan
      2 -> ElectricPurple
      3 -> SunsetAmber
      else -> RealmeGreen
    }
}
