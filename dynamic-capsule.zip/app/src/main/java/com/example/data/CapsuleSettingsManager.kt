package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CapsuleSettingsManager private constructor(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("dynamic_capsule_prefs", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(loadSettings())
  val settings: StateFlow<CapsuleSettings> = _settings.asStateFlow()

  private fun loadSettings(): CapsuleSettings {
    return CapsuleSettings(
      serviceEnabled = prefs.getBoolean(KEY_SERVICE_ENABLED, true),
      notchOffsetYDp = prefs.getInt(KEY_NOTCH_OFFSET_Y, 12),
      capsuleWidthDp = prefs.getInt(KEY_CAPSULE_WIDTH, 190),
      capsuleHeightDp = prefs.getInt(KEY_CAPSULE_HEIGHT, 38),
      accentColorIndex = prefs.getInt(KEY_ACCENT_COLOR, 0),
      autoCollapseSeconds = prefs.getInt(KEY_AUTO_COLLAPSE, 8),
      showWhenIdle = prefs.getBoolean(KEY_SHOW_WHEN_IDLE, false),
      hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true)
    )
  }

  fun updateServiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    _settings.value = _settings.value.copy(serviceEnabled = enabled)
  }

  fun updateNotchOffsetY(offset: Int) {
    prefs.edit().putInt(KEY_NOTCH_OFFSET_Y, offset).apply()
    _settings.value = _settings.value.copy(notchOffsetYDp = offset)
  }

  fun updateCapsuleWidth(width: Int) {
    prefs.edit().putInt(KEY_CAPSULE_WIDTH, width).apply()
    _settings.value = _settings.value.copy(capsuleWidthDp = width)
  }

  fun updateAccentColorIndex(index: Int) {
    prefs.edit().putInt(KEY_ACCENT_COLOR, index).apply()
    _settings.value = _settings.value.copy(accentColorIndex = index)
  }

  fun updateAutoCollapseSeconds(seconds: Int) {
    prefs.edit().putInt(KEY_AUTO_COLLAPSE, seconds).apply()
    _settings.value = _settings.value.copy(autoCollapseSeconds = seconds)
  }

  fun updateShowWhenIdle(show: Boolean) {
    prefs.edit().putBoolean(KEY_SHOW_WHEN_IDLE, show).apply()
    _settings.value = _settings.value.copy(showWhenIdle = show)
  }

  companion object {
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_NOTCH_OFFSET_Y = "notch_offset_y"
    private const val KEY_CAPSULE_WIDTH = "capsule_width"
    private const val KEY_CAPSULE_HEIGHT = "capsule_height"
    private const val KEY_ACCENT_COLOR = "accent_color"
    private const val KEY_AUTO_COLLAPSE = "auto_collapse"
    private const val KEY_SHOW_WHEN_IDLE = "show_when_idle"
    private const val KEY_HAPTIC = "haptic"

    @Volatile
    private var INSTANCE: CapsuleSettingsManager? = null

    fun getInstance(context: Context): CapsuleSettingsManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: CapsuleSettingsManager(context).also { INSTANCE = it }
      }
    }
  }
}
