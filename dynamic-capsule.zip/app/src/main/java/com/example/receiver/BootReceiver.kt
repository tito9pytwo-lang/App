package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.example.data.CapsuleSettingsManager
import com.example.service.FloatingCapsuleService

class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      if (settings.serviceEnabled && Settings.canDrawOverlays(context)) {
        val serviceIntent = Intent(context, FloatingCapsuleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          context.startForegroundService(serviceIntent)
        } else {
          context.startService(serviceIntent)
        }
      }
    }
  }
}
