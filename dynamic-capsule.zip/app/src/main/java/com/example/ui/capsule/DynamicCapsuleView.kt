package com.example.ui.capsule

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CapsuleSettings
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.theme.CapsuleBlack
import com.example.ui.theme.CapsuleCardBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CapsuleMode {
  MINI,
  EXPANDED
}

@Composable
fun DynamicCapsuleView(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  mode: CapsuleMode,
  onModeChange: (CapsuleMode) -> Unit,
  modifier: Modifier = Modifier,
  onPlayPauseClick: () -> Unit = { MediaSessionHolder.togglePlayPause() },
  onNextClick: () -> Unit = { MediaSessionHolder.skipToNext() },
  onPrevClick: () -> Unit = { MediaSessionHolder.skipToPrevious() },
  onSeek: (Long) -> Unit = { MediaSessionHolder.seekTo(it) }
) {
  val accentColor = settings.accentColor

  Box(
    modifier = modifier,
    contentAlignment = Alignment.TopCenter
  ) {
    if (mode == CapsuleMode.MINI) {
      MiniCapsule(
        trackInfo = trackInfo,
        accentColor = accentColor,
        compactWidth = settings.capsuleWidthDp.dp,
        compactHeight = settings.capsuleHeightDp.dp,
        onClick = { onModeChange(CapsuleMode.EXPANDED) }
      )
    } else {
      ExpandedCapsule(
        trackInfo = trackInfo,
        accentColor = accentColor,
        onCollapse = { onModeChange(CapsuleMode.MINI) },
        onPlayPauseClick = onPlayPauseClick,
        onNextClick = onNextClick,
        onPrevClick = onPrevClick,
        onSeek = onSeek
      )
    }
  }
}

@Composable
fun MiniCapsule(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  compactWidth: androidx.compose.ui.unit.Dp,
  compactHeight: androidx.compose.ui.unit.Dp,
  onClick: () -> Unit
) {
  val isPlaying = trackInfo?.isPlaying == true
  val interactionSource = remember { MutableInteractionSource() }

  Surface(
    modifier = Modifier
      .testTag("mini_capsule_surface")
      .widthIn(min = compactWidth, max = 260.dp)
      .height(compactHeight)
      .shadow(elevation = 12.dp, shape = CircleShape, spotColor = accentColor.copy(alpha = 0.5f))
      .clip(CircleShape)
      .background(CapsuleBlack)
      .border(
        width = 1.dp,
        brush = Brush.horizontalGradient(
          listOf(
            accentColor.copy(alpha = 0.6f),
            Color.White.copy(alpha = 0.15f),
            accentColor.copy(alpha = 0.6f)
          )
        ),
        shape = CircleShape
      )
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick
      ),
    color = CapsuleBlack,
    shape = CircleShape
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left side: Mini Album Art or Music Icon
      if (trackInfo?.albumArt != null) {
        Image(
          bitmap = trackInfo.albumArt.asImageBitmap(),
          contentDescription = "Album Thumbnail",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .border(1.dp, accentColor.copy(alpha = 0.7f), CircleShape)
        )
      } else {
        Box(
          modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(accentColor.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(14.dp)
          )
        }
      }

      // Center title preview / camera notch cutout gap
      Text(
        text = trackInfo?.title ?: "Realme Music",
        color = TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
          .weight(1f)
          .padding(horizontal = 6.dp)
      )

      // Right side: Animated Mini Waveform
      MiniWaveformVisualizer(
        isPlaying = isPlaying,
        color = accentColor,
        barCount = 4,
        width = 18.dp,
        height = 14.dp
      )
    }
  }
}

@Composable
fun ExpandedCapsule(
  trackInfo: MediaTrackInfo?,
  accentColor: Color,
  onCollapse: () -> Unit,
  onPlayPauseClick: () -> Unit,
  onNextClick: () -> Unit,
  onPrevClick: () -> Unit,
  onSeek: (Long) -> Unit
) {
  val isPlaying = trackInfo?.isPlaying == true
  val duration = (trackInfo?.durationMs ?: 0L).coerceAtLeast(1L)
  val currentPos = trackInfo?.getEstimatedPositionMs() ?: 0L

  var isUserDragging by remember { mutableStateOf(false) }
  var dragPositionFraction by remember { mutableFloatStateOf(0f) }

  val effectiveFraction = if (isUserDragging) {
    dragPositionFraction
  } else {
    (currentPos.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
  }

  Surface(
    modifier = Modifier
      .testTag("expanded_capsule_card")
      .widthIn(min = 320.dp, max = 380.dp)
      .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
      .shadow(elevation = 20.dp, shape = RoundedCornerShape(28.dp), spotColor = accentColor.copy(alpha = 0.45f))
      .clip(RoundedCornerShape(28.dp))
      .background(CapsuleBlack)
      .border(
        width = 1.2.dp,
        brush = Brush.verticalGradient(
          listOf(
            accentColor.copy(alpha = 0.7f),
            Color(0xFF262E3D),
            accentColor.copy(alpha = 0.3f)
          )
        ),
        shape = RoundedCornerShape(28.dp)
      ),
    color = CapsuleBlack,
    shape = RoundedCornerShape(28.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Header: App badge + Collapse button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (isPlaying) accentColor else TextMuted)
          )
          Text(
            text = (trackInfo?.appName?.takeIf { it.isNotBlank() } ?: "Dynamic Capsule").uppercase(),
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        }

        IconButton(
          onClick = onCollapse,
          modifier = Modifier
            .testTag("collapse_capsule_button")
            .size(32.dp)
            .background(Color.White.copy(alpha = 0.08f), CircleShape)
        ) {
          Icon(
            imageVector = Icons.Rounded.KeyboardArrowUp,
            contentDescription = "Collapse Capsule",
            tint = TextPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Main Track row: Album Art + Titles
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (trackInfo?.albumArt != null) {
          Image(
            bitmap = trackInfo.albumArt.asImageBitmap(),
            contentDescription = "Album Cover",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(14.dp))
              .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
          )
        } else {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(
                Brush.linearGradient(
                  listOf(Color(0xFF1E2638), Color(0xFF111624))
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.GraphicEq,
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(28.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = trackInfo?.title ?: "No Track Playing",
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = trackInfo?.artist ?: "Connect music app or start demo",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Waveform Visualizer Section
      ExpandedWaveformVisualizer(
        isPlaying = isPlaying,
        color = accentColor,
        barCount = 20,
        height = 24.dp,
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Interactive Progress Slider
      Slider(
        value = effectiveFraction,
        onValueChange = { fraction ->
          isUserDragging = true
          dragPositionFraction = fraction
        },
        onValueChangeFinished = {
          val seekTargetMs = (dragPositionFraction * duration).toLong()
          onSeek(seekTargetMs)
          isUserDragging = false
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(24.dp)
          .testTag("track_progress_slider"),
        colors = SliderDefaults.colors(
          thumbColor = accentColor,
          activeTrackColor = accentColor,
          inactiveTrackColor = Color.White.copy(alpha = 0.15f)
        )
      )

      // Time Display row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        val displayPos = if (isUserDragging) {
          (dragPositionFraction * duration).toLong()
        } else {
          currentPos
        }
        Text(
          text = trackInfo?.formatTime(displayPos) ?: "00:00",
          color = TextMuted,
          fontSize = 11.sp
        )
        Text(
          text = trackInfo?.formatTime(duration) ?: "00:00",
          color = TextMuted,
          fontSize = 11.sp
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Playback Controls Row: Previous, Play/Pause, Next
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onPrevClick,
          modifier = Modifier
            .testTag("prev_track_button")
            .size(44.dp)
            .background(Color.White.copy(alpha = 0.06f), CircleShape)
        ) {
          Icon(
            imageVector = Icons.Default.SkipPrevious,
            contentDescription = "Previous Track",
            tint = TextPrimary,
            modifier = Modifier.size(24.dp)
          )
        }

        IconButton(
          onClick = onPlayPauseClick,
          modifier = Modifier
            .testTag("play_pause_button")
            .size(56.dp)
            .shadow(12.dp, CircleShape, spotColor = accentColor)
            .background(accentColor, CircleShape)
        ) {
          Icon(
            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (isPlaying) "Pause" else "Play",
            tint = Color.Black,
            modifier = Modifier.size(32.dp)
          )
        }

        IconButton(
          onClick = onNextClick,
          modifier = Modifier
            .testTag("next_track_button")
            .size(44.dp)
            .background(Color.White.copy(alpha = 0.06f), CircleShape)
        ) {
          Icon(
            imageVector = Icons.Default.SkipNext,
            contentDescription = "Next Track",
            tint = TextPrimary,
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }
  }
}
