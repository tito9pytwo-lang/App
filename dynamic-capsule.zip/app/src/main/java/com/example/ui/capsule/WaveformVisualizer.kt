package com.example.ui.capsule

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun MiniWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  modifier: Modifier = Modifier,
  barCount: Int = 4,
  width: Dp = 18.dp,
  height: Dp = 16.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "miniWave")

  val phase1 by infiniteTransition.animateFloat(
    initialValue = 0.2f,
    targetValue = 0.95f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "p1"
  )
  val phase2 by infiniteTransition.animateFloat(
    initialValue = 0.35f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 550, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "p2"
  )
  val phase3 by infiniteTransition.animateFloat(
    initialValue = 0.15f,
    targetValue = 0.75f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 460, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "p3"
  )
  val phase4 by infiniteTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = 0.85f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 620, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "p4"
  )

  val phases = listOf(phase1, phase2, phase3, phase4)

  Box(modifier = modifier.width(width).height(height)) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val totalWidth = size.width
      val totalHeight = size.height
      val barWidth = (totalWidth / (barCount * 2 - 1)).coerceAtLeast(3f)
      val gap = barWidth

      for (i in 0 until barCount) {
        val fraction = if (isPlaying) {
          phases[i % phases.size]
        } else {
          0.18f // Calm resting line when paused
        }
        val barH = (totalHeight * fraction).coerceAtLeast(barWidth)
        val left = i * (barWidth + gap)
        val top = (totalHeight - barH) / 2f

        drawRoundRect(
          color = color,
          topLeft = Offset(left, top),
          size = Size(barWidth, barH),
          cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
        )
      }
    }
  }
}

@Composable
fun ExpandedWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  modifier: Modifier = Modifier,
  barCount: Int = 18,
  height: Dp = 28.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "expandedWave")

  val time by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 6.28318f, // 2 * PI
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1800, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "time"
  )

  Box(modifier = modifier.height(height)) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val totalWidth = size.width
      val totalHeight = size.height
      val barSpacing = totalWidth / barCount
      val barWidth = (barSpacing * 0.55f).coerceIn(4f, 10f)

      val brush = Brush.verticalGradient(
        colors = listOf(
          color.copy(alpha = 0.95f),
          color.copy(alpha = 0.45f)
        )
      )

      for (i in 0 until barCount) {
        val fraction = if (isPlaying) {
          // Combination of two sine waves for organic musical spectrum feeling
          val wave1 = sin(time * 2.2f + i * 0.45f) * 0.4f
          val wave2 = sin(time * 1.4f + i * 0.85f) * 0.3f
          (0.35f + wave1 + wave2).coerceIn(0.12f, 1.0f)
        } else {
          // Flat calm resting wave
          0.12f
        }

        val barH = (totalHeight * fraction).coerceAtLeast(barWidth)
        val left = i * barSpacing + (barSpacing - barWidth) / 2f
        val top = (totalHeight - barH) / 2f

        drawRoundRect(
          brush = brush,
          topLeft = Offset(left, top),
          size = Size(barWidth, barH),
          cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
        )
      }
    }
  }
}
