package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.CapsuleSettings
import com.example.data.CapsuleSettingsManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.service.FloatingCapsuleService
import com.example.ui.capsule.CapsuleMode
import com.example.ui.capsule.DynamicCapsuleView
import com.example.ui.theme.CapsuleBlack
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.RealmeGreen
import com.example.ui.theme.SunsetAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainSettingsScreen(
  settingsManager: CapsuleSettingsManager,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val settings by settingsManager.settings.collectAsState()
  val trackInfo by MediaSessionHolder.currentTrack.collectAsState()
  val isListenerConnected by MediaSessionHolder.isListenerConnected.collectAsState()

  // Track live permissions state
  var canDrawOverlay by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
  var isNotifListenerGranted by remember {
    mutableStateOf(NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName))
  }
  var isPostNotifGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      } else true
    )
  }
  var isBatteryOptIgnored by remember {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    mutableStateOf(pm?.isIgnoringBatteryOptimizations(context.packageName) == true)
  }

  // Refresh permissions on app resume
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        canDrawOverlay = Settings.canDrawOverlays(context)
        isNotifListenerGranted =
          NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          isPostNotifGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
          ) == PackageManager.PERMISSION_GRANTED
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        isBatteryOptIgnored = pm?.isIgnoringBatteryOptimizations(context.packageName) == true

        // If all granted and enabled, start service
        if (canDrawOverlay && settings.serviceEnabled) {
          startCapsuleService(context)
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  val postNotifLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    isPostNotifGranted = granted
  }

  var previewMode by remember { mutableStateOf(CapsuleMode.MINI) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      HeaderBanner(
        serviceEnabled = settings.serviceEnabled && canDrawOverlay && isNotifListenerGranted,
        accentColor = settings.accentColor
      )
    }

    // Live In-App Capsule Preview Card
    item {
      LivePreviewCard(
        trackInfo = trackInfo,
        settings = settings,
        previewMode = previewMode,
        onModeToggle = {
          previewMode = if (previewMode == CapsuleMode.MINI) CapsuleMode.EXPANDED else CapsuleMode.MINI
        }
      )
    }

    // Active Media Session Card & Demo Player
    item {
      ActivePlayerCard(
        trackInfo = trackInfo,
        isListenerConnected = isNotifListenerGranted,
        accentColor = settings.accentColor,
        onStartDemo = { MediaSessionHolder.startDemoTrack() },
        onStopDemo = { MediaSessionHolder.stopDemoTrack() }
      )
    }

    // Required Permissions Checklist
    item {
      PermissionsCard(
        canDrawOverlay = canDrawOverlay,
        isNotifListenerGranted = isNotifListenerGranted,
        isPostNotifGranted = isPostNotifGranted,
        isBatteryOptIgnored = isBatteryOptIgnored,
        accentColor = settings.accentColor,
        onGrantOverlay = {
          val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
          )
          context.startActivity(intent)
        },
        onGrantListener = {
          val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
          context.startActivity(intent)
        },
        onRequestPostNotif = {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            postNotifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
          }
        },
        onRequestBatteryOpt = {
          val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:${context.packageName}")
          }
          context.startActivity(intent)
        }
      )
    }

    // Customization & Calibration Controls
    item {
      CustomizationCard(
        settings = settings,
        onUpdateSettings = { newSettings ->
          settingsManager.updateNotchOffsetY(newSettings.notchOffsetYDp)
          settingsManager.updateCapsuleWidth(newSettings.capsuleWidthDp)
          settingsManager.updateAccentColorIndex(newSettings.accentColorIndex)
          settingsManager.updateAutoCollapseSeconds(newSettings.autoCollapseSeconds)
          settingsManager.updateShowWhenIdle(newSettings.showWhenIdle)
        },
        onToggleService = { enabled ->
          settingsManager.updateServiceEnabled(enabled)
          if (enabled) {
            startCapsuleService(context)
          } else {
            stopCapsuleService(context)
          }
        }
      )
    }
  }
}

@Composable
private fun HeaderBanner(
  serviceEnabled: Boolean,
  accentColor: Color
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Dynamic Capsule",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "كبسولة الموسيقى العائمة • realme C53",
            color = TextSecondary,
            fontSize = 13.sp
          )
        }

        // Status chip
        Surface(
          shape = CircleShape,
          color = if (serviceEnabled) accentColor.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (serviceEnabled) accentColor else Color.Red.copy(alpha = 0.5f)
          )
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (serviceEnabled) accentColor else Color.Red)
            )
            Text(
              text = if (serviceEnabled) "نشطة (Active)" else "غير مفعلة",
              color = if (serviceEnabled) accentColor else Color.Red,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LivePreviewCard(
  trackInfo: MediaTrackInfo?,
  settings: CapsuleSettings,
  previewMode: CapsuleMode,
  onModeToggle: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.GraphicEq,
            contentDescription = null,
            tint = settings.accentColor,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "معاينة حية للكبسولة (Live Preview)",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }

        OutlinedButton(
          onClick = onModeToggle,
          modifier = Modifier.testTag("toggle_preview_mode_button"),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = settings.accentColor)
        ) {
          Text(
            text = if (previewMode == CapsuleMode.MINI) "تبديل للموسعة" else "تبديل للمصغرة",
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Simulated phone camera notch area
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF07080C))
          .border(1.dp, Color(0xFF1B202D), RoundedCornerShape(16.dp))
          .padding(vertical = 24.dp, horizontal = 12.dp),
        contentAlignment = Alignment.TopCenter
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          // Camera punch hole dot representing realme C53 front lens
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(Color(0xFF0F1218))
              .border(1.5.dp, Color(0xFF262D3D), CircleShape)
          )
          Spacer(modifier = Modifier.height(6.dp))

          DynamicCapsuleView(
            trackInfo = trackInfo ?: MediaTrackInfo(
              title = "Realme Beats",
              artist = "Mini Capsule Sound",
              isPlaying = true,
              durationMs = 210000L,
              currentPositionMs = 65000L
            ),
            settings = settings,
            mode = previewMode,
            onModeChange = { /* preview mode controlled by button */ }
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "المعاينة تدعم الأزرار التفاعلية والموجات المتحركة مباشرة",
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
private fun ActivePlayerCard(
  trackInfo: MediaTrackInfo?,
  isListenerConnected: Boolean,
  accentColor: Color,
  onStartDemo: () -> Unit,
  onStopDemo: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Tune,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
          )
          Text(
            text = "مشغل الوسائط الحالي (Media Session)",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (trackInfo != null) {
        // Active media detected
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.GraphicEq,
              contentDescription = null,
              tint = accentColor,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = trackInfo.title,
              color = TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1
            )
            Text(
              text = "${trackInfo.artist} • ${trackInfo.appName}",
              color = TextSecondary,
              fontSize = 12.sp,
              maxLines = 1
            )
          }

          // Stop demo button if it's the demo session
          if (trackInfo.appName.contains("Demo")) {
            OutlinedButton(
              onClick = onStopDemo,
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("إيقاف", fontSize = 11.sp)
            }
          }
        }
      } else {
        // No active media session
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (isListenerConnected)
              "بانتظار تشغيل الموسيقى من Spotify أو YouTube Music أو أي مشغل..."
            else
              "يرجى تفعيل صلاحية الإشعارات أدناه لاكتشاف الموسيقى",
            color = TextSecondary,
            fontSize = 12.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Button(
            onClick = onStartDemo,
            modifier = Modifier.testTag("start_demo_track_button"),
            colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.Black)
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("تشغيل مقطع تجريبي لفحص الكبسولة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionsCard(
  canDrawOverlay: Boolean,
  isNotifListenerGranted: Boolean,
  isPostNotifGranted: Boolean,
  isBatteryOptIgnored: Boolean,
  accentColor: Color,
  onGrantOverlay: () -> Unit,
  onGrantListener: () -> Unit,
  onRequestPostNotif: () -> Unit,
  onRequestBatteryOpt: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Settings,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(20.dp)
        )
        Text(
          text = "صلاحيات النظام المطلوبة (Permissions)",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 1. Overlay Permission
      PermissionItem(
        title = "الظهور فوق التطبيقات (Display Overlay)",
        description = "مطلوبة لعرض الكبسولة العائمة أعلى الشاشة",
        isGranted = canDrawOverlay,
        icon = Icons.Default.Widgets,
        accentColor = accentColor,
        onActionClick = onGrantOverlay
      )

      // 2. Notification Listener Permission
      PermissionItem(
        title = "الوصول لجلسات الوسائط (Media Session)",
        description = "مطلوبة لقراءة الأغنية الحالية والتحكم بها عبر MediaSessionManager",
        isGranted = isNotifListenerGranted,
        icon = Icons.Default.GraphicEq,
        accentColor = accentColor,
        onActionClick = onGrantListener
      )

      // 3. Post Notifications (Android 13+)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        PermissionItem(
          title = "إشعارات الخدمة (Notifications)",
          description = "مطلوبة لتشغيل خدمة الكبسولة في الخلفية بثبات",
          isGranted = isPostNotifGranted,
          icon = Icons.Default.Notifications,
          accentColor = accentColor,
          onActionClick = onRequestPostNotif
        )
      }

      // 4. Battery Optimization Exemption (Realme UI)
      PermissionItem(
        title = "استثناء توفير الطاقة (Realme UI Battery)",
        description = "يمنع نظام realme من إغلاق خدمة الكبسولة تلقائياً",
        isGranted = isBatteryOptIgnored,
        icon = Icons.Default.BatteryChargingFull,
        accentColor = accentColor,
        onActionClick = onRequestBatteryOpt
      )
    }
  }
}

@Composable
private fun PermissionItem(
  title: String,
  description: String,
  isGranted: Boolean,
  icon: ImageVector,
  accentColor: Color,
  onActionClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(DarkSurfaceCard)
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = if (isGranted) accentColor else Color(0xFFFFB74D),
      modifier = Modifier.size(24.dp)
    )

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        color = TextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = description,
        color = TextSecondary,
        fontSize = 11.sp
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    if (isGranted) {
      Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = "Granted",
        tint = accentColor,
        modifier = Modifier.size(22.dp)
      )
    } else {
      Button(
        onClick = onActionClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B3347), contentColor = TextPrimary),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text("تفعيل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
private fun CustomizationCard(
  settings: CapsuleSettings,
  onUpdateSettings: (CapsuleSettings) -> Unit,
  onToggleService: (Boolean) -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = DarkSurface),
    shape = RoundedCornerShape(22.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "تشغيل الكبسولة العائمة",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "إظهار الكبسولة تلقائياً عند تشغيل الموسيقى",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.serviceEnabled,
          onCheckedChange = onToggleService,
          modifier = Modifier.testTag("service_toggle_switch"),
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.Black,
            checkedTrackColor = settings.accentColor
          )
        )
      }

      androidx.compose.material3.HorizontalDivider(color = DarkSurfaceBorder)

      // Top Notch Offset Slider (realme C53 camera cutout alignment)
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "محاذاة مع فتحة الكاميرا (Notch Y Offset)",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "${settings.notchOffsetYDp} dp (C53)",
            color = settings.accentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Slider(
          value = settings.notchOffsetYDp.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(notchOffsetYDp = it.toInt())) },
          valueRange = 0f..60f,
          colors = SliderDefaults.colors(
            thumbColor = settings.accentColor,
            activeTrackColor = settings.accentColor
          )
        )
      }

      // Accent Color Picker
      Column {
        Text(
          text = "لون موجات الكبسولة (Accent Color)",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          val colors = listOf(
            Pair("Realme Green", RealmeGreen),
            Pair("Cyber Cyan", CyberCyan),
            Pair("Purple", ElectricPurple),
            Pair("Amber", SunsetAmber)
          )
          colors.forEachIndexed { index, (label, color) ->
            val isSelected = settings.accentColorIndex == index
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                  width = if (isSelected) 3.dp else 1.dp,
                  color = if (isSelected) Color.White else Color.Transparent,
                  shape = CircleShape
                )
                .clickable { onUpdateSettings(settings.copy(accentColorIndex = index)) }
            )
          }
        }
      }

      // Compact Capsule Width Slider
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "عرض الكبسولة المصغرة (Width)",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "${settings.capsuleWidthDp} dp",
            color = settings.accentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Slider(
          value = settings.capsuleWidthDp.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(capsuleWidthDp = it.toInt())) },
          valueRange = 150f..250f,
          colors = SliderDefaults.colors(
            thumbColor = settings.accentColor,
            activeTrackColor = settings.accentColor
          )
        )
      }

      // Show when idle toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "إبقاء الكبسولة مرئية دائماً",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "تظل الكبسولة ظاهرة حتى عند توقف الموسيقى",
            color = TextSecondary,
            fontSize = 11.sp
          )
        }
        Switch(
          checked = settings.showWhenIdle,
          onCheckedChange = { onUpdateSettings(settings.copy(showWhenIdle = it)) },
          colors = SwitchDefaults.colors(
            checkedThumbColor = Color.Black,
            checkedTrackColor = settings.accentColor
          )
        )
      }
    }
  }
}

private fun startCapsuleService(context: Context) {
  try {
    val intent = Intent(context, FloatingCapsuleService::class.java)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      context.startForegroundService(intent)
    } else {
      context.startService(intent)
    }
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to start FloatingCapsuleService", e)
  }
}

private fun stopCapsuleService(context: Context) {
  try {
    val intent = Intent(context, FloatingCapsuleService::class.java)
    context.stopService(intent)
  } catch (e: Exception) {
    android.util.Log.e("MainSettingsScreen", "Failed to stop FloatingCapsuleService", e)
  }
}
