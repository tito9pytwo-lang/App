package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RealmeGreen = Color(0xFF00E676)
val RealmeGreenDark = Color(0xFF00C853)
val RealmeGreenGlow = Color(0x6600E676)

val CyberCyan = Color(0xFF00E5FF)
val ElectricPurple = Color(0xFFD500F9)
val SunsetAmber = Color(0xFFFFAB00)

val CapsuleBlack = Color(0xFF050507)
val CapsuleCardBlack = Color(0xFF0E1117)
val DarkBackground = Color(0xFF090B10)
val DarkSurface = Color(0xFF121620)
val DarkSurfaceCard = Color(0xFF1A1F2C)
val DarkSurfaceBorder = Color(0xFF252D3D)

val TextPrimary = Color(0xFFF2F5FA)
val TextSecondary = Color(0xFFA1AAB9)
val TextMuted = Color(0xFF6B7485)
