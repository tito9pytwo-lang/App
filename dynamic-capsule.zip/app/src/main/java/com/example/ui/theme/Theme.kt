package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = RealmeGreen,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00381B),
    onPrimaryContainer = RealmeGreen,
    secondary = CyberCyan,
    onSecondary = Color.Black,
    tertiary = ElectricPurple,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceBorder
  )

private val LightColorScheme =
  lightColorScheme(
    primary = RealmeGreenDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB9F6CA),
    onPrimaryContainer = Color(0xFF00210C),
    secondary = CyberCyan,
    onSecondary = Color.Black,
    tertiary = ElectricPurple,
    background = Color(0xFFF7F9FC),
    onBackground = Color(0xFF101318),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF101318),
    surfaceVariant = Color(0xFFE8ECF2),
    onSurfaceVariant = Color(0xFF434A56),
    outline = Color(0xFFCFD5DF)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to sleek dark mode for Dynamic Capsule
  dynamicColor: Boolean = false, // Preserve brand Realme Green and Obsidian palette
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
