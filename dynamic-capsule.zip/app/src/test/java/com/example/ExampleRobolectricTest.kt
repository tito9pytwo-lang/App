package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(15)
    assertEquals(15, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateAccentColorIndex(1)
    assertEquals(1, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Test Artist",
      durationMs = 215000L,
      currentPositionMs = 75000L,
      isPlaying = false
    )

    assertEquals("03:35", track.formatTime(track.durationMs))
    assertEquals("01:15", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }
}
