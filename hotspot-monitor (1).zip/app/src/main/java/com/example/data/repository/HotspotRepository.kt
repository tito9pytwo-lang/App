package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.DeviceHistoryEntity
import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.DeviceStatus
import com.example.data.model.HotspotStatus
import com.example.data.scanner.HotspotDetector
import com.example.data.scanner.LocalSubnetScanner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HotspotRepository private constructor(private val context: Context) {

    private val database = AppDatabase.getInstance(context)
    private val historyDao = database.deviceHistoryDao()

    private val detector = HotspotDetector(context)
    private val scanner = LocalSubnetScanner()

    private val repositoryScope = CoroutineScope(Dispatchers.IO + Job())
    private var scanLoopJob: Job? = null

    // State Flows
    private val _hotspotStatus = MutableStateFlow(HotspotStatus())
    val hotspotStatus: StateFlow<HotspotStatus> = _hotspotStatus.asStateFlow()

    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices: StateFlow<List<ConnectedDevice>> = _connectedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _lastScanTime = MutableStateFlow(0L)
    val lastScanTime: StateFlow<Long> = _lastScanTime.asStateFlow()

    private val _isMonitoringActive = MutableStateFlow(false)
    val isMonitoringActive: StateFlow<Boolean> = _isMonitoringActive.asStateFlow()

    private val _scanIntervalSeconds = MutableStateFlow(5)
    val scanIntervalSeconds: StateFlow<Int> = _scanIntervalSeconds.asStateFlow()

    val historyDevices: Flow<List<DeviceHistoryEntity>> = historyDao.getAllHistory()

    // Listeners for device events (join / leave)
    var onDeviceJoined: ((ConnectedDevice) -> Unit)? = null
    var onDeviceLeft: ((ConnectedDevice) -> Unit)? = null

    init {
        // Observe hotspot status continuously
        repositoryScope.launch {
            detector.observeHotspotState().collect { status ->
                _hotspotStatus.value = status
            }
        }
    }

    fun setScanInterval(seconds: Int) {
        _scanIntervalSeconds.value = seconds.coerceIn(2, 60)
    }

    fun startMonitoring() {
        if (_isMonitoringActive.value) return
        _isMonitoringActive.value = true

        scanLoopJob?.cancel()
        scanLoopJob = repositoryScope.launch {
            while (isActive && _isMonitoringActive.value) {
                try {
                    val currentStatus = detector.checkHotspotStatus()
                    _hotspotStatus.value = currentStatus

                    // Always scan when user explicitly activated monitoring mode
                    runScanCycle(currentStatus)
                } catch (e: Exception) {
                    Log.e("HotspotRepo", "Loop iteration error: ${e.message}")
                }

                val waitTime = (_scanIntervalSeconds.value * 1000L).coerceAtLeast(2000L)
                delay(waitTime)
            }
        }
    }

    fun stopMonitoring() {
        _isMonitoringActive.value = false
        scanLoopJob?.cancel()
        scanLoopJob = null
        _isScanning.value = false
    }

    suspend fun manualRefresh() = withContext(Dispatchers.IO) {
        val currentStatus = detector.checkHotspotStatus()
        _hotspotStatus.value = currentStatus
        runScanCycle(currentStatus)
    }

    private suspend fun runScanCycle(status: HotspotStatus) {
        if (_isScanning.value) return
        _isScanning.value = true

        try {
            val prefix = status.subnetPrefix
            val gateway = status.gatewayIp ?: "$prefix.1"

            val previousIps = _connectedDevices.value.map { it.ip }.toSet()
            val newDevices = scanner.scanSubnet(prefix, gateway)

            val currentIps = newDevices.map { it.ip }.toSet()

            // If active devices were discovered, Hotspot is guaranteed enabled
            if (newDevices.isNotEmpty() && !_hotspotStatus.value.isEnabled) {
                _hotspotStatus.value = _hotspotStatus.value.copy(
                    isEnabled = true,
                    detectionMethod = "اكتشاف أجهزة نشطة على النطاق $prefix"
                )
            }

            // Detect new devices
            for (dev in newDevices) {
                if (!previousIps.contains(dev.ip) && dev.status == DeviceStatus.CONNECTED) {
                    onDeviceJoined?.invoke(dev)
                }
            }

            // Detect left devices
            for (oldDev in _connectedDevices.value) {
                if (!currentIps.contains(oldDev.ip)) {
                    onDeviceLeft?.invoke(oldDev)
                }
            }

            _connectedDevices.value = newDevices
            _lastScanTime.value = System.currentTimeMillis()

            // Persist to Room history
            persistToHistory(newDevices)

        } catch (e: Exception) {
            Log.e("HotspotRepo", "Scan error: ${e.message}")
        } finally {
            _isScanning.value = false
        }
    }

    private suspend fun persistToHistory(devices: List<ConnectedDevice>) {
        for (device in devices) {
            try {
                val existing = historyDao.getDeviceByIp(device.ip)
                if (existing != null) {
                    historyDao.update(
                        existing.copy(
                            hostname = device.hostname ?: existing.hostname,
                            deviceType = device.deviceType.name,
                            lastSeenTimestamp = device.lastSeenTimestamp,
                            appearanceCount = existing.appearanceCount + 1,
                            lastLatencyMs = device.latencyMs
                        )
                    )
                } else {
                    historyDao.insert(
                        DeviceHistoryEntity(
                            ip = device.ip,
                            hostname = device.hostname,
                            deviceType = device.deviceType.name,
                            firstSeenTimestamp = device.firstSeenTimestamp,
                            lastSeenTimestamp = device.lastSeenTimestamp,
                            appearanceCount = 1,
                            lastLatencyMs = device.latencyMs
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("HotspotRepo", "DB insert error: ${e.message}")
            }
        }
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        historyDao.clearAll()
    }

    fun getDiagnostics(): DetectionDiagnostics {
        val status = _hotspotStatus.value
        val gateway = status.gatewayIp ?: "192.168.43.1"
        val prefix = status.subnetPrefix

        return DetectionDiagnostics(
            currentMethod = "فحص متعدد: سجلات النواة (ip neigh / ARP) + مقابس UDP/mDNS/TCP",
            activeInterface = status.interfaceName ?: "ap0 / wlan1 (افتراضي)",
            gatewayIp = gateway,
            subnetRange = "$prefix.2 - $prefix.254",
            reliabilityLevel = if (status.isEnabled || _connectedDevices.value.isNotEmpty()) "عالي جداً ومؤكد (أجهزة نشطة)" else "في وضع الاستعداد"
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: HotspotRepository? = null

        fun getInstance(context: Context): HotspotRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = HotspotRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
