package com.example.data.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import com.example.data.model.HotspotStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.net.Inet4Address
import java.net.NetworkInterface

class HotspotDetector(private val context: Context) {

    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val connectivityManager: ConnectivityManager? =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    /**
     * Inspects network interfaces, system reflection, and tethering state to detect Wi-Fi Hotspot status.
     */
    fun checkHotspotStatus(): HotspotStatus {
        var isEnabled = false
        var activeInterface: String? = null
        var gatewayIp: String? = null
        var subnetPrefix = "192.168.43"
        var detectionMethod = "فحص واجهات الشبكة المباشرة"

        // 1. Check ConnectivityManager tethered interfaces via reflection (Standard on Android 10..15)
        try {
            if (connectivityManager != null) {
                val method = connectivityManager.javaClass.getDeclaredMethod("getTetheredIfaces")
                method.isAccessible = true
                val tetheredIfaces = method.invoke(connectivityManager) as? Array<*>
                if (!tetheredIfaces.isNullOrEmpty()) {
                    isEnabled = true
                    activeInterface = tetheredIfaces.firstOrNull()?.toString()
                    detectionMethod = "واجهة التوصيل النشطة: $activeInterface"
                }
            }
        } catch (_: Exception) {}

        // 2. Check WifiManager getWifiApState reflection (WIFI_AP_STATE_ENABLED = 13, WIFI_AP_STATE_ENABLING = 12)
        if (!isEnabled && wifiManager != null) {
            try {
                val stateMethod = wifiManager.javaClass.getDeclaredMethod("getWifiApState")
                stateMethod.isAccessible = true
                val state = stateMethod.invoke(wifiManager) as? Int
                if (state == 13 || state == 12) {
                    isEnabled = true
                    detectionMethod = "حالة WifiManager النشطة ($state)"
                }
            } catch (_: Exception) {}
        }

        // 3. Fallback: Check isWifiApEnabled reflection
        if (!isEnabled && wifiManager != null) {
            try {
                val isApEnabledMethod = wifiManager.javaClass.getDeclaredMethod("isWifiApEnabled")
                isApEnabledMethod.isAccessible = true
                val result = isApEnabledMethod.invoke(wifiManager) as? Boolean
                if (result == true) {
                    isEnabled = true
                    detectionMethod = "استعلام WifiManager النظامي"
                }
            } catch (_: Exception) {}
        }

        // 4. Scan all network interfaces on the device (handles realme C53 / Unisoc kernel naming)
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            for (iface in interfaces) {
                if (iface.isLoopback) continue

                val name = iface.name.lowercase()
                val isApName = name.startsWith("ap") ||
                        name.startsWith("wlan1") ||
                        name.startsWith("softap") ||
                        name.startsWith("swlan") ||
                        name.startsWith("rndis") ||
                        name.contains("tether") ||
                        name.startsWith("uap") ||
                        name.startsWith("p2p")

                val addrs = iface.inetAddresses.toList()
                for (addr in addrs) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val hostAddr = addr.hostAddress ?: continue

                        val isHotspotSubnet = hostAddr.startsWith("192.168.43.") ||
                                hostAddr.startsWith("192.168.44.") ||
                                hostAddr.startsWith("192.168.49.") ||
                                hostAddr.startsWith("192.168.50.") ||
                                hostAddr.startsWith("192.168.225.") ||
                                hostAddr.startsWith("172.20.10.") ||
                                (isApName && hostAddr.endsWith(".1"))

                        if (isHotspotSubnet || isApName) {
                            isEnabled = true
                            activeInterface = iface.name
                            gatewayIp = hostAddr
                            subnetPrefix = hostAddr.substringBeforeLast('.')
                            detectionMethod = "واجهة $activeInterface نشطة ($hostAddr)"
                            break
                        }
                    }
                }
                if (gatewayIp != null) break
            }
        } catch (e: Exception) {
            Log.e("HotspotDetector", "Interface scan error: ${e.message}")
        }

        // Safe defaults for realme C53 hotspot gateway
        if (gatewayIp == null) {
            gatewayIp = "$subnetPrefix.1"
        }

        return HotspotStatus(
            isEnabled = isEnabled,
            interfaceName = activeInterface ?: (if (isEnabled) "ap0/wlan1" else "wlan1/ap0"),
            gatewayIp = gatewayIp,
            subnetPrefix = subnetPrefix,
            detectionMethod = detectionMethod,
            lastCheckedTimestamp = System.currentTimeMillis()
        )
    }

    /**
     * Emits Hotspot status updates via broadcast intents and network state changes.
     */
    fun observeHotspotState(): Flow<HotspotStatus> = callbackFlow {
        trySend(checkHotspotStatus())

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                trySend(checkHotspotStatus())
            }
        }

        val filter = IntentFilter().apply {
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction("android.net.conn.TETHER_STATE_CHANGED")
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
        } catch (_: Exception) {
            try {
                context.registerReceiver(receiver, filter)
            } catch (e: Exception) {
                Log.w("HotspotDetector", "Receiver registration error: ${e.message}")
            }
        }

        awaitClose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
        }
    }
}
