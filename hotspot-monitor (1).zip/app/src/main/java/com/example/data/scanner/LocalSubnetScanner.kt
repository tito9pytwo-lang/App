package com.example.data.scanner

import android.util.Log
import com.example.data.model.ConnectedDevice
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.PortUnreachableException
import java.net.Socket

class LocalSubnetScanner {

    private val commonTcpPorts = intArrayOf(80, 443, 53, 5353, 8080, 137, 22, 8008, 62078, 5000)

    // Tracks devices across consecutive scans to prevent flapping
    private val deviceStateMap = mutableMapOf<String, ConnectedDevice>()

    /**
     * Executes a deep multi-layer subnet scan:
     * 1. Pre-scan kernel neighbor table inspection (/proc/net/arp & ip neigh)
     * 2. Concurrent network probing (Connected UDP, mDNS, NetBIOS, TCP) forcing ARP resolution
     * 3. Post-scan kernel neighbor table inspection (captures freshly resolved ARP entries)
     * 4. Merging and deduplicating results
     */
    suspend fun scanSubnet(
        subnetPrefix: String = "192.168.43",
        gatewayIp: String? = "192.168.43.1"
    ): List<ConnectedDevice> = withContext(Dispatchers.IO) {
        val discoveredInThisRound = mutableMapOf<String, ProbeResult>()

        // Step 1: Pre-read kernel ARP / neighbor tables before probing
        readKernelNeighbors(subnetPrefix, gatewayIp, discoveredInThisRound)

        // Step 2: Concurrent Active Probing across all hosts in subnet
        // Realme C53 / Android Hotspot typically assigns DHCP in the 10..150 range.
        val primaryHosts = (10..150).toList()
        val secondaryHosts = (2..9) + (151..254)
        val allHosts = primaryHosts + secondaryHosts

        val semaphore = Semaphore(25)

        coroutineScope {
            val deferreds = allHosts.map { hostSuffix ->
                async {
                    val targetIp = "$subnetPrefix.$hostSuffix"
                    if (targetIp == gatewayIp) return@async null

                    semaphore.withPermit {
                        probeHost(targetIp)
                    }
                }
            }

            deferreds.awaitAll().filterNotNull().forEach { result ->
                val existing = discoveredInThisRound[result.ip]
                if (existing == null || (!result.hostname.isNullOrBlank() && existing.hostname.isNullOrBlank())) {
                    discoveredInThisRound[result.ip] = result.copy(
                        mac = result.mac ?: existing?.mac
                    )
                }
            }
        }

        // Step 3: Re-read kernel neighbor tables AFTER probing!
        // Sending packets across the subnet triggers hardware ARP requests in the Linux kernel.
        // Responding hosts now populate the kernel neighbor table!
        readKernelNeighbors(subnetPrefix, gatewayIp, discoveredInThisRound)

        val currentTime = System.currentTimeMillis()
        val updatedDevices = mutableListOf<ConnectedDevice>()

        // 1. Process devices discovered in this scan round
        for ((ip, probeResult) in discoveredInThisRound) {
            val existing = deviceStateMap[ip]
            val resolvedHostname = probeResult.hostname?.takeIf { it.isNotBlank() } ?: existing?.hostname
            val deviceType = existing?.deviceType
                ?.takeIf { it != DeviceType.UNKNOWN }
                ?: classifyDevice(resolvedHostname, probeResult.openPorts)

            val updatedDevice = ConnectedDevice(
                ip = ip,
                hostname = resolvedHostname,
                mac = probeResult.mac ?: existing?.mac,
                deviceType = deviceType,
                firstSeenTimestamp = existing?.firstSeenTimestamp ?: currentTime,
                lastSeenTimestamp = currentTime,
                status = DeviceStatus.CONNECTED,
                failedProbeCount = 0,
                latencyMs = probeResult.latencyMs,
                detectionMethod = probeResult.method,
                openPorts = probeResult.openPorts
            )
            deviceStateMap[ip] = updatedDevice
            updatedDevices.add(updatedDevice)
        }

        // 2. Handle previously seen devices that did not respond in this round (Anti-flapping)
        for ((ip, previousDevice) in deviceStateMap.toMap()) {
            if (!discoveredInThisRound.containsKey(ip)) {
                val newFailCount = previousDevice.failedProbeCount + 1

                val newStatus = when {
                    newFailCount < 2 -> DeviceStatus.CONNECTED // Still connected after 1 miss
                    newFailCount in 2..3 -> DeviceStatus.UNCONFIRMED // Unconfirmed after 2-3 misses
                    else -> DeviceStatus.DISCONNECTED // Marked disconnected after 4 consecutive misses
                }

                if (newFailCount > 4) {
                    deviceStateMap.remove(ip)
                } else {
                    val updatedDevice = previousDevice.copy(
                        failedProbeCount = newFailCount,
                        status = newStatus
                    )
                    deviceStateMap[ip] = updatedDevice
                    updatedDevices.add(updatedDevice)
                }
            }
        }

        return@withContext updatedDevices.filter { it.status != DeviceStatus.DISCONNECTED }
            .sortedBy { device ->
                device.ip.substringAfterLast('.').toIntOrNull() ?: 999
            }
    }

    /**
     * Probes an individual IP address using multiple protocols:
     * - Connected UDP socket (detects ICMP Port Unreachable from live hosts)
     * - mDNS query on UDP 5353 (extracts real name from Apple/Android/Smart TVs)
     * - NetBIOS query on UDP 137 (extracts Windows/Android computer names)
     * - TCP socket probe (detects open ports or RST connection refusal)
     */
    private fun probeHost(ip: String): ProbeResult? {
        val startTime = System.currentTimeMillis()
        var isAlive = false
        var probeMethod = "استجابة فحص الشبكة"
        val openPorts = mutableListOf<Int>()
        var hostname: String? = null

        // 1. Try mDNS Query (UDP 5353) - Very effective for iOS / Android / smart devices
        val mDnsName = queryMdns(ip)
        if (mDnsName != null) {
            isAlive = true
            hostname = mDnsName
            probeMethod = "استجابة بروتوكول mDNS/Bonjour"
        }

        // 2. Try NetBIOS Name Query (UDP 137) - Windows / Samba / Android
        if (!isAlive) {
            val netbiosName = queryNetBios(ip)
            if (netbiosName != null) {
                isAlive = true
                hostname = netbiosName
                probeMethod = "استجابة بروتوكول NetBIOS"
            }
        }

        // 3. Connected DatagramSocket probe (High UDP port)
        // If the host is live, its OS kernel sends back ICMP Port Unreachable!
        if (!isAlive) {
            try {
                val udpSocket = DatagramSocket()
                udpSocket.soTimeout = 120
                val targetAddr = InetAddress.getByName(ip)
                udpSocket.connect(InetSocketAddress(targetAddr, 38241))
                val probePayload = byteArrayOf(0x01, 0x02, 0x03, 0x04)
                udpSocket.send(DatagramPacket(probePayload, probePayload.size))
                try {
                    val recvBuf = ByteArray(32)
                    udpSocket.receive(DatagramPacket(recvBuf, recvBuf.size))
                    isAlive = true
                    probeMethod = "استجابة مقبس UDP"
                } catch (e: PortUnreachableException) {
                    // ICMP Port Unreachable received! Host is 100% active!
                    isAlive = true
                    probeMethod = "استجابة ICMP Port Unreachable (مؤكد)"
                } catch (_: Exception) {}
                finally {
                    try { udpSocket.close() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }

        // 4. Try TCP Socket connections to common ports
        if (!isAlive) {
            for (port in commonTcpPorts) {
                var socket: Socket? = null
                try {
                    socket = Socket()
                    socket.connect(InetSocketAddress(ip, port), 140)
                    isAlive = true
                    openPorts.add(port)
                    probeMethod = "منفذ مفتوح: $port"
                    break
                } catch (e: Exception) {
                    val msg = e.message ?: ""
                    // "Connection refused" indicates the host is ACTIVE and replied with TCP RST!
                    if (msg.contains("refused", ignoreCase = true) || msg.contains("econnrefused", ignoreCase = true)) {
                        isAlive = true
                        probeMethod = "استجابة رفض اتصال (المضيف نشط)"
                        break
                    }
                } finally {
                    try { socket?.close() } catch (_: Exception) {}
                }
            }
        }

        // 5. Try ICMP isReachable as final probe attempt
        if (!isAlive) {
            try {
                val inetAddr = InetAddress.getByName(ip)
                if (inetAddr.isReachable(150)) {
                    isAlive = true
                    probeMethod = "استجابة فحص ICMP"
                }
            } catch (_: Exception) {}
        }

        if (isAlive) {
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)

            // Resolve reverse DNS hostname if not already obtained from mDNS/NetBIOS
            if (hostname.isNullOrBlank()) {
                try {
                    val inet = InetAddress.getByName(ip)
                    val resolved = inet.canonicalHostName
                    if (!resolved.isNullOrBlank() && resolved != ip && !resolved.contains("unknown", ignoreCase = true)) {
                        hostname = resolved
                    }
                } catch (_: Exception) {}
            }

            return ProbeResult(
                ip = ip,
                hostname = hostname,
                latencyMs = latency,
                method = probeMethod,
                openPorts = openPorts
            )
        }

        return null
    }

    /**
     * Reads Linux kernel neighbor table via 'ip neigh' command and '/proc/net/arp'.
     */
    private fun readKernelNeighbors(
        subnetPrefix: String,
        gatewayIp: String?,
        discoveredMap: MutableMap<String, ProbeResult>
    ) {
        // Path 1: Execute 'ip neigh' command
        try {
            val process = Runtime.getRuntime().exec(arrayOf("ip", "neigh"))
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val row = line?.trim() ?: continue
                    parseIpNeighLine(row, subnetPrefix, gatewayIp, discoveredMap)
                }
            }
            process.waitFor()
        } catch (_: Exception) {
            // Try with full path /system/bin/ip
            try {
                val process = Runtime.getRuntime().exec(arrayOf("/system/bin/ip", "neigh"))
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val row = line?.trim() ?: continue
                        parseIpNeighLine(row, subnetPrefix, gatewayIp, discoveredMap)
                    }
                }
                process.waitFor()
            } catch (_: Exception) {}
        }

        // Path 2: Read /proc/net/arp directly if permitted
        try {
            val arpDoc = File("/proc/net/arp")
            if (arpDoc.exists() && arpDoc.canRead()) {
                BufferedReader(FileReader(arpDoc)).use { reader ->
                    var line: String?
                    var isHeader = true
                    while (reader.readLine().also { line = it } != null) {
                        if (isHeader) {
                            isHeader = false
                            continue
                        }
                        val parts = line?.trim()?.split("\\s+".toRegex()) ?: continue
                        if (parts.size >= 4) {
                            val ip = parts[0]
                            val flags = parts[2]
                            val mac = parts[3]

                            if (ip.startsWith(subnetPrefix) && ip != gatewayIp && flags != "0x0" && mac != "00:00:00:00:00:00") {
                                val existing = discoveredMap[ip]
                                discoveredMap[ip] = existing?.copy(mac = mac) ?: ProbeResult(
                                    ip = ip,
                                    hostname = null,
                                    mac = mac,
                                    latencyMs = 2,
                                    method = "سجل ARP النواة (مؤكد)",
                                    openPorts = emptyList()
                                )
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun parseIpNeighLine(
        row: String,
        subnetPrefix: String,
        gatewayIp: String?,
        discoveredMap: MutableMap<String, ProbeResult>
    ) {
        val tokens = row.split("\\s+".toRegex())
        if (tokens.size >= 4) {
            val ip = tokens[0]
            if (ip.startsWith(subnetPrefix) && ip != gatewayIp) {
                val isFailed = tokens.contains("FAILED")
                if (!isFailed) {
                    val lladdrIdx = tokens.indexOf("lladdr")
                    val mac = if (lladdrIdx != -1 && lladdrIdx + 1 < tokens.size) {
                        tokens[lladdrIdx + 1]
                    } else null

                    if (mac != null && mac != "00:00:00:00:00:00") {
                        val existing = discoveredMap[ip]
                        discoveredMap[ip] = existing?.copy(mac = mac) ?: ProbeResult(
                            ip = ip,
                            hostname = null,
                            mac = mac,
                            latencyMs = 2,
                            method = "سجل الجيران في النواة (ip neigh)",
                            openPorts = emptyList()
                        )
                    }
                }
            }
        }
    }

    /**
     * Sends a minimal mDNS query to targetIp:5353 and parses device name if returned.
     */
    private fun queryMdns(ip: String): String? {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            socket.soTimeout = 180

            // Standard mDNS PTR query for _services._dns-sd._udp.local
            val queryBytes = byteArrayOf(
                0x00, 0x00, // Transaction ID
                0x00, 0x00, // Flags
                0x00, 0x01, // Questions: 1
                0x00, 0x00, // Answer RRs
                0x00, 0x00, // Authority RRs
                0x00, 0x00, // Additional RRs
                0x09, '_'.code.toByte(), 's'.code.toByte(), 'e'.code.toByte(), 'r'.code.toByte(),
                'v'.code.toByte(), 'i'.code.toByte(), 'c'.code.toByte(), 'e'.code.toByte(), 's'.code.toByte(),
                0x07, '_'.code.toByte(), 'd'.code.toByte(), 'n'.code.toByte(), 's'.code.toByte(),
                '-'.code.toByte(), 's'.code.toByte(), 'd'.code.toByte(),
                0x04, '_'.code.toByte(), 'u'.code.toByte(), 'd'.code.toByte(), 'p'.code.toByte(),
                0x05, 'l'.code.toByte(), 'o'.code.toByte(), 'c'.code.toByte(), 'a'.code.toByte(), 'l'.code.toByte(),
                0x00,
                0x00, 0x0C, // Type: PTR
                0x00, 0x01  // Class: IN
            )

            val packet = DatagramPacket(queryBytes, queryBytes.size, InetAddress.getByName(ip), 5353)
            socket.send(packet)

            val recvBuf = ByteArray(512)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)

            if (recvPacket.length > 12) {
                val data = recvPacket.data
                val text = String(data, 12, recvPacket.length - 12, Charsets.UTF_8)
                val clean = text.filter { it.isLetterOrDigit() || it == '-' || it == '_' || it == ' ' }
                val match = clean.split("\\s+".toRegex()).firstOrNull { it.length in 3..25 }
                if (!match.isNullOrBlank() && !match.equals("local", ignoreCase = true)) {
                    return match
                }
                return "جهاز مفعّل لخدمة mDNS"
            }
        } catch (_: Exception) {}
        finally {
            try { socket?.close() } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Sends a minimal NetBIOS Node Status query to targetIp:137.
     */
    private fun queryNetBios(ip: String): String? {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            socket.soTimeout = 150

            val query = byteArrayOf(
                0x80.toByte(), 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x20, 0x43, 0x4B, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x00, 0x00, 0x21,
                0x00, 0x01
            )

            val packet = DatagramPacket(query, query.size, InetAddress.getByName(ip), 137)
            socket.send(packet)

            val recvBuf = ByteArray(256)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)

            if (recvPacket.length >= 57) {
                val nameBytes = recvPacket.data.copyOfRange(57, 57 + 15)
                val rawName = String(nameBytes, Charsets.US_ASCII).trim()
                if (rawName.isNotBlank()) {
                    return rawName
                }
            }
        } catch (_: Exception) {}
        finally {
            try { socket?.close() } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Classifies device type using hostname patterns or common open service ports.
     */
    private fun classifyDevice(hostname: String?, openPorts: List<Int>): DeviceType {
        val name = hostname?.lowercase() ?: ""
        return when {
            name.contains("iphone") || name.contains("android") ||
                    name.contains("galaxy") || name.contains("pixel") ||
                    name.contains("realme") || name.contains("redmi") ||
                    name.contains("oppo") || name.contains("huawei") ||
                    name.contains("xiaomi") -> DeviceType.PHONE

            name.contains("ipad") || name.contains("tablet") -> DeviceType.TABLET

            name.contains("macbook") || name.contains("laptop") ||
                    name.contains("desktop") || name.contains("pc") ||
                    name.contains("windows") || openPorts.contains(137) ||
                    openPorts.contains(22) -> DeviceType.LAPTOP

            name.contains("tv") || name.contains("cast") ||
                    name.contains("bravia") || name.contains("roku") ||
                    openPorts.contains(8008) -> DeviceType.TV

            name.contains("esp") || name.contains("cam") ||
                    name.contains("plug") || name.contains("printer") ||
                    name.contains("iot") -> DeviceType.IOT

            else -> DeviceType.UNKNOWN
        }
    }

    fun clearState() {
        deviceStateMap.clear()
    }

    private data class ProbeResult(
        val ip: String,
        val hostname: String?,
        val mac: String? = null,
        val latencyMs: Long,
        val method: String,
        val openPorts: List<Int>
    )
}
