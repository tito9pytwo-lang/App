package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DeviceHistoryEntity
import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.HotspotStatus
import com.example.data.repository.HotspotRepository
import com.example.service.HotspotMonitorService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HotspotViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HotspotRepository.getInstance(application)

    val hotspotStatus: StateFlow<HotspotStatus> = repository.hotspotStatus
    val connectedDevices: StateFlow<List<ConnectedDevice>> = repository.connectedDevices
    val isScanning: StateFlow<Boolean> = repository.isScanning
    val lastScanTime: StateFlow<Long> = repository.lastScanTime
    val isMonitoringActive: StateFlow<Boolean> = repository.isMonitoringActive
    val scanIntervalSeconds: StateFlow<Int> = repository.scanIntervalSeconds

    val historyDevices: StateFlow<List<DeviceHistoryEntity>> = repository.historyDevices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun startMonitoring() {
        // Start repository monitoring loop immediately in-app
        repository.startMonitoring()

        // Launch foreground service for persistent notification safely
        try {
            HotspotMonitorService.startService(getApplication())
        } catch (e: Exception) {
            Log.e("HotspotViewModel", "Failed to start HotspotMonitorService: ${e.message}")
        }
    }

    fun stopMonitoring() {
        try {
            HotspotMonitorService.stopService(getApplication())
        } catch (e: Exception) {
            Log.e("HotspotViewModel", "Failed to stop HotspotMonitorService: ${e.message}")
        }
        repository.stopMonitoring()
    }

    fun refreshManually() {
        viewModelScope.launch {
            try {
                repository.manualRefresh()
            } catch (e: Exception) {
                Log.e("HotspotViewModel", "Manual refresh error: ${e.message}")
            }
        }
    }

    fun setScanInterval(seconds: Int) {
        repository.setScanInterval(seconds)
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun getDiagnostics(): DetectionDiagnostics {
        return repository.getDiagnostics()
    }
}
