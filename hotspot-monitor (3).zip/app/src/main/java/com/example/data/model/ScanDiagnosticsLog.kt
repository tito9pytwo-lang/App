package com.example.data.model

enum class LogLevel(val arabicLabel: String) {
    INFO("معلومة"),
    SUCCESS("نجاح"),
    WARNING("تحذير"),
    ERROR("خطأ")
}

data class ScanLogEntry(
    val id: Long = System.nanoTime(),
    val timestamp: String,
    val level: LogLevel,
    val tag: String,
    val message: String
)

data class NetworkInterfaceInfo(
    val name: String,
    val ipAddress: String,
    val prefixLength: Int,
    val isUp: Boolean,
    val classification: String,
    val isHotspotCandidate: Boolean
)

data class ScanProgressState(
    val isScanning: Boolean = false,
    val progressPercent: Float = 0f,
    val currentPhase: String = "في انتظار بدء الفحص",
    val scannedHosts: Int = 0,
    val totalHosts: Int = 0,
    val foundInCurrentRound: Int = 0,
    val lastError: String? = null,
    val errorCount: Int = 0,
    val warningCount: Int = 0
)
