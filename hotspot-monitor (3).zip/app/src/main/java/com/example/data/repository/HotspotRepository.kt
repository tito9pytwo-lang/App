package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.DeviceHistoryEntity
import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.DeviceStatus
import com.example.data.model.HotspotStatus
import com.example.data.model.LogLevel
import com.example.data.model.ScanLogEntry
import com.example.data.model.ScanProgressState
import com.example.data.scanner.HotspotDetector
import com.example.data.scanner.LocalSubnetScanner
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HotspotRepository private constructor(private val context: Context) {

    private val database = AppDatabase.getInstance(context)
    private val historyDao = database.deviceHistoryDao()

    private val detector = HotspotDetector(context)
    private val scanner = LocalSubnetScanner()

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        val msg = throwable.localizedMessage ?: throwable.javaClass.simpleName
        Log.e("HotspotRepo", "Unhandled coroutine error: $msg", throwable)
        appendLog(LogLevel.ERROR, "النظام", "خطأ غير متوقع: $msg")
        _scanProgress.value = _scanProgress.value.copy(
            isScanning = false,
            lastError = msg
        )
    }

    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob() + exceptionHandler)
    private var scanLoopJob: Job? = null

    // State Flows
    private val _hotspotStatus = MutableStateFlow(HotspotStatus())
    val hotspotStatus: StateFlow<HotspotStatus> = _hotspotStatus.asStateFlow()

    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices: StateFlow<List<ConnectedDevice>> = _connectedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _lastScanTime = MutableStateFlow(0L)
    val lastScanTime: StateFlow<Long> = _lastScanTime.asStateFlow()

    private val _isMonitoringActive = MutableStateFlow(false)
    val isMonitoringActive: StateFlow<Boolean> = _isMonitoringActive.asStateFlow()

    private val _scanIntervalSeconds = MutableStateFlow(5)
    val scanIntervalSeconds: StateFlow<Int> = _scanIntervalSeconds.asStateFlow()

    private val _scanProgress = MutableStateFlow(ScanProgressState())
    val scanProgress: StateFlow<ScanProgressState> = _scanProgress.asStateFlow()

    private val _scanLogs = MutableStateFlow<List<ScanLogEntry>>(emptyList())
    val scanLogs: StateFlow<List<ScanLogEntry>> = _scanLogs.asStateFlow()

    val historyDevices: Flow<List<DeviceHistoryEntity>> = historyDao.getAllHistory()

    // Listeners for device events (join / leave)
    var onDeviceJoined: ((ConnectedDevice) -> Unit)? = null
    var onDeviceLeft: ((ConnectedDevice) -> Unit)? = null

    init {
        repositoryScope.launch {
            detector.observeHotspotState().collect { status ->
                _hotspotStatus.value = status
            }
        }
    }

    fun appendLog(level: LogLevel, tag: String, message: String) {
        val entry = ScanLogEntry(
            timestamp = timeFormat.format(Date()),
            level = level,
            tag = tag,
            message = message
        )
        val current = _scanLogs.value.toMutableList()
        current.add(0, entry) // Newest first
        if (current.size > 150) {
            current.subList(150, current.size).clear()
        }
        _scanLogs.value = current

        val errors = current.count { it.level == LogLevel.ERROR }
        val warnings = current.count { it.level == LogLevel.WARNING }
        _scanProgress.value = _scanProgress.value.copy(
            errorCount = errors,
            warningCount = warnings,
            lastError = if (level == LogLevel.ERROR) message else _scanProgress.value.lastError
        )
    }

    fun clearLogs() {
        _scanLogs.value = emptyList()
        _scanProgress.value = _scanProgress.value.copy(
            errorCount = 0,
            warningCount = 0,
            lastError = null
        )
    }

    fun reportServiceError(message: String) {
        appendLog(LogLevel.ERROR, "خدمة الخلفية", message)
    }

    fun setScanInterval(seconds: Int) {
        _scanIntervalSeconds.value = seconds.coerceIn(2, 60)
    }

    fun startMonitoring() {
        if (_isMonitoringActive.value) return
        _isMonitoringActive.value = true
        appendLog(LogLevel.INFO, "المراقبة", "تم تفعيل وضع المراقبة المستمرة (كل ${_scanIntervalSeconds.value} ثوانٍ)")

        scanLoopJob?.cancel()
        scanLoopJob = repositoryScope.launch {
            while (isActive && _isMonitoringActive.value) {
                try {
                    runScanCycle()
                } catch (e: Exception) {
                    val err = e.localizedMessage ?: e.javaClass.simpleName
                    Log.e("HotspotRepo", "Loop iteration error: $err")
                    appendLog(LogLevel.ERROR, "دورة المراقبة", "تعذر إتمام دورة الفحص: $err")
                }

                val waitTime = (_scanIntervalSeconds.value * 1000L).coerceAtLeast(2000L)
                delay(waitTime)
            }
        }
    }

    fun stopMonitoring() {
        _isMonitoringActive.value = false
        scanLoopJob?.cancel()
        scanLoopJob = null
        _isScanning.value = false
        _scanProgress.value = _scanProgress.value.copy(
            isScanning = false,
            currentPhase = "تم إيقاف المراقبة"
        )
        appendLog(LogLevel.INFO, "المراقبة", "تم إيقاف المراقبة المستمرة")
    }

    suspend fun manualRefresh() = withContext(Dispatchers.IO) {
        appendLog(LogLevel.INFO, "تحديث يدوي", "بدء فحص فوري للشبكة بناءً على طلب المستخدم")
        runScanCycle()
    }

    private suspend fun runScanCycle() {
        if (_isScanning.value) return
        _isScanning.value = true
        _scanProgress.value = _scanProgress.value.copy(
            isScanning = true,
            progressPercent = 0.05f,
            currentPhase = "فحص واجهات الشبكة ونقطة الاتصال...",
            scannedHosts = 0,
            totalHosts = 253
        )

        try {
            val inspection = detector.inspectHotspot()
            val status = inspection.status
            _hotspotStatus.value = status

            for ((level, tag, msg) in inspection.diagnosticMessages) {
                appendLog(level, tag, msg)
            }

            val prefix = status.subnetPrefix
            val gateway = status.gatewayIp ?: "$prefix.1"

            val previousIps = _connectedDevices.value.map { it.ip }.toSet()
            val newDevices = scanner.scanSubnet(
                subnetPrefix = prefix,
                gatewayIp = gateway,
                hotspotInterface = inspection.activeNetworkInterface,
                onProgress = { scanned, total, phase, found ->
                    val pct = if (total > 0) (scanned.toFloat() / total.toFloat()).coerceIn(0.05f, 1f) else 0f
                    _scanProgress.value = _scanProgress.value.copy(
                        isScanning = true,
                        progressPercent = pct,
                        currentPhase = phase,
                        scannedHosts = scanned,
                        totalHosts = total,
                        foundInCurrentRound = found
                    )
                },
                onLog = { level, tag, msg ->
                    appendLog(level, tag, msg)
                }
            )

            val currentIps = newDevices.map { it.ip }.toSet()

            // If active devices were discovered, Hotspot is guaranteed enabled
            if (newDevices.isNotEmpty() && !_hotspotStatus.value.isEnabled) {
                _hotspotStatus.value = _hotspotStatus.value.copy(
                    isEnabled = true,
                    detectionMethod = "اكتشاف أجهزة نشطة على النطاق $prefix"
                )
            }

            // Detect new devices
            for (dev in newDevices) {
                if (!previousIps.contains(dev.ip) && dev.status == DeviceStatus.CONNECTED) {
                    onDeviceJoined?.invoke(dev)
                }
            }

            // Detect left devices
            for (oldDev in _connectedDevices.value) {
                if (!currentIps.contains(oldDev.ip)) {
                    onDeviceLeft?.invoke(oldDev)
                }
            }

            _connectedDevices.value = newDevices
            _lastScanTime.value = System.currentTimeMillis()
            _scanProgress.value = _scanProgress.value.copy(
                isScanning = false,
                progressPercent = 1f,
                currentPhase = if (newDevices.isNotEmpty()) {
                    "اكتمل الفحص • تم العثور على ${newDevices.size} جهاز"
                } else {
                    "اكتمل الفحص • لم يتم العثور على أجهزة متصلة"
                },
                foundInCurrentRound = newDevices.size
            )

            persistToHistory(newDevices)

        } catch (e: Exception) {
            val err = e.localizedMessage ?: e.javaClass.simpleName
            Log.e("HotspotRepo", "Scan error: $err", e)
            appendLog(LogLevel.ERROR, "فحص الشبكة", "فشل الفحص بسبب خطأ: $err")
            _scanProgress.value = _scanProgress.value.copy(
                isScanning = false,
                currentPhase = "فشل الفحص: $err",
                lastError = err
            )
        } finally {
            _isScanning.value = false
        }
    }

    private suspend fun persistToHistory(devices: List<ConnectedDevice>) {
        for (device in devices) {
            try {
                val existing = historyDao.getDeviceByIp(device.ip)
                if (existing != null) {
                    historyDao.update(
                        existing.copy(
                            hostname = device.hostname ?: existing.hostname,
                            deviceType = device.deviceType.name,
                            lastSeenTimestamp = device.lastSeenTimestamp,
                            appearanceCount = existing.appearanceCount + 1,
                            lastLatencyMs = device.latencyMs
                        )
                    )
                } else {
                    historyDao.insert(
                        DeviceHistoryEntity(
                            ip = device.ip,
                            hostname = device.hostname,
                            deviceType = device.deviceType.name,
                            firstSeenTimestamp = device.firstSeenTimestamp,
                            lastSeenTimestamp = device.lastSeenTimestamp,
                            appearanceCount = 1,
                            lastLatencyMs = device.latencyMs
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("HotspotRepo", "DB insert error: ${e.message}")
            }
        }
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        historyDao.clearAll()
    }

    fun getDiagnostics(): DetectionDiagnostics {
        val status = _hotspotStatus.value
        val gateway = status.gatewayIp ?: "192.168.43.1"
        val prefix = status.subnetPrefix

        return DetectionDiagnostics(
            currentMethod = "فحص متعدد: واجهات النظام + بث mDNS + ICMP + TCP RST + UDP",
            activeInterface = status.interfaceName ?: "لم تُحدد بعد",
            gatewayIp = gateway,
            subnetRange = "$prefix.1 - $prefix.254",
            reliabilityLevel = if (status.isEnabled || _connectedDevices.value.isNotEmpty()) "عالي ومباشر للأجهزة النشطة" else "في وضع الاستعداد"
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: HotspotRepository? = null

        fun getInstance(context: Context): HotspotRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = HotspotRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
