package com.example.data.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import com.example.data.model.HotspotStatus
import com.example.data.model.LogLevel
import com.example.data.model.NetworkInterfaceInfo
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.net.Inet4Address
import java.net.NetworkInterface

class HotspotDetector(private val context: Context) {

    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val connectivityManager: ConnectivityManager? =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    data class DetectionResult(
        val status: HotspotStatus,
        val activeNetworkInterface: NetworkInterface?,
        val diagnosticMessages: List<Triple<LogLevel, String, String>>
    )

    fun checkHotspotStatus(): HotspotStatus = inspectHotspot().status

    /**
     * Performs comprehensive inspection of ConnectivityManager, WifiManager, and NetworkInterfaces
     * to detect Android 10-15 randomized hotspot subnets (10.x.x.x / 192.168.x.x / 172.16.x.x)
     * and realme/Unisoc AP interfaces (including wlan0 single-interface AP mode).
     */
    fun inspectHotspot(): DetectionResult {
        val messages = mutableListOf<Triple<LogLevel, String, String>>()
        val interfaceInfos = mutableListOf<NetworkInterfaceInfo>()

        var isApEnabledFlag = false
        val tetheredIfacesSet = mutableSetOf<String>()
        var tetheredIfaceHint: String? = null
        var detectionMethod = "فحص واجهات الشبكة المباشرة"

        // 1. Identify active STA Wi-Fi (with Internet), Cellular, and VPN interface names via ConnectivityManager
        val wifiStaWithInternet = mutableSetOf<String>()
        val wifiTransportInterfaces = mutableSetOf<String>()
        val cellularInterfaces = mutableSetOf<String>()
        val vpnInterfaces = mutableSetOf<String>()

        try {
            if (connectivityManager != null) {
                @Suppress("DEPRECATION")
                val networks = connectivityManager.allNetworks
                for (net in networks) {
                    val caps = connectivityManager.getNetworkCapabilities(net) ?: continue
                    val props = connectivityManager.getLinkProperties(net) ?: continue
                    val ifName = props.interfaceName?.lowercase() ?: continue

                    when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                            wifiTransportInterfaces.add(ifName)
                            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                                wifiStaWithInternet.add(ifName)
                            }
                        }
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> cellularInterfaces.add(ifName)
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> vpnInterfaces.add(ifName)
                    }
                }
            }
        } catch (e: Exception) {
            messages.add(Triple(LogLevel.WARNING, "الشبكة", "تعذر قراءة ConnectivityManager: ${e.message}"))
        }

        // 2. Check ConnectivityManager.getTetheredIfaces() via reflection
        try {
            if (connectivityManager != null) {
                val method = connectivityManager.javaClass.getDeclaredMethod("getTetheredIfaces")
                method.isAccessible = true
                val tetheredIfaces = method.invoke(connectivityManager) as? Array<*>
                if (!tetheredIfaces.isNullOrEmpty()) {
                    isApEnabledFlag = true
                    tetheredIfaces.mapNotNull { it?.toString()?.trim() }
                        .filter { it.isNotEmpty() }
                        .forEach {
                            tetheredIfacesSet.add(it.lowercase())
                            if (tetheredIfaceHint == null) tetheredIfaceHint = it
                        }
                    detectionMethod = "واجهة التوصيل النظامية: ${tetheredIfaces.joinToString()}"
                    messages.add(Triple(LogLevel.SUCCESS, "TetherAPI", "تم رصد واجهة نقطة اتصال: ${tetheredIfaces.joinToString()}"))
                }
            }
        } catch (e: Exception) {
            messages.add(Triple(LogLevel.INFO, "TetherAPI", "واجهة getTetheredIfaces مقيدة (${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName})"))
        }

        // 3. Check WifiManager.getWifiApState() reflection (13 = ENABLED, 12 = ENABLING)
        if (wifiManager != null) {
            try {
                val stateMethod = wifiManager.javaClass.getDeclaredMethod("getWifiApState")
                stateMethod.isAccessible = true
                val state = stateMethod.invoke(wifiManager) as? Int
                if (state == 13 || state == 12) {
                    isApEnabledFlag = true
                    detectionMethod = "حالة WifiManager ($state)"
                    messages.add(Triple(LogLevel.SUCCESS, "WifiAP", "حالة نقطة الاتصال مفعّلة في النظام ($state)"))
                } else if (state != null) {
                    messages.add(Triple(LogLevel.INFO, "WifiAP", "حالة WifiManager AP = $state"))
                }
            } catch (_: Exception) {
                messages.add(Triple(LogLevel.INFO, "WifiAP", "getWifiApState مقيدة في هذا الإصدار"))
            }

            if (!isApEnabledFlag) {
                try {
                    val isApEnabledMethod = wifiManager.javaClass.getDeclaredMethod("isWifiApEnabled")
                    isApEnabledMethod.isAccessible = true
                    val result = isApEnabledMethod.invoke(wifiManager) as? Boolean
                    if (result == true) {
                        isApEnabledFlag = true
                        detectionMethod = "استعلام isWifiApEnabled النظامي"
                        messages.add(Triple(LogLevel.SUCCESS, "WifiAP", "isWifiApEnabled = true"))
                    }
                } catch (_: Exception) {}
            }
        }

        // 4. Enumerate ALL NetworkInterfaces to find the true Hotspot IP & subnet
        var selectedHotspotIface: NetworkInterface? = null
        var selectedIp: String? = null
        var selectedPrefixLen = 24
        var bestScore = -1

        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            for (iface in interfaces) {
                val rawName = iface.name ?: continue
                val name = rawName.lowercase()
                if (iface.isLoopback || name == "lo") continue

                val isUp = try { iface.isUp } catch (_: Exception) { false }

                for (ifaceAddr in iface.interfaceAddresses) {
                    val addr = ifaceAddr.address
                    if (addr !is Inet4Address || addr.isLoopbackAddress) continue
                    val hostAddr = addr.hostAddress ?: continue
                    val prefixLen = ifaceAddr.networkPrefixLength.toInt().let { if (it in 8..30) it else 24 }

                    val isCellularName = cellularInterfaces.contains(name) ||
                            name.startsWith("rmnet") ||
                            name.startsWith("ccmni") ||
                            name.startsWith("seth") ||
                            name.startsWith("clat") ||
                            name.startsWith("v4-") ||
                            name.startsWith("pdp") ||
                            name.startsWith("wwan") ||
                            name.startsWith("ims")

                    val isVpnName = vpnInterfaces.contains(name) ||
                            name.startsWith("tun") ||
                            name.startsWith("tap") ||
                            name.startsWith("ppp") ||
                            name.startsWith("ipsec")

                    // CRITICAL: If ConnectivityManager.getTetheredIfaces() explicitly lists this interface
                    // (e.g., "wlan0" on realme RMX3760 / Unisoc), it MUST take precedence over TRANSPORT_WIFI!
                    val isConfirmedTethered = tetheredIfacesSet.contains(name)

                    val isWifiStaWithNet = wifiStaWithInternet.contains(name) && !isConfirmedTethered
                    val isWifiTransportOnly = wifiTransportInterfaces.contains(name) && !isConfirmedTethered

                    val isExplicitApName = name.startsWith("ap") ||
                            name.startsWith("softap") ||
                            name.startsWith("swlan") ||
                            name.startsWith("wlan1") ||
                            name.startsWith("wlan2") ||
                            name.startsWith("ap_br") ||
                            name.startsWith("bridge") ||
                            name.startsWith("uap") ||
                            name.startsWith("rndis") ||
                            name.startsWith("usb") ||
                            name.contains("tether")

                    val isPrivateIp = isPrivateIpv4(hostAddr)
                    val isWlanApFallback = name.startsWith("wlan") && isApEnabledFlag && !isWifiStaWithNet && isPrivateIp

                    val classification: String
                    var candidateScore = -1

                    when {
                        isCellularName -> classification = "شبكة الجوال (مستبعدة)"
                        isVpnName -> classification = "شبكة VPN (مستبعدة)"
                        !isUp -> classification = "واجهة غير نشطة (Down)"
                        isConfirmedTethered && isPrivateIp -> {
                            classification = "نقطة اتصال مؤكدة (Tethered Hotspot AP)"
                            candidateScore = 150
                        }
                        isExplicitApName && isPrivateIp && !isWifiStaWithNet -> {
                            classification = "نقطة اتصال مؤكدة (Hotspot AP)"
                            candidateScore = 110
                        }
                        isWlanApFallback -> {
                            classification = "واجهة Wi-Fi في وضع نقطة الاتصال"
                            candidateScore = 95
                        }
                        isWifiStaWithNet || isWifiTransportOnly -> {
                            classification = "واجهة Wi-Fi عميل (متصلة براوتر)"
                        }
                        isPrivateIp && !name.startsWith("dummy") && !name.startsWith("sit") -> {
                            classification = "واجهة محلية مرشحة للـ Hotspot"
                            candidateScore = 60
                        }
                        else -> classification = "واجهة أخرى"
                    }

                    val isCandidate = candidateScore > 0
                    interfaceInfos.add(
                        NetworkInterfaceInfo(
                            name = rawName,
                            ipAddress = hostAddr,
                            prefixLength = prefixLen,
                            isUp = isUp,
                            classification = classification,
                            isHotspotCandidate = isCandidate
                        )
                    )

                    if (isCandidate && candidateScore > bestScore) {
                        bestScore = candidateScore
                        selectedHotspotIface = iface
                        selectedIp = hostAddr
                        selectedPrefixLen = prefixLen
                        detectionMethod = "واجهة $rawName ($hostAddr/$prefixLen)"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("HotspotDetector", "Interface scan error: ${e.message}")
            messages.add(Triple(LogLevel.ERROR, "الواجهات", "خطأ أثناء قراءة واجهات الشبكة: ${e.message}"))
        }

        val isEnabled = isApEnabledFlag || selectedHotspotIface != null
        val resolvedGateway = selectedIp ?: "192.168.43.1"
        val resolvedSubnet = resolvedGateway.substringBeforeLast('.')

        if (selectedHotspotIface != null) {
            messages.add(
                Triple(
                    LogLevel.SUCCESS,
                    "الواجهة",
                    "تم تحديد واجهة نقطة الاتصال: ${selectedHotspotIface.name} • البوابة: $resolvedGateway/$selectedPrefixLen"
                )
            )
        } else if (isApEnabledFlag) {
            messages.add(
                Triple(
                    LogLevel.WARNING,
                    "الواجهة",
                    "نقطة الاتصال مفعّلة ولكن لم تُقرأ واجهة IP صريحة، سيتم فحص النطاق الافتراضي $resolvedSubnet.x"
                )
            )
        } else {
            messages.add(
                Triple(
                    LogLevel.WARNING,
                    "الواجهة",
                    "لم يتم العثور على واجهة Hotspot نشطة حالياً (عدد الواجهات المفحوصة: ${interfaceInfos.size}). تأكد من تشغيل نقطة الاتصال."
                )
            )
        }

        val status = HotspotStatus(
            isEnabled = isEnabled,
            interfaceName = selectedHotspotIface?.name ?: tetheredIfaceHint,
            gatewayIp = resolvedGateway,
            subnetPrefix = resolvedSubnet,
            prefixLength = selectedPrefixLen,
            detectionMethod = detectionMethod,
            detectedInterfaces = interfaceInfos,
            lastCheckedTimestamp = System.currentTimeMillis()
        )

        return DetectionResult(
            status = status,
            activeNetworkInterface = selectedHotspotIface,
            diagnosticMessages = messages
        )
    }

    private fun isPrivateIpv4(ip: String): Boolean {
        val parts = ip.split(".").mapNotNull { it.toIntOrNull() }
        if (parts.size != 4) return false
        return when {
            parts[0] == 192 && parts[1] == 168 -> true
            parts[0] == 10 -> true
            parts[0] == 172 && parts[1] in 16..31 -> true
            else -> false
        }
    }

    /**
     * Emits Hotspot status updates via broadcast intents and network state changes.
     */
    fun observeHotspotState(): Flow<HotspotStatus> = callbackFlow {
        trySend(checkHotspotStatus())

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                trySend(checkHotspotStatus())
            }
        }

        val filter = IntentFilter().apply {
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction("android.net.conn.TETHER_STATE_CHANGED")
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            @Suppress("DEPRECATION")
            addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
        } catch (_: Exception) {
            try {
                context.registerReceiver(receiver, filter)
            } catch (e: Exception) {
                Log.w("HotspotDetector", "Receiver registration error: ${e.message}")
            }
        }

        awaitClose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
        }
    }
}
