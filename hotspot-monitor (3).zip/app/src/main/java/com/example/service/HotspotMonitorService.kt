package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.LogLevel
import com.example.data.repository.HotspotRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HotspotMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var repository: HotspotRepository
    private lateinit var notificationManager: NotificationManager

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate() {
        super.onCreate()
        repository = HotspotRepository.getInstance(applicationContext)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        createNotificationChannels()

        repository.onDeviceJoined = { device ->
            sendDeviceAlert(
                title = "جهاز جديد متصل بنقطة الاتصال",
                message = "${device.displayName} (${device.ip}) انضم للشبكة الآن",
                notificationId = device.ip.hashCode()
            )
        }

        repository.onDeviceLeft = { device ->
            sendDeviceAlert(
                title = "مغادرة جهاز من نقطة الاتصال",
                message = "${device.displayName} (${device.ip}) غادر الشبكة",
                notificationId = device.ip.hashCode() + 1
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_STOP_MONITORING) {
            try {
                repository.stopMonitoring()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } catch (e: Throwable) {
                Log.e("HotspotService", "Error stopping foreground: ${e.message}")
            }
            return START_NOT_STICKY
        }

        val initialNotification = buildNotification(
            deviceCount = repository.connectedDevices.value.size,
            isHotspotEnabled = repository.hotspotStatus.value.isEnabled,
            lastUpdate = "جاري البدء..."
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, initialNotification, 0)
            } else {
                startForeground(NOTIFICATION_ID, initialNotification)
            }
            repository.appendLog(LogLevel.SUCCESS, "خدمة الخلفية", "تم تشغيل خدمة الإشعار الدائم بنجاح")
        } catch (e: Throwable) {
            val msg = "تعذر تشغيل ForegroundService: ${e.localizedMessage ?: e.javaClass.simpleName}"
            Log.e("HotspotService", msg, e)
            repository.reportServiceError(msg)
            try {
                startForeground(NOTIFICATION_ID, initialNotification)
            } catch (e2: Throwable) {
                repository.reportServiceError("المحاولة البديلة لخدمة الخلفية فشلت: ${e2.localizedMessage}")
            }
        }

        repository.startMonitoring()

        serviceScope.launch {
            combine(
                repository.connectedDevices,
                repository.hotspotStatus,
                repository.lastScanTime
            ) { devices, status, lastScanTime ->
                Triple(devices.size, status.isEnabled, lastScanTime)
            }.collect { (count, isEnabled, lastScanTime) ->
                try {
                    val timeStr = if (lastScanTime > 0) timeFormat.format(Date(lastScanTime)) else "الآن"
                    val updatedNotification = buildNotification(count, isEnabled, timeStr)
                    notificationManager.notify(NOTIFICATION_ID, updatedNotification)
                } catch (e: Throwable) {
                    Log.e("HotspotService", "Notify update error: ${e.message}")
                }
            }
        }

        return START_STICKY
    }

    private fun buildNotification(
        deviceCount: Int,
        isHotspotEnabled: Boolean,
        lastUpdate: String
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, HotspotMonitorService::class.java).apply {
            action = ACTION_STOP_MONITORING
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (isHotspotEnabled || deviceCount > 0) {
            "$deviceCount أجهزة متصلة بنقطة الاتصال"
        } else {
            "المراقبة نشطة (جاري فحص نقطة الاتصال)"
        }

        return NotificationCompat.Builder(this, CHANNEL_MONITOR_ID)
            .setSmallIcon(R.drawable.ic_stat_hotspot)
            .setContentTitle("Hotspot Monitor")
            .setContentText("$statusText • آخر تحديث: $lastUpdate")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    if (isHotspotEnabled || deviceCount > 0) {
                        "حالة نقطة الاتصال: مفعّلة\nعدد الأجهزة المتصلة: $deviceCount\nآخر فحص: $lastUpdate"
                    } else {
                        "المراقبة نشطة بانتظار اتصال الأجهزة.\nالتطبيق يقوم بفحص الشبكة بانتظام."
                    }
                )
            )
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                0,
                "إيقاف المراقبة",
                stopPendingIntent
            )
            .build()
    }

    private fun sendDeviceAlert(title: String, message: String, notificationId: Int) {
        try {
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                notificationId,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alert = NotificationCompat.Builder(this, CHANNEL_ALERTS_ID)
                .setSmallIcon(R.drawable.ic_stat_hotspot)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(openAppPendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()

            notificationManager.notify(notificationId, alert)
        } catch (e: Throwable) {
            Log.e("HotspotService", "Error sending alert: ${e.message}")
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val monitorChannel = NotificationChannel(
                CHANNEL_MONITOR_ID,
                "مراقبة نقطة الاتصال الدائمة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار دائم يوضح حالة نقطة الاتصال وعدد الأجهزة المتصلة"
                setShowBadge(false)
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS_ID,
                "تنبيهات انضمام ومغادرة الأجهزة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تنبيه عند اتصال جهاز جديد أو مغادرته نقطة الاتصال"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(monitorChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_MONITOR_ID = "hotspot_monitor_permanent_channel"
        const val CHANNEL_ALERTS_ID = "hotspot_device_alerts_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_MONITORING = "com.example.service.START_MONITORING"
        const val ACTION_STOP_MONITORING = "com.example.service.STOP_MONITORING"

        fun startService(context: Context) {
            val intent = Intent(context, HotspotMonitorService::class.java).apply {
                action = ACTION_START_MONITORING
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, HotspotMonitorService::class.java).apply {
                action = ACTION_STOP_MONITORING
            }
            context.startService(intent)
        }
    }
}
