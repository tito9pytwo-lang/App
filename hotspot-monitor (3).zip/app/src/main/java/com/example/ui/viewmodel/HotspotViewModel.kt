package com.example.ui.viewmodel

import android.app.Application
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DeviceHistoryEntity
import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.HotspotStatus
import com.example.data.model.ScanLogEntry
import com.example.data.model.ScanProgressState
import com.example.data.repository.HotspotRepository
import com.example.service.HotspotMonitorService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HotspotViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HotspotRepository.getInstance(application)

    val hotspotStatus: StateFlow<HotspotStatus> = repository.hotspotStatus
    val connectedDevices: StateFlow<List<ConnectedDevice>> = repository.connectedDevices
    val isScanning: StateFlow<Boolean> = repository.isScanning
    val lastScanTime: StateFlow<Long> = repository.lastScanTime
    val isMonitoringActive: StateFlow<Boolean> = repository.isMonitoringActive
    val scanIntervalSeconds: StateFlow<Int> = repository.scanIntervalSeconds
    val scanProgress: StateFlow<ScanProgressState> = repository.scanProgress
    val scanLogs: StateFlow<List<ScanLogEntry>> = repository.scanLogs

    val historyDevices: StateFlow<List<DeviceHistoryEntity>> = repository.historyDevices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun startMonitoring() {
        repository.startMonitoring()
        try {
            HotspotMonitorService.startService(getApplication())
        } catch (e: Throwable) {
            val err = e.localizedMessage ?: e.javaClass.simpleName
            Log.e("HotspotViewModel", "Failed to start HotspotMonitorService: $err")
            repository.reportServiceError("فشل بدء خدمة الإشعار الدائم: $err (المراقبة داخل التطبيق مستمرة)")
        }
    }

    fun stopMonitoring() {
        try {
            HotspotMonitorService.stopService(getApplication())
        } catch (e: Throwable) {
            Log.e("HotspotViewModel", "Failed to stop HotspotMonitorService: ${e.message}")
        }
        repository.stopMonitoring()
    }

    fun refreshManually() {
        viewModelScope.launch {
            try {
                repository.manualRefresh()
            } catch (e: Throwable) {
                val err = e.localizedMessage ?: e.javaClass.simpleName
                Log.e("HotspotViewModel", "Manual refresh error: $err")
                repository.reportServiceError("خطأ أثناء الفحص اليدوي: $err")
            }
        }
    }

    fun setScanInterval(seconds: Int) {
        repository.setScanInterval(seconds)
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun clearLogs() {
        repository.clearLogs()
    }

    fun getDiagnostics(): DetectionDiagnostics {
        return repository.getDiagnostics()
    }

    fun buildCopyableReport(): String {
        val status = hotspotStatus.value
        val progress = scanProgress.value
        val devices = connectedDevices.value
        val logs = scanLogs.value

        return buildString {
            appendLine("=== Hotspot Monitor Diagnostic Report ===")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, SDK ${Build.VERSION.SDK_INT})")
            appendLine("Hotspot Enabled: ${status.isEnabled}")
            appendLine("Interface: ${status.interfaceName ?: "None"} | Gateway: ${status.gatewayIp ?: "None"} | Subnet: ${status.subnetPrefix}.x/${status.prefixLength}")
            appendLine("Progress: ${(progress.progressPercent * 100).toInt()}% | Phase: ${progress.currentPhase}")
            appendLine("Connected Devices Count: ${devices.size}")
            devices.forEach { d ->
                appendLine("  - ${d.ip} | ${d.displayName} | ${d.status.arabicLabel} | ${d.detectionMethod}")
            }
            appendLine("--- Detected Network Interfaces ---")
            status.detectedInterfaces.forEach { iface ->
                appendLine("  * ${iface.name}: ${iface.ipAddress}/${iface.prefixLength} [up=${iface.isUp}] -> ${iface.classification}")
            }
            appendLine("--- Execution Logs (${logs.size}) ---")
            logs.take(50).forEach { log ->
                appendLine("[${log.timestamp}] [${log.level.name}] [${log.tag}] ${log.message}")
            }
        }
    }
}
