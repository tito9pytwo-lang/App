package com.example

import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.DeviceType
import com.example.data.model.HotspotStatus
import com.example.data.model.LogLevel
import com.example.data.model.NetworkInterfaceInfo
import com.example.data.model.ScanLogEntry
import com.example.data.model.ScanProgressState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testDeviceDisplayName() {
    val deviceWithHost = ConnectedDevice(
      ip = "192.168.187.120",
      hostname = "realme_C53_guest",
      deviceType = DeviceType.PHONE
    )
    assertEquals("realme_C53_guest", deviceWithHost.displayName)

    val deviceWithoutHost = ConnectedDevice(
      ip = "192.168.187.121",
      hostname = null,
      deviceType = DeviceType.UNKNOWN
    )
    assertEquals("جهاز متصل (121)", deviceWithoutHost.displayName)
  }

  @Test
  fun testDeviceFormattedMac() {
    val device = ConnectedDevice(
      ip = "192.168.43.50",
      mac = null
    )
    assertTrue(device.formattedMac.contains("Android 15"))
  }

  @Test
  fun testHotspotStatusRandomizedSubnetSupport() {
    val iface = NetworkInterfaceInfo(
      name = "ap_br_wlan2",
      ipAddress = "192.168.214.129",
      prefixLength = 24,
      isUp = true,
      classification = "نقطة اتصال مؤكدة (Hotspot AP)",
      isHotspotCandidate = true
    )
    val status = HotspotStatus(
      isEnabled = true,
      interfaceName = iface.name,
      gatewayIp = iface.ipAddress,
      subnetPrefix = "192.168.214",
      prefixLength = 24,
      detectedInterfaces = listOf(iface)
    )
    assertTrue(status.isEnabled)
    assertEquals("192.168.214", status.subnetPrefix)
    assertEquals("192.168.214.129", status.gatewayIp)
    assertEquals(1, status.detectedInterfaces.size)
  }

  @Test
  fun testScanProgressAndErrorLogModels() {
    val progress = ScanProgressState(
      isScanning = true,
      progressPercent = 0.5f,
      currentPhase = "جاري فحص الشبكة",
      scannedHosts = 127,
      totalHosts = 253,
      foundInCurrentRound = 2,
      errorCount = 1,
      warningCount = 1
    )
    assertEquals(0.5f, progress.progressPercent)
    assertEquals(2, progress.foundInCurrentRound)

    val log = ScanLogEntry(
      timestamp = "12:00:00",
      level = LogLevel.ERROR,
      tag = "ARP",
      message = "Permission denied"
    )
    assertEquals(LogLevel.ERROR, log.level)
    assertEquals("خطأ", log.level.arabicLabel)
  }

  @Test
  fun testDiagnosticsTransparency() {
    val diag = DetectionDiagnostics()
    assertNotNull(diag.android15RestrictionsExplanation)
    assertTrue(diag.android15RestrictionsExplanation.contains("SELinux"))
    assertTrue(diag.android15RestrictionsExplanation.contains("/proc/net/arp"))
  }
}
