package com.example.data.scanner

import com.example.data.model.ConnectedDevice
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.LogLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.NoRouteToHostException
import java.net.PortUnreachableException
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class LocalSubnetScanner {

    private val enrichmentTcpPorts = intArrayOf(80, 443, 8080, 53, 5353, 62078, 8008, 22, 137)

    // Tracks devices across consecutive scans to prevent flapping
    private val deviceStateMap = ConcurrentHashMap<String, ConnectedDevice>()

    /**
     * Executes a fast, multi-layer subnet scan with real-time progress and error reporting.
     */
    suspend fun scanSubnet(
        subnetPrefix: String = "192.168.43",
        gatewayIp: String? = "192.168.43.1",
        hotspotInterface: NetworkInterface? = null,
        strictImmediateRemoval: Boolean = false,
        onProgress: (scanned: Int, total: Int, phase: String, foundCount: Int) -> Unit = { _, _, _, _ -> },
        onLog: (level: LogLevel, tag: String, message: String) -> Unit = { _, _, _ -> }
    ): List<ConnectedDevice> = withContext(Dispatchers.IO) {
        val discoveredInThisRound = ConcurrentHashMap<String, ProbeResult>()
        val targetHosts = (1..254)
            .map { "$subnetPrefix.$it" }
            .filter { it != gatewayIp }
        val totalHosts = targetHosts.size

        onLog(
            LogLevel.INFO,
            "بدء الفحص",
            "فحص النطاق $subnetPrefix.1 - $subnetPrefix.254 (البوابة: ${gatewayIp ?: "غير معروف"}، الواجهة: ${hotspotInterface?.name ?: "تلقائي"})"
        )

        // Step 1: Pre-read kernel ARP / neighbor tables
        onProgress(0, totalHosts, "قراءة سجلات الجيران (ARP / ip neigh)...", 0)
        readKernelNeighbors(subnetPrefix, gatewayIp, discoveredInThisRound, logErrors = true, onLog = onLog)

        // Step 2: Multicast mDNS discovery bound to Hotspot interface
        onProgress(0, totalHosts, "إرسال استعلام mDNS الجماعي للأجهزة الذكية...", discoveredInThisRound.size)
        discoverViaMulticastMdns(subnetPrefix, gatewayIp, hotspotInterface, discoveredInThisRound, onLog)

        // Step 3: Check whether InetAddress.isReachable(hotspotInterface, ...) is allowed on this kernel
        val useIfaceForReachable = if (hotspotInterface != null && gatewayIp != null) {
            try {
                val gw = InetAddress.getByName(gatewayIp)
                val withIface = try { gw.isReachable(hotspotInterface, 0, 150) } catch (_: Exception) { false }
                if (withIface) {
                    true
                } else {
                    val plain = try { gw.isReachable(150) } catch (_: Exception) { false }
                    if (plain) {
                        onLog(LogLevel.INFO, "ICMP", "ربط isReachable بالواجهة مقيد؛ تم التبديل إلى التوجيه التلقائي للنظام")
                        false
                    } else {
                        true
                    }
                }
            } catch (_: Exception) {
                false
            }
        } else false

        // Fast Concurrent Active Probing across 1..254
        val scannedCounter = AtomicInteger(0)
        val semaphore = Semaphore(64)

        onProgress(0, totalHosts, "فحص العناوين النشطة ($subnetPrefix.x)...", discoveredInThisRound.size)

        coroutineScope {
            val deferreds = targetHosts.map { targetIp ->
                async {
                    val result = semaphore.withPermit {
                        fastProbeHost(targetIp, gatewayIp, if (useIfaceForReachable) hotspotInterface else null)
                    }
                    if (result != null) {
                        discoveredInThisRound.merge(result.ip, result) { old, new ->
                            old.copy(
                                hostname = new.hostname ?: old.hostname,
                                mac = new.mac ?: old.mac,
                                method = if (old.mac != null) "${old.method} + ${new.method}" else new.method
                            )
                        }
                    }
                    val count = scannedCounter.incrementAndGet()
                    if (count % 12 == 0 || count == totalHosts || result != null) {
                        onProgress(
                            count,
                            totalHosts,
                            "جاري فحص الشبكة ($count / $totalHosts)...",
                            discoveredInThisRound.size
                        )
                    }
                }
            }
            deferreds.awaitAll()
        }

        // Step 4: Re-read kernel neighbor table post-sweep (quiet mode to avoid duplicate error logs)
        readKernelNeighbors(subnetPrefix, gatewayIp, discoveredInThisRound, logErrors = false, onLog = onLog)

        // Step 5: Fallback /system/bin/ping sweep if no devices were discovered yet
        if (discoveredInThisRound.isEmpty()) {
            onProgress(totalHosts, totalHosts, "اختبار الفحص الاحتياطي عبر /system/bin/ping...", 0)
            val pingBindArg = testSystemPing(gatewayIp ?: "$subnetPrefix.1", gatewayIp, onLog)
            if (pingBindArg != null) {
                runFallbackPingSweep(targetHosts, pingBindArg.ifBlank { null }, discoveredInThisRound, onProgress, onLog)
            }
        }

        // Step 5.5: Targeted verification for previously connected devices that missed this round
        val missingIps = deviceStateMap.keys.filter { !discoveredInThisRound.containsKey(it) && it.startsWith("$subnetPrefix.") }
        if (missingIps.isNotEmpty()) {
            onProgress(totalHosts, totalHosts, "التحقق من استجابة ${missingIps.size} جهاز غير مستجيب...", discoveredInThisRound.size)
            coroutineScope {
                missingIps.map { ip ->
                    async {
                        val verified = verifyMissingHost(
                            ip = ip,
                            gatewayIp = gatewayIp,
                            hotspotInterface = if (useIfaceForReachable) hotspotInterface else null
                        )
                        if (verified != null) {
                            discoveredInThisRound[ip] = verified
                        }
                    }
                }.awaitAll()
            }
        }

        // Step 6: Enrich ONLY live discovered devices (hostname, open ports, device type)
        if (discoveredInThisRound.isNotEmpty()) {
            onProgress(totalHosts, totalHosts, "استخراج أسماء وتفاصيل ${discoveredInThisRound.size} جهاز...", discoveredInThisRound.size)
            coroutineScope {
                discoveredInThisRound.keys.toList().map { ip ->
                    async {
                        enrichLiveHost(ip, gatewayIp, discoveredInThisRound)
                    }
                }.awaitAll()
            }
            onLog(
                LogLevel.SUCCESS,
                "النتيجة",
                "تم اكتشاف ${discoveredInThisRound.size} جهاز متصل بنشاط في هذه الجولة"
            )
        } else {
            onLog(
                LogLevel.WARNING,
                "النتيجة",
                "لم يستجب أي جهاز على النطاق $subnetPrefix.1..254. تأكد من أن الجهاز المتصل متصل فعلياً بشبكة الهاتف وأن واجهة الشبكة المحددة صحيحة."
            )
        }

        val currentTime = System.currentTimeMillis()
        val updatedDevices = mutableListOf<ConnectedDevice>()

        // Process devices discovered in this scan round
        for ((ip, probeResult) in discoveredInThisRound) {
            val existing = deviceStateMap[ip]
            val resolvedHostname = probeResult.hostname?.takeIf { it.isNotBlank() } ?: existing?.hostname
            val deviceType = existing?.deviceType
                ?.takeIf { it != DeviceType.UNKNOWN }
                ?: classifyDevice(resolvedHostname, probeResult.openPorts)

            val updatedDevice = ConnectedDevice(
                ip = ip,
                hostname = resolvedHostname,
                mac = probeResult.mac ?: existing?.mac,
                deviceType = deviceType,
                firstSeenTimestamp = existing?.firstSeenTimestamp ?: currentTime,
                lastSeenTimestamp = currentTime,
                status = DeviceStatus.CONNECTED,
                failedProbeCount = 0,
                latencyMs = probeResult.latencyMs,
                detectionMethod = probeResult.method,
                openPorts = probeResult.openPorts
            )
            deviceStateMap[ip] = updatedDevice
            updatedDevices.add(updatedDevice)
        }

        // Handle previously seen devices that STILL did not respond after targeted verification
        for ((ip, previousDevice) in deviceStateMap.toMap()) {
            if (!discoveredInThisRound.containsKey(ip)) {
                val newFailCount = previousDevice.failedProbeCount + 1

                if (newFailCount >= 2 || strictImmediateRemoval || !ip.startsWith("$subnetPrefix.")) {
                    // Confirmed left after 2 consecutive missed cycles, manual refresh verification failure, or subnet change
                    deviceStateMap.remove(ip)
                    onLog(LogLevel.INFO, "المغادرة", "غادر الجهاز $ip الشبكة بعد عدم الاستجابة للفحص")
                } else {
                    // First missed cycle after targeted retry: mark immediately as UNCONFIRMED (not CONNECTED!)
                    val updatedDevice = previousDevice.copy(
                        failedProbeCount = newFailCount,
                        status = DeviceStatus.UNCONFIRMED
                    )
                    deviceStateMap[ip] = updatedDevice
                    updatedDevices.add(updatedDevice)
                    onLog(LogLevel.WARNING, "تحقق", "الجهاز $ip لم يستجب — حالته الآن غير مؤكد (سيُزال في الدورة القادمة إن لم يرد)")
                }
            }
        }

        onProgress(totalHosts, totalHosts, "اكتمل الفحص", discoveredInThisRound.size)

        return@withContext updatedDevices
            .filter { it.status != DeviceStatus.DISCONNECTED }
            .sortedBy { it.ip.substringAfterLast('.').toIntOrNull() ?: 999 }
    }

    /**
     * Deep targeted check on a previously-active IP that missed the fast sweep.
     * Prevents false disconnects during Wi-Fi sleep while catching real disconnects quickly.
     */
    private fun verifyMissingHost(
        ip: String,
        gatewayIp: String?,
        hotspotInterface: NetworkInterface?
    ): ProbeResult? {
        val startTime = System.currentTimeMillis()

        // 1. Longer ICMP isReachable
        try {
            val addr = InetAddress.getByName(ip)
            val ok = if (hotspotInterface != null) {
                addr.isReachable(hotspotInterface, 0, 500) || addr.isReachable(450)
            } else {
                addr.isReachable(500)
            }
            if (ok) {
                return ProbeResult(
                    ip = ip,
                    hostname = null,
                    latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                    method = "تأكيد استجابة ICMP",
                    openPorts = emptyList()
                )
            }
        } catch (_: Exception) {}

        // 2. TCP probe on common ports
        for (port in intArrayOf(80, 443, 62078)) {
            var socket: Socket? = null
            try {
                socket = Socket()
                if (gatewayIp != null) {
                    try { socket.bind(InetSocketAddress(gatewayIp, 0)) } catch (_: Exception) {}
                }
                socket.connect(InetSocketAddress(ip, port), 450)
                return ProbeResult(
                    ip = ip,
                    hostname = null,
                    latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                    method = "تأكيد منفذ TCP: $port",
                    openPorts = listOf(port)
                )
            } catch (_: NoRouteToHostException) {
                return null
            } catch (e: Exception) {
                val msg = (e.message ?: "").lowercase()
                if (msg.contains("refused") || msg.contains("econnrefused")) {
                    return ProbeResult(
                        ip = ip,
                        hostname = null,
                        latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                        method = "تأكيد استجابة TCP RST",
                        openPorts = emptyList()
                    )
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }

        // 3. System ping check on single IP
        try {
            val cmd = if (!gatewayIp.isNullOrBlank()) {
                arrayOf("/system/bin/ping", "-c", "1", "-W", "1", "-I", gatewayIp, ip)
            } else {
                arrayOf("/system/bin/ping", "-c", "1", "-W", "1", ip)
            }
            val p = Runtime.getRuntime().exec(cmd)
            if (p.waitFor() == 0) {
                return ProbeResult(
                    ip = ip,
                    hostname = null,
                    latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                    method = "تأكيد Ping ICMP",
                    openPorts = emptyList()
                )
            }
        } catch (_: Exception) {}

        return null
    }

    /**
     * Fast single-host liveness probe optimized to run across 253 hosts in ~2-3 seconds.
     */
    private fun fastProbeHost(
        ip: String,
        gatewayIp: String?,
        hotspotInterface: NetworkInterface?
    ): ProbeResult? {
        val startTime = System.currentTimeMillis()

        // 1. ICMP Echo via InetAddress.isReachable bound to Hotspot NetworkInterface
        try {
            val inetAddr = InetAddress.getByName(ip)
            val reachable = if (hotspotInterface != null) {
                inetAddr.isReachable(hotspotInterface, 0, 380)
            } else {
                inetAddr.isReachable(380)
            }
            if (reachable) {
                return ProbeResult(
                    ip = ip,
                    hostname = null,
                    latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                    method = "استجابة ICMP على واجهة نقطة الاتصال",
                    openPorts = emptyList()
                )
            }
        } catch (_: Exception) {}

        // 2. TCP SYN / RST probe (port 80) bound to Hotspot gateway IP
        // An active host with closed port 80 replies with TCP RST -> ConnectException (ECONNREFUSED)
        for (port in intArrayOf(80, 62078)) {
            var socket: Socket? = null
            try {
                socket = Socket()
                if (gatewayIp != null) {
                    try {
                        socket.bind(InetSocketAddress(gatewayIp, 0))
                    } catch (_: Exception) {}
                }
                socket.connect(InetSocketAddress(ip, port), 300)
                return ProbeResult(
                    ip = ip,
                    hostname = null,
                    latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                    method = "منفذ TCP مفتوح: $port",
                    openPorts = listOf(port)
                )
            } catch (_: NoRouteToHostException) {
                // Kernel ARP resolution failed directly; host is unreachable
                return null
            } catch (e: Exception) {
                val msg = (e.message ?: "").lowercase()
                if (msg.contains("refused") || msg.contains("econnrefused")) {
                    return ProbeResult(
                        ip = ip,
                        hostname = null,
                        latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                        method = "استجابة TCP RST (الجهاز نشط)",
                        openPorts = emptyList()
                    )
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }

        // 3. Connected UDP Socket (ICMP Port Unreachable probe)
        var udpSocket: DatagramSocket? = null
        try {
            udpSocket = if (gatewayIp != null) {
                try {
                    DatagramSocket(InetSocketAddress(gatewayIp, 0))
                } catch (_: Exception) {
                    DatagramSocket()
                }
            } else {
                DatagramSocket()
            }
            udpSocket.soTimeout = 140
            udpSocket.connect(InetSocketAddress(InetAddress.getByName(ip), 38241))
            val payload = byteArrayOf(0x48, 0x4D, 0x01, 0x00)
            udpSocket.send(DatagramPacket(payload, payload.size))
            val recvBuf = ByteArray(16)
            udpSocket.receive(DatagramPacket(recvBuf, recvBuf.size))
            return ProbeResult(
                ip = ip,
                hostname = null,
                latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                method = "استجابة مقبس UDP",
                openPorts = emptyList()
            )
        } catch (_: PortUnreachableException) {
            return ProbeResult(
                ip = ip,
                hostname = null,
                latencyMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1),
                method = "استجابة ICMP Port Unreachable",
                openPorts = emptyList()
            )
        } catch (_: Exception) {
        } finally {
            try { udpSocket?.close() } catch (_: Exception) {}
        }

        return null
    }

    /**
     * Sends a multicast mDNS query (224.0.0.251:5353) with QU bit set (unicast response requested),
     * bound to the Hotspot gateway IP so packets are sent over the Hotspot Wi-Fi interface.
     */
    private fun discoverViaMulticastMdns(
        subnetPrefix: String,
        gatewayIp: String?,
        hotspotInterface: NetworkInterface?,
        discoveredMap: ConcurrentHashMap<String, ProbeResult>,
        onLog: (LogLevel, String, String) -> Unit
    ) {
        var socket: DatagramSocket? = null
        try {
            socket = if (gatewayIp != null) {
                try {
                    DatagramSocket(InetSocketAddress(gatewayIp, 0))
                } catch (_: Exception) {
                    DatagramSocket()
                }
            } else {
                DatagramSocket()
            }
            socket.soTimeout = 350

            // Standard mDNS PTR query for _services._dns-sd._udp.local with QU bit (0x8001)
            val queryBytes = byteArrayOf(
                0x00, 0x01, // Transaction ID
                0x00, 0x00, // Flags
                0x00, 0x01, // Questions: 1
                0x00, 0x00, // Answer RRs
                0x00, 0x00, // Authority RRs
                0x00, 0x00, // Additional RRs
                0x09, '_'.code.toByte(), 's'.code.toByte(), 'e'.code.toByte(), 'r'.code.toByte(),
                'v'.code.toByte(), 'i'.code.toByte(), 'c'.code.toByte(), 'e'.code.toByte(), 's'.code.toByte(),
                0x07, '_'.code.toByte(), 'd'.code.toByte(), 'n'.code.toByte(), 's'.code.toByte(),
                '-'.code.toByte(), 's'.code.toByte(), 'd'.code.toByte(),
                0x04, '_'.code.toByte(), 'u'.code.toByte(), 'd'.code.toByte(), 'p'.code.toByte(),
                0x05, 'l'.code.toByte(), 'o'.code.toByte(), 'c'.code.toByte(), 'a'.code.toByte(), 'l'.code.toByte(),
                0x00,
                0x00, 0x0C, // Type: PTR
                0x80.toByte(), 0x01  // Class: IN + QU (request unicast reply!)
            )

            val mcastAddr = InetAddress.getByName("224.0.0.251")
            socket.send(DatagramPacket(queryBytes, queryBytes.size, mcastAddr, 5353))

            val deadline = System.currentTimeMillis() + 450
            val recvBuf = ByteArray(1024)
            var mcastFound = 0

            while (System.currentTimeMillis() < deadline) {
                try {
                    val packet = DatagramPacket(recvBuf, recvBuf.size)
                    socket.receive(packet)
                    val responderIp = packet.address?.hostAddress ?: continue
                    if (responderIp.startsWith(subnetPrefix) && responderIp != gatewayIp) {
                        val parsedName = extractReadableNameFromDns(packet.data, packet.length)
                        discoveredMap.putIfAbsent(
                            responderIp,
                            ProbeResult(
                                ip = responderIp,
                                hostname = parsedName,
                                latencyMs = 10,
                                method = "بث mDNS الجماعي (${hotspotInterface?.name ?: "WLAN"})",
                                openPorts = listOf(5353)
                            )
                        )
                        mcastFound++
                    }
                } catch (_: SocketTimeoutException) {
                    break
                }
            }

            if (mcastFound > 0) {
                onLog(LogLevel.SUCCESS, "mDNS", "استجاب $mcastFound جهاز لاستعلام mDNS الجماعي")
            }
        } catch (e: Exception) {
            onLog(LogLevel.INFO, "mDNS", "تعذر إرسال بث mDNS الجماعي: ${e.message}")
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Reads Linux kernel neighbor table via 'ip neigh' and '/proc/net/arp' with full error logging.
     */
    private fun readKernelNeighbors(
        subnetPrefix: String,
        gatewayIp: String?,
        discoveredMap: ConcurrentHashMap<String, ProbeResult>,
        logErrors: Boolean,
        onLog: (LogLevel, String, String) -> Unit
    ) {
        var ipNeighFound = 0
        var ipNeighErr: String? = null

        // Path 1: 'ip neigh'
        val commands = listOf(arrayOf("ip", "neigh"), arrayOf("/system/bin/ip", "neigh"))
        for (cmd in commands) {
            try {
                val process = Runtime.getRuntime().exec(cmd)
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val row = line?.trim() ?: continue
                        if (parseIpNeighLine(row, subnetPrefix, gatewayIp, discoveredMap)) {
                            ipNeighFound++
                        }
                    }
                }
                val errText = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
                val exitCode = process.waitFor()
                if (exitCode != 0 && errText.isNotBlank()) {
                    ipNeighErr = errText
                } else if (exitCode == 0) {
                    ipNeighErr = null
                    break
                }
            } catch (e: Exception) {
                ipNeighErr = e.message
            }
        }

        if (logErrors) {
            if (ipNeighFound > 0) {
                onLog(LogLevel.SUCCESS, "ip neigh", "تم العثور على $ipNeighFound جهاز في جدول الجيران")
            } else if (!ipNeighErr.isNullOrBlank()) {
                onLog(LogLevel.INFO, "ip neigh", "مقيد في Android 15: $ipNeighErr")
            }
        }

        // Path 2: /proc/net/arp
        try {
            val arpDoc = File("/proc/net/arp")
            if (!arpDoc.exists()) {
                if (logErrors) onLog(LogLevel.INFO, "ARP", "ملف /proc/net/arp غير موجود")
                return
            }
            if (!arpDoc.canRead()) {
                if (logErrors) onLog(LogLevel.INFO, "ARP", "قراءة /proc/net/arp محظورة بواسطة SELinux في Android 15")
                return
            }

            var arpFound = 0
            BufferedReader(FileReader(arpDoc)).use { reader ->
                var line: String?
                var isHeader = true
                while (reader.readLine().also { line = it } != null) {
                    if (isHeader) {
                        isHeader = false
                        continue
                    }
                    val parts = line?.trim()?.split("\\s+".toRegex()) ?: continue
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val flags = parts[2]
                        val mac = parts[3]

                        if (ip.startsWith("$subnetPrefix.") && ip != gatewayIp && flags != "0x0" && mac != "00:00:00:00:00:00") {
                            arpFound++
                            discoveredMap.merge(
                                ip,
                                ProbeResult(
                                    ip = ip,
                                    hostname = null,
                                    mac = mac,
                                    latencyMs = 2,
                                    method = "جدول ARP النواة",
                                    openPorts = emptyList()
                                )
                            ) { old, _ -> old.copy(mac = mac) }
                        }
                    }
                }
            }
            if (logErrors && arpFound > 0) {
                onLog(LogLevel.SUCCESS, "ARP", "تمت قراءة $arpFound جهاز من /proc/net/arp")
            }
        } catch (e: Exception) {
            if (logErrors) {
                onLog(LogLevel.INFO, "ARP", "تعذر فتح /proc/net/arp: ${e.message}")
            }
        }
    }

    private fun parseIpNeighLine(
        row: String,
        subnetPrefix: String,
        gatewayIp: String?,
        discoveredMap: ConcurrentHashMap<String, ProbeResult>
    ): Boolean {
        val tokens = row.split("\\s+".toRegex())
        if (tokens.size >= 4) {
            val ip = tokens[0]
            if (ip.startsWith("$subnetPrefix.") && ip != gatewayIp) {
                val isStaleOrFailed = tokens.contains("FAILED") ||
                        tokens.contains("INCOMPLETE") ||
                        tokens.contains("STALE")
                if (!isStaleOrFailed) {
                    val lladdrIdx = tokens.indexOf("lladdr")
                    val mac = if (lladdrIdx != -1 && lladdrIdx + 1 < tokens.size) {
                        tokens[lladdrIdx + 1]
                    } else null

                    if (mac != null && mac != "00:00:00:00:00:00") {
                        discoveredMap.merge(
                            ip,
                            ProbeResult(
                                ip = ip,
                                hostname = null,
                                mac = mac,
                                latencyMs = 2,
                                method = "سجل الجيران (ip neigh)",
                                openPorts = emptyList()
                            )
                        ) { old, _ -> old.copy(mac = mac) }
                        return true
                    }
                }
            }
        }
        return false
    }

    /**
     * Tests whether /system/bin/ping works on the device without root.
     * Returns the source IP bind argument to pass to `-I` (or `""` if plain ping works, or `null` if unavailable).
     */
    private fun testSystemPing(
        testIp: String,
        sourceIp: String?,
        onLog: (LogLevel, String, String) -> Unit
    ): String? {
        val candidates = buildList {
            if (!sourceIp.isNullOrBlank()) add(sourceIp)
            add("")
        }
        var lastError = ""
        var lastCode = -1

        for (bindArg in candidates) {
            try {
                val cmd = if (bindArg.isNotBlank()) {
                    arrayOf("/system/bin/ping", "-c", "1", "-W", "1", "-I", bindArg, testIp)
                } else {
                    arrayOf("/system/bin/ping", "-c", "1", "-W", "1", testIp)
                }
                val process = Runtime.getRuntime().exec(cmd)
                val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
                val code = process.waitFor()
                if (code == 0) {
                    onLog(LogLevel.INFO, "Ping", "أداة /system/bin/ping متاحة على الجهاز، بدء المسح الاحتياطي...")
                    return bindArg
                }
                lastCode = code
                lastError = err
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
            }
        }

        onLog(
            LogLevel.WARNING,
            "Ping",
            "اختبار Ping على البوابة انتهى برمز $lastCode${if (lastError.isNotBlank()) ": $lastError" else ""}"
        )
        return null
    }

    private suspend fun runFallbackPingSweep(
        targetHosts: List<String>,
        sourceIpBind: String?,
        discoveredMap: ConcurrentHashMap<String, ProbeResult>,
        onProgress: (scanned: Int, total: Int, phase: String, foundCount: Int) -> Unit,
        onLog: (LogLevel, String, String) -> Unit
    ) = coroutineScope {
        val semaphore = Semaphore(32)
        val counter = AtomicInteger(0)
        val total = targetHosts.size

        targetHosts.map { ip ->
            async {
                semaphore.withPermit {
                    try {
                        val cmd = if (!sourceIpBind.isNullOrBlank()) {
                            arrayOf("/system/bin/ping", "-c", "1", "-W", "1", "-I", sourceIpBind, ip)
                        } else {
                            arrayOf("/system/bin/ping", "-c", "1", "-W", "1", ip)
                        }
                        val start = System.currentTimeMillis()
                        val process = Runtime.getRuntime().exec(cmd)
                        val exit = process.waitFor()
                        if (exit == 0) {
                            discoveredMap.putIfAbsent(
                                ip,
                                ProbeResult(
                                    ip = ip,
                                    hostname = null,
                                    latencyMs = (System.currentTimeMillis() - start).coerceAtLeast(1),
                                    method = "استجابة Ping ICMP مباشر",
                                    openPorts = emptyList()
                                )
                            )
                        }
                    } catch (_: Exception) {}
                    val c = counter.incrementAndGet()
                    if (c % 20 == 0 || c == total) {
                        onProgress(c, total, "مسح Ping الاحتياطي ($c / $total)...", discoveredMap.size)
                    }
                }
            }
        }.awaitAll()

        if (discoveredMap.isNotEmpty()) {
            onLog(LogLevel.SUCCESS, "Ping", "اكتشف المسح الاحتياطي ${discoveredMap.size} جهاز")
        }
    }

    /**
     * Enriches already-confirmed live hosts with hostname (mDNS, NetBIOS, rDNS) and open ports.
     */
    private fun enrichLiveHost(
        ip: String,
        gatewayIp: String?,
        discoveredMap: ConcurrentHashMap<String, ProbeResult>
    ) {
        val current = discoveredMap[ip] ?: return
        var hostname = current.hostname
        val openPorts = current.openPorts.toMutableList()

        if (hostname.isNullOrBlank()) {
            hostname = queryUnicastMdns(ip, gatewayIp)
        }
        if (hostname.isNullOrBlank()) {
            hostname = queryNetBios(ip, gatewayIp)
        }
        if (hostname.isNullOrBlank()) {
            try {
                val resolved = InetAddress.getByName(ip).canonicalHostName
                if (!resolved.isNullOrBlank() && resolved != ip && !resolved.contains("unknown", ignoreCase = true)) {
                    hostname = resolved
                }
            } catch (_: Exception) {}
        }

        // Quick check for open service ports on confirmed host
        for (port in enrichmentTcpPorts) {
            if (openPorts.contains(port)) continue
            var socket: Socket? = null
            try {
                socket = Socket()
                if (gatewayIp != null) {
                    try { socket.bind(InetSocketAddress(gatewayIp, 0)) } catch (_: Exception) {}
                }
                socket.connect(InetSocketAddress(ip, port), 150)
                openPorts.add(port)
            } catch (_: Exception) {
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }

        discoveredMap[ip] = current.copy(
            hostname = hostname,
            openPorts = openPorts.distinct()
        )
    }

    private fun queryUnicastMdns(ip: String, gatewayIp: String?): String? {
        var socket: DatagramSocket? = null
        try {
            socket = if (gatewayIp != null) {
                try { DatagramSocket(InetSocketAddress(gatewayIp, 0)) } catch (_: Exception) { DatagramSocket() }
            } else DatagramSocket()
            socket.soTimeout = 200

            val queryBytes = byteArrayOf(
                0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x09, '_'.code.toByte(), 's'.code.toByte(), 'e'.code.toByte(), 'r'.code.toByte(),
                'v'.code.toByte(), 'i'.code.toByte(), 'c'.code.toByte(), 'e'.code.toByte(), 's'.code.toByte(),
                0x07, '_'.code.toByte(), 'd'.code.toByte(), 'n'.code.toByte(), 's'.code.toByte(),
                '-'.code.toByte(), 's'.code.toByte(), 'd'.code.toByte(),
                0x04, '_'.code.toByte(), 'u'.code.toByte(), 'd'.code.toByte(), 'p'.code.toByte(),
                0x05, 'l'.code.toByte(), 'o'.code.toByte(), 'c'.code.toByte(), 'a'.code.toByte(), 'l'.code.toByte(),
                0x00, 0x00, 0x0C, 0x00, 0x01
            )

            socket.send(DatagramPacket(queryBytes, queryBytes.size, InetAddress.getByName(ip), 5353))
            val recvBuf = ByteArray(512)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)

            if (recvPacket.length > 12) {
                return extractReadableNameFromDns(recvPacket.data, recvPacket.length)
            }
        } catch (_: Exception) {}
        finally {
            try { socket?.close() } catch (_: Exception) {}
        }
        return null
    }

    private fun extractReadableNameFromDns(data: ByteArray, length: Int): String? {
        if (length <= 12) return null
        val text = String(data, 12, length - 12, Charsets.UTF_8)
        val clean = text.map { if (it.isLetterOrDigit() || it == '-' || it == '_') it else ' ' }.joinToString("")
        return clean.split("\\s+".toRegex())
            .firstOrNull {
                it.length in 3..25 &&
                        !it.equals("local", ignoreCase = true) &&
                        !it.equals("services", ignoreCase = true) &&
                        !it.equals("dns-sd", ignoreCase = true) &&
                        !it.equals("udp", ignoreCase = true) &&
                        !it.equals("tcp", ignoreCase = true)
            }
    }

    private fun queryNetBios(ip: String, gatewayIp: String?): String? {
        var socket: DatagramSocket? = null
        try {
            socket = if (gatewayIp != null) {
                try { DatagramSocket(InetSocketAddress(gatewayIp, 0)) } catch (_: Exception) { DatagramSocket() }
            } else DatagramSocket()
            socket.soTimeout = 160

            val query = byteArrayOf(
                0x80.toByte(), 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x20, 0x43, 0x4B, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41,
                0x41, 0x41, 0x41, 0x41, 0x41, 0x00, 0x00, 0x21,
                0x00, 0x01
            )

            socket.send(DatagramPacket(query, query.size, InetAddress.getByName(ip), 137))
            val recvBuf = ByteArray(256)
            val recvPacket = DatagramPacket(recvBuf, recvBuf.size)
            socket.receive(recvPacket)

            if (recvPacket.length >= 72) {
                val nameBytes = recvPacket.data.copyOfRange(57, 57 + 15)
                val rawName = String(nameBytes, Charsets.US_ASCII).trim()
                if (rawName.isNotBlank()) return rawName
            }
        } catch (_: Exception) {}
        finally {
            try { socket?.close() } catch (_: Exception) {}
        }
        return null
    }

    private fun classifyDevice(hostname: String?, openPorts: List<Int>): DeviceType {
        val name = hostname?.lowercase() ?: ""
        return when {
            name.contains("iphone") || name.contains("android") ||
                    name.contains("galaxy") || name.contains("pixel") ||
                    name.contains("realme") || name.contains("redmi") ||
                    name.contains("oppo") || name.contains("huawei") ||
                    name.contains("xiaomi") || openPorts.contains(62078) -> DeviceType.PHONE

            name.contains("ipad") || name.contains("tablet") -> DeviceType.TABLET

            name.contains("macbook") || name.contains("laptop") ||
                    name.contains("desktop") || name.contains("pc") ||
                    name.contains("windows") || openPorts.contains(137) ||
                    openPorts.contains(22) -> DeviceType.LAPTOP

            name.contains("tv") || name.contains("cast") ||
                    name.contains("bravia") || name.contains("roku") ||
                    openPorts.contains(8008) -> DeviceType.TV

            name.contains("esp") || name.contains("cam") ||
                    name.contains("plug") || name.contains("printer") ||
                    name.contains("iot") -> DeviceType.IOT

            else -> DeviceType.UNKNOWN
        }
    }

    fun clearState() {
        deviceStateMap.clear()
    }

    private data class ProbeResult(
        val ip: String,
        val hostname: String?,
        val mac: String? = null,
        val latencyMs: Long,
        val method: String,
        val openPorts: List<Int>
    )
}
