package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.DeviceStatus
import com.example.data.model.LogLevel
import com.example.data.repository.HotspotRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HotspotMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var repository: HotspotRepository
    private lateinit var notificationManager: NotificationManager

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate() {
        super.onCreate()
        repository = HotspotRepository.getInstance(applicationContext)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        createNotificationChannels()

        repository.onDeviceJoined = { device ->
            sendDeviceAlert(
                title = "جهاز جديد متصل بنقطة الاتصال",
                message = "${device.displayName} (${device.ip}) انضم للشبكة الآن",
                notificationId = device.ip.hashCode()
            )
        }

        repository.onDeviceLeft = { device ->
            sendDeviceAlert(
                title = "مغادرة جهاز من نقطة الاتصال",
                message = "${device.displayName} (${device.ip}) غادر الشبكة",
                notificationId = device.ip.hashCode() + 1
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (action == ACTION_STOP_MONITORING) {
            try {
                repository.stopMonitoring()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } catch (e: Throwable) {
                Log.e("HotspotService", "Error stopping foreground: ${e.message}")
            }
            return START_NOT_STICKY
        }

        val initialNotification = buildNotification(
            deviceCount = repository.connectedDevices.value.count { it.status == DeviceStatus.CONNECTED },
            isHotspotEnabled = repository.hotspotStatus.value.isEnabled,
            lastUpdate = "جاري البدء..."
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, initialNotification, 0)
            } else {
                startForeground(NOTIFICATION_ID, initialNotification)
            }
            repository.appendLog(LogLevel.SUCCESS, "خدمة الخلفية", "تم تشغيل خدمة الإشعار الدائم بنجاح")
        } catch (e: Throwable) {
            val msg = "تعذر تشغيل ForegroundService: ${e.localizedMessage ?: e.javaClass.simpleName}"
            Log.e("HotspotService", msg, e)
            repository.reportServiceError(msg)
            try {
                startForeground(NOTIFICATION_ID, initialNotification)
            } catch (e2: Throwable) {
                repository.reportServiceError("المحاولة البديلة لخدمة الخلفية فشلت: ${e2.localizedMessage}")
            }
        }

        repository.startMonitoring()

        serviceScope.launch {
            combine(
                repository.connectedDevices,
                repository.hotspotStatus,
                repository.lastScanTime
            ) { devices, status, lastScanTime ->
                val confirmedCount = devices.count { it.status == DeviceStatus.CONNECTED }
                Triple(confirmedCount, status.isEnabled, lastScanTime)
            }.collect { (count, isEnabled, lastScanTime) ->
                try {
                    val timeStr = if (lastScanTime > 0) timeFormat.format(Date(lastScanTime)) else "الآن"
                    val updatedNotification = buildNotification(count, isEnabled, timeStr)
                    notificationManager.notify(NOTIFICATION_ID, updatedNotification)
                } catch (e: Throwable) {
                    Log.e("HotspotService", "Notify update error: ${e.message}")
                }
            }
        }

        return START_STICKY
    }

    private fun buildNotification(
        deviceCount: Int,
        isHotspotEnabled: Boolean,
        lastUpdate: String
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, HotspotMonitorService::class.java).apply {
            action = ACTION_STOP_MONITORING
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (isHotspotEnabled || deviceCount > 0) {
            "$deviceCount متصل الآن"
        } else {
            "بانتظار الأجهزة"
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_MONITOR_ID)
            .setContentTitle("Hotspot Monitor")
            .setContentText("$statusText • $lastUpdate")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    if (isHotspotEnabled || deviceCount > 0) {
                        "نقطة الاتصال مفعّلة • الأجهزة المتصلة: $deviceCount\nآخر فحص: $lastUpdate"
                    } else {
                        "المراقبة نشطة بانتظار اتصال الأجهزة.\nآخر فحص: $lastUpdate"
                    }
                )
            )
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setNumber(deviceCount)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                0,
                "إيقاف المراقبة",
                stopPendingIntent
            )

        val dynamicIcon = createCountStatusIcon(deviceCount)
        if (dynamicIcon != null) {
            builder.setSmallIcon(dynamicIcon)
        } else {
            builder.setSmallIcon(R.drawable.ic_stat_hotspot)
        }

        return builder.build()
    }

    /**
     * Generates a monochrome status-bar icon displaying the connected device count
     * (white rounded badge with transparent cutout number) so Android 15 can tint it
     * cleanly beside the system Hotspot icon in the top status bar.
     */
    private fun createCountStatusIcon(count: Int): IconCompat? {
        return try {
            val size = 96
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }

            // Draw a subtle top hotspot arc dot + rounded badge with the bold count inside
            val badgeRect = RectF(10f, 18f, size - 10f, size - 8f)
            canvas.drawRoundRect(badgeRect, 20f, 20f, bgPaint)

            // Small signal arc at the top edge to associate the count with Hotspot
            val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 7f
                strokeCap = Paint.Cap.ROUND
            }
            canvas.drawArc(RectF(26f, 4f, size - 26f, 34f), 205f, 130f, false, arcPaint)

            val label = if (count > 99) "99+" else count.coerceAtLeast(0).toString()
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textSize = when (label.length) {
                    1 -> 54f
                    2 -> 44f
                    else -> 32f
                }
            }

            val textY = badgeRect.centerY() - ((textPaint.descent() + textPaint.ascent()) / 2f)
            canvas.drawText(label, badgeRect.centerX(), textY, textPaint)

            IconCompat.createWithBitmap(bitmap)
        } catch (e: Throwable) {
            Log.w("HotspotService", "Dynamic count icon fallback: ${e.message}")
            null
        }
    }

    private fun sendDeviceAlert(title: String, message: String, notificationId: Int) {
        try {
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openAppPendingIntent = PendingIntent.getActivity(
                this,
                notificationId,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alert = NotificationCompat.Builder(this, CHANNEL_ALERTS_ID)
                .setSmallIcon(R.drawable.ic_stat_hotspot)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(openAppPendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()

            notificationManager.notify(notificationId, alert)
        } catch (e: Throwable) {
            Log.e("HotspotService", "Error sending alert: ${e.message}")
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val monitorChannel = NotificationChannel(
                CHANNEL_MONITOR_ID,
                "مراقبة نقطة الاتصال الدائمة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار دائم يوضح حالة نقطة الاتصال وعدد الأجهزة المتصلة"
                setShowBadge(false)
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS_ID,
                "تنبيهات انضمام ومغادرة الأجهزة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تنبيه عند اتصال جهاز جديد أو مغادرته نقطة الاتصال"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(monitorChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_MONITOR_ID = "hotspot_monitor_permanent_channel"
        const val CHANNEL_ALERTS_ID = "hotspot_device_alerts_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_MONITORING = "com.example.service.START_MONITORING"
        const val ACTION_STOP_MONITORING = "com.example.service.STOP_MONITORING"

        fun startService(context: Context) {
            val intent = Intent(context, HotspotMonitorService::class.java).apply {
                action = ACTION_START_MONITORING
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, HotspotMonitorService::class.java).apply {
                action = ACTION_STOP_MONITORING
            }
            context.startService(intent)
        }
    }
}
