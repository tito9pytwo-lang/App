package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material.icons.filled.WifiTetheringOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.DeviceStatus
import com.example.data.model.ScanProgressState
import com.example.ui.components.DeviceItemCard
import com.example.ui.components.ProgressAndErrorsDialog
import com.example.ui.theme.HotspotCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.viewmodel.HotspotViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: HotspotViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hotspotStatus by viewModel.hotspotStatus.collectAsState()
    val connectedDevices by viewModel.connectedDevices.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val lastScanTime by viewModel.lastScanTime.collectAsState()
    val isMonitoringActive by viewModel.isMonitoringActive.collectAsState()
    val scanProgress by viewModel.scanProgress.collectAsState()
    val scanLogs by viewModel.scanLogs.collectAsState()

    var showProgressDialog by remember { mutableStateOf(false) }

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    val confirmedDevices = remember(connectedDevices) {
        connectedDevices.filter { it.status == DeviceStatus.CONNECTED }
    }
    val unconfirmedDevices = remember(connectedDevices) {
        connectedDevices.filter { it.status == DeviceStatus.UNCONFIRMED }
    }

    if (showProgressDialog) {
        ProgressAndErrorsDialog(
            progress = scanProgress,
            hotspotStatus = hotspotStatus,
            logs = scanLogs,
            onDismiss = { showProgressDialog = false },
            onRunScanNow = { viewModel.refreshManually() },
            onClearLogs = { viewModel.clearLogs() },
            onCopyReport = { viewModel.buildCopyableReport() }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Notification permission banner if missing
            if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .testTag("notification_permission_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = SignalAmber.copy(alpha = 0.15f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "صلاحية الإشعارات",
                            tint = SignalAmber
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تفعيل إشعارات المراقبة الدائمة",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "مطلوب لإظهار عدد الأجهزة المتصلة في شريط الإشعارات على Android 15",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalAmber),
                            contentPadding = ButtonDefaults.TextButtonContentPadding
                        ) {
                            Text("سماح", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Hotspot Status Bar
            HotspotStatusBar(
                status = hotspotStatus,
                connectedCount = confirmedDevices.size,
                hasConnectedDevices = confirmedDevices.isNotEmpty(),
                onOpenHotspotSettings = {
                    try {
                        val intent = Intent("android.settings.TETHER_SETTINGS")
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        try {
                            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                        } catch (_: Exception) {}
                    }
                }
            )
        }

        // Big Connected Device Hero Counter Card
        item {
            ConnectedCountHeroCard(
                deviceCount = confirmedDevices.size,
                unconfirmedCount = unconfirmedDevices.size,
                isScanning = isScanning,
                isMonitoringActive = isMonitoringActive,
                lastScanTime = lastScanTime,
                isHotspotEnabled = hotspotStatus.isEnabled || confirmedDevices.isNotEmpty(),
                timeFormat = timeFormat
            )
        }

        // Action Controls Row
        item {
            ActionControls(
                isMonitoringActive = isMonitoringActive,
                isScanning = isScanning,
                onToggleMonitoring = {
                    if (isMonitoringActive) {
                        viewModel.stopMonitoring()
                    } else {
                        viewModel.startMonitoring()
                    }
                },
                onManualRefresh = {
                    viewModel.refreshManually()
                }
            )
        }

        // Inline Live Progress & Errors Summary Card (opens full Progress & Errors window)
        item {
            LiveProgressBannerCard(
                progress = scanProgress,
                onOpenDetails = { showProgressDialog = true }
            )
        }

        // Header for Devices List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأجهزة المتصلة حالياً",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Surface(
                    shape = CircleShape,
                    color = HotspotCyan.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${confirmedDevices.size} متصل",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = HotspotCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // List of Connected Devices or Empty State
        if (confirmedDevices.isEmpty()) {
            item {
                EmptyDevicesState(
                    isHotspotEnabled = hotspotStatus.isEnabled,
                    isMonitoring = isMonitoringActive,
                    isScanning = isScanning,
                    subnetPrefix = hotspotStatus.subnetPrefix,
                    onStartScan = { viewModel.refreshManually() },
                    onOpenProgressWindow = { showProgressDialog = true }
                )
            }
        } else {
            items(
                items = confirmedDevices,
                key = { it.ip }
            ) { device ->
                DeviceItemCard(device = device)
            }
        }

        if (unconfirmedDevices.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "لم تستجب للفحص الأخير (قيد التحقق من المغادرة)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = SignalAmber
                    )
                }
            }
            items(
                items = unconfirmedDevices,
                key = { "unconfirmed_${it.ip}" }
            ) { device ->
                DeviceItemCard(device = device)
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun HotspotStatusBar(
    status: com.example.data.model.HotspotStatus,
    connectedCount: Int = 0,
    hasConnectedDevices: Boolean = false,
    onOpenHotspotSettings: () -> Unit
) {
    val isApActive = status.isEnabled || hasConnectedDevices
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hotspot_status_bar"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                BadgedBox(
                    badge = {
                        Badge(
                            containerColor = if (connectedCount > 0) SignalGreen else MaterialTheme.colorScheme.outline,
                            contentColor = if (connectedCount > 0) Color.Black else Color.White
                        ) {
                            Text(
                                text = "$connectedCount",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp
                            )
                        }
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isApActive) SignalGreen.copy(alpha = 0.15f)
                                else SignalAmber.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isApActive) Icons.Default.WifiTethering else Icons.Default.WifiTetheringOff,
                            contentDescription = "حالة نقطة الاتصال ($connectedCount متصل)",
                            tint = if (isApActive) SignalGreen else SignalAmber,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isApActive) SignalGreen else SignalAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isApActive) "نقطة الاتصال مفعّلة" else "نقطة الاتصال (بانتظار الأجهزة)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = if (isApActive) {
                            "الواجهة: ${status.interfaceName ?: "تلقائي"} • البوابة: ${status.gatewayIp ?: "192.168.43.1"}"
                        } else {
                            "النطاق: ${status.subnetPrefix}.x • اضغط للتحديث أو لفتح الإعدادات"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (connectedCount > 0) SignalGreen.copy(alpha = 0.16f)
                    else HotspotCyan.copy(alpha = 0.12f),
                    modifier = Modifier.testTag("hotspot_bar_count_icon")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = "الأجهزة المتصلة",
                            tint = if (connectedCount > 0) SignalGreen else HotspotCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$connectedCount",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (connectedCount > 0) SignalGreen else HotspotCyan
                        )
                    }
                }

                IconButton(
                    onClick = onOpenHotspotSettings,
                    modifier = Modifier.testTag("hotspot_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "إعدادات نقطة الاتصال",
                        tint = HotspotCyan
                    )
                }
            }
        }
    }
}

@Composable
private fun ConnectedCountHeroCard(
    deviceCount: Int,
    unconfirmedCount: Int = 0,
    isScanning: Boolean,
    isMonitoringActive: Boolean,
    lastScanTime: Long,
    isHotspotEnabled: Boolean,
    timeFormat: SimpleDateFormat
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_count_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = HotspotCyan.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top status pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isScanning) HotspotCyan.copy(alpha = 0.15f)
                    else if (isMonitoringActive) SignalGreen.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 2.dp,
                                color = HotspotCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري الفحص الآن...",
                                style = MaterialTheme.typography.labelMedium,
                                color = HotspotCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else if (isMonitoringActive) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(SignalGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المراقبة المستمرة نشطة",
                                style = MaterialTheme.typography.labelMedium,
                                color = SignalGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المراقبة متوقفة",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Giant Animated Number
                Text(
                    text = "$deviceCount",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 76.sp,
                        fontWeight = FontWeight.Black
                    ),
                    color = if (deviceCount > 0) HotspotCyan else MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = when (deviceCount) {
                        0 -> "لا توجد أجهزة متصلة"
                        1 -> "جهاز واحد متصل بنقطة الاتصال"
                        2 -> "جهازان متصلان بنقطة الاتصال"
                        in 3..10 -> "$deviceCount أجهزة متصلة بنقطة الاتصال"
                        else -> "$deviceCount جهازاً متصلاً بنقطة الاتصال"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (unconfirmedCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "$unconfirmedCount جهاز لم يستجب لآخر فحص — جاري التحقق من مغادرته",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalAmber,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Last Update Time
                Text(
                    text = if (lastScanTime > 0) {
                        "آخر تحديث: ${timeFormat.format(Date(lastScanTime))}"
                    } else {
                        "لم يتم الفحص بعد"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ActionControls(
    isMonitoringActive: Boolean,
    isScanning: Boolean,
    onToggleMonitoring: () -> Unit,
    onManualRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Toggle Monitoring Button
        Button(
            onClick = onToggleMonitoring,
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("toggle_monitoring_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isMonitoringActive) SignalRed else SignalGreen
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(
                imageVector = if (isMonitoringActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = if (isMonitoringActive) "إيقاف المراقبة" else "بدء المراقبة",
                tint = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isMonitoringActive) "إيقاف المراقبة" else "بدء المراقبة",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Manual Refresh Button
        FilledTonalButton(
            onClick = onManualRefresh,
            enabled = !isScanning,
            modifier = Modifier
                .height(52.dp)
                .testTag("manual_refresh_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = HotspotCyan.copy(alpha = 0.15f),
                contentColor = HotspotCyan
            )
        ) {
            if (isScanning) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = HotspotCyan
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "تحديث فوري",
                    tint = HotspotCyan
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "تحديث",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun LiveProgressBannerCard(
    progress: ScanProgressState,
    onOpenDetails: () -> Unit
) {
    val hasErrors = progress.errorCount > 0
    val borderColor = when {
        hasErrors -> SignalRed.copy(alpha = 0.5f)
        progress.isScanning -> HotspotCyan.copy(alpha = 0.5f)
        else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenDetails)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .testTag("open_progress_errors_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (hasErrors) Icons.Default.Error else Icons.Default.BugReport,
                        contentDescription = "تقرير التقدم والأخطاء",
                        tint = if (hasErrors) SignalRed else HotspotCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "التحقق من التقدم والأخطاء",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = progress.currentPhase,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        hasErrors -> SignalRed.copy(alpha = 0.15f)
                        progress.warningCount > 0 -> SignalAmber.copy(alpha = 0.15f)
                        else -> HotspotCyan.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = when {
                            hasErrors -> "${progress.errorCount} خطأ • عرض"
                            progress.warningCount > 0 -> "${progress.warningCount} تنبيه • عرض"
                            progress.isScanning -> "${(progress.progressPercent * 100).toInt()}%"
                            else -> "عرض السجل"
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            hasErrors -> SignalRed
                            progress.warningCount > 0 -> SignalAmber
                            else -> HotspotCyan
                        }
                    )
                }
            }

            if (progress.isScanning || progress.progressPercent > 0f) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.progressPercent.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (hasErrors) SignalRed else HotspotCyan,
                    trackColor = MaterialTheme.colorScheme.surface
                )
            }
        }
    }
}

@Composable
private fun EmptyDevicesState(
    isHotspotEnabled: Boolean,
    isMonitoring: Boolean,
    isScanning: Boolean,
    subnetPrefix: String,
    onStartScan: () -> Unit,
    onOpenProgressWindow: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_devices_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(HotspotCyan.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                if (isScanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        strokeWidth = 3.dp,
                        color = HotspotCyan
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "لا توجد أجهزة",
                        tint = HotspotCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isScanning) "جاري فحص الشبكة المحلية بحثاً عن الأجهزة..."
                else "لم يتم اكتشاف أجهزة متصلة في الفحص الأخير",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isScanning) {
                    "يتم الآن إرسال حزم استكشاف لجميع الأجهزة المتصلة بنطاق نقطة الاتصال $subnetPrefix.x وقراءة سجلات الجيران..."
                } else {
                    "تأكد من تشغيل نقطة الاتصال وتوصيل الجهاز بها، ثم اضغط على زر 'فحص فوري' أو افتح نافذة التقدم والأخطاء لمعرفة السبب."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (!isScanning) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onStartScan,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HotspotCyan)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = Color(0xFF00363F)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "فحص فوري للأجهزة المتصلة الآن",
                        color = Color(0xFF00363F),
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onOpenProgressWindow,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("empty_open_progress_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = HotspotCyan
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "فتح نافذة التحقق من التقدم والأخطاء",
                        color = HotspotCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
