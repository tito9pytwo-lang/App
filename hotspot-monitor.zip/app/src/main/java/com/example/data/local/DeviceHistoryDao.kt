package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceHistoryDao {
    @Query("SELECT * FROM device_history ORDER BY lastSeenTimestamp DESC")
    fun getAllHistory(): Flow<List<DeviceHistoryEntity>>

    @Query("SELECT * FROM device_history WHERE ip = :ip LIMIT 1")
    suspend fun getDeviceByIp(ip: String): DeviceHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: DeviceHistoryEntity): Long

    @Update
    suspend fun update(entity: DeviceHistoryEntity)

    @Query("DELETE FROM device_history")
    suspend fun clearAll()

    @Query("DELETE FROM device_history WHERE id = :id")
    suspend fun deleteById(id: Long)
}
