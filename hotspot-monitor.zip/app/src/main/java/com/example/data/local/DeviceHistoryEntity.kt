package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "device_history",
    indices = [Index(value = ["ip"], unique = true)]
)
data class DeviceHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ip: String,
    val hostname: String?,
    val deviceType: String,
    val firstSeenTimestamp: Long,
    val lastSeenTimestamp: Long,
    val appearanceCount: Int = 1,
    val lastLatencyMs: Long? = null
)
