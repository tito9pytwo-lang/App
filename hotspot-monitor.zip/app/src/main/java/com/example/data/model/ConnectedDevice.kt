package com.example.data.model

enum class DeviceStatus(val arabicLabel: String) {
    CONNECTED("متصل"),
    UNCONFIRMED("غير مؤكد"),
    DISCONNECTED("غادر الشبكة")
}

enum class DeviceType(val arabicLabel: String) {
    PHONE("هاتف ذكي"),
    LAPTOP("حاسوب محمول"),
    TABLET("جهاز لوحي"),
    TV("تلفاز ذكي"),
    IOT("جهاز إنترنت الأشياء"),
    UNKNOWN("جهاز شبكي")
}

data class ConnectedDevice(
    val ip: String,
    val hostname: String? = null,
    val mac: String? = null,
    val deviceType: DeviceType = DeviceType.UNKNOWN,
    val firstSeenTimestamp: Long = System.currentTimeMillis(),
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val status: DeviceStatus = DeviceStatus.CONNECTED,
    val failedProbeCount: Int = 0,
    val latencyMs: Long? = null,
    val detectionMethod: String = "فحص استجابة المقبس والشبكة",
    val openPorts: List<Int> = emptyList()
) {
    val displayName: String
        get() = hostname?.takeIf { it.isNotBlank() && it != ip && !it.contains("unknown", ignoreCase = true) }
            ?: "جهاز متصل (${ip.substringAfterLast('.')})"

    val formattedMac: String
        get() = mac ?: "غير متاح (حماية Android 15)"
}
