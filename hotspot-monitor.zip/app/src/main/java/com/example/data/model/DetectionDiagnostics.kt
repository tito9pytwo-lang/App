package com.example.data.model

data class DetectionDiagnostics(
    val currentMethod: String = "الفحص المباشر للشبكة الفرعية (Subnet Probing)",
    val activeInterface: String = "غير محدد",
    val gatewayIp: String = "192.168.43.1",
    val subnetRange: String = "192.168.43.1 - 192.168.43.254",
    val reliabilityLevel: String = "دقيق ومؤكد (عناوين IP النشطة)",
    val grantedPermissions: List<String> = emptyList(),
    val missingPermissions: List<String> = emptyList(),
    val isPostNotificationGranted: Boolean = false,
    val android15RestrictionsExplanation: String = """
        • نظام Android 15 يطبق قيود أمان صارمة (SELinux) تمنع التطبيقات العادية من قراءة ملف /proc/net/arp للوصول إلى عناوين MAC.
        • واجهة عملاء نقطة الاتصال (TetheringManager.TetheringEventCallback) تتطلب صلاحيات نظام محمية MAINLINE_NETWORK_STACK المخصصة للنظام فقط.
        • لحل هذه القيود على هاتف realme C53، يعتمد التطبيق على طريقة قانونية وفعالة: الفحص المتزامن الخفيف للمنافذ المشتركة (TCP/ICMP/DNS) داخل نطاق الشبكة المحلية 192.168.43.0/24 بدقة عالية واستهلاك بطارية منخفض.
    """.trimIndent()
)
