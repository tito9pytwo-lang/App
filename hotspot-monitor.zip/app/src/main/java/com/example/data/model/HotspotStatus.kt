package com.example.data.model

data class HotspotStatus(
    val isEnabled: Boolean = false,
    val interfaceName: String? = null,
    val gatewayIp: String? = null,
    val subnetMask: String = "255.255.255.0",
    val subnetPrefix: String = "192.168.43",
    val detectionMethod: String = "فحص واجهات الشبكة وحالة النظام",
    val lastCheckedTimestamp: Long = System.currentTimeMillis()
)
