package com.example.data.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import com.example.data.model.HotspotStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.net.Inet4Address
import java.net.NetworkInterface

class HotspotDetector(private val context: Context) {

    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    /**
     * Inspects network interfaces and system states to determine Hotspot state.
     */
    fun checkHotspotStatus(): HotspotStatus {
        var isEnabled = false
        var activeInterface: String? = null
        var gatewayIp: String? = null
        var subnetPrefix = "192.168.43"
        var detectionMethod = "فحص واجهات الشبكة المباشرة"

        // 1. Check active network interfaces for known AP / Tethering interfaces
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            for (iface in interfaces) {
                if (!iface.isUp || iface.isLoopback) continue

                val name = iface.name.lowercase()
                val isApName = name.startsWith("ap") ||
                        name.startsWith("wlan1") ||
                        name.startsWith("softap") ||
                        name.startsWith("swlan") ||
                        name.startsWith("rndis") ||
                        name.contains("tether")

                val addrs = iface.inetAddresses.toList()
                for (addr in addrs) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val hostAddr = addr.hostAddress ?: continue

                        // Android hotspot almost always uses 192.168.43.1 or 192.168.44.1 or similar
                        val isHotspotSubnet = hostAddr.startsWith("192.168.43.") ||
                                hostAddr.startsWith("192.168.44.") ||
                                hostAddr.startsWith("192.168.49.") ||
                                hostAddr.startsWith("192.168.50.")

                        if (isApName || isHotspotSubnet) {
                            isEnabled = true
                            activeInterface = iface.name
                            gatewayIp = hostAddr
                            subnetPrefix = hostAddr.substringBeforeLast('.')
                            detectionMethod = "واجهة $activeInterface نشطة ($hostAddr)"
                            break
                        }
                    }
                }
                if (isEnabled) break
            }
        } catch (e: Exception) {
            Log.e("HotspotDetector", "Error scanning network interfaces: ${e.message}")
        }

        // 2. Fallback / supplementary check via WifiManager reflection if interface inspection was inconclusive
        if (!isEnabled && wifiManager != null) {
            try {
                val method = wifiManager.javaClass.getDeclaredMethod("isWifiApEnabled")
                method.isAccessible = true
                val result = method.invoke(wifiManager) as? Boolean
                if (result == true) {
                    isEnabled = true
                    detectionMethod = "استعلام WifiManager النظامي"
                    if (gatewayIp == null) {
                        gatewayIp = "192.168.43.1"
                    }
                }
            } catch (_: Exception) {
                // Restricted on some Android 15 builds - handled gracefully
            }
        }

        return HotspotStatus(
            isEnabled = isEnabled,
            interfaceName = activeInterface ?: (if (isEnabled) "ap0/wlan1" else null),
            gatewayIp = gatewayIp ?: (if (isEnabled) "192.168.43.1" else null),
            subnetPrefix = subnetPrefix,
            detectionMethod = detectionMethod,
            lastCheckedTimestamp = System.currentTimeMillis()
        )
    }

    /**
     * Emits Hotspot status updates via broadcast intents and interface monitoring.
     */
    fun observeHotspotState(): Flow<HotspotStatus> = callbackFlow {
        // Send initial state immediately
        trySend(checkHotspotStatus())

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                trySend(checkHotspotStatus())
            }
        }

        val filter = IntentFilter().apply {
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction("android.net.conn.TETHER_STATE_CHANGED")
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
        } catch (_: Exception) {
            try {
                context.registerReceiver(receiver, filter)
            } catch (e: Exception) {
                Log.w("HotspotDetector", "Receiver registration: ${e.message}")
            }
        }

        awaitClose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
        }
    }
}
