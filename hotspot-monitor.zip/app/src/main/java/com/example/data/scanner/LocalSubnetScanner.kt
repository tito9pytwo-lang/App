package com.example.data.scanner

import android.util.Log
import com.example.data.model.ConnectedDevice
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

class LocalSubnetScanner {

    // Common probe ports across modern smartphones, laptops, TVs, and IoT
    private val probePorts = intArrayOf(80, 443, 53, 5353, 8080, 137, 22, 8008, 62078)

    // Tracks devices across consecutive scans to prevent flapping
    private val deviceStateMap = mutableMapOf<String, ConnectedDevice>()

    /**
     * Executes a full subnet scan on the specified subnet prefix (e.g., "192.168.43").
     * Excludes gateway IP (the host phone itself).
     */
    suspend fun scanSubnet(
        subnetPrefix: String = "192.168.43",
        gatewayIp: String? = "192.168.43.1"
    ): List<ConnectedDevice> = withContext(Dispatchers.IO) {
        val discoveredInThisRound = mutableMapOf<String, ProbeResult>()

        // Realme C53 / Android Hotspot typically assigns DHCP in the 10..150 range.
        // We prioritize this range first for rapid discovery and low battery use.
        val primaryHosts = (10..150).toList()
        val secondaryHosts = (2..9) + (151..254)
        val allHosts = primaryHosts + secondaryHosts

        // Concurrency limiter to prevent CPU or battery spikes
        val semaphore = Semaphore(20)

        coroutineScope {
            val deferreds = allHosts.map { hostSuffix ->
                async {
                    val targetIp = "$subnetPrefix.$hostSuffix"
                    if (targetIp == gatewayIp) return@async null

                    semaphore.withPermit {
                        probeHost(targetIp)
                    }
                }
            }

            deferreds.awaitAll().filterNotNull().forEach { result ->
                discoveredInThisRound[result.ip] = result
            }
        }

        val currentTime = System.currentTimeMillis()
        val updatedDevices = mutableListOf<ConnectedDevice>()

        // 1. Process devices discovered in this scan round
        for ((ip, probeResult) in discoveredInThisRound) {
            val existing = deviceStateMap[ip]
            val deviceType = existing?.deviceType
                ?.takeIf { it != DeviceType.UNKNOWN }
                ?: classifyDevice(probeResult.hostname, probeResult.openPorts)

            val updatedDevice = ConnectedDevice(
                ip = ip,
                hostname = probeResult.hostname ?: existing?.hostname,
                mac = null, // Protected by Android 15 SELinux
                deviceType = deviceType,
                firstSeenTimestamp = existing?.firstSeenTimestamp ?: currentTime,
                lastSeenTimestamp = currentTime,
                status = DeviceStatus.CONNECTED,
                failedProbeCount = 0,
                latencyMs = probeResult.latencyMs,
                detectionMethod = probeResult.method,
                openPorts = probeResult.openPorts
            )
            deviceStateMap[ip] = updatedDevice
            updatedDevices.add(updatedDevice)
        }

        // 2. Handle previously seen devices that did not respond in this round
        // Flapping prevention: we don't drop immediately!
        for ((ip, previousDevice) in deviceStateMap.toMap()) {
            if (!discoveredInThisRound.containsKey(ip)) {
                val newFailCount = previousDevice.failedProbeCount + 1

                val newStatus = when {
                    newFailCount < 2 -> DeviceStatus.CONNECTED // Still considered connected after 1 miss
                    newFailCount in 2..3 -> DeviceStatus.UNCONFIRMED // Unconfirmed after 2-3 misses
                    else -> DeviceStatus.DISCONNECTED // Marked left after 4 misses
                }

                if (newFailCount > 4) {
                    // Remove from active state after 4 persistent failures
                    deviceStateMap.remove(ip)
                } else {
                    val updatedDevice = previousDevice.copy(
                        failedProbeCount = newFailCount,
                        status = newStatus
                    )
                    deviceStateMap[ip] = updatedDevice
                    updatedDevices.add(updatedDevice)
                }
            }
        }

        // Return only currently active or unconfirmed devices (not fully disconnected)
        return@withContext updatedDevices.filter { it.status != DeviceStatus.DISCONNECTED }
            .sortedBy { device ->
                // Sort by IP numeric ending
                device.ip.substringAfterLast('.').toIntOrNull() ?: 999
            }
    }

    /**
     * Probes an individual IP address via TCP sockets and ICMP.
     */
    private fun probeHost(ip: String): ProbeResult? {
        val startTime = System.currentTimeMillis()
        var isAlive = false
        var probeMethod = "استجابة فحص المقبس"
        val openPorts = mutableListOf<Int>()
        var hostname: String? = null

        // Try TCP socket connections to representative ports
        for (port in probePorts) {
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.connect(InetSocketAddress(ip, port), 180)
                isAlive = true
                openPorts.add(port)
                probeMethod = "منفذ مفتوح: $port"
                break // Fast exit upon first verified open port
            } catch (e: Exception) {
                // Port unreachable or connection refused:
                // Note: "Connection refused" indicates the host is ACTIVE and rejected the port!
                val msg = e.message ?: ""
                if (msg.contains("refused", ignoreCase = true)) {
                    isAlive = true
                    probeMethod = "استجابة رفض اتصال (المضيف نشط)"
                    break
                }
            } finally {
                try {
                    socket?.close()
                } catch (_: Exception) {}
            }
        }

        // If TCP probe didn't confirm, try ICMP isReachable
        if (!isAlive) {
            try {
                val inetAddr = InetAddress.getByName(ip)
                if (inetAddr.isReachable(200)) {
                    isAlive = true
                    probeMethod = "استجابة فحص ICMP"
                }
            } catch (_: Exception) {}
        }

        if (isAlive) {
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)

            // Attempt hostname resolution
            try {
                val inet = InetAddress.getByName(ip)
                val resolvedName = inet.canonicalHostName
                if (!resolvedName.isNullOrBlank() && resolvedName != ip) {
                    hostname = resolvedName
                }
            } catch (_: Exception) {}

            return ProbeResult(
                ip = ip,
                hostname = hostname,
                latencyMs = latency,
                method = probeMethod,
                openPorts = openPorts
            )
        }

        return null
    }

    /**
     * Classifies device type using hostname patterns or common open service ports.
     */
    private fun classifyDevice(hostname: String?, openPorts: List<Int>): DeviceType {
        val name = hostname?.lowercase() ?: ""
        return when {
            name.contains("iphone") || name.contains("android") ||
                    name.contains("galaxy") || name.contains("pixel") ||
                    name.contains("realme") || name.contains("redmi") ||
                    name.contains("oppo") || name.contains("huawei") ||
                    name.contains("xiaomi") -> DeviceType.PHONE

            name.contains("ipad") || name.contains("tablet") -> DeviceType.TABLET

            name.contains("macbook") || name.contains("laptop") ||
                    name.contains("desktop") || name.contains("pc") ||
                    name.contains("windows") || openPorts.contains(137) ||
                    openPorts.contains(22) -> DeviceType.LAPTOP

            name.contains("tv") || name.contains("cast") ||
                    name.contains("bravia") || name.contains("roku") ||
                    openPorts.contains(8008) -> DeviceType.TV

            name.contains("esp") || name.contains("cam") ||
                    name.contains("plug") || name.contains("printer") ||
                    name.contains("iot") -> DeviceType.IOT

            else -> DeviceType.UNKNOWN
        }
    }

    fun clearState() {
        deviceStateMap.clear()
    }

    private data class ProbeResult(
        val ip: String,
        val hostname: String?,
        val latencyMs: Long,
        val method: String,
        val openPorts: List<Int>
    )
}
