package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.HotspotCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.viewmodel.HotspotViewModel

@Composable
fun DiagnosticsScreen(
    viewModel: HotspotViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hotspotStatus by viewModel.hotspotStatus.collectAsState()
    val diagnostics = viewModel.getDiagnostics()

    // Permission checks
    val isPostNotificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else true

    val isNetworkStateGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_NETWORK_STATE
    ) == PackageManager.PERMISSION_GRANTED

    val isWifiStateGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_WIFI_STATE
    ) == PackageManager.PERMISSION_GRANTED

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "حالة الاكتشاف والتشخيص التقني",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "تقرير دقة واكتشاف الأجهزة على هاتف realme C53 بنظام Android 15",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Method & Reliability Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("method_reliability_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(HotspotCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Router,
                                contentDescription = null,
                                tint = HotspotCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "نظام الاكتشاف النشط",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    DiagnosticRow(
                        title = "طريقة الاكتشاف:",
                        value = "فحص متزامن خفيف لمنافذ الشبكة الفرعية (TCP/ICMP)"
                    )
                    DiagnosticRow(
                        title = "واجهة الشبكة النشطة:",
                        value = hotspotStatus.interfaceName ?: "ap0 / wlan1 (افتراضي)"
                    )
                    DiagnosticRow(
                        title = "عنوان بوابة Hotspot:",
                        value = hotspotStatus.gatewayIp ?: "192.168.43.1"
                    )
                    DiagnosticRow(
                        title = "نطاق الشبكة الفرعية:",
                        value = "${hotspotStatus.subnetPrefix}.2 إلى ${hotspotStatus.subnetPrefix}.254"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SignalGreen.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SignalGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "مستوى موثوقية الأجهزة النشطة: عالي ومؤكد بنسبة 100% لأي جهاز يستجيب على الشبكة الفرعية",
                                style = MaterialTheme.typography.bodySmall,
                                color = SignalGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Permissions Status
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("permissions_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = HotspotCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "حالة الصلاحيات النظامية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    PermissionItem(
                        name = "الإشعارات الدائمة (POST_NOTIFICATIONS)",
                        isGranted = isPostNotificationsGranted,
                        note = "مطلوب لإبقاء الإشعار الدائم وتحديث عدد الأجهزة في الخلفية"
                    )
                    PermissionItem(
                        name = "الوصول لحالة الشبكة (ACCESS_NETWORK_STATE)",
                        isGranted = isNetworkStateGranted,
                        note = "مطلوب لقراءة عناوين IP وواجهات نقطة الاتصال"
                    )
                    PermissionItem(
                        name = "حالة اتصال Wi-Fi (ACCESS_WIFI_STATE)",
                        isGranted = isWifiStateGranted,
                        note = "مطلوب لاستقبال أحداث تشغيل وإيقاف نقطة الاتصال"
                    )
                    PermissionItem(
                        name = "خدمة الخلفية للمراقبة (FOREGROUND_SERVICE)",
                        isGranted = true,
                        note = "مصرّح بها في AndroidManifest لضمان عدم إيقاف الخدمة"
                    )
                }
            }
        }

        // Android 15 & realme Technical Limitations Transparency
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("android_limitations_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = SignalAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "الشفافية التقنية: حدود Android 15 و realme C53",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "1. قيود عناوين MAC:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = HotspotCyan
                    )
                    Text(
                        text = "بدءاً من Android 10 وتم تشديده في Android 15، تفرض Google حماية SELinux صارمة تعزل ملف النواة /proc/net/arp تماماً عن التطبيقات العادية لحماية خصوصية المستخدمين ومنع تتبعهم. لذلك يتم عرض 'غير متاح (حماية Android 15)' بدلاً من توليد بيانات وهمية.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "2. واجهة عملاء نقطة الاتصال الرسمية:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = HotspotCyan
                    )
                    Text(
                        text = "واجهات TetheringManager.registerTetheringEventCallback المباشرة تتطلب تصريح MAINLINE_NETWORK_STACK أو توقيع النظام (System Signature)، ولا تمنحها أنظمة Android للتطبيقات المستقلة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "3. خوارزمية منع التردد (Anti-Flapping):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = HotspotCyan
                    )
                    Text(
                        text = "لتجنب اختفاء الأجهزة عند دخولها وضع توفير الطاقة (Sleep Mode)، لا يقوم التطبيق باعتبار الجهاز قد غادر الشبكة بعد فشل فحص واحد؛ بل يتطلب 4 دورات فحص فاشلة متتالية قبل تأكيد مغادرته.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun DiagnosticRow(title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun PermissionItem(
    name: String,
    isGranted: Boolean,
    note: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isGranted) SignalGreen else SignalAmber,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = note,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}
