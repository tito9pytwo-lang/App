package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material.icons.filled.WifiTetheringOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.components.DeviceItemCard
import com.example.ui.theme.HotspotCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.viewmodel.HotspotViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: HotspotViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hotspotStatus by viewModel.hotspotStatus.collectAsState()
    val connectedDevices by viewModel.connectedDevices.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val lastScanTime by viewModel.lastScanTime.collectAsState()
    val isMonitoringActive by viewModel.isMonitoringActive.collectAsState()

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Notification permission banner if missing
            if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .testTag("notification_permission_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = SignalAmber.copy(alpha = 0.15f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "صلاحية الإشعارات",
                            tint = SignalAmber
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تفعيل إشعارات المراقبة الدائمة",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "مطلوب لإظهار عدد الأجهزة المتصلة في شريط الإشعارات على Android 15",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalAmber),
                            contentPadding = ButtonDefaults.TextButtonContentPadding
                        ) {
                            Text("سماح", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Hotspot Status Bar
            HotspotStatusBar(
                status = hotspotStatus,
                onOpenHotspotSettings = {
                    try {
                        val intent = Intent("android.settings.TETHER_SETTINGS")
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        try {
                            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                        } catch (_: Exception) {}
                    }
                }
            )
        }

        // Big Connected Device Hero Counter Card
        item {
            ConnectedCountHeroCard(
                deviceCount = connectedDevices.size,
                isScanning = isScanning,
                isMonitoringActive = isMonitoringActive,
                lastScanTime = lastScanTime,
                isHotspotEnabled = hotspotStatus.isEnabled,
                timeFormat = timeFormat
            )
        }

        // Action Controls Row
        item {
            ActionControls(
                isMonitoringActive = isMonitoringActive,
                isScanning = isScanning,
                onToggleMonitoring = {
                    if (isMonitoringActive) {
                        viewModel.stopMonitoring()
                    } else {
                        viewModel.startMonitoring()
                    }
                },
                onManualRefresh = {
                    viewModel.refreshManually()
                }
            )
        }

        // Header for Devices List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأجهزة المتصلة حالياً",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Surface(
                    shape = CircleShape,
                    color = HotspotCyan.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${connectedDevices.size} جهاز",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = HotspotCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // List of Connected Devices or Empty State
        if (connectedDevices.isEmpty()) {
            item {
                EmptyDevicesState(
                    isHotspotEnabled = hotspotStatus.isEnabled,
                    isMonitoring = isMonitoringActive,
                    isScanning = isScanning,
                    onStartScan = { viewModel.refreshManually() }
                )
            }
        } else {
            items(
                items = connectedDevices,
                key = { it.ip }
            ) { device ->
                DeviceItemCard(device = device)
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun HotspotStatusBar(
    status: com.example.data.model.HotspotStatus,
    onOpenHotspotSettings: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hotspot_status_bar"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (status.isEnabled) SignalGreen.copy(alpha = 0.15f)
                            else SignalAmber.copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (status.isEnabled) Icons.Default.WifiTethering else Icons.Default.WifiTetheringOff,
                        contentDescription = "حالة نقطة الاتصال",
                        tint = if (status.isEnabled) SignalGreen else SignalAmber,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (status.isEnabled) SignalGreen else SignalAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (status.isEnabled) "نقطة الاتصال مفعّلة" else "نقطة الاتصال متوقفة",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = if (status.isEnabled) "البوابة: ${status.gatewayIp ?: "192.168.43.1"}" else "اضغط لفتح إعدادات Hotspot",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            IconButton(
                onClick = onOpenHotspotSettings,
                modifier = Modifier.testTag("hotspot_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "إعدادات نقطة الاتصال",
                    tint = HotspotCyan
                )
            }
        }
    }
}

@Composable
private fun ConnectedCountHeroCard(
    deviceCount: Int,
    isScanning: Boolean,
    isMonitoringActive: Boolean,
    lastScanTime: Long,
    isHotspotEnabled: Boolean,
    timeFormat: SimpleDateFormat
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_count_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = HotspotCyan.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top status pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isScanning) HotspotCyan.copy(alpha = 0.15f)
                    else if (isMonitoringActive) SignalGreen.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 2.dp,
                                color = HotspotCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري الفحص الآن...",
                                style = MaterialTheme.typography.labelMedium,
                                color = HotspotCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else if (isMonitoringActive) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(SignalGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المراقبة المستمرة نشطة",
                                style = MaterialTheme.typography.labelMedium,
                                color = SignalGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المراقبة متوقفة",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Giant Animated Number
                Text(
                    text = "$deviceCount",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 76.sp,
                        fontWeight = FontWeight.Black
                    ),
                    color = if (deviceCount > 0) HotspotCyan else MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = when (deviceCount) {
                        0 -> "لا توجد أجهزة متصلة"
                        1 -> "جهاز واحد متصل بنقطة الاتصال"
                        2 -> "جهازان متصلان بنقطة الاتصال"
                        in 3..10 -> "$deviceCount أجهزة متصلة بنقطة الاتصال"
                        else -> "$deviceCount جهازاً متصلاً بنقطة الاتصال"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Last Update Time
                Text(
                    text = if (lastScanTime > 0) {
                        "آخر تحديث: ${timeFormat.format(Date(lastScanTime))}"
                    } else {
                        "لم يتم الفحص بعد"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ActionControls(
    isMonitoringActive: Boolean,
    isScanning: Boolean,
    onToggleMonitoring: () -> Unit,
    onManualRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Toggle Monitoring Button
        Button(
            onClick = onToggleMonitoring,
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("toggle_monitoring_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isMonitoringActive) SignalRed else SignalGreen
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(
                imageVector = if (isMonitoringActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = if (isMonitoringActive) "إيقاف المراقبة" else "بدء المراقبة",
                tint = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isMonitoringActive) "إيقاف المراقبة" else "بدء المراقبة",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Manual Refresh Button
        FilledTonalButton(
            onClick = onManualRefresh,
            enabled = !isScanning,
            modifier = Modifier
                .height(52.dp)
                .testTag("manual_refresh_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = HotspotCyan.copy(alpha = 0.15f),
                contentColor = HotspotCyan
            )
        ) {
            if (isScanning) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = HotspotCyan
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "تحديث فوري",
                    tint = HotspotCyan
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "تحديث",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun EmptyDevicesState(
    isHotspotEnabled: Boolean,
    isMonitoring: Boolean,
    isScanning: Boolean,
    onStartScan: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_devices_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(HotspotCyan.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Wifi,
                    contentDescription = "لا توجد أجهزة",
                    tint = HotspotCyan,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (!isHotspotEnabled) "نقطة الاتصال غير مفعّلة" else "لم يتم اكتشاف أجهزة متصلة بعد",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (!isHotspotEnabled) {
                    "يرجى تشغيل نقطة الاتصال الشخصية من إعدادات الهاتف لبدء استقبال اتصالات الأجهزة."
                } else {
                    "تأكد من اتصال الأجهزة بشبكة Hotspot، ثم اضغط على زر التحديث أو ابدأ المراقبة التلقائية."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (isHotspotEnabled && !isMonitoring) {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(
                    onClick = onStartScan,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إجراء فحص سريع")
                }
            }
        }
    }
}
