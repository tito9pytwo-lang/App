package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tech / Cyber Network Palette
val HotspotCyan = Color(0xFF00D1FF)
val HotspotCyanDark = Color(0xFF005F73)
val SignalGreen = Color(0xFF22C55E)
val SignalGreenDark = Color(0xFF15803D)
val SignalAmber = Color(0xFFF59E0B)
val SignalRed = Color(0xFFEF4444)

// Dark Theme Colors
val DarkBackground = Color(0xFF070C18)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceHighlight = Color(0xFF334155)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightSurfaceHighlight = Color(0xFFCBD5E1)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)

val PrimaryBlue = Color(0xFF0284C7)
val PrimaryBlueLight = Color(0xFF38BDF8)
