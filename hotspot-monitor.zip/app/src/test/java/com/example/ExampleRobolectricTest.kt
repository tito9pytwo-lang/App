package com.example

import com.example.data.model.ConnectedDevice
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.HotspotStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun `verify app configuration and defaults`() {
    val status = HotspotStatus(
      isEnabled = true,
      interfaceName = "wlan1",
      gatewayIp = "192.168.43.1"
    )
    assertTrue(status.isEnabled)
    assertEquals("wlan1", status.interfaceName)
    assertEquals("192.168.43.1", status.gatewayIp)
  }

  @Test
  fun `verify device status transitions and anti-flapping`() {
    val device = ConnectedDevice(
      ip = "192.168.43.120",
      status = DeviceStatus.CONNECTED,
      failedProbeCount = 0
    )
    assertEquals(DeviceStatus.CONNECTED, device.status)

    // After 2 missed probes
    val unconfirmedDevice = device.copy(
      status = DeviceStatus.UNCONFIRMED,
      failedProbeCount = 2
    )
    assertEquals(DeviceStatus.UNCONFIRMED, unconfirmedDevice.status)

    // After 4 missed probes
    val disconnectedDevice = device.copy(
      status = DeviceStatus.DISCONNECTED,
      failedProbeCount = 4
    )
    assertEquals(DeviceStatus.DISCONNECTED, disconnectedDevice.status)
  }

  @Test
  fun `verify device type identification`() {
    val phone = ConnectedDevice(ip = "192.168.43.10", deviceType = DeviceType.PHONE)
    assertEquals("هاتف ذكي", phone.deviceType.arabicLabel)

    val laptop = ConnectedDevice(ip = "192.168.43.11", deviceType = DeviceType.LAPTOP)
    assertEquals("حاسوب محمول", laptop.deviceType.arabicLabel)
  }
}
