package com.example

import com.example.data.model.ConnectedDevice
import com.example.data.model.DetectionDiagnostics
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.HotspotStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testDeviceDisplayName() {
    val deviceWithHost = ConnectedDevice(
      ip = "192.168.43.120",
      hostname = "realme_C53_guest",
      deviceType = DeviceType.PHONE
    )
    assertEquals("realme_C53_guest", deviceWithHost.displayName)

    val deviceWithoutHost = ConnectedDevice(
      ip = "192.168.43.121",
      hostname = null,
      deviceType = DeviceType.UNKNOWN
    )
    assertEquals("جهاز متصل (121)", deviceWithoutHost.displayName)
  }

  @Test
  fun testDeviceFormattedMac() {
    val device = ConnectedDevice(
      ip = "192.168.43.50",
      mac = null
    )
    assertTrue(device.formattedMac.contains("Android 15"))
  }

  @Test
  fun testHotspotStatusDefaults() {
    val status = HotspotStatus()
    assertEquals("192.168.43", status.subnetPrefix)
    assertEquals(false, status.isEnabled)
  }

  @Test
  fun testDiagnosticsTransparency() {
    val diag = DetectionDiagnostics()
    assertNotNull(diag.android15RestrictionsExplanation)
    assertTrue(diag.android15RestrictionsExplanation.contains("SELinux"))
    assertTrue(diag.android15RestrictionsExplanation.contains("/proc/net/arp"))
  }
}
