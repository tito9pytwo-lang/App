package com.example.data.db

import androidx.room.*
import com.example.data.model.BlockLogEntry
import com.example.data.model.BlockSchedule
import com.example.data.model.BlockedRule
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockedRuleDao {
    @Query("SELECT * FROM blocked_rules")
    fun getAllRules(): Flow<List<BlockedRule>>

    @Query("SELECT * FROM blocked_rules WHERE packageName = :packageName LIMIT 1")
    suspend fun getRuleForPackage(packageName: String): BlockedRule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(rule: BlockedRule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<BlockedRule>)

    @Query("DELETE FROM blocked_rules WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)

    @Query("DELETE FROM blocked_rules")
    suspend fun clearAll()
}

@Dao
interface BlockScheduleDao {
    @Query("SELECT * FROM schedules ORDER BY id DESC")
    fun getAllSchedules(): Flow<List<BlockSchedule>>

    @Query("SELECT * FROM schedules WHERE isEnabled = 1")
    suspend fun getActiveSchedules(): List<BlockSchedule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: BlockSchedule): Long

    @Update
    suspend fun updateSchedule(schedule: BlockSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: BlockSchedule)
}

@Dao
interface BlockLogDao {
    @Query("SELECT * FROM block_logs ORDER BY timestamp DESC LIMIT 150")
    fun getRecentLogs(): Flow<List<BlockLogEntry>>

    @Insert
    suspend fun insertLog(log: BlockLogEntry)

    @Query("DELETE FROM block_logs")
    suspend fun clearLogs()
}

@Database(
    entities = [BlockedRule::class, BlockSchedule::class, BlockLogEntry::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun blockedRuleDao(): BlockedRuleDao
    abstract fun blockScheduleDao(): BlockScheduleDao
    abstract fun blockLogDao(): BlockLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "net_blocker_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
