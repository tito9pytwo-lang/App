package com.example.data.model

import android.graphics.drawable.Drawable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blocked_rules")
data class BlockedRule(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isWifiBlocked: Boolean = false,
    val isDataBlocked: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "schedules")
data class BlockSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val daysOfWeek: String, // Comma separated integers 1..7 (Calendar.SUNDAY..Calendar.SATURDAY)
    val isEnabled: Boolean = true,
    val blockWifi: Boolean = true,
    val blockData: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getFormattedTime(): String {
        val startFormatted = String.format("%02d:%02d", startHour, startMinute)
        val endFormatted = String.format("%02d:%02d", endHour, endMinute)
        return "$startFormatted - $endFormatted"
    }

    fun containsDay(dayOfWeek: Int): Boolean {
        return daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }.contains(dayOfWeek)
    }
}

@Entity(tableName = "block_logs")
data class BlockLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val appName: String,
    val packageName: String,
    val networkType: String, // "WIFI" or "MOBILE_DATA"
    val reason: String
)

data class AppItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false,
    val uid: Int = 0,
    val isWifiBlocked: Boolean = false,
    val isDataBlocked: Boolean = false
) {
    val isBlocked: Boolean get() = isWifiBlocked || isDataBlocked
}
