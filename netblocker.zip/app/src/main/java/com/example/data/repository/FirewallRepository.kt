package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.data.db.AppDatabase
import com.example.data.model.AppItem
import com.example.data.model.BlockLogEntry
import com.example.data.model.BlockSchedule
import com.example.data.model.BlockedRule
import com.example.service.NetBlockVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import java.util.Calendar

class FirewallRepository(private val context: Context) {

    private val database = AppDatabase.getDatabase(context)
    private val ruleDao = database.blockedRuleDao()
    private val scheduleDao = database.blockScheduleDao()
    private val logDao = database.blockLogDao()
    private val pm = context.packageManager

    private val prefs: SharedPreferences =
        context.getSharedPreferences("net_blocker_prefs", Context.MODE_PRIVATE)

    private val _customNotificationText = MutableStateFlow(
        prefs.getString("custom_notif_text", "🛡️ تم تفعيل حظر الإنترنت على التطبيقات المحددة") ?: "🛡️ تم تفعيل حظر الإنترنت"
    )
    val customNotificationText: StateFlow<String> = _customNotificationText.asStateFlow()

    private val _themeMode = MutableStateFlow(
        prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM" // "SYSTEM", "LIGHT", "DARK"
    )
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    // Cache raw installed applications metadata
    private val _rawInstalledApps = MutableStateFlow<List<AppItem>>(emptyList())

    suspend fun loadInstalledApps() = withContext(Dispatchers.IO) {
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val myPackage = context.packageName

        val appList = packages
            .filter { it.packageName != myPackage }
            .map { appInfo ->
                val appName = try {
                    appInfo.loadLabel(pm).toString()
                } catch (_: Exception) {
                    appInfo.packageName
                }
                val icon = try {
                    appInfo.loadIcon(pm)
                } catch (_: Exception) {
                    null
                }
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                AppItem(
                    packageName = appInfo.packageName,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    uid = appInfo.uid,
                    isWifiBlocked = false,
                    isDataBlocked = false
                )
            }
            .sortedWith(compareBy({ it.isSystemApp }, { it.appName.lowercase() }))

        _rawInstalledApps.value = appList
    }

    // Combine installed apps with saved database rules
    val installedApps: Flow<List<AppItem>> = combine(
        _rawInstalledApps,
        ruleDao.getAllRules()
    ) { apps, rules ->
        val ruleMap = rules.associateBy { it.packageName }
        apps.map { app ->
            val rule = ruleMap[app.packageName]
            app.copy(
                isWifiBlocked = rule?.isWifiBlocked ?: false,
                isDataBlocked = rule?.isDataBlocked ?: false
            )
        }
    }.flowOn(Dispatchers.Default)

    val allSchedules: Flow<List<BlockSchedule>> = scheduleDao.getAllSchedules()
    val recentLogs: Flow<List<BlockLogEntry>> = logDao.getRecentLogs()

    suspend fun toggleWifi(app: AppItem) = withContext(Dispatchers.IO) {
        val newWifiState = !app.isWifiBlocked
        val rule = BlockedRule(
            packageName = app.packageName,
            appName = app.appName,
            isWifiBlocked = newWifiState,
            isDataBlocked = app.isDataBlocked
        )
        ruleDao.insertOrUpdate(rule)
        logDao.insertLog(
            BlockLogEntry(
                appName = app.appName,
                packageName = app.packageName,
                networkType = "واي فاي",
                reason = if (newWifiState) "تم حظر الواي فاي" else "تم إلغاء حظر الواي فاي"
            )
        )
        notifyVpnRuleUpdate()
    }

    suspend fun toggleData(app: AppItem) = withContext(Dispatchers.IO) {
        val newDataState = !app.isDataBlocked
        val rule = BlockedRule(
            packageName = app.packageName,
            appName = app.appName,
            isWifiBlocked = app.isWifiBlocked,
            isDataBlocked = newDataState
        )
        ruleDao.insertOrUpdate(rule)
        logDao.insertLog(
            BlockLogEntry(
                appName = app.appName,
                packageName = app.packageName,
                networkType = "بيانات الهاتف",
                reason = if (newDataState) "تم حظر بيانات الهاتف" else "تم إلغاء حظر بيانات الهاتف"
            )
        )
        notifyVpnRuleUpdate()
    }

    suspend fun blockAllWifi(onlyUserApps: Boolean = true) = withContext(Dispatchers.IO) {
        val currentApps = _rawInstalledApps.value
        val targets = if (onlyUserApps) currentApps.filter { !it.isSystemApp } else currentApps
        val currentRules = ruleDao.getAllRules().first().associateBy { it.packageName }

        val newRules = targets.map { app ->
            val existing = currentRules[app.packageName]
            BlockedRule(
                packageName = app.packageName,
                appName = app.appName,
                isWifiBlocked = true,
                isDataBlocked = existing?.isDataBlocked ?: false
            )
        }
        ruleDao.insertAll(newRules)
        logDao.insertLog(
            BlockLogEntry(
                appName = "الكل",
                packageName = "all",
                networkType = "واي فاي",
                reason = "تم حظر شبكة الواي فاي عن جميع التطبيقات (${newRules.size} تطبيق)"
            )
        )
        notifyVpnRuleUpdate()
    }

    suspend fun blockAllData(onlyUserApps: Boolean = true) = withContext(Dispatchers.IO) {
        val currentApps = _rawInstalledApps.value
        val targets = if (onlyUserApps) currentApps.filter { !it.isSystemApp } else currentApps
        val currentRules = ruleDao.getAllRules().first().associateBy { it.packageName }

        val newRules = targets.map { app ->
            val existing = currentRules[app.packageName]
            BlockedRule(
                packageName = app.packageName,
                appName = app.appName,
                isWifiBlocked = existing?.isWifiBlocked ?: false,
                isDataBlocked = true
            )
        }
        ruleDao.insertAll(newRules)
        logDao.insertLog(
            BlockLogEntry(
                appName = "الكل",
                packageName = "all",
                networkType = "بيانات الهاتف",
                reason = "تم حظر بيانات الهاتف عن جميع التطبيقات (${newRules.size} تطبيق)"
            )
        )
        notifyVpnRuleUpdate()
    }

    suspend fun unblockAll() = withContext(Dispatchers.IO) {
        ruleDao.clearAll()
        logDao.insertLog(
            BlockLogEntry(
                appName = "الكل",
                packageName = "all",
                networkType = "الكل",
                reason = "تم إلغاء حظر الإنترنت عن جميع التطبيقات"
            )
        )
        notifyVpnRuleUpdate()
    }

    suspend fun saveSchedule(schedule: BlockSchedule) = withContext(Dispatchers.IO) {
        if (schedule.id == 0L) {
            scheduleDao.insertSchedule(schedule)
        } else {
            scheduleDao.updateSchedule(schedule)
        }
    }

    suspend fun toggleSchedule(schedule: BlockSchedule) = withContext(Dispatchers.IO) {
        val updated = schedule.copy(isEnabled = !schedule.isEnabled)
        scheduleDao.updateSchedule(updated)
    }

    suspend fun deleteSchedule(schedule: BlockSchedule) = withContext(Dispatchers.IO) {
        scheduleDao.deleteSchedule(schedule)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        logDao.clearLogs()
    }

    fun setCustomNotificationText(text: String) {
        prefs.edit().putString("custom_notif_text", text).apply()
        _customNotificationText.value = text
    }

    fun setThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _themeMode.value = mode
    }

    private fun notifyVpnRuleUpdate() {
        if (NetBlockVpnService.isServiceActive.value) {
            val intent = android.content.Intent(context, NetBlockVpnService::class.java).apply {
                action = NetBlockVpnService.ACTION_UPDATE_RULES
                putExtra(NetBlockVpnService.EXTRA_CUSTOM_MESSAGE, _customNotificationText.value)
            }
            context.startService(intent)
        }
    }

    fun isScheduleActiveNow(schedule: BlockSchedule): Boolean {
        if (!schedule.isEnabled) return false
        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_WEEK)
        if (!schedule.containsDay(currentDay)) return false

        val currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        val startMinutes = schedule.startHour * 60 + schedule.startMinute
        val endMinutes = schedule.endHour * 60 + schedule.endMinute

        return if (startMinutes <= endMinutes) {
            currentMinutes in startMinutes..endMinutes
        } else {
            currentMinutes >= startMinutes || currentMinutes <= endMinutes
        }
    }
}
