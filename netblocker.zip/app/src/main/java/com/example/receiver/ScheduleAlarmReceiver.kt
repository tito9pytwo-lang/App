package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.db.AppDatabase
import com.example.service.NetBlockVpnService
import com.example.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class ScheduleAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                checkAndApplySchedules(context)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun checkAndApplySchedules(context: Context) {
        val database = AppDatabase.getDatabase(context)
        val activeSchedules = database.blockScheduleDao().getActiveSchedules()
        if (activeSchedules.isEmpty()) return

        val calendar = Calendar.getInstance()
        val currentDay = calendar.get(Calendar.DAY_OF_WEEK)
        val currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)

        for (schedule in activeSchedules) {
            if (!schedule.containsDay(currentDay)) continue

            val startMinutes = schedule.startHour * 60 + schedule.startMinute
            val endMinutes = schedule.endHour * 60 + schedule.endMinute

            val isMatch = if (startMinutes <= endMinutes) {
                currentMinutes in startMinutes..endMinutes
            } else {
                // Overnight schedule (e.g. 22:00 to 07:00)
                currentMinutes >= startMinutes || currentMinutes <= endMinutes
            }

            if (isMatch) {
                val customMsg = "تم تفعيل جدول الحظر: ${schedule.name} (${schedule.getFormattedTime()})"
                NetBlockVpnService.startService(context, customMsg)
                NotificationHelper.sendCustomAlertNotification(
                    context,
                    "⏰ جدول حظر نشط",
                    customMsg
                )
                break
            }
        }
    }
}
