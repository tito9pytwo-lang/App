package com.example.service

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.data.db.AppDatabase
import com.example.data.model.BlockLogEntry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class NetBlockVpnService : VpnService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var vpnInterface: ParcelFileDescriptor? = null
    private var isRunning = false

    companion object {
        const val ACTION_START = "com.example.action.START_VPN"
        const val ACTION_STOP = "com.example.action.STOP_VPN"
        const val ACTION_UPDATE_RULES = "com.example.action.UPDATE_RULES"
        const val EXTRA_CUSTOM_MESSAGE = "extra_custom_message"

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        fun startService(context: Context, customMessage: String? = null) {
            val intent = Intent(context, NetBlockVpnService::class.java).apply {
                action = ACTION_START
                if (customMessage != null) {
                    putExtra(EXTRA_CUSTOM_MESSAGE, customMessage)
                }
            }
            context.startService(intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, NetBlockVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                return START_NOT_STICKY
            }
            ACTION_UPDATE_RULES -> {
                if (isRunning) {
                    serviceScope.launch {
                        refreshVpnRules(intent.getStringExtra(EXTRA_CUSTOM_MESSAGE))
                    }
                }
            }
            else -> {
                val customMsg = intent?.getStringExtra(EXTRA_CUSTOM_MESSAGE)
                startVpn(customMsg)
            }
        }
        return START_STICKY
    }

    private fun startVpn(customMessage: String?) {
        if (isRunning) return
        isRunning = true
        _isServiceActive.value = true

        serviceScope.launch {
            try {
                refreshVpnRules(customMessage)
            } catch (e: Exception) {
                Log.e("NetBlockVpnService", "Error establishing VPN", e)
                stopVpn()
            }
        }
    }

    private suspend fun refreshVpnRules(customMessage: String?) {
        val database = AppDatabase.getDatabase(applicationContext)
        val allRules = database.blockedRuleDao().getAllRules().first()

        val isWifi = isCurrentNetworkWifi()
        val blockedPackages = allRules.filter { rule ->
            if (isWifi) rule.isWifiBlocked else rule.isDataBlocked
        }.map { it.packageName }

        val wifiBlockedCount = allRules.count { it.isWifiBlocked }
        val dataBlockedCount = allRules.count { it.isDataBlocked }

        // Close existing interface before building new one
        vpnInterface?.close()
        vpnInterface = null

        val builder = Builder()
            .setSession("قاطع الإنترنت")
            .setMtu(1500)
            .addAddress("10.254.1.1", 32)
            .addRoute("10.254.1.0", 24)

        var addedCount = 0
        for (pkg in blockedPackages) {
            try {
                builder.addAllowedApplication(pkg)
                addedCount++
            } catch (e: Exception) {
                Log.w("NetBlockVpnService", "Could not route package $pkg: ${e.message}")
            }
        }

        // Exclude our own app so it never blocks itself
        try {
            builder.addDisallowedApplication(packageName)
        } catch (_: Exception) {}

        vpnInterface = builder.establish()

        val notification = NotificationHelper.buildServiceNotification(
            context = applicationContext,
            customTitle = "🛡️ جدار حظر الإنترنت مفعّل",
            customMessage = customMessage,
            wifiBlockedCount = wifiBlockedCount,
            dataBlockedCount = dataBlockedCount
        )

        startForeground(NotificationHelper.NOTIFICATION_ID, notification)

        // Log action in database
        if (blockedPackages.isNotEmpty()) {
            database.blockLogDao().insertLog(
                BlockLogEntry(
                    appName = "جدار الحماية",
                    packageName = "all.firewall",
                    networkType = if (isWifi) "واي فاي" else "بيانات الهاتف",
                    reason = "تم تفعيل حظر $addedCount تطبيق بنجاح"
                )
            )
        }

        // Trigger custom alert notification requested by user
        NotificationHelper.sendCustomAlertNotification(
            context = applicationContext,
            title = "تم تفعيل الحظر بنجاح 🛡️",
            message = customMessage ?: "جدار الحماية نشط الآن لحظر $wifiBlockedCount تطبيق واي فاي و $dataBlockedCount تطبيق بيانات"
        )
    }

    private fun isCurrentNetworkWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return true
        val caps = cm.getNetworkCapabilities(network) ?: return true
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun stopVpn() {
        isRunning = false
        _isServiceActive.value = false
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.e("NetBlockVpnService", "Error closing VPN interface", e)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
