package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.LogsScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NetworkAllowed
import com.example.ui.theme.NetworkBlocked

enum class NavTab {
    APPS, SCHEDULE, LOGS, SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirewallMainApp(
    viewModel: FirewallViewModel,
    onRequireVpnPermission: (android.content.Intent) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var currentTab by remember { mutableStateOf(NavTab.APPS) }
    val context = androidx.compose.ui.platform.LocalContext.current

    // Force Arabic RTL Layout
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (uiState.isFirewallActive) NetworkAllowed else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            )
                        }
                    },
                    actions = {
                        // Small live indicator in top bar
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = if (uiState.isFirewallActive) NetworkAllowed.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(
                                            if (uiState.isFirewallActive) NetworkAllowed else MaterialTheme.colorScheme.outline,
                                            shape = androidx.compose.foundation.shape.CircleShape
                                        )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.isFirewallActive) "نشط" else "متوقف",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    ),
                                    color = if (uiState.isFirewallActive) NetworkAllowed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == NavTab.APPS,
                        onClick = { currentTab = NavTab.APPS },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.APPS) Icons.Default.Apps else Icons.Outlined.Apps,
                                contentDescription = stringResource(R.string.tab_apps)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_apps)) },
                        modifier = Modifier.testTag("nav_tab_apps")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavTab.SCHEDULE,
                        onClick = { currentTab = NavTab.SCHEDULE },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (uiState.activeSchedulesCount > 0) {
                                        Badge { Text("${uiState.activeSchedulesCount}") }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (currentTab == NavTab.SCHEDULE) Icons.Default.Schedule else Icons.Outlined.Schedule,
                                    contentDescription = stringResource(R.string.tab_schedule)
                                )
                            }
                        },
                        label = { Text(stringResource(R.string.tab_schedule)) },
                        modifier = Modifier.testTag("nav_tab_schedule")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavTab.LOGS,
                        onClick = { currentTab = NavTab.LOGS },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.LOGS) Icons.Default.History else Icons.Outlined.History,
                                contentDescription = stringResource(R.string.tab_logs)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_logs)) },
                        modifier = Modifier.testTag("nav_tab_logs")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavTab.SETTINGS,
                        onClick = { currentTab = NavTab.SETTINGS },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.SETTINGS) Icons.Default.Settings else Icons.Outlined.Settings,
                                contentDescription = stringResource(R.string.tab_settings)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_settings)) },
                        modifier = Modifier.testTag("nav_tab_settings")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    NavTab.APPS -> AppsScreen(
                        uiState = uiState,
                        onToggleFirewall = { viewModel.toggleFirewall(context, onRequireVpnPermission) },
                        onSearchChange = { viewModel.setSearchQuery(it) },
                        onFilterChange = { viewModel.setFilter(it) },
                        onToggleWifi = { viewModel.toggleWifi(it) },
                        onToggleData = { viewModel.toggleData(it) },
                        onBlockAllWifi = { viewModel.blockAllWifi() },
                        onBlockAllData = { viewModel.blockAllData() },
                        onUnblockAll = { viewModel.unblockAll() }
                    )

                    NavTab.SCHEDULE -> ScheduleScreen(
                        schedules = uiState.schedules,
                        isScheduleActive = { viewModel.isScheduleActive(it) },
                        onAddSchedule = { viewModel.saveSchedule(it) },
                        onToggleSchedule = { viewModel.toggleSchedule(it) },
                        onDeleteSchedule = { viewModel.deleteSchedule(it) }
                    )

                    NavTab.LOGS -> LogsScreen(
                        logs = uiState.logs,
                        onClearLogs = { viewModel.clearLogs() }
                    )

                    NavTab.SETTINGS -> SettingsScreen(
                        currentThemeMode = uiState.themeMode,
                        customNotificationText = uiState.customNotificationMessage,
                        onThemeModeChange = { viewModel.setThemeMode(it) },
                        onCustomNotificationTextChange = { viewModel.updateCustomNotificationMessage(it) },
                        onTestNotification = { viewModel.testCustomNotification(context) }
                    )
                }
            }
        }
    }
}
