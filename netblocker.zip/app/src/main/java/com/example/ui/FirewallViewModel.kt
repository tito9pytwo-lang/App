package com.example.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppItem
import com.example.data.model.BlockLogEntry
import com.example.data.model.BlockSchedule
import com.example.data.repository.FirewallRepository
import com.example.service.NetBlockVpnService
import com.example.service.NotificationHelper
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppFilter {
    ALL, BLOCKED, USER, SYSTEM
}

data class FirewallUiState(
    val apps: List<AppItem> = emptyList(),
    val totalAppsCount: Int = 0,
    val wifiBlockedCount: Int = 0,
    val dataBlockedCount: Int = 0,
    val activeSchedulesCount: Int = 0,
    val searchQuery: String = "",
    val filter: AppFilter = AppFilter.ALL,
    val isFirewallActive: Boolean = false,
    val schedules: List<BlockSchedule> = emptyList(),
    val logs: List<BlockLogEntry> = emptyList(),
    val customNotificationMessage: String = "",
    val themeMode: String = "SYSTEM",
    val isLoading: Boolean = true
)

class FirewallViewModel(
    private val repository: FirewallRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _filter = MutableStateFlow(AppFilter.ALL)
    private val _isLoading = MutableStateFlow(true)

    val isVpnActive: StateFlow<Boolean> = NetBlockVpnService.isServiceActive

    private data class AppFilterResult(
        val filteredApps: List<AppItem>,
        val totalCount: Int,
        val wifiBlockedCount: Int,
        val dataBlockedCount: Int,
        val query: String,
        val filter: AppFilter
    )

    private val appsStateFlow = combine(
        repository.installedApps,
        _searchQuery,
        _filter
    ) { apps, query, filter ->
        val filtered = apps.filter { app ->
            val matchesQuery = query.isBlank() ||
                    app.appName.contains(query, ignoreCase = true) ||
                    app.packageName.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                AppFilter.ALL -> true
                AppFilter.BLOCKED -> app.isBlocked
                AppFilter.USER -> !app.isSystemApp
                AppFilter.SYSTEM -> app.isSystemApp
            }
            matchesQuery && matchesFilter
        }
        AppFilterResult(
            filteredApps = filtered,
            totalCount = apps.size,
            wifiBlockedCount = apps.count { it.isWifiBlocked },
            dataBlockedCount = apps.count { it.isDataBlocked },
            query = query,
            filter = filter
        )
    }

    private data class SettingsState(
        val notifMessage: String,
        val themeMode: String,
        val isLoading: Boolean
    )

    private val settingsFlow = combine(
        repository.customNotificationText,
        repository.themeMode,
        _isLoading
    ) { notif, theme, loading ->
        SettingsState(notif, theme, loading)
    }

    val uiState: StateFlow<FirewallUiState> = combine(
        appsStateFlow,
        isVpnActive,
        repository.allSchedules,
        repository.recentLogs,
        settingsFlow
    ) { appResult, vpnActive, schedules, logs, settings ->
        val activeSchedules = schedules.count { repository.isScheduleActiveNow(it) }
        FirewallUiState(
            apps = appResult.filteredApps,
            totalAppsCount = appResult.totalCount,
            wifiBlockedCount = appResult.wifiBlockedCount,
            dataBlockedCount = appResult.dataBlockedCount,
            activeSchedulesCount = activeSchedules,
            searchQuery = appResult.query,
            filter = appResult.filter,
            isFirewallActive = vpnActive,
            schedules = schedules,
            logs = logs,
            customNotificationMessage = settings.notifMessage,
            themeMode = settings.themeMode,
            isLoading = settings.isLoading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FirewallUiState()
    )

    init {
        viewModelScope.launch {
            repository.loadInstalledApps()
            _isLoading.value = false
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: AppFilter) {
        _filter.value = filter
    }

    fun toggleWifi(app: AppItem) {
        viewModelScope.launch {
            repository.toggleWifi(app)
        }
    }

    fun toggleData(app: AppItem) {
        viewModelScope.launch {
            repository.toggleData(app)
        }
    }

    fun blockAllWifi(onlyUser: Boolean = true) {
        viewModelScope.launch {
            repository.blockAllWifi(onlyUser)
        }
    }

    fun blockAllData(onlyUser: Boolean = true) {
        viewModelScope.launch {
            repository.blockAllData(onlyUser)
        }
    }

    fun unblockAll() {
        viewModelScope.launch {
            repository.unblockAll()
        }
    }

    fun toggleFirewall(context: Context, onRequireVpnPermission: (Intent) -> Unit) {
        if (isVpnActive.value) {
            NetBlockVpnService.stopService(context)
            NotificationHelper.sendCustomAlertNotification(
                context,
                "تم إيقاف جدار الحماية",
                "تم تعطيل حظر الإنترنت واستعادة اتصال جميع التطبيقات"
            )
        } else {
            val vpnIntent = VpnService.prepare(context)
            if (vpnIntent != null) {
                onRequireVpnPermission(vpnIntent)
            } else {
                startFirewallDirectly(context)
            }
        }
    }

    fun startFirewallDirectly(context: Context) {
        NetBlockVpnService.startService(context, uiState.value.customNotificationMessage)
    }

    fun saveSchedule(schedule: BlockSchedule) {
        viewModelScope.launch {
            repository.saveSchedule(schedule)
        }
    }

    fun toggleSchedule(schedule: BlockSchedule) {
        viewModelScope.launch {
            repository.toggleSchedule(schedule)
        }
    }

    fun deleteSchedule(schedule: BlockSchedule) {
        viewModelScope.launch {
            repository.deleteSchedule(schedule)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun updateCustomNotificationMessage(text: String) {
        repository.setCustomNotificationText(text)
    }

    fun setThemeMode(mode: String) {
        repository.setThemeMode(mode)
    }

    fun isScheduleActive(schedule: BlockSchedule): Boolean {
        return repository.isScheduleActiveNow(schedule)
    }

    fun testCustomNotification(context: Context) {
        val currentMsg = uiState.value.customNotificationMessage
        NotificationHelper.sendCustomAlertNotification(
            context,
            "تجربة التنبيه المخصص 🛡️",
            if (currentMsg.isNotBlank()) currentMsg else "تنبيه تجريبي: جدار الحماية نشط ويتم حظر الإنترنت"
        )
    }
}

class FirewallViewModelFactory(
    private val repository: FirewallRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FirewallViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FirewallViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
