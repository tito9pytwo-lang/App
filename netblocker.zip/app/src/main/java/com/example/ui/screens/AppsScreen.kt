package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppItem
import com.example.ui.AppFilter
import com.example.ui.FirewallUiState
import com.example.ui.components.AppIconImage
import com.example.ui.components.MasterSwitchCard
import com.example.ui.theme.NetworkAllowed
import com.example.ui.theme.NetworkBlocked
import com.example.ui.theme.NetworkData
import com.example.ui.theme.NetworkWifi

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    uiState: FirewallUiState,
    onToggleFirewall: () -> Unit,
    onSearchChange: (String) -> Unit,
    onFilterChange: (AppFilter) -> Unit,
    onToggleWifi: (AppItem) -> Unit,
    onToggleData: (AppItem) -> Unit,
    onBlockAllWifi: () -> Unit,
    onBlockAllData: () -> Unit,
    onUnblockAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showBatchActions by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
    ) {
        // Master Firewall Toggle Card
        item {
            MasterSwitchCard(
                isActive = uiState.isFirewallActive,
                wifiBlockedCount = uiState.wifiBlockedCount,
                dataBlockedCount = uiState.dataBlockedCount,
                activeSchedulesCount = uiState.activeSchedulesCount,
                onToggle = onToggleFirewall
            )
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_search_input"),
                placeholder = {
                    Text(
                        stringResource(R.string.search_hint),
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear search",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            )
        }

        // Filter Chips & Quick Action Toggle Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        FilterChip(
                            selected = uiState.filter == AppFilter.ALL,
                            onClick = { onFilterChange(AppFilter.ALL) },
                            label = { Text("${stringResource(R.string.filter_all)} (${uiState.totalAppsCount})") },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = uiState.filter == AppFilter.BLOCKED,
                            onClick = { onFilterChange(AppFilter.BLOCKED) },
                            label = {
                                Text(
                                    "${stringResource(R.string.filter_blocked)} (${uiState.wifiBlockedCount + uiState.dataBlockedCount})"
                                )
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = uiState.filter == AppFilter.USER,
                            onClick = { onFilterChange(AppFilter.USER) },
                            label = { Text(stringResource(R.string.filter_user)) },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    item {
                        FilterChip(
                            selected = uiState.filter == AppFilter.SYSTEM,
                            onClick = { onFilterChange(AppFilter.SYSTEM) },
                            label = { Text(stringResource(R.string.filter_system)) },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { showBatchActions = !showBatchActions },
                    modifier = Modifier
                        .padding(start = 4.dp)
                        .testTag("batch_actions_toggle_btn")
                ) {
                    Icon(
                        imageVector = if (showBatchActions) Icons.Default.ExpandLess else Icons.Default.Tune,
                        contentDescription = "Batch Actions",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Expandable Quick Batch Actions
        item {
            AnimatedVisibility(visible = showBatchActions) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "إجراءات جماعية سريعة",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onBlockAllWifi,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.WifiOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حظر واي فاي", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onBlockAllData,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.SignalCellularOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حظر بيانات", fontSize = 11.sp)
                            }
                            FilledTonalButton(
                                onClick = onUnblockAll,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("سماح للكل", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Loading or Empty State
        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        } else if (uiState.apps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "لا توجد تطبيقات تطابق البحث أو الفلتر المحدد",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Apps List Items
            items(uiState.apps, key = { it.packageName }) { app ->
                AppItemCard(
                    app = app,
                    onToggleWifi = { onToggleWifi(app) },
                    onToggleData = { onToggleData(app) }
                )
            }
        }
    }
}

@Composable
fun AppItemCard(
    app: AppItem,
    onToggleWifi: () -> Unit,
    onToggleData: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("app_item_${app.packageName}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Icon & Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                AppIconImage(
                    drawable = app.icon,
                    appName = app.appName,
                    size = 46.dp
                )

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = app.appName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (app.isSystemApp) {
                            Text(
                                text = "نظام",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Wi-Fi and Cellular Data Block Toggle Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Wi-Fi Toggle Button
                NetworkToggleButton(
                    isBlocked = app.isWifiBlocked,
                    networkLabel = "واي فاي",
                    blockedIcon = Icons.Default.WifiOff,
                    allowedIcon = Icons.Default.Wifi,
                    networkColor = NetworkWifi,
                    onToggle = onToggleWifi,
                    testTag = "toggle_wifi_${app.packageName}"
                )

                // Mobile Data Toggle Button
                NetworkToggleButton(
                    isBlocked = app.isDataBlocked,
                    networkLabel = "بيانات",
                    blockedIcon = Icons.Default.SignalCellularOff,
                    allowedIcon = Icons.Default.SignalCellularAlt,
                    networkColor = NetworkData,
                    onToggle = onToggleData,
                    testTag = "toggle_data_${app.packageName}"
                )
            }
        }
    }
}

@Composable
fun NetworkToggleButton(
    isBlocked: Boolean,
    networkLabel: String,
    blockedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    allowedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    networkColor: Color,
    onToggle: () -> Unit,
    testTag: String
) {
    val bgColor by animateColorAsState(
        targetValue = if (isBlocked) NetworkBlocked.copy(alpha = 0.16f) else networkColor.copy(alpha = 0.1f),
        label = "bgColor"
    )
    val borderColor by animateColorAsState(
        targetValue = if (isBlocked) NetworkBlocked else networkColor.copy(alpha = 0.3f),
        label = "borderColor"
    )
    val iconColor by animateColorAsState(
        targetValue = if (isBlocked) NetworkBlocked else networkColor,
        label = "iconColor"
    )

    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onToggle)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isBlocked) blockedIcon else allowedIcon,
                contentDescription = if (isBlocked) "$networkLabel محظور" else "$networkLabel مسموح",
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = if (isBlocked) "محظور" else "مسموح",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = iconColor
            )
        }
    }
}
