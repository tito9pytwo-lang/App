package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand - Sapphire & Cyan Cyber Shield
val ShieldPrimaryDark = Color(0xFF38BDF8)      // Light sky cyan
val ShieldOnPrimaryDark = Color(0xFF00354E)
val ShieldPrimaryContainerDark = Color(0xFF075985)
val ShieldOnPrimaryContainerDark = Color(0xFFBAE6FD)

val ShieldPrimaryLight = Color(0xFF0284C7)     // Deep azure
val ShieldOnPrimaryLight = Color(0xFFFFFFFF)
val ShieldPrimaryContainerLight = Color(0xFFE0F2FE)
val ShieldOnPrimaryContainerLight = Color(0xFF0369A1)

// Status & Network Badges
val NetworkAllowed = Color(0xFF10B981)         // Emerald Green (Allowed)
val NetworkBlocked = Color(0xFFEF4444)         // Crimson Red (Blocked)
val NetworkWifi = Color(0xFF0284C7)            // Sky Blue
val NetworkData = Color(0xFF8B5CF6)            // Indigo Violet

// Backgrounds & Surfaces
val SlateBackgroundDark = Color(0xFF0B0F19)
val SlateSurfaceDark = Color(0xFF131B2E)
val SlateCardDark = Color(0xFF1E293B)
val SlateBorderDark = Color(0xFF334155)

val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateCardLight = Color(0xFFF1F5F9)
val SlateBorderLight = Color(0xFFE2E8F0)
