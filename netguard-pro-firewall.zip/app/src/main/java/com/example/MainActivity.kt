package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.FirewallViewModel
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.LiveLogsScreen
import com.example.ui.theme.BlockCrimson
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: FirewallViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshNetworkStatus()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: FirewallViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val logs by viewModel.recentLogs.collectAsState()
    val totalPackets by viewModel.dbTotalPackets.collectAsState()
    val totalBytes by viewModel.dbTotalBytes.collectAsState()

    var selectedNavIndex by rememberSaveable { mutableIntStateOf(0) }

    // Launcher for VPN system permission dialog
    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.setFirewallActive(true, context)
            Toast.makeText(context, "تم تفعيل جدار الحماية بنجاح", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "تم رفض صلاحية الـ VPN، لم يتم تشغيل الجدار", Toast.LENGTH_SHORT).show()
        }
    }

    // Launcher for Notification permission (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Handled silently */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    fun handleToggleFirewall(enable: Boolean) {
        if (enable) {
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnLauncher.launch(prepareIntent)
            } else {
                viewModel.setFirewallActive(true, context)
                Toast.makeText(context, "تم تفعيل جدار الحماية بنجاح", Toast.LENGTH_SHORT).show()
            }
        } else {
            viewModel.setFirewallActive(false, context)
            Toast.makeText(context, "تم إيقاف جدار الحماية", Toast.LENGTH_SHORT).show()
        }
    }

    BackHandler(enabled = selectedNavIndex != 0) {
        selectedNavIndex = 0
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = CyberBlack,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ElectricCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "NetShield",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "جدار حماية محلي بدون Root",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Status badge in TopBar
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    if (uiState.isFirewallActive) ShieldEmerald.copy(alpha = 0.18f)
                                    else Color(0xFF1E293B)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(if (uiState.isFirewallActive) ShieldEmerald else Color(0xFF64748B))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.isFirewallActive) "الحماية نشطة" else "متوقف",
                                    color = if (uiState.isFirewallActive) ShieldEmerald else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberDarkSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberDarkSurface,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedNavIndex == 0,
                    onClick = { selectedNavIndex = 0 },
                    icon = { Icon(Icons.Filled.Apps, contentDescription = "Apps") },
                    label = { Text("التطبيقات", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ElectricCyan,
                        selectedTextColor = ElectricCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = ElectricCyan.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_apps")
                )

                NavigationBarItem(
                    selected = selectedNavIndex == 1,
                    onClick = { selectedNavIndex = 1 },
                    icon = { Icon(Icons.Filled.History, contentDescription = "Logs") },
                    label = { Text("سجل الحظر", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BlockCrimson,
                        selectedTextColor = BlockCrimson,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = BlockCrimson.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_logs")
                )

                NavigationBarItem(
                    selected = selectedNavIndex == 2,
                    onClick = { selectedNavIndex = 2 },
                    icon = { Icon(Icons.Filled.NetworkCheck, contentDescription = "Diagnostics") },
                    label = { Text("فحص الحظر", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ShieldEmerald,
                        selectedTextColor = ShieldEmerald,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = ShieldEmerald.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("nav_diagnostics")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedNavIndex) {
                0 -> AppsScreen(
                    state = uiState,
                    onToggleFirewall = ::handleToggleFirewall,
                    onSearchQueryChanged = viewModel::onSearchQueryChanged,
                    onTabChanged = viewModel::onTabChanged,
                    onToggleShowSystemApps = viewModel::toggleShowSystemApps,
                    onToggleAppBlock = viewModel::toggleAppBlock,
                    onToggleWifiBlock = viewModel::setWifiBlock,
                    onToggleMobileBlock = viewModel::setMobileBlock,
                    onBlockAll = viewModel::blockAllApps,
                    onAllowAll = viewModel::allowAllApps
                )
                1 -> LiveLogsScreen(
                    logs = logs,
                    totalPackets = totalPackets,
                    totalBytes = totalBytes,
                    onClearLogs = viewModel::clearLogs
                )
                2 -> DiagnosticsScreen(
                    diagnostic = uiState.diagnostic,
                    apps = uiState.apps,
                    isFirewallActive = uiState.isFirewallActive,
                    autoStartOnBoot = uiState.autoStartOnBoot,
                    blockNewApps = uiState.blockNewApps,
                    onRunDiagnostic = viewModel::runDiagnosticTest,
                    onToggleAutoStart = viewModel::toggleAutoStart,
                    onToggleBlockNewApps = viewModel::toggleBlockNewApps,
                    onToggleAppBlock = viewModel::toggleAppBlock
                )
            }
        }
    }
}
