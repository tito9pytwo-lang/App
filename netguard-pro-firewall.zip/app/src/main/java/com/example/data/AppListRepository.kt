package com.example.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.core.graphics.createBitmap
import com.example.model.AppItem
import com.example.model.AppRule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class AppListRepository(
    private val context: Context,
    private val preferences: FirewallPreferences
) {
    private val packageManager: PackageManager = context.packageManager
    private val iconCache = ConcurrentHashMap<String, Bitmap>()

    data class RawApp(
        val packageName: String,
        val appName: String,
        val uid: Int,
        val isSystemApp: Boolean
    )

    private var cachedRawApps: List<RawApp>? = null

    suspend fun getInstalledApps(forceRefresh: Boolean = false): List<RawApp> = withContext(Dispatchers.IO) {
        if (!forceRefresh && cachedRawApps != null) {
            return@withContext cachedRawApps!!
        }

        val installedPackages = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            packageManager.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }

        val myPackageName = context.packageName
        val rawList = mutableListOf<RawApp>()

        for (pkgInfo in installedPackages) {
            val appInfo = pkgInfo.applicationInfo ?: continue
            val pkgName = pkgInfo.packageName

            // Skip NetShield itself from blocking list so user doesn't accidentally block the firewall
            if (pkgName == myPackageName) continue

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

            // Check if app has INTERNET permission or launcher intent
            val permissions = pkgInfo.requestedPermissions
            val hasInternet = permissions?.contains(android.Manifest.permission.INTERNET) == true

            // We include apps that have internet permission or launcher activity
            if (hasInternet || !isSystem) {
                val label = try {
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (_: Exception) {
                    pkgName
                }

                rawList.add(
                    RawApp(
                        packageName = pkgName,
                        appName = if (label.isNotBlank()) label else pkgName,
                        uid = appInfo.uid,
                        isSystemApp = isSystem
                    )
                )
            }
        }

        // Sort: user apps first, then alphabetically
        val sorted = rawList.sortedWith(
            compareBy<RawApp> { it.isSystemApp }
                .thenBy { it.appName.lowercase() }
        )
        cachedRawApps = sorted
        sorted
    }

    fun observeAppItems(): Flow<List<AppItem>> {
        return preferences.rulesFlow.combine(
            kotlinx.coroutines.flow.flow {
                emit(getInstalledApps())
            }
        ) { rules, rawApps ->
            rawApps.map { raw ->
                val rule = rules[raw.packageName]
                AppItem(
                    packageName = raw.packageName,
                    appName = raw.appName,
                    uid = raw.uid,
                    isSystemApp = raw.isSystemApp,
                    blockWifi = rule?.blockWifi ?: false,
                    blockMobile = rule?.blockMobile ?: false,
                    icon = getAppIcon(raw.packageName)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    fun getAppIcon(packageName: String): Bitmap? {
        iconCache[packageName]?.let { return it }
        return try {
            val drawable = packageManager.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable)
            iconCache[packageName] = bitmap
            bitmap
        } catch (_: Exception) {
            null
        }
    }

    fun updateAppRule(packageName: String, blockWifi: Boolean, blockMobile: Boolean) {
        val raw = cachedRawApps?.find { it.packageName == packageName }
        val appName = raw?.appName ?: packageName
        val uid = raw?.uid ?: 0
        val isSystem = raw?.isSystemApp ?: false

        preferences.updateRule(
            AppRule(
                packageName = packageName,
                appName = appName,
                uid = uid,
                isSystemApp = isSystem,
                blockWifi = blockWifi,
                blockMobile = blockMobile
            )
        )
    }

    fun toggleAppBlock(packageName: String) {
        val currentRule = preferences.getRules()[packageName]
        val willBlock = currentRule == null || (!currentRule.blockWifi && !currentRule.blockMobile)
        updateAppRule(packageName, blockWifi = willBlock, blockMobile = willBlock)
    }

    suspend fun setAllAppsBlocked(block: Boolean, systemAppsOnly: Boolean? = null) {
        val rawApps = getInstalledApps()
        val currentRules = preferences.getRules().toMutableMap()
        for (app in rawApps) {
            if (systemAppsOnly != null && app.isSystemApp != systemAppsOnly) continue
            if (block) {
                currentRules[app.packageName] = AppRule(
                    packageName = app.packageName,
                    appName = app.appName,
                    uid = app.uid,
                    isSystemApp = app.isSystemApp,
                    blockWifi = true,
                    blockMobile = true
                )
            } else {
                currentRules.remove(app.packageName)
            }
        }
        preferences.batchUpdateRules(currentRules.values.toList())
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = createBitmap(width, height)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
