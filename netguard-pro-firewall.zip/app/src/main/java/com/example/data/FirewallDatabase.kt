package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.TrafficLog

@Database(entities = [TrafficLog::class], version = 1, exportSchema = false)
abstract class FirewallDatabase : RoomDatabase() {

    abstract fun trafficLogDao(): TrafficLogDao

    companion object {
        @Volatile
        private var INSTANCE: FirewallDatabase? = null

        fun getInstance(context: Context): FirewallDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FirewallDatabase::class.java,
                    "netshield_firewall.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
