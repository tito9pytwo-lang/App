package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppRule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class FirewallPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _rulesFlow = MutableStateFlow<Map<String, AppRule>>(loadRules())
    val rulesFlow: StateFlow<Map<String, AppRule>> = _rulesFlow.asStateFlow()

    private val _isFirewallRunning = MutableStateFlow(isFirewallEnabled())
    val isFirewallRunning: StateFlow<Boolean> = _isFirewallRunning.asStateFlow()

    fun isFirewallEnabled(): Boolean = prefs.getBoolean(KEY_FIREWALL_ENABLED, false)

    fun setFirewallEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_FIREWALL_ENABLED, enabled).apply()
        _isFirewallRunning.value = enabled
    }

    fun isAutoStartOnBoot(): Boolean = prefs.getBoolean(KEY_AUTO_START_BOOT, true)

    fun setAutoStartOnBoot(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_START_BOOT, enabled).apply()
    }

    fun isBlockNewApps(): Boolean = prefs.getBoolean(KEY_BLOCK_NEW_APPS, false)

    fun setBlockNewApps(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BLOCK_NEW_APPS, enabled).apply()
    }

    fun isShowSystemApps(): Boolean = prefs.getBoolean(KEY_SHOW_SYSTEM_APPS, false)

    fun setShowSystemApps(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SHOW_SYSTEM_APPS, enabled).apply()
    }

    fun getRules(): Map<String, AppRule> = _rulesFlow.value

    fun updateRule(rule: AppRule) {
        val current = _rulesFlow.value.toMutableMap()
        if (!rule.blockWifi && !rule.blockMobile) {
            current.remove(rule.packageName)
        } else {
            current[rule.packageName] = rule
        }
        saveRules(current)
        _rulesFlow.value = current
    }

    fun batchUpdateRules(rules: List<AppRule>) {
        val current = _rulesFlow.value.toMutableMap()
        for (rule in rules) {
            if (!rule.blockWifi && !rule.blockMobile) {
                current.remove(rule.packageName)
            } else {
                current[rule.packageName] = rule
            }
        }
        saveRules(current)
        _rulesFlow.value = current
    }

    fun clearAllRules() {
        prefs.edit().remove(KEY_RULES_JSON).apply()
        _rulesFlow.value = emptyMap()
    }

    private fun loadRules(): Map<String, AppRule> {
        val jsonStr = prefs.getString(KEY_RULES_JSON, null) ?: return emptyMap()
        val result = mutableMapOf<String, AppRule>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val pkg = obj.optString("packageName", "")
                if (pkg.isNotEmpty()) {
                    result[pkg] = AppRule(
                        packageName = pkg,
                        appName = obj.optString("appName", pkg),
                        uid = obj.optInt("uid", 0),
                        isSystemApp = obj.optBoolean("isSystemApp", false),
                        blockWifi = obj.optBoolean("blockWifi", false),
                        blockMobile = obj.optBoolean("blockMobile", false)
                    )
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    private fun saveRules(map: Map<String, AppRule>) {
        val jsonArray = JSONArray()
        for ((_, rule) in map) {
            val obj = JSONObject()
            obj.put("packageName", rule.packageName)
            obj.put("appName", rule.appName)
            obj.put("uid", rule.uid)
            obj.put("isSystemApp", rule.isSystemApp)
            obj.put("blockWifi", rule.blockWifi)
            obj.put("blockMobile", rule.blockMobile)
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_RULES_JSON, jsonArray.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "netshield_firewall_prefs"
        private const val KEY_FIREWALL_ENABLED = "key_firewall_enabled"
        private const val KEY_AUTO_START_BOOT = "key_auto_start_boot"
        private const val KEY_BLOCK_NEW_APPS = "key_block_new_apps"
        private const val KEY_SHOW_SYSTEM_APPS = "key_show_system_apps"
        private const val KEY_RULES_JSON = "key_rules_json"

        @Volatile
        private var INSTANCE: FirewallPreferences? = null

        fun getInstance(context: Context): FirewallPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = FirewallPreferences(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
