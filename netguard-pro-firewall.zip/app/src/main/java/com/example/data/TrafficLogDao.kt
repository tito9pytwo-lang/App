package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.TrafficLog
import kotlinx.coroutines.flow.Flow

@Dao
interface TrafficLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TrafficLog)

    @Query("SELECT * FROM traffic_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentLogs(limit: Int = 100): Flow<List<TrafficLog>>

    @Query("SELECT COUNT(*) FROM traffic_logs")
    fun getTotalCount(): Flow<Long>

    @Query("SELECT COALESCE(SUM(packetSize), 0) FROM traffic_logs")
    fun getTotalBytes(): Flow<Long>

    @Query("DELETE FROM traffic_logs")
    suspend fun clearAll()
}
