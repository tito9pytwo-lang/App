package com.example.model

data class AppRule(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val isSystemApp: Boolean = false,
    val blockWifi: Boolean = false,
    val blockMobile: Boolean = false
) {
    val isFullyBlocked: Boolean
        get() = blockWifi && blockMobile

    val isPartiallyBlocked: Boolean
        get() = blockWifi || blockMobile
}
