package com.example.model

import android.graphics.Bitmap

data class AppItem(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val isSystemApp: Boolean,
    val blockWifi: Boolean,
    val blockMobile: Boolean,
    val icon: Bitmap? = null
) {
    val isBlocked: Boolean
        get() = blockWifi || blockMobile

    val isFullyBlocked: Boolean
        get() = blockWifi && blockMobile
}

enum class FilterTab {
    ALL,
    BLOCKED,
    ALLOWED
}

data class DiagnosticResult(
    val isChecking: Boolean = false,
    val isGlobalInternetAlive: Boolean? = null,
    val activeInterface: String = "غير متصل",
    val latencyMs: Long? = null,
    val blockedAppTestStatus: String? = null,
    val allowedAppTestStatus: String? = null,
    val dnsResolving: Boolean? = null,
    val timestamp: Long = 0L
)
