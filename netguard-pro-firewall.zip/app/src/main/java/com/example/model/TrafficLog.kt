package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "traffic_logs")
data class TrafficLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val appName: String,
    val protocol: String,
    val destIp: String,
    val destPort: Int,
    val packetSize: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val networkType: String = "Unknown"
)
