package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.example.data.FirewallPreferences
import com.example.service.FirewallVpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            val prefs = FirewallPreferences.getInstance(context)
            if (prefs.isFirewallEnabled() && prefs.isAutoStartOnBoot()) {
                // Check if VPN permission was already granted previously
                if (VpnService.prepare(context) == null) {
                    FirewallVpnService.startService(context)
                }
            }
        }
    }
}
