package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.FirewallDatabase
import com.example.data.FirewallPreferences
import com.example.model.TrafficLog
import com.example.util.NetworkUtils
import com.example.util.PacketParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class FirewallVpnService : VpnService() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var vpnInterface: ParcelFileDescriptor? = null
    private val isRunning = AtomicBoolean(false)
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private lateinit var preferences: FirewallPreferences
    private lateinit var database: FirewallDatabase

    private val blockedPackages = mutableSetOf<String>()
    private val packageUidMap = mutableMapOf<String, Int>()

    private val logQueue = ConcurrentLinkedQueue<TrafficLog>()

    companion object {
        private const val TAG = "FirewallVpnService"
        const val NOTIFICATION_ID = 9001
        const val CHANNEL_ID = "netshield_firewall_channel"

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val ACTION_RELOAD = "com.example.service.ACTION_RELOAD"

        val totalBlockedPackets = AtomicLong(0L)
        val totalBlockedBytes = AtomicLong(0L)
        val isServiceActive = AtomicBoolean(false)

        fun startService(context: Context) {
            val intent = Intent(context, FirewallVpnService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FirewallVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun reloadRules(context: Context) {
            val intent = Intent(context, FirewallVpnService::class.java).apply {
                action = ACTION_RELOAD
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        preferences = FirewallPreferences.getInstance(this)
        database = FirewallDatabase.getInstance(this)
        createNotificationChannel()
        startLogFlusher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopFirewall()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                serviceScope.launch {
                    reloadFirewallConfiguration()
                }
                return START_STICKY
            }
            ACTION_START, null -> {
                startFirewall()
                return START_STICKY
            }
        }
        return START_STICKY
    }

    private fun startFirewall() {
        if (isRunning.get()) {
            serviceScope.launch { reloadFirewallConfiguration() }
            return
        }

        val notification = buildNotification(0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        isRunning.set(true)
        isServiceActive.set(true)
        preferences.setFirewallEnabled(true)

        registerNetworkMonitor()

        serviceScope.launch {
            setupAndRunVpn()
        }
    }

    private fun stopFirewall() {
        isRunning.set(false)
        isServiceActive.set(false)
        preferences.setFirewallEnabled(false)

        unregisterNetworkMonitor()

        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN interface", e)
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private suspend fun reloadFirewallConfiguration() {
        if (!isRunning.get()) return
        Log.d(TAG, "Reloading firewall configuration with latest rules")
        setupAndRunVpn()
    }

    @Synchronized
    private fun setupAndRunVpn() {
        try {
            vpnInterface?.close()
            vpnInterface = null

            val isWifi = NetworkUtils.isWifiConnected(this)
            val isMobile = NetworkUtils.isMobileConnected(this)
            val rules = preferences.getRules()

            blockedPackages.clear()
            packageUidMap.clear()

            for ((pkg, rule) in rules) {
                val shouldBlock = (isWifi && rule.blockWifi) || (isMobile && rule.blockMobile) || (rule.blockWifi && rule.blockMobile)
                if (shouldBlock) {
                    blockedPackages.add(pkg)
                    packageUidMap[pkg] = rule.uid
                }
            }

            val builder = Builder().apply {
                setSession("NetShield")
                setMtu(1500)
                addAddress("10.120.0.1", 32)
                addRoute("0.0.0.0", 0)

                try {
                    addAddress("fd00::1", 128)
                    addRoute("::", 0)
                } catch (e: Exception) {
                    Log.w(TAG, "IPv6 address assignment ignored: ${e.message}")
                }

                // Non-routable dummy DNS so blocked apps immediately fail DNS resolution
                addDnsServer("10.120.0.2")

                // Selective Per-App Routing:
                // Only apps added to addAllowedApplication will enter the VPN tun interface.
                // All other apps (WhatsApp, YouTube, Chrome, etc.) completely bypass the VPN
                // and use normal direct internet with zero restrictions!
                if (blockedPackages.isNotEmpty()) {
                    for (pkg in blockedPackages) {
                        try {
                            addAllowedApplication(pkg)
                        } catch (e: PackageManager.NameNotFoundException) {
                            Log.w(TAG, "Package not found on device: $pkg")
                        }
                    }
                } else {
                    // When no apps are blocked, add our own package so the VPN session stays active
                    // without intercepting any other application traffic
                    try {
                        addAllowedApplication(packageName)
                    } catch (_: Exception) {
                    }
                }
            }

            vpnInterface = builder.establish()
            updateNotification(blockedPackages.size)

            if (vpnInterface != null) {
                serviceScope.launch {
                    processTunPackets(vpnInterface!!)
                }
            } else {
                Log.e(TAG, "builder.establish() returned null. VPN permission might be revoked.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during setupAndRunVpn", e)
        }
    }

    private fun processTunPackets(pfd: ParcelFileDescriptor) {
        val inputStream = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32768)

        val activeNet = NetworkUtils.getActiveNetworkType(this)
        val pm = packageManager

        try {
            while (isRunning.get() && serviceScope.isActive) {
                val bytesRead = inputStream.read(buffer)
                if (bytesRead > 0) {
                    totalBlockedPackets.incrementAndGet()
                    totalBlockedBytes.addAndGet(bytesRead.toLong())

                    val parsed = PacketParser.parse(buffer, bytesRead)
                    if (parsed != null) {
                        // Match with blocked package
                        val appPkg = blockedPackages.firstOrNull() ?: "blocked.app"
                        val appName = try {
                            val info = pm.getApplicationInfo(appPkg, 0)
                            pm.getApplicationLabel(info).toString()
                        } catch (_: Exception) {
                            appPkg
                        }

                        val log = TrafficLog(
                            packageName = appPkg,
                            appName = appName,
                            protocol = parsed.protocol,
                            destIp = parsed.destIp,
                            destPort = parsed.destPort,
                            packetSize = parsed.size,
                            timestamp = System.currentTimeMillis(),
                            networkType = activeNet
                        )
                        logQueue.offer(log)
                    }
                    // Packet is dropped (we do not write it to external network)
                }
            }
        } catch (e: Exception) {
            if (isRunning.get()) {
                Log.w(TAG, "TUN loop interrupted: ${e.message}")
            }
        } finally {
            try {
                inputStream.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun startLogFlusher() {
        serviceScope.launch {
            val batch = mutableListOf<TrafficLog>()
            while (isActive) {
                delay(1000)
                batch.clear()
                while (batch.size < 50 && !logQueue.isEmpty()) {
                    logQueue.poll()?.let { batch.add(it) }
                }
                if (batch.isNotEmpty()) {
                    try {
                        for (item in batch) {
                            database.trafficLogDao().insertLog(item)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error writing logs to database", e)
                    }
                }
            }
        }
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                Log.d(TAG, "Network available, evaluating firewall rules")
                serviceScope.launch {
                    delay(500)
                    reloadFirewallConfiguration()
                }
            }

            override fun onLost(network: Network) {
                Log.d(TAG, "Network lost, updating firewall")
                serviceScope.launch {
                    delay(500)
                    reloadFirewallConfiguration()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                serviceScope.launch {
                    reloadFirewallConfiguration()
                }
            }
        }

        try {
            cm.registerNetworkCallback(request, networkCallback!!)
        } catch (e: Exception) {
            Log.w(TAG, "Could not register network callback: ${e.message}")
        }
    }

    private fun unregisterNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        networkCallback?.let {
            try {
                cm.unregisterNetworkCallback(it)
            } catch (_: Exception) {
            }
            networkCallback = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(blockedCount: Int): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FirewallVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val contentText = if (blockedCount == 0) {
            "الحماية نشطة - لا توجد تطبيقات محظورة حالياً"
        } else {
            getString(R.string.notification_text_format, blockedCount)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.btn_stop_protection),
                pendingStop
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(blockedCount: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.notify(NOTIFICATION_ID, buildNotification(blockedCount))
    }

    override fun onDestroy() {
        stopFirewall()
        serviceJob.cancel()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopFirewall()
        super.onRevoke()
    }
}
