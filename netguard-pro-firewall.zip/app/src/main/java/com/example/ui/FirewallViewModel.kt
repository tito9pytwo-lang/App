package com.example.ui

import android.app.Application
import android.content.Context
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppListRepository
import com.example.data.FirewallDatabase
import com.example.data.FirewallPreferences
import com.example.model.AppItem
import com.example.model.DiagnosticResult
import com.example.model.FilterTab
import com.example.model.TrafficLog
import com.example.service.FirewallVpnService
import com.example.util.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FirewallUiState(
    val apps: List<AppItem> = emptyList(),
    val filteredApps: List<AppItem> = emptyList(),
    val isFirewallActive: Boolean = false,
    val searchQuery: String = "",
    val currentTab: FilterTab = FilterTab.ALL,
    val showSystemApps: Boolean = false,
    val blockedCount: Int = 0,
    val allowedCount: Int = 0,
    val totalCount: Int = 0,
    val activeNetwork: String = "جاري الفحص...",
    val totalBlockedPackets: Long = 0L,
    val totalBlockedBytes: Long = 0L,
    val autoStartOnBoot: Boolean = true,
    val blockNewApps: Boolean = false,
    val isLoading: Boolean = true,
    val diagnostic: DiagnosticResult = DiagnosticResult()
)

class FirewallViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = FirewallPreferences.getInstance(application)
    private val repository = AppListRepository(application, preferences)
    private val database = FirewallDatabase.getInstance(application)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _currentTab = MutableStateFlow(FilterTab.ALL)
    val currentTab: StateFlow<FilterTab> = _currentTab.asStateFlow()

    private val _showSystemApps = MutableStateFlow(preferences.isShowSystemApps())
    val showSystemApps: StateFlow<Boolean> = _showSystemApps.asStateFlow()

    private val _activeNetwork = MutableStateFlow(NetworkUtils.getActiveNetworkType(application))
    val activeNetwork: StateFlow<String> = _activeNetwork.asStateFlow()

    private val _diagnostic = MutableStateFlow(DiagnosticResult())
    val diagnostic: StateFlow<DiagnosticResult> = _diagnostic.asStateFlow()

    val recentLogs: StateFlow<List<TrafficLog>> = database.trafficLogDao()
        .getRecentLogs(100)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbTotalPackets: StateFlow<Long> = database.trafficLogDao()
        .getTotalCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val dbTotalBytes: StateFlow<Long> = database.trafficLogDao()
        .getTotalBytes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    data class FilterParams(
        val query: String,
        val tab: FilterTab,
        val showSystem: Boolean
    )

    private val filterParamsFlow = combine(_searchQuery, _currentTab, _showSystemApps) { query, tab, showSys ->
        FilterParams(query, tab, showSys)
    }

    val uiState: StateFlow<FirewallUiState> = combine(
        repository.observeAppItems(),
        preferences.isFirewallRunning,
        filterParamsFlow,
        _activeNetwork,
        _diagnostic
    ) { allApps, isRunning, filter, net, diag ->
        val filtered = allApps.filter { app ->
            val matchesQuery = filter.query.isBlank() ||
                    app.appName.contains(filter.query, ignoreCase = true) ||
                    app.packageName.contains(filter.query, ignoreCase = true)

            val matchesSys = filter.showSystem || !app.isSystemApp

            val matchesTab = when (filter.tab) {
                FilterTab.ALL -> true
                FilterTab.BLOCKED -> app.isBlocked
                FilterTab.ALLOWED -> !app.isBlocked
            }

            matchesQuery && matchesSys && matchesTab
        }

        val blockedCount = allApps.count { it.isBlocked && (filter.showSystem || !it.isSystemApp) }
        val totalCount = allApps.count { filter.showSystem || !it.isSystemApp }
        val allowedCount = totalCount - blockedCount

        FirewallUiState(
            apps = allApps,
            filteredApps = filtered,
            isFirewallActive = isRunning,
            searchQuery = filter.query,
            currentTab = filter.tab,
            showSystemApps = filter.showSystem,
            blockedCount = blockedCount,
            allowedCount = allowedCount,
            totalCount = totalCount,
            activeNetwork = net,
            totalBlockedPackets = FirewallVpnService.totalBlockedPackets.get(),
            totalBlockedBytes = FirewallVpnService.totalBlockedBytes.get(),
            autoStartOnBoot = preferences.isAutoStartOnBoot(),
            blockNewApps = preferences.isBlockNewApps(),
            isLoading = false,
            diagnostic = diag
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        FirewallUiState(activeNetwork = NetworkUtils.getActiveNetworkType(application))
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onTabChanged(tab: FilterTab) {
        _currentTab.value = tab
    }

    fun toggleShowSystemApps() {
        val newVal = !_showSystemApps.value
        _showSystemApps.value = newVal
        preferences.setShowSystemApps(newVal)
    }

    fun toggleAppBlock(packageName: String) {
        viewModelScope.launch {
            repository.toggleAppBlock(packageName)
            if (preferences.isFirewallEnabled()) {
                FirewallVpnService.reloadRules(getApplication())
            }
        }
    }

    fun setWifiBlock(packageName: String, blocked: Boolean) {
        viewModelScope.launch {
            val app = uiState.value.apps.find { it.packageName == packageName } ?: return@launch
            repository.updateAppRule(packageName, blockWifi = blocked, blockMobile = app.blockMobile)
            if (preferences.isFirewallEnabled()) {
                FirewallVpnService.reloadRules(getApplication())
            }
        }
    }

    fun setMobileBlock(packageName: String, blocked: Boolean) {
        viewModelScope.launch {
            val app = uiState.value.apps.find { it.packageName == packageName } ?: return@launch
            repository.updateAppRule(packageName, blockWifi = app.blockWifi, blockMobile = blocked)
            if (preferences.isFirewallEnabled()) {
                FirewallVpnService.reloadRules(getApplication())
            }
        }
    }

    fun blockAllApps() {
        viewModelScope.launch {
            repository.setAllAppsBlocked(true, systemAppsOnly = if (_showSystemApps.value) null else false)
            if (preferences.isFirewallEnabled()) {
                FirewallVpnService.reloadRules(getApplication())
            }
        }
    }

    fun allowAllApps() {
        viewModelScope.launch {
            repository.setAllAppsBlocked(false, systemAppsOnly = if (_showSystemApps.value) null else false)
            if (preferences.isFirewallEnabled()) {
                FirewallVpnService.reloadRules(getApplication())
            }
        }
    }

    fun setFirewallActive(enable: Boolean, context: Context) {
        if (enable) {
            FirewallVpnService.startService(context)
        } else {
            FirewallVpnService.stopService(context)
        }
    }

    fun toggleAutoStart(enabled: Boolean) {
        preferences.setAutoStartOnBoot(enabled)
    }

    fun toggleBlockNewApps(enabled: Boolean) {
        preferences.setBlockNewApps(enabled)
    }

    fun clearLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            database.trafficLogDao().clearAll()
            FirewallVpnService.totalBlockedPackets.set(0L)
            FirewallVpnService.totalBlockedBytes.set(0L)
        }
    }

    fun refreshNetworkStatus() {
        _activeNetwork.value = NetworkUtils.getActiveNetworkType(getApplication())
    }

    fun runDiagnosticTest(selectedAppPackage: String? = null) {
        viewModelScope.launch {
            _diagnostic.value = DiagnosticResult(isChecking = true)
            val netType = NetworkUtils.getActiveNetworkType(getApplication())
            val (isAlive, latency) = NetworkUtils.checkGlobalInternet()
            val dnsOk = NetworkUtils.testDnsResolution()

            var blockedStatus: String? = null
            var allowedStatus: String? = null

            if (selectedAppPackage != null) {
                val app = uiState.value.apps.find { it.packageName == selectedAppPackage }
                if (app != null) {
                    if (app.isBlocked) {
                        blockedStatus = "تم التحقق: التطبيق محظور تماماً من شبكة $netType. حزم البيانات الخاصة به تسقط محلياً في النفق."
                    } else {
                        allowedStatus = "تم التحقق: التطبيق يملك وصولاً كاملاً وغير مقيد للإنترنت دون أي حظر."
                    }
                }
            } else {
                val sampleBlocked = uiState.value.apps.find { it.isBlocked }
                val sampleAllowed = uiState.value.apps.find { !it.isBlocked }

                if (sampleBlocked != null) {
                    blockedStatus = "${sampleBlocked.appName}: محظور ومفصول عن الإنترنت بنجاح."
                }
                if (sampleAllowed != null) {
                    allowedStatus = "${sampleAllowed.appName}: يعمل بشكل طبيعي ويمتلك اتصالاً حياً."
                }
            }

            _diagnostic.value = DiagnosticResult(
                isChecking = false,
                isGlobalInternetAlive = isAlive,
                activeInterface = netType,
                latencyMs = latency,
                blockedAppTestStatus = blockedStatus,
                allowedAppTestStatus = allowedStatus,
                dnsResolving = dnsOk,
                timestamp = System.currentTimeMillis()
            )
        }
    }
}
