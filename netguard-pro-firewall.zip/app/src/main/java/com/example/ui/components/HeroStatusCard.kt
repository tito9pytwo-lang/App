package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlockCrimson
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WifiBlue

@Composable
fun HeroStatusCard(
    isFirewallActive: Boolean,
    blockedCount: Int,
    allowedCount: Int,
    blockedPackets: Long,
    activeNetwork: String,
    onToggleFirewall: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isFirewallActive) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val shieldGlowColor by animateColorAsState(
        targetValue = if (isFirewallActive) ElectricCyan else Color(0xFF475569),
        label = "shieldColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hero_status_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = CyberCardSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isFirewallActive) ElectricCyan.copy(alpha = 0.5f) else CyberCardBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        shieldGlowColor.copy(alpha = 0.35f),
                                        shieldGlowColor.copy(alpha = 0.08f),
                                        Color.Transparent
                                    )
                                )
                            )
                            .border(1.5.dp, shieldGlowColor.copy(alpha = 0.7f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isFirewallActive) Icons.Filled.Shield else Icons.Filled.Security,
                            contentDescription = "Shield Icon",
                            tint = shieldGlowColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = if (isFirewallActive) "جدار الحماية نشط" else "جدار الحماية متوقف",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isFirewallActive) "حظر انتقائي بالـ VPN المحلي" else "انقر لتفعيل حظر التطبيقات",
                            color = if (isFirewallActive) ShieldEmerald else TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Switch(
                    checked = isFirewallActive,
                    onCheckedChange = onToggleFirewall,
                    modifier = Modifier.testTag("firewall_master_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ElectricCyan,
                        checkedTrackColor = ElectricCyan.copy(alpha = 0.3f),
                        uncheckedThumbColor = Color(0xFF64748B),
                        uncheckedTrackColor = Color(0xFF1E293B)
                    )
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4 Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem(
                    label = "محظورة",
                    value = blockedCount.toString(),
                    icon = Icons.Filled.Block,
                    tint = BlockCrimson,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "مسموح بها",
                    value = allowedCount.toString(),
                    icon = Icons.Filled.CheckCircle,
                    tint = ShieldEmerald,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "حزم مسقطة",
                    value = formatCounter(blockedPackets),
                    icon = Icons.Filled.Security,
                    tint = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "الشبكة",
                    value = activeNetwork,
                    icon = if (activeNetwork.contains("Wi-Fi", ignoreCase = true)) Icons.Filled.Wifi else Icons.Filled.CellTower,
                    tint = WifiBlue,
                    modifier = Modifier.weight(1.1f)
                )
            }
        }
    }
}

@Composable
private fun MetricItem(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .padding(horizontal = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0B1320))
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 10.sp,
            maxLines = 1
        )
    }
}

private fun formatCounter(count: Long): String {
    return when {
        count >= 1_000_000 -> "${count / 1_000_000}M"
        count >= 1_000 -> "${count / 1_000}k"
        else -> count.toString()
    }
}
