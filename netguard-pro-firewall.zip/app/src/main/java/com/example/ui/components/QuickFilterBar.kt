package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FilterTab
import com.example.ui.theme.BlockCrimson
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun QuickFilterBar(
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    currentTab: FilterTab,
    onTabChanged: (FilterTab) -> Unit,
    totalCount: Int,
    blockedCount: Int,
    allowedCount: Int,
    showSystemApps: Boolean,
    onToggleShowSystemApps: () -> Unit,
    onBlockAll: () -> Unit,
    onAllowAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        // Search Input Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChanged,
            placeholder = {
                Text(
                    text = "ابحث عن تطبيق (مثل: WhatsApp, TikTok...)",
                    color = TextTertiary,
                    fontSize = 13.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = ElectricCyan
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChanged("") }) {
                        Icon(
                            imageVector = Icons.Filled.Clear,
                            contentDescription = "Clear",
                            tint = TextSecondary
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CyberCardSurface,
                unfocusedContainerColor = CyberCardSurface,
                focusedBorderColor = ElectricCyan,
                unfocusedBorderColor = CyberCardBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_apps_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Tabs: All, Blocked, Allowed
        val tabs = listOf(
            Triple(FilterTab.ALL, "الكل", totalCount),
            Triple(FilterTab.BLOCKED, "المحظورة", blockedCount),
            Triple(FilterTab.ALLOWED, "المسموح بها", allowedCount)
        )

        val selectedTabIndex = tabs.indexOfFirst { it.first == currentTab }.coerceAtLeast(0)

        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.Transparent,
            contentColor = ElectricCyan,
            indicator = { tabPositions ->
                if (selectedTabIndex < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = when (currentTab) {
                            FilterTab.BLOCKED -> BlockCrimson
                            FilterTab.ALLOWED -> ShieldEmerald
                            FilterTab.ALL -> ElectricCyan
                        }
                    )
                }
            },
            divider = {}
        ) {
            tabs.forEach { (tab, label, count) ->
                val selected = currentTab == tab
                Tab(
                    selected = selected,
                    onClick = { onTabChanged(tab) },
                    modifier = Modifier.testTag("tab_${tab.name}")
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (selected) TextPrimary else TextSecondary,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when {
                                        tab == FilterTab.BLOCKED -> BlockCrimson.copy(alpha = 0.25f)
                                        tab == FilterTab.ALLOWED -> ShieldEmerald.copy(alpha = 0.25f)
                                        else -> Color(0xFF1E293B)
                                    }
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = count.toString(),
                                color = when {
                                    tab == FilterTab.BLOCKED -> BlockCrimson
                                    tab == FilterTab.ALLOWED -> ShieldEmerald
                                    else -> TextSecondary
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chips row: System apps toggle, Block all, Allow all
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = showSystemApps,
                onClick = onToggleShowSystemApps,
                label = {
                    Text(
                        text = "تطبيقات النظام",
                        fontSize = 11.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
                    selectedLabelColor = ElectricCyan,
                    containerColor = Color(0xFF101B2B),
                    labelColor = TextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = showSystemApps,
                    borderColor = if (showSystemApps) ElectricCyan else CyberCardBorder
                ),
                modifier = Modifier.testTag("chip_system_apps")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(
                    onClick = onBlockAll,
                    label = { Text("حظر الكل", fontSize = 11.sp, color = BlockCrimson) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF1E1420)),
                    border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = BlockCrimson.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("btn_block_all")
                )

                AssistChip(
                    onClick = onAllowAll,
                    label = { Text("السماح للكل", fontSize = 11.sp, color = ShieldEmerald) },
                    colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFF11221E)),
                    border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = ShieldEmerald.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("btn_allow_all")
                )
            }
        }
    }
}
