package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FilterTab
import com.example.ui.FirewallUiState
import com.example.ui.components.AppItemCard
import com.example.ui.components.HeroStatusCard
import com.example.ui.components.QuickFilterBar
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun AppsScreen(
    state: FirewallUiState,
    onToggleFirewall: (Boolean) -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onTabChanged: (FilterTab) -> Unit,
    onToggleShowSystemApps: () -> Unit,
    onToggleAppBlock: (String) -> Unit,
    onToggleWifiBlock: (String, Boolean) -> Unit,
    onToggleMobileBlock: (String, Boolean) -> Unit,
    onBlockAll: () -> Unit,
    onAllowAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Hero Card
        HeroStatusCard(
            isFirewallActive = state.isFirewallActive,
            blockedCount = state.blockedCount,
            allowedCount = state.allowedCount,
            blockedPackets = state.totalBlockedPackets,
            activeNetwork = state.activeNetwork,
            onToggleFirewall = onToggleFirewall
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Filters and Search
        QuickFilterBar(
            searchQuery = state.searchQuery,
            onSearchQueryChanged = onSearchQueryChanged,
            currentTab = state.currentTab,
            onTabChanged = onTabChanged,
            totalCount = state.totalCount,
            blockedCount = state.blockedCount,
            allowedCount = state.allowedCount,
            showSystemApps = state.showSystemApps,
            onToggleShowSystemApps = onToggleShowSystemApps,
            onBlockAll = onBlockAll,
            onAllowAll = onAllowAll
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (state.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = ElectricCyan)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "جاري فحص التطبيقات المثبتة...",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else if (state.filteredApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (state.currentTab == FilterTab.BLOCKED) Icons.Filled.CheckCircle else Icons.Filled.Apps,
                        contentDescription = null,
                        tint = if (state.currentTab == FilterTab.BLOCKED) ShieldEmerald else TextTertiary,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = when (state.currentTab) {
                            FilterTab.BLOCKED -> "لا توجد تطبيقات محظورة حالياً"
                            FilterTab.ALLOWED -> "لا توجد تطبيقات مسموح بها ضمن الفلتر"
                            FilterTab.ALL -> "لا توجد تطبيقات مطابقة لبحثك"
                        },
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (state.currentTab == FilterTab.BLOCKED)
                            "اختر أي تطبيق وقم بتفعيل زر الحظر لمنعه من الاتصال بالإنترنت"
                        else
                            "جرّب البحث باسم آخر أو إظهار تطبيقات النظام",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("apps_list"),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(
                    items = state.filteredApps,
                    key = { it.packageName }
                ) { app ->
                    AppItemCard(
                        app = app,
                        onToggleBlock = { onToggleAppBlock(app.packageName) },
                        onToggleWifi = { blocked -> onToggleWifiBlock(app.packageName, blocked) },
                        onToggleMobile = { blocked -> onToggleMobileBlock(app.packageName, blocked) }
                    )
                }
            }
        }
    }
}
