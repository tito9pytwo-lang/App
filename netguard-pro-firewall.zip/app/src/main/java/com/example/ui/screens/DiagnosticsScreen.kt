package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppItem
import com.example.model.DiagnosticResult
import com.example.ui.theme.BlockCrimson
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.SafetyAmber
import com.example.ui.theme.ShieldEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(
    diagnostic: DiagnosticResult,
    apps: List<AppItem>,
    isFirewallActive: Boolean,
    autoStartOnBoot: Boolean,
    blockNewApps: Boolean,
    onRunDiagnostic: (String?) -> Unit,
    onToggleAutoStart: (Boolean) -> Unit,
    onToggleBlockNewApps: (Boolean) -> Unit,
    onToggleAppBlock: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedApp by remember { mutableStateOf<AppItem?>(null) }

    LaunchedEffect(Unit) {
        if (diagnostic.timestamp == 0L) {
            onRunDiagnostic(null)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .padding(bottom = 90.dp)
    ) {
        // Diagnostic Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "فحص الاتصال والتحقق من الحظر",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "اختبار عزل التطبيقات المحظورة مع استمرار الإنترنت في البقية",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = { onRunDiagnostic(selectedApp?.packageName) },
                enabled = !diagnostic.isChecking,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("btn_run_diagnostic")
            ) {
                if (diagnostic.isChecking) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.Black,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Run check",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (diagnostic.isChecking) "جاري الفحص..." else "فحص الآن",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Diagnostic Results Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardSurface),
            border = BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "حالة اتصال الشبكة العام",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Test 1: Global Internet
                DiagnosticRow(
                    icon = Icons.Filled.Wifi,
                    title = "اتصال الإنترنت العام (التطبيقات المسموحة)",
                    subtitle = if (diagnostic.isGlobalInternetAlive == true)
                        "يعمل بكفاءة وسرعة (استجابة: ${diagnostic.latencyMs ?: 0}ms)"
                    else if (diagnostic.isGlobalInternetAlive == false)
                        "لا يوجد اتصال خارجي بالإنترنت حالياً"
                    else "جاري الفحص...",
                    isSuccess = diagnostic.isGlobalInternetAlive == true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Test 2: DNS Resolution
                DiagnosticRow(
                    icon = Icons.Filled.Dns,
                    title = "خادم أسماء النطاقات (DNS)",
                    subtitle = if (diagnostic.dnsResolving == true)
                        "محلل DNS يعمل للتطبيقات المسموحة، ومفصول عن المحظورة"
                    else "جاري التحقق...",
                    isSuccess = diagnostic.dnsResolving == true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Test 3: Active Interface
                DiagnosticRow(
                    icon = Icons.Filled.Speed,
                    title = "الواجهة النشطة الحالية",
                    subtitle = "${diagnostic.activeInterface} • جاهز لتطبيق قواعد Wi-Fi والبيانات",
                    isSuccess = true
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Per-App Verifier
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardSurface),
            border = BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "اختبار حظر تطبيق مخصص (Per-App Test)",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "اختر أي تطبيق لفحص كيفية تعامل جدار الحماية معه بشكل مستقل:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Dropdown to pick app
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedApp?.appName ?: "اختر تطبيقاً من القائمة...",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF0B1320),
                            unfocusedContainerColor = Color(0xFF0B1320),
                            focusedBorderColor = ElectricCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("app_diagnostic_dropdown")
                    )

                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(CyberCardSurface)
                    ) {
                        apps.take(30).forEach { app ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = app.appName, color = TextPrimary, fontSize = 13.sp)
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (app.isBlocked) BlockCrimson.copy(alpha = 0.2f) else ShieldEmerald.copy(alpha = 0.2f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (app.isBlocked) "محظور" else "مسموح",
                                                color = if (app.isBlocked) BlockCrimson else ShieldEmerald,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    selectedApp = app
                                    expanded = false
                                    onRunDiagnostic(app.packageName)
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Detail verification of selected app
                if (selectedApp != null) {
                    val app = apps.find { it.packageName == selectedApp!!.packageName } ?: selectedApp!!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (app.isBlocked) Color(0xFF221118) else Color(0xFF10241A))
                            .border(
                                1.dp,
                                if (app.isBlocked) BlockCrimson.copy(alpha = 0.5f) else ShieldEmerald.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.appName,
                                        color = TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "UID: ${app.uid} • ${app.packageName}",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }

                                Button(
                                    onClick = { onToggleAppBlock(app.packageName) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (app.isBlocked) ShieldEmerald else BlockCrimson
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = if (app.isBlocked) "إلغاء الحظر" else "حظر التطبيق",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (app.isBlocked)
                                    "الحالة: محظور تماماً. يتم اعتراض وتوجيه حزم التطبيق محلياً إلى نفق VPN وإسقاطها فوراً. التطبيق معزول تماماً عن الإنترنت ولا يستطيع الاتصال بخوادمه أو استخدام DNS."
                                else
                                    "الحالة: مسموح به بالكامل. اتصالات التطبيق تتجاوز نفق VPN تماماً وتمر مباشرة عبر الشبكة الفعلية بأقصى سرعة وبدون أي تأخير أو مقاطعة.",
                                color = if (app.isBlocked) Color(0xFFFFB4AB) else Color(0xFFB4F3D0),
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Device & Architecture Info (realme C53 & Android 15 ready)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardSurface),
            border = BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "معلومات النظام والأداء (No-Root)",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                InfoRow(label = "نوع التقنية", value = "Android VpnService محلية بدون Root")
                InfoRow(label = "توجيه البيانات", value = "حظر انتقائي بالـ UID (Per-App Routing)")
                InfoRow(label = "استهلاك البطارية", value = "شبه منعدم (إسقاط فوري للحزم المحظورة)")
                InfoRow(label = "التوافق", value = "Android 15+ & realme C53 متوافق بالكامل")
                InfoRow(label = "الأمان والخصوصية", value = "100% محلي - لا يتم إرسال بيانات لخادم خارجي")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Settings / Options
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CyberCardSurface),
            border = BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "إعدادات متقدمة",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                SettingToggleRow(
                    title = "إعادة تشغيل الحماية تلقائياً",
                    subtitle = "استئناف جدار الحماية فور تشغيل الهاتف (Boot Completed)",
                    checked = autoStartOnBoot,
                    onCheckedChange = onToggleAutoStart
                )

                Spacer(modifier = Modifier.height(12.dp))

                SettingToggleRow(
                    title = "حظر التطبيقات الجديدة افتراضياً",
                    subtitle = "تطبيق الحظر تلقائياً على أي تطبيق يتم تثبيته لاحقاً",
                    checked = blockNewApps,
                    onCheckedChange = onToggleBlockNewApps
                )
            }
        }
    }
}

@Composable
private fun DiagnosticRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isSuccess: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0B1320))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isSuccess) ShieldEmerald.copy(alpha = 0.2f) else SafetyAmber.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isSuccess) Icons.Filled.Check else Icons.Filled.Security,
                contentDescription = null,
                tint = if (isSuccess) ShieldEmerald else SafetyAmber,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Text(text = value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ElectricCyan,
                checkedTrackColor = ElectricCyan.copy(alpha = 0.35f),
                uncheckedThumbColor = Color(0xFF64748B),
                uncheckedTrackColor = Color(0xFF1E293B)
            )
        )
    }
}
