package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Obsidian & Electric Cyan Palette
val CyberBlack = Color(0xFF090E17)
val CyberDarkSurface = Color(0xFF0F1726)
val CyberCardSurface = Color(0xFF141F33)
val CyberCardBorder = Color(0xFF1E2F4D)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanContainer = Color(0xFF004D56)
val ElectricCyanOnContainer = Color(0xFF8CF4FF)

val SafetyAmber = Color(0xFFFF9100)
val SafetyAmberContainer = Color(0xFF5A3100)
val SafetyAmberOnContainer = Color(0xFFFFD9B3)

val ShieldEmerald = Color(0xFF00E676)
val ShieldEmeraldContainer = Color(0xFF004D25)
val ShieldEmeraldOnContainer = Color(0xFF86FFB5)

val BlockCrimson = Color(0xFFFF3D57)
val BlockCrimsonContainer = Color(0xFF590013)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val WifiBlue = Color(0xFF38BDF8)
val MobileDataPurple = Color(0xFFA855F7)
