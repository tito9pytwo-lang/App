package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val CyberDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF00363D),
    primaryContainer = ElectricCyanContainer,
    onPrimaryContainer = ElectricCyanOnContainer,
    secondary = SafetyAmber,
    onSecondary = Color(0xFF422200),
    secondaryContainer = SafetyAmberContainer,
    onSecondaryContainer = SafetyAmberOnContainer,
    tertiary = ShieldEmerald,
    onTertiary = Color(0xFF003918),
    tertiaryContainer = ShieldEmeraldContainer,
    onTertiaryContainer = ShieldEmeraldOnContainer,
    error = BlockCrimson,
    onError = Color.White,
    errorContainer = BlockCrimsonContainer,
    onErrorContainer = Color(0xFFFFDAD9),
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = CyberDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = CyberCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep high-contrast cybersecurity branding
    content: @Composable () -> Unit
) {
    val colorScheme = CyberDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
