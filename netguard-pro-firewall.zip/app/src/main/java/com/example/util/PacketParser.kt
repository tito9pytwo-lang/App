package com.example.util

import java.net.InetAddress
import java.nio.ByteBuffer

object PacketParser {

    data class ParsedPacket(
        val ipVersion: Int,
        val protocol: String,
        val sourceIp: String,
        val destIp: String,
        val sourcePort: Int,
        val destPort: Int,
        val size: Int
    )

    fun parse(buffer: ByteArray, length: Int): ParsedPacket? {
        if (length < 20) return null

        val version = (buffer[0].toInt() shr 4) and 0x0F
        return when (version) {
            4 -> parseIpv4(buffer, length)
            6 -> parseIpv6(buffer, length)
            else -> null
        }
    }

    private fun parseIpv4(buffer: ByteArray, length: Int): ParsedPacket? {
        val ihl = (buffer[0].toInt() and 0x0F) * 4
        if (length < ihl) return null

        val protocolNum = buffer[9].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(buffer.sliceArray(12..15)).hostAddress ?: "0.0.0.0"
        val dstIp = InetAddress.getByAddress(buffer.sliceArray(16..19)).hostAddress ?: "0.0.0.0"

        val protocolStr = when (protocolNum) {
            6 -> "TCP"
            17 -> "UDP"
            1 -> "ICMP"
            else -> "IP-$protocolNum"
        }

        var srcPort = 0
        var dstPort = 0

        if ((protocolNum == 6 || protocolNum == 17) && length >= ihl + 4) {
            srcPort = ((buffer[ihl].toInt() and 0xFF) shl 8) or (buffer[ihl + 1].toInt() and 0xFF)
            dstPort = ((buffer[ihl + 2].toInt() and 0xFF) shl 8) or (buffer[ihl + 3].toInt() and 0xFF)
        }

        val displayProtocol = if (dstPort == 53 || srcPort == 53) "DNS" else protocolStr

        return ParsedPacket(
            ipVersion = 4,
            protocol = displayProtocol,
            sourceIp = srcIp,
            destIp = dstIp,
            sourcePort = srcPort,
            destPort = dstPort,
            size = length
        )
    }

    private fun parseIpv6(buffer: ByteArray, length: Int): ParsedPacket? {
        if (length < 40) return null

        val nextHeader = buffer[6].toInt() and 0xFF
        val srcIp = InetAddress.getByAddress(buffer.sliceArray(8..23)).hostAddress ?: "::"
        val dstIp = InetAddress.getByAddress(buffer.sliceArray(24..39)).hostAddress ?: "::"

        val protocolStr = when (nextHeader) {
            6 -> "TCP"
            17 -> "UDP"
            58 -> "ICMPv6"
            else -> "IPv6-$nextHeader"
        }

        var srcPort = 0
        var dstPort = 0

        if ((nextHeader == 6 || nextHeader == 17) && length >= 44) {
            srcPort = ((buffer[40].toInt() and 0xFF) shl 8) or (buffer[41].toInt() and 0xFF)
            dstPort = ((buffer[42].toInt() and 0xFF) shl 8) or (buffer[43].toInt() and 0xFF)
        }

        val displayProtocol = if (dstPort == 53 || srcPort == 53) "DNS" else protocolStr

        return ParsedPacket(
            ipVersion = 6,
            protocol = displayProtocol,
            sourceIp = srcIp,
            destIp = dstIp,
            sourcePort = srcPort,
            destPort = dstPort,
            size = length
        )
    }
}
