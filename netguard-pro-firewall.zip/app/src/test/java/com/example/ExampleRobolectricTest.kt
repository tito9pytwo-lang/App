package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.FirewallPreferences
import com.example.model.AppRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NetShield", appName)
    }

    @Test
    fun `firewall preferences persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = FirewallPreferences.getInstance(context)

        prefs.setFirewallEnabled(true)
        assertTrue(prefs.isFirewallEnabled())

        val testRule = AppRule(
            packageName = "com.tiktok.app",
            appName = "TikTok",
            uid = 10123,
            isSystemApp = false,
            blockWifi = true,
            blockMobile = true
        )
        prefs.updateRule(testRule)

        val retrieved = prefs.getRules()["com.tiktok.app"]
        assertEquals(true, retrieved?.blockWifi)
        assertEquals(true, retrieved?.blockMobile)
        assertEquals(10123, retrieved?.uid)
    }
}
