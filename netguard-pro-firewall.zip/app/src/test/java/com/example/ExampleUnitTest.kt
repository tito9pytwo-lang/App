package com.example

import com.example.model.AppRule
import com.example.util.PacketParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun appRule_blockedLogic() {
        val ruleBoth = AppRule("com.test.app", "Test", 1001, blockWifi = true, blockMobile = true)
        assertTrue(ruleBoth.isFullyBlocked)
        assertTrue(ruleBoth.isPartiallyBlocked)

        val ruleWifiOnly = AppRule("com.test.app2", "Test2", 1002, blockWifi = true, blockMobile = false)
        assertEquals(false, ruleWifiOnly.isFullyBlocked)
        assertTrue(ruleWifiOnly.isPartiallyBlocked)
    }

    @Test
    fun packetParser_parsesSyntheticIpv4TcpPacket() {
        // Construct a synthetic 40-byte IPv4 + TCP packet
        val packet = ByteArray(40)
        // Version 4, IHL 5 (20 bytes header)
        packet[0] = 0x45.toByte()
        // Total length = 40
        packet[2] = 0x00.toByte()
        packet[3] = 40.toByte()
        // Protocol = 6 (TCP)
        packet[9] = 6.toByte()
        // Source IP: 10.120.0.1
        packet[12] = 10.toByte()
        packet[13] = 120.toByte()
        packet[14] = 0.toByte()
        packet[15] = 1.toByte()
        // Dest IP: 142.250.180.206
        packet[16] = 142.toByte()
        packet[17] = 250.toByte()
        packet[18] = 180.toByte()
        packet[19] = 206.toByte()
        // Source Port: 54321 (0xD431)
        packet[20] = 0xD4.toByte()
        packet[21] = 0x31.toByte()
        // Dest Port: 443 (HTTPS) (0x01BB)
        packet[22] = 0x01.toByte()
        packet[23] = 0xBB.toByte()

        val parsed = PacketParser.parse(packet, 40)
        assertNotNull(parsed)
        assertEquals(4, parsed?.ipVersion)
        assertEquals("TCP", parsed?.protocol)
        assertEquals("10.120.0.1", parsed?.sourceIp)
        assertEquals("142.250.180.206", parsed?.destIp)
        assertEquals(54321, parsed?.sourcePort)
        assertEquals(443, parsed?.destPort)
    }

    @Test
    fun packetParser_parsesSyntheticDnsPacket() {
        val packet = ByteArray(28)
        packet[0] = 0x45.toByte()
        packet[9] = 17.toByte() // UDP
        packet[12] = 10.toByte()
        packet[13] = 120.toByte()
        packet[14] = 0.toByte()
        packet[15] = 1.toByte()
        packet[16] = 8.toByte()
        packet[17] = 8.toByte()
        packet[18] = 8.toByte()
        packet[19] = 8.toByte()
        packet[20] = 0xC0.toByte()
        packet[21] = 0x01.toByte()
        // Dest Port = 53 (DNS)
        packet[22] = 0x00.toByte()
        packet[23] = 53.toByte()

        val parsed = PacketParser.parse(packet, 28)
        assertNotNull(parsed)
        assertEquals("DNS", parsed?.protocol)
        assertEquals(53, parsed?.destPort)
    }
}
