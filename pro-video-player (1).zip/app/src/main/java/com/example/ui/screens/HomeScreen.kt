package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppSettings
import com.example.model.SortOption
import com.example.model.SortOrder
import com.example.model.ThumbnailSize
import com.example.model.VideoItem
import com.example.model.ViewMode
import com.example.scanner.ThumbnailCacheManager
import com.example.ui.components.ContinueWatchingCard
import com.example.ui.components.VideoGridCard
import com.example.ui.components.VideoListRowCard
import com.example.ui.localization.LocalAppStrings

@Composable
fun HomeScreen(
    videos: List<VideoItem>,
    continueWatchingVideos: List<VideoItem>,
    recentlyAddedVideos: List<VideoItem>,
    historyVideos: List<VideoItem>,
    favoriteVideos: List<VideoItem>,
    settings: AppSettings,
    searchQuery: String,
    isScanning: Boolean,
    hasMediaPermission: Boolean,
    thumbnailCache: ThumbnailCacheManager,
    onSearchQueryChange: (String) -> Unit,
    onPlayVideo: (VideoItem, List<VideoItem>) -> Unit,
    onLongPressVideo: (VideoItem) -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onToggleViewMode: () -> Unit,
    onUpdateSort: (SortOption, SortOrder) -> Unit,
    onRequestMediaPermission: () -> Unit,
    onAddFolderClick: () -> Unit,
    onPickVideosClick: () -> Unit,
    onRescanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var showSortMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text(strings.searchPlaceholder) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("home_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Toolbar row: Sort, ViewMode, Add Folder, Open Video, Rescan
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box {
                    FilterChip(
                        selected = true,
                        onClick = { showSortMenu = true },
                        label = {
                            val sortLabel = when (settings.sortOption) {
                                SortOption.NAME -> strings.sortName
                                SortOption.DATE -> strings.sortDate
                                SortOption.SIZE -> strings.sortSize
                                SortOption.DURATION -> strings.sortDuration
                            }
                            Text("${strings.sortBy}: $sortLabel")
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Sort,
                                contentDescription = strings.sortBy,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        trailingIcon = {
                            Icon(
                                imageVector = if (settings.sortOrder == SortOrder.ASCENDING) {
                                    Icons.Default.ArrowUpward
                                } else {
                                    Icons.Default.ArrowDownward
                                },
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                        },
                        modifier = Modifier.testTag("sort_chip_button")
                    )

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(strings.sortName) },
                            onClick = {
                                onUpdateSort(SortOption.NAME, settings.sortOrder)
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.sortDate) },
                            onClick = {
                                onUpdateSort(SortOption.DATE, settings.sortOrder)
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.sortSize) },
                            onClick = {
                                onUpdateSort(SortOption.SIZE, settings.sortOrder)
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(strings.sortDuration) },
                            onClick = {
                                onUpdateSort(SortOption.DURATION, settings.sortOrder)
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (settings.sortOrder == SortOrder.ASCENDING) {
                                        strings.descending
                                    } else {
                                        strings.ascending
                                    }
                                )
                            },
                            onClick = {
                                val nextOrder = if (settings.sortOrder == SortOrder.ASCENDING) {
                                    SortOrder.DESCENDING
                                } else {
                                    SortOrder.ASCENDING
                                }
                                onUpdateSort(settings.sortOption, nextOrder)
                                showSortMenu = false
                            }
                        )
                    }
                }

                Text(
                    text = strings.videosCountLabel(videos.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onAddFolderClick,
                    modifier = Modifier.testTag("add_saf_folder_icon_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CreateNewFolder,
                        contentDescription = strings.addFolderSaf,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = onPickVideosClick,
                    modifier = Modifier.testTag("pick_videos_icon_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VideoFile,
                        contentDescription = strings.openVideoFiles,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = onToggleViewMode,
                    modifier = Modifier.testTag("toggle_view_mode_button")
                ) {
                    Icon(
                        imageVector = if (settings.viewMode == ViewMode.GRID) {
                            Icons.AutoMirrored.Filled.ViewList
                        } else {
                            Icons.Default.GridView
                        },
                        contentDescription = if (settings.viewMode == ViewMode.GRID) strings.listView else strings.gridView,
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(
                    onClick = onRescanClick,
                    modifier = Modifier.testTag("rescan_library_button")
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = strings.rescanLibrary,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (!hasMediaPermission) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (strings.isArabic) "إذن الوصول لجميع الفيديوهات" else "All Videos Access Permission",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (strings.isArabic) {
                                "امنح التطبيق صلاحية قراءة الفيديوهات لعرض جميع مقاطع الفيديو تلقائيًا بدون اختيار مجلد."
                            } else {
                                "Grant video permission to automatically list all videos on your device."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = onRequestMediaPermission,
                        modifier = Modifier.testTag("grant_media_permission_banner_button")
                    ) {
                        Text(if (strings.isArabic) "منح الإذن" else "Grant")
                    }
                }
            }
        }

        if (videos.isEmpty() && !isScanning) {
            EmptyVideosLibraryCard(
                hasMediaPermission = hasMediaPermission,
                onRequestMediaPermission = onRequestMediaPermission,
                onAddFolderClick = onAddFolderClick,
                onPickVideosClick = onPickVideosClick,
                onRescanClick = onRescanClick
            )
        } else {
            val minGridCellWidth = when (settings.thumbnailSize) {
                ThumbnailSize.SMALL -> 150.dp
                ThumbnailSize.MEDIUM -> 175.dp
                ThumbnailSize.LARGE -> 230.dp
            }

            if (settings.viewMode == ViewMode.GRID) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = minGridCellWidth),
                    contentPadding = PaddingValues(bottom = 96.dp, top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("videos_grid_container")
                ) {
                    if (searchQuery.isBlank() && continueWatchingVideos.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            ContinueWatchingSection(
                                videos = continueWatchingVideos,
                                thumbnailCache = thumbnailCache,
                                onPlayVideo = { video -> onPlayVideo(video, continueWatchingVideos) }
                            )
                        }
                    }

                    if (searchQuery.isBlank() && historyVideos.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            SectionHeader(title = strings.recentlyPlayed)
                        }
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                items(historyVideos.take(8), key = { "hist_${it.uriString}" }) { item ->
                                    ContinueWatchingCard(
                                        video = item,
                                        thumbnailCache = thumbnailCache,
                                        onClick = { onPlayVideo(item, historyVideos) }
                                    )
                                }
                            }
                        }
                    }

                    item(span = { GridItemSpan(maxLineSpan) }) {
                        SectionHeader(title = strings.allVideos)
                    }

                    items(videos, key = { it.uriString }) { video ->
                        VideoGridCard(
                            video = video,
                            thumbnailCache = thumbnailCache,
                            onClick = { onPlayVideo(video, videos) },
                            onLongClick = { onLongPressVideo(video) },
                            onFavoriteToggle = { onToggleFavorite(video) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 96.dp, top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("videos_list_container")
                ) {
                    if (searchQuery.isBlank() && continueWatchingVideos.isNotEmpty()) {
                        item {
                            ContinueWatchingSection(
                                videos = continueWatchingVideos,
                                thumbnailCache = thumbnailCache,
                                onPlayVideo = { video -> onPlayVideo(video, continueWatchingVideos) }
                            )
                        }
                    }

                    item {
                        SectionHeader(title = strings.allVideos)
                    }

                    items(videos, key = { it.uriString }) { video ->
                        VideoListRowCard(
                            video = video,
                            thumbnailSize = settings.thumbnailSize,
                            thumbnailCache = thumbnailCache,
                            onClick = { onPlayVideo(video, videos) },
                            onLongClick = { onLongPressVideo(video) },
                            onFavoriteToggle = { onToggleFavorite(video) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingSection(
    videos: List<VideoItem>,
    thumbnailCache: ThumbnailCacheManager,
    onPlayVideo: (VideoItem) -> Unit
) {
    val strings = LocalAppStrings.current
    Column(modifier = Modifier.fillMaxWidth()) {
        SectionHeader(title = strings.continueWatching)
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            items(videos, key = { "cw_${it.uriString}" }) { video ->
                ContinueWatchingCard(
                    video = video,
                    thumbnailCache = thumbnailCache,
                    onClick = { onPlayVideo(video) }
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
private fun EmptyVideosLibraryCard(
    hasMediaPermission: Boolean,
    onRequestMediaPermission: () -> Unit,
    onAddFolderClick: () -> Unit,
    onPickVideosClick: () -> Unit,
    onRescanClick: () -> Unit
) {
    val strings = LocalAppStrings.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_cinema_banner),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .clip(RoundedCornerShape(16.dp))
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = strings.noVideosTitle,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (!hasMediaPermission) {
                        if (strings.isArabic) {
                            "اسمح للتطبيق بالوصول إلى ملفات الفيديو لعرض جميع الفيديوهات والمجلدات الموجودة على جهازك تلقائيًا."
                        } else {
                            "Allow video access permission so the app can automatically discover and list all videos on your device."
                        }
                    } else {
                        strings.noVideosSubtitle
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                if (!hasMediaPermission) {
                    Button(
                        onClick = onRequestMediaPermission,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("empty_grant_permission_button")
                    ) {
                        Text(
                            text = if (strings.isArabic) "منح إذن الوصول لجميع الفيديوهات" else "Allow Access to All Videos",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onPickVideosClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("empty_pick_videos_button")
                    ) {
                        Icon(Icons.Default.VideoFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.openVideoFiles)
                    }

                    FilledTonalButton(
                        onClick = onAddFolderClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("empty_add_folder_button")
                    ) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.addFolderSaf)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onRescanClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.rescanLibrary)
                }
            }
        }
    }
}
