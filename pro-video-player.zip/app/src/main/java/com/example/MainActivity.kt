package com.example

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.ProVideoPlayerApp
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleViewIntentIfPresent(intent)

        setContent {
            ProVideoPlayerApp(
                viewModel = viewModel,
                onRequestPipMode = { enterPipModeSafely() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntentIfPresent(intent)
    }

    private fun handleViewIntentIfPresent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            val dataUri = intent.data ?: return
            viewModel.handleIncomingViewIntent(dataUri)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val playerState = viewModel.playerController.uiState.value
        val settings = viewModel.settings.value
        if (playerState.isPlayerOpen && playerState.isPlaying && settings.autoPipEnabled) {
            val entered = enterPipModeSafely()
            if (entered) return
        }
        viewModel.playerController.onAppBackgrounded(isEnteringPip = false)
    }

    override fun onStop() {
        super.onStop()
        val isInPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isInPictureInPictureMode
        } else {
            false
        }
        if (!isInPip && !isChangingConfigurations) {
            viewModel.playerController.onAppBackgrounded(isEnteringPip = false)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.playerController.onAppForegrounded()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        viewModel.playerController.onPipModeChanged(isInPictureInPictureMode)
    }

    private fun enterPipModeSafely(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false

        return try {
            val playerState = viewModel.playerController.uiState.value
            val w = playerState.videoWidth.takeIf { it > 0 } ?: 16
            val h = playerState.videoHeight.takeIf { it > 0 } ?: 9
            val ratio = Rational(w, h).let { r ->
                val f = r.toFloat()
                if (f in 0.42f..2.38f) r else Rational(16, 9)
            }
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(ratio)
                .build()
            enterPictureInPictureMode(params)
        } catch (_: Exception) {
            false
        }
    }
}
