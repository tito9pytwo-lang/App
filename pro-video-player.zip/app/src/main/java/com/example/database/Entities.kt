package com.example.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "video_user_metadata")
data class VideoUserMetadataEntity(
    @PrimaryKey val uriString: String,
    val customTitle: String? = null,
    val isFavorite: Boolean = false,
    val lastPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val watchPercentage: Float = 0f,
    val lastPlayedAt: Long = 0L,
    val playCount: Int = 0,
    val totalWatchTimeMs: Long = 0L,
    val preferredAspectRatio: String? = null,
    val externalSubtitleUri: String? = null,
    val externalSubtitleName: String? = null
)

@Entity(tableName = "saf_sources")
data class SafSourceEntity(
    @PrimaryKey val uriString: String,
    val displayName: String,
    val isTree: Boolean,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0L,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_items",
    primaryKeys = ["playlistId", "videoUri"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["playlistId"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["playlistId"]), Index(value = ["videoUri"])]
)
data class PlaylistItemEntity(
    val playlistId: Long,
    val videoUri: String,
    val sortOrder: Int,
    val addedAt: Long = System.currentTimeMillis()
)
