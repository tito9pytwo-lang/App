package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM video_user_metadata")
    fun observeAllMetadata(): Flow<List<VideoUserMetadataEntity>>

    @Query("SELECT * FROM video_user_metadata WHERE uriString = :uriString LIMIT 1")
    suspend fun getMetadataForUri(uriString: String): VideoUserMetadataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMetadata(entity: VideoUserMetadataEntity)

    @Query("DELETE FROM video_user_metadata WHERE uriString = :uriString")
    suspend fun deleteMetadataByUri(uriString: String)

    @Query(
        """
        UPDATE video_user_metadata 
        SET lastPositionMs = 0, watchPercentage = 0, lastPlayedAt = 0 
        WHERE uriString = :uriString
        """
    )
    suspend fun clearHistoryForUri(uriString: String)

    @Query(
        """
        UPDATE video_user_metadata 
        SET lastPositionMs = 0, watchPercentage = 0, lastPlayedAt = 0
        """
    )
    suspend fun clearAllHistory()

    // SAF Sources
    @Query("SELECT * FROM saf_sources ORDER BY addedAt DESC")
    fun observeSafSources(): Flow<List<SafSourceEntity>>

    @Query("SELECT * FROM saf_sources ORDER BY addedAt DESC")
    suspend fun getAllSafSources(): List<SafSourceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSafSource(source: SafSourceEntity)

    @Query("DELETE FROM saf_sources WHERE uriString = :uriString")
    suspend fun deleteSafSource(uriString: String)

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY updatedAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_items ORDER BY playlistId ASC, sortOrder ASC")
    fun observeAllPlaylistItems(): Flow<List<PlaylistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName, updatedAt = :updatedAt WHERE playlistId = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM playlists WHERE playlistId = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("SELECT COALESCE(MAX(sortOrder), -1) + 1 FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun getNextSortOrder(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(item: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId AND videoUri = :videoUri")
    suspend fun removeVideoFromPlaylist(playlistId: Long, videoUri: String)

    @Query("DELETE FROM playlist_items WHERE videoUri = :videoUri")
    suspend fun removeVideoFromAllPlaylists(videoUri: String)

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY sortOrder ASC")
    suspend fun getPlaylistItemsSync(playlistId: Long): List<PlaylistItemEntity>

    @Transaction
    suspend fun updatePlaylistOrder(playlistId: Long, orderedVideoUris: List<String>) {
        orderedVideoUris.forEachIndexed { index, uri ->
            insertPlaylistItem(
                PlaylistItemEntity(
                    playlistId = playlistId,
                    videoUri = uri,
                    sortOrder = index
                )
            )
        }
    }
}
