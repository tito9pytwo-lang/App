package com.example.model

import androidx.compose.ui.graphics.Color

enum class SortOption {
    NAME,
    DATE,
    SIZE,
    DURATION
}

enum class SortOrder {
    ASCENDING,
    DESCENDING
}

enum class ViewMode {
    GRID,
    LIST
}

enum class ThumbnailSize {
    SMALL,
    MEDIUM,
    LARGE
}

enum class AspectRatioMode(val labelEn: String, val labelAr: String) {
    FIT("Fit", "ملائم (Fit)"),
    FILL("Fill", "ملء (Fill)"),
    CROP("Crop", "قص (Crop)"),
    STRETCH("Stretch", "تمدد (Stretch)"),
    ORIGINAL("Original", "الأصلي (Original)"),
    RATIO_16_9("16:9", "16:9"),
    RATIO_4_3("4:3", "4:3")
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class AppLanguage {
    SYSTEM,
    ARABIC,
    ENGLISH
}

enum class SleepTimerOption(val minutes: Int, val stopAtEndOfVideo: Boolean = false) {
    OFF(0, false),
    MIN_5(5, false),
    MIN_10(10, false),
    MIN_15(15, false),
    MIN_30(30, false),
    MIN_60(60, false),
    END_OF_VIDEO(0, true)
}

data class VideoItem(
    val id: String,
    val uriString: String,
    val title: String,
    val displayName: String,
    val folderName: String,
    val folderPath: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val mimeType: String,
    val detectedFormat: String,
    val width: Int = 0,
    val height: Int = 0,
    val fps: Float = 0f,
    val videoCodec: String = "",
    val audioCodec: String = "",
    val bitrate: Long = 0L,
    val isFavorite: Boolean = false,
    val lastPositionMs: Long = 0L,
    val watchPercentage: Float = 0f,
    val lastPlayedAt: Long = 0L,
    val playCount: Int = 0,
    val totalWatchTimeMs: Long = 0L,
    val preferredAspectRatio: AspectRatioMode? = null,
    val externalSubtitleUri: String? = null,
    val externalSubtitleName: String? = null,
    val isSafDocument: Boolean = false
) {
    val resolutionLabel: String
        get() = when {
            height >= 2160 || width >= 3840 -> "4K UHD"
            height >= 1440 || width >= 2560 -> "2K QHD"
            height >= 1080 || width >= 1920 -> "1080p FHD"
            height >= 720 || width >= 1280 -> "720p HD"
            height >= 480 || width >= 854 -> "480p SD"
            height > 0 && width > 0 -> "${width}x${height}"
            else -> detectedFormat.ifEmpty { "VIDEO" }
        }

    val frameSizeLabel: String
        get() = if (width > 0 && height > 0) "${width} × ${height}" else "Auto"

    val hasResumePosition: Boolean
        get() = lastPositionMs > 3_000L &&
            (durationMs <= 0L || (lastPositionMs.toFloat() / durationMs.toFloat()) in 0.01f..0.96f)
}

data class VideoFolder(
    val path: String,
    val name: String,
    val videos: List<VideoItem>,
    val totalSizeBytes: Long,
    val latestModifiedSec: Long
) {
    val videoCount: Int get() = videos.size
    val previewVideo: VideoItem? get() = videos.firstOrNull()
}

data class PlaylistWithVideos(
    val playlistId: Long,
    val name: String,
    val createdAt: Long,
    val videos: List<VideoItem>
)

data class SubtitleStyleConfig(
    val enabled: Boolean = true,
    val fontSizeSp: Float = 20f,
    val textColorArgb: Int = 0xFFFFFFFF.toInt(),
    val backgroundColorArgb: Int = 0xFF000000.toInt(),
    val backgroundOpacity: Float = 0.65f,
    val verticalPositionPercent: Float = 0.88f, // 0.15 (top) to 0.92 (bottom)
    val delayMs: Long = 0L,
    val fontFamilyName: String = "Default", // Default, SansSerif, Serif, Monospace
    val preferRtlArabic: Boolean = true
)

data class AppSettings(
    // Playback settings
    val autoPlayNext: Boolean = true,
    val resumePlayback: Boolean = true,
    val smartResumePrompt: Boolean = true,
    val defaultLoop: Boolean = false,
    val defaultShuffle: Boolean = false,
    val defaultPlaybackSpeed: Float = 1.0f,
    val defaultAspectRatio: AspectRatioMode = AspectRatioMode.FIT,

    // Gesture settings
    val forwardSeekSeconds: Int = 10,
    val backwardSeekSeconds: Int = 10,
    val enableBrightnessGesture: Boolean = true,
    val enableVolumeGesture: Boolean = true,
    val enableHorizontalSeekGesture: Boolean = true,
    val controlsHideDelaySeconds: Int = 4,

    // Subtitle settings
    val subtitleConfig: SubtitleStyleConfig = SubtitleStyleConfig(),

    // UI settings
    val themeMode: ThemeMode = ThemeMode.DARK,
    val viewMode: ViewMode = ViewMode.GRID,
    val thumbnailSize: ThumbnailSize = ThumbnailSize.MEDIUM,
    val sortOption: SortOption = SortOption.DATE,
    val sortOrder: SortOrder = SortOrder.DESCENDING,
    val appLanguage: AppLanguage = AppLanguage.ARABIC,
    val saveHistoryEnabled: Boolean = true,

    // Background & PiP settings
    val backgroundAudioEnabled: Boolean = false,
    val autoPipEnabled: Boolean = true
)

data class TrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val id: String,
    val label: String,
    val language: String,
    val isSelected: Boolean,
    val bitrate: Int = 0,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = ""
)

data class SubtitleCueItem(
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String
)

data class PlaybackStatisticsSummary(
    val totalVideosWatched: Int,
    val totalPlayCount: Int,
    val totalWatchTimeMs: Long,
    val mostWatchedVideo: VideoItem?,
    val lastWatchedVideo: VideoItem?
)
