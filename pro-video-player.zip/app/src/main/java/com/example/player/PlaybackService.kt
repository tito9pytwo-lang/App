package com.example.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.MainActivity

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = SharedPlayerHolder.getOrCreatePlayer(applicationContext)
        val sessionActivityIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityIntent)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 || !SharedPlayerHolder.backgroundPlaybackAllowed) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}

object SharedPlayerHolder {
    @Volatile
    private var exoPlayerInstance: androidx.media3.exoplayer.ExoPlayer? = null

    @Volatile
    var backgroundPlaybackAllowed: Boolean = false

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    fun getOrCreatePlayer(context: android.content.Context): androidx.media3.exoplayer.ExoPlayer {
        return exoPlayerInstance ?: synchronized(this) {
            exoPlayerInstance ?: run {
                val trackSelector = androidx.media3.exoplayer.trackselection.DefaultTrackSelector(context.applicationContext).apply {
                    setParameters(
                        buildUponParameters()
                            .setPreferredTextLanguage("ar")
                    )
                }
                val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory()
                    .setConstantBitrateSeekingEnabled(true)

                val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(
                    context.applicationContext,
                    extractorsFactory
                )

                val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                    .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build()

                androidx.media3.exoplayer.ExoPlayer.Builder(context.applicationContext)
                    .setTrackSelector(trackSelector)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .setAudioAttributes(audioAttributes, true)
                    .setHandleAudioBecomingNoisy(true)
                    .build()
                    .also { exoPlayerInstance = it }
            }
        }
    }

    fun releasePlayer() {
        synchronized(this) {
            exoPlayerInstance?.release()
            exoPlayerInstance = null
        }
    }
}
