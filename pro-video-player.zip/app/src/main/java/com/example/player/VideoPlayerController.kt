package com.example.player

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.SleepTimerOption
import com.example.model.SubtitleCueItem
import com.example.model.TrackOption
import com.example.model.VideoItem
import com.example.repository.VideoRepository
import com.example.subtitle.SubtitleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class PlayerUiState(
    val isPlayerOpen: Boolean = false,
    val currentVideo: VideoItem? = null,
    val queue: List<VideoItem> = emptyList(),
    val currentQueueIndex: Int = 0,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val playbackSpeed: Float = 1.0f,
    val isMuted: Boolean = false,
    val volumeLevel: Float = 0.7f,
    val brightnessLevel: Float = 0.65f,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val isShuffleEnabled: Boolean = false,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val isFullscreen: Boolean = false,
    val isScreenLocked: Boolean = false,
    val isOrientationLocked: Boolean = false,
    val isLandscapePreferred: Boolean = true,
    val audioTracks: List<TrackOption> = emptyList(),
    val subtitleTracks: List<TrackOption> = emptyList(),
    val videoQualityTracks: List<TrackOption> = emptyList(),
    val selectedQualityLabel: String = "Auto",
    val activeInternalSubtitleText: String? = null,
    val activeExternalSubtitleText: String? = null,
    val externalSubtitleName: String? = null,
    val externalSubtitleCues: List<SubtitleCueItem> = emptyList(),
    val showSmartResumeBanner: Boolean = false,
    val smartResumeTargetMs: Long = 0L,
    val sleepTimerOption: SleepTimerOption = SleepTimerOption.OFF,
    val sleepTimerRemainingSec: Long = 0L,
    val isInPipMode: Boolean = false,
    val isPlayingInBackground: Boolean = false,
    val playbackError: String? = null,
    val playbackErrorCodeName: String? = null
)

@OptIn(UnstableApi::class)
class VideoPlayerController(
    private val context: Context,
    private val repository: VideoRepository,
    private val subtitleManager: SubtitleManager = SubtitleManager(context)
) {
    private val controllerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    val exoPlayer: ExoPlayer = SharedPlayerHolder.getOrCreatePlayer(context)

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var currentSettings: AppSettings = AppSettings()
    private var progressPollingJob: Job? = null
    private var sleepTimerJob: Job? = null
    private var lastProgressSaveTimeMs: Long = 0L

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                startProgressLoop()
            } else {
                saveCurrentProgressNow(addedWatchMs = 0L)
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val isBuffering = playbackState == Player.STATE_BUFFERING
            val duration = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
            _uiState.update {
                it.copy(
                    isBuffering = isBuffering,
                    durationMs = duration
                )
            }

            if (playbackState == Player.STATE_ENDED) {
                saveCurrentProgressNow(addedWatchMs = 0L)
                if (_uiState.value.sleepTimerOption == SleepTimerOption.END_OF_VIDEO) {
                    exoPlayer.pause()
                    _uiState.update { it.copy(sleepTimerOption = SleepTimerOption.OFF, sleepTimerRemainingSec = 0L) }
                    return
                }
                if (currentSettings.autoPlayNext && _uiState.value.repeatMode != Player.REPEAT_MODE_ONE) {
                    playNextInQueue()
                }
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                _uiState.update {
                    it.copy(
                        videoWidth = videoSize.width,
                        videoHeight = videoSize.height
                    )
                }
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            parseAvailableTracks(tracks)
        }

        override fun onCues(cueGroup: CueGroup) {
            val text = cueGroup.cues.mapNotNull { it.text?.toString() }
                .filter { it.isNotBlank() }
                .joinToString("\n")
                .takeIf { it.isNotBlank() }
            _uiState.update { it.copy(activeInternalSubtitleText = text) }
        }

        override fun onPlayerError(error: PlaybackException) {
            val errorDetail = error.errorCodeName
            _uiState.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    playbackError = error.localizedMessage ?: "Unsupported or corrupted video stream",
                    playbackErrorCodeName = errorDetail
                )
            }
        }
    }

    init {
        exoPlayer.addListener(playerListener)
        syncSystemVolume()
    }

    fun applySettings(settings: AppSettings) {
        val previous = currentSettings
        currentSettings = settings
        SharedPlayerHolder.backgroundPlaybackAllowed = settings.backgroundAudioEnabled

        if (!_uiState.value.isPlayerOpen) {
            _uiState.update {
                it.copy(
                    playbackSpeed = settings.defaultPlaybackSpeed,
                    aspectRatioMode = settings.defaultAspectRatio,
                    isShuffleEnabled = settings.defaultShuffle,
                    repeatMode = if (settings.defaultLoop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                )
            }
        }
        if (previous.subtitleConfig.delayMs != settings.subtitleConfig.delayMs) {
            refreshSubtitleCueAtPosition(exoPlayer.currentPosition)
        }
    }

    fun openAndPlayVideo(
        video: VideoItem,
        queue: List<VideoItem> = listOf(video),
        forceStartFromBeginning: Boolean = false
    ) {
        val validQueue = if (queue.isEmpty()) listOf(video) else queue
        val index = validQueue.indexOfFirst { it.uriString == video.uriString }.coerceAtLeast(0)

        val preferredRatio = video.preferredAspectRatio ?: currentSettings.defaultAspectRatio
        val speed = currentSettings.defaultPlaybackSpeed
        val hasSavedResume = !forceStartFromBeginning && video.hasResumePosition
        val initialSeekMs = if (hasSavedResume && currentSettings.resumePlayback) {
            video.lastPositionMs
        } else {
            0L
        }
        val showResumeBanner = hasSavedResume && currentSettings.smartResumePrompt

        _uiState.update {
            it.copy(
                isPlayerOpen = true,
                currentVideo = video,
                queue = validQueue,
                currentQueueIndex = index,
                currentPositionMs = initialSeekMs,
                durationMs = video.durationMs,
                videoWidth = video.width,
                videoHeight = video.height,
                playbackSpeed = speed,
                aspectRatioMode = preferredRatio,
                showSmartResumeBanner = showResumeBanner,
                smartResumeTargetMs = video.lastPositionMs,
                playbackError = null,
                playbackErrorCodeName = null,
                activeInternalSubtitleText = null,
                activeExternalSubtitleText = null,
                externalSubtitleName = video.externalSubtitleName,
                externalSubtitleCues = emptyList()
            )
        }

        // Load external subtitle if previously linked to this video
        if (!video.externalSubtitleUri.isNullOrBlank()) {
            controllerScope.launch {
                val res = subtitleManager.loadSubtitleFromUri(Uri.parse(video.externalSubtitleUri))
                res.onSuccess { subFile ->
                    _uiState.update {
                        it.copy(
                            externalSubtitleName = subFile.displayName,
                            externalSubtitleCues = subFile.cues
                        )
                    }
                }
            }
        }

        // Prepare ExoPlayer
        try {
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(video.uriString))
                .setMediaId(video.id)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(video.title)
                        .setSubtitle(video.folderName)
                        .build()
                )
                .build()

            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.setPlaybackParameters(PlaybackParameters(speed))
            exoPlayer.repeatMode = _uiState.value.repeatMode
            exoPlayer.prepare()
            if (initialSeekMs > 0L) {
                exoPlayer.seekTo(initialSeekMs)
            }
            exoPlayer.playWhenReady = true

            startMediaSessionServiceIfNeeded()

            controllerScope.launch {
                repository.recordPlaybackStart(video, currentSettings.saveHistoryEnabled)
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    playbackError = e.localizedMessage ?: "Failed to initialize video playback",
                    playbackErrorCodeName = "INITIALIZATION_ERROR"
                )
            }
        }
    }

    private fun startMediaSessionServiceIfNeeded() {
        runCatching {
            val intent = Intent(context, PlaybackService::class.java)
            context.startService(intent)
        }
    }

    fun togglePlayPause() {
        if (_uiState.value.playbackError != null) {
            // Retry playback on error
            _uiState.value.currentVideo?.let { openAndPlayVideo(it, _uiState.value.queue) }
            return
        }
        if (exoPlayer.playbackState == Player.STATE_ENDED) {
            exoPlayer.seekTo(0L)
            exoPlayer.playWhenReady = true
        } else if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun replayFromBeginning() {
        _uiState.update { it.copy(showSmartResumeBanner = false) }
        exoPlayer.seekTo(0L)
        exoPlayer.playWhenReady = true
    }

    fun confirmSmartResume() {
        val target = _uiState.value.smartResumeTargetMs
        _uiState.update { it.copy(showSmartResumeBanner = false) }
        if (target > 0L) {
            exoPlayer.seekTo(target)
            exoPlayer.playWhenReady = true
        }
    }

    fun dismissSmartResumeBanner() {
        _uiState.update { it.copy(showSmartResumeBanner = false) }
    }

    fun seekTo(positionMs: Long) {
        val duration = _uiState.value.durationMs.takeIf { it > 0 } ?: exoPlayer.duration.coerceAtLeast(0L)
        val clamped = if (duration > 0) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
        exoPlayer.seekTo(clamped)
        _uiState.update { it.copy(currentPositionMs = clamped) }
        refreshSubtitleCueAtPosition(clamped)
    }

    fun seekByDeltaMs(deltaMs: Long) {
        val target = exoPlayer.currentPosition + deltaMs
        seekTo(target)
    }

    fun forwardByConfiguredSeconds() {
        seekByDeltaMs(currentSettings.forwardSeekSeconds * 1000L)
    }

    fun backwardByConfiguredSeconds() {
        seekByDeltaMs(-currentSettings.backwardSeekSeconds * 1000L)
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 3.0f)
        exoPlayer.setPlaybackParameters(PlaybackParameters(clamped))
        _uiState.update { it.copy(playbackSpeed = clamped) }
    }

    fun toggleMute() {
        val currentlyMuted = _uiState.value.isMuted
        if (currentlyMuted) {
            exoPlayer.volume = 1f
            _uiState.update { it.copy(isMuted = false) }
        } else {
            exoPlayer.volume = 0f
            _uiState.update { it.copy(isMuted = true) }
        }
    }

    fun setVolumeLevel(fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val targetIndex = (clamped * maxVol).toInt().coerceIn(0, maxVol)
        runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetIndex, 0)
        }
        exoPlayer.volume = if (clamped == 0f) 0f else 1f
        _uiState.update {
            it.copy(
                volumeLevel = clamped,
                isMuted = clamped == 0f
            )
        }
    }

    fun setBrightnessLevel(fraction: Float) {
        val clamped = fraction.coerceIn(0.05f, 1f)
        _uiState.update { it.copy(brightnessLevel = clamped) }
    }

    fun cycleRepeatMode() {
        val nextMode = when (_uiState.value.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        exoPlayer.repeatMode = nextMode
        _uiState.update { it.copy(repeatMode = nextMode) }
    }

    fun toggleShuffle() {
        val nextShuffle = !_uiState.value.isShuffleEnabled
        _uiState.update { it.copy(isShuffleEnabled = nextShuffle) }
    }

    fun playNextInQueue() {
        val state = _uiState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        saveCurrentProgressNow(addedWatchMs = 0L)

        val nextIndex = if (state.isShuffleEnabled && queue.size > 1) {
            val candidates = queue.indices.filter { it != state.currentQueueIndex }
            candidates.random()
        } else {
            val candidate = state.currentQueueIndex + 1
            if (candidate < queue.size) {
                candidate
            } else if (state.repeatMode == Player.REPEAT_MODE_ALL) {
                0
            } else {
                return
            }
        }
        openAndPlayVideo(queue[nextIndex], queue)
    }

    fun playPreviousInQueue() {
        if (exoPlayer.currentPosition > 5_000L) {
            seekTo(0L)
            return
        }
        val state = _uiState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        saveCurrentProgressNow(addedWatchMs = 0L)

        val prevIndex = if (state.currentQueueIndex > 0) {
            state.currentQueueIndex - 1
        } else if (state.repeatMode == Player.REPEAT_MODE_ALL) {
            queue.lastIndex
        } else {
            0
        }
        openAndPlayVideo(queue[prevIndex], queue)
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        _uiState.update { it.copy(aspectRatioMode = mode) }
        val videoUri = _uiState.value.currentVideo?.uriString ?: return
        controllerScope.launch {
            repository.saveVideoAspectRatio(videoUri, mode)
        }
    }

    fun cycleAspectRatio() {
        val modes = AspectRatioMode.entries
        val currentIdx = modes.indexOf(_uiState.value.aspectRatioMode)
        val nextMode = modes[(currentIdx + 1) % modes.size]
        setAspectRatio(nextMode)
    }

    fun toggleFullscreen() {
        _uiState.update { it.copy(isFullscreen = !it.isFullscreen) }
    }

    fun setFullscreen(fullscreen: Boolean) {
        _uiState.update { it.copy(isFullscreen = fullscreen) }
    }

    fun toggleScreenLock() {
        _uiState.update { it.copy(isScreenLocked = !it.isScreenLocked) }
    }

    fun toggleOrientationLock() {
        _uiState.update { it.copy(isOrientationLocked = !it.isOrientationLocked) }
    }

    fun toggleLandscapePortrait() {
        _uiState.update { it.copy(isLandscapePreferred = !it.isLandscapePreferred) }
    }

    fun loadExternalSubtitleFromUri(uri: Uri) {
        controllerScope.launch {
            val result = subtitleManager.loadSubtitleFromUri(uri)
            result.onSuccess { loaded ->
                _uiState.update {
                    it.copy(
                        externalSubtitleName = loaded.displayName,
                        externalSubtitleCues = loaded.cues
                    )
                }
                refreshSubtitleCueAtPosition(exoPlayer.currentPosition)
                _uiState.value.currentVideo?.let { video ->
                    repository.saveExternalSubtitle(
                        uriString = video.uriString,
                        subtitleUri = loaded.uriString,
                        subtitleName = loaded.displayName
                    )
                }
            }
        }
    }

    fun clearExternalSubtitle() {
        _uiState.update {
            it.copy(
                externalSubtitleName = null,
                externalSubtitleCues = emptyList(),
                activeExternalSubtitleText = null
            )
        }
        _uiState.value.currentVideo?.let { video ->
            controllerScope.launch {
                repository.saveExternalSubtitle(video.uriString, null, null)
            }
        }
    }

    fun selectAudioTrack(option: TrackOption) {
        val groups = exoPlayer.currentTracks.groups
        if (option.groupIndex in groups.indices) {
            val group = groups[option.groupIndex]
            val override = TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex)
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setOverrideForType(override)
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                .build()
        }
    }

    fun selectInternalSubtitleTrack(option: TrackOption?) {
        if (option == null) {
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            _uiState.update { it.copy(activeInternalSubtitleText = null) }
            return
        }
        val groups = exoPlayer.currentTracks.groups
        if (option.groupIndex in groups.indices) {
            val group = groups[option.groupIndex]
            val override = TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex)
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(override)
                .build()
        }
    }

    fun selectVideoQualityTrack(option: TrackOption?) {
        if (option == null) {
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                .build()
            _uiState.update { it.copy(selectedQualityLabel = "Auto") }
            return
        }
        val groups = exoPlayer.currentTracks.groups
        if (option.groupIndex in groups.indices) {
            val group = groups[option.groupIndex]
            val override = TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex)
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setOverrideForType(override)
                .build()
            _uiState.update { it.copy(selectedQualityLabel = option.label) }
        }
    }

    fun setSleepTimer(option: SleepTimerOption) {
        sleepTimerJob?.cancel()
        if (option == SleepTimerOption.OFF) {
            _uiState.update { it.copy(sleepTimerOption = SleepTimerOption.OFF, sleepTimerRemainingSec = 0L) }
            return
        }
        if (option == SleepTimerOption.END_OF_VIDEO) {
            _uiState.update { it.copy(sleepTimerOption = SleepTimerOption.END_OF_VIDEO, sleepTimerRemainingSec = 0L) }
            return
        }
        val totalSeconds = option.minutes * 60L
        _uiState.update {
            it.copy(
                sleepTimerOption = option,
                sleepTimerRemainingSec = totalSeconds
            )
        }
        sleepTimerJob = controllerScope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && isActive) {
                delay(1000L)
                remaining--
                _uiState.update { it.copy(sleepTimerRemainingSec = remaining) }
            }
            if (remaining <= 0L) {
                exoPlayer.pause()
                _uiState.update {
                    it.copy(
                        sleepTimerOption = SleepTimerOption.OFF,
                        sleepTimerRemainingSec = 0L
                    )
                }
            }
        }
    }

    fun onPipModeChanged(isInPipMode: Boolean) {
        _uiState.update { it.copy(isInPipMode = isInPipMode) }
    }

    fun onAppBackgrounded(isEnteringPip: Boolean) {
        if (isEnteringPip) return
        if (currentSettings.backgroundAudioEnabled && exoPlayer.isPlaying) {
            _uiState.update { it.copy(isPlayingInBackground = true) }
        } else {
            exoPlayer.pause()
            saveCurrentProgressNow(addedWatchMs = 0L)
        }
    }

    fun onAppForegrounded() {
        _uiState.update { it.copy(isPlayingInBackground = false) }
    }

    fun closePlayer() {
        saveCurrentProgressNow(addedWatchMs = 0L)
        if (!currentSettings.backgroundAudioEnabled) {
            exoPlayer.pause()
        }
        _uiState.update {
            it.copy(
                isPlayerOpen = false,
                isFullscreen = false,
                isScreenLocked = false,
                showSmartResumeBanner = false
            )
        }
    }

    fun stopAndClosePlayerCompletely() {
        saveCurrentProgressNow(addedWatchMs = 0L)
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        _uiState.update {
            it.copy(
                isPlayerOpen = false,
                isPlaying = false,
                isPlayingInBackground = false,
                currentVideo = null
            )
        }
    }

    private fun parseAvailableTracks(tracks: Tracks) {
        val audioList = mutableListOf<TrackOption>()
        val subList = mutableListOf<TrackOption>()
        val videoList = mutableListOf<TrackOption>()

        tracks.groups.forEachIndexed { groupIdx, group ->
            val trackType = group.type
            for (trackIdx in 0 until group.length) {
                val format = group.getTrackFormat(trackIdx)
                val selected = group.isTrackSelected(trackIdx)
                val langCode = format.language ?: ""
                val displayLang = if (langCode.isNotBlank() && langCode != C.LANGUAGE_UNDETERMINED) {
                    Locale(langCode).getDisplayLanguage(Locale.getDefault()).ifBlank { langCode }
                } else {
                    ""
                }

                when (trackType) {
                    C.TRACK_TYPE_AUDIO -> {
                        val label = buildString {
                            append(format.label ?: displayLang.ifBlank { "Audio Track ${audioList.size + 1}" })
                            if (displayLang.isNotBlank() && format.label != null && !format.label!!.contains(displayLang, true)) {
                                append(" ($displayLang)")
                            }
                            if (format.channelCount > 0) {
                                append(" • ${format.channelCount}ch")
                            }
                        }
                        audioList.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = trackIdx,
                                id = format.id ?: "aud_${groupIdx}_$trackIdx",
                                label = label,
                                language = displayLang.ifBlank { "Default" },
                                isSelected = selected,
                                bitrate = format.bitrate,
                                mimeType = format.sampleMimeType ?: ""
                            )
                        )
                    }

                    C.TRACK_TYPE_TEXT -> {
                        val label = format.label ?: displayLang.ifBlank { "Subtitle ${subList.size + 1}" }
                        subList.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = trackIdx,
                                id = format.id ?: "sub_${groupIdx}_$trackIdx",
                                label = label,
                                language = displayLang.ifBlank { "Track ${subList.size + 1}" },
                                isSelected = selected,
                                mimeType = format.sampleMimeType ?: ""
                            )
                        )
                    }

                    C.TRACK_TYPE_VIDEO -> {
                        val w = format.width.coerceAtLeast(0)
                        val h = format.height.coerceAtLeast(0)
                        val resLabel = when {
                            h >= 2160 -> "4K (2160p)"
                            h >= 1440 -> "2K (1440p)"
                            h >= 1080 -> "1080p Full HD"
                            h >= 720 -> "720p HD"
                            h >= 480 -> "480p SD"
                            h > 0 -> "${h}p (${w}x${h})"
                            else -> format.label ?: "Video Stream ${videoList.size + 1}"
                        }
                        videoList.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = trackIdx,
                                id = format.id ?: "vid_${groupIdx}_$trackIdx",
                                label = resLabel,
                                language = "",
                                isSelected = selected,
                                bitrate = format.bitrate,
                                width = w,
                                height = h,
                                mimeType = format.sampleMimeType ?: ""
                            )
                        )
                    }
                }
            }
        }

        _uiState.update {
            it.copy(
                audioTracks = audioList,
                subtitleTracks = subList,
                videoQualityTracks = videoList
            )
        }
    }

    private fun startProgressLoop() {
        progressPollingJob?.cancel()
        lastProgressSaveTimeMs = System.currentTimeMillis()
        progressPollingJob = controllerScope.launch {
            var tickCount = 0
            while (isActive && exoPlayer.isPlaying) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
                _uiState.update {
                    it.copy(
                        currentPositionMs = pos,
                        durationMs = dur
                    )
                }
                refreshSubtitleCueAtPosition(pos)

                tickCount++
                // Persist position & watch time to Room every ~2.5 seconds
                if (tickCount % 10 == 0) {
                    val now = System.currentTimeMillis()
                    val elapsed = (now - lastProgressSaveTimeMs).coerceIn(0L, 10_000L)
                    lastProgressSaveTimeMs = now
                    saveCurrentProgressNow(addedWatchMs = elapsed)
                }
                delay(250L)
            }
        }
    }

    private fun refreshSubtitleCueAtPosition(positionMs: Long) {
        val cues = _uiState.value.externalSubtitleCues
        if (cues.isNotEmpty()) {
            val active = subtitleManager.getActiveSubtitleText(
                cues = cues,
                currentPositionMs = positionMs,
                delayMs = currentSettings.subtitleConfig.delayMs
            )
            _uiState.update { it.copy(activeExternalSubtitleText = active) }
        }
    }

    private fun saveCurrentProgressNow(addedWatchMs: Long) {
        val currentVideo = _uiState.value.currentVideo ?: return
        val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val dur = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: _uiState.value.durationMs
        controllerScope.launch {
            repository.recordPlaybackProgress(
                uriString = currentVideo.uriString,
                positionMs = pos,
                durationMs = dur,
                addedWatchTimeMs = addedWatchMs,
                saveHistory = currentSettings.saveHistoryEnabled
            )
        }
    }

    private fun syncSystemVolume() {
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(0)
        val fraction = (curVol.toFloat() / maxVol.toFloat()).coerceIn(0f, 1f)
        _uiState.update {
            it.copy(
                volumeLevel = fraction,
                isMuted = curVol == 0
            )
        }
    }
}
