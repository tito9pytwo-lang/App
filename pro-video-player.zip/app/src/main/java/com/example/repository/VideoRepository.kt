package com.example.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.database.PlaylistEntity
import com.example.database.PlaylistItemEntity
import com.example.database.SafSourceEntity
import com.example.database.VideoDao
import com.example.database.VideoUserMetadataEntity
import com.example.model.AspectRatioMode
import com.example.model.PlaylistWithVideos
import com.example.model.VideoItem
import com.example.scanner.ThumbnailCacheManager
import com.example.scanner.VideoFileScanner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VideoRepository(
    private val context: Context,
    private val videoDao: VideoDao,
    val scanner: VideoFileScanner = VideoFileScanner(context),
    val thumbnailCache: ThumbnailCacheManager = ThumbnailCacheManager(context)
) {
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _rawScannedVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val allVideosFlow: Flow<List<VideoItem>> = combine(
        _rawScannedVideos,
        videoDao.observeAllMetadata()
    ) { scannedList, metadataList ->
        val metaByUri = metadataList.associateBy { it.uriString }
        scannedList.map { video ->
            val meta = metaByUri[video.uriString]
            if (meta == null) {
                video
            } else {
                video.copy(
                    title = meta.customTitle?.takeIf { it.isNotBlank() } ?: video.title,
                    isFavorite = meta.isFavorite,
                    lastPositionMs = meta.lastPositionMs,
                    durationMs = if (video.durationMs > 0L) video.durationMs else meta.durationMs,
                    watchPercentage = meta.watchPercentage,
                    lastPlayedAt = meta.lastPlayedAt,
                    playCount = meta.playCount,
                    totalWatchTimeMs = meta.totalWatchTimeMs,
                    preferredAspectRatio = meta.preferredAspectRatio?.let {
                        runCatching { AspectRatioMode.valueOf(it) }.getOrNull()
                    },
                    externalSubtitleUri = meta.externalSubtitleUri,
                    externalSubtitleName = meta.externalSubtitleName
                )
            }
        }
    }

    val playlistsFlow: Flow<List<PlaylistWithVideos>> = combine(
        videoDao.observePlaylists(),
        videoDao.observeAllPlaylistItems(),
        allVideosFlow
    ) { playlists, items, allVideos ->
        val videoByUri = allVideos.associateBy { it.uriString }
        val itemsByPlaylist = items.groupBy { it.playlistId }
        playlists.map { playlist ->
            val orderedItems = (itemsByPlaylist[playlist.playlistId] ?: emptyList())
                .sortedBy { it.sortOrder }
            val resolvedVideos = orderedItems.mapNotNull { item ->
                videoByUri[item.videoUri]
            }
            PlaylistWithVideos(
                playlistId = playlist.playlistId,
                name = playlist.name,
                createdAt = playlist.createdAt,
                videos = resolvedVideos
            )
        }
    }

    val safSourcesFlow: Flow<List<SafSourceEntity>> = videoDao.observeSafSources()

    suspend fun refreshLibrary() = withContext(Dispatchers.IO) {
        _isScanning.value = true
        try {
            val safSources = videoDao.getAllSafSources()
            val discovered = scanner.scanAllDeviceVideos(safSources)
            _rawScannedVideos.value = discovered
        } finally {
            _isScanning.value = false
        }
    }

    suspend fun addSafFolder(treeUri: Uri) = withContext(Dispatchers.IO) {
        runCatching {
            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
        }.onFailure {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        val doc = DocumentFile.fromTreeUri(context, treeUri)
        val folderName = doc?.name ?: treeUri.lastPathSegment?.substringAfterLast(':') ?: "Video Folder"
        videoDao.insertSafSource(
            SafSourceEntity(
                uriString = treeUri.toString(),
                displayName = folderName,
                isTree = true
            )
        )
        refreshLibrary()
    }

    suspend fun addPickedVideoUris(uris: List<Uri>): List<VideoItem> = withContext(Dispatchers.IO) {
        val newlyAdded = mutableListOf<VideoItem>()
        for (uri in uris) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val inspected = scanner.inspectSingleUri(uri)
            if (inspected != null) {
                videoDao.insertSafSource(
                    SafSourceEntity(
                        uriString = uri.toString(),
                        displayName = inspected.displayName,
                        isTree = false
                    )
                )
                newlyAdded.add(inspected)
            }
        }
        refreshLibrary()
        newlyAdded
    }

    suspend fun removeSafSource(uriString: String) = withContext(Dispatchers.IO) {
        videoDao.deleteSafSource(uriString)
        refreshLibrary()
    }

    suspend fun toggleFavorite(video: VideoItem) = withContext(Dispatchers.IO) {
        val existing = videoDao.getMetadataForUri(video.uriString)
        val updated = (existing ?: VideoUserMetadataEntity(uriString = video.uriString)).copy(
            isFavorite = !video.isFavorite,
            durationMs = video.durationMs
        )
        videoDao.upsertMetadata(updated)
    }

    suspend fun recordPlaybackStart(video: VideoItem, saveHistory: Boolean) = withContext(Dispatchers.IO) {
        val existing = videoDao.getMetadataForUri(video.uriString) ?: VideoUserMetadataEntity(uriString = video.uriString)
        val now = System.currentTimeMillis()
        val updated = existing.copy(
            playCount = existing.playCount + 1,
            lastPlayedAt = if (saveHistory) now else existing.lastPlayedAt,
            durationMs = if (video.durationMs > 0L) video.durationMs else existing.durationMs
        )
        videoDao.upsertMetadata(updated)
    }

    suspend fun recordPlaybackProgress(
        uriString: String,
        positionMs: Long,
        durationMs: Long,
        addedWatchTimeMs: Long,
        saveHistory: Boolean
    ) = withContext(Dispatchers.IO) {
        val existing = videoDao.getMetadataForUri(uriString) ?: VideoUserMetadataEntity(uriString = uriString)
        val validDuration = if (durationMs > 0L) durationMs else existing.durationMs
        val percentage = if (validDuration > 0L) {
            (positionMs.toFloat() / validDuration.toFloat()).coerceIn(0f, 1f)
        } else 0f

        val updated = existing.copy(
            lastPositionMs = if (saveHistory) positionMs.coerceAtLeast(0L) else existing.lastPositionMs,
            durationMs = validDuration,
            watchPercentage = if (saveHistory) percentage else existing.watchPercentage,
            lastPlayedAt = if (saveHistory) System.currentTimeMillis() else existing.lastPlayedAt,
            totalWatchTimeMs = (existing.totalWatchTimeMs + addedWatchTimeMs.coerceAtLeast(0L))
        )
        videoDao.upsertMetadata(updated)
    }

    suspend fun saveVideoAspectRatio(uriString: String, aspectRatioMode: AspectRatioMode) = withContext(Dispatchers.IO) {
        val existing = videoDao.getMetadataForUri(uriString) ?: VideoUserMetadataEntity(uriString = uriString)
        videoDao.upsertMetadata(existing.copy(preferredAspectRatio = aspectRatioMode.name))
    }

    suspend fun saveExternalSubtitle(uriString: String, subtitleUri: String?, subtitleName: String?) = withContext(Dispatchers.IO) {
        val existing = videoDao.getMetadataForUri(uriString) ?: VideoUserMetadataEntity(uriString = uriString)
        videoDao.upsertMetadata(
            existing.copy(
                externalSubtitleUri = subtitleUri,
                externalSubtitleName = subtitleName
            )
        )
    }

    suspend fun removeHistoryItem(uriString: String) = withContext(Dispatchers.IO) {
        videoDao.clearHistoryForUri(uriString)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        videoDao.clearAllHistory()
    }

    // Playlist Management
    suspend fun createPlaylist(name: String, initialVideoUri: String? = null): Long = withContext(Dispatchers.IO) {
        val cleanName = name.trim().ifEmpty { "My Playlist" }
        val playlistId = videoDao.insertPlaylist(PlaylistEntity(name = cleanName))
        if (initialVideoUri != null) {
            videoDao.insertPlaylistItem(
                PlaylistItemEntity(
                    playlistId = playlistId,
                    videoUri = initialVideoUri,
                    sortOrder = 0
                )
            )
        }
        playlistId
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) = withContext(Dispatchers.IO) {
        val clean = newName.trim()
        if (clean.isNotEmpty()) {
            videoDao.renamePlaylist(playlistId, clean)
        }
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        videoDao.deletePlaylist(playlistId)
    }

    suspend fun addVideoToPlaylist(playlistId: Long, videoUri: String) = withContext(Dispatchers.IO) {
        val nextOrder = videoDao.getNextSortOrder(playlistId)
        videoDao.insertPlaylistItem(
            PlaylistItemEntity(
                playlistId = playlistId,
                videoUri = videoUri,
                sortOrder = nextOrder
            )
        )
    }

    suspend fun removeVideoFromPlaylist(playlistId: Long, videoUri: String) = withContext(Dispatchers.IO) {
        videoDao.removeVideoFromPlaylist(playlistId, videoUri)
    }

    suspend fun moveVideoInPlaylist(playlistId: Long, fromIndex: Int, toIndex: Int) = withContext(Dispatchers.IO) {
        val currentItems = videoDao.getPlaylistItemsSync(playlistId).map { it.videoUri }.toMutableList()
        if (fromIndex in currentItems.indices && toIndex in currentItems.indices && fromIndex != toIndex) {
            val moved = currentItems.removeAt(fromIndex)
            currentItems.add(toIndex, moved)
            videoDao.updatePlaylistOrder(playlistId, currentItems)
        }
    }

    // File Operations
    suspend fun renameVideo(video: VideoItem, newTitle: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanTitle = newTitle.trim()
        if (cleanTitle.isEmpty()) return@withContext Result.failure(IllegalArgumentException("Empty title"))

        val renameResult = scanner.renameVideoFile(video, cleanTitle)
        val newUriString = renameResult.getOrDefault(video.uriString)
        val existingMeta = videoDao.getMetadataForUri(video.uriString)
            ?: VideoUserMetadataEntity(uriString = newUriString)

        if (newUriString != video.uriString) {
            videoDao.deleteMetadataByUri(video.uriString)
        }
        videoDao.upsertMetadata(
            existingMeta.copy(
                uriString = newUriString,
                customTitle = cleanTitle
            )
        )
        refreshLibrary()
        Result.success(Unit)
    }

    suspend fun deleteVideo(video: VideoItem): Result<Unit> = withContext(Dispatchers.IO) {
        val deleteResult = scanner.deleteVideoFile(video)
        // Always clean up local references if deleted or if it was a SAF picked source
        videoDao.deleteSafSource(video.uriString)
        videoDao.deleteMetadataByUri(video.uriString)
        videoDao.removeVideoFromAllPlaylists(video.uriString)
        thumbnailCache.invalidate(video.uriString)

        // Remove from in-memory scanned list immediately
        _rawScannedVideos.value = _rawScannedVideos.value.filterNot { it.uriString == video.uriString }
        if (deleteResult.isSuccess) {
            Result.success(Unit)
        } else {
            Result.success(Unit)
        }
    }

    fun shareVideo(video: VideoItem) {
        scanner.shareVideoFile(video)
    }

    suspend fun getDetailedTechnicalInfo(video: VideoItem): VideoItem {
        return scanner.extractDetailedTechnicalInfo(video)
    }
}
