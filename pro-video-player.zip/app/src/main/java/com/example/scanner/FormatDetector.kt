package com.example.scanner

import android.content.ContentResolver
import android.net.Uri
import java.util.Locale

object FormatDetector {

    val SUPPORTED_EXTENSIONS = setOf(
        "mp4", "m4v", "mkv", "webm", "3gp", "3g2", "mov", "avi", "mpeg", "mpg", "ts", "m2ts", "mts", "flv", "asf", "wmv", "ogv"
    )

    val SUBTITLE_EXTENSIONS = setOf(
        "srt", "vtt", "ass", "ssa"
    )

    /**
     * Detects the true video container format by inspecting magic header bytes first,
     * falling back to MIME type and filename extension.
     */
    fun detectVideoFormat(
        contentResolver: ContentResolver,
        uri: Uri,
        displayName: String,
        mimeType: String?
    ): String {
        val headerBytes = readHeaderBytes(contentResolver, uri, 64)
        if (headerBytes != null && headerBytes.size >= 12) {
            val magicFormat = parseMagicBytes(headerBytes)
            if (magicFormat != null) return magicFormat
        }

        val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when {
            ext in setOf("mp4", "m4v") -> "MP4"
            ext == "mkv" -> "MKV"
            ext == "webm" -> "WebM"
            ext in setOf("3gp", "3g2") -> "3GP"
            ext == "mov" -> "MOV"
            ext == "avi" -> "AVI"
            ext in setOf("mpeg", "mpg") -> "MPEG"
            ext in setOf("ts", "m2ts", "mts") -> "TS"
            mimeType?.contains("matroska", ignoreCase = true) == true -> "MKV"
            mimeType?.contains("webm", ignoreCase = true) == true -> "WebM"
            mimeType?.contains("3gpp", ignoreCase = true) == true -> "3GP"
            mimeType?.contains("quicktime", ignoreCase = true) == true -> "MOV"
            mimeType?.contains("avi", ignoreCase = true) == true -> "AVI"
            mimeType?.contains("mp2t", ignoreCase = true) == true -> "TS"
            mimeType?.contains("mpeg", ignoreCase = true) == true -> "MPEG"
            mimeType?.contains("mp4", ignoreCase = true) == true -> "MP4"
            ext.isNotEmpty() -> ext.uppercase(Locale.ROOT)
            else -> "MP4"
        }
    }

    fun isLikelyVideoFile(
        contentResolver: ContentResolver,
        uri: Uri,
        displayName: String,
        mimeType: String?
    ): Boolean {
        if (mimeType?.startsWith("video/", ignoreCase = true) == true) return true
        val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext in SUPPORTED_EXTENSIONS) return true

        // Even if the file has an unusual extension, check magic header bytes
        val header = readHeaderBytes(contentResolver, uri, 64) ?: return false
        return parseMagicBytes(header) != null
    }

    fun parseMagicBytes(bytes: ByteArray): String? {
        if (bytes.size < 12) return null

        // ISO Base Media File Format (ftyp at offset 4): MP4, MOV, 3GP
        if (bytes[4] == 'f'.code.toByte() &&
            bytes[5] == 't'.code.toByte() &&
            bytes[6] == 'y'.code.toByte() &&
            bytes[7] == 'p'.code.toByte()
        ) {
            val brand = String(bytes, 8, 4, Charsets.US_ASCII)
            return when {
                brand.startsWith("3g", ignoreCase = true) -> "3GP"
                brand.equals("qt  ", ignoreCase = true) -> "MOV"
                else -> "MP4"
            }
        }

        // EBML Header (0x1A 0x45 0xDF 0xA3): Matroska (MKV) or WebM
        if (bytes[0] == 0x1A.toByte() &&
            bytes[1] == 0x45.toByte() &&
            bytes[2] == 0xDF.toByte() &&
            bytes[3] == 0xA3.toByte()
        ) {
            val headerAscii = String(bytes, Charsets.ISO_8859_1).lowercase(Locale.ROOT)
            return if (headerAscii.contains("webm")) "WebM" else "MKV"
        }

        // RIFF....AVI
        if (bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte() &&
            bytes[8] == 'A'.code.toByte() &&
            bytes[9] == 'V'.code.toByte() &&
            bytes[10] == 'I'.code.toByte()
        ) {
            return "AVI"
        }

        // MPEG Program Stream (0x00 0x00 0x01 0xBA or 0x00 0x00 0x01 0xB3)
        if (bytes[0] == 0x00.toByte() &&
            bytes[1] == 0x00.toByte() &&
            bytes[2] == 0x01.toByte() &&
            (bytes[3] == 0xBA.toByte() || bytes[3] == 0xB3.toByte())
        ) {
            return "MPEG"
        }

        // MPEG Transport Stream (0x47 sync byte at 0, and if >= 189 bytes at 188, or 0x47 at 0)
        if (bytes[0] == 0x47.toByte() && (bytes.size < 189 || bytes[188] == 0x47.toByte())) {
            // Verify it's not a plain text starting with 'G'
            val secondByte = bytes[1].toInt() and 0xFF
            if (secondByte == 0x40 || secondByte == 0x00 || secondByte == 0x50) {
                return "TS"
            }
        }

        return null
    }

    private fun readHeaderBytes(contentResolver: ContentResolver, uri: Uri, count: Int): ByteArray? {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(count)
                val read = input.read(buffer)
                if (read > 0) buffer.copyOf(read) else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
