package com.example.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class ThumbnailCacheManager(private val context: Context) {

    private val maxMemoryKb = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSizeKb = (maxMemoryKb / 8).coerceAtLeast(4 * 1024)

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSizeKb) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    private val diskCacheDir: File by lazy {
        File(context.cacheDir, "video_thumbnails").apply {
            if (!exists()) mkdirs()
        }
    }

    // Limit concurrent MediaMetadataRetriever instances to avoid memory spikes or UI jank
    private val extractionSemaphore = Semaphore(3)

    fun getMemoryCached(uriString: String): Bitmap? {
        val key = hashKey(uriString)
        return memoryCache.get(key)
    }

    suspend fun getOrLoadThumbnail(
        uriString: String,
        widthPx: Int = 420,
        heightPx: Int = 240
    ): Bitmap? = withContext(Dispatchers.IO) {
        val key = hashKey(uriString)
        memoryCache.get(key)?.let { return@withContext it }

        val diskFile = File(diskCacheDir, "$key.jpg")
        if (diskFile.exists() && diskFile.length() > 0) {
            val decoded = runCatching {
                BitmapFactory.decodeFile(diskFile.absolutePath)
            }.getOrNull()
            if (decoded != null) {
                memoryCache.put(key, decoded)
                return@withContext decoded
            }
        }

        extractionSemaphore.withPermit {
            memoryCache.get(key)?.let { return@withPermit it }
            val generated = extractThumbnail(Uri.parse(uriString), widthPx, heightPx)
            if (generated != null) {
                memoryCache.put(key, generated)
                runCatching {
                    FileOutputStream(diskFile).use { out ->
                        generated.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    }
                }
            }
            generated
        }
    }

    private fun extractThumbnail(uri: Uri, widthPx: Int, heightPx: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri.scheme == "content") {
            try {
                return context.contentResolver.loadThumbnail(uri, Size(widthPx, heightPx), null)
            } catch (_: Exception) {
                // Fall back to MediaMetadataRetriever
            }
        }

        val retriever = MediaMetadataRetriever()
        return try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val frameTimeUs = if (durationMs > 5000L) 2_000_000L else (durationMs * 300L)
            val rawFrame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    frameTimeUs,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    widthPx,
                    heightPx
                )
            } else {
                retriever.getFrameAtTime(frameTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            }
            rawFrame
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun invalidate(uriString: String) {
        val key = hashKey(uriString)
        memoryCache.remove(key)
        runCatching { File(diskCacheDir, "$key.jpg").delete() }
    }

    private fun hashKey(input: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
