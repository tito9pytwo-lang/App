package com.example.scanner

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.example.database.SafSourceEntity
import com.example.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoFileScanner(private val context: Context) {

    suspend fun scanAllDeviceVideos(
        safSources: List<SafSourceEntity>
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val discoveredByUri = LinkedHashMap<String, VideoItem>()

        // 1. Scan MediaStore.Video.Media
        scanMediaStoreVideos().forEach { item ->
            discoveredByUri[item.uriString] = item
        }

        // 2. Scan persisted SAF URIs from ContentResolver + Room SAF sources
        val allTreeUris = LinkedHashSet<Uri>()
        val allSingleUris = LinkedHashSet<Uri>()

        runCatching {
            context.contentResolver.persistedUriPermissions.forEach { perm ->
                if (perm.isReadPermission) {
                    val uri = perm.uri
                    if (DocumentsContract.isTreeUri(uri)) {
                        allTreeUris.add(uri)
                    } else {
                        allSingleUris.add(uri)
                    }
                }
            }
        }

        safSources.forEach { source ->
            val uri = Uri.parse(source.uriString)
            if (source.isTree || DocumentsContract.isTreeUri(uri)) {
                allTreeUris.add(uri)
            } else {
                allSingleUris.add(uri)
            }
        }

        for (treeUri in allTreeUris) {
            val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
            if (rootDoc != null && rootDoc.exists()) {
                val rootFolderName = rootDoc.name ?: "Folder"
                scanDocumentTreeRecursive(
                    docDir = rootDoc,
                    parentPath = rootFolderName,
                    results = discoveredByUri,
                    maxDepth = 5
                )
            }
        }

        for (singleUri in allSingleUris) {
            if (!discoveredByUri.containsKey(singleUri.toString())) {
                inspectSingleUri(singleUri)?.let { item ->
                    discoveredByUri[item.uriString] = item
                }
            }
        }

        // 3. Scan app-accessible external media directories
        scanAppDirectories(discoveredByUri)

        discoveredByUri.values.toList()
    }

    private fun scanMediaStoreVideos(): List<VideoItem> {
        val list = mutableListOf<VideoItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
            } else {
                @Suppress("DEPRECATION")
                add(MediaStore.Video.Media.DATA)
            }
        }.toTypedArray()

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val pathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else {
                    @Suppress("DEPRECATION")
                    cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                }

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val displayName = cursor.getString(nameCol) ?: "Video_$id.mp4"
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val duration = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val dateAdded = cursor.getLong(addedCol)
                    val dateModified = cursor.getLong(modifiedCol).let { if (it > 0) it else dateAdded }
                    val mimeType = cursor.getString(mimeCol) ?: "video/mp4"
                    val width = cursor.getInt(widthCol).coerceAtLeast(0)
                    val height = cursor.getInt(heightCol).coerceAtLeast(0)
                    val bucketName = cursor.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Videos"
                    val rawPath = if (pathCol >= 0) cursor.getString(pathCol) ?: "" else ""
                    val folderPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        rawPath.trimEnd('/').ifEmpty { bucketName }
                    } else {
                        File(rawPath).parent ?: bucketName
                    }

                    val detectedFormat = FormatDetector.detectVideoFormat(
                        contentResolver = context.contentResolver,
                        uri = contentUri,
                        displayName = displayName,
                        mimeType = mimeType
                    )

                    list.add(
                        VideoItem(
                            id = "ms_$id",
                            uriString = contentUri.toString(),
                            title = title,
                            displayName = displayName,
                            folderName = bucketName,
                            folderPath = folderPath,
                            sizeBytes = size,
                            durationMs = duration,
                            dateAddedSec = dateAdded,
                            dateModifiedSec = dateModified,
                            mimeType = mimeType,
                            detectedFormat = detectedFormat,
                            width = width,
                            height = height,
                            isSafDocument = false
                        )
                    )
                }
            }
        }
        return list
    }

    private fun scanDocumentTreeRecursive(
        docDir: DocumentFile,
        parentPath: String,
        results: LinkedHashMap<String, VideoItem>,
        maxDepth: Int
    ) {
        if (maxDepth < 0) return
        val children = runCatching { docDir.listFiles() }.getOrNull() ?: return
        val currentFolderName = docDir.name ?: parentPath.substringAfterLast('/')

        for (child in children) {
            if (child.isDirectory) {
                val childName = child.name ?: "Subfolder"
                scanDocumentTreeRecursive(
                    docDir = child,
                    parentPath = "$parentPath/$childName",
                    results = results,
                    maxDepth = maxDepth - 1
                )
            } else if (child.isFile) {
                val name = child.name ?: continue
                val mime = child.type
                if (FormatDetector.isLikelyVideoFile(context.contentResolver, child.uri, name, mime)) {
                    val uriStr = child.uri.toString()
                    if (!results.containsKey(uriStr)) {
                        val item = createVideoItemFromDocument(
                            doc = child,
                            folderName = currentFolderName,
                            folderPath = parentPath
                        )
                        results[uriStr] = item
                    }
                }
            }
        }
    }

    fun inspectSingleUri(uri: Uri): VideoItem? {
        val doc = DocumentFile.fromSingleUri(context, uri)
        if (doc != null && doc.exists()) {
            val name = doc.name ?: queryDisplayName(uri) ?: "Video.mp4"
            val mime = doc.type ?: context.contentResolver.getType(uri)
            if (FormatDetector.isLikelyVideoFile(context.contentResolver, uri, name, mime)) {
                return createVideoItemFromDocument(
                    doc = doc,
                    folderName = "Picked Videos",
                    folderPath = "SAF / Picked Videos"
                )
            }
        }

        // Fallback via ContentResolver query
        val displayName = queryDisplayName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Video.mp4"
        val mimeType = context.contentResolver.getType(uri) ?: "video/mp4"
        val sizeBytes = querySize(uri)
        val meta = extractQuickDurationAndSize(uri)
        val detectedFormat = FormatDetector.detectVideoFormat(
            contentResolver = context.contentResolver,
            uri = uri,
            displayName = displayName,
            mimeType = mimeType
        )
        val nowSec = System.currentTimeMillis() / 1000L
        return VideoItem(
            id = "uri_${uri.toString().hashCode()}",
            uriString = uri.toString(),
            title = displayName.substringBeforeLast('.'),
            displayName = displayName,
            folderName = "Device Videos",
            folderPath = "Device Videos",
            sizeBytes = sizeBytes,
            durationMs = meta.durationMs,
            dateAddedSec = nowSec,
            dateModifiedSec = nowSec,
            mimeType = mimeType,
            detectedFormat = detectedFormat,
            width = meta.width,
            height = meta.height,
            isSafDocument = true
        )
    }

    private fun createVideoItemFromDocument(
        doc: DocumentFile,
        folderName: String,
        folderPath: String
    ): VideoItem {
        val uri = doc.uri
        val displayName = doc.name ?: "Video.mp4"
        val title = displayName.substringBeforeLast('.')
        val sizeBytes = doc.length().coerceAtLeast(0L)
        val modifiedSec = (doc.lastModified() / 1000L).takeIf { it > 0 } ?: (System.currentTimeMillis() / 1000L)
        val mimeType = doc.type ?: "video/mp4"
        val quickMeta = extractQuickDurationAndSize(uri)
        val detectedFormat = FormatDetector.detectVideoFormat(
            contentResolver = context.contentResolver,
            uri = uri,
            displayName = displayName,
            mimeType = mimeType
        )
        return VideoItem(
            id = "saf_${uri.toString().hashCode()}",
            uriString = uri.toString(),
            title = title,
            displayName = displayName,
            folderName = folderName,
            folderPath = folderPath,
            sizeBytes = sizeBytes,
            durationMs = quickMeta.durationMs,
            dateAddedSec = modifiedSec,
            dateModifiedSec = modifiedSec,
            mimeType = mimeType,
            detectedFormat = detectedFormat,
            width = quickMeta.width,
            height = quickMeta.height,
            isSafDocument = true
        )
    }

    private fun scanAppDirectories(results: LinkedHashMap<String, VideoItem>) {
        val dirs = mutableListOf<File>()
        context.getExternalFilesDirs(null)?.filterNotNull()?.let { dirs.addAll(it) }
        context.filesDir?.let { dirs.add(it) }

        for (root in dirs) {
            scanFileDirectoryRecursive(root, results, maxDepth = 4)
        }
    }

    private fun scanFileDirectoryRecursive(
        dir: File,
        results: LinkedHashMap<String, VideoItem>,
        maxDepth: Int
    ) {
        if (maxDepth < 0 || !dir.exists() || !dir.isDirectory) return
        if (dir.name.startsWith(".") || dir.name == "video_thumbnails") return

        val files = dir.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                scanFileDirectoryRecursive(file, results, maxDepth - 1)
            } else if (file.isFile && file.length() > 0) {
                val ext = file.extension.lowercase()
                if (ext in FormatDetector.SUPPORTED_EXTENSIONS) {
                    val uri = Uri.fromFile(file)
                    val uriStr = uri.toString()
                    if (!results.containsKey(uriStr)) {
                        val quickMeta = extractQuickDurationAndSize(uri)
                        val format = FormatDetector.detectVideoFormat(
                            contentResolver = context.contentResolver,
                            uri = uri,
                            displayName = file.name,
                            mimeType = "video/$ext"
                        )
                        val modSec = (file.lastModified() / 1000L).coerceAtLeast(1L)
                        results[uriStr] = VideoItem(
                            id = "file_${file.absolutePath.hashCode()}",
                            uriString = uriStr,
                            title = file.nameWithoutExtension,
                            displayName = file.name,
                            folderName = file.parentFile?.name ?: "Local Videos",
                            folderPath = file.parentFile?.absolutePath ?: "Local Videos",
                            sizeBytes = file.length(),
                            durationMs = quickMeta.durationMs,
                            dateAddedSec = modSec,
                            dateModifiedSec = modSec,
                            mimeType = "video/$ext",
                            detectedFormat = format,
                            width = quickMeta.width,
                            height = quickMeta.height,
                            isSafDocument = false
                        )
                    }
                }
            }
        }
    }

    private data class QuickVideoMeta(
        val durationMs: Long = 0L,
        val width: Int = 0,
        val height: Int = 0
    )

    private fun extractQuickDurationAndSize(uri: Uri): QuickVideoMeta {
        val retriever = MediaMetadataRetriever()
        return try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
            QuickVideoMeta(durationMs = duration, width = width, height = height)
        } catch (_: Exception) {
            QuickVideoMeta()
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * Deep technical metadata inspection for the "Video Info" sheet:
     * extracts Resolution, Frame Size, FPS, Video Codec, Audio Codec, and Bitrate.
     */
    suspend fun extractDetailedTechnicalInfo(item: VideoItem): VideoItem = withContext(Dispatchers.IO) {
        val uri = Uri.parse(item.uriString)
        var duration = item.durationMs
        var width = item.width
        var height = item.height
        var bitrate = item.bitrate
        var fps = item.fps
        var videoCodec = item.videoCodec
        var audioCodec = item.audioCodec

        val retriever = MediaMetadataRetriever()
        try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: duration
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: width
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: height
            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toLongOrNull() ?: bitrate
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val frameRateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
                fps = frameRateStr?.toFloatOrNull() ?: fps
            }
        } catch (_: Exception) {
        } finally {
            runCatching { retriever.release() }
        }

        // Use MediaExtractor to inspect exact video & audio track codecs and frame rate
        val extractor = MediaExtractor()
        try {
            if (uri.scheme == "file" && uri.path != null) {
                extractor.setDataSource(uri.path!!)
            } else {
                extractor.setDataSource(context, uri, null)
            }
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoCodec = formatCodecName(mime)
                    if (width == 0 && format.containsKey(MediaFormat.KEY_WIDTH)) {
                        width = format.getInteger(MediaFormat.KEY_WIDTH)
                    }
                    if (height == 0 && format.containsKey(MediaFormat.KEY_HEIGHT)) {
                        height = format.getInteger(MediaFormat.KEY_HEIGHT)
                    }
                    if (fps <= 0f && format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = runCatching { format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                            .getOrElse {
                                runCatching { format.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrDefault(0f)
                            }
                    }
                    if (bitrate <= 0L && format.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        bitrate = format.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                    }
                } else if (mime.startsWith("audio/")) {
                    audioCodec = formatCodecName(mime)
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { extractor.release() }
        }

        val trueFormat = FormatDetector.detectVideoFormat(
            contentResolver = context.contentResolver,
            uri = uri,
            displayName = item.displayName,
            mimeType = item.mimeType
        )

        item.copy(
            durationMs = duration,
            width = width,
            height = height,
            fps = if (fps > 0f) fps else 30f,
            videoCodec = videoCodec.ifEmpty { "H.264 / AVC" },
            audioCodec = audioCodec.ifEmpty { "AAC" },
            bitrate = bitrate,
            detectedFormat = trueFormat
        )
    }

    private fun formatCodecName(mime: String): String {
        return when (mime.lowercase()) {
            "video/avc" -> "H.264 (AVC)"
            "video/hevc" -> "H.265 (HEVC)"
            "video/x-vnd.on2.vp9" -> "VP9"
            "video/x-vnd.on2.vp8" -> "VP8"
            "video/av01" -> "AV1"
            "video/mp4v-es" -> "MPEG-4 Part 2"
            "video/3gpp" -> "H.263"
            "video/mpeg2" -> "MPEG-2"
            "audio/mp4a-latm" -> "AAC"
            "audio/ac3" -> "Dolby AC-3"
            "audio/eac3" -> "Dolby Digital Plus (E-AC3)"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            "audio/mpeg" -> "MP3"
            "audio/flac" -> "FLAC"
            else -> mime.substringAfter('/')
        }
    }

    suspend fun isVideoUriAccessible(uriString: String): Boolean = withContext(Dispatchers.IO) {
        val uri = Uri.parse(uriString)
        if (uri.scheme == "file") {
            return@withContext uri.path?.let { File(it).exists() } ?: false
        }
        val doc = DocumentFile.fromSingleUri(context, uri)
        if (doc != null && doc.exists()) return@withContext true
        return@withContext try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        } catch (_: Exception) {
            false
        }
    }

    suspend fun renameVideoFile(item: VideoItem, newBaseName: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanBase = newBaseName.trim()
        if (cleanBase.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Name cannot be empty"))
        }
        val ext = item.displayName.substringAfterLast('.', "")
        val newDisplayName = if (ext.isNotEmpty() && !cleanBase.endsWith(".$ext", ignoreCase = true)) {
            "$cleanBase.$ext"
        } else {
            cleanBase
        }

        val uri = Uri.parse(item.uriString)
        try {
            if (uri.scheme == "file" && uri.path != null) {
                val file = File(uri.path!!)
                val targetFile = File(file.parentFile, newDisplayName)
                if (file.renameTo(targetFile)) {
                    return@withContext Result.success(Uri.fromFile(targetFile).toString())
                }
            }

            if (DocumentsContract.isDocumentUri(context, uri)) {
                val renamedUri = DocumentsContract.renameDocument(context.contentResolver, uri, newDisplayName)
                if (renamedUri != null) {
                    return@withContext Result.success(renamedUri.toString())
                }
            }

            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, newDisplayName)
                put(MediaStore.Video.Media.TITLE, cleanBase)
            }
            val updatedRows = context.contentResolver.update(uri, values, null, null)
            if (updatedRows > 0) {
                return@withContext Result.success(item.uriString)
            }
            // Even if the underlying OS storage provider restricts in-place file renaming,
            // return success with the same URI so our Room database stores the custom title override.
            Result.success(item.uriString)
        } catch (e: Exception) {
            // Fallback to Room custom title override if Android Scoped Storage blocks direct file rename
            Result.success(item.uriString)
        }
    }

    suspend fun deleteVideoFile(item: VideoItem): Result<Boolean> = withContext(Dispatchers.IO) {
        val uri = Uri.parse(item.uriString)
        try {
            if (uri.scheme == "file" && uri.path != null) {
                val file = File(uri.path!!)
                if (file.exists() && file.delete()) {
                    return@withContext Result.success(true)
                }
            }

            if (DocumentsContract.isDocumentUri(context, uri)) {
                val deleted = DocumentsContract.deleteDocument(context.contentResolver, uri)
                if (deleted) return@withContext Result.success(true)
            }

            val docFile = DocumentFile.fromSingleUri(context, uri)
            if (docFile != null && docFile.canWrite() && docFile.delete()) {
                return@withContext Result.success(true)
            }

            val rows = context.contentResolver.delete(uri, null, null)
            if (rows > 0) {
                return@withContext Result.success(true)
            }
            Result.failure(SecurityException("Storage provider requires system permission to delete this file."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun shareVideoFile(item: VideoItem) {
        val rawUri = Uri.parse(item.uriString)
        val shareUri = if (rawUri.scheme == "file" && rawUri.path != null) {
            runCatching {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    File(rawUri.path!!)
                )
            }.getOrDefault(rawUri)
        } else {
            rawUri
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = item.mimeType.ifEmpty { "video/*" }
            putExtra(Intent.EXTRA_STREAM, shareUri)
            putExtra(Intent.EXTRA_TITLE, item.title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, item.title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching {
            context.startActivity(chooser)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun querySize(uri: Uri): Long {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (idx >= 0) cursor.getLong(idx) else 0L
                } else 0L
            } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }
}
