package com.example.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.SortOption
import com.example.model.SortOrder
import com.example.model.SubtitleStyleConfig
import com.example.model.ThemeMode
import com.example.model.ThumbnailSize
import com.example.model.ViewMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pro_video_player_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val AUTO_PLAY_NEXT = booleanPreferencesKey("auto_play_next")
        val RESUME_PLAYBACK = booleanPreferencesKey("resume_playback")
        val SMART_RESUME_PROMPT = booleanPreferencesKey("smart_resume_prompt")
        val DEFAULT_LOOP = booleanPreferencesKey("default_loop")
        val DEFAULT_SHUFFLE = booleanPreferencesKey("default_shuffle")
        val DEFAULT_SPEED = floatPreferencesKey("default_speed")
        val DEFAULT_ASPECT_RATIO = stringPreferencesKey("default_aspect_ratio")

        val FORWARD_SEEK_SECONDS = intPreferencesKey("forward_seek_seconds")
        val BACKWARD_SEEK_SECONDS = intPreferencesKey("backward_seek_seconds")
        val ENABLE_BRIGHTNESS_GESTURE = booleanPreferencesKey("enable_brightness_gesture")
        val ENABLE_VOLUME_GESTURE = booleanPreferencesKey("enable_volume_gesture")
        val ENABLE_HORIZONTAL_SEEK = booleanPreferencesKey("enable_horizontal_seek")
        val CONTROLS_HIDE_DELAY = intPreferencesKey("controls_hide_delay")

        val SUBTITLE_ENABLED = booleanPreferencesKey("subtitle_enabled")
        val SUBTITLE_FONT_SIZE = floatPreferencesKey("subtitle_font_size")
        val SUBTITLE_TEXT_COLOR = intPreferencesKey("subtitle_text_color")
        val SUBTITLE_BG_COLOR = intPreferencesKey("subtitle_bg_color")
        val SUBTITLE_BG_OPACITY = floatPreferencesKey("subtitle_bg_opacity")
        val SUBTITLE_VERTICAL_POS = floatPreferencesKey("subtitle_vertical_pos")
        val SUBTITLE_DELAY_MS = longPreferencesKey("subtitle_delay_ms")
        val SUBTITLE_FONT_FAMILY = stringPreferencesKey("subtitle_font_family")
        val SUBTITLE_RTL_ARABIC = booleanPreferencesKey("subtitle_rtl_arabic")

        val THEME_MODE = stringPreferencesKey("theme_mode")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val THUMBNAIL_SIZE = stringPreferencesKey("thumbnail_size")
        val SORT_OPTION = stringPreferencesKey("sort_option")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val SAVE_HISTORY_ENABLED = booleanPreferencesKey("save_history_enabled")

        val BACKGROUND_AUDIO_ENABLED = booleanPreferencesKey("background_audio_enabled")
        val AUTO_PIP_ENABLED = booleanPreferencesKey("auto_pip_enabled")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            autoPlayNext = prefs[Keys.AUTO_PLAY_NEXT] ?: true,
            resumePlayback = prefs[Keys.RESUME_PLAYBACK] ?: true,
            smartResumePrompt = prefs[Keys.SMART_RESUME_PROMPT] ?: true,
            defaultLoop = prefs[Keys.DEFAULT_LOOP] ?: false,
            defaultShuffle = prefs[Keys.DEFAULT_SHUFFLE] ?: false,
            defaultPlaybackSpeed = prefs[Keys.DEFAULT_SPEED] ?: 1.0f,
            defaultAspectRatio = prefs[Keys.DEFAULT_ASPECT_RATIO]?.let {
                runCatching { AspectRatioMode.valueOf(it) }.getOrNull()
            } ?: AspectRatioMode.FIT,

            forwardSeekSeconds = prefs[Keys.FORWARD_SEEK_SECONDS] ?: 10,
            backwardSeekSeconds = prefs[Keys.BACKWARD_SEEK_SECONDS] ?: 10,
            enableBrightnessGesture = prefs[Keys.ENABLE_BRIGHTNESS_GESTURE] ?: true,
            enableVolumeGesture = prefs[Keys.ENABLE_VOLUME_GESTURE] ?: true,
            enableHorizontalSeekGesture = prefs[Keys.ENABLE_HORIZONTAL_SEEK] ?: true,
            controlsHideDelaySeconds = prefs[Keys.CONTROLS_HIDE_DELAY] ?: 4,

            subtitleConfig = SubtitleStyleConfig(
                enabled = prefs[Keys.SUBTITLE_ENABLED] ?: true,
                fontSizeSp = prefs[Keys.SUBTITLE_FONT_SIZE] ?: 20f,
                textColorArgb = prefs[Keys.SUBTITLE_TEXT_COLOR] ?: 0xFFFFFFFF.toInt(),
                backgroundColorArgb = prefs[Keys.SUBTITLE_BG_COLOR] ?: 0xFF000000.toInt(),
                backgroundOpacity = prefs[Keys.SUBTITLE_BG_OPACITY] ?: 0.65f,
                verticalPositionPercent = prefs[Keys.SUBTITLE_VERTICAL_POS] ?: 0.88f,
                delayMs = prefs[Keys.SUBTITLE_DELAY_MS] ?: 0L,
                fontFamilyName = prefs[Keys.SUBTITLE_FONT_FAMILY] ?: "Default",
                preferRtlArabic = prefs[Keys.SUBTITLE_RTL_ARABIC] ?: true
            ),

            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrNull()
            } ?: ThemeMode.DARK,
            viewMode = prefs[Keys.VIEW_MODE]?.let {
                runCatching { ViewMode.valueOf(it) }.getOrNull()
            } ?: ViewMode.GRID,
            thumbnailSize = prefs[Keys.THUMBNAIL_SIZE]?.let {
                runCatching { ThumbnailSize.valueOf(it) }.getOrNull()
            } ?: ThumbnailSize.MEDIUM,
            sortOption = prefs[Keys.SORT_OPTION]?.let {
                runCatching { SortOption.valueOf(it) }.getOrNull()
            } ?: SortOption.DATE,
            sortOrder = prefs[Keys.SORT_ORDER]?.let {
                runCatching { SortOrder.valueOf(it) }.getOrNull()
            } ?: SortOrder.DESCENDING,
            appLanguage = prefs[Keys.APP_LANGUAGE]?.let {
                runCatching { AppLanguage.valueOf(it) }.getOrNull()
            } ?: AppLanguage.ARABIC,
            saveHistoryEnabled = prefs[Keys.SAVE_HISTORY_ENABLED] ?: true,

            backgroundAudioEnabled = prefs[Keys.BACKGROUND_AUDIO_ENABLED] ?: false,
            autoPipEnabled = prefs[Keys.AUTO_PIP_ENABLED] ?: true
        )
    }

    suspend fun updatePlaybackSettings(
        autoPlayNext: Boolean? = null,
        resumePlayback: Boolean? = null,
        smartResumePrompt: Boolean? = null,
        defaultLoop: Boolean? = null,
        defaultShuffle: Boolean? = null,
        defaultSpeed: Float? = null,
        defaultAspectRatio: AspectRatioMode? = null
    ) {
        context.dataStore.edit { prefs ->
            autoPlayNext?.let { prefs[Keys.AUTO_PLAY_NEXT] = it }
            resumePlayback?.let { prefs[Keys.RESUME_PLAYBACK] = it }
            smartResumePrompt?.let { prefs[Keys.SMART_RESUME_PROMPT] = it }
            defaultLoop?.let { prefs[Keys.DEFAULT_LOOP] = it }
            defaultShuffle?.let { prefs[Keys.DEFAULT_SHUFFLE] = it }
            defaultSpeed?.let { prefs[Keys.DEFAULT_SPEED] = it }
            defaultAspectRatio?.let { prefs[Keys.DEFAULT_ASPECT_RATIO] = it.name }
        }
    }

    suspend fun updateGestureSettings(
        forwardSeekSeconds: Int? = null,
        backwardSeekSeconds: Int? = null,
        enableBrightness: Boolean? = null,
        enableVolume: Boolean? = null,
        enableHorizontalSeek: Boolean? = null,
        controlsHideDelaySeconds: Int? = null
    ) {
        context.dataStore.edit { prefs ->
            forwardSeekSeconds?.let { prefs[Keys.FORWARD_SEEK_SECONDS] = it }
            backwardSeekSeconds?.let { prefs[Keys.BACKWARD_SEEK_SECONDS] = it }
            enableBrightness?.let { prefs[Keys.ENABLE_BRIGHTNESS_GESTURE] = it }
            enableVolume?.let { prefs[Keys.ENABLE_VOLUME_GESTURE] = it }
            enableHorizontalSeek?.let { prefs[Keys.ENABLE_HORIZONTAL_SEEK] = it }
            controlsHideDelaySeconds?.let { prefs[Keys.CONTROLS_HIDE_DELAY] = it }
        }
    }

    suspend fun updateSubtitleConfig(transform: (SubtitleStyleConfig) -> SubtitleStyleConfig) {
        context.dataStore.edit { prefs ->
            val current = SubtitleStyleConfig(
                enabled = prefs[Keys.SUBTITLE_ENABLED] ?: true,
                fontSizeSp = prefs[Keys.SUBTITLE_FONT_SIZE] ?: 20f,
                textColorArgb = prefs[Keys.SUBTITLE_TEXT_COLOR] ?: 0xFFFFFFFF.toInt(),
                backgroundColorArgb = prefs[Keys.SUBTITLE_BG_COLOR] ?: 0xFF000000.toInt(),
                backgroundOpacity = prefs[Keys.SUBTITLE_BG_OPACITY] ?: 0.65f,
                verticalPositionPercent = prefs[Keys.SUBTITLE_VERTICAL_POS] ?: 0.88f,
                delayMs = prefs[Keys.SUBTITLE_DELAY_MS] ?: 0L,
                fontFamilyName = prefs[Keys.SUBTITLE_FONT_FAMILY] ?: "Default",
                preferRtlArabic = prefs[Keys.SUBTITLE_RTL_ARABIC] ?: true
            )
            val updated = transform(current)
            prefs[Keys.SUBTITLE_ENABLED] = updated.enabled
            prefs[Keys.SUBTITLE_FONT_SIZE] = updated.fontSizeSp
            prefs[Keys.SUBTITLE_TEXT_COLOR] = updated.textColorArgb
            prefs[Keys.SUBTITLE_BG_COLOR] = updated.backgroundColorArgb
            prefs[Keys.SUBTITLE_BG_OPACITY] = updated.backgroundOpacity
            prefs[Keys.SUBTITLE_VERTICAL_POS] = updated.verticalPositionPercent
            prefs[Keys.SUBTITLE_DELAY_MS] = updated.delayMs
            prefs[Keys.SUBTITLE_FONT_FAMILY] = updated.fontFamilyName
            prefs[Keys.SUBTITLE_RTL_ARABIC] = updated.preferRtlArabic
        }
    }

    suspend fun updateUiSettings(
        themeMode: ThemeMode? = null,
        viewMode: ViewMode? = null,
        thumbnailSize: ThumbnailSize? = null,
        sortOption: SortOption? = null,
        sortOrder: SortOrder? = null,
        appLanguage: AppLanguage? = null,
        saveHistoryEnabled: Boolean? = null
    ) {
        context.dataStore.edit { prefs ->
            themeMode?.let { prefs[Keys.THEME_MODE] = it.name }
            viewMode?.let { prefs[Keys.VIEW_MODE] = it.name }
            thumbnailSize?.let { prefs[Keys.THUMBNAIL_SIZE] = it.name }
            sortOption?.let { prefs[Keys.SORT_OPTION] = it.name }
            sortOrder?.let { prefs[Keys.SORT_ORDER] = it.name }
            appLanguage?.let { prefs[Keys.APP_LANGUAGE] = it.name }
            saveHistoryEnabled?.let { prefs[Keys.SAVE_HISTORY_ENABLED] = it }
        }
    }

    suspend fun updateBackgroundSettings(
        backgroundAudioEnabled: Boolean? = null,
        autoPipEnabled: Boolean? = null
    ) {
        context.dataStore.edit { prefs ->
            backgroundAudioEnabled?.let { prefs[Keys.BACKGROUND_AUDIO_ENABLED] = it }
            autoPipEnabled?.let { prefs[Keys.AUTO_PIP_ENABLED] = it }
        }
    }
}
