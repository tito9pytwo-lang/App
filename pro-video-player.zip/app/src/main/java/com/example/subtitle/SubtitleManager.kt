package com.example.subtitle

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.SubtitleCueItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.util.regex.Pattern

class SubtitleManager(private val context: Context) {

    data class LoadedSubtitleFile(
        val uriString: String,
        val displayName: String,
        val format: String,
        val cues: List<SubtitleCueItem>
    )

    suspend fun loadSubtitleFromUri(uri: Uri): Result<LoadedSubtitleFile> = withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext Result.failure(IllegalArgumentException("Unable to read subtitle file"))

            val content = decodeSubtitleBytesWithArabicSupport(bytes)
            val displayName = queryFileName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "subtitle.srt"
            val ext = displayName.substringAfterLast('.', "srt").lowercase()

            val cues = parseSubtitleContent(content, ext)
            Result.success(
                LoadedSubtitleFile(
                    uriString = uri.toString(),
                    displayName = displayName,
                    format = ext.uppercase(),
                    cues = cues
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun parseSubtitleContent(rawContent: String, extensionHint: String = "srt"): List<SubtitleCueItem> {
        val trimmed = rawContent.trimStart('\uFEFF').replace("\r\n", "\n").replace("\r", "\n")
        if (trimmed.isBlank()) return emptyList()

        return try {
            when {
                extensionHint in listOf("ass", "ssa") ||
                    trimmed.contains("[Events]", ignoreCase = true) -> parseAssOrSsa(trimmed)
                extensionHint == "vtt" ||
                    trimmed.startsWith("WEBVTT", ignoreCase = true) -> parseSrtOrVtt(trimmed)
                else -> parseSrtOrVtt(trimmed)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getActiveSubtitleText(
        cues: List<SubtitleCueItem>,
        currentPositionMs: Long,
        delayMs: Long
    ): String? {
        if (cues.isEmpty()) return null
        // Applying subtitle delay: if delayMs > 0, subtitles appear later, so we check (currentPositionMs - delayMs)
        val effectiveTimeMs = currentPositionMs - delayMs
        val activeLines = cues.filter { cue ->
            effectiveTimeMs in cue.startTimeMs..cue.endTimeMs
        }.map { it.text }

        return if (activeLines.isNotEmpty()) {
            activeLines.joinToString("\n")
        } else {
            null
        }
    }

    private fun parseSrtOrVtt(content: String): List<SubtitleCueItem> {
        val cues = mutableListOf<SubtitleCueItem>()
        val blocks = content.split(Regex("\n\\s*\n"))
        // Matches: 00:01:20,000 --> 00:01:23,500 or 01:20.000 --> 01:23.500
        val timingRegex = Pattern.compile(
            "(?:(\\d{1,2}):)?(\\d{2}):(\\d{2})[,.](\\d{3})\\s*-->\\s*(?:(\\d{1,2}):)?(\\d{2}):(\\d{2})[,.](\\d{3})"
        )

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            if (lines[0].equals("WEBVTT", ignoreCase = true) || lines[0].startsWith("NOTE")) continue

            var timingLineIndex = -1
            var startMs = 0L
            var endMs = 0L

            for (i in lines.indices) {
                val matcher = timingRegex.matcher(lines[i])
                if (matcher.find()) {
                    timingLineIndex = i
                    startMs = toMillis(
                        matcher.group(1),
                        matcher.group(2),
                        matcher.group(3),
                        matcher.group(4)
                    )
                    endMs = toMillis(
                        matcher.group(5),
                        matcher.group(6),
                        matcher.group(7),
                        matcher.group(8)
                    )
                    break
                }
            }

            if (timingLineIndex >= 0 && timingLineIndex + 1 < lines.size && endMs >= startMs) {
                val textLines = lines.subList(timingLineIndex + 1, lines.size)
                val cleanedText = cleanSubtitleTags(textLines.joinToString("\n"))
                if (cleanedText.isNotBlank()) {
                    cues.add(
                        SubtitleCueItem(
                            startTimeMs = startMs,
                            endTimeMs = endMs,
                            text = cleanedText
                        )
                    )
                }
            }
        }
        return cues.sortedBy { it.startTimeMs }
    }

    private fun parseAssOrSsa(content: String): List<SubtitleCueItem> {
        val cues = mutableListOf<SubtitleCueItem>()
        val lines = content.lines()
        var inEvents = false
        var startIdx = 1
        var endIdx = 2
        var textIdx = 9
        var totalColumns = 10

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.equals("[Events]", ignoreCase = true)) {
                inEvents = true
                continue
            }
            if (line.startsWith("[") && !line.equals("[Events]", ignoreCase = true)) {
                if (inEvents) break
            }
            if (!inEvents) continue

            if (line.startsWith("Format:", ignoreCase = true)) {
                val cols = line.substringAfter(":").split(",").map { it.trim().lowercase() }
                totalColumns = cols.size.coerceAtLeast(3)
                cols.indexOf("start").takeIf { it >= 0 }?.let { startIdx = it }
                cols.indexOf("end").takeIf { it >= 0 }?.let { endIdx = it }
                cols.indexOf("text").takeIf { it >= 0 }?.let { textIdx = it }
            } else if (line.startsWith("Dialogue:", ignoreCase = true)) {
                val payload = line.substringAfter(":").trimStart()
                val parts = payload.split(",", limit = totalColumns)
                if (parts.size > maxOf(startIdx, endIdx, textIdx)) {
                    val startMs = parseAssTimestamp(parts[startIdx].trim())
                    val endMs = parseAssTimestamp(parts[endIdx].trim())
                    val rawText = parts[textIdx]
                    val cleaned = cleanSubtitleTags(
                        rawText.replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
                    )
                    if (cleaned.isNotBlank() && endMs >= startMs) {
                        cues.add(
                            SubtitleCueItem(
                                startTimeMs = startMs,
                                endTimeMs = endMs,
                                text = cleaned
                            )
                        )
                    }
                }
            }
        }
        return cues.sortedBy { it.startTimeMs }
    }

    private fun parseAssTimestamp(ts: String): Long {
        // Format: H:MM:SS.cc (centiseconds)
        val regex = Pattern.compile("(\\d+):(\\d{2}):(\\d{2})[.:](\\d{2,3})")
        val m = regex.matcher(ts)
        if (!m.find()) return 0L
        val h = m.group(1)?.toLongOrNull() ?: 0L
        val min = m.group(2)?.toLongOrNull() ?: 0L
        val sec = m.group(3)?.toLongOrNull() ?: 0L
        val fracStr = m.group(4) ?: "0"
        val ms = if (fracStr.length == 2) (fracStr.toLongOrNull() ?: 0L) * 10L else (fracStr.toLongOrNull() ?: 0L)
        return ((h * 3600L) + (min * 60L) + sec) * 1000L + ms
    }

    private fun toMillis(hStr: String?, mStr: String?, sStr: String?, msStr: String?): Long {
        val h = hStr?.toLongOrNull() ?: 0L
        val m = mStr?.toLongOrNull() ?: 0L
        val s = sStr?.toLongOrNull() ?: 0L
        val ms = msStr?.toLongOrNull() ?: 0L
        return ((h * 3600L) + (m * 60L) + s) * 1000L + ms
    }

    private fun cleanSubtitleTags(input: String): String {
        return input
            .replace(Regex("\\{[^}]*\\}"), "") // Remove ASS override tags {\an8}, {\pos(...)}
            .replace(Regex("<[^>]*>"), "") // Remove HTML tags <i>, <b>, <font>
            .trim()
    }

    private fun decodeSubtitleBytesWithArabicSupport(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        // Check BOMs
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()
        ) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }

        // Strict UTF-8 check; if invalid UTF-8 sequences exist (common in Arabic Windows-1256 SRT files), fallback to windows-1256
        return try {
            val decoder = Charsets.UTF_8.newDecoder()
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: CharacterCodingException) {
            val arabicCharset = runCatching { Charset.forName("windows-1256") }.getOrDefault(Charsets.UTF_8)
            String(bytes, arabicCharset)
        }
    }

    private fun queryFileName(uri: Uri): String? {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
