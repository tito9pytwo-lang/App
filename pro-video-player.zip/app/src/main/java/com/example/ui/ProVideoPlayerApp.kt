package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.CreatePlaylistDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.PlaybackStatisticsDialog
import com.example.ui.components.RenameVideoDialog
import com.example.ui.components.VideoQuickActionsSheet
import com.example.ui.components.VideoTechnicalInfoDialog
import com.example.ui.localization.LocalAppStrings
import com.example.ui.screens.FavoritesAndHistoryScreen
import com.example.ui.screens.FoldersScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.ProVideoPlayerTheme
import com.example.viewmodel.MainViewModel

enum class MainNavTab {
    VIDEOS,
    FOLDERS,
    PLAYLISTS,
    FAVORITES_HISTORY,
    SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProVideoPlayerApp(
    viewModel: MainViewModel,
    onRequestPipMode: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val playerState by viewModel.playerController.uiState.collectAsStateWithLifecycle()
    val allVideos by viewModel.sortedAndFilteredVideos.collectAsStateWithLifecycle()
    val continueWatching by viewModel.continueWatchingVideos.collectAsStateWithLifecycle()
    val recentlyAdded by viewModel.recentlyAddedVideos.collectAsStateWithLifecycle()
    val historyVideos by viewModel.historyVideos.collectAsStateWithLifecycle()
    val favoriteVideos by viewModel.favoriteVideos.collectAsStateWithLifecycle()
    val folders by viewModel.folders.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val statistics by viewModel.playbackStatistics.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val selectedFolderPath by viewModel.selectedFolderPath.collectAsStateWithLifecycle()
    val selectedPlaylistId by viewModel.selectedPlaylistId.collectAsStateWithLifecycle()

    // Dialog states
    val quickActionVideo by viewModel.quickActionVideo.collectAsStateWithLifecycle()
    val videoInfoTarget by viewModel.videoInfoTarget.collectAsStateWithLifecycle()
    val renameTarget by viewModel.renameTarget.collectAsStateWithLifecycle()
    val deleteConfirmTarget by viewModel.deleteConfirmTarget.collectAsStateWithLifecycle()
    val addToPlaylistTarget by viewModel.addToPlaylistTarget.collectAsStateWithLifecycle()
    val showCreatePlaylistDialog by viewModel.showCreatePlaylistDialog.collectAsStateWithLifecycle()
    val showStatisticsDialog by viewModel.showStatisticsDialog.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(MainNavTab.VIDEOS) }
    var showHistoryInFavTab by rememberSaveable { mutableStateOf(false) }

    // SAF Launchers
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            viewModel.onSafFolderPicked(treeUri)
        }
    }

    val videoFilesPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.onVideoFilesPicked(uris, autoPlayFirst = true)
        }
    }

    val subtitleFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.playerController.loadExternalSubtitleFromUri(uri)
        }
    }

    ProVideoPlayerTheme(
        themeMode = settings.themeMode,
        appLanguage = settings.appLanguage
    ) {
        val strings = LocalAppStrings.current

        if (playerState.isPlayerOpen && playerState.currentVideo != null) {
            VideoPlayerScreen(
                playerState = playerState,
                settings = settings,
                controller = viewModel.playerController,
                onPickSubtitleFile = {
                    subtitleFilePickerLauncher.launch(arrayOf("*/*"))
                },
                onEnterPipMode = onRequestPipMode,
                onUpdateSubtitleConfig = { transform ->
                    viewModel.updateSubtitleConfig(transform)
                },
                onToggleBackgroundAudio = { enabled ->
                    viewModel.updateBackgroundSettings(backgroundAudioEnabled = enabled)
                },
                onClosePlayer = {
                    viewModel.playerController.closePlayer()
                }
            )
            return@ProVideoPlayerTheme
        }

        if (currentTab != MainNavTab.VIDEOS) {
            BackHandler {
                currentTab = MainNavTab.VIDEOS
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 640.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = CircleShape,
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.PlayCircleFilled,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = strings.appName,
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    currentTab = MainNavTab.FAVORITES_HISTORY
                                    showHistoryInFavTab = true
                                },
                                modifier = Modifier.testTag("top_bar_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = strings.navHistory
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                },
                bottomBar = {
                    Column {
                        // Mini-player bar when background audio is active and player screen is minimized
                        if (!playerState.isPlayerOpen && playerState.currentVideo != null && settings.backgroundAudioEnabled) {
                            MiniBackgroundPlayerBar(
                                title = playerState.currentVideo!!.title,
                                isPlaying = playerState.isPlaying,
                                onExpandPlayer = {
                                    viewModel.playVideo(playerState.currentVideo!!, playerState.queue)
                                },
                                onTogglePlayPause = {
                                    viewModel.playerController.togglePlayPause()
                                },
                                onStop = {
                                    viewModel.playerController.stopAndClosePlayerCompletely()
                                }
                            )
                        }

                        if (!isWideScreen) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                NavigationBarItem(
                                    selected = currentTab == MainNavTab.VIDEOS,
                                    onClick = { currentTab = MainNavTab.VIDEOS },
                                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = strings.navVideos) },
                                    label = { Text(strings.navVideos, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_videos")
                                )
                                NavigationBarItem(
                                    selected = currentTab == MainNavTab.FOLDERS,
                                    onClick = { currentTab = MainNavTab.FOLDERS },
                                    icon = { Icon(Icons.Default.Folder, contentDescription = strings.navFolders) },
                                    label = { Text(strings.navFolders, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_folders")
                                )
                                NavigationBarItem(
                                    selected = currentTab == MainNavTab.PLAYLISTS,
                                    onClick = { currentTab = MainNavTab.PLAYLISTS },
                                    icon = { Icon(Icons.AutoMirrored.Filled.PlaylistPlay, contentDescription = strings.navPlaylists) },
                                    label = { Text(strings.navPlaylists, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_playlists")
                                )
                                NavigationBarItem(
                                    selected = currentTab == MainNavTab.FAVORITES_HISTORY,
                                    onClick = { currentTab = MainNavTab.FAVORITES_HISTORY },
                                    icon = { Icon(Icons.Default.Favorite, contentDescription = strings.navFavorites) },
                                    label = { Text(strings.navFavorites, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_favorites")
                                )
                                NavigationBarItem(
                                    selected = currentTab == MainNavTab.SETTINGS,
                                    onClick = { currentTab = MainNavTab.SETTINGS },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = strings.navSettings) },
                                    label = { Text(strings.navSettings, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_settings")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isWideScreen) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            NavigationRailItem(
                                selected = currentTab == MainNavTab.VIDEOS,
                                onClick = { currentTab = MainNavTab.VIDEOS },
                                icon = { Icon(Icons.Default.VideoLibrary, contentDescription = strings.navVideos) },
                                label = { Text(strings.navVideos) }
                            )
                            NavigationRailItem(
                                selected = currentTab == MainNavTab.FOLDERS,
                                onClick = { currentTab = MainNavTab.FOLDERS },
                                icon = { Icon(Icons.Default.Folder, contentDescription = strings.navFolders) },
                                label = { Text(strings.navFolders) }
                            )
                            NavigationRailItem(
                                selected = currentTab == MainNavTab.PLAYLISTS,
                                onClick = { currentTab = MainNavTab.PLAYLISTS },
                                icon = { Icon(Icons.AutoMirrored.Filled.PlaylistPlay, contentDescription = strings.navPlaylists) },
                                label = { Text(strings.navPlaylists) }
                            )
                            NavigationRailItem(
                                selected = currentTab == MainNavTab.FAVORITES_HISTORY,
                                onClick = { currentTab = MainNavTab.FAVORITES_HISTORY },
                                icon = { Icon(Icons.Default.Favorite, contentDescription = strings.navFavorites) },
                                label = { Text(strings.navFavorites) }
                            )
                            NavigationRailItem(
                                selected = currentTab == MainNavTab.SETTINGS,
                                onClick = { currentTab = MainNavTab.SETTINGS },
                                icon = { Icon(Icons.Default.Settings, contentDescription = strings.navSettings) },
                                label = { Text(strings.navSettings) }
                            )
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        when (currentTab) {
                            MainNavTab.VIDEOS -> {
                                HomeScreen(
                                    videos = allVideos,
                                    continueWatchingVideos = continueWatching,
                                    recentlyAddedVideos = recentlyAdded,
                                    historyVideos = historyVideos,
                                    favoriteVideos = favoriteVideos,
                                    settings = settings,
                                    searchQuery = searchQuery,
                                    isScanning = isScanning,
                                    thumbnailCache = viewModel.repository.thumbnailCache,
                                    onSearchQueryChange = viewModel::setSearchQuery,
                                    onPlayVideo = { video, queue -> viewModel.playVideo(video, queue) },
                                    onLongPressVideo = viewModel::openQuickActions,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onToggleViewMode = viewModel::toggleViewMode,
                                    onUpdateSort = viewModel::updateSort,
                                    onAddFolderClick = { folderPickerLauncher.launch(null) },
                                    onPickVideosClick = {
                                        videoFilesPickerLauncher.launch(
                                            arrayOf("video/*", "application/x-matroska", "video/mp2t")
                                        )
                                    },
                                    onRescanClick = viewModel::rescanLibrary
                                )
                            }

                            MainNavTab.FOLDERS -> {
                                FoldersScreen(
                                    folders = folders,
                                    selectedFolderPath = selectedFolderPath,
                                    thumbnailSize = settings.thumbnailSize,
                                    thumbnailCache = viewModel.repository.thumbnailCache,
                                    onSelectFolder = viewModel::selectFolder,
                                    onAddFolderSaf = { folderPickerLauncher.launch(null) },
                                    onPlayVideo = { video, queue -> viewModel.playVideo(video, queue) },
                                    onLongPressVideo = viewModel::openQuickActions,
                                    onToggleFavorite = viewModel::toggleFavorite
                                )
                            }

                            MainNavTab.PLAYLISTS -> {
                                PlaylistsScreen(
                                    playlists = playlists,
                                    selectedPlaylistId = selectedPlaylistId,
                                    thumbnailCache = viewModel.repository.thumbnailCache,
                                    onSelectPlaylist = viewModel::selectPlaylist,
                                    onCreatePlaylistClick = { viewModel.setShowCreatePlaylistDialog(true) },
                                    onRenamePlaylist = viewModel::renamePlaylist,
                                    onDeletePlaylist = viewModel::deletePlaylist,
                                    onPlayPlaylist = viewModel::playPlaylist,
                                    onPlayVideoInPlaylist = { video, queue -> viewModel.playVideo(video, queue) },
                                    onMoveVideoInPlaylist = viewModel::moveVideoInPlaylist,
                                    onRemoveVideoFromPlaylist = viewModel::removeVideoFromPlaylist
                                )
                            }

                            MainNavTab.FAVORITES_HISTORY -> {
                                FavoritesAndHistoryScreen(
                                    showHistoryTab = showHistoryInFavTab,
                                    onTabChange = { showHistoryInFavTab = it },
                                    favoriteVideos = favoriteVideos,
                                    historyVideos = historyVideos,
                                    saveHistoryEnabled = settings.saveHistoryEnabled,
                                    thumbnailSize = settings.thumbnailSize,
                                    thumbnailCache = viewModel.repository.thumbnailCache,
                                    onPlayVideo = { video, queue -> viewModel.playVideo(video, queue) },
                                    onLongPressVideo = viewModel::openQuickActions,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onRemoveHistoryItem = viewModel::removeHistoryItem,
                                    onClearAllHistory = viewModel::clearAllHistory,
                                    onToggleSaveHistory = viewModel::updateSaveHistoryEnabled
                                )
                            }

                            MainNavTab.SETTINGS -> {
                                SettingsScreen(
                                    settings = settings,
                                    statistics = statistics,
                                    onShowStatisticsDialog = { viewModel.setShowStatisticsDialog(true) },
                                    onUpdateThemeMode = viewModel::updateThemeMode,
                                    onUpdateLanguage = viewModel::updateAppLanguage,
                                    onToggleViewMode = viewModel::toggleViewMode,
                                    onUpdateThumbnailSize = viewModel::updateThumbnailSize,
                                    onUpdatePlayback = viewModel::updatePlaybackSettings,
                                    onUpdateGestures = viewModel::updateGestureSettings,
                                    onUpdateSubtitles = viewModel::updateSubtitleConfig,
                                    onUpdateBackground = viewModel::updateBackgroundSettings
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Actions Sheet & Dialogs
        quickActionVideo?.let { video ->
            VideoQuickActionsSheet(
                video = video,
                onDismiss = viewModel::dismissQuickActions,
                onPlay = { viewModel.playVideo(video, allVideos) },
                onToggleFavorite = { viewModel.toggleFavorite(video) },
                onAddToPlaylist = { viewModel.openAddToPlaylistDialog(video) },
                onShare = { viewModel.shareVideo(video) },
                onRename = { viewModel.openRenameDialog(video) },
                onDelete = { viewModel.openDeleteConfirmDialog(video) },
                onShowInfo = { viewModel.openVideoInfo(video) }
            )
        }

        videoInfoTarget?.let { video ->
            VideoTechnicalInfoDialog(
                video = video,
                onDismiss = viewModel::dismissVideoInfo
            )
        }

        renameTarget?.let { video ->
            RenameVideoDialog(
                video = video,
                onDismiss = viewModel::dismissRenameDialog,
                onConfirm = { newTitle -> viewModel.confirmRenameVideo(video, newTitle) }
            )
        }

        deleteConfirmTarget?.let { video ->
            DeleteConfirmDialog(
                video = video,
                onDismiss = viewModel::dismissDeleteConfirmDialog,
                onConfirmDelete = { viewModel.confirmDeleteVideo(video) }
            )
        }

        addToPlaylistTarget?.let { video ->
            AddToPlaylistDialog(
                video = video,
                playlists = playlists,
                onDismiss = viewModel::dismissAddToPlaylistDialog,
                onSelectPlaylist = { playlistId ->
                    viewModel.addVideoToExistingPlaylist(playlistId, video.uriString)
                },
                onCreateNewPlaylist = { name ->
                    viewModel.createPlaylist(name, video.uriString)
                }
            )
        }

        if (showCreatePlaylistDialog) {
            CreatePlaylistDialog(
                onDismiss = { viewModel.setShowCreatePlaylistDialog(false) },
                onCreate = { name -> viewModel.createPlaylist(name) }
            )
        }

        if (showStatisticsDialog) {
            PlaybackStatisticsDialog(
                stats = statistics,
                onDismiss = { viewModel.setShowStatisticsDialog(false) }
            )
        }
    }
}

@Composable
private fun MiniBackgroundPlayerBar(
    title: String,
    isPlaying: Boolean,
    onExpandPlayer: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onStop: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onExpandPlayer)
            .testTag("mini_background_player_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.PlayCircleFilled,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onTogglePlayPause) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
            IconButton(onClick = onStop) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close background player",
                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}
