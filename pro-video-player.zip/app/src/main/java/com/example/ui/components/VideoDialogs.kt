package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PlaybackStatisticsSummary
import com.example.model.PlaylistWithVideos
import com.example.model.VideoItem
import com.example.ui.localization.LocalAppStrings
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoQuickActionsSheet(
    video: VideoItem,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onShowInfo: () -> Unit
) {
    val strings = LocalAppStrings.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${video.detectedFormat} • ${FormatUtils.formatFileSize(video.sizeBytes)} • ${FormatUtils.formatDuration(video.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            QuickActionRow(
                icon = Icons.Default.PlayArrow,
                label = strings.playAction,
                onClick = {
                    onDismiss()
                    onPlay()
                },
                testTag = "quick_action_play"
            )

            QuickActionRow(
                icon = if (video.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                label = if (video.isFavorite) strings.removeFromFavorites else strings.addToFavorites,
                iconTint = if (video.isFavorite) Color(0xFFFF4081) else MaterialTheme.colorScheme.primary,
                onClick = {
                    onDismiss()
                    onToggleFavorite()
                },
                testTag = "quick_action_favorite"
            )

            QuickActionRow(
                icon = Icons.AutoMirrored.Filled.PlaylistAdd,
                label = strings.addToPlaylist,
                onClick = onAddToPlaylist,
                testTag = "quick_action_playlist"
            )

            QuickActionRow(
                icon = Icons.Default.Share,
                label = strings.shareVideo,
                onClick = onShare,
                testTag = "quick_action_share"
            )

            QuickActionRow(
                icon = Icons.Default.DriveFileRenameOutline,
                label = strings.renameVideo,
                onClick = onRename,
                testTag = "quick_action_rename"
            )

            QuickActionRow(
                icon = Icons.Default.Info,
                label = strings.videoInfo,
                onClick = onShowInfo,
                testTag = "quick_action_info"
            )

            QuickActionRow(
                icon = Icons.Default.DeleteOutline,
                label = strings.deleteVideo,
                iconTint = MaterialTheme.colorScheme.error,
                textColor = MaterialTheme.colorScheme.error,
                onClick = onDelete,
                testTag = "quick_action_delete"
            )
        }
    }
}

@Composable
private fun QuickActionRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = textColor
        )
    }
}

@Composable
fun VideoTechnicalInfoDialog(
    video: VideoItem,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = strings.videoInfo,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                InfoFieldRow(strings.infoFileName, video.displayName)
                InfoFieldRow(strings.infoFolder, video.folderPath)
                InfoFieldRow(strings.infoFileSize, FormatUtils.formatFileSize(video.sizeBytes))
                InfoFieldRow(strings.infoDuration, FormatUtils.formatDuration(video.durationMs))
                InfoFieldRow(strings.infoResolution, "${video.resolutionLabel} (${video.detectedFormat})")
                InfoFieldRow(strings.infoFrameSize, video.frameSizeLabel)
                InfoFieldRow(
                    strings.infoFps,
                    if (video.fps > 0f) "${String.format(java.util.Locale.US, "%.2f", video.fps)} fps" else "30.0 fps"
                )
                InfoFieldRow(strings.infoVideoCodec, video.videoCodec.ifEmpty { "H.264 / AVC" })
                InfoFieldRow(strings.infoAudioCodec, video.audioCodec.ifEmpty { "AAC" })
                InfoFieldRow(strings.infoBitrate, FormatUtils.formatBitrate(video.bitrate))
                InfoFieldRow(strings.infoDateModified, FormatUtils.formatDateSec(video.dateModifiedSec))
                InfoFieldRow(strings.infoPlayCount, "${video.playCount}")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
private fun InfoFieldRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun RenameVideoDialog(
    video: VideoItem,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var text by remember(video) { mutableStateOf(video.title) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.renameVideo) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rename_input_field")
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(text) },
                enabled = text.isNotBlank(),
                modifier = Modifier.testTag("confirm_rename_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun DeleteConfirmDialog(
    video: VideoItem,
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    val strings = LocalAppStrings.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.deleteConfirmTitle) },
        text = {
            Text(strings.deleteConfirmMessage(video.displayName))
        },
        confirmButton = {
            Button(
                onClick = onConfirmDelete,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier.testTag("confirm_delete_button")
            ) {
                Text(strings.confirmDelete)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun AddToPlaylistDialog(
    video: VideoItem,
    playlists: List<PlaylistWithVideos>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (Long) -> Unit,
    onCreateNewPlaylist: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.addToPlaylist) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (playlists.isNotEmpty()) {
                    playlists.forEach { playlist ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectPlaylist(playlist.playlistId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = playlist.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = strings.videosCountLabel(playlist.videos.size),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                }

                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text(strings.playlistNameHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_playlist_name_input")
                )

                Button(
                    onClick = { onCreateNewPlaylist(newPlaylistName) },
                    enabled = newPlaylistName.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_and_add_playlist_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.createPlaylist)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun CreatePlaylistDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.createPlaylist) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(strings.playlistNameHint) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_playlist_input")
            )
        },
        confirmButton = {
            Button(
                onClick = { onCreate(name) },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("confirm_create_playlist_button")
            ) {
                Text(strings.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}

@Composable
fun PlaybackStatisticsDialog(
    stats: PlaybackStatisticsSummary,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = strings.playbackStatisticsTitle,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InfoFieldRow(
                    strings.totalWatchTimeLabel,
                    FormatUtils.formatWatchTimeTotal(stats.totalWatchTimeMs, strings.isArabic)
                )
                InfoFieldRow(strings.totalPlaysLabel, "${stats.totalPlayCount}")
                InfoFieldRow(strings.videosWatchedLabel, "${stats.totalVideosWatched}")
                stats.mostWatchedVideo?.let { most ->
                    InfoFieldRow(
                        if (strings.isArabic) "الأكثر مشاهدة" else "Most Watched",
                        "${most.title} (${most.playCount}x)"
                    )
                }
                stats.lastWatchedVideo?.let { last ->
                    InfoFieldRow(
                        if (strings.isArabic) "آخر فيديو تم تشغيله" else "Last Played Video",
                        "${last.title} • ${FormatUtils.formatDateTimeMillis(last.lastPlayedAt)}"
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}
