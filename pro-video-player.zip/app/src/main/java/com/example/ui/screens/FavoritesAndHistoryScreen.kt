package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.ThumbnailSize
import com.example.model.VideoItem
import com.example.scanner.ThumbnailCacheManager
import com.example.ui.components.VideoListRowCard
import com.example.ui.components.VideoThumbnailImage
import com.example.ui.localization.LocalAppStrings
import com.example.util.FormatUtils

@Composable
fun FavoritesAndHistoryScreen(
    showHistoryTab: Boolean,
    onTabChange: (Boolean) -> Unit,
    favoriteVideos: List<VideoItem>,
    historyVideos: List<VideoItem>,
    saveHistoryEnabled: Boolean,
    thumbnailSize: ThumbnailSize,
    thumbnailCache: ThumbnailCacheManager,
    onPlayVideo: (VideoItem, List<VideoItem>) -> Unit,
    onLongPressVideo: (VideoItem) -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onRemoveHistoryItem: (VideoItem) -> Unit,
    onClearAllHistory: () -> Unit,
    onToggleSaveHistory: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = !showHistoryTab,
                onClick = { onTabChange(false) },
                label = { Text("${strings.navFavorites} (${favoriteVideos.size})") },
                modifier = Modifier.testTag("tab_chip_favorites")
            )
            FilterChip(
                selected = showHistoryTab,
                onClick = { onTabChange(true) },
                label = { Text("${strings.navHistory} (${historyVideos.size})") },
                modifier = Modifier.testTag("tab_chip_history")
            )
        }

        if (!showHistoryTab) {
            if (favoriteVideos.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.emptyFavoritesText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(favoriteVideos, key = { it.uriString }) { video ->
                        VideoListRowCard(
                            video = video,
                            thumbnailSize = thumbnailSize,
                            thumbnailCache = thumbnailCache,
                            onClick = { onPlayVideo(video, favoriteVideos) },
                            onLongClick = { onLongPressVideo(video) },
                            onFavoriteToggle = { onToggleFavorite(video) }
                        )
                    }
                }
            }
        } else {
            // Watch History Tab
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = strings.pauseHistoryRecording,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                    )
                    Switch(
                        checked = saveHistoryEnabled,
                        onCheckedChange = onToggleSaveHistory,
                        modifier = Modifier.testTag("save_history_switch")
                    )
                }
            }

            if (historyVideos.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onClearAllHistory,
                        modifier = Modifier.testTag("clear_all_history_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.clearHistory)
                    }
                }
            }

            if (historyVideos.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.emptyHistoryText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(historyVideos, key = { "hist_row_${it.uriString}" }) { video ->
                        Card(
                            onClick = { onPlayVideo(video, historyVideos) },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 116.dp, height = 70.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                ) {
                                    VideoThumbnailImage(
                                        uriString = video.uriString,
                                        thumbnailCache = thumbnailCache,
                                        contentDescription = video.title,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    LinearProgressIndicator(
                                        progress = { video.watchPercentage.coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .align(Alignment.BottomCenter),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = video.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${FormatUtils.formatDuration(video.lastPositionMs)} / ${FormatUtils.formatDuration(video.durationMs)} (${(video.watchPercentage * 100).toInt()}%)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = FormatUtils.formatDateTimeMillis(video.lastPlayedAt),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(onClick = { onPlayVideo(video, historyVideos) }) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = strings.resumeAction,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                IconButton(onClick = { onRemoveHistoryItem(video) }) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove from history",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
