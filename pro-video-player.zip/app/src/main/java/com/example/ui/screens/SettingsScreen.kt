package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.PlaybackStatisticsSummary
import com.example.model.SubtitleStyleConfig
import com.example.model.ThemeMode
import com.example.model.ThumbnailSize
import com.example.model.ViewMode
import com.example.ui.localization.LocalAppStrings
import com.example.util.FormatUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    statistics: PlaybackStatisticsSummary,
    onShowStatisticsDialog: () -> Unit,
    onUpdateThemeMode: (ThemeMode) -> Unit,
    onUpdateLanguage: (AppLanguage) -> Unit,
    onToggleViewMode: () -> Unit,
    onUpdateThumbnailSize: (ThumbnailSize) -> Unit,
    onUpdatePlayback: (
        autoPlayNext: Boolean?,
        resumePlayback: Boolean?,
        smartResumePrompt: Boolean?,
        defaultLoop: Boolean?,
        defaultShuffle: Boolean?,
        defaultSpeed: Float?,
        defaultAspectRatio: AspectRatioMode?
    ) -> Unit,
    onUpdateGestures: (
        forwardSeekSeconds: Int?,
        backwardSeekSeconds: Int?,
        enableBrightness: Boolean?,
        enableVolume: Boolean?,
        enableHorizontalSeek: Boolean?,
        controlsHideDelaySeconds: Int?
    ) -> Unit,
    onUpdateSubtitles: ((SubtitleStyleConfig) -> SubtitleStyleConfig) -> Unit,
    onUpdateBackground: (backgroundAudioEnabled: Boolean?, autoPipEnabled: Boolean?) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_scroll_container")
    ) {
        // Playback Statistics Summary Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.playbackStatisticsTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${strings.totalWatchTimeLabel}: ${FormatUtils.formatWatchTimeTotal(statistics.totalWatchTimeMs, strings.isArabic)} • ${strings.totalPlaysLabel}: ${statistics.totalPlayCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    FilledTonalButton(
                        onClick = onShowStatisticsDialog,
                        modifier = Modifier.testTag("open_statistics_button")
                    ) {
                        Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // UI & Appearance Section
        item {
            SettingsCardSection(title = strings.settingsUiSection) {
                Text(
                    text = strings.settingsLanguage,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    FilterChip(
                        selected = settings.appLanguage == AppLanguage.ARABIC,
                        onClick = { onUpdateLanguage(AppLanguage.ARABIC) },
                        label = { Text("العربية (RTL)") },
                        modifier = Modifier.testTag("lang_chip_arabic")
                    )
                    FilterChip(
                        selected = settings.appLanguage == AppLanguage.ENGLISH,
                        onClick = { onUpdateLanguage(AppLanguage.ENGLISH) },
                        label = { Text("English") },
                        modifier = Modifier.testTag("lang_chip_english")
                    )
                    FilterChip(
                        selected = settings.appLanguage == AppLanguage.SYSTEM,
                        onClick = { onUpdateLanguage(AppLanguage.SYSTEM) },
                        label = { Text(strings.settingsThemeSystem) }
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = strings.settingsThemeMode,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.DARK,
                        onClick = { onUpdateThemeMode(ThemeMode.DARK) },
                        label = { Text(strings.settingsThemeDark) }
                    )
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.LIGHT,
                        onClick = { onUpdateThemeMode(ThemeMode.LIGHT) },
                        label = { Text(strings.settingsThemeLight) }
                    )
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.SYSTEM,
                        onClick = { onUpdateThemeMode(ThemeMode.SYSTEM) },
                        label = { Text(strings.settingsThemeSystem) }
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = strings.settingsThumbnailSize,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    FilterChip(
                        selected = settings.thumbnailSize == ThumbnailSize.SMALL,
                        onClick = { onUpdateThumbnailSize(ThumbnailSize.SMALL) },
                        label = { Text(strings.settingsThumbSmall) }
                    )
                    FilterChip(
                        selected = settings.thumbnailSize == ThumbnailSize.MEDIUM,
                        onClick = { onUpdateThumbnailSize(ThumbnailSize.MEDIUM) },
                        label = { Text(strings.settingsThumbMedium) }
                    )
                    FilterChip(
                        selected = settings.thumbnailSize == ThumbnailSize.LARGE,
                        onClick = { onUpdateThumbnailSize(ThumbnailSize.LARGE) },
                        label = { Text(strings.settingsThumbLarge) }
                    )
                }

                SettingsSwitchRow(
                    label = "${strings.gridView} / ${strings.listView}",
                    checked = settings.viewMode == ViewMode.GRID,
                    onCheckedChange = { onToggleViewMode() }
                )
            }
        }

        // Playback Settings Section
        item {
            SettingsCardSection(title = strings.settingsPlaybackSection) {
                SettingsSwitchRow(
                    label = strings.settingsAutoPlayNext,
                    checked = settings.autoPlayNext,
                    onCheckedChange = { onUpdatePlayback(it, null, null, null, null, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsAutoResume,
                    checked = settings.resumePlayback,
                    onCheckedChange = { onUpdatePlayback(null, it, null, null, null, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsSmartResumePrompt,
                    checked = settings.smartResumePrompt,
                    onCheckedChange = { onUpdatePlayback(null, null, it, null, null, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsDefaultLoop,
                    checked = settings.defaultLoop,
                    onCheckedChange = { onUpdatePlayback(null, null, null, it, null, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsDefaultShuffle,
                    checked = settings.defaultShuffle,
                    onCheckedChange = { onUpdatePlayback(null, null, null, null, it, null, null) }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = "${strings.settingsDefaultSpeed}: ${settings.defaultPlaybackSpeed}x",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                        FilterChip(
                            selected = settings.defaultPlaybackSpeed == spd,
                            onClick = { onUpdatePlayback(null, null, null, null, null, spd, null) },
                            label = { Text("${spd}x") }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = strings.aspectRatioTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    AspectRatioMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.defaultAspectRatio == mode,
                            onClick = { onUpdatePlayback(null, null, null, null, null, null, mode) },
                            label = { Text(if (strings.isArabic) mode.labelAr else mode.labelEn) }
                        )
                    }
                }
            }
        }

        // Gesture Settings Section
        item {
            SettingsCardSection(title = strings.settingsGesturesSection) {
                Text(
                    text = "${strings.settingsForwardDuration}: ${settings.forwardSeekSeconds}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    listOf(5, 10, 15, 30).forEach { sec ->
                        FilterChip(
                            selected = settings.forwardSeekSeconds == sec,
                            onClick = { onUpdateGestures(sec, null, null, null, null, null) },
                            label = { Text("${sec}s") }
                        )
                    }
                }

                Text(
                    text = "${strings.settingsBackwardDuration}: ${settings.backwardSeekSeconds}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    listOf(5, 10, 15, 30).forEach { sec ->
                        FilterChip(
                            selected = settings.backwardSeekSeconds == sec,
                            onClick = { onUpdateGestures(null, sec, null, null, null, null) },
                            label = { Text("${sec}s") }
                        )
                    }
                }

                SettingsSwitchRow(
                    label = strings.settingsBrightnessGesture,
                    checked = settings.enableBrightnessGesture,
                    onCheckedChange = { onUpdateGestures(null, null, it, null, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsVolumeGesture,
                    checked = settings.enableVolumeGesture,
                    onCheckedChange = { onUpdateGestures(null, null, null, it, null, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsHorizontalSeekGesture,
                    checked = settings.enableHorizontalSeekGesture,
                    onCheckedChange = { onUpdateGestures(null, null, null, null, it, null) }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = "${strings.settingsControlsHideDelay}: ${settings.controlsHideDelaySeconds}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    listOf(2, 4, 6, 8).forEach { sec ->
                        FilterChip(
                            selected = settings.controlsHideDelaySeconds == sec,
                            onClick = { onUpdateGestures(null, null, null, null, null, sec) },
                            label = { Text("${sec}s") }
                        )
                    }
                }
            }
        }

        // Subtitle Customization Section
        item {
            val sub = settings.subtitleConfig
            SettingsCardSection(title = strings.settingsSubtitleSection) {
                // Live Subtitle Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1A2234)),
                    contentAlignment = Alignment.Center
                ) {
                    val bgColor = Color(sub.backgroundColorArgb).copy(alpha = sub.backgroundOpacity)
                    val txtColor = Color(sub.textColorArgb)
                    val fontFamily = when (sub.fontFamilyName) {
                        "Serif" -> FontFamily.Serif
                        "Monospace" -> FontFamily.Monospace
                        "SansSerif" -> FontFamily.SansSerif
                        else -> FontFamily.Default
                    }
                    Surface(
                        color = bgColor,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (strings.isArabic) "معاينة نص الترجمة الاحترافية" else "Live Subtitle Style Preview",
                            color = txtColor,
                            fontSize = sub.fontSizeSp.sp,
                            fontFamily = fontFamily,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "${strings.subtitleFontSizeLabel}: ${sub.fontSizeSp.toInt()} sp",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = sub.fontSizeSp,
                    onValueChange = { sz -> onUpdateSubtitles { it.copy(fontSizeSp = sz) } },
                    valueRange = 14f..34f
                )

                Text(
                    text = "${strings.subtitleBgOpacityLabel}: ${(sub.backgroundOpacity * 100).toInt()}%",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = sub.backgroundOpacity,
                    onValueChange = { op -> onUpdateSubtitles { it.copy(backgroundOpacity = op) } },
                    valueRange = 0f..1f
                )

                Text(
                    text = strings.subtitlePositionLabel,
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = sub.verticalPositionPercent,
                    onValueChange = { pos -> onUpdateSubtitles { it.copy(verticalPositionPercent = pos) } },
                    valueRange = 0.2f..0.94f
                )

                // Subtitle Text Color Swatches
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val colors = listOf(
                        0xFFFFFFFF.toInt(), // White
                        0xFFFFEB3B.toInt(), // Yellow
                        0xFF00E5FF.toInt(), // Cyan
                        0xFF69F0AE.toInt(), // Green
                        0xFFFF80AB.toInt()  // Pink
                    )
                    colors.forEach { argb ->
                        val isSelected = sub.textColorArgb == argb
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray,
                                    shape = CircleShape
                                )
                                .clickable {
                                    onUpdateSubtitles { it.copy(textColorArgb = argb) }
                                }
                        )
                    }
                }

                // Font Family selection
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    listOf("Default", "SansSerif", "Serif", "Monospace").forEach { family ->
                        FilterChip(
                            selected = sub.fontFamilyName == family,
                            onClick = { onUpdateSubtitles { it.copy(fontFamilyName = family) } },
                            label = { Text(family) }
                        )
                    }
                }
            }
        }

        // Background & PiP Section
        item {
            SettingsCardSection(title = strings.settingsBackgroundSection) {
                SettingsSwitchRow(
                    label = strings.settingsAllowBackgroundAudio,
                    checked = settings.backgroundAudioEnabled,
                    onCheckedChange = { onUpdateBackground(it, null) }
                )
                SettingsSwitchRow(
                    label = strings.settingsAllowAutoPip,
                    checked = settings.autoPipEnabled,
                    onCheckedChange = { onUpdateBackground(null, it) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun SettingsCardSection(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
