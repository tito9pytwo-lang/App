package com.example.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.SleepTimerOption
import com.example.model.SubtitleStyleConfig
import com.example.player.PlayerUiState
import com.example.player.VideoPlayerController
import com.example.ui.localization.LocalAppStrings
import com.example.util.FormatUtils
import kotlinx.coroutines.delay
import kotlin.math.abs

private enum class ActivePlayerSheet {
    NONE,
    SUBTITLES,
    AUDIO_TRACKS,
    VIDEO_QUALITY,
    SPEED,
    SLEEP_TIMER,
    ASPECT_RATIO
}

private enum class GestureOverlayType {
    NONE,
    BRIGHTNESS,
    VOLUME,
    HORIZONTAL_SEEK,
    DOUBLE_TAP_LEFT,
    DOUBLE_TAP_RIGHT
}

@androidx.annotation.OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VideoPlayerScreen(
    playerState: PlayerUiState,
    settings: AppSettings,
    controller: VideoPlayerController,
    onPickSubtitleFile: () -> Unit,
    onEnterPipMode: () -> Unit,
    onUpdateSubtitleConfig: ((SubtitleStyleConfig) -> SubtitleStyleConfig) -> Unit,
    onToggleBackgroundAudio: (Boolean) -> Unit,
    onClosePlayer: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val activity = context as? Activity

    var controlsVisible by remember { mutableStateOf(true) }
    var lastInteractionTick by remember { mutableIntStateOf(0) }
    var activeSheet by remember { mutableStateOf(ActivePlayerSheet.NONE) }

    // Gesture feedback states
    var gestureOverlay by remember { mutableStateOf(GestureOverlayType.NONE) }
    var gestureSeekTargetMs by remember { mutableLongStateOf(0L) }
    var gestureSeekDeltaMs by remember { mutableLongStateOf(0L) }
    var doubleTapFeedbackTick by remember { mutableIntStateOf(0) }

    BackHandler {
        if (playerState.isScreenLocked) {
            controller.toggleScreenLock()
        } else if (playerState.isFullscreen) {
            controller.setFullscreen(false)
        } else {
            onClosePlayer()
        }
    }

    // Manage fullscreen system bars & keep screen on during playback
    DisposableEffect(playerState.isFullscreen, playerState.isLandscapePreferred, playerState.isOrientationLocked) {
        val window = activity?.window
        if (window != null) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)
            if (playerState.isFullscreen) {
                insetsController.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                insetsController.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
        }

        if (activity != null) {
            activity.requestedOrientation = when {
                playerState.isOrientationLocked && playerState.isLandscapePreferred ->
                    ActivityInfo.SCREEN_ORIENTATION_LOCKED
                playerState.isFullscreen && playerState.isLandscapePreferred ->
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                !playerState.isLandscapePreferred ->
                    ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }

        onDispose {
            val win = activity?.window
            if (win != null) {
                win.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                WindowCompat.getInsetsController(win, win.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Apply brightness to window when modified by gesture
    LaunchedEffect(playerState.brightnessLevel) {
        val window = activity?.window ?: return@LaunchedEffect
        val params = window.attributes
        params.screenBrightness = playerState.brightnessLevel.coerceIn(0.05f, 1.0f)
        window.attributes = params
    }

    // Auto-hide controls after configured delay
    LaunchedEffect(controlsVisible, lastInteractionTick, playerState.isPlaying, activeSheet) {
        if (controlsVisible && playerState.isPlaying && activeSheet == ActivePlayerSheet.NONE) {
            val delayMs = (settings.controlsHideDelaySeconds.coerceIn(2, 15)) * 1000L
            delay(delayMs)
            controlsVisible = false
        }
    }

    // Auto-dismiss double-tap feedback badge
    LaunchedEffect(doubleTapFeedbackTick) {
        if (doubleTapFeedbackTick > 0) {
            delay(650L)
            if (gestureOverlay == GestureOverlayType.DOUBLE_TAP_LEFT ||
                gestureOverlay == GestureOverlayType.DOUBLE_TAP_RIGHT
            ) {
                gestureOverlay = GestureOverlayType.NONE
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("video_player_root")
    ) {
        val containerWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val containerHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val containerMaxHeightDp = maxHeight.value

        // 1. Video Surface with Aspect Ratio
        val videoSurfaceModifier = when (playerState.aspectRatioMode) {
            AspectRatioMode.RATIO_16_9 -> Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .align(Alignment.Center)
            AspectRatioMode.RATIO_4_3 -> Modifier
                .fillMaxWidth()
                .aspectRatio(4f / 3f)
                .align(Alignment.Center)
            AspectRatioMode.ORIGINAL -> {
                val ratio = if (playerState.videoWidth > 0 && playerState.videoHeight > 0) {
                    playerState.videoWidth.toFloat() / playerState.videoHeight.toFloat()
                } else {
                    16f / 9f
                }
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(ratio.coerceIn(0.4f, 3.0f))
                    .align(Alignment.Center)
            }
            else -> Modifier.fillMaxSize()
        }

        val media3ResizeMode = when (playerState.aspectRatioMode) {
            AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            AspectRatioMode.FILL, AspectRatioMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            AspectRatioMode.CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AspectRatioMode.ORIGINAL,
            AspectRatioMode.RATIO_16_9,
            AspectRatioMode.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }

        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    subtitleView?.visibility = View.GONE
                    keepScreenOn = true
                    player = controller.exoPlayer
                    resizeMode = media3ResizeMode
                }
            },
            update = { view ->
                if (view.player !== controller.exoPlayer) {
                    view.player = controller.exoPlayer
                }
                view.resizeMode = media3ResizeMode
            },
            modifier = videoSurfaceModifier
        )

        // 2. Custom Subtitle Overlay (Supports SRT, VTT, ASS, SSA + Internal Tracks + Arabic RTL + Custom Style)
        val subtitleConfig = settings.subtitleConfig
        val displayedSubtitleText = playerState.activeExternalSubtitleText
            ?: playerState.activeInternalSubtitleText

        if (subtitleConfig.enabled && !displayedSubtitleText.isNullOrBlank()) {
            val topFraction = subtitleConfig.verticalPositionPercent.coerceIn(0.15f, 0.92f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                val topOffsetDp = (containerMaxHeightDp * topFraction).dp
                val bgColor = Color(subtitleConfig.backgroundColorArgb)
                    .copy(alpha = subtitleConfig.backgroundOpacity)
                val txtColor = Color(subtitleConfig.textColorArgb)
                val fontFamily = when (subtitleConfig.fontFamilyName) {
                    "Serif" -> FontFamily.Serif
                    "Monospace" -> FontFamily.Monospace
                    "SansSerif" -> FontFamily.SansSerif
                    else -> FontFamily.Default
                }

                Surface(
                    color = bgColor,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .padding(top = topOffsetDp.coerceAtMost((containerMaxHeightDp - 52f).coerceAtLeast(16f).dp))
                        .testTag("subtitle_overlay_box")
                ) {
                    Text(
                        text = displayedSubtitleText,
                        color = txtColor,
                        fontSize = subtitleConfig.fontSizeSp.sp,
                        fontFamily = fontFamily,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        lineHeight = (subtitleConfig.fontSizeSp * 1.28f).sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // If in Picture-in-Picture mode, hide all interactive touch overlays and chrome
        if (playerState.isInPipMode) {
            return@BoxWithConstraints
        }

        // 3. Multi-Zone Gesture Detector Layer
        var dragMode by remember { mutableStateOf(GestureOverlayType.NONE) }
        var initialSeekPos by remember { mutableLongStateOf(0L) }
        var accumulatedDx by remember { mutableFloatStateOf(0f) }
        var accumulatedDy by remember { mutableFloatStateOf(0f) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(
                    playerState.isScreenLocked,
                    settings.enableBrightnessGesture,
                    settings.enableVolumeGesture,
                    settings.enableHorizontalSeekGesture,
                    settings.forwardSeekSeconds,
                    settings.backwardSeekSeconds
                ) {
                    detectTapGestures(
                        onTap = {
                            controlsVisible = !controlsVisible
                            lastInteractionTick++
                        },
                        onDoubleTap = { offset ->
                            if (playerState.isScreenLocked) return@detectTapGestures
                            val xFraction = offset.x / containerWidthPx
                            when {
                                xFraction < 0.35f -> {
                                    controller.backwardByConfiguredSeconds()
                                    gestureOverlay = GestureOverlayType.DOUBLE_TAP_LEFT
                                    doubleTapFeedbackTick++
                                }
                                xFraction > 0.65f -> {
                                    controller.forwardByConfiguredSeconds()
                                    gestureOverlay = GestureOverlayType.DOUBLE_TAP_RIGHT
                                    doubleTapFeedbackTick++
                                }
                                else -> {
                                    controller.togglePlayPause()
                                }
                            }
                        }
                    )
                }
                .pointerInput(
                    playerState.isScreenLocked,
                    settings.enableBrightnessGesture,
                    settings.enableVolumeGesture,
                    settings.enableHorizontalSeekGesture
                ) {
                    if (playerState.isScreenLocked) return@pointerInput
                    detectDragGestures(
                        onDragStart = { startOffset ->
                            accumulatedDx = 0f
                            accumulatedDy = 0f
                            initialSeekPos = controller.exoPlayer.currentPosition
                            dragMode = GestureOverlayType.NONE
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            accumulatedDx += dragAmount.x
                            accumulatedDy += dragAmount.y

                            if (dragMode == GestureOverlayType.NONE) {
                                if (abs(accumulatedDx) > 24f && abs(accumulatedDx) > abs(accumulatedDy) * 1.2f) {
                                    if (settings.enableHorizontalSeekGesture) {
                                        dragMode = GestureOverlayType.HORIZONTAL_SEEK
                                        gestureOverlay = GestureOverlayType.HORIZONTAL_SEEK
                                    }
                                } else if (abs(accumulatedDy) > 24f && abs(accumulatedDy) > abs(accumulatedDx) * 1.2f) {
                                    val isLeftSide = change.position.x < (containerWidthPx * 0.5f)
                                    if (isLeftSide && settings.enableBrightnessGesture) {
                                        dragMode = GestureOverlayType.BRIGHTNESS
                                        gestureOverlay = GestureOverlayType.BRIGHTNESS
                                    } else if (!isLeftSide && settings.enableVolumeGesture) {
                                        dragMode = GestureOverlayType.VOLUME
                                        gestureOverlay = GestureOverlayType.VOLUME
                                    }
                                }
                            }

                            when (dragMode) {
                                GestureOverlayType.BRIGHTNESS -> {
                                    val delta = -dragAmount.y / (containerHeightPx * 0.75f)
                                    controller.setBrightnessLevel(playerState.brightnessLevel + delta)
                                }
                                GestureOverlayType.VOLUME -> {
                                    val delta = -dragAmount.y / (containerHeightPx * 0.75f)
                                    controller.setVolumeLevel(playerState.volumeLevel + delta)
                                }
                                GestureOverlayType.HORIZONTAL_SEEK -> {
                                    val duration = playerState.durationMs.coerceAtLeast(60_000L)
                                    val maxSwipeSeekMs = (duration * 0.35f).toLong().coerceIn(30_000L, 180_000L)
                                    val deltaMs = ((accumulatedDx / containerWidthPx) * maxSwipeSeekMs).toLong()
                                    val target = (initialSeekPos + deltaMs).coerceIn(0L, playerState.durationMs.coerceAtLeast(0L))
                                    gestureSeekDeltaMs = target - initialSeekPos
                                    gestureSeekTargetMs = target
                                }
                                else -> {}
                            }
                        },
                        onDragEnd = {
                            if (dragMode == GestureOverlayType.HORIZONTAL_SEEK) {
                                controller.seekTo(gestureSeekTargetMs)
                            }
                            dragMode = GestureOverlayType.NONE
                            gestureOverlay = GestureOverlayType.NONE
                        },
                        onDragCancel = {
                            dragMode = GestureOverlayType.NONE
                            gestureOverlay = GestureOverlayType.NONE
                        }
                    )
                }
        )

        // 4. Center Gesture OSD Indicator (Brightness, Volume, Seek, Double-Tap)
        if (gestureOverlay != GestureOverlayType.NONE) {
            Surface(
                color = Color.Black.copy(alpha = 0.78f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (gestureOverlay) {
                        GestureOverlayType.BRIGHTNESS -> {
                            Icon(Icons.Default.BrightnessMedium, contentDescription = null, tint = Color.White)
                            LinearProgressIndicator(
                                progress = { playerState.brightnessLevel.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .width(110.dp)
                                    .height(6.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${(playerState.brightnessLevel * 100).toInt()}%",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        GestureOverlayType.VOLUME -> {
                            Icon(
                                imageVector = if (playerState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = null,
                                tint = Color.White
                            )
                            LinearProgressIndicator(
                                progress = { playerState.volumeLevel.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .width(110.dp)
                                    .height(6.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${(playerState.volumeLevel * 100).toInt()}%",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        GestureOverlayType.HORIZONTAL_SEEK -> {
                            val sign = if (gestureSeekDeltaMs >= 0) "+" else "-"
                            val deltaFormatted = FormatUtils.formatDuration(abs(gestureSeekDeltaMs))
                            Text(
                                text = "${FormatUtils.formatDuration(gestureSeekTargetMs)} ($sign$deltaFormatted)",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        GestureOverlayType.DOUBLE_TAP_LEFT -> {
                            Icon(Icons.Default.FastRewind, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "-${settings.backwardSeekSeconds}s",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        GestureOverlayType.DOUBLE_TAP_RIGHT -> {
                            Icon(Icons.Default.FastForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "+${settings.forwardSeekSeconds}s",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        else -> {}
                    }
                }
            }
        }

        // 5. Buffering Spinner
        if (playerState.isBuffering && playerState.playbackError == null) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // 6. Error State Overlay ("تعذر تشغيل هذا الفيديو")
        if (playerState.playbackError != null) {
            Surface(
                color = Color(0xE6101624),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .testTag("player_error_card")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = strings.playbackErrorTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${playerState.playbackError} (${playerState.playbackErrorCodeName ?: "MEDIA_ERROR"})",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.78f),
                        textAlign = TextAlign.Center
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = onClosePlayer) {
                            Text(strings.cancel, color = Color.White)
                        }
                        Button(onClick = { controller.togglePlayPause() }) {
                            Text(strings.retryPlayback)
                        }
                    }
                }
            }
        }

        // 7. Smart Resume Floating Banner ("متابعة من 12:35")
        AnimatedVisibility(
            visible = playerState.showSmartResumeBanner,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 76.dp, start = 16.dp, end = 16.dp)
        ) {
            Surface(
                color = Color(0xE6121A2B),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("smart_resume_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = strings.smartResumeBannerText(FormatUtils.formatDuration(playerState.smartResumeTargetMs)),
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    TextButton(
                        onClick = { controller.replayFromBeginning() },
                        modifier = Modifier.testTag("smart_resume_start_over_button")
                    ) {
                        Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.startOver, color = MaterialTheme.colorScheme.primary)
                    }
                    TextButton(
                        onClick = { controller.confirmSmartResume() }
                    ) {
                        Text("OK", color = Color.White.copy(alpha = 0.8f))
                    }
                }
            }
        }

        // 8. Locked Screen Mode (Only shows Unlock button when tapped)
        if (playerState.isScreenLocked) {
            AnimatedVisibility(
                visible = controlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(24.dp)
            ) {
                Surface(
                    onClick = { controller.toggleScreenLock() },
                    color = MaterialTheme.colorScheme.primary,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(54.dp)
                        .testTag("unlock_screen_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = strings.unlockControls,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
            return@BoxWithConstraints
        }

        // 9. Full Player Controls Chrome (Top Bar, Center Transport, Bottom Seek & Quick Tools)
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.75f),
                                Color.Transparent,
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
                    .systemBarsPadding()
            ) {
                // TOP BAR
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onClosePlayer,
                        modifier = Modifier.testTag("player_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = playerState.currentVideo?.title ?: "",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${playerState.currentVideo?.resolutionLabel ?: ""} • ${playerState.aspectRatioMode.labelEn}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (playerState.sleepTimerOption != SleepTimerOption.OFF) {
                                val timerLabel = if (playerState.sleepTimerOption == SleepTimerOption.END_OF_VIDEO) {
                                    "Sleep: End"
                                } else {
                                    "Sleep: ${FormatUtils.formatDuration(playerState.sleepTimerRemainingSec * 1000L)}"
                                }
                                Text(
                                    text = "• $timerLabel",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFFB300)
                                )
                            }
                        }
                    }

                    // Top action icons: Background Audio, PiP, Subtitles, Audio Track, Quality
                    IconButton(
                        onClick = { onToggleBackgroundAudio(!settings.backgroundAudioEnabled) },
                        modifier = Modifier.testTag("player_bg_audio_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = strings.backgroundAudioToggle,
                            tint = if (settings.backgroundAudioEnabled) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }

                    IconButton(
                        onClick = onEnterPipMode,
                        modifier = Modifier.testTag("player_pip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureInPictureAlt,
                            contentDescription = strings.enterPip,
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            activeSheet = ActivePlayerSheet.SUBTITLES
                        },
                        modifier = Modifier.testTag("player_subtitles_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClosedCaption,
                            contentDescription = strings.subtitlesTitle,
                            tint = if (settings.subtitleConfig.enabled &&
                                (playerState.externalSubtitleCues.isNotEmpty() || playerState.subtitleTracks.any { it.isSelected })
                            ) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                Color.White
                            }
                        )
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            activeSheet = ActivePlayerSheet.AUDIO_TRACKS
                        },
                        modifier = Modifier.testTag("player_audio_tracks_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Audiotrack,
                            contentDescription = strings.audioTracksTitle,
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            activeSheet = ActivePlayerSheet.VIDEO_QUALITY
                        },
                        modifier = Modifier.testTag("player_quality_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HighQuality,
                            contentDescription = strings.videoQualityTitle,
                            tint = Color.White
                        )
                    }
                }

                // CENTER PLAYBACK CONTROLS
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            controller.playPreviousInQueue()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("player_prev_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            controller.backwardByConfiguredSeconds()
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("player_rewind_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Rewind",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Surface(
                        onClick = {
                            lastInteractionTick++
                            controller.togglePlayPause()
                        },
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(68.dp)
                            .testTag("player_play_pause_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            controller.forwardByConfiguredSeconds()
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("player_forward_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Fast Forward",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            lastInteractionTick++
                            controller.playNextInQueue()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("player_next_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }

                // BOTTOM CONTROLS (Seekbar, Time, and Ergonomic One-Handed Action Row)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Time & Seek Bar Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = FormatUtils.formatDuration(playerState.currentPositionMs),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = Color.White
                        )
                        Text(
                            text = "${FormatUtils.formatRemainingDuration(playerState.currentPositionMs, playerState.durationMs)} / ${FormatUtils.formatDuration(playerState.durationMs)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }

                    val totalDuration = playerState.durationMs.coerceAtLeast(1L)
                    Slider(
                        value = playerState.currentPositionMs.coerceIn(0L, totalDuration).toFloat(),
                        onValueChange = { newPos ->
                            lastInteractionTick++
                            controller.seekTo(newPos.toLong())
                        },
                        valueRange = 0f..totalDuration.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("player_seek_slider")
                    )

                    // Bottom Action Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Screen Lock
                        IconButton(
                            onClick = { controller.toggleScreenLock() },
                            modifier = Modifier.testTag("player_lock_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = strings.lockControls,
                                tint = Color.White
                            )
                        }

                        // Mute / Volume
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.toggleMute()
                            },
                            modifier = Modifier.testTag("player_mute_button")
                        ) {
                            Icon(
                                imageVector = if (playerState.isMuted) {
                                    Icons.AutoMirrored.Filled.VolumeOff
                                } else {
                                    Icons.AutoMirrored.Filled.VolumeUp
                                },
                                contentDescription = "Mute",
                                tint = if (playerState.isMuted) MaterialTheme.colorScheme.error else Color.White
                            )
                        }

                        // Playback Speed Pill
                        Surface(
                            onClick = {
                                lastInteractionTick++
                                activeSheet = ActivePlayerSheet.SPEED
                            },
                            color = Color.White.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("player_speed_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${playerState.playbackSpeed}x",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }
                        }

                        // Loop Mode
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.cycleRepeatMode()
                            },
                            modifier = Modifier.testTag("player_loop_button")
                        ) {
                            Icon(
                                imageVector = if (playerState.repeatMode == Player.REPEAT_MODE_ONE) {
                                    Icons.Default.RepeatOne
                                } else {
                                    Icons.Default.Repeat
                                },
                                contentDescription = "Repeat",
                                tint = if (playerState.repeatMode != Player.REPEAT_MODE_OFF) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    Color.White
                                }
                            )
                        }

                        // Shuffle Mode
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.toggleShuffle()
                            },
                            modifier = Modifier.testTag("player_shuffle_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shuffle,
                                contentDescription = "Shuffle",
                                tint = if (playerState.isShuffleEnabled) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    Color.White
                                }
                            )
                        }

                        // Sleep Timer
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                activeSheet = ActivePlayerSheet.SLEEP_TIMER
                            },
                            modifier = Modifier.testTag("player_sleep_timer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bedtime,
                                contentDescription = strings.sleepTimerTitle,
                                tint = if (playerState.sleepTimerOption != SleepTimerOption.OFF) {
                                    Color(0xFFFFB300)
                                } else {
                                    Color.White
                                }
                            )
                        }

                        // Aspect Ratio
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.cycleAspectRatio()
                            },
                            modifier = Modifier.testTag("player_aspect_ratio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AspectRatio,
                                contentDescription = strings.aspectRatioTitle,
                                tint = Color.White
                            )
                        }

                        // Orientation Rotate
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.toggleLandscapePortrait()
                            },
                            modifier = Modifier.testTag("player_rotate_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ScreenRotation,
                                contentDescription = "Rotate Orientation",
                                tint = Color.White
                            )
                        }

                        // Fullscreen Toggle
                        IconButton(
                            onClick = {
                                lastInteractionTick++
                                controller.toggleFullscreen()
                            },
                            modifier = Modifier.testTag("player_fullscreen_button")
                        ) {
                            Icon(
                                imageVector = if (playerState.isFullscreen) {
                                    Icons.Default.FullscreenExit
                                } else {
                                    Icons.Default.Fullscreen
                                },
                                contentDescription = "Fullscreen",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }

    // BOTTOM SHEETS FOR SUBTITLES, AUDIO TRACKS, QUALITY, SPEED, SLEEP TIMER
    when (activeSheet) {
        ActivePlayerSheet.SUBTITLES -> {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActivePlayerSheet.NONE },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val sub = settings.subtitleConfig
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.subtitlesTitle,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Switch(
                            checked = sub.enabled,
                            onCheckedChange = { enabled ->
                                onUpdateSubtitleConfig { it.copy(enabled = enabled) }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            activeSheet = ActivePlayerSheet.NONE
                            onPickSubtitleFile()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("load_external_subtitle_button")
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.loadExternalSubtitle)
                    }

                    if (playerState.externalSubtitleName != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "External: ${playerState.externalSubtitleName} (${playerState.externalSubtitleCues.size} cues)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { controller.clearExternalSubtitle() }) {
                                Text(strings.disableSubtitles)
                            }
                        }
                    }

                    if (playerState.subtitleTracks.isNotEmpty()) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Text(
                            text = "Embedded Subtitle Tracks",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(vertical = 6.dp)
                        ) {
                            FilterChip(
                                selected = playerState.subtitleTracks.none { it.isSelected },
                                onClick = { controller.selectInternalSubtitleTrack(null) },
                                label = { Text(strings.disableSubtitles) }
                            )
                            playerState.subtitleTracks.forEach { track ->
                                FilterChip(
                                    selected = track.isSelected,
                                    onClick = { controller.selectInternalSubtitleTrack(track) },
                                    label = { Text(track.label) }
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    // Subtitle Delay Control
                    Text(
                        text = "${strings.subtitleDelayLabel}: ${sub.delayMs} ms",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 6.dp)
                    ) {
                        FilledTonalButton(onClick = { onUpdateSubtitleConfig { it.copy(delayMs = it.delayMs - 500L) } }) {
                            Text("-500ms")
                        }
                        FilledTonalButton(onClick = { onUpdateSubtitleConfig { it.copy(delayMs = it.delayMs - 100L) } }) {
                            Text("-100ms")
                        }
                        OutlinedButton(onClick = { onUpdateSubtitleConfig { it.copy(delayMs = 0L) } }) {
                            Text("0ms")
                        }
                        FilledTonalButton(onClick = { onUpdateSubtitleConfig { it.copy(delayMs = it.delayMs + 100L) } }) {
                            Text("+100ms")
                        }
                        FilledTonalButton(onClick = { onUpdateSubtitleConfig { it.copy(delayMs = it.delayMs + 500L) } }) {
                            Text("+500ms")
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text("${strings.subtitleFontSizeLabel}: ${sub.fontSizeSp.toInt()} sp")
                    Slider(
                        value = sub.fontSizeSp,
                        onValueChange = { sz -> onUpdateSubtitleConfig { it.copy(fontSizeSp = sz) } },
                        valueRange = 14f..34f
                    )

                    Text("${strings.subtitleBgOpacityLabel}: ${(sub.backgroundOpacity * 100).toInt()}%")
                    Slider(
                        value = sub.backgroundOpacity,
                        onValueChange = { op -> onUpdateSubtitleConfig { it.copy(backgroundOpacity = op) } },
                        valueRange = 0f..1f
                    )

                    Text(strings.subtitlePositionLabel)
                    Slider(
                        value = sub.verticalPositionPercent,
                        onValueChange = { pos -> onUpdateSubtitleConfig { it.copy(verticalPositionPercent = pos) } },
                        valueRange = 0.2f..0.94f
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        listOf(
                            0xFFFFFFFF.toInt(),
                            0xFFFFEB3B.toInt(),
                            0xFF00E5FF.toInt(),
                            0xFF69F0AE.toInt()
                        ).forEach { argb ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb))
                                    .border(
                                        width = if (sub.textColorArgb == argb) 3.dp else 1.dp,
                                        color = if (sub.textColorArgb == argb) MaterialTheme.colorScheme.primary else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onUpdateSubtitleConfig { it.copy(textColorArgb = argb) }
                                    }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        ActivePlayerSheet.AUDIO_TRACKS -> {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActivePlayerSheet.NONE },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = strings.audioTracksTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    if (playerState.audioTracks.isEmpty()) {
                        Text(
                            text = if (strings.isArabic) "مسار صوتي افتراضي (مدمج)" else "Default Audio Track",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        playerState.audioTracks.forEach { track ->
                            FilterChip(
                                selected = track.isSelected,
                                onClick = {
                                    controller.selectAudioTrack(track)
                                    activeSheet = ActivePlayerSheet.NONE
                                },
                                label = { Text(track.label) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        ActivePlayerSheet.VIDEO_QUALITY -> {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActivePlayerSheet.NONE },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = strings.videoQualityTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FilterChip(
                        selected = playerState.selectedQualityLabel == "Auto",
                        onClick = {
                            controller.selectVideoQualityTrack(null)
                            activeSheet = ActivePlayerSheet.NONE
                        },
                        label = { Text("Auto (${playerState.currentVideo?.resolutionLabel ?: "HD"})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    playerState.videoQualityTracks.forEach { track ->
                        FilterChip(
                            selected = track.isSelected && playerState.selectedQualityLabel != "Auto",
                            onClick = {
                                controller.selectVideoQualityTrack(track)
                                activeSheet = ActivePlayerSheet.NONE
                            },
                            label = { Text(track.label) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        ActivePlayerSheet.SPEED -> {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActivePlayerSheet.NONE },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = strings.playbackSpeedTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f).forEach { spd ->
                            FilterChip(
                                selected = playerState.playbackSpeed == spd,
                                onClick = {
                                    controller.setPlaybackSpeed(spd)
                                    activeSheet = ActivePlayerSheet.NONE
                                },
                                label = { Text("${spd}x") }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        ActivePlayerSheet.SLEEP_TIMER -> {
            ModalBottomSheet(
                onDismissRequest = { activeSheet = ActivePlayerSheet.NONE },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = strings.sleepTimerTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SleepTimerOption.entries.forEach { option ->
                            val label = when (option) {
                                SleepTimerOption.OFF -> if (strings.isArabic) "إيقاف المؤقت" else "Off"
                                SleepTimerOption.END_OF_VIDEO -> if (strings.isArabic) "عند انتهاء الفيديو" else "End of Video"
                                else -> if (strings.isArabic) "${option.minutes} دقائق" else "${option.minutes} min"
                            }
                            FilterChip(
                                selected = playerState.sleepTimerOption == option,
                                onClick = {
                                    controller.setSleepTimer(option)
                                    activeSheet = ActivePlayerSheet.NONE
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        else -> {}
    }
}
