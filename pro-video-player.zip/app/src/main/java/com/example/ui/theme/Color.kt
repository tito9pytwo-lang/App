package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinema Dark Palette (Eye-friendly night viewing)
val ObsidianBackground = Color(0xFF0A0E17)
val ObsidianSurface = Color(0xFF121826)
val ObsidianSurfaceVariant = Color(0xFF1C2539)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00838F)
val ElectricViolet = Color(0xFF8C52FF)
val AmberAccent = Color(0xFFFFB300)
val TextPrimaryDark = Color(0xFFF3F6FC)
val TextSecondaryDark = Color(0xFF9BA8C2)

// Daylight Clean Palette
val DaylightBackground = Color(0xFFF5F7FB)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE6ECF5)
val CobaltPrimary = Color(0xFF006D77)
val IndigoSecondary = Color(0xFF5E35B1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
