package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.model.AppLanguage
import com.example.model.ThemeMode
import com.example.ui.localization.ArabicStrings
import com.example.ui.localization.EnglishStrings
import com.example.ui.localization.LocalAppStrings
import java.util.Locale

private val ProCinemaDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF00252B),
    primaryContainer = Color(0xFF004E59),
    onPrimaryContainer = Color(0xFFB3F7FF),
    secondary = ElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF331C6E),
    onSecondaryContainer = Color(0xFFE5D7FF),
    tertiary = Color(0xFFFFB300),
    onTertiary = Color(0xFF3A2700),
    background = ObsidianBackground,
    onBackground = TextPrimaryDark,
    surface = ObsidianSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    error = Color(0xFFFF5252),
    onError = Color.White
)

private val ProDaylightLightColorScheme = lightColorScheme(
    primary = CobaltPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFF4F9),
    onPrimaryContainer = Color(0xFF002023),
    secondary = IndigoSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE7F6),
    onSecondaryContainer = Color(0xFF1F005C),
    tertiary = Color(0xFFD97706),
    onTertiary = Color.White,
    background = DaylightBackground,
    onBackground = TextPrimaryLight,
    surface = DaylightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    error = Color(0xFFD32F2F),
    onError = Color.White
)

@Composable
fun ProVideoPlayerTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    appLanguage: AppLanguage = AppLanguage.ARABIC,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val isArabicActive = when (appLanguage) {
        AppLanguage.ARABIC -> true
        AppLanguage.ENGLISH -> false
        AppLanguage.SYSTEM -> Locale.getDefault().language.startsWith("ar", ignoreCase = true)
    }

    val strings = if (isArabicActive) ArabicStrings else EnglishStrings
    val layoutDirection = if (isArabicActive) LayoutDirection.Rtl else LayoutDirection.Ltr
    val colorScheme = if (isDark) ProCinemaDarkColorScheme else ProDaylightLightColorScheme

    CompositionLocalProvider(
        LocalAppStrings provides strings,
        LocalLayoutDirection provides layoutDirection
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
