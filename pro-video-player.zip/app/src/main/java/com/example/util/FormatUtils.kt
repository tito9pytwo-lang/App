package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

object FormatUtils {

    fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0L) return "00:00"
        val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatRemainingDuration(currentMs: Long, totalMs: Long): String {
        val remaining = (totalMs - currentMs).coerceAtLeast(0L)
        return "-${formatDuration(remaining)}"
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceIn(0, units.lastIndex)
        val value = bytes / 1024.0.pow(digitGroups.toDouble())
        return String.format(Locale.US, "%.1f %s", value, units[digitGroups])
    }

    fun formatDateSec(timestampSec: Long): String {
        if (timestampSec <= 0L) return "—"
        val millis = if (timestampSec > 100_000_000_000L) timestampSec else timestampSec * 1000L
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date(millis))
    }

    fun formatDateTimeMillis(timestampMs: Long): String {
        if (timestampMs <= 0L) return "—"
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        return sdf.format(Date(timestampMs))
    }

    fun formatBitrate(bitrateBps: Long): String {
        if (bitrateBps <= 0L) return "Variable (VBR)"
        return when {
            bitrateBps >= 1_000_000L -> String.format(Locale.US, "%.2f Mbps", bitrateBps / 1_000_000.0)
            bitrateBps >= 1_000L -> String.format(Locale.US, "%d kbps", bitrateBps / 1_000L)
            else -> "$bitrateBps bps"
        }
    }

    fun formatWatchTimeTotal(totalMs: Long, isArabic: Boolean): String {
        val totalMinutes = (totalMs / 60_000L).coerceAtLeast(0L)
        val hours = totalMinutes / 60L
        val mins = totalMinutes % 60L
        val secs = (totalMs / 1000L) % 60L
        return if (isArabic) {
            when {
                hours > 0 -> "${hours} س و ${mins} د"
                mins > 0 -> "${mins} د و ${secs} ث"
                else -> "${secs} ثانية"
            }
        } else {
            when {
                hours > 0 -> "${hours}h ${mins}m"
                mins > 0 -> "${mins}m ${secs}s"
                else -> "${secs}s"
            }
        }
    }
}
