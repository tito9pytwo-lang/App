package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.model.AppLanguage
import com.example.model.AppSettings
import com.example.model.AspectRatioMode
import com.example.model.PlaybackStatisticsSummary
import com.example.model.PlaylistWithVideos
import com.example.model.SortOption
import com.example.model.SortOrder
import com.example.model.SubtitleStyleConfig
import com.example.model.ThemeMode
import com.example.model.ThumbnailSize
import com.example.model.VideoFolder
import com.example.model.VideoItem
import com.example.model.ViewMode
import com.example.player.VideoPlayerController
import com.example.repository.VideoRepository
import com.example.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    val repository = VideoRepository(
        context = application.applicationContext,
        videoDao = database.videoDao()
    )
    val settingsRepository = SettingsRepository(application.applicationContext)
    val playerController = VideoPlayerController(
        context = application.applicationContext,
        repository = repository
    )

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    val isScanning: StateFlow<Boolean> = repository.isScanning

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFolderPath = MutableStateFlow<String?>(null)
    val selectedFolderPath: StateFlow<String?> = _selectedFolderPath.asStateFlow()

    private val _selectedPlaylistId = MutableStateFlow<Long?>(null)
    val selectedPlaylistId: StateFlow<Long?> = _selectedPlaylistId.asStateFlow()

    // Dialog / BottomSheet states
    private val _quickActionVideo = MutableStateFlow<VideoItem?>(null)
    val quickActionVideo: StateFlow<VideoItem?> = _quickActionVideo.asStateFlow()

    private val _videoInfoTarget = MutableStateFlow<VideoItem?>(null)
    val videoInfoTarget: StateFlow<VideoItem?> = _videoInfoTarget.asStateFlow()

    private val _renameTarget = MutableStateFlow<VideoItem?>(null)
    val renameTarget: StateFlow<VideoItem?> = _renameTarget.asStateFlow()

    private val _deleteConfirmTarget = MutableStateFlow<VideoItem?>(null)
    val deleteConfirmTarget: StateFlow<VideoItem?> = _deleteConfirmTarget.asStateFlow()

    private val _addToPlaylistTarget = MutableStateFlow<VideoItem?>(null)
    val addToPlaylistTarget: StateFlow<VideoItem?> = _addToPlaylistTarget.asStateFlow()

    private val _showCreatePlaylistDialog = MutableStateFlow(false)
    val showCreatePlaylistDialog: StateFlow<Boolean> = _showCreatePlaylistDialog.asStateFlow()

    private val _showStatisticsDialog = MutableStateFlow(false)
    val showStatisticsDialog: StateFlow<Boolean> = _showStatisticsDialog.asStateFlow()

    val sortedAndFilteredVideos: StateFlow<List<VideoItem>> = combine(
        repository.allVideosFlow,
        settings,
        _searchQuery
    ) { allVideos, currentSettings, query ->
        val trimmedQuery = query.trim()
        val filtered = if (trimmedQuery.isEmpty()) {
            allVideos
        } else {
            allVideos.filter { video ->
                video.title.contains(trimmedQuery, ignoreCase = true) ||
                    video.displayName.contains(trimmedQuery, ignoreCase = true) ||
                    video.folderName.contains(trimmedQuery, ignoreCase = true) ||
                    video.folderPath.contains(trimmedQuery, ignoreCase = true)
            }
        }
        sortVideos(filtered, currentSettings.sortOption, currentSettings.sortOrder)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val continueWatchingVideos: StateFlow<List<VideoItem>> = repository.allVideosFlow.combine(_searchQuery) { list, _ ->
        list.filter { it.hasResumePosition }
            .sortedByDescending { it.lastPlayedAt }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentlyAddedVideos: StateFlow<List<VideoItem>> = repository.allVideosFlow.combine(_searchQuery) { list, _ ->
        list.sortedByDescending { it.dateAddedSec }.take(12)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val historyVideos: StateFlow<List<VideoItem>> = repository.allVideosFlow.combine(_searchQuery) { list, query ->
        val q = query.trim()
        list.filter { it.lastPlayedAt > 0L }
            .filter {
                q.isEmpty() ||
                    it.title.contains(q, ignoreCase = true) ||
                    it.folderName.contains(q, ignoreCase = true)
            }
            .sortedByDescending { it.lastPlayedAt }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteVideos: StateFlow<List<VideoItem>> = combine(
        repository.allVideosFlow,
        settings,
        _searchQuery
    ) { list, currentSettings, query ->
        val q = query.trim()
        val favs = list.filter { it.isFavorite }
            .filter {
                q.isEmpty() ||
                    it.title.contains(q, ignoreCase = true) ||
                    it.folderName.contains(q, ignoreCase = true)
            }
        sortVideos(favs, currentSettings.sortOption, currentSettings.sortOrder)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val folders: StateFlow<List<VideoFolder>> = combine(
        repository.allVideosFlow,
        settings,
        _searchQuery
    ) { allVideos, currentSettings, query ->
        val q = query.trim()
        val grouped = allVideos.groupBy { it.folderPath.ifEmpty { it.folderName } }
        grouped.map { (path, videos) ->
            val sortedInside = sortVideos(videos, currentSettings.sortOption, currentSettings.sortOrder)
            val folderName = videos.firstOrNull()?.folderName ?: path.substringAfterLast('/')
            VideoFolder(
                path = path,
                name = folderName,
                videos = sortedInside,
                totalSizeBytes = videos.sumOf { it.sizeBytes },
                latestModifiedSec = videos.maxOfOrNull { it.dateModifiedSec } ?: 0L
            )
        }
            .filter { folder ->
                q.isEmpty() ||
                    folder.name.contains(q, ignoreCase = true) ||
                    folder.path.contains(q, ignoreCase = true) ||
                    folder.videos.any { it.title.contains(q, ignoreCase = true) }
            }
            .sortedBy { it.name.lowercase() }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val playlists: StateFlow<List<PlaylistWithVideos>> = repository.playlistsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val playbackStatistics: StateFlow<PlaybackStatisticsSummary> = repository.allVideosFlow.combine(settings) { list, _ ->
        val watched = list.filter { it.playCount > 0 || it.totalWatchTimeMs > 0L }
        PlaybackStatisticsSummary(
            totalVideosWatched = watched.size,
            totalPlayCount = list.sumOf { it.playCount },
            totalWatchTimeMs = list.sumOf { it.totalWatchTimeMs },
            mostWatchedVideo = watched.maxByOrNull { it.playCount },
            lastWatchedVideo = watched.maxByOrNull { it.lastPlayedAt }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PlaybackStatisticsSummary(0, 0, 0L, null, null)
    )

    init {
        viewModelScope.launch {
            settings.collect { currentSettings ->
                playerController.applySettings(currentSettings)
            }
        }
        rescanLibrary()
    }

    fun rescanLibrary() {
        viewModelScope.launch {
            repository.refreshLibrary()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFolder(folderPath: String?) {
        _selectedFolderPath.value = folderPath
    }

    fun selectPlaylist(playlistId: Long?) {
        _selectedPlaylistId.value = playlistId
    }

    fun onSafFolderPicked(treeUri: Uri) {
        viewModelScope.launch {
            repository.addSafFolder(treeUri)
        }
    }

    fun onVideoFilesPicked(uris: List<Uri>, autoPlayFirst: Boolean = false) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val added = repository.addPickedVideoUris(uris)
            if (autoPlayFirst && added.isNotEmpty()) {
                playerController.openAndPlayVideo(added.first(), added)
            }
        }
    }

    fun handleIncomingViewIntent(uri: Uri) {
        viewModelScope.launch {
            val added = repository.addPickedVideoUris(listOf(uri))
            val target = added.firstOrNull() ?: repository.scanner.inspectSingleUri(uri)
            if (target != null) {
                playerController.openAndPlayVideo(target, listOf(target))
            }
        }
    }

    fun playVideo(video: VideoItem, queue: List<VideoItem>? = null, startOver: Boolean = false) {
        val activeQueue = queue ?: sortedAndFilteredVideos.value.ifEmpty { listOf(video) }
        playerController.openAndPlayVideo(
            video = video,
            queue = activeQueue,
            forceStartFromBeginning = startOver
        )
    }

    fun playPlaylist(playlist: PlaylistWithVideos, shuffle: Boolean = false) {
        if (playlist.videos.isEmpty()) return
        val ordered = if (shuffle) playlist.videos.shuffled() else playlist.videos
        if (shuffle && !playerController.uiState.value.isShuffleEnabled) {
            playerController.toggleShuffle()
        }
        playerController.openAndPlayVideo(ordered.first(), ordered)
    }

    fun toggleFavorite(video: VideoItem) {
        viewModelScope.launch {
            repository.toggleFavorite(video)
        }
    }

    fun openQuickActions(video: VideoItem) {
        _quickActionVideo.value = video
    }

    fun dismissQuickActions() {
        _quickActionVideo.value = null
    }

    fun openVideoInfo(video: VideoItem) {
        _quickActionVideo.value = null
        _videoInfoTarget.value = video
        viewModelScope.launch(Dispatchers.IO) {
            val detailed = repository.getDetailedTechnicalInfo(video)
            if (_videoInfoTarget.value?.uriString == video.uriString) {
                _videoInfoTarget.value = detailed
            }
        }
    }

    fun dismissVideoInfo() {
        _videoInfoTarget.value = null
    }

    fun openRenameDialog(video: VideoItem) {
        _quickActionVideo.value = null
        _renameTarget.value = video
    }

    fun dismissRenameDialog() {
        _renameTarget.value = null
    }

    fun confirmRenameVideo(video: VideoItem, newTitle: String) {
        _renameTarget.value = null
        viewModelScope.launch {
            repository.renameVideo(video, newTitle)
        }
    }

    fun openDeleteConfirmDialog(video: VideoItem) {
        _quickActionVideo.value = null
        _deleteConfirmTarget.value = video
    }

    fun dismissDeleteConfirmDialog() {
        _deleteConfirmTarget.value = null
    }

    fun confirmDeleteVideo(video: VideoItem) {
        _deleteConfirmTarget.value = null
        if (playerController.uiState.value.currentVideo?.uriString == video.uriString) {
            playerController.stopAndClosePlayerCompletely()
        }
        viewModelScope.launch {
            repository.deleteVideo(video)
        }
    }

    fun shareVideo(video: VideoItem) {
        _quickActionVideo.value = null
        repository.shareVideo(video)
    }

    fun openAddToPlaylistDialog(video: VideoItem) {
        _quickActionVideo.value = null
        _addToPlaylistTarget.value = video
    }

    fun dismissAddToPlaylistDialog() {
        _addToPlaylistTarget.value = null
    }

    fun setShowCreatePlaylistDialog(show: Boolean) {
        _showCreatePlaylistDialog.value = show
    }

    fun setShowStatisticsDialog(show: Boolean) {
        _showStatisticsDialog.value = show
    }

    fun createPlaylist(name: String, initialVideoUri: String? = null) {
        _showCreatePlaylistDialog.value = false
        _addToPlaylistTarget.value = null
        viewModelScope.launch {
            repository.createPlaylist(name, initialVideoUri)
        }
    }

    fun addVideoToExistingPlaylist(playlistId: Long, videoUri: String) {
        _addToPlaylistTarget.value = null
        viewModelScope.launch {
            repository.addVideoToPlaylist(playlistId, videoUri)
        }
    }

    fun removeVideoFromPlaylist(playlistId: Long, videoUri: String) {
        viewModelScope.launch {
            repository.removeVideoFromPlaylist(playlistId, videoUri)
        }
    }

    fun moveVideoInPlaylist(playlistId: Long, fromIndex: Int, toIndex: Int) {
        viewModelScope.launch {
            repository.moveVideoInPlaylist(playlistId, fromIndex, toIndex)
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(playlistId, newName)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        if (_selectedPlaylistId.value == playlistId) {
            _selectedPlaylistId.value = null
        }
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun removeHistoryItem(video: VideoItem) {
        viewModelScope.launch {
            repository.removeHistoryItem(video.uriString)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    // Settings updates
    fun toggleViewMode() {
        val next = if (settings.value.viewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
        viewModelScope.launch {
            settingsRepository.updateUiSettings(viewMode = next)
        }
    }

    fun updateSort(option: SortOption, order: SortOrder = settings.value.sortOrder) {
        viewModelScope.launch {
            settingsRepository.updateUiSettings(sortOption = option, sortOrder = order)
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            settingsRepository.updateUiSettings(themeMode = mode)
        }
    }

    fun updateAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsRepository.updateUiSettings(appLanguage = language)
        }
    }

    fun updateThumbnailSize(size: ThumbnailSize) {
        viewModelScope.launch {
            settingsRepository.updateUiSettings(thumbnailSize = size)
        }
    }

    fun updateSaveHistoryEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateUiSettings(saveHistoryEnabled = enabled)
        }
    }

    fun updatePlaybackSettings(
        autoPlayNext: Boolean? = null,
        resumePlayback: Boolean? = null,
        smartResumePrompt: Boolean? = null,
        defaultLoop: Boolean? = null,
        defaultShuffle: Boolean? = null,
        defaultSpeed: Float? = null,
        defaultAspectRatio: AspectRatioMode? = null
    ) {
        viewModelScope.launch {
            settingsRepository.updatePlaybackSettings(
                autoPlayNext = autoPlayNext,
                resumePlayback = resumePlayback,
                smartResumePrompt = smartResumePrompt,
                defaultLoop = defaultLoop,
                defaultShuffle = defaultShuffle,
                defaultSpeed = defaultSpeed,
                defaultAspectRatio = defaultAspectRatio
            )
        }
    }

    fun updateGestureSettings(
        forwardSeekSeconds: Int? = null,
        backwardSeekSeconds: Int? = null,
        enableBrightness: Boolean? = null,
        enableVolume: Boolean? = null,
        enableHorizontalSeek: Boolean? = null,
        controlsHideDelaySeconds: Int? = null
    ) {
        viewModelScope.launch {
            settingsRepository.updateGestureSettings(
                forwardSeekSeconds = forwardSeekSeconds,
                backwardSeekSeconds = backwardSeekSeconds,
                enableBrightness = enableBrightness,
                enableVolume = enableVolume,
                enableHorizontalSeek = enableHorizontalSeek,
                controlsHideDelaySeconds = controlsHideDelaySeconds
            )
        }
    }

    fun updateSubtitleConfig(transform: (SubtitleStyleConfig) -> SubtitleStyleConfig) {
        viewModelScope.launch {
            settingsRepository.updateSubtitleConfig(transform)
        }
    }

    fun updateBackgroundSettings(
        backgroundAudioEnabled: Boolean? = null,
        autoPipEnabled: Boolean? = null
    ) {
        viewModelScope.launch {
            settingsRepository.updateBackgroundSettings(
                backgroundAudioEnabled = backgroundAudioEnabled,
                autoPipEnabled = autoPipEnabled
            )
        }
    }

    private fun sortVideos(
        videos: List<VideoItem>,
        sortOption: SortOption,
        sortOrder: SortOrder
    ): List<VideoItem> {
        val comparator: Comparator<VideoItem> = when (sortOption) {
            SortOption.NAME -> compareBy { it.title.lowercase() }
            SortOption.DATE -> compareBy { it.dateModifiedSec }
            SortOption.SIZE -> compareBy { it.sizeBytes }
            SortOption.DURATION -> compareBy { it.durationMs }
        }
        return if (sortOrder == SortOrder.ASCENDING) {
            videos.sortedWith(comparator)
        } else {
            videos.sortedWith(comparator.reversed())
        }
    }
}
