package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.database.AppDatabase
import com.example.database.PlaylistEntity
import com.example.database.PlaylistItemEntity
import com.example.database.VideoUserMetadataEntity
import com.example.subtitle.SubtitleManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var subtitleManager: SubtitleManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        subtitleManager = SubtitleManager(context)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun appName_isProVideoPlayer() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Pro Video Player", appName)
    }

    @Test
    fun subtitleManager_parsesSrtVttAssAndDelayWithArabic() {
        val srtContent = """
            1
            00:00:02,000 --> 00:00:05,500
            مرحباً بكم في مشغل الفيديو الاحترافي

            2
            00:00:06,000 --> 00:00:09,000
            <i>Second subtitle line</i>
        """.trimIndent()

        val srtCues = subtitleManager.parseSubtitleContent(srtContent, "srt")
        assertEquals(2, srtCues.size)
        assertEquals("مرحباً بكم في مشغل الفيديو الاحترافي", srtCues[0].text)
        assertEquals("Second subtitle line", srtCues[1].text)

        // Test active cue lookup with 0ms delay and +1000ms delay
        assertEquals(
            "مرحباً بكم في مشغل الفيديو الاحترافي",
            subtitleManager.getActiveSubtitleText(srtCues, currentPositionMs = 3000L, delayMs = 0L)
        )
        assertNull(
            subtitleManager.getActiveSubtitleText(srtCues, currentPositionMs = 2500L, delayMs = 1000L)
        )

        val assContent = """
            [Events]
            Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
            Dialogue: 0,0:00:10.00,0:00:14.50,Default,,0,0,0,,{\an8}ترجمة عربية بصيغة ASS\Nالسطر الثاني
        """.trimIndent()
        val assCues = subtitleManager.parseSubtitleContent(assContent, "ass")
        assertEquals(1, assCues.size)
        assertTrue(assCues[0].text.contains("ترجمة عربية بصيغة ASS"))
    }

    @Test
    fun database_persistsFavoritesHistoryAndPlaylists() = runBlocking {
        val dao = db.videoDao()
        val sampleUri = "content://media/external/video/media/101"

        // Save favorite and playback resume position
        dao.upsertMetadata(
            VideoUserMetadataEntity(
                uriString = sampleUri,
                isFavorite = true,
                lastPositionMs = 755_000L,
                durationMs = 1_510_000L,
                watchPercentage = 0.5f,
                lastPlayedAt = 1_700_000_000_000L,
                playCount = 3,
                totalWatchTimeMs = 900_000L
            )
        )

        val savedMeta = dao.getMetadataForUri(sampleUri)
        assertEquals(true, savedMeta?.isFavorite)
        assertEquals(755_000L, savedMeta?.lastPositionMs)
        assertEquals(3, savedMeta?.playCount)

        // Create playlist and reorder videos
        val playlistId = dao.insertPlaylist(PlaylistEntity(name = "Cinema Favorites"))
        dao.insertPlaylistItem(PlaylistItemEntity(playlistId, "uri_1", 0))
        dao.insertPlaylistItem(PlaylistItemEntity(playlistId, "uri_2", 1))
        dao.updatePlaylistOrder(playlistId, listOf("uri_2", "uri_1"))

        val items = dao.getPlaylistItemsSync(playlistId)
        assertEquals(2, items.size)
        assertEquals("uri_2", items[0].videoUri)
        assertEquals("uri_1", items[1].videoUri)

        // Clear history keeps favorite status intact
        dao.clearAllHistory()
        val afterClear = dao.observeAllMetadata().first().first()
        assertEquals(true, afterClear.isFavorite)
        assertEquals(0L, afterClear.lastPositionMs)
    }
}
