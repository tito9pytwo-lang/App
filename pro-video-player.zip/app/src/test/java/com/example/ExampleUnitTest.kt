package com.example

import com.example.scanner.FormatDetector
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun formatDetector_identifiesMagicBytesCorrectly() {
        // MP4 ftyp isom header
        val mp4Header = byteArrayOf(
            0x00, 0x00, 0x00, 0x18,
            'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
            'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte()
        )
        assertEquals("MP4", FormatDetector.parseMagicBytes(mp4Header))

        // MOV ftyp qt
        val movHeader = byteArrayOf(
            0x00, 0x00, 0x00, 0x14,
            'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
            'q'.code.toByte(), 't'.code.toByte(), ' '.code.toByte(), ' '.code.toByte()
        )
        assertEquals("MOV", FormatDetector.parseMagicBytes(movHeader))

        // 3GP ftyp 3gp5
        val threeGpHeader = byteArrayOf(
            0x00, 0x00, 0x00, 0x14,
            'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
            '3'.code.toByte(), 'g'.code.toByte(), 'p'.code.toByte(), '5'.code.toByte()
        )
        assertEquals("3GP", FormatDetector.parseMagicBytes(threeGpHeader))

        // MKV EBML header
        val mkvHeader = byteArrayOf(
            0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte(),
            0x93.toByte(), 0x42, 0x82.toByte(), 0x88.toByte(),
            'm'.code.toByte(), 'a'.code.toByte(), 't'.code.toByte(), 'r'.code.toByte()
        )
        assertEquals("MKV", FormatDetector.parseMagicBytes(mkvHeader))

        // WebM EBML header
        val webmHeader = byteArrayOf(
            0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte(),
            0x93.toByte(), 0x42, 0x82.toByte(), 0x88.toByte(),
            'w'.code.toByte(), 'e'.code.toByte(), 'b'.code.toByte(), 'm'.code.toByte()
        )
        assertEquals("WebM", FormatDetector.parseMagicBytes(webmHeader))

        // AVI RIFF header
        val aviHeader = byteArrayOf(
            'R'.code.toByte(), 'I'.code.toByte(), 'F'.code.toByte(), 'F'.code.toByte(),
            0x00, 0x00, 0x00, 0x00,
            'A'.code.toByte(), 'V'.code.toByte(), 'I'.code.toByte(), ' '.code.toByte()
        )
        assertEquals("AVI", FormatDetector.parseMagicBytes(aviHeader))
    }

    @Test
    fun formatUtils_formatsDurationAndSizeAccurately() {
        assertEquals("00:00", FormatUtils.formatDuration(0L))
        assertEquals("12:35", FormatUtils.formatDuration(755_000L))
        assertEquals("01:05:09", FormatUtils.formatDuration(3_909_000L))
        assertEquals("-02:00", FormatUtils.formatRemainingDuration(60_000L, 180_000L))
        assertEquals("1.0 MB", FormatUtils.formatFileSize(1024L * 1024L))
    }
}
