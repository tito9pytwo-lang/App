package com.example.data.api

import com.example.data.model.RecitersResponse
import com.example.data.model.SurahResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface QuranApi {
    @GET("https://mp3quran.net/api/v3/reciters")
    suspend fun getReciters(@Query("language") language: String = "ar"): RecitersResponse

    @GET("https://api.alquran.cloud/v1/surah")
    suspend fun getSurahs(): SurahResponse
}
