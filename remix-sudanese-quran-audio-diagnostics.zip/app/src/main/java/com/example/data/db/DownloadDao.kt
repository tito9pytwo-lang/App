package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloaded_surahs ORDER BY downloadDate DESC")
    fun getAllDownloads(): Flow<List<DownloadedSurah>>

    @Query("SELECT * FROM downloaded_surahs WHERE id = :id")
    suspend fun getDownloadById(id: String): DownloadedSurah?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(surah: DownloadedSurah)

    @Delete
    suspend fun deleteDownload(surah: DownloadedSurah)

    @Query("DELETE FROM downloaded_surahs WHERE id = :id")
    suspend fun deleteDownloadById(id: String)
}
