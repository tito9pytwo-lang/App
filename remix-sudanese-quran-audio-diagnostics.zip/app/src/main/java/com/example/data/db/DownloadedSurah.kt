package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_surahs")
data class DownloadedSurah(
    @PrimaryKey val id: String, // Combination of reciterId and surahNumber
    val reciterId: Int,
    val reciterName: String,
    val surahNumber: Int,
    val surahName: String,
    val localPath: String,
    val serverUrl: String,
    val downloadDate: Long = System.currentTimeMillis()
)
