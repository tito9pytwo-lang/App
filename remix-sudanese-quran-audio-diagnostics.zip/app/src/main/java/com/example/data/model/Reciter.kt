package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class RecitersResponse(
    @Json(name = "reciters") val reciters: List<Reciter>
)

@JsonClass(generateAdapter = true)
data class Reciter(
    @Json(name = "id") val id: Int,
    @Json(name = "name") val name: String,
    @Json(name = "letter") val letter: String,
    @Json(name = "moshaf") val moshaf: List<Moshaf>
)

@JsonClass(generateAdapter = true)
data class Moshaf(
    @Json(name = "id") val id: Int,
    @Json(name = "name") val name: String,
    @Json(name = "server") val server: String,
    @Json(name = "surah_total") val surahTotal: Int,
    @Json(name = "moshaf_type") val moshafType: Int,
    @Json(name = "surah_list") val surahList: String
)
