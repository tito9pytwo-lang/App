package com.example.data.repository

import com.example.data.api.QuranApi
import com.example.data.db.DownloadDao
import com.example.data.db.DownloadedSurah
import com.example.data.model.Reciter
import com.example.data.model.Surah
import kotlinx.coroutines.flow.Flow

class QuranRepository(
    private val api: QuranApi,
    private val downloadDao: DownloadDao
) {
    suspend fun getReciters(): List<Reciter> {
        return try {
            val response = api.getReciters()
            response.reciters
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getSurahs(): List<Surah> {
        return try {
            val response = api.getSurahs()
            response.data
        } catch (e: Exception) {
            emptyList()
        }
    }

    val allDownloads: Flow<List<DownloadedSurah>> = downloadDao.getAllDownloads()

    suspend fun isDownloaded(reciterId: Int, surahNumber: Int): Boolean {
        return downloadDao.getDownloadById("${reciterId}_$surahNumber") != null
    }

    suspend fun getDownloadedPath(reciterId: Int, surahNumber: Int): String? {
        return downloadDao.getDownloadById("${reciterId}_$surahNumber")?.localPath
    }

    suspend fun saveDownload(surah: DownloadedSurah) {
        downloadDao.insertDownload(surah)
    }

    suspend fun deleteDownload(id: String) {
        downloadDao.deleteDownloadById(id)
    }
    
    // Sudanese Reciters
    val sudaneseReciters = listOf(
        "نورين محمد صديق",
        "الزين محمد أحمد",
        "الفاتح محمد الزبير",
        "محمد عبد الكريم",
        "عبد الرشيد صوفي",
        "الهادي كنونة",
        "محمد سيد",
        "عوض عمر",
        "صديق أحمد حمدون",
        "محمد الطيب حمدان",
        "عبد اللطيف العوض",
        "أحمد جبارة",
        "الشيخ الزين",
        "إبراهيم الكرار",
        "يوسف منصور",
        "طه الفشني", // some Sudanese also listen to him
        "حسن عوض الكريم",
        "محمد أحمد بسيوني", // popular in Sudan
        "فيصل محمد جاد الله",
        "عصام كمال",
        "محمود علي البنا", // popular
        "جعفر محمد عثمان",
        "محي الدين الكردي",
        "عفيف محمد تاج",
        "محمد تاج عفيف",
        "عفيفي",
        "عفيف",
        "محمد تاج",
        "عفيف محمد"
    )

    // Egyptian Reciters
    val egyptianReciters = listOf(
        "الحصري",
        "عبد الباسط",
        "المنشاوي",
        "مصطفى إسماعيل",
        "البنا",
        "الطبلاوي",
        "محمد رفعت",
        "محمود شاهات",
        "الشحات محمد أنور",
        "أبو العينين شعيشع",
        "محمد محمود الطبلاوي",
        "محمود علي البنا",
        "محمود خليل الحصري",
        "محمد صديق المنشاوي",
        "عبد الفتاح الشعشاعي",
        "طه الفشني",
        "كامل يوسف البهتيمي",
        "أحمد نعينع",
        "عبد العزيز حصان",
        "محمد بدوي",
        "السيد متولي",
        "عنتر مسلم",
        "محمود الصعيدي"
    )

    // Saudi Reciters
    val saudiReciters = listOf(
        "السديس",
        "الشريم",
        "ماهر المعيقلي",
        "ياسر الدوسري",
        "بندر بليلة",
        "ناصر القطامي",
        "علي الحذيفي",
        "محمد أيوب",
        "عبد الله الجهني",
        "سعود الشريم",
        "عبد الرحمن السديس",
        "عبد الباري الثبيتي",
        "صلاح البدير",
        "أحمد الحواشي",
        "خالد القحطاني",
        "محمد اللحيدان",
        "صالح الهبدان",
        "عبد الودود حنيف",
        "أحمد بن علي العجمي",
        "سعد الغامدي",
        "عبد العزيز الأحمد",
        "خالد الغامدي",
        "عماد زهير حافظ"
    )

    // Arabic / Others
    val otherPopularReciters = listOf(
        "أحمد العجمي",
        "سعد الغامدي",
        "مشاري العفاسي",
        "فارس عباد",
        "أبو بكر الشاطري",
        "إدريس أبكر",
        "منصور السالمي",
        "هزاع البلوشي",
        "صلاح الهاشم",
        "وديع اليمني",
        "سلمان العتيبي",
        "نبيل الرفاعي",
        "سهل ياسين",
        "هاني الرفاعي",
        "توفيق الصايغ",
        "إبراهيم الجبرين",
        "محمد المقيط",
        "عبد الولي الأركاني",
        "شيرزاد عبد الرحمن",
        "جمال شاكر عبد الله"
    )
}
