package com.example.service

import android.app.PendingIntent
import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.ui.PlaybackDiagnostics

class PlaybackService : MediaSessionService() {
    companion object {
        private const val TAG = "PlaybackService"
    }

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        try {
            val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent("SudaneseQuran/1.0")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(30_000)

            val mediaSourceFactory = DefaultMediaSourceFactory(httpDataSourceFactory)

            val audioAttributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build()

            val player = ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .setAudioAttributes(audioAttributes, true)
                .setHandleAudioBecomingNoisy(true)
                .build()

            player.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val uri = player.currentMediaItem?.localConfiguration?.uri?.toString()
                    val cause = error.cause
                    val causeText = cause?.let {
                        "${it.javaClass.simpleName}: ${it.message ?: "بدون تفاصيل"}"
                    }

                    Log.e(
                        TAG,
                        "AUDIO_ERROR code=${error.errorCode} message=${error.message} uri=$uri cause=$causeText",
                        error
                    )

                    PlaybackDiagnostics.show(
                        title = "فشل تشغيل الصوت",
                        message = error.message ?: "حدث خطأ أثناء تحميل ملف الصوت.",
                        uri = uri,
                        code = error.errorCode,
                        cause = causeText
                    )
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    Log.d(
                        TAG,
                        "Playback state=$playbackState uri=${player.currentMediaItem?.localConfiguration?.uri}"
                    )
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    Log.d(TAG, "isPlaying=$isPlaying")
                }
            })

            val intent = packageManager.getLaunchIntentForPackage(packageName)
            val pendingIntent = intent?.let {
                PendingIntent.getActivity(
                    this,
                    0,
                    it,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }

            mediaSession = MediaSession.Builder(this, player).apply {
                pendingIntent?.let { setSessionActivity(it) }
            }.build()

            Log.d(TAG, "PlaybackService created successfully")
        } catch (t: Throwable) {
            val message = t.message ?: t.javaClass.simpleName
            Log.e(TAG, "PlaybackService initialization failed: $message", t)
            PlaybackDiagnostics.show(
                title = "فشل تهيئة الصوت",
                message = "تعذر إنشاء مشغل الصوت داخل التطبيق.",
                cause = "${t.javaClass.simpleName}: $message"
            )
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val player = mediaSession?.player
        if (player != null && (!player.playWhenReady || player.mediaItemCount == 0)) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
        Log.d(TAG, "PlaybackService destroyed")
    }
}
