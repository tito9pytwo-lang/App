package com.example.ui

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Shared in-app diagnostics for audio playback. */
object PlaybackDiagnostics {
    data class ErrorInfo(
        val title: String,
        val message: String,
        val uri: String? = null,
        val code: Int? = null,
        val cause: String? = null
    )

    private val _error = MutableStateFlow<ErrorInfo?>(null)
    val error: StateFlow<ErrorInfo?> = _error.asStateFlow()

    fun show(
        title: String,
        message: String,
        uri: String? = null,
        code: Int? = null,
        cause: String? = null
    ) {
        _error.value = ErrorInfo(title, message, uri, code, cause)
    }

    fun clear() {
        _error.value = null
    }
}
