package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.session.MediaController

@Composable
fun MiniPlayer(controller: MediaController) {
    var isPlaying by remember { mutableStateOf(controller.isPlaying) }
    var currentTitle by remember { mutableStateOf(controller.currentMediaItem?.mediaMetadata?.title?.toString() ?: "") }
    var currentArtist by remember { mutableStateOf(controller.currentMediaItem?.mediaMetadata?.artist?.toString() ?: "") }
    var position by remember { mutableLongStateOf(controller.currentPosition) }
    var duration by remember { mutableLongStateOf(controller.duration) }
    var isBuffering by remember { mutableStateOf(controller.playbackState == androidx.media3.common.Player.STATE_BUFFERING) }

    val listener = remember {
        object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
            override fun onMediaMetadataChanged(metadata: androidx.media3.common.MediaMetadata) {
                currentTitle = metadata.title?.toString() ?: ""
                currentArtist = metadata.artist?.toString() ?: ""
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = if (playbackState == androidx.media3.common.Player.STATE_READY) controller.duration else 0L
                isBuffering = playbackState == androidx.media3.common.Player.STATE_BUFFERING
            }
        }
    }

    LaunchedEffect(controller, isPlaying) {
        while (isPlaying) {
            position = controller.currentPosition
            duration = controller.duration
            kotlinx.coroutines.delay(1000)
        }
    }

    DisposableEffect(controller) {
        controller.addListener(listener)
        isPlaying = controller.isPlaying
        currentTitle = controller.currentMediaItem?.mediaMetadata?.title?.toString() ?: ""
        currentArtist = controller.currentMediaItem?.mediaMetadata?.artist?.toString() ?: ""
        onDispose {
            controller.removeListener(listener)
        }
    }

    Surface(
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(
                        text = if (currentTitle.isNotEmpty()) currentTitle else "Not Playing",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1
                    )
                    Text(
                        text = currentArtist,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
                IconButton(onClick = {
                    if (isPlaying) controller.pause() else controller.play()
                }) {
                    if (isBuffering) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play"
                        )
                    }
                }
            }

            if (duration > 0 || position > 0) {
                val safeDuration = if (duration > 0) duration else position + 1 // Fallback
                Slider(
                    value = position.toFloat(),
                    onValueChange = { 
                        position = it.toLong()
                        controller.seekTo(it.toLong())
                    },
                    valueRange = 0f..safeDuration.toFloat(),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatTime(position), fontSize = 10.sp)
                    Text(formatTime(duration.coerceAtLeast(0)), fontSize = 10.sp)
                }
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
