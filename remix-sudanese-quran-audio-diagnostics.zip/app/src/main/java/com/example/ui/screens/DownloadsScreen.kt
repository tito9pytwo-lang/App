package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.example.ui.QuranViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.rememberMediaController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(viewModel: QuranViewModel) {
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val mediaController by rememberMediaController()

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("المحفوظات", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        if (downloads.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد سور محفوظة")
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(downloads) { download ->
                    ListItem(
                        headlineContent = { Text(download.surahName, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text(download.reciterName) },
                        trailingContent = {
                            Row {
                                IconButton(onClick = {
                                    viewModel.deleteDownload(download.id)
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف")
                                }
                                IconButton(onClick = {
                                    val startIndex = downloads.indexOf(download)
                                    val playlist = downloads.drop(startIndex).map { d ->
                                        val uri = android.net.Uri.fromFile(java.io.File(d.localPath)).toString()
                                        MediaItem.Builder()
                                            .setUri(uri)
                                            .setMediaMetadata(
                                                MediaMetadata.Builder()
                                                    .setTitle(d.surahName)
                                                    .setArtist(d.reciterName)
                                                    .build()
                                            )
                                            .build()
                                    }
                                    mediaController?.setMediaItems(playlist)
                                    mediaController?.prepare()
                                    mediaController?.play()
                                }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                                }
                            }
                        }
                    )
                }
            }
        }
        
        mediaController?.let { controller ->
            com.example.ui.components.MiniPlayer(controller)
        }
    }
}
