package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.QuranViewModel
import kotlinx.serialization.Serializable

@Serializable
object ReciterListRoute

@Serializable
object DownloadsRoute

@Serializable
data class SurahListRoute(val reciterId: Int)

@Composable
fun MainScreen(viewModel: QuranViewModel) {
    val navController = rememberNavController()
    var currentRoute by remember { mutableStateOf<Any>(ReciterListRoute) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentRoute == ReciterListRoute,
                    onClick = {
                        currentRoute = ReciterListRoute
                        navController.navigate(ReciterListRoute) {
                            popUpTo(ReciterListRoute) { inclusive = false }
                        }
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = "القراء") },
                    label = { Text("القراء") }
                )
                NavigationBarItem(
                    selected = currentRoute == DownloadsRoute,
                    onClick = {
                        currentRoute = DownloadsRoute
                        navController.navigate(DownloadsRoute) {
                            popUpTo(ReciterListRoute) { inclusive = false }
                        }
                    },
                    icon = { Icon(Icons.Default.List, contentDescription = "المحفوظات") },
                    label = { Text("المحفوظات") }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ReciterListRoute,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable<ReciterListRoute> {
                ReciterListScreen(
                    viewModel = viewModel,
                    onReciterClick = { reciter ->
                        viewModel.selectReciter(reciter)
                        navController.navigate(SurahListRoute(reciter.id))
                    }
                )
            }
            composable<SurahListRoute> {
                SurahListScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable<DownloadsRoute> {
                DownloadsScreen(viewModel = viewModel)
            }
        }
    }
}
