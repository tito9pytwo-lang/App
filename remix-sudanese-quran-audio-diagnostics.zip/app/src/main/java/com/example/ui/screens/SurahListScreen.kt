package com.example.ui.screens

import android.net.Uri
import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontFamily
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import com.example.data.model.Surah
import com.example.ui.PlaybackDiagnostics
import com.example.ui.QuranViewModel
import com.example.ui.rememberMediaController

private const val TAG = "SurahListScreen"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahListScreen(
    viewModel: QuranViewModel,
    onBack: () -> Unit
) {
    val reciter by viewModel.selectedReciter.collectAsState()
    val surahs by viewModel.surahs.collectAsState()
    val isSurahsLoading by viewModel.isSurahsLoading.collectAsState()
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val mediaController by rememberMediaController()
    val playbackError by PlaybackDiagnostics.error.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(reciter?.name ?: "السور", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            mediaController?.let { controller ->
                com.example.ui.components.MiniPlayer(controller)
            }
        }
    ) { innerPadding ->
        if (reciter == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لم يتم اختيار قارئ")
            }
        } else if (isSurahsLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val moshaf = reciter!!.moshaf.firstOrNull()
            val availableSurahs = moshaf?.surahList
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?.toSet()
                ?: emptySet()

            val filteredSurahs = surahs.filter { it.number in availableSurahs }

            if (moshaf == null || moshaf.server.isBlank()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا يوجد رابط صوت صالح لهذا القارئ")
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    playbackError?.let { error ->
                        AudioErrorCard(
                            error = error,
                            onDismiss = { PlaybackDiagnostics.clear() }
                        )
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {
                    items(filteredSurahs, key = { it.number }) { surah ->
                        val isDownloaded = downloads.any {
                            it.reciterId == reciter!!.id && it.surahNumber == surah.number
                        }

                        SurahItem(
                            surah = surah,
                            isDownloaded = isDownloaded,
                            onPlay = {
                                val controller = mediaController
                                if (controller == null) {
                                    val message = "MediaController غير متصل بخدمة تشغيل الصوت."
                                    Log.e(TAG, message)
                                    PlaybackDiagnostics.show(
                                        title = "تعذر بدء الصوت",
                                        message = message
                                    )
                                    return@SurahItem
                                }

                                val startIndex = filteredSurahs.indexOf(surah)
                                if (startIndex < 0) return@SurahItem

                                val playlist = filteredSurahs.drop(startIndex).mapNotNull { s ->
                                    val downloaded = downloads.find {
                                        it.reciterId == reciter!!.id && it.surahNumber == s.number
                                    }

                                    val uri = if (downloaded != null && downloaded.localPath.isNotBlank()) {
                                        val file = java.io.File(downloaded.localPath)
                                        if (file.exists() && file.length() > 0L) {
                                            Uri.fromFile(file)
                                        } else {
                                            Log.w(TAG, "Downloaded file missing: ${downloaded.localPath}")
                                            buildRemoteUri(moshaf.server, s.number)
                                        }
                                    } else {
                                        buildRemoteUri(moshaf.server, s.number)
                                    }

                                    if (uri == null) {
                                        val message = "لم يتم إنشاء رابط صوت صالح للسورة ${s.number}."
                                        Log.e(TAG, message)
                                        PlaybackDiagnostics.show(
                                            title = "رابط الصوت غير صالح",
                                            message = message
                                        )
                                        null
                                    } else {
                                        Log.d(TAG, "Queueing surah ${s.number}: $uri")
                                        MediaItem.Builder()
                                            .setUri(uri)
                                            .setMediaMetadata(
                                                MediaMetadata.Builder()
                                                    .setTitle(s.name)
                                                    .setArtist(reciter!!.name)
                                                    .build()
                                            )
                                            .build()
                                    }
                                }

                                if (playlist.isEmpty()) {
                                    val message = "لا يوجد ملف صوت يمكن تشغيله لهذه السورة."
                                    Log.e(TAG, message)
                                    PlaybackDiagnostics.show(
                                        title = "لا يوجد صوت للتشغيل",
                                        message = message
                                    )
                                    return@SurahItem
                                }

                                try {
                                    controller.stop()
                                    controller.setMediaItems(playlist, 0, 0L)
                                    controller.prepare()
                                    controller.play()
                                    val uri = playlist.first().localConfiguration?.uri?.toString()
                                    Log.d(TAG, "Playback requested: $uri")
                                    PlaybackDiagnostics.clear()
                                } catch (t: Throwable) {
                                    val message = t.message ?: t.javaClass.simpleName
                                    Log.e(TAG, "Failed to start playback: $message", t)
                                    PlaybackDiagnostics.show(
                                        title = "تعذر بدء التشغيل",
                                        message = message,
                                        uri = playlist.firstOrNull()?.localConfiguration?.uri?.toString(),
                                        cause = "${t.javaClass.simpleName}: $message"
                                    )
                                }
                            },
                            onDownload = {
                                viewModel.downloadSurah(reciter!!, moshaf, surah)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioErrorCard(
    error: PlaybackDiagnostics.ErrorInfo,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = error.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = error.message,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            error.code?.let {
                Text(
                    text = "رمز الخطأ: $it",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontFamily = FontFamily.Monospace
                )
            }
            error.uri?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "الرابط:\n$it",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            error.cause?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "التفاصيل التقنية:\n$it",
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
            TextButton(onClick = onDismiss) {
                Text("إخفاء الخطأ")
            }
        }
    }
}

private fun buildRemoteUri(server: String, surahNumber: Int): Uri? {
    val cleanServer = server.trim()
    if (cleanServer.isBlank()) return null

    val baseUrl = if (cleanServer.endsWith("/")) cleanServer else "$cleanServer/"
    val surahStr = String.format("%03d", surahNumber)
    return Uri.parse("${baseUrl}${surahStr}.mp3")
}

@Composable
fun SurahItem(
    surah: Surah,
    isDownloaded: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit
) {
    ListItem(
        headlineContent = { Text("${surah.number}. ${surah.name}", fontWeight = FontWeight.SemiBold) },
        supportingContent = {
            val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
            Text("$type • ${surah.numberOfAyahs} آية")
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isDownloaded) {
                    Text("تم التنزيل", fontSize = 10.sp, color = Color.Gray)
                } else {
                    IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, contentDescription = "تنزيل")
                    }
                }
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                }
            }
        },
        modifier = Modifier.clickable { onPlay() }
    )
}
