package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepGreen = Color(0xFF1B5E20)
val Gold = Color(0xFFD4AF37)
val SoftBackground = Color(0xFFF4F7F6)

val DeepGreenDark = Color(0xFF0D2F10)
val GoldDark = Color(0xFF9E812A)
val DarkBackground = Color(0xFF121212)
