package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.util.Locale

@JsonClass(generateAdapter = true)
data class RecitersResponse(
    @Json(name = "reciters") val reciters: List<Reciter>
)

@JsonClass(generateAdapter = true)
data class Reciter(
    @Json(name = "id") val id: Int,
    @Json(name = "name") val name: String,
    @Json(name = "letter") val letter: String,
    @Json(name = "moshaf") val moshaf: List<Moshaf>
)

@JsonClass(generateAdapter = true)
data class Moshaf(
    @Json(name = "id") val id: Int,
    @Json(name = "name") val name: String,
    @Json(name = "server") val server: String,
    @Json(name = "surah_total") val surahTotal: Int,
    @Json(name = "moshaf_type") val moshafType: Int,
    @Json(name = "surah_list") val surahList: String,
    @Json(name = "custom_surah_urls") val customSurahUrls: Map<Int, String> = emptyMap()
) {
    fun getSurahAudioUrl(surahNumber: Int): String {
        customSurahUrls[surahNumber]?.let { return it }
        val surahStr = String.format(Locale.US, "%03d", surahNumber)
        val baseUrl = if (server.endsWith("/")) server else "$server/"
        return "$baseUrl$surahStr.mp3"
    }
}

@JsonClass(generateAdapter = true)
data class ArchiveMetadataResponse(
    @Json(name = "files") val files: List<ArchiveFile>? = null
)

@JsonClass(generateAdapter = true)
data class ArchiveFile(
    @Json(name = "name") val name: String = "",
    @Json(name = "format") val format: String? = null,
    @Json(name = "title") val title: String? = null,
    @Json(name = "track") val track: String? = null
)

@JsonClass(generateAdapter = true)
data class ArchiveSearchResponse(
    @Json(name = "response") val response: ArchiveSearchDocs? = null
)

@JsonClass(generateAdapter = true)
data class ArchiveSearchDocs(
    @Json(name = "docs") val docs: List<ArchiveSearchDoc> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ArchiveSearchDoc(
    @Json(name = "identifier") val identifier: String = "",
    @Json(name = "title") val title: String? = null
)
