package com.example.data.repository

import android.net.Uri
import com.example.data.api.QuranApi
import com.example.data.db.DownloadDao
import com.example.data.db.DownloadedSurah
import com.example.data.model.ArchiveFile
import com.example.data.model.FallbackSurahs
import com.example.data.model.Moshaf
import com.example.data.model.Reciter
import com.example.data.model.RecitersResponse
import com.example.data.model.Surah
import com.example.data.model.SurahResponse
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.coroutines.coroutineContext

data class RecitersLoadResult(
    val reciters: List<Reciter>,
    val isFromCache: Boolean,
    val errorMessage: String? = null
)

class QuranRepository(
    private val api: QuranApi,
    private val downloadDao: DownloadDao,
    private val downloadClient: OkHttpClient,
    private val filesDir: File,
    private val moshi: Moshi
) {
    private val cacheDir = File(filesDir, "api_cache").apply { mkdirs() }
    val downloadsDir = File(filesDir, "quran_downloads").apply { mkdirs() }

    private val recitersCacheFile = File(cacheDir, "reciters_cache.json")
    private val surahsCacheFile = File(cacheDir, "surahs_cache.json")

    suspend fun getRecitersWithStatus(): RecitersLoadResult = withContext(Dispatchers.IO) {
        var lastException: Exception? = null
        // Retry up to 2 times for weak networks
        for (attempt in 1..2) {
            try {
                val response = api.getReciters()
                val baseReciters = response.reciters.toMutableList()

                // Fetch Ethiopian reciters from Archive.org in best-effort mode
                val extraReciters = fetchAdditionalEthiopianReciters()
                for (extra in extraReciters) {
                    if (baseReciters.none { normalizeArabicName(it.name) == normalizeArabicName(extra.name) }) {
                        baseReciters.add(0, extra)
                    }
                }

                saveRecitersCache(RecitersResponse(baseReciters))
                return@withContext RecitersLoadResult(
                    reciters = baseReciters,
                    isFromCache = false
                )
            } catch (e: Exception) {
                lastException = e
                if (attempt < 2) delay(1200)
            }
        }

        // Network failed -> load from local cache if available
        val cached = loadRecitersCache()
        if (cached != null && cached.reciters.isNotEmpty()) {
            return@withContext RecitersLoadResult(
                reciters = cached.reciters,
                isFromCache = true,
                errorMessage = null
            )
        }

        return@withContext RecitersLoadResult(
            reciters = emptyList(),
            isFromCache = false,
            errorMessage = lastException?.localizedMessage ?: "تعذر الاتصال بالخادم. تحقق من اتصال الإنترنت."
        )
    }

    private suspend fun fetchAdditionalEthiopianReciters(): List<Reciter> {
        val extras = mutableListOf<Reciter>()

        // 1. Sheikh Afif Muhammad Taj (Ethiopia) from Internet Archive
        val afifSurahUrls = mutableMapOf<Int, String>()
        val afifArchiveItems = listOf("20240228_20240228_1941", "20231115_20231115_2253")
        for (itemId in afifArchiveItems) {
            try {
                val metadata = api.getArchiveMetadata(itemId)
                val files = metadata.files.orEmpty()
                val parsed = mapArchiveFilesToSurahs(itemId, files)
                for ((surahNum, url) in parsed) {
                    if (!afifSurahUrls.containsKey(surahNum)) {
                        afifSurahUrls[surahNum] = url
                    }
                }
            } catch (_: Exception) {
                // Continue if one archive item fails
            }
        }

        if (afifSurahUrls.isNotEmpty()) {
            val sortedSurahs = afifSurahUrls.keys.sorted()
            extras.add(
                Reciter(
                    id = 9001,
                    name = "عفيف محمد تاج (إثيوبيا)",
                    letter = "ع",
                    moshaf = listOf(
                        Moshaf(
                            id = 90011,
                            name = "حفص عن عاصم - إثيوبيا",
                            server = "https://archive.org/download/20240228_20240228_1941/",
                            surahTotal = sortedSurahs.size,
                            moshafType = 11,
                            surahList = sortedSurahs.joinToString(","),
                            customSurahUrls = afifSurahUrls
                        )
                    )
                )
            )
        }

        // 2. Search Archive.org for Sheikh Muhammad Al-Fateh (Ethiopia) Quran recitations
        try {
            val searchResp = api.searchArchiveItems(
                query = "(\"محمد الفاتح\" OR \"الفاتح\") AND (\"قرآن\" OR \"سورة\" OR \"مصحف\") AND mediatype:audio",
                rows = 5
            )
            val docs = searchResp.response?.docs.orEmpty()
            for (doc in docs) {
                val title = doc.title.orEmpty()
                if (doc.identifier.isNotBlank() &&
                    (title.contains("الفاتح") || title.contains("الفتح")) &&
                    !title.contains("الزبير")
                ) {
                    val metadata = api.getArchiveMetadata(doc.identifier)
                    val parsed = mapArchiveFilesToSurahs(doc.identifier, metadata.files.orEmpty())
                    if (parsed.isNotEmpty()) {
                        val sortedSurahs = parsed.keys.sorted()
                        extras.add(
                            Reciter(
                                id = 9002,
                                name = "محمد الفاتح (إثيوبيا)",
                                letter = "م",
                                moshaf = listOf(
                                    Moshaf(
                                        id = 90021,
                                        name = "مصحف مرتل - إثيوبيا",
                                        server = "https://archive.org/download/${doc.identifier}/",
                                        surahTotal = sortedSurahs.size,
                                        moshafType = 11,
                                        surahList = sortedSurahs.joinToString(","),
                                        customSurahUrls = parsed
                                    )
                                )
                            )
                        )
                        break
                    }
                }
            }
        } catch (_: Exception) {
            // Optional archive search failure shouldn't break main reciters loading
        }

        return extras
    }

    private fun mapArchiveFilesToSurahs(itemId: String, files: List<ArchiveFile>): Map<Int, String> {
        val result = mutableMapOf<Int, String>()
        val mp3Files = files.filter { file ->
            file.name.endsWith(".mp3", ignoreCase = true) &&
                !file.name.contains("_64kb", ignoreCase = true)
        }
        val surahs = FallbackSurahs.list

        for (file in mp3Files) {
            val baseName = file.name.substringAfterLast("/").substringBeforeLast(".")
            val titleText = normalizeArabicName(file.title ?: baseName)
            val fileText = normalizeArabicName(baseName)

            var matchedNumber: Int? = null

            // 1. Check Arabic surah name match (longest match first to avoid partial conflicts)
            val matchedSurah = surahs
                .sortedByDescending { it.name.length }
                .firstOrNull { surah ->
                    val shortName = normalizeArabicName(surah.name.removePrefix("سورة ").trim())
                    titleText.contains(shortName) || fileText.contains(shortName)
                }
            if (matchedSurah != null) {
                matchedNumber = matchedSurah.number
            }

            // 2. Fallback: leading 3-digit or numeric prefix (001..114)
            if (matchedNumber == null) {
                val numMatch = Regex("^0*(\\d{1,3})(?:\\D|$)").find(baseName)
                    ?: Regex("(?:^|\\D)0*(\\d{3})(?:\\D|$)").find(baseName)
                val parsedNum = numMatch?.groupValues?.getOrNull(1)?.toIntOrNull()
                if (parsedNum != null && parsedNum in 1..114) {
                    matchedNumber = parsedNum
                }
            }

            if (matchedNumber != null && !result.containsKey(matchedNumber)) {
                val encodedPath = file.name.split("/").joinToString("/") { Uri.encode(it) }
                result[matchedNumber] = "https://archive.org/download/$itemId/$encodedPath"
            }
        }
        return result
    }

    suspend fun getSurahs(): List<Surah> = withContext(Dispatchers.IO) {
        try {
            val response = api.getSurahs()
            if (response.data.isNotEmpty()) {
                saveSurahsCache(response)
                return@withContext response.data
            }
        } catch (_: Exception) {
            // Fall through to cache/fallback
        }

        val cached = loadSurahsCache()
        if (cached != null && cached.data.isNotEmpty()) {
            return@withContext cached.data
        }

        return@withContext FallbackSurahs.list
    }

    private fun saveRecitersCache(data: RecitersResponse) {
        try {
            val adapter = moshi.adapter(RecitersResponse::class.java)
            recitersCacheFile.writeText(adapter.toJson(data))
        } catch (_: Exception) {
        }
    }

    private fun loadRecitersCache(): RecitersResponse? {
        return try {
            if (!recitersCacheFile.exists()) return null
            val adapter = moshi.adapter(RecitersResponse::class.java)
            adapter.fromJson(recitersCacheFile.readText())
        } catch (_: Exception) {
            null
        }
    }

    private fun saveSurahsCache(data: SurahResponse) {
        try {
            val adapter = moshi.adapter(SurahResponse::class.java)
            surahsCacheFile.writeText(adapter.toJson(data))
        } catch (_: Exception) {
        }
    }

    private fun loadSurahsCache(): SurahResponse? {
        return try {
            if (!surahsCacheFile.exists()) return null
            val adapter = moshi.adapter(SurahResponse::class.java)
            adapter.fromJson(surahsCacheFile.readText())
        } catch (_: Exception) {
            null
        }
    }

    suspend fun downloadSurahFile(
        reciterId: Int,
        surahNumber: Int,
        url: String,
        onProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val finalFile = File(downloadsDir, "${reciterId}_${surahNumber}.mp3")
        val tempFile = File(downloadsDir, "${reciterId}_${surahNumber}.mp3.tmp")

        var lastError: Exception? = null
        // Retry up to 3 times on weak network failures
        for (attempt in 1..3) {
            coroutineContext.ensureActive()
            if (tempFile.exists()) tempFile.delete()

            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "SudaneseQuran/1.0")
                    .build()

                downloadClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("HTTP ${response.code}")
                    }
                    val body = response.body ?: throw IOException("Empty response body")
                    val totalBytes = body.contentLength()
                    var bytesCopied = 0L

                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var read: Int
                            var lastEmitTime = 0L
                            while (input.read(buffer).also { read = it } != -1) {
                                coroutineContext.ensureActive()
                                output.write(buffer, 0, read)
                                bytesCopied += read
                                val now = System.currentTimeMillis()
                                if (now - lastEmitTime >= 150) {
                                    onProgress(bytesCopied, totalBytes)
                                    lastEmitTime = now
                                }
                            }
                            output.flush()
                        }
                    }

                    onProgress(bytesCopied, if (totalBytes > 0) totalBytes else bytesCopied)

                    if (bytesCopied <= 1024 || (totalBytes > 0 && bytesCopied < totalBytes)) {
                        throw IOException("Incomplete download ($bytesCopied / $totalBytes)")
                    }

                    if (finalFile.exists()) finalFile.delete()
                    if (!tempFile.renameTo(finalFile)) {
                        tempFile.copyTo(finalFile, overwrite = true)
                        tempFile.delete()
                    }
                    return@withContext finalFile.absolutePath
                }
            } catch (e: Exception) {
                tempFile.delete()
                if (e is kotlinx.coroutines.CancellationException) throw e
                lastError = e
                if (attempt < 3) delay(1500L * attempt)
            }
        }

        throw lastError ?: IOException("فشل تنزيل الملف")
    }

    val allDownloads: Flow<List<DownloadedSurah>> = downloadDao.getAllDownloads()

    suspend fun saveDownload(surah: DownloadedSurah) {
        downloadDao.insertDownload(surah)
    }

    suspend fun deleteDownload(id: String) {
        val existing = downloadDao.getDownloadById(id)
        if (existing != null) {
            try {
                val file = File(existing.localPath)
                if (file.exists()) file.delete()
            } catch (_: Exception) {
            }
        }
        downloadDao.deleteDownloadById(id)
    }

    suspend fun cleanupStaleDownloads(downloads: List<DownloadedSurah>) = withContext(Dispatchers.IO) {
        for (d in downloads) {
            val file = File(d.localPath)
            if (!file.exists() || file.length() <= 1024) {
                downloadDao.deleteDownloadById(d.id)
            }
        }
    }

    fun normalizeArabicName(text: String): String {
        return text.replace("[\u064B-\u0652]".toRegex(), "")
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("ؤ", "و")
            .replace("ئ", "ي")
            .replace("الشيخ", "")
            .replace("شيخ", "")
            .replace("الدكتور", "")
            .replace("دكتور", "")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    // Sudanese Reciters (includes popular Ethiopian reciters requested by user)
    val sudaneseReciters = listOf(
        "نورين محمد صديق",
        "الزين محمد أحمد",
        "الفاتح محمد الزبير",
        "محمد الفاتح",
        "محمد عبد الكريم",
        "عبد الرشيد صوفي",
        "الهادي كنونة",
        "محمد سيد",
        "عوض عمر",
        "صديق أحمد حمدون",
        "محمد الطيب حمدان",
        "عبد اللطيف العوض",
        "أحمد جبارة",
        "الشيخ الزين",
        "إبراهيم الكرار",
        "يوسف منصور",
        "طه الفشني",
        "حسن عوض الكريم",
        "محمد أحمد بسيوني",
        "فيصل محمد جاد الله",
        "عصام كمال",
        "محمود علي البنا",
        "جعفر محمد عثمان",
        "محي الدين الكردي",
        "عفيف محمد تاج",
        "محمد تاج عفيف",
        "عفيفي",
        "عفيف"
    )

    // Ethiopian Reciters
    val ethiopianReciters = listOf(
        "عفيف محمد تاج",
        "محمد تاج عفيف",
        "محمد الفاتح",
        "الفاتح محمد الزبير",
        "عفيف"
    )

    // Egyptian Reciters
    val egyptianReciters = listOf(
        "الحصري",
        "عبد الباسط",
        "المنشاوي",
        "مصطفى إسماعيل",
        "البنا",
        "الطبلاوي",
        "محمد رفعت",
        "محمود شاهات",
        "الشحات محمد أنور",
        "أبو العينين شعيشع",
        "محمد محمود الطبلاوي",
        "محمود علي البنا",
        "محمود خليل الحصري",
        "محمد صديق المنشاوي",
        "عبد الفتاح الشعشاعي",
        "طه الفشني",
        "كامل يوسف البهتيمي",
        "أحمد نعينع",
        "عبد العزيز حصان",
        "محمد بدوي",
        "السيد متولي",
        "عنتر مسلم",
        "محمود الصعيدي"
    )

    // Saudi Reciters
    val saudiReciters = listOf(
        "السديس",
        "الشريم",
        "ماهر المعيقلي",
        "ياسر الدوسري",
        "بندر بليلة",
        "ناصر القطامي",
        "علي الحذيفي",
        "محمد أيوب",
        "عبد الله الجهني",
        "سعود الشريم",
        "عبد الرحمن السديس",
        "عبد الباري الثبيتي",
        "صلاح البدير",
        "أحمد الحواشي",
        "خالد القحطاني",
        "محمد اللحيدان",
        "صالح الهبدان",
        "عبد الودود حنيف",
        "أحمد بن علي العجمي",
        "سعد الغامدي",
        "عبد العزيز الأحمد",
        "خالد الغامدي",
        "عماد زهير حافظ"
    )

    // Arabic / Others
    val otherPopularReciters = listOf(
        "أحمد العجمي",
        "سعد الغامدي",
        "مشاري العفاسي",
        "فارس عباد",
        "أبو بكر الشاطري",
        "إدريس أبكر",
        "منصور السالمي",
        "هزاع البلوشي",
        "صلاح الهاشم",
        "وديع اليمني",
        "سلمان العتيبي",
        "نبيل الرفاعي",
        "سهل ياسين",
        "هاني الرفاعي",
        "توفيق الصايغ",
        "إبراهيم الجبرين",
        "محمد المقيط",
        "عبد الولي الأركاني",
        "شيرزاد عبد الرحمن",
        "جمال شاكر عبد الله"
    )
}
