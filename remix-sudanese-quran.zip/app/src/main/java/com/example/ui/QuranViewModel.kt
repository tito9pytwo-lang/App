package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.DownloadedSurah
import com.example.data.model.Moshaf
import com.example.data.model.Reciter
import com.example.data.model.Surah
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class DownloadStatus {
    DOWNLOADING,
    FAILED
}

data class DownloadTaskState(
    val id: String,
    val reciterName: String,
    val surahName: String,
    val progressPercent: Int, // 0..100, or -1 if content length unknown
    val downloadedBytes: Long,
    val totalBytes: Long,
    val status: DownloadStatus,
    val errorMessage: String? = null
)

class QuranViewModel(
    application: Application,
    private val repository: QuranRepository
) : AndroidViewModel(application) {

    private val _reciters = MutableStateFlow<List<Reciter>>(emptyList())
    val reciters: StateFlow<List<Reciter>> = _reciters.asStateFlow()

    private val _filteredReciters = MutableStateFlow<List<Reciter>>(emptyList())
    val filteredReciters: StateFlow<List<Reciter>> = _filteredReciters.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Sudanese")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs.asStateFlow()

    private val _downloadedSurahs = MutableStateFlow<List<DownloadedSurah>>(emptyList())
    val downloadedSurahs: StateFlow<List<DownloadedSurah>> = _downloadedSurahs.asStateFlow()

    private val _downloadProgress = MutableStateFlow<Map<String, DownloadTaskState>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, DownloadTaskState>> = _downloadProgress.asStateFlow()

    private val _selectedReciter = MutableStateFlow<Reciter?>(null)
    val selectedReciter: StateFlow<Reciter?> = _selectedReciter.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSurahsLoading = MutableStateFlow(false)
    val isSurahsLoading: StateFlow<Boolean> = _isSurahsLoading.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _recitersError = MutableStateFlow<String?>(null)
    val recitersError: StateFlow<String?> = _recitersError.asStateFlow()

    private val _isOfflineCache = MutableStateFlow(false)
    val isOfflineCache: StateFlow<Boolean> = _isOfflineCache.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val activeDownloadJobs = mutableMapOf<String, Job>()
    private var hasCleanedStaleDownloads = false

    init {
        fetchReciters()
        fetchSurahs()
        observeDownloads()
    }

    fun retryFetchReciters() {
        fetchReciters()
        if (_surahs.value.isEmpty()) {
            fetchSurahs()
        }
    }

    private fun fetchReciters() {
        viewModelScope.launch {
            _isLoading.value = true
            _recitersError.value = null
            val result = repository.getRecitersWithStatus()
            _reciters.value = result.reciters
            _isOfflineCache.value = result.isFromCache
            _recitersError.value = result.errorMessage
            filterReciters()
            _isLoading.value = false
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        filterReciters()
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        filterReciters()
    }

    private fun filterReciters() {
        val all = _reciters.value
        val query = _searchQuery.value.trim()
        val category = _selectedCategory.value

        if (query.isNotEmpty()) {
            _isSearching.value = true
            val normalizedQuery = normalizeArabic(query)
            val queryTokens = normalizedQuery.split(" ").filter { it.isNotBlank() }
            _filteredReciters.value = all.filter { reciter ->
                val normalizedName = normalizeArabic(reciter.name)
                normalizedName.contains(normalizedQuery, ignoreCase = true) ||
                    (queryTokens.isNotEmpty() && queryTokens.all { token ->
                        normalizedName.contains(token, ignoreCase = true)
                    })
            }
            _isSearching.value = false
            return
        }

        _isSearching.value = false

        val featured = when (category) {
            "Sudanese" -> repository.sudaneseReciters
            "Ethiopian" -> repository.ethiopianReciters
            "Egyptian" -> repository.egyptianReciters
            "Saudi" -> repository.saudiReciters
            "Arabic" -> repository.otherPopularReciters
            else -> emptyList()
        }

        if (featured.isEmpty()) {
            _filteredReciters.value = all
        } else {
            _filteredReciters.value = all.filter { reciter ->
                val normalizedName = normalizeArabic(reciter.name)
                featured.any { name ->
                    val nFeatured = normalizeArabic(name)
                    normalizedName.contains(nFeatured, ignoreCase = true) ||
                        nFeatured.contains(normalizedName, ignoreCase = true)
                }
            }
        }
    }

    private fun normalizeArabic(text: String): String {
        return repository.normalizeArabicName(text)
    }

    private fun fetchSurahs() {
        viewModelScope.launch {
            _isSurahsLoading.value = true
            _surahs.value = repository.getSurahs()
            _isSurahsLoading.value = false
        }
    }

    private fun observeDownloads() {
        viewModelScope.launch {
            repository.allDownloads.collectLatest { downloads ->
                if (!hasCleanedStaleDownloads) {
                    hasCleanedStaleDownloads = true
                    val missing = downloads.filter {
                        val f = File(it.localPath)
                        !f.exists() || f.length() <= 1024
                    }
                    if (missing.isNotEmpty()) {
                        repository.cleanupStaleDownloads(missing)
                    }
                }
                _downloadedSurahs.value = downloads.filter {
                    val f = File(it.localPath)
                    f.exists() && f.length() > 1024
                }
            }
        }
    }

    fun selectReciter(reciter: Reciter) {
        _selectedReciter.value = reciter
    }

    fun downloadSurah(reciter: Reciter, moshaf: Moshaf, surah: Surah) {
        val downloadId = "${reciter.id}_${surah.number}"
        if (_downloadedSurahs.value.any { it.id == downloadId }) return
        if (activeDownloadJobs[downloadId]?.isActive == true) return

        val url = moshaf.getSurahAudioUrl(surah.number)

        val job = viewModelScope.launch {
            _downloadProgress.update { map ->
                map + (downloadId to DownloadTaskState(
                    id = downloadId,
                    reciterName = reciter.name,
                    surahName = surah.name,
                    progressPercent = 0,
                    downloadedBytes = 0L,
                    totalBytes = -1L,
                    status = DownloadStatus.DOWNLOADING
                ))
            }

            try {
                val localPath = repository.downloadSurahFile(
                    reciterId = reciter.id,
                    surahNumber = surah.number,
                    url = url,
                    onProgress = { downloadedBytes, totalBytes ->
                        val percent = if (totalBytes > 0) {
                            ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
                        } else {
                            -1
                        }
                        _downloadProgress.update { map ->
                            val current = map[downloadId] ?: return@update map
                            map + (downloadId to current.copy(
                                progressPercent = percent,
                                downloadedBytes = downloadedBytes,
                                totalBytes = totalBytes,
                                status = DownloadStatus.DOWNLOADING
                            ))
                        }
                    }
                )

                repository.saveDownload(
                    DownloadedSurah(
                        id = downloadId,
                        reciterId = reciter.id,
                        reciterName = reciter.name,
                        surahNumber = surah.number,
                        surahName = surah.name,
                        localPath = localPath,
                        serverUrl = url
                    )
                )

                _downloadProgress.update { it - downloadId }
            } catch (e: CancellationException) {
                _downloadProgress.update { it - downloadId }
            } catch (e: Exception) {
                _downloadProgress.update { map ->
                    map + (downloadId to DownloadTaskState(
                        id = downloadId,
                        reciterName = reciter.name,
                        surahName = surah.name,
                        progressPercent = 0,
                        downloadedBytes = 0L,
                        totalBytes = -1L,
                        status = DownloadStatus.FAILED,
                        errorMessage = "فشل التنزيل: الشبكة ضعيفة أو غير متصلة"
                    ))
                }
            } finally {
                activeDownloadJobs.remove(downloadId)
            }
        }

        activeDownloadJobs[downloadId] = job
    }

    fun cancelDownload(downloadId: String) {
        activeDownloadJobs[downloadId]?.cancel()
        activeDownloadJobs.remove(downloadId)
        _downloadProgress.update { it - downloadId }
    }

    fun dismissDownloadError(downloadId: String) {
        _downloadProgress.update { it - downloadId }
    }

    fun deleteDownload(downloadId: String) {
        viewModelScope.launch {
            repository.deleteDownload(downloadId)
        }
    }
}
