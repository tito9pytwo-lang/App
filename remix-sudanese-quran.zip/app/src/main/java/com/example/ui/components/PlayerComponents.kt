package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import java.util.Locale

@Composable
fun MiniPlayer(controller: MediaController) {
    var isPlaying by remember { mutableStateOf(controller.isPlaying) }
    var currentTitle by remember {
        mutableStateOf(controller.currentMediaItem?.mediaMetadata?.title?.toString() ?: "")
    }
    var currentArtist by remember {
        mutableStateOf(controller.currentMediaItem?.mediaMetadata?.artist?.toString() ?: "")
    }
    var position by remember { mutableLongStateOf(controller.currentPosition.coerceAtLeast(0L)) }
    var duration by remember { mutableLongStateOf(controller.duration.coerceAtLeast(0L)) }
    var isBuffering by remember {
        mutableStateOf(controller.playbackState == Player.STATE_BUFFERING)
    }
    var playbackError by remember { mutableStateOf<String?>(null) }

    val listener = remember {
        object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (playing) playbackError = null
            }

            override fun onMediaMetadataChanged(metadata: MediaMetadata) {
                currentTitle = metadata.title?.toString() ?: ""
                currentArtist = metadata.artist?.toString() ?: ""
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    duration = controller.duration.coerceAtLeast(0L)
                    playbackError = null
                } else if (playbackState == Player.STATE_IDLE && controller.playerError == null) {
                    isBuffering = false
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                isPlaying = false
                val uriStr = controller.currentMediaItem?.localConfiguration?.uri?.toString().orEmpty()
                playbackError = if (uriStr.startsWith("file://")) {
                    "تعذر تشغيل الملف المحفوظ، حاول إعادة تنزيل السورة"
                } else {
                    "تعذر الاتصال بالخادم (الشبكة ضعيفة). اضغط إعادة المحاولة"
                }
            }
        }
    }

    LaunchedEffect(controller, isPlaying) {
        while (isPlaying) {
            position = controller.currentPosition.coerceAtLeast(0L)
            val d = controller.duration
            if (d > 0) duration = d
            kotlinx.coroutines.delay(500)
        }
    }

    DisposableEffect(controller) {
        controller.addListener(listener)
        isPlaying = controller.isPlaying
        isBuffering = controller.playbackState == Player.STATE_BUFFERING
        currentTitle = controller.currentMediaItem?.mediaMetadata?.title?.toString() ?: ""
        currentArtist = controller.currentMediaItem?.mediaMetadata?.artist?.toString() ?: ""
        duration = controller.duration.coerceAtLeast(0L)
        position = controller.currentPosition.coerceAtLeast(0L)
        onDispose {
            controller.removeListener(listener)
        }
    }

    Surface(
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            if (playbackError != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = playbackError!!,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = {
                                playbackError = null
                                controller.prepare()
                                controller.play()
                            },
                            modifier = Modifier.testTag("retry_playback_button")
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "إعادة المحاولة",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إعادة", fontSize = 12.sp)
                        }
                        IconButton(
                            onClick = { playbackError = null },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "إغلاق",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(
                        text = if (currentTitle.isNotEmpty()) currentTitle else "لا يوجد تشغيل حالياً",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1
                    )
                    if (currentArtist.isNotEmpty()) {
                        Text(
                            text = currentArtist,
                            fontSize = 12.sp,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(
                    onClick = {
                        if (playbackError != null) {
                            playbackError = null
                            controller.prepare()
                            controller.play()
                        } else if (isPlaying) {
                            controller.pause()
                        } else {
                            if (controller.playbackState == Player.STATE_IDLE) {
                                controller.prepare()
                            }
                            controller.play()
                        }
                    },
                    modifier = Modifier.testTag("mini_player_toggle_button")
                ) {
                    if (isBuffering) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل"
                        )
                    }
                }
            }

            if (duration > 0 || position > 0) {
                val safeDuration = if (duration > 0) duration else position + 1
                Slider(
                    value = position.toFloat().coerceIn(0f, safeDuration.toFloat()),
                    onValueChange = {
                        position = it.toLong()
                        controller.seekTo(it.toLong())
                    },
                    valueRange = 0f..safeDuration.toFloat(),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatTime(position), fontSize = 10.sp)
                    Text(formatTime(duration.coerceAtLeast(0)), fontSize = 10.sp)
                }
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
