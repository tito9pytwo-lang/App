package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.example.ui.DownloadStatus
import com.example.ui.QuranViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.rememberMediaController
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(viewModel: QuranViewModel) {
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val downloadProgress by viewModel.downloadProgress.collectAsState()
    val mediaController by rememberMediaController()

    val activeTasks = downloadProgress.values.toList()

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("المحفوظات", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        if (downloads.isEmpty() && activeTasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.OfflinePin,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("لا توجد سور محفوظة", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "قم بتنزيل أي سورة للاستماع إليها بدون إنترنت",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (activeTasks.isNotEmpty()) {
                    item {
                        Text(
                            text = "التنزيلات الجارية",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                    items(activeTasks, key = { "active_${it.id}" }) { task ->
                        Column(modifier = Modifier.fillMaxWidth()) {
                            ListItem(
                                headlineContent = { Text(task.surahName, fontWeight = FontWeight.Bold) },
                                supportingContent = {
                                    Column {
                                        Text(task.reciterName, fontSize = 12.sp)
                                        if (task.status == DownloadStatus.DOWNLOADING) {
                                            val pct = if (task.progressPercent >= 0) "${task.progressPercent}%" else "جارٍ..."
                                            val sizeStr = if (task.totalBytes > 0) {
                                                "${formatByteSize(task.downloadedBytes)} / ${formatByteSize(task.totalBytes)}"
                                            } else {
                                                formatByteSize(task.downloadedBytes)
                                            }
                                            Text(
                                                "التقدم: $pct ($sizeStr)",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        } else {
                                            Text(
                                                task.errorMessage ?: "فشل التنزيل",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                },
                                trailingContent = {
                                    IconButton(
                                        onClick = {
                                            if (task.status == DownloadStatus.DOWNLOADING) {
                                                viewModel.cancelDownload(task.id)
                                            } else {
                                                viewModel.dismissDownloadError(task.id)
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "إلغاء")
                                    }
                                }
                            )
                            if (task.status == DownloadStatus.DOWNLOADING) {
                                if (task.progressPercent >= 0) {
                                    LinearProgressIndicator(
                                        progress = { task.progressPercent / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp)
                                            .height(4.dp)
                                    )
                                } else {
                                    LinearProgressIndicator(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp)
                                            .height(4.dp)
                                    )
                                }
                            }
                            HorizontalDivider(
                                modifier = Modifier.padding(top = 6.dp),
                                thickness = 0.5.dp,
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }

                if (downloads.isNotEmpty()) {
                    item {
                        Text(
                            text = "متاح بدون إنترنت (${downloads.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }

                items(downloads, key = { it.id }) { download ->
                    val fileSize = File(download.localPath).let { if (it.exists()) formatByteSize(it.length()) else "" }
                    val playAction = {
                        val startIndex = downloads.indexOf(download).coerceAtLeast(0)
                        val playlist = downloads.drop(startIndex).mapNotNull { d ->
                            val file = File(d.localPath)
                            if (!file.exists() || file.length() <= 1024) return@mapNotNull null
                            val uri = Uri.fromFile(file).toString()
                            MediaItem.Builder()
                                .setUri(uri)
                                .setMediaMetadata(
                                    MediaMetadata.Builder()
                                        .setTitle(d.surahName)
                                        .setArtist(d.reciterName)
                                        .build()
                                )
                                .build()
                        }
                        if (playlist.isNotEmpty()) {
                            mediaController?.setMediaItems(playlist)
                            mediaController?.prepare()
                            mediaController?.play()
                        }
                    }

                    ListItem(
                        headlineContent = { Text(download.surahName, fontWeight = FontWeight.Bold) },
                        supportingContent = {
                            val info = if (fileSize.isNotEmpty()) "${download.reciterName} • $fileSize" else download.reciterName
                            Text(info)
                        },
                        trailingContent = {
                            Row {
                                IconButton(
                                    onClick = { viewModel.deleteDownload(download.id) },
                                    modifier = Modifier.testTag("delete_download_${download.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف")
                                }
                                IconButton(
                                    onClick = playAction,
                                    modifier = Modifier.testTag("play_download_${download.id}")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                                }
                            }
                        },
                        modifier = Modifier.clickable { playAction() }
                    )
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }

        mediaController?.let { controller ->
            MiniPlayer(controller)
        }
    }
}
