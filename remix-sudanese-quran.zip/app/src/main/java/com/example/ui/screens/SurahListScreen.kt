package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.example.data.model.Surah
import com.example.ui.DownloadStatus
import com.example.ui.DownloadTaskState
import com.example.ui.QuranViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.rememberMediaController
import java.io.File
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahListScreen(
    viewModel: QuranViewModel,
    onBack: () -> Unit
) {
    val reciter by viewModel.selectedReciter.collectAsState()
    val surahs by viewModel.surahs.collectAsState()
    val isSurahsLoading by viewModel.isSurahsLoading.collectAsState()
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val downloadProgress by viewModel.downloadProgress.collectAsState()
    val mediaController by rememberMediaController()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(reciter?.name ?: "السور", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            mediaController?.let { controller ->
                MiniPlayer(controller)
            }
        }
    ) { innerPadding ->
        if (reciter == null) {
            Box(Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                Text("لم يتم اختيار قارئ")
            }
        } else if (isSurahsLoading && surahs.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val moshaf = reciter!!.moshaf.firstOrNull()
            val availableSurahs = moshaf?.surahList
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?.toSet()
                ?: emptySet()

            val filteredSurahs = surahs.filter { availableSurahs.contains(it.number) }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(filteredSurahs, key = { it.number }) { surah ->
                    val downloadId = "${reciter!!.id}_${surah.number}"
                    val downloadedEntry = downloads.find { it.id == downloadId }
                    val isDownloaded = downloadedEntry != null && File(downloadedEntry.localPath).let {
                        it.exists() && it.length() > 1024
                    }
                    val taskState = downloadProgress[downloadId]

                    SurahItem(
                        surah = surah,
                        isDownloaded = isDownloaded,
                        downloadTask = taskState,
                        onPlay = {
                            val startIndex = filteredSurahs.indexOf(surah)
                            val playlist = filteredSurahs.drop(startIndex).mapNotNull { s ->
                                val sId = "${reciter!!.id}_${s.number}"
                                val localEntry = downloads.find { it.id == sId }
                                val localFile = localEntry?.let { File(it.localPath) }
                                val sUrl = if (localFile != null && localFile.exists() && localFile.length() > 1024) {
                                    Uri.fromFile(localFile).toString()
                                } else {
                                    moshaf?.getSurahAudioUrl(s.number) ?: return@mapNotNull null
                                }
                                MediaItem.Builder()
                                    .setUri(sUrl)
                                    .setMediaMetadata(
                                        MediaMetadata.Builder()
                                            .setTitle(s.name)
                                            .setArtist(reciter!!.name)
                                            .build()
                                    )
                                    .build()
                            }

                            if (playlist.isNotEmpty()) {
                                mediaController?.setMediaItems(playlist)
                                mediaController?.prepare()
                                mediaController?.play()
                            }
                        },
                        onDownload = {
                            moshaf?.let { viewModel.downloadSurah(reciter!!, it, surah) }
                        },
                        onCancelDownload = {
                            viewModel.cancelDownload(downloadId)
                        }
                    )
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
    }
}

@Composable
fun SurahItem(
    surah: Surah,
    isDownloaded: Boolean,
    downloadTask: DownloadTaskState?,
    onPlay: () -> Unit,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .testTag("surah_item_${surah.number}")
    ) {
        ListItem(
            headlineContent = {
                Text("${surah.number}. ${surah.name}", fontWeight = FontWeight.SemiBold)
            },
            supportingContent = {
                val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
                Column {
                    Text("$type • ${surah.numberOfAyahs} آية", fontSize = 12.sp)
                    if (downloadTask?.status == DownloadStatus.DOWNLOADING) {
                        val percentText = if (downloadTask.progressPercent >= 0) {
                            "${downloadTask.progressPercent}%"
                        } else {
                            "جارٍ التنزيل"
                        }
                        val sizeText = if (downloadTask.totalBytes > 0) {
                            "${formatByteSize(downloadTask.downloadedBytes)} / ${formatByteSize(downloadTask.totalBytes)}"
                        } else {
                            formatByteSize(downloadTask.downloadedBytes)
                        }
                        Text(
                            text = "جارٍ التنزيل: $percentText ($sizeText)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    } else if (downloadTask?.status == DownloadStatus.FAILED) {
                        Text(
                            text = downloadTask.errorMessage ?: "فشل التنزيل، اضغط لإعادة المحاولة",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            trailingContent = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when {
                        isDownloaded -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "تم التنزيل",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "محفوظة",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        downloadTask?.status == DownloadStatus.DOWNLOADING -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (downloadTask.progressPercent >= 0) {
                                    Text(
                                        text = "${downloadTask.progressPercent}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    CircularProgressIndicator(
                                        progress = { downloadTask.progressPercent / 100f },
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.5.dp
                                    )
                                } else {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.5.dp
                                    )
                                }
                                IconButton(
                                    onClick = onCancelDownload,
                                    modifier = Modifier.testTag("cancel_download_${surah.number}")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "إلغاء التنزيل")
                                }
                            }
                        }
                        downloadTask?.status == DownloadStatus.FAILED -> {
                            IconButton(
                                onClick = onDownload,
                                modifier = Modifier.testTag("retry_download_${surah.number}")
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "إعادة التنزيل",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                        else -> {
                            IconButton(
                                onClick = onDownload,
                                modifier = Modifier.testTag("download_surah_${surah.number}")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = "تنزيل")
                            }
                        }
                    }

                    IconButton(
                        onClick = onPlay,
                        modifier = Modifier.testTag("play_surah_${surah.number}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                    }
                }
            }
        )

        if (downloadTask?.status == DownloadStatus.DOWNLOADING) {
            if (downloadTask.progressPercent >= 0) {
                LinearProgressIndicator(
                    progress = { downloadTask.progressPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                )
            }
        }
    }
}

fun formatByteSize(bytes: Long): String {
    if (bytes <= 0) return "0 KB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        String.format(Locale.US, "%.0f KB", kb)
    }
}
