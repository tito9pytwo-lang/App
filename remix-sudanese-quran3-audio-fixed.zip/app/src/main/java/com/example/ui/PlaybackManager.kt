package com.example.ui

import android.content.ComponentName
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.service.PlaybackService
import com.google.common.util.concurrent.MoreExecutors

private const val TAG = "PlaybackManager"

@Composable
fun rememberMediaController(): State<MediaController?> {
    val context = LocalContext.current
    val controllerState = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, PlaybackService::class.java)
        )

        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()

        controllerFuture.addListener({
            try {
                controllerState.value = controllerFuture.get()
                Log.d(TAG, "MediaController connected successfully")
            } catch (t: Throwable) {
                controllerState.value = null
                Log.e(TAG, "Failed to connect to PlaybackService", t)
            }
        }, MoreExecutors.directExecutor())

        onDispose {
            try {
                MediaController.releaseFuture(controllerFuture)
            } catch (t: Throwable) {
                Log.w(TAG, "Failed to release MediaController", t)
            }
            controllerState.value = null
        }
    }

    return controllerState
}
