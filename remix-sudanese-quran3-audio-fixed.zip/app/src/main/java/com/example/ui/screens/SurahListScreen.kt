package com.example.ui.screens

import android.net.Uri
import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import com.example.data.model.Surah
import com.example.ui.QuranViewModel
import com.example.ui.rememberMediaController

private const val TAG = "SurahListScreen"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahListScreen(
    viewModel: QuranViewModel,
    onBack: () -> Unit
) {
    val reciter by viewModel.selectedReciter.collectAsState()
    val surahs by viewModel.surahs.collectAsState()
    val isSurahsLoading by viewModel.isSurahsLoading.collectAsState()
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val mediaController by rememberMediaController()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(reciter?.name ?: "السور", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            mediaController?.let { controller ->
                com.example.ui.components.MiniPlayer(controller)
            }
        }
    ) { innerPadding ->
        if (reciter == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لم يتم اختيار قارئ")
            }
        } else if (isSurahsLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val moshaf = reciter!!.moshaf.firstOrNull()
            val availableSurahs = moshaf?.surahList
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?.toSet()
                ?: emptySet()

            val filteredSurahs = surahs.filter { it.number in availableSurahs }

            if (moshaf == null || moshaf.server.isBlank()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا يوجد رابط صوت صالح لهذا القارئ")
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    items(filteredSurahs, key = { it.number }) { surah ->
                        val isDownloaded = downloads.any {
                            it.reciterId == reciter!!.id && it.surahNumber == surah.number
                        }

                        SurahItem(
                            surah = surah,
                            isDownloaded = isDownloaded,
                            onPlay = {
                                val controller = mediaController
                                if (controller == null) {
                                    Log.e(TAG, "Cannot play: MediaController is not connected")
                                    return@SurahItem
                                }

                                val startIndex = filteredSurahs.indexOf(surah)
                                if (startIndex < 0) return@SurahItem

                                val playlist = filteredSurahs.drop(startIndex).mapNotNull { s ->
                                    val downloaded = downloads.find {
                                        it.reciterId == reciter!!.id && it.surahNumber == s.number
                                    }

                                    val uri = if (downloaded != null && downloaded.localPath.isNotBlank()) {
                                        val file = java.io.File(downloaded.localPath)
                                        if (file.exists() && file.length() > 0L) {
                                            Uri.fromFile(file)
                                        } else {
                                            Log.w(TAG, "Downloaded file missing: ${downloaded.localPath}")
                                            buildRemoteUri(moshaf.server, s.number)
                                        }
                                    } else {
                                        buildRemoteUri(moshaf.server, s.number)
                                    }

                                    if (uri == null) {
                                        Log.e(TAG, "Invalid audio URL for surah ${s.number}")
                                        null
                                    } else {
                                        Log.d(TAG, "Queueing surah ${s.number}: $uri")
                                        MediaItem.Builder()
                                            .setUri(uri)
                                            .setMediaMetadata(
                                                MediaMetadata.Builder()
                                                    .setTitle(s.name)
                                                    .setArtist(reciter!!.name)
                                                    .build()
                                            )
                                            .build()
                                    }
                                }

                                if (playlist.isEmpty()) {
                                    Log.e(TAG, "No playable media items")
                                    return@SurahItem
                                }

                                try {
                                    controller.stop()
                                    controller.setMediaItems(playlist, 0, 0L)
                                    controller.prepare()
                                    controller.play()
                                    Log.d(TAG, "Playback started: ${playlist.first().localConfiguration?.uri}")
                                } catch (t: Throwable) {
                                    Log.e(TAG, "Failed to start playback", t)
                                }
                            },
                            onDownload = {
                                viewModel.downloadSurah(reciter!!, moshaf, surah)
                            }
                        )
                    }
                }
            }
        }
    }
}

private fun buildRemoteUri(server: String, surahNumber: Int): Uri? {
    val cleanServer = server.trim()
    if (cleanServer.isBlank()) return null

    val baseUrl = if (cleanServer.endsWith("/")) cleanServer else "$cleanServer/"
    val surahStr = String.format("%03d", surahNumber)
    return Uri.parse("${baseUrl}${surahStr}.mp3")
}

@Composable
fun SurahItem(
    surah: Surah,
    isDownloaded: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit
) {
    ListItem(
        headlineContent = { Text("${surah.number}. ${surah.name}", fontWeight = FontWeight.SemiBold) },
        supportingContent = {
            val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
            Text("$type • ${surah.numberOfAyahs} آية")
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isDownloaded) {
                    Text("تم التنزيل", fontSize = 10.sp, color = Color.Gray)
                } else {
                    IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, contentDescription = "تنزيل")
                    }
                }
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                }
            }
        },
        modifier = Modifier.clickable { onPlay() }
    )
}
