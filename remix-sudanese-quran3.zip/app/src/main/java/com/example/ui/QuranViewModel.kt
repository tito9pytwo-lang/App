package com.example.ui

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.DownloadedSurah
import com.example.data.model.Moshaf
import com.example.data.model.Reciter
import com.example.data.model.Surah
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class QuranViewModel(
    application: Application,
    private val repository: QuranRepository
) : AndroidViewModel(application) {

    private val _reciters = MutableStateFlow<List<Reciter>>(emptyList())
    val reciters: StateFlow<List<Reciter>> = _reciters.asStateFlow()

    private val _filteredReciters = MutableStateFlow<List<Reciter>>(emptyList())
    val filteredReciters: StateFlow<List<Reciter>> = _filteredReciters.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Sudanese")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs.asStateFlow()

    private val _downloadedSurahs = MutableStateFlow<List<DownloadedSurah>>(emptyList())
    val downloadedSurahs: StateFlow<List<DownloadedSurah>> = _downloadedSurahs.asStateFlow()

    private val _selectedReciter = MutableStateFlow<Reciter?>(null)
    val selectedReciter: StateFlow<Reciter?> = _selectedReciter.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSurahsLoading = MutableStateFlow(false)
    val isSurahsLoading: StateFlow<Boolean> = _isSurahsLoading.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    init {
        fetchReciters()
        fetchSurahs()
        observeDownloads()
    }

    private fun fetchReciters() {
        viewModelScope.launch {
            _isLoading.value = true
            val allReciters = repository.getReciters()
            _reciters.value = allReciters
            launch { filterReciters() }
            _isLoading.value = false
        }
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            filterReciters()
        }
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        viewModelScope.launch {
            filterReciters()
        }
    }

    private suspend fun filterReciters() {
        val all = _reciters.value
        val query = _searchQuery.value.trim()
        val category = _selectedCategory.value

        // If searching, search in the FULL list to give "all" results
        if (query.isNotEmpty()) {
            _isSearching.value = true
            val normalizedQuery = normalizeArabic(query)
            _filteredReciters.value = all.filter { reciter ->
                val normalizedName = normalizeArabic(reciter.name)
                normalizedName.contains(normalizedQuery, ignoreCase = true)
            }
            _isSearching.value = false
            return
        }

        _isSearching.value = false

        // Otherwise filter by category
        val featured = when (category) {
            "Sudanese" -> repository.sudaneseReciters
            "Egyptian" -> repository.egyptianReciters
            "Saudi" -> repository.saudiReciters
            "Arabic" -> repository.otherPopularReciters
            else -> emptyList() // All
        }

        if (featured.isEmpty()) {
            _filteredReciters.value = all
        } else {
            _filteredReciters.value = all.filter { reciter ->
                val normalizedName = normalizeArabic(reciter.name)
                featured.any { name -> 
                    val nFeatured = normalizeArabic(name)
                    normalizedName.contains(nFeatured, ignoreCase = true) || 
                    nFeatured.contains(normalizedName, ignoreCase = true)
                }
            }
        }
    }

    private fun normalizeArabic(text: String): String {
        return text.replace("[\u064B-\u0652]".toRegex(), "") // Remove diacritics
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ى", "ي")
            .replace("ة", "ه")
            .replace("ؤ", "و")
            .replace("ئ", "ي")
            .replace("الشيخ", "")
            .replace("شيخ", "")
            .replace("الدكتور", "")
            .replace("دكتور", "")
            .replace("  ", " ")
            .trim()
    }

    private fun fetchSurahs() {
        viewModelScope.launch {
            _isSurahsLoading.value = true
            _surahs.value = repository.getSurahs()
            _isSurahsLoading.value = false
        }
    }

    private fun observeDownloads() {
        viewModelScope.launch {
            repository.allDownloads.collectLatest {
                _downloadedSurahs.value = it
            }
        }
    }

    fun selectReciter(reciter: Reciter) {
        _selectedReciter.value = reciter
    }

    fun downloadSurah(reciter: Reciter, moshaf: Moshaf, surah: Surah) {
        val downloadId = "${reciter.id}_${surah.number}"
        if (_downloadedSurahs.value.any { it.id == downloadId }) return

        val surahStr = String.format("%03d", surah.number)
        val baseUrl = moshaf.server.let { if (it.endsWith("/")) it else "$it/" }
        val url = "$baseUrl$surahStr.mp3"
        val fileName = "${reciter.name}_${surah.name}".replace(" ", "_") + ".mp3"
        
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("تنزيل ${surah.name}")
            .setDescription("بصوت ${reciter.name}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(getApplication(), Environment.DIRECTORY_MUSIC, fileName)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)

        val downloadManager = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        downloadManager.enqueue(request)

        // Ideally, we'd wait for completion to save to DB. 
        // For simplicity, we can assume it's starting or use a BroadcastReceiver.
        // Let's add it to DB now with a placeholder or handle it via a receiver.
        viewModelScope.launch {
            val path = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.absolutePath + File.separator + fileName
            repository.saveDownload(
                DownloadedSurah(
                    id = "${reciter.id}_${surah.number}",
                    reciterId = reciter.id,
                    reciterName = reciter.name,
                    surahNumber = surah.number,
                    surahName = surah.name,
                    localPath = path,
                    serverUrl = url
                )
            )
        }
    }

    fun deleteDownload(downloadId: String) {
        viewModelScope.launch {
            repository.deleteDownload(downloadId)
        }
    }
}
