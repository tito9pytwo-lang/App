package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.example.data.model.Surah
import com.example.ui.QuranViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.rememberMediaController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahListScreen(
    viewModel: QuranViewModel,
    onBack: () -> Unit
) {
    val reciter by viewModel.selectedReciter.collectAsState()
    val surahs by viewModel.surahs.collectAsState()
    val isSurahsLoading by viewModel.isSurahsLoading.collectAsState()
    val downloads by viewModel.downloadedSurahs.collectAsState()
    val mediaController by rememberMediaController()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(reciter?.name ?: "السور", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            mediaController?.let { controller ->
                com.example.ui.components.MiniPlayer(controller)
            }
        }
    ) { innerPadding ->
        if (reciter == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لم يتم اختيار قارئ")
            }
        } else {
            if (isSurahsLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                val moshaf = reciter!!.moshaf.firstOrNull()
                val availableSurahs = moshaf?.surahList?.split(",") ?: emptyList()
                
                val filteredSurahs = surahs.filter { 
                    availableSurahs.contains(it.number.toString()) 
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    items(filteredSurahs) { surah ->
                        val isDownloaded = downloads.any { it.reciterId == reciter!!.id && it.surahNumber == surah.number }
                        SurahItem(
                            surah = surah,
                            isDownloaded = isDownloaded,
                        onPlay = {
                            // Create playlist starting from this surah to support autoplay
                            val startIndex = filteredSurahs.indexOf(surah)
                            val playlist = filteredSurahs.drop(startIndex).map { s ->
                                val sDownloaded = downloads.any { it.reciterId == reciter!!.id && it.surahNumber == s.number }
                                val sUrl = if (sDownloaded) {
                                    val path = downloads.find { it.reciterId == reciter!!.id && it.surahNumber == s.number }?.localPath ?: ""
                                    Uri.fromFile(java.io.File(path)).toString()
                                } else {
                                    val sStr = String.format("%03d", s.number)
                                    val baseUrl = moshaf?.server?.let { if (it.endsWith("/")) it else "$it/" } ?: ""
                                    "$baseUrl$sStr.mp3"
                                }
                                MediaItem.Builder()
                                    .setUri(sUrl)
                                    .setMediaMetadata(
                                        MediaMetadata.Builder()
                                            .setTitle(s.name)
                                            .setArtist(reciter!!.name)
                                            .build()
                                    )
                                    .build()
                            }
                            
                            mediaController?.setMediaItems(playlist)
                            mediaController?.prepare()
                            mediaController?.play()
                        },
                            onDownload = {
                                moshaf?.let { viewModel.downloadSurah(reciter!!, it, surah) }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SurahItem(
    surah: Surah,
    isDownloaded: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit
) {
    ListItem(
        headlineContent = { Text("${surah.number}. ${surah.name}", fontWeight = FontWeight.SemiBold) },
        supportingContent = { 
            val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
            Text("$type • ${surah.numberOfAyahs} آية") 
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isDownloaded) {
                    Text("تم التنزيل", fontSize = 10.sp, color = Color.Gray)
                } else {
                    IconButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, contentDescription = "تنزيل")
                    }
                }
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل")
                }
            }
        },
        modifier = Modifier.clickable { onPlay() }
    )
}

