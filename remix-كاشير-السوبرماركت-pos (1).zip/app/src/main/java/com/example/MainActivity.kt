package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.InvoiceWithItems
import com.example.ui.PosViewModel
import com.example.ui.components.AssignShortcutDialog
import com.example.ui.components.DataTransferDialog
import com.example.ui.components.PosAddProductDialog
import com.example.ui.model.PosTab
import com.example.ui.screens.PosMainScreen
import com.example.ui.screens.ProductsManagementScreen
import com.example.ui.screens.SalesHistoryScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Arabic RTL Layout Direction
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        PosApp(modifier = Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}

@Composable
fun PosApp(
    viewModel: PosViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val shortcutProducts by viewModel.shortcutProducts.collectAsStateWithLifecycle()
    val allInvoices by viewModel.allInvoices.collectAsStateWithLifecycle()
    val totalSalesAmount by viewModel.totalSalesAmount.collectAsStateWithLifecycle()
    val totalInvoiceCount by viewModel.totalInvoiceCount.collectAsStateWithLifecycle()

    // Handle back button on secondary screens
    if (uiState.activeTab != PosTab.POS) {
        BackHandler {
            viewModel.setActiveTab(PosTab.POS)
        }
    }

    when (uiState.activeTab) {
        PosTab.POS -> {
            PosMainScreen(
                uiState = uiState,
                allProducts = allProducts,
                shortcutProducts = shortcutProducts,
                salesCount = totalInvoiceCount,
                onCodeChange = { viewModel.setManualCodeInput(it) },
                onSubmitCode = { viewModel.submitManualCode() },
                onBarcodeScanned = { barcode -> viewModel.onBarcodeScanned(barcode) },
                onSelectItem = { index -> viewModel.selectCartItem(index) },
                onIncrementItem = { index ->
                    viewModel.selectCartItem(index)
                    viewModel.incrementSelectedQuantity(1.0)
                },
                onDecrementItem = { index ->
                    viewModel.selectCartItem(index)
                    viewModel.decrementSelectedQuantity(1.0)
                },
                onDeleteItem = { index ->
                    viewModel.selectCartItem(index)
                    viewModel.deleteSelectedCartItem()
                },
                onNumPadModeChange = { mode -> viewModel.setNumPadMode(mode) },
                onNumPadKeyPress = { key -> viewModel.onNumPadKeyPress(key) },
                onNumPadApply = { viewModel.applyNumPadBuffer() },
                onSetQuantityFromBuffer = { viewModel.setQuantityFromBuffer() },
                onCashClick = { viewModel.openPaymentDialog() },
                onHoldInvoice = { viewModel.holdCurrentInvoice() },
                onRecallHeldInvoice = { heldCart -> viewModel.recallHeldInvoice(heldCart) },
                onNewInvoice = { viewModel.startNewInvoice() },
                onOpenScanner = { viewModel.setScannerOpen(true) },
                onCloseScanner = { viewModel.setScannerOpen(false) },
                onOpenQuickProducts = { viewModel.setQuickProductsSheetOpen(true) },
                onCloseQuickProducts = { viewModel.setQuickProductsSheetOpen(false) },
                onSelectQuickProduct = { product ->
                    viewModel.addProductToCart(product, 1.0)
                },
                onOpenAddProduct = { barcode -> viewModel.openAddProductDialog(barcode) },
                onCloseAddProduct = { viewModel.closeAddProductDialog() },
                onSaveProduct = { product, addToCart ->
                    viewModel.saveProduct(product, addToCart)
                },
                onOpenAssignShortcut = { targetProduct ->
                    viewModel.openAssignShortcutDialog(targetProduct)
                },
                onCloseAssignShortcut = { viewModel.closeAssignShortcutDialog() },
                onSaveShortcutCode = { productId, shortcutCode ->
                    viewModel.assignShortcutCode(productId, shortcutCode)
                },
                onOpenDataTransfer = { viewModel.openDataTransferDialog() },
                onCloseDataTransfer = { viewModel.closeDataTransferDialog() },
                onExportAndShare = { viewModel.exportAndShareData(context) },
                onImportFromUri = { uri -> viewModel.importDataFromUri(context, uri) },
                onConfirmCashPayment = {
                    viewModel.completeCashPayment()
                },
                onClosePaymentDialog = { viewModel.closePaymentDialog() },
                onSelectTab = { tab -> viewModel.setActiveTab(tab) },
                onDismissBanner = { viewModel.dismissBanner() },
                onProceedRegisterUnregistered = { viewModel.proceedToRegisterUnregisteredProduct() },
                onDismissUnregisteredPrompt = { viewModel.dismissUnregisteredPrompt() },
                onOpenMultipleVariantsSetting = { viewModel.openMultipleVariantsSetting() },
                onCloseMultipleVariantsSetting = { viewModel.closeMultipleVariantsSetting() },
                onSelectProductVariant = { product -> viewModel.selectProductVariant(product) },
                onDismissAmbiguousBarcodeDialog = { viewModel.dismissAmbiguousBarcodeDialog() },
                onAddNewVariantForBarcode = { barcode, price -> viewModel.openAddProductDialog(barcode, price) },
                modifier = modifier
            )
        }

        PosTab.PRODUCTS -> {
            ProductsManagementScreen(
                products = allProducts,
                onAddProductClick = { viewModel.openAddProductDialog(null) },
                onAssignShortcut = { product -> viewModel.openAssignShortcutDialog(product) },
                onDeleteProduct = { product -> viewModel.deleteProduct(product) },
                onAddToCart = { product -> viewModel.addProductToCart(product, 1.0) },
                onBackToPos = { viewModel.setActiveTab(PosTab.POS) },
                onOpenMultipleVariantsSetting = { viewModel.openMultipleVariantsSetting() },
                modifier = modifier
            )

            if (uiState.isAddProductDialogOpen) {
                PosAddProductDialog(
                    initialBarcode = uiState.unregisteredBarcode,
                    initialPrice = uiState.presetAddProductPrice,
                    existingProducts = allProducts,
                    onSaveProduct = { product, addToCart ->
                        viewModel.saveProduct(product, addToCart)
                    },
                    onDismiss = { viewModel.closeAddProductDialog() }
                )
            }

            if (uiState.isMultipleVariantsSettingsOpen) {
                com.example.ui.components.MultipleProductsSettingsDialog(
                    allProducts = allProducts,
                    onAddNewProductWithBarcode = { barcode, defaultPrice ->
                        viewModel.closeMultipleVariantsSetting()
                        viewModel.openAddProductDialog(barcode, defaultPrice)
                    },
                    onDismiss = { viewModel.closeMultipleVariantsSetting() }
                )
            }

            if (uiState.isAssignShortcutDialogOpen) {
                AssignShortcutDialog(
                    products = allProducts,
                    initialTargetProduct = uiState.shortcutAssignmentTargetProduct,
                    initialCode = uiState.pendingShortcutCodeToAssign,
                    onSaveShortcut = { productId, shortcutCode ->
                        viewModel.assignShortcutCode(productId, shortcutCode)
                    },
                    onDismiss = { viewModel.closeAssignShortcutDialog() }
                )
            }
        }

        PosTab.SALES -> {
            SalesHistoryScreen(
                invoices = allInvoices,
                totalSalesAmount = totalSalesAmount,
                totalInvoiceCount = totalInvoiceCount,
                onViewReceipt = {},
                onBackToPos = { viewModel.setActiveTab(PosTab.POS) },
                modifier = modifier
            )
        }
    }
}
