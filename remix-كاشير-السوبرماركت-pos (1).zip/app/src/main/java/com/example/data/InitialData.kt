package com.example.data

import com.example.data.model.ProductEntity

object InitialData {
    // No pre-packaged products as requested by user - user adds their own products exclusively
    val sampleProducts: List<ProductEntity> = emptyList()
}
