package com.example.data.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupImportResult(
    val productsImported: Int,
    val invoicesImported: Int,
    val errorMessage: String? = null
)

object PosBackupManager {

    /**
     * Serializes all products and completed sales invoices into clean, structured JSON.
     */
    fun createBackupJson(
        products: List<ProductEntity>,
        invoices: List<InvoiceWithItems>
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("appName", "POS_Supermarket")
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("exportDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(Date()))

        // Products Array
        val productsArray = JSONArray()
        products.forEach { prod ->
            val pObj = JSONObject()
            pObj.put("name", prod.name)
            pObj.put("barcode", prod.barcode ?: "")
            pObj.put("shortcutCode", prod.shortcutCode ?: "")
            pObj.put("price", prod.price)
            pObj.put("costPrice", prod.costPrice)
            pObj.put("unit", prod.unit)
            pObj.put("category", prod.category)
            pObj.put("iconEmoji", prod.iconEmoji)
            pObj.put("isShortcut", prod.isShortcut)
            productsArray.put(pObj)
        }
        root.put("products", productsArray)

        // Invoices Array
        val invoicesArray = JSONArray()
        invoices.forEach { invWithItems ->
            val inv = invWithItems.invoice
            val iObj = JSONObject()
            iObj.put("invoiceNumber", inv.invoiceNumber)
            iObj.put("timestamp", inv.timestamp)
            iObj.put("totalAmount", inv.totalAmount)
            iObj.put("paidAmount", inv.paidAmount)
            iObj.put("changeAmount", inv.changeAmount)
            iObj.put("paymentMethod", inv.paymentMethod)
            iObj.put("itemCount", inv.itemCount)
            iObj.put("cashierName", inv.cashierName)

            val itemsArray = JSONArray()
            invWithItems.items.forEach { item ->
                val itObj = JSONObject()
                itObj.put("productId", item.productId)
                itObj.put("productName", item.productName)
                itObj.put("barcode", item.barcode ?: "")
                itObj.put("quantity", item.quantity)
                itObj.put("unitPrice", item.unitPrice)
                itObj.put("totalPrice", item.totalPrice)
                itObj.put("unit", item.unit)
                itemsArray.put(itObj)
            }
            iObj.put("items", itemsArray)
            invoicesArray.put(iObj)
        }
        root.put("invoices", invoicesArray)

        return root.toString(2)
    }

    /**
     * Parses a backup JSON string and returns parsed products and invoices.
     */
    fun parseBackupJson(jsonString: String): Pair<List<ProductEntity>, List<Pair<SaleInvoiceEntity, List<SaleItemEntity>>>> {
        val root = JSONObject(jsonString)

        val products = mutableListOf<ProductEntity>()
        val productsArray = root.optJSONArray("products") ?: JSONArray()
        for (i in 0 until productsArray.length()) {
            val pObj = productsArray.getJSONObject(i)
            val barcodeStr = pObj.optString("barcode").trim().ifEmpty { null }
            val shortcutCodeStr = pObj.optString("shortcutCode").trim().ifEmpty { null }

            val product = ProductEntity(
                name = pObj.getString("name"),
                barcode = barcodeStr,
                shortcutCode = shortcutCodeStr,
                price = pObj.getDouble("price"),
                costPrice = pObj.optDouble("costPrice", 0.0),
                unit = pObj.optString("unit", "قطعة"),
                category = pObj.optString("category", "عام"),
                iconEmoji = pObj.optString("iconEmoji", "📦"),
                isShortcut = pObj.optBoolean("isShortcut", false)
            )
            products.add(product)
        }

        val invoicesWithItems = mutableListOf<Pair<SaleInvoiceEntity, List<SaleItemEntity>>>()
        val invoicesArray = root.optJSONArray("invoices") ?: JSONArray()
        for (i in 0 until invoicesArray.length()) {
            val iObj = invoicesArray.getJSONObject(i)
            val invoice = SaleInvoiceEntity(
                invoiceNumber = iObj.getString("invoiceNumber"),
                timestamp = iObj.getLong("timestamp"),
                totalAmount = iObj.getDouble("totalAmount"),
                paidAmount = iObj.getDouble("paidAmount"),
                changeAmount = iObj.optDouble("changeAmount", 0.0),
                paymentMethod = iObj.optString("paymentMethod", "كاش"),
                itemCount = iObj.optInt("itemCount", 0),
                cashierName = iObj.optString("cashierName", "كاشير 1")
            )

            val items = mutableListOf<SaleItemEntity>()
            val itemsArray = iObj.optJSONArray("items") ?: JSONArray()
            for (j in 0 until itemsArray.length()) {
                val itObj = itemsArray.getJSONObject(j)
                val item = SaleItemEntity(
                    invoiceId = 0L, // will be assigned on db insert
                    productId = itObj.optLong("productId", 0L),
                    productName = itObj.getString("productName"),
                    barcode = itObj.optString("barcode").ifEmpty { null },
                    quantity = itObj.getDouble("quantity"),
                    unitPrice = itObj.getDouble("unitPrice"),
                    totalPrice = itObj.getDouble("totalPrice"),
                    unit = itObj.optString("unit", "قطعة")
                )
                items.add(item)
            }
            invoicesWithItems.add(Pair(invoice, items))
        }

        return Pair(products, invoicesWithItems)
    }

    /**
     * Writes backup JSON to a cache file and launches Android Share Sheet to send to another phone.
     */
    fun shareBackupFile(context: Context, backupJson: String) {
        val dateSuffix = SimpleDateFormat("yyyyMMdd_HHmm", Locale.ENGLISH).format(Date())
        val fileName = "pos_backup_$dateSuffix.json"
        val cacheFile = File(context.cacheDir, fileName)

        FileOutputStream(cacheFile).use { fos ->
            fos.write(backupJson.toByteArray(Charsets.UTF_8))
        }

        val authority = "${context.packageName}.fileprovider"
        val contentUri: Uri = FileProvider.getUriForFile(context, authority, cacheFile)

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية لبيانات الكاشير ($dateSuffix)")
            putExtra(
                Intent.EXTRA_TEXT,
                "ملف بيانات الكاشير (منتجات ومبيعات). افتحه في التطبيق على الهاتف الآخر لاستيراد البيانات مباشرة."
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(shareIntent, "إرسال البيانات إلى هاتف آخر عبر:")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * Reads text content from a picked file Uri.
     */
    fun readBackupFromUri(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).use { reader ->
                    reader.readText()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
