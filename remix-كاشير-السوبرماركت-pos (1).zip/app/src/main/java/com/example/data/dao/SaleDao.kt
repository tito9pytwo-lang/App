package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.InvoiceWithItems
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SaleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: SaleInvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSaleItems(items: List<SaleItemEntity>)

    @Transaction
    @Query("SELECT * FROM sale_invoices ORDER BY timestamp DESC")
    fun getAllInvoicesWithItems(): Flow<List<InvoiceWithItems>>

    @Transaction
    @Query("SELECT * FROM sale_invoices ORDER BY timestamp DESC")
    suspend fun getAllInvoicesWithItemsList(): List<InvoiceWithItems>

    @Transaction
    @Query("SELECT * FROM sale_invoices WHERE invoiceId = :invoiceId")
    suspend fun getInvoiceWithItemsById(invoiceId: Long): InvoiceWithItems?

    @Query("SELECT COUNT(*) FROM sale_invoices")
    fun getTotalInvoiceCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(totalAmount), 0.0) FROM sale_invoices")
    fun getTotalSalesAmount(): Flow<Double>

    @Query("SELECT COALESCE(SUM(totalAmount), 0.0) FROM sale_invoices WHERE timestamp >= :startOfDayTimestamp")
    fun getTodaySalesAmount(startOfDayTimestamp: Long): Flow<Double>
}
