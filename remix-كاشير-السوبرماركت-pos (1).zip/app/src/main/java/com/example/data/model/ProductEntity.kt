package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    indices = [
        Index(value = ["barcode"], unique = false),
        Index(value = ["shortcutCode"], unique = false)
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val barcode: String? = null,
    val shortcutCode: String? = null, // كود الاختصار السريع من لوحة الأرقام (مثل: "0" للبيض، "1" للخبز...)
    val price: Double,
    val costPrice: Double = 0.0,
    val unit: String = "قطعة", // قطعة أو كجم أو لتر
    val isShortcut: Boolean = false, // اختصار سريع في الشاشة الرئيسية
    val iconEmoji: String = "📦", // إيموجي للتعريف السريع
    val category: String = "عام",
    val stockQuantity: Double = 100.0,
    val createdAt: Long = System.currentTimeMillis()
)
