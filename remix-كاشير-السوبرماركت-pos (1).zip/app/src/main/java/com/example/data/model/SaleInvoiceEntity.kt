package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sale_invoices")
data class SaleInvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val invoiceId: Long = 0,
    val invoiceNumber: String,
    val timestamp: Long = System.currentTimeMillis(),
    val totalAmount: Double,
    val paidAmount: Double,
    val changeAmount: Double,
    val paymentMethod: String = "كاش", // كاش أو شبكة
    val itemCount: Int,
    val cashierName: String = "كاشير 1"
)
