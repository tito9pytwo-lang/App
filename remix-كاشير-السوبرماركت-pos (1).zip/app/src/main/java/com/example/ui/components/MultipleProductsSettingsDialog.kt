package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProductEntity
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.util.BarcodeMatcher
import com.example.ui.util.NumberUtils

private enum class MultiScanTarget {
    SEARCH,
    ADD_VARIANT
}

@Composable
fun MultipleProductsSettingsDialog(
    allProducts: List<ProductEntity>,
    onAddNewProductWithBarcode: (barcode: String?, basePrice: Double?) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var isCameraScannerOpen by remember { mutableStateOf(false) }
    var scanTarget by remember { mutableStateOf(MultiScanTarget.ADD_VARIANT) }

    // Group products by normalized barcode (only barcodes with 1+ products)
    val barcodeGroups = remember(allProducts, searchQuery) {
        val nonBlank = allProducts.filter { !it.barcode.isNullOrBlank() }
        val grouped = nonBlank.groupBy { BarcodeMatcher.normalizeBarcode(it.barcode) }

        val normQuery = BarcodeMatcher.normalizeBarcode(searchQuery)
        grouped.filter { (barcode, list) ->
            searchQuery.isBlank() ||
                    barcode.contains(normQuery.ifEmpty { searchQuery.trim() }) ||
                    list.any { it.name.contains(searchQuery.trim(), ignoreCase = true) }
        }.toList()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFFE0F2FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = PosBluePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "الأصناف المتعددة لنفس الباركود",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "تسجيل نكهات أو أشكال مختلفة بنفس الباركود",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Informational Banner
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                ) {
                    Text(
                        text = "💡 تتيح لك هذه الميزة تسجيل منتجات بأشكال أو نكهات مختلفة تشترك في نفس الباركود ونفس السعر. عند مسح الباركود يظهر لك خيار سريع لاختيار الشكل المطلوب.",
                        fontSize = 12.sp,
                        color = Color(0xFF1E40AF),
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                // Search & Filter with Camera Scanner Button
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث بالباركود أو اسم الصنف...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PosBluePrimary) },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح", tint = Color(0xFF64748B))
                                }
                            }
                            IconButton(
                                onClick = {
                                    scanTarget = MultiScanTarget.SEARCH
                                    isCameraScannerOpen = true
                                },
                                modifier = Modifier.testTag("btn_scanner_in_multiple_settings")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "مسح الباركود بالكاميرا",
                                    tint = Color(0xFF16A34A)
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )

                // Prominent Camera Scan Action Button for adding variants/shapes
                Button(
                    onClick = {
                        scanTarget = MultiScanTarget.ADD_VARIANT
                        isCameraScannerOpen = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_scan_camera_multiple_settings")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("📷 مسح باركود بالكاميرا لإضافة شكل أو نكهة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // List of Barcodes with their variants
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (barcodeGroups.isEmpty()) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = if (searchQuery.isNotBlank())
                                            "لا توجد باركودات مسجلة تطابق: $searchQuery"
                                        else
                                            "لا توجد باركودات مسجلة حالياً",
                                        color = Color(0xFF64748B),
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )

                                    if (searchQuery.isNotBlank()) {
                                        Button(
                                            onClick = {
                                                val clean = BarcodeMatcher.normalizeBarcode(searchQuery)
                                                onDismiss()
                                                onAddNewProductWithBarcode(clean, null)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تسجيل صنف جديد بهذا الباركود", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        items(barcodeGroups) { (barcode, variants) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "باركود: $barcode",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = PosBluePrimary
                                        )
                                        Surface(
                                            color = if (variants.size > 1) Color(0xFFECFDF5) else Color(0xFFF1F5F9),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (variants.size > 1) "${variants.size} أشكال / نكهات" else "شكل واحد",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (variants.size > 1) Color(0xFF047857) else Color(0xFF64748B),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    // Variant Names
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        variants.forEach { v ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.White, RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (v.iconEmoji.isNotBlank()) {
                                                        Text(v.iconEmoji, fontSize = 16.sp, modifier = Modifier.padding(end = 6.dp))
                                                    }
                                                    Text(v.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                                Text(
                                                    text = "${NumberUtils.formatNumber(v.price)} ر.س",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF1E293B)
                                                )
                                            }
                                        }
                                    }

                                    // Add variant button for this barcode
                                    val basePrice = variants.firstOrNull()?.price
                                    Button(
                                        onClick = {
                                            onDismiss()
                                            onAddNewProductWithBarcode(barcode, basePrice)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(38.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إضافة شكل/نكهة جديدة لهذا الباركود", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Action: Add completely new product
                Button(
                    onClick = {
                        onDismiss()
                        onAddNewProductWithBarcode(null, null)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PosGreenCashLight),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_add_new_barcode_item")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إضافة صنف جديد تماماً", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }

        // Camera Barcode Scanner for Multiple Products Settings Dialog
        if (isCameraScannerOpen) {
            PosScannerDialog(
                onBarcodeScanned = { rawCode ->
                    val clean = BarcodeMatcher.normalizeBarcode(rawCode)
                    isCameraScannerOpen = false
                    if (clean.isNotBlank()) {
                        when (scanTarget) {
                            MultiScanTarget.SEARCH -> {
                                searchQuery = clean
                            }
                            MultiScanTarget.ADD_VARIANT -> {
                                val existingVariants = allProducts.filter {
                                    BarcodeMatcher.normalizeBarcode(it.barcode) == clean
                                }
                                val basePrice = existingVariants.firstOrNull()?.price
                                onDismiss()
                                onAddNewProductWithBarcode(clean, basePrice)
                            }
                        }
                    }
                },
                onDismiss = { isCameraScannerOpen = false }
            )
        }
    }
}
