package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.CartItem
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosTableRowAlternate
import com.example.ui.theme.PosTableRowSelected
import com.example.ui.util.NumberUtils

@Composable
fun PosCartTable(
    cartItems: List<CartItem>,
    selectedIndex: Int?,
    onSelectItem: (Int) -> Unit,
    onIncrementItem: (Int) -> Unit = {},
    onDecrementItem: (Int) -> Unit = {},
    onDeleteItem: (Int) -> Unit = {},
    onOpenAddProduct: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto-scroll to selected or newly added item
    LaunchedEffect(selectedIndex, cartItems.size) {
        if (selectedIndex != null && selectedIndex in cartItems.indices) {
            listState.animateScrollToItem(selectedIndex)
        } else if (cartItems.isNotEmpty()) {
            listState.animateScrollToItem(cartItems.lastIndex)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .border(1.5.dp, Color(0xFF64B5F6), RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        color = Color.White
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Table Header Bar with Order: اسم المنتج -> الكمية -> السعر -> الإجمالي
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PosBlueHeader)
                    .height(IntrinsicSize.Min)
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Column 1: اسم المنتج (Product Name)
                Text(
                    text = "اسم المنتج",
                    modifier = Modifier
                        .weight(2.6f)
                        .padding(horizontal = 8.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Start
                )

                VerticalDivider(color = Color(0x55FFFFFF), modifier = Modifier.fillMaxHeight().width(1.dp))

                // Column 2: الكمية (Quantity) - أولاً قبل السعر كما طُلب
                Text(
                    text = "الكمية",
                    modifier = Modifier
                        .weight(0.9f)
                        .padding(horizontal = 2.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                VerticalDivider(color = Color(0x55FFFFFF), modifier = Modifier.fillMaxHeight().width(1.dp))

                // Column 3: السعر (Price) - ثانياً بعد الكمية
                Text(
                    text = "السعر",
                    modifier = Modifier
                        .weight(1.0f)
                        .padding(horizontal = 2.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                VerticalDivider(color = Color(0x55FFFFFF), modifier = Modifier.fillMaxHeight().width(1.dp))

                // Column 4: الإجمالي (Total) - ثالثاً الإجمالي
                Text(
                    text = "الإجمالي",
                    modifier = Modifier
                        .weight(1.2f)
                        .padding(horizontal = 4.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Table Body
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFFB0BEC5)
                        )
                        Text(
                            text = "لا توجد منتجات في الفاتورة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF455A64)
                        )
                        Text(
                            text = "امسح الباركود، أو اكتب رقم اختصار الصنف من لوحة الأرقام",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = onOpenAddProduct,
                            colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("empty_cart_add_product_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("➕ إضافة منتج جديد إلى المخزن", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(cartItems, key = { _, item -> item.cartItemId }) { index, item ->
                        val isSelected = selectedIndex == index
                        val rowBg = when {
                            isSelected -> PosTableRowSelected
                            index % 2 == 1 -> PosTableRowAlternate
                            else -> Color.White
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .clickable { onSelectItem(index) }
                                .testTag("cart_row_$index")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Column 1: اسم المنتج (Product Name & Barcode)
                                Column(
                                    modifier = Modifier
                                        .weight(2.6f)
                                        .padding(horizontal = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (item.product.iconEmoji.isNotBlank()) {
                                            Text(
                                                text = item.product.iconEmoji,
                                                fontSize = 16.sp,
                                                modifier = Modifier.padding(end = 4.dp)
                                            )
                                        }
                                        Text(
                                            text = item.product.name,
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF0F172A),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (!item.product.barcode.isNullOrBlank()) {
                                        Text(
                                            text = item.product.barcode,
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B),
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }

                                VerticalDivider(color = Color(0xFFE2E8F0), modifier = Modifier.fillMaxHeight().width(1.dp))

                                // Column 2: الكمية (Quantity) - أولاً قبل السعر كما طُلب
                                val qtyFormatted = NumberUtils.formatNumber(item.quantity)
                                Text(
                                    text = qtyFormatted,
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .padding(horizontal = 2.dp),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = PosBluePrimary,
                                    textAlign = TextAlign.Center
                                )

                                VerticalDivider(color = Color(0xFFE2E8F0), modifier = Modifier.fillMaxHeight().width(1.dp))

                                // Column 3: السعر (Unit Price) - ثانياً بعد الكمية
                                val priceFormatted = NumberUtils.formatNumber(item.unitPrice)
                                Text(
                                    text = priceFormatted,
                                    modifier = Modifier
                                        .weight(1.0f)
                                        .padding(horizontal = 2.dp),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1E293B),
                                    textAlign = TextAlign.Center
                                )

                                VerticalDivider(color = Color(0xFFE2E8F0), modifier = Modifier.fillMaxHeight().width(1.dp))

                                // Column 4: الإجمالي (Total Price)
                                val totalFormatted = NumberUtils.formatNumber(item.totalPrice)
                                Text(
                                    text = totalFormatted,
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .padding(horizontal = 4.dp),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = Color(0xFF0F172A),
                                    textAlign = TextAlign.Center
                                )
                            }

                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                        }
                    }
                }
            }
        }
    }
}
