package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.model.CartItem
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCash
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.util.NumberUtils

@Composable
fun PosCashPaymentDialog(
    cartItems: List<CartItem>,
    totalAmount: Double,
    onConfirmPayment: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.96f)
                .clip(RoundedCornerShape(18.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header (Large, High Contrast)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color(0xFFE8F5E9), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                tint = PosGreenCashLight,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "ملخص الكاش والبيع",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "${cartItems.size} منتجات ممسوحة",
                                fontSize = 13.sp,
                                color = Color(0xFF64748B),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", modifier = Modifier.size(26.dp))
                    }
                }

                // Table of scanned items (اسم الصنف، الكمية، السعر، الإجمالي) with large text
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF90CAF9))
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Header Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PosBlueHeader)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الصنف", modifier = Modifier.weight(2.4f), fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                            Text("الكمية", modifier = Modifier.weight(1.1f), fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White, textAlign = TextAlign.Center)
                            Text("السعر", modifier = Modifier.weight(1.1f), fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White, textAlign = TextAlign.Center)
                            Text("الإجمالي", modifier = Modifier.weight(1.3f), fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White, textAlign = TextAlign.End)
                        }

                        // Scanned Items List with high-contrast, legible text
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                        ) {
                            itemsIndexed(cartItems) { index, item ->
                                val rowBg = if (index % 2 == 1) Color(0xFFF8FAFC) else Color.White
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(rowBg)
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Product Name
                                    Text(
                                        text = item.product.name,
                                        modifier = Modifier.weight(2.4f),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    // Quantity
                                    Text(
                                        text = NumberUtils.formatNumber(item.quantity),
                                        modifier = Modifier.weight(1.1f),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = PosBluePrimary,
                                        textAlign = TextAlign.Center
                                    )

                                    // Unit Price
                                    Text(
                                        text = NumberUtils.formatNumber(item.unitPrice),
                                        modifier = Modifier.weight(1.1f),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF334155),
                                        textAlign = TextAlign.Center
                                    )

                                    // Line Total
                                    Text(
                                        text = NumberUtils.formatNumber(item.totalPrice),
                                        modifier = Modifier.weight(1.3f),
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF0F172A),
                                        textAlign = TextAlign.End
                                    )
                                }
                                Divider(color = Color(0xFFE2E8F0))
                            }
                        }
                    }
                }

                // Grand Total Box (Extra Large, Crystal Clear LED Display)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
                        .border(2.dp, Color(0xFF00E676), RoundedCornerShape(12.dp))
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "الإجمالي النهائي المطلوب",
                                color = Color(0xFFA7F3D0),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "مجموع كافة الأصناف الممسوحة",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }

                        Text(
                            text = NumberUtils.formatNumber(totalAmount),
                            color = Color(0xFF00E676),
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }

                // Finish Sale Button (Big, Bold, 60dp height)
                Button(
                    onClick = onConfirmPayment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .testTag("confirm_cash_simple_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PosGreenCashLight
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(28.dp),
                            tint = Color.White
                        )
                        Text(
                            text = "تأكيد الكاش وإنهاء البيع",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}
