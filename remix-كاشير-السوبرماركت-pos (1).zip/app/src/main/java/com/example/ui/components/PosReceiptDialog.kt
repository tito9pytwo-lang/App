package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.InvoiceWithItems
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PosReceiptDialog(
    invoiceWithItems: InvoiceWithItems,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val invoice = invoiceWithItems.invoice
    val dateStr = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.getDefault()).format(Date(invoice.timestamp))

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Success Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = PosGreenCashLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "تم حفظ وطباعة الفاتورة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = PosGreenCashLight
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Printable Receipt Slip (Monospace style look)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                        .background(Color(0xFFFCFDFE))
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "سوبرماركت المدينة",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "فاتورة بيع ضريبية مبسطة",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "رقم الفاتورة: ${invoice.invoiceNumber}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "التاريخ: $dateStr",
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )
                        Text(
                            text = "الكاشير: ${invoice.cashierName} | طريقة الدفع: ${invoice.paymentMethod}",
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )

                        Divider(color = Color(0xFF94A3B8), thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        // Items
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            items(invoiceWithItems.items) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(2f)) {
                                        Text(
                                            text = item.productName,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString()
                                        Text(
                                            text = "$qtyStr × ${String.format(Locale.ENGLISH, "%.2f", item.unitPrice)}",
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                    Text(
                                        text = "${String.format(Locale.ENGLISH, "%.2f", item.totalPrice)} ر.س",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f),
                                        textAlign = TextAlign.End
                                    )
                                }
                            }
                        }

                        Divider(color = Color(0xFF94A3B8), thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        // Totals
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الإجمالي الكلي:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${String.format(Locale.ENGLISH, "%.2f", invoice.totalAmount)} ر.س", fontWeight = FontWeight.Black, fontSize = 15.sp, color = PosBluePrimary)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("المبلغ المدفوع:", fontSize = 12.sp, color = Color(0xFF475569))
                            Text("${String.format(Locale.ENGLISH, "%.2f", invoice.paidAmount)} ر.س", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الباقي للعميل:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PosGreenCashLight)
                            Text("${String.format(Locale.ENGLISH, "%.2f", invoice.changeAmount)} ر.س", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PosGreenCashLight)
                        }

                        Text(
                            text = "شكراً لزيارتكم! نتمنى لكم يوماً سعيداً",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }

                // Action Buttons
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("receipt_new_invoice_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("بدء فاتورة جديدة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
