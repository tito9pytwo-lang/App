package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PosGreenCash
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.theme.PosOrangePrice
import com.example.ui.theme.PosRedDelete

@Composable
fun PosSideControls(
    onCashClick: () -> Unit,
    onSetQuantityFromBuffer: () -> Unit,
    onQuickProductsClick: () -> Unit,
    onScannerClick: () -> Unit,
    onIncrementSelected: () -> Unit,
    onDecrementSelected: () -> Unit,
    onDeleteSelected: () -> Unit,
    onNewInvoiceClick: () -> Unit,
    hasSelectedItem: Boolean,
    bufferText: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(2.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Large CASH Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(PosGreenCashLight, PosGreenCash)
                    )
                )
                .border(2.dp, Color(0xFF81C784), RoundedCornerShape(10.dp))
                .clickable { onCashClick() }
                .testTag("pos_cash_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = "كاش",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = "كاش (Cash)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        // Direct Set Quantity Button: "تعيين الكمية إلى [X]"
        val qtyLabel = if (bufferText.isNotBlank()) "تحديد الكمية ($bufferText)" else "تحديد الكمية بالرقم"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(
                    if (bufferText.isNotBlank()) Brush.horizontalGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1)))
                    else Brush.horizontalGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
                )
                .clickable { onSetQuantityFromBuffer() }
                .testTag("btn_set_quantity_buffer")
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Text(
                    text = qtyLabel,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Increment & Decrement row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2E7D32))
                    .clickable { onIncrementSelected() }
                    .testTag("btn_side_increment"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "زيادة 1", tint = Color.White)
                    Text("+1", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF57C00))
                    .clickable { onDecrementSelected() }
                    .testTag("btn_side_decrement"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "إنقاص 1", tint = Color.White)
                    Text("-1", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        // Barcode Scanner button
        PosSideButton(
            title = "مسح باركود",
            subtitle = "كاميرا الهاتف",
            icon = Icons.Default.QrCodeScanner,
            bgColors = listOf(Color(0xFF00897B), Color(0xFF00695C)),
            onClick = onScannerClick,
            testTag = "btn_open_camera_scanner"
        )

        // Quick Products (اختصارات سريعة)
        PosSideButton(
            title = "أصناف سريعة",
            subtitle = "أصناف بدون باركود",
            icon = Icons.Default.Bolt,
            bgColors = listOf(Color(0xFF1E88E5), Color(0xFF1565C0)),
            onClick = onQuickProductsClick,
            testTag = "btn_quick_products"
        )

        // Delete selected item (X)
        PosSideButton(
            title = "حذف صنف (X)",
            subtitle = "إزالة من الفاتورة",
            icon = Icons.Default.Delete,
            bgColors = listOf(Color(0xFFE53935), PosRedDelete),
            onClick = onDeleteSelected,
            testTag = "btn_delete_item"
        )

        // Clear / New Invoice button
        PosSideButton(
            title = "تفريغ الفاتورة",
            subtitle = "بدء عملية بيع جديدة",
            icon = Icons.Default.NoteAdd,
            bgColors = listOf(Color(0xFF475569), Color(0xFF334155)),
            onClick = onNewInvoiceClick,
            testTag = "btn_new_invoice"
        )
    }
}

@Composable
private fun PosSideButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    bgColors: List<Color>,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Brush.horizontalGradient(bgColors))
            .clickable { onClick() }
            .testTag(testTag)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = Color(0xFFCBD5E1),
                    fontSize = 9.sp
                )
            }
        }
    }
}
