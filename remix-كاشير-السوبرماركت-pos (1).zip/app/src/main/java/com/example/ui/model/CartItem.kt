package com.example.ui.model

import com.example.data.model.ProductEntity
import com.example.data.model.SaleItemEntity
import java.util.UUID

data class CartItem(
    val cartItemId: String = UUID.randomUUID().toString(),
    val product: ProductEntity,
    val quantity: Double = 1.0,
    val unitPrice: Double = product.price
) {
    val totalPrice: Double
        get() = quantity * unitPrice

    fun toSaleItem(invoiceId: Long = 0): SaleItemEntity {
        return SaleItemEntity(
            invoiceId = invoiceId,
            productId = product.id,
            productName = product.name,
            barcode = product.barcode,
            quantity = quantity,
            unitPrice = unitPrice,
            totalPrice = totalPrice,
            unit = product.unit
        )
    }
}

enum class NumPadMode(val title: String) {
    BARCODE("كود / اختصار"),
    QUANTITY("الكمية"),
    PRICE("السعر"),
    CASH_PAID("المدفوع")
}

enum class PosTab(val title: String) {
    POS("نقطة البيع (الكاشير)"),
    PRODUCTS("إدارة الأصناف والمنتجات"),
    SALES("سجل الفواتير والمبيعات")
}
