package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// POS Supermarket Terminal Color Palette
val PosBluePrimary = Color(0xFF0D47A1)
val PosBlueSecondary = Color(0xFF1976D2)
val PosBlueSurface = Color(0xFFE3F2FD)
val PosBlueHeader = Color(0xFF0B3880)

val PosGreenCash = Color(0xFF1B5E20)
val PosGreenCashLight = Color(0xFF2E7D32)
val PosGreenAccent = Color(0xFF00C853)
val PosDigitalLed = Color(0xFF00E676)
val PosDigitalBg = Color(0xFF0D1B2A)

val PosRedDelete = Color(0xFFC62828)
val PosOrangePrice = Color(0xFFE65100)
val PosYellowWarning = Color(0xFFF57F17)

val PosTableBorder = Color(0xFFB0BEC5)
val PosTableRowAlternate = Color(0xFFF8FAFC)
val PosTableRowSelected = Color(0xFFBBDEFB)

val PosSurface = Color(0xFFF4F6F9)
val PosOnSurface = Color(0xFF1E293B)
val PosCardBg = Color(0xFFFFFFFF)
