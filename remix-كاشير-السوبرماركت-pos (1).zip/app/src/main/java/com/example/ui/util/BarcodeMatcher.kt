package com.example.ui.util

import android.util.Log
import com.example.data.model.ProductEntity

object BarcodeMatcher {

    private const val TAG = "PosBarcodeLookup"

    /**
     * Normalizes a barcode string according to strict retail POS requirements:
     * 1. Preserves the barcode as a String (never converts to Int, Long, or Double).
     * 2. Preserves all leading zeros (e.g. "0123456789" stays "0123456789").
     * 3. Normalizes Arabic-Indic digits (٠-٩) and Eastern digits (۰-۹) to standard Western digits (0-9).
     * 4. Strips leading, trailing, and internal whitespace/spaces/newlines/carriage returns/tabs.
     * 5. Strips invisible characters (BOM \uFEFF, zero-width spaces \u200B..\u200F, \u2060, control characters).
     */
    fun normalizeBarcode(input: String?): String {
        if (input.isNullOrBlank()) return ""

        val sb = StringBuilder(input.length)
        for (char in input) {
            when (char) {
                // Arabic-Indic digits ٠-٩ -> 0-9
                '٠' -> sb.append('0')
                '١' -> sb.append('1')
                '٢' -> sb.append('2')
                '٣' -> sb.append('3')
                '٤' -> sb.append('4')
                '٥' -> sb.append('5')
                '٦' -> sb.append('6')
                '٧' -> sb.append('7')
                '٨' -> sb.append('8')
                '٩' -> sb.append('9')

                // Eastern Arabic-Indic digits ۰-۹ -> 0-9
                '۰' -> sb.append('0')
                '۱' -> sb.append('1')
                '۲' -> sb.append('2')
                '۳' -> sb.append('3')
                '۴' -> sb.append('4')
                '۵' -> sb.append('5')
                '۶' -> sb.append('6')
                '۷' -> sb.append('7')
                '۸' -> sb.append('8')
                '۹' -> sb.append('9')

                // Whitespace, line-breaks, tabs (remove completely)
                ' ', '\t', '\r', '\n', '\u00A0', '\u1680',
                '\u2000', '\u2001', '\u2002', '\u2003', '\u2004', '\u2005', '\u2006',
                '\u2007', '\u2008', '\u2009', '\u200A', '\u202F', '\u205F', '\u3000' -> {
                    // skip whitespace
                }

                // Invisible and zero-width characters (remove completely)
                '\uFEFF', '\u200B', '\u200C', '\u200D', '\u200E', '\u200F',
                '\u2028', '\u2029', '\u2060', '\u0000' -> {
                    // skip invisible
                }

                else -> {
                    // Skip ISO control characters
                    if (!char.isISOControl()) {
                        sb.append(char)
                    }
                }
            }
        }

        return sb.toString().trim()
    }

    /**
     * Performs exact string comparison between the scanned code and the product barcode.
     * Both strings are normalized first.
     */
    fun isExactMatch(scannedCode: String, productBarcode: String?): Boolean {
        val normScanned = normalizeBarcode(scannedCode)
        val normProd = normalizeBarcode(productBarcode)
        return normScanned.isNotEmpty() && normScanned == normProd
    }

    /**
     * Checks if a scanned code matches a product either by exact barcode OR exact shortcut code.
     */
    fun isMatch(scannedCode: String, product: ProductEntity): Boolean {
        val normScanned = normalizeBarcode(scannedCode)
        if (normScanned.isEmpty()) return false

        val normBarcode = normalizeBarcode(product.barcode)
        if (normBarcode.isNotEmpty() && normScanned == normBarcode) {
            return true
        }

        val normShortcut = normalizeBarcode(product.shortcutCode)
        if (normShortcut.isNotEmpty() && normScanned == normShortcut) {
            return true
        }

        // Standard UPC-A (12 digits) to EAN-13 (13 digits with leading zero) compatibility
        if (normScanned.length in 12..13 && normBarcode.length in 12..13) {
            if (normScanned.length == 13 && normScanned.startsWith("0") && normScanned.substring(1) == normBarcode) {
                return true
            }
            if (normBarcode.length == 13 && normBarcode.startsWith("0") && normBarcode.substring(1) == normScanned) {
                return true
            }
        }

        return false
    }

    /**
     * Finds the matching product from a list of products.
     * Priority 1: Exact match on barcode (Barcode -> Barcode).
     * Priority 2: Exact match on shortcut code.
     * Priority 3: UPC-A (12 digits) vs EAN-13 (13 digits starting with 0) standard compatibility.
     * Does NOT use product name or fuzzy string similarity.
     */
    fun findMatch(scannedCode: String, products: List<ProductEntity>): ProductEntity? {
        val normScanned = normalizeBarcode(scannedCode)
        if (normScanned.isEmpty()) return null

        // 1. Exact match on Barcode
        val exactBarcode = products.firstOrNull { prod ->
            val b = normalizeBarcode(prod.barcode)
            b.isNotEmpty() && b == normScanned
        }
        if (exactBarcode != null) return exactBarcode

        // 2. Exact match on Shortcut Code
        val exactShortcut = products.firstOrNull { prod ->
            val s = normalizeBarcode(prod.shortcutCode)
            s.isNotEmpty() && s == normScanned
        }
        if (exactShortcut != null) return exactShortcut

        // 3. UPC-A (12) vs EAN-13 (13 starting with 0)
        if (normScanned.length in 12..13) {
            val upcEanMatch = products.firstOrNull { prod ->
                val b = normalizeBarcode(prod.barcode)
                (normScanned.length == 13 && normScanned.startsWith("0") && normScanned.substring(1) == b) ||
                        (b.length == 13 && b.startsWith("0") && b.substring(1) == normScanned)
            }
            if (upcEanMatch != null) return upcEanMatch
        }

        return null
    }

    /**
     * Finds ALL matching products for a barcode/QR code.
     * Used when multiple variants, shapes, or flavors share the same barcode.
     */
    fun findAllMatches(scannedCode: String, products: List<ProductEntity>): List<ProductEntity> {
        val normScanned = normalizeBarcode(scannedCode)
        if (normScanned.isEmpty()) return emptyList()

        // 1. All products matching exact barcode
        val barcodeMatches = products.filter { prod ->
            val b = normalizeBarcode(prod.barcode)
            b.isNotEmpty() && b == normScanned
        }
        if (barcodeMatches.isNotEmpty()) return barcodeMatches

        // 2. All products matching exact shortcut code
        val shortcutMatches = products.filter { prod ->
            val s = normalizeBarcode(prod.shortcutCode)
            s.isNotEmpty() && s == normScanned
        }
        if (shortcutMatches.isNotEmpty()) return shortcutMatches

        // 3. UPC-A (12) vs EAN-13 (13 starting with 0)
        if (normScanned.length in 12..13) {
            val upcMatches = products.filter { prod ->
                val b = normalizeBarcode(prod.barcode)
                (normScanned.length == 13 && normScanned.startsWith("0") && normScanned.substring(1) == b) ||
                        (b.length == 13 && b.startsWith("0") && b.substring(1) == normScanned)
            }
            if (upcMatches.isNotEmpty()) return upcMatches
        }

        return emptyList()
    }

    /**
     * Logs diagnostic output strictly matching the requested format:
     *
     * MATCH FOUND:
     * SCANNED BARCODE: 6281001234567
     * NORMALIZED BARCODE: 6281001234567
     * DATABASE SEARCH: 6281001234567
     * MATCH FOUND: YES
     * PRODUCT NAME: منتج ABC
     * PRODUCT PRICE: 10
     *
     * NO MATCH:
     * SCANNED BARCODE: 6281001234567
     * NORMALIZED BARCODE: 6281001234567
     * DATABASE SEARCH: 6281001234567
     * MATCH FOUND: NO
     */
    fun logDiagnostic(
        scannedBarcode: String,
        normalizedBarcode: String,
        foundProduct: ProductEntity?
    ) {
        val searchKey = normalizedBarcode

        try {
            Log.d(TAG, "SCANNED BARCODE: $scannedBarcode")
            Log.d(TAG, "NORMALIZED BARCODE: $normalizedBarcode")
            Log.d(TAG, "DATABASE SEARCH: $searchKey")
            if (foundProduct != null) {
                Log.d(TAG, "MATCH FOUND: YES")
                Log.d(TAG, "PRODUCT NAME: ${foundProduct.name}")
                val priceFormatted = formatPrice(foundProduct.price)
                Log.d(TAG, "PRODUCT PRICE: $priceFormatted")
            } else {
                Log.d(TAG, "MATCH FOUND: NO")
            }
        } catch (_: Exception) {
            // In unit tests or environments without Android Log implementation
        }

        // Also print to standard stdout for immediate inspection in build logs and tests
        println("SCANNED BARCODE: $scannedBarcode")
        println("NORMALIZED BARCODE: $normalizedBarcode")
        println("DATABASE SEARCH: $searchKey")
        if (foundProduct != null) {
            println("MATCH FOUND: YES")
            println("PRODUCT NAME: ${foundProduct.name}")
            println("PRODUCT PRICE: ${formatPrice(foundProduct.price)}")
        } else {
            println("MATCH FOUND: NO")
        }
    }

    private fun formatPrice(price: Double): String {
        return if (price % 1.0 == 0.0) {
            price.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.2f", price).trimEnd('0').trimEnd('.')
        }
    }
}
