package com.example.ui.util

import java.util.Locale

object NumberUtils {
    /**
     * Formats prices and quantities without currency symbols and without unnecessary decimals:
     * e.g. 3.0 -> "3"
     *      3.5 -> "3.5"
     *      3.75 -> "3.75"
     */
    fun formatNumber(value: Double): String {
        return if (value % 1.0 == 0.0) {
            value.toLong().toString()
        } else {
            val formatted = String.format(Locale.ENGLISH, "%.2f", value)
            formatted.replace(Regex("\\.?0+$"), "")
        }
    }
}
