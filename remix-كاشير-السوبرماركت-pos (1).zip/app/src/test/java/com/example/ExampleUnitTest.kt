package com.example

import com.example.ui.util.NumberUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun number_formatting_no_trailing_decimals_or_currency() {
        assertEquals("3", NumberUtils.formatNumber(3.0))
        assertEquals("100", NumberUtils.formatNumber(100.0))
        assertEquals("3.5", NumberUtils.formatNumber(3.5))
        assertEquals("3.75", NumberUtils.formatNumber(3.75))
        assertEquals("0", NumberUtils.formatNumber(0.0))
    }
}
