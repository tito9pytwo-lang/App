package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ProductBarcodeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductBarcodeDao {
    @Query("SELECT * FROM product_barcodes WHERE parentProductId = :parentProductId ORDER BY id ASC")
    fun getBarcodesForProduct(parentProductId: Long): Flow<List<ProductBarcodeEntity>>

    @Query("SELECT * FROM product_barcodes WHERE parentProductId = :parentProductId ORDER BY id ASC")
    suspend fun getBarcodesForProductList(parentProductId: Long): List<ProductBarcodeEntity>

    @Query("SELECT * FROM product_barcodes ORDER BY id ASC")
    fun getAllBarcodes(): Flow<List<ProductBarcodeEntity>>

    @Query("SELECT * FROM product_barcodes ORDER BY id ASC")
    suspend fun getAllBarcodesList(): List<ProductBarcodeEntity>

    @Query("SELECT * FROM product_barcodes WHERE barcode = :barcode OR trim(barcode) = :barcode LIMIT 1")
    suspend fun getBarcodeEntity(barcode: String): ProductBarcodeEntity?

    @Query("SELECT * FROM product_barcodes WHERE barcode = :barcode OR trim(barcode) = :barcode ORDER BY id ASC")
    suspend fun getBarcodeEntities(barcode: String): List<ProductBarcodeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBarcode(barcodeEntity: ProductBarcodeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBarcodes(barcodes: List<ProductBarcodeEntity>)

    @Delete
    suspend fun deleteBarcode(barcodeEntity: ProductBarcodeEntity)

    @Query("DELETE FROM product_barcodes WHERE id = :id")
    suspend fun deleteBarcodeById(id: Long)

    @Query("DELETE FROM product_barcodes WHERE parentProductId = :parentProductId")
    suspend fun deleteBarcodesForProduct(parentProductId: Long)
}
