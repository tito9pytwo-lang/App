package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products ORDER BY name ASC")
    suspend fun getAllProductsList(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE isShortcut = 1 OR shortcutCode IS NOT NULL ORDER BY name ASC")
    fun getShortcutProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun getProductByBarcode(barcode: String): ProductEntity?

    @Query("SELECT * FROM products WHERE shortcutCode = :shortcutCode LIMIT 1")
    suspend fun getProductByShortcutCode(shortcutCode: String): ProductEntity?

    @Query("SELECT * FROM products WHERE barcode = :code OR shortcutCode = :code LIMIT 1")
    suspend fun getProductByBarcodeOrShortcut(code: String): ProductEntity?

    @Query("SELECT * FROM products WHERE trim(barcode) = :code OR trim(shortcutCode) = :code OR barcode = :code OR shortcutCode = :code LIMIT 1")
    suspend fun getProductByTrimmedBarcodeOrShortcut(code: String): ProductEntity?

    @Query("SELECT * FROM products WHERE barcode = :code OR shortcutCode = :code OR trim(barcode) = :code OR trim(shortcutCode) = :code ORDER BY id ASC")
    suspend fun getProductsByBarcodeOrShortcut(code: String): List<ProductEntity>

    @Query("SELECT * FROM products WHERE barcode IN (:candidates) OR shortcutCode IN (:candidates)")
    suspend fun getProductsByCandidates(candidates: List<String>): List<ProductEntity>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): ProductEntity?

    @Query("SELECT * FROM products WHERE parentProductId = :parentProductId ORDER BY name ASC")
    fun getChildProducts(parentProductId: Long): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE parentProductId = :parentProductId ORDER BY name ASC")
    suspend fun getChildProductsList(parentProductId: Long): List<ProductEntity>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%' OR shortcutCode LIKE '%' || :query || '%'")
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun getProductCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET shortcutCode = :shortcutCode WHERE id = :productId")
    suspend fun updateShortcutCode(productId: Long, shortcutCode: String?)

    @Query("UPDATE products SET parentProductId = :parentProductId WHERE id = :productId")
    suspend fun updateParentProductId(productId: Long, parentProductId: Long?)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)
}
