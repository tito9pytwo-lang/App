package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entity for linking multiple barcodes (e.g. different flavors or shapes)
 * to a single Parent Product (المنتج الرئيسي).
 *
 * When any linked barcode is scanned, the POS identifies the Parent Product,
 * adds it to the cart, or increments its quantity if already present, ensuring
 * that all flavors/shapes update the same single cart row.
 */
@Entity(
    tableName = "product_barcodes",
    indices = [
        Index(value = ["barcode"], unique = false),
        Index(value = ["parentProductId"], unique = false)
    ]
)
data class ProductBarcodeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val parentProductId: Long, // ID of the parent ProductEntity
    val barcode: String,       // The scanned barcode/QR code
    val label: String? = null, // Optional label/flavor e.g. "فراولة", "نعناع", "عنب"
    val createdAt: Long = System.currentTimeMillis()
)
