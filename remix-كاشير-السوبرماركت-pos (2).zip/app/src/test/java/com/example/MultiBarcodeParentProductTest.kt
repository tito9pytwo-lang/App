package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.model.ProductBarcodeEntity
import com.example.data.model.ProductEntity
import com.example.data.repository.PosRepository
import com.example.ui.PosUiState
import com.example.ui.model.CartItem
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MultiBarcodeParentProductTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: PosRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = PosRepository(db.productDao(), db.productBarcodeDao(), db.saleDao())
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `scanning three distinct barcodes linked to one parent product increments quantity on a single cart line to 3`() = runBlocking {
        // 1. Create Parent Product: «علكة متنوعة» with price 100.0
        val parentProduct = ProductEntity(
            name = "علكة متنوعة",
            price = 100.0,
            unit = "قطعة"
        )
        val parentId = db.productDao().insertProduct(parentProduct)
        assertTrue(parentId > 0)

        // 2. Link 3 distinct barcodes representing different flavors/types to the Parent Product:
        // - 1111: علكة الفراولة
        // - 2222: علكة النعناع
        // - 3333: علكة العنب
        repository.addBarcodeToProduct(parentId, "1111", "علكة الفراولة")
        repository.addBarcodeToProduct(parentId, "2222", "علكة النعناع")
        repository.addBarcodeToProduct(parentId, "3333", "علكة العنب")

        // 3. Create an independent product with barcode 9999
        val pepsi = ProductEntity(
            name = "بيبسي",
            barcode = "9999",
            price = 15.0,
            unit = "علبة"
        )
        val pepsiId = db.productDao().insertProduct(pepsi)
        assertTrue(pepsiId > 0)

        // Helper simulation of cart addition matching PosViewModel.addProductToCart logic
        var cartState = PosUiState()

        fun simulateAddToCart(product: ProductEntity, qtyToAdd: Double = 1.0) {
            val targetProductId = if (product.parentProductId != null && product.parentProductId > 0) product.parentProductId else product.id
            val existingIndex = cartState.cartItems.indexOfFirst { item ->
                val itemTargetId = if (item.product.parentProductId != null && item.product.parentProductId > 0) item.product.parentProductId else item.product.id
                (targetProductId > 0 && itemTargetId > 0 && targetProductId == itemTargetId) ||
                        (item.product.id > 0 && product.id > 0 && item.product.id == product.id)
            }

            val updatedCart = if (existingIndex >= 0) {
                cartState.cartItems.mapIndexed { index, item ->
                    if (index == existingIndex) {
                        item.copy(quantity = item.quantity + qtyToAdd)
                    } else {
                        item
                    }
                }
            } else {
                cartState.cartItems + CartItem(
                    product = product,
                    quantity = qtyToAdd,
                    unitPrice = product.price
                )
            }

            cartState = cartState.copy(cartItems = updatedCart)
        }

        fun simulateBarcodeScan(scannedCode: String) {
            val matched = runBlocking { repository.findProductsByBarcode(scannedCode) }
            if (matched.isNotEmpty()) {
                simulateAddToCart(matched.first(), 1.0)
            }
        }

        // --- Step 1: Scan Barcode 1111 (Strawberry flavor) ---
        simulateBarcodeScan("1111")
        assertEquals(1, cartState.cartItems.size)
        assertEquals("علكة متنوعة", cartState.cartItems[0].product.name)
        assertEquals(1.0, cartState.cartItems[0].quantity, 0.001)
        assertEquals(100.0, cartState.cartItems[0].unitPrice, 0.001)
        assertEquals(100.0, cartState.cartItems[0].totalPrice, 0.001)
        assertEquals(100.0, cartState.totalAmount, 0.001)

        // --- Step 2: Scan Barcode 2222 (Mint flavor) ---
        simulateBarcodeScan("2222")
        // MUST NOT create a new row! Must update existing row
        assertEquals(1, cartState.cartItems.size)
        assertEquals("علكة متنوعة", cartState.cartItems[0].product.name)
        assertEquals(2.0, cartState.cartItems[0].quantity, 0.001)
        assertEquals(100.0, cartState.cartItems[0].unitPrice, 0.001)
        assertEquals(200.0, cartState.cartItems[0].totalPrice, 0.001)
        assertEquals(200.0, cartState.totalAmount, 0.001)

        // --- Step 3: Scan Barcode 3333 (Grape flavor) ---
        simulateBarcodeScan("3333")
        // MUST NOT create a new row! Must update existing row to 3
        assertEquals(1, cartState.cartItems.size)
        assertEquals("علكة متنوعة", cartState.cartItems[0].product.name)
        assertEquals(3.0, cartState.cartItems[0].quantity, 0.001)
        assertEquals(100.0, cartState.cartItems[0].unitPrice, 0.001)
        assertEquals(300.0, cartState.cartItems[0].totalPrice, 0.001)
        assertEquals(300.0, cartState.totalAmount, 0.001)

        // --- Step 4: Scan Independent Product Barcode 9999 (Pepsi) ---
        simulateBarcodeScan("9999")
        // MUST NOT merge with parent product! Must create a distinct second row
        assertEquals(2, cartState.cartItems.size)
        // Row 1: علكة متنوعة
        assertEquals("علكة متنوعة", cartState.cartItems[0].product.name)
        assertEquals(3.0, cartState.cartItems[0].quantity, 0.001)
        assertEquals(300.0, cartState.cartItems[0].totalPrice, 0.001)
        // Row 2: بيبسي
        assertEquals("بيبسي", cartState.cartItems[1].product.name)
        assertEquals(1.0, cartState.cartItems[1].quantity, 0.001)
        assertEquals(15.0, cartState.cartItems[1].totalPrice, 0.001)
        // Total sum = 300 + 15 = 315
        assertEquals(315.0, cartState.totalAmount, 0.001)

        // --- Step 5: Scan Unregistered Barcode 8888 ---
        val unregisteredMatches = repository.findProductsByBarcode("8888")
        assertTrue("Unregistered barcode must return empty list", unregisteredMatches.isEmpty())
        // Cart remains untouched
        assertEquals(2, cartState.cartItems.size)
        assertEquals(315.0, cartState.totalAmount, 0.001)
    }

    @Test
    fun `adding a new barcode to parent product works without creating a new parent product`() = runBlocking {
        // Create parent product
        val parent = ProductEntity(name = "عصير طبيعي مشكل", price = 12.0)
        val parentId = db.productDao().insertProduct(parent)

        // Initially no linked barcodes
        val initialList = repository.getBarcodesForProductList(parentId)
        assertEquals(0, initialList.size)

        // Add orange flavor barcode
        val bcId1 = repository.addBarcodeToProduct(parentId, "6280001", "برتقال")
        assertTrue(bcId1 > 0)

        // Add mango flavor barcode
        val bcId2 = repository.addBarcodeToProduct(parentId, "6280002", "مانجو")
        assertTrue(bcId2 > 0)

        val updatedList = repository.getBarcodesForProductList(parentId)
        assertEquals(2, updatedList.size)
        assertEquals("6280001", updatedList[0].barcode)
        assertEquals("برتقال", updatedList[0].label)
        assertEquals("6280002", updatedList[1].barcode)
        assertEquals("مانجو", updatedList[1].label)

        // Searching by either barcode returns the same parent product
        val foundOrange = repository.findProductsByBarcode("6280001")
        assertEquals(1, foundOrange.size)
        assertEquals("عصير طبيعي مشكل", foundOrange[0].name)
        assertEquals(12.0, foundOrange[0].price, 0.001)

        val foundMango = repository.findProductsByBarcode("6280002")
        assertEquals(1, foundMango.size)
        assertEquals("عصير طبيعي مشكل", foundMango[0].name)
        assertEquals(12.0, foundMango[0].price, 0.001)

        // Delete orange barcode
        repository.removeBarcode(bcId1)
        val afterDelete = repository.getBarcodesForProductList(parentId)
        assertEquals(1, afterDelete.size)
        assertEquals("6280002", afterDelete[0].barcode)
    }
}
