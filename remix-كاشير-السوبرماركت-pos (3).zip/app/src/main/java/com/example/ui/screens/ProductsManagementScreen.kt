package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductBarcodeEntity
import com.example.data.model.ProductEntity
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.theme.PosRedDelete
import com.example.ui.util.BarcodeMatcher
import com.example.ui.util.NumberUtils

@Composable
fun ProductsManagementScreen(
    products: List<ProductEntity>,
    allProductBarcodes: List<ProductBarcodeEntity> = emptyList(),
    onAddProductClick: () -> Unit,
    onAssignShortcut: (ProductEntity) -> Unit,
    onManageBarcodes: (ProductEntity) -> Unit = {},
    onDeleteProduct: (ProductEntity) -> Unit,
    onAddToCart: (ProductEntity) -> Unit,
    onBackToPos: () -> Unit,
    onOpenMultipleVariantsSetting: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var isCameraScannerOpen by remember { mutableStateOf(false) }

    val categories = listOf("الكل", "مخبوزات", "ألبان وبيض", "خضروات", "فواكه", "مشروبات", "حلويات", "تسالي", "بقالة", "عام")

    val filteredProducts = remember(products, allProductBarcodes, searchQuery, selectedCategory) {
        val normQuery = BarcodeMatcher.normalizeBarcode(searchQuery)
        products.filter { product ->
            val matchesCategory = selectedCategory == "الكل" || product.category == selectedCategory
            val linkedCodes = allProductBarcodes.filter { it.parentProductId == product.id }
            val matchesLinkedBarcode = linkedCodes.any {
                BarcodeMatcher.normalizeBarcode(it.barcode).contains(normQuery.ifEmpty { searchQuery.trim() }) ||
                        (!it.label.isNullOrBlank() && it.label.contains(searchQuery.trim(), ignoreCase = true))
            }
            val matchesQuery = searchQuery.isBlank() ||
                    product.name.contains(searchQuery.trim(), ignoreCase = true) ||
                    (!product.barcode.isNullOrBlank() && BarcodeMatcher.normalizeBarcode(product.barcode).contains(normQuery.ifEmpty { searchQuery.trim() })) ||
                    (!product.shortcutCode.isNullOrBlank() && BarcodeMatcher.normalizeBarcode(product.shortcutCode).contains(normQuery.ifEmpty { searchQuery.trim() })) ||
                    matchesLinkedBarcode
            matchesCategory && matchesQuery
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFFF8FAFC)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Screen Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PosBlueHeader)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onBackToPos,
                        modifier = Modifier.background(Color(0x33FFFFFF), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "العودة للكاشير",
                            tint = Color.White
                        )
                    }
                    Column {
                        Text(
                            text = "إدارة المنتجات والأصناف",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "إجمالي ${products.size} صنف مسجل محلياً",
                            color = Color(0xFF90CAF9),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onOpenMultipleVariantsSetting,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color(0x66FFFFFF)),
                        modifier = Modifier.testTag("btn_multiple_variants_mgmt")
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("باركود متعدد", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
                    }

                    Button(
                        onClick = onAddProductClick,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PosGreenCashLight),
                        modifier = Modifier.testTag("btn_add_product_screen")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة صنف", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }

            // Search & Category Filters
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن صنف بالاسم أو الباركود أو رقم الاختصار...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = PosBluePrimary)
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح", tint = Color(0xFF64748B))
                                }
                            }
                            IconButton(
                                onClick = { isCameraScannerOpen = true },
                                modifier = Modifier.testTag("btn_scan_in_products_mgmt")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "مسح الباركود بالكاميرا",
                                    tint = Color(0xFF16A34A)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_products_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PosBluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Product List
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "لا توجد منتجات مضافة بعد",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onAddProductClick,
                            colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary)
                        ) {
                            Text("➕ اضغط هنا لإضافة أول صنف")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        val linkedCount = allProductBarcodes.count { it.parentProductId == product.id }
                        val hasShortcut = !product.shortcutCode.isNullOrBlank()
                        val hasMultipleSameBarcode = !product.barcode.isNullOrBlank() &&
                                products.count { it.barcode?.trim() == product.barcode.trim() } > 1

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Top Section: Emoji + Product Details + Delete Button
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Product Icon / Emoji
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(Color(0xFFE3F2FD), RoundedCornerShape(10.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(product.iconEmoji, fontSize = 24.sp)
                                    }

                                    // Main Info Column - takes all available horizontal space so product name NEVER splits!
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        // Product Name (clear, prominent, never squeezed)
                                        Text(
                                            text = product.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = Color(0xFF1E293B),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        // Badges row if any
                                        if (hasShortcut || linkedCount > 0 || hasMultipleSameBarcode) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (hasShortcut) {
                                                    Box(
                                                        modifier = Modifier
                                                            .background(PosBluePrimary, RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "اختصار: ${product.shortcutCode}",
                                                            fontSize = 11.sp,
                                                            color = Color.White,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                                if (linkedCount > 0) {
                                                    Box(
                                                        modifier = Modifier
                                                            .background(Color(0xFFE0E7FF), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "🔗 $linkedCount نكهات/باركودات",
                                                            fontSize = 11.sp,
                                                            color = Color(0xFF3730A3),
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                } else if (hasMultipleSameBarcode) {
                                                    Box(
                                                        modifier = Modifier
                                                            .background(Color(0xFFE0F2FE), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "🏷️ أشكال متعددة",
                                                            fontSize = 11.sp,
                                                            color = PosBluePrimary,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Barcode and Unit
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = if (product.barcode.isNullOrBlank()) "بدون باركود" else "باركود: ${product.barcode}",
                                                fontSize = 12.sp,
                                                color = Color(0xFF64748B)
                                            )
                                            Text(
                                                text = "• ${product.unit}",
                                                fontSize = 12.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }

                                        // Unit Price
                                        Text(
                                            text = "السعر: ${NumberUtils.formatNumber(product.price)}",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 15.sp,
                                            color = PosGreenCashLight
                                        )
                                    }

                                    // Delete Button at top corner
                                    IconButton(
                                        onClick = { onDeleteProduct(product) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف المنتج",
                                            tint = PosRedDelete
                                        )
                                    }
                                }

                                // Subtle divider between info and actions
                                HorizontalDivider(color = Color(0xFFF1F5F9))

                                // Bottom Actions Row: beautifully organized, responsive, wide buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Manage Barcodes / Flavors Button
                                    OutlinedButton(
                                        onClick = { onManageBarcodes(product) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PosBluePrimary),
                                        border = BorderStroke(1.dp, PosBluePrimary.copy(alpha = 0.5f)),
                                        modifier = Modifier
                                            .weight(1.3f)
                                            .height(38.dp)
                                            .testTag("btn_manage_barcodes_${product.id}")
                                    ) {
                                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (linkedCount > 0) "نكهات ($linkedCount)" else "ربط باركود",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }

                                    // Shortcut code button
                                    OutlinedButton(
                                        onClick = { onAssignShortcut(product) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF475569)),
                                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                        modifier = Modifier
                                            .weight(0.9f)
                                            .height(38.dp)
                                    ) {
                                        Icon(Icons.Default.Dialpad, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("كود", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    }

                                    // Add to Cart Button
                                    Button(
                                        onClick = {
                                            onAddToCart(product)
                                            onBackToPos()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        modifier = Modifier
                                            .weight(1.1f)
                                            .height(38.dp)
                                    ) {
                                        Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إضافة", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isCameraScannerOpen) {
            com.example.ui.components.PosScannerDialog(
                onBarcodeScanned = { rawCode ->
                    val clean = com.example.ui.util.BarcodeMatcher.normalizeBarcode(rawCode)
                    if (clean.isNotBlank()) {
                        searchQuery = clean
                    }
                    isCameraScannerOpen = false
                },
                onDismiss = { isCameraScannerOpen = false }
            )
        }
    }
}
