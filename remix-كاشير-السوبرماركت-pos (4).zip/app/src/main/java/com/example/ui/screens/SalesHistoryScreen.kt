package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterAltOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InvoiceWithItems
import com.example.ui.components.PosReceiptDialog
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.util.NumberUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class SalesDateFilter(val label: String) {
    ALL("الكل"),
    TODAY("اليوم"),
    LAST_7_DAYS("آخر 7 أيام"),
    THIS_MONTH("هذا الشهر"),
    CUSTOM("نطاق مخصص 📅")
}

enum class SalesSortOrder(val label: String) {
    NEWEST_FIRST("الأحدث أولاً ⬇️"),
    OLDEST_FIRST("الأقدم أولاً ⬆️")
}

@Composable
fun SalesHistoryScreen(
    invoices: List<InvoiceWithItems>,
    totalSalesAmount: Double,
    totalInvoiceCount: Int,
    onViewReceipt: (InvoiceWithItems) -> Unit,
    onBackToPos: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Search and Filter State
    var searchQuery by remember { mutableStateOf("") }
    var selectedDateFilter by remember { mutableStateOf(SalesDateFilter.ALL) }
    var sortOrder by remember { mutableStateOf(SalesSortOrder.NEWEST_FIRST) }

    // Custom Date Range State (start & end of day timestamps in ms)
    var customStartDate by remember { mutableStateOf<Long?>(null) }
    var customEndDate by remember { mutableStateOf<Long?>(null) }
    var isCustomRangeDialogOpen by remember { mutableStateOf(false) }

    // Expanded Cards State (track expanded invoice IDs independently)
    var expandedInvoiceId by remember { mutableStateOf<Long?>(null) }

    // Selected invoice for receipt preview dialog
    var receiptToView by remember { mutableStateOf<InvoiceWithItems?>(null) }

    // Incremental loading limit to guarantee silky smooth rendering with thousands of records
    var visibleLimit by remember { mutableIntStateOf(50) }

    // Helper Date Formatter for search matching and display
    val fullDateFormatter = remember { SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale.getDefault()) }
    val dayDateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }

    // Filter and Sort in-memory with high performance
    val filteredInvoices = remember(
        invoices,
        searchQuery,
        selectedDateFilter,
        customStartDate,
        customEndDate,
        sortOrder
    ) {
        val trimmedQuery = searchQuery.trim().lowercase()

        val list = invoices.filter { itemWithInvoice ->
            val inv = itemWithInvoice.invoice
            val timestamp = inv.timestamp

            // 1. Date Range Check
            val matchesDate = when (selectedDateFilter) {
                SalesDateFilter.ALL -> true
                SalesDateFilter.TODAY -> {
                    val startOfDay = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    timestamp >= startOfDay
                }
                SalesDateFilter.LAST_7_DAYS -> {
                    val sevenDaysAgo = Calendar.getInstance().apply {
                        add(Calendar.DAY_OF_YEAR, -6)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    timestamp >= sevenDaysAgo
                }
                SalesDateFilter.THIS_MONTH -> {
                    val startOfMonth = Calendar.getInstance().apply {
                        set(Calendar.DAY_OF_MONTH, 1)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    timestamp >= startOfMonth
                }
                SalesDateFilter.CUSTOM -> {
                    val start = customStartDate ?: 0L
                    val end = customEndDate ?: Long.MAX_VALUE
                    timestamp in start..end
                }
            }

            if (!matchesDate) return@filter false

            // 2. Search Query Check
            if (trimmedQuery.isEmpty()) {
                true
            } else {
                val formattedDate = fullDateFormatter.format(Date(timestamp)).lowercase()
                val matchesNumber = inv.invoiceNumber.lowercase().contains(trimmedQuery)
                val matchesDateText = formattedDate.contains(trimmedQuery)
                val matchesPayment = inv.paymentMethod.lowercase().contains(trimmedQuery)
                val matchesProduct = itemWithInvoice.items.any { item ->
                    item.productName.lowercase().contains(trimmedQuery) ||
                            (!item.barcode.isNullOrBlank() && item.barcode.contains(trimmedQuery))
                }
                matchesNumber || matchesDateText || matchesPayment || matchesProduct
            }
        }

        when (sortOrder) {
            SalesSortOrder.NEWEST_FIRST -> list.sortedByDescending { it.invoice.timestamp }
            SalesSortOrder.OLDEST_FIRST -> list.sortedBy { it.invoice.timestamp }
        }
    }

    // Dynamic Summary Stats: calculated across ALL filtered invoices matching period & query
    val filteredTotalSales = remember(filteredInvoices) {
        filteredInvoices.sumOf { it.invoice.totalAmount }
    }
    val filteredInvoiceCount = filteredInvoices.size

    // Slice for incremental loading to protect performance
    val displayedInvoices = remember(filteredInvoices, visibleLimit) {
        filteredInvoices.take(visibleLimit)
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFFF8FAFC)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // --- 1. Screen Header ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PosBlueHeader)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackToPos,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0x33FFFFFF), CircleShape)
                        .testTag("btn_back_to_pos_from_sales")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "العودة لشاشة الكاشير",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "سجل المبيعات والفواتير",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "إجمالي الفواتير المحفوظة: $totalInvoiceCount",
                        color = Color(0xFF90CAF9),
                        fontSize = 11.sp
                    )
                }
            }

            // --- 2. Top Summary Cards (إجمالي المبيعات وعدد الفواتير) ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Card 1: Total Sales (إجمالي المبيعات)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_total_sales_summary"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(Color(0xFFDCFCE7), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Payments,
                                    contentDescription = null,
                                    tint = Color(0xFF15803D),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "إجمالي المبيعات",
                                fontSize = 12.sp,
                                color = Color(0xFF166534),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = NumberUtils.formatNumber(filteredTotalSales),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = PosGreenCashLight,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (selectedDateFilter == SalesDateFilter.ALL && searchQuery.isBlank())
                                "لجميع المبيعات"
                            else
                                "للفترة والبحث المختار",
                            fontSize = 10.sp,
                            color = Color(0xFF4B5563)
                        )
                    }
                }

                // Card 2: Total Invoices Count (عدد الفواتير)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_total_invoices_count_summary"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(Color(0xFFDBEAFE), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = PosBluePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "عدد الفواتير",
                                fontSize = 12.sp,
                                color = Color(0xFF1E40AF),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$filteredInvoiceCount",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = PosBluePrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "عملية بيع مكتملة",
                            fontSize = 10.sp,
                            color = Color(0xFF4B5563)
                        )
                    }
                }
            }

            // --- 3. Search Bar ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 2.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "ابحث برقم الفاتورة، أو اسم المنتج داخلها...",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = Color(0xFF64748B)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح البحث",
                                    tint = Color(0xFF64748B)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_search_sales_invoices"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = PosBluePrimary,
                        unfocusedBorderColor = Color(0xFFCBD5E1)
                    ),
                    singleLine = true
                )
            }

            // --- 4. Date Filter Chips (Scrollable row) ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SalesDateFilter.entries.forEach { filter ->
                    val isSelected = selectedDateFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedDateFilter = filter
                            if (filter == SalesDateFilter.CUSTOM) {
                                isCustomRangeDialogOpen = true
                            }
                        },
                        label = {
                            Text(
                                text = filter.label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PosBluePrimary,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = Color(0xFF334155)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) PosBluePrimary else Color(0xFFCBD5E1),
                            selectedBorderColor = PosBluePrimary,
                            borderWidth = 1.dp,
                            selectedBorderWidth = 1.dp
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                    )
                }
            }

            // Active Custom Range Display if any
            if (selectedDateFilter == SalesDateFilter.CUSTOM && (customStartDate != null || customEndDate != null)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp)
                        .background(Color(0xFFEFF6FF), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val startStr = customStartDate?.let { dayDateFormatter.format(Date(it)) } ?: "البداية"
                    val endStr = customEndDate?.let { dayDateFormatter.format(Date(it)) } ?: "النهاية"
                    Text(
                        text = "📅 النطاق المحدد: من $startStr إلى $endStr",
                        fontSize = 11.sp,
                        color = PosBluePrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "تعديل",
                            fontSize = 11.sp,
                            color = PosBluePrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { isCustomRangeDialogOpen = true }
                                .padding(horizontal = 6.dp)
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إلغاء التصفية المخصصة",
                            tint = Color(0xFF64748B),
                            modifier = Modifier
                                .size(16.dp)
                                .clickable {
                                    customStartDate = null
                                    customEndDate = null
                                    selectedDateFilter = SalesDateFilter.ALL
                                }
                        )
                    }
                }
            }

            // --- 5. Results Count & Sort Order Bar ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (filteredInvoiceCount == invoices.size)
                        "عرض $filteredInvoiceCount فاتورة"
                    else
                        "عرض $filteredInvoiceCount من أصل ${invoices.size} فاتورة",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            sortOrder = if (sortOrder == SalesSortOrder.NEWEST_FIRST)
                                SalesSortOrder.OLDEST_FIRST
                            else
                                SalesSortOrder.NEWEST_FIRST
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("btn_toggle_sales_sort")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Sort,
                        contentDescription = "ترتيب",
                        tint = PosBluePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = sortOrder.label,
                        fontSize = 11.sp,
                        color = PosBluePrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // --- 6. Invoices List / Empty State ---
            if (filteredInvoices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color(0xFFF1F5F9), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (invoices.isEmpty()) Icons.Default.History else Icons.Default.FilterAltOff,
                                contentDescription = null,
                                modifier = Modifier.size(38.dp),
                                tint = Color(0xFF94A3B8)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (invoices.isEmpty())
                                "لا توجد فواتير مبيعات سابقة"
                            else
                                "لا توجد فواتير مطابقة لبحثك",
                            color = Color(0xFF1E293B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (invoices.isEmpty())
                                "الفواتير التي يتم إتمامها في الكاشير ستظهر هنا تلقائياً"
                            else
                                "جرّب تغيير كلمات البحث أو تغيير فترة التصفية",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        if (invoices.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            OutlinedButton(
                                onClick = {
                                    searchQuery = ""
                                    selectedDateFilter = SalesDateFilter.ALL
                                    customStartDate = null
                                    customEndDate = null
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PosBluePrimary)
                            ) {
                                Text("إعادة ضبط الفلاتر والبحث")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayedInvoices, key = { it.invoice.invoiceId }) { itemWithInvoice ->
                        val inv = itemWithInvoice.invoice
                        val isExpanded = expandedInvoiceId == inv.invoiceId
                        val dateFormatted = fullDateFormatter.format(Date(inv.timestamp))

                        // Individual Invoice Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("invoice_card_${inv.invoiceId}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(
                                width = if (isExpanded) 1.5.dp else 1.dp,
                                color = if (isExpanded) PosBluePrimary else Color(0xFFE2E8F0)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 3.dp else 1.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {

                                // --- Always Visible Card Header ---
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            expandedInvoiceId = if (isExpanded) null else inv.invoiceId
                                        }
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Left: Invoice Number & Date & Badges
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = "#${inv.invoiceNumber}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = Color(0xFF0F172A)
                                            )

                                            // Payment Method Pill
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = inv.paymentMethod,
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF475569),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }

                                            // Items count pill
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFEFF6FF), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "${itemWithInvoice.items.size} أصناف",
                                                    fontSize = 11.sp,
                                                    color = PosBluePrimary,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }

                                        Text(
                                            text = dateFormatted,
                                            fontSize = 12.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }

                                    // Right: Prominent Total & Expand Button
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = NumberUtils.formatNumber(inv.totalAmount),
                                                fontWeight = FontWeight.Black,
                                                fontSize = 18.sp,
                                                color = PosGreenCashLight
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(
                                                    if (isExpanded) PosBluePrimary else Color(0xFFF1F5F9),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                contentDescription = if (isExpanded) "إغلاق التفاصيل" else "عرض التفاصيل",
                                                tint = if (isExpanded) Color.White else Color(0xFF64748B),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }

                                // --- Expanded Structured Invoice Details (Table) ---
                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFFAFAFA))
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        HorizontalDivider(color = Color(0xFFE2E8F0))
                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Structured Arabic RTL Table Header
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFE2E8F0), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "المنتج",
                                                modifier = Modifier.weight(2.2f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF1E293B),
                                                textAlign = TextAlign.Start
                                            )
                                            Text(
                                                text = "الكمية",
                                                modifier = Modifier.weight(0.9f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF1E293B),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                text = "سعر الوحدة",
                                                modifier = Modifier.weight(1.1f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF1E293B),
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                text = "الإجمالي",
                                                modifier = Modifier.weight(1.2f),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF1E293B),
                                                textAlign = TextAlign.End
                                            )
                                        }

                                        // Table Body Rows
                                        itemWithInvoice.items.forEachIndexed { idx, item ->
                                            val rowBg = if (idx % 2 == 0) Color.White else Color(0xFFF8FAFC)
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(rowBg)
                                                    .border(BorderStroke(0.5.dp, Color(0xFFF1F5F9)))
                                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // Product Name
                                                Text(
                                                    text = item.productName,
                                                    modifier = Modifier.weight(2.2f),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = Color(0xFF0F172A),
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Start
                                                )

                                                // Quantity
                                                Text(
                                                    text = NumberUtils.formatNumber(item.quantity),
                                                    modifier = Modifier.weight(0.9f),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = Color(0xFF334155),
                                                    textAlign = TextAlign.Center
                                                )

                                                // Unit Price
                                                Text(
                                                    text = NumberUtils.formatNumber(item.unitPrice),
                                                    modifier = Modifier.weight(1.1f),
                                                    fontSize = 13.sp,
                                                    color = Color(0xFF64748B),
                                                    textAlign = TextAlign.Center
                                                )

                                                // Line Total
                                                Text(
                                                    text = NumberUtils.formatNumber(item.totalPrice),
                                                    modifier = Modifier.weight(1.2f),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF1E293B),
                                                    textAlign = TextAlign.End
                                                )
                                            }
                                        }

                                        // Table Footer Total Bar
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFECFDF5), RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                                .border(BorderStroke(1.dp, Color(0xFFA7F3D0)), RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                                .padding(horizontal = 12.dp, vertical = 9.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "إجمالي الفاتورة:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color(0xFF065F46)
                                            )
                                            Text(
                                                text = NumberUtils.formatNumber(inv.totalAmount),
                                                fontWeight = FontWeight.Black,
                                                fontSize = 16.sp,
                                                color = PosGreenCashLight
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Additional info & Actions: Paid / Change / Receipt button
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                if (inv.paidAmount > 0) {
                                                    Text(
                                                        text = "المدفوع: ${NumberUtils.formatNumber(inv.paidAmount)} • الباقي: ${NumberUtils.formatNumber(inv.changeAmount)}",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFF64748B)
                                                    )
                                                }
                                                Text(
                                                    text = "الكاشير: ${inv.cashierName}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF94A3B8)
                                                )
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    receiptToView = itemWithInvoice
                                                    onViewReceipt(itemWithInvoice)
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PosBluePrimary),
                                                modifier = Modifier.testTag("btn_view_receipt_${inv.invoiceId}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Receipt,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("عرض الإيصال", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Incremental Loading button if there are more invoices
                    if (filteredInvoices.size > displayedInvoices.size) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Button(
                                    onClick = { visibleLimit += 50 },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                                    modifier = Modifier.testTag("btn_load_more_invoices")
                                ) {
                                    Text(
                                        text = "تحميل المزيد (+50 فاتورة) • المتبقي ${filteredInvoices.size - displayedInvoices.size}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    // --- Custom Date Range Picker Dialog ---
    if (isCustomRangeDialogOpen) {
        val cal = Calendar.getInstance()
        var tempStart by remember { mutableStateOf(customStartDate ?: cal.timeInMillis) }
        var tempEnd by remember { mutableStateOf(customEndDate ?: cal.timeInMillis) }

        androidx.compose.ui.window.Dialog(onDismissRequest = { isCustomRangeDialogOpen = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "تحديد نطاق تاريخ مخصص",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    // Start Date Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
                            .clickable {
                                val c = Calendar.getInstance().apply { timeInMillis = tempStart }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val picked = Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth, 0, 0, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        tempStart = picked.timeInMillis
                                    },
                                    c.get(Calendar.YEAR),
                                    c.get(Calendar.MONTH),
                                    c.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("من تاريخ:", fontSize = 13.sp, color = Color(0xFF64748B))
                        Text(
                            text = dayDateFormatter.format(Date(tempStart)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PosBluePrimary
                        )
                    }

                    // End Date Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp))
                            .clickable {
                                val c = Calendar.getInstance().apply { timeInMillis = tempEnd }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val picked = Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth, 23, 59, 59)
                                            set(Calendar.MILLISECOND, 999)
                                        }
                                        tempEnd = picked.timeInMillis
                                    },
                                    c.get(Calendar.YEAR),
                                    c.get(Calendar.MONTH),
                                    c.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إلى تاريخ:", fontSize = 13.sp, color = Color(0xFF64748B))
                        Text(
                            text = dayDateFormatter.format(Date(tempEnd)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PosBluePrimary
                        )
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isCustomRangeDialogOpen = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إلغاء")
                        }

                        Button(
                            onClick = {
                                customStartDate = minOf(tempStart, tempEnd)
                                customEndDate = maxOf(tempStart, tempEnd)
                                selectedDateFilter = SalesDateFilter.CUSTOM
                                isCustomRangeDialogOpen = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary)
                        ) {
                            Text("تطبيق التصفية", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // --- Printable Receipt Dialog preview ---
    if (receiptToView != null) {
        PosReceiptDialog(
            invoiceWithItems = receiptToView!!,
            onDismiss = { receiptToView = null }
        )
    }
}
