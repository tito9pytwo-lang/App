package com.example.ui.util

import com.example.data.model.ProductEntity
import kotlin.math.abs

/**
 * Intelligent classifier for POS products sharing the same barcode or representing
 * the same commercial trade item (الصنف التجاري نفسه).
 *
 * Rules:
 * 1. Unit price equality (abs(diff) < 0.001) is MANDATORY. Different prices represent
 *    a real economic difference and can NEVER be automatically merged.
 * 2. Products sharing the same parentProductId or linked as parent-child are always
 *    the same commercial product if their prices match.
 * 3. Products sharing the same company/category and commercial base name (after normalizing
 *    Arabic text and stripping flavor, shape, and packaging descriptors) represent the
 *    same commercial product.
 * 4. When a barcode is scanned, if all matched products represent the same commercial item,
 *    no selection dialog is shown; the product is added directly to the cart, incrementing
 *    quantity on the single cart row.
 * 5. If there is a real difference (differing prices or unrelated commercial items),
 *    the selection dialog is presented so the cashier can make an accurate choice.
 */
object CommercialProductMatcher {

    /**
     * Determines whether two products represent the SAME commercial product
     * (الصنف التجاري نفسه) for cart line consolidation and auto-scan resolution.
     */
    fun isSameCommercialProduct(a: ProductEntity, b: ProductEntity): Boolean {
        // Same database ID is always the same product
        if (a.id > 0 && b.id > 0 && a.id == b.id) return true

        // 1. Mandatory Price Check: prices must be equal
        if (abs(a.price - b.price) > 0.001) return false

        // 2. Parent-child relationship check
        if (a.parentProductId != null && a.parentProductId > 0 && a.parentProductId == b.parentProductId) {
            return true
        }
        if (a.parentProductId != null && a.parentProductId == b.id) return true
        if (b.parentProductId != null && b.parentProductId == a.id) return true

        // 3. Company/Category compatibility check
        if (!isCompanyOrCategoryCompatible(a.category, b.category)) {
            return false
        }

        // 4. Commercial Base Name match (stripping flavors, packaging, shapes)
        val baseA = extractCommercialBaseName(a.name)
        val baseB = extractCommercialBaseName(b.name)

        if (baseA.isNotEmpty() && baseA == baseB) {
            return true
        }

        // 5. Normalized text equality
        val normA = normalizeArabicText(a.name)
        val normB = normalizeArabicText(b.name)
        if (normA.isNotEmpty() && normA == normB) {
            return true
        }

        // 6. Common prefix / root brand match when sharing the same barcode
        val wordsA = baseA.split(" ").filter { it.isNotBlank() }
        val wordsB = baseB.split(" ").filter { it.isNotBlank() }
        if (wordsA.isNotEmpty() && wordsB.isNotEmpty()) {
            if (wordsA.first() == wordsB.first()) {
                val hasCommonBarcode = !a.barcode.isNullOrBlank() &&
                        BarcodeMatcher.isExactMatch(a.barcode, b.barcode)
                if (hasCommonBarcode) {
                    return true
                }
            }
        }

        return false
    }

    /**
     * Result of barcode evaluation.
     */
    sealed class BarcodeResolution {
        data class Single(val representativeProduct: ProductEntity) : BarcodeResolution()
        data class Ambiguous(val products: List<ProductEntity>) : BarcodeResolution()
    }

    /**
     * Evaluates multiple database products matching a scanned barcode:
     * - Returns [BarcodeResolution.Single] if all products represent the same commercial item
     *   with the same price and compatible company/category (no dialog needed).
     * - Returns [BarcodeResolution.Ambiguous] if there is a real difference in price or
     *   commercial item identity (dialog needed to prevent errors).
     */
    fun resolveBarcodeMatches(matches: List<ProductEntity>): BarcodeResolution {
        require(matches.isNotEmpty()) { "Matches list must not be empty" }
        if (matches.size == 1) return BarcodeResolution.Single(matches.first())

        // 1. Check if prices differ
        val firstPrice = matches.first().price
        val hasPriceDifference = matches.any { abs(it.price - firstPrice) > 0.001 }
        if (hasPriceDifference) {
            // Price difference: real difference, must let cashier choose
            return BarcodeResolution.Ambiguous(matches)
        }

        // 2. Check if all matched products belong to the same commercial product
        val reference = matches.first()
        val allSameCommercialProduct = matches.all { prod ->
            isSameCommercialProduct(reference, prod)
        }

        return if (allSameCommercialProduct) {
            // Choose parent product if exists among them, otherwise first
            val parent = matches.firstOrNull { it.parentProductId == null || it.parentProductId == 0L }
                ?: matches.first()
            BarcodeResolution.Single(parent)
        } else {
            // Real difference in item identity
            BarcodeResolution.Ambiguous(matches)
        }
    }

    /**
     * Normalizes Arabic text for uniform comparison:
     * - Normalizes Alef forms (أ, إ, آ, ٱ -> ا)
     * - Normalizes Ta Marbuta (ة -> ه)
     * - Normalizes Ya (ى -> ي)
     * - Strips Tatweel (ـ)
     * - Strips Tashkeel / Harakat
     * - Normalizes punctuation and spaces
     */
    fun normalizeArabicText(text: String?): String {
        if (text.isNullOrBlank()) return ""
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when {
                // Tashkeel / Harakat (diacritics)
                ch in '\u064B'..'\u065F' || ch == '\u0670' -> {} // skip
                // Tatweel / Kashida
                ch == 'ـ' -> {} // skip
                // Alef variants
                ch in "أإآٱ" -> sb.append('ا')
                // Ta Marbuta
                ch == 'ة' -> sb.append('ه')
                // Ya / Alif Maqsura
                ch == 'ى' -> sb.append('ي')
                // Punctuation, dashes, brackets, emojis, symbols
                ch in "-_[](){}«»\"':/\\،,;.•*~!?#@+=\t\r\n" -> sb.append(' ')
                else -> {
                    if (ch.isWhitespace()) {
                        sb.append(' ')
                    } else if (!ch.isISOControl()) {
                        sb.append(ch.lowercaseChar())
                    }
                }
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Extracts the core commercial base name by removing flavor words, packaging,
     * shapes, and optional descriptors.
     *
     * Example:
     * "علكة فراولة" -> "علكه"
     * "علكة نعناع" -> "علكه"
     * "علكة فواكه" -> "علكه"
     * "علكة متنوعة" -> "علكه"
     * "شيبس ليز بالجبنة" -> "شيبس ليز"
     * "شيبس ليز بالملح" -> "شيبس ليز"
     */
    fun extractCommercialBaseName(name: String?): String {
        val normalized = normalizeArabicText(name)
        if (normalized.isBlank()) return ""

        val words = normalized.split(" ").filter { it.isNotBlank() }
        val filteredWords = words.filter { word ->
            word !in DESCRIPTOR_WORDS && !isFlavorWithPrefix(word)
        }

        // If filtering removed all words, fallback to the normalized name
        return if (filteredWords.isNotEmpty()) {
            filteredWords.joinToString(" ")
        } else {
            normalized
        }
    }

    /**
     * Checks if a word is prefixed with "بالـ" or "بـ" followed by a known flavor/descriptor.
     */
    private fun isFlavorWithPrefix(word: String): Boolean {
        if (word.startsWith("بال") && word.length > 4) {
            val stem = word.substring(3)
            if (stem in BASE_FLAVOR_STEMS) return true
        }
        if (word.startsWith("ب") && word.length > 3) {
            val stem = word.substring(1)
            if (stem in BASE_FLAVOR_STEMS) return true
        }
        return false
    }

    /**
     * Verifies that two categories or company names are compatible.
     */
    fun isCompanyOrCategoryCompatible(catA: String?, catB: String?): Boolean {
        val a = normalizeArabicText(catA)
        val b = normalizeArabicText(catB)
        val defaultCategories = setOf("", "عام", "اخري", "اخرى", "بدون")
        if (a in defaultCategories || b in defaultCategories) return true
        return a == b || a.contains(b) || b.contains(a)
    }

    // Set of flavor stems for "بالـ" detection
    private val BASE_FLAVOR_STEMS = setOf(
        "فراوله", "فراولة", "نعناع", "ليمون", "برتقال", "تفاح", "عنب", "مانجو", "موز", "توت",
        "رمان", "خوخ", "مشمش", "بطيخ", "كرز", "كيوي", "اناناس", "أناناس", "جوافه", "جوافة",
        "فواكه", "شوكولاته", "شوكولاتة", "شوكلاته", "شوكولا", "كاكاو", "فانيلا", "فانيليا",
        "كراميل", "قهوه", "قهوة", "بندق", "لوز", "فستق", "كاجو", "ملح", "خل", "جبنه", "جبنة",
        "جبن", "شيدر", "كاتشب", "شطه", "شطة", "باربيكيو", "باربكيو", "شواء", "بصل", "طماطم",
        "زعتر", "زيتون"
    )

    // Known flavor and descriptor words in normalized Arabic form (ه for ة, ا for أ/إ)
    private val DESCRIPTOR_WORDS = setOf(
        // Flavors (نكهات وأطعمة)
        "فراوله", "فراولة", "نعناع", "ليمون", "برتقال", "تفاح", "عنب", "مانجو", "موز", "توت",
        "رمان", "خوخ", "مشمش", "بطيخ", "كرز", "كيوي", "اناناس", "أناناس", "جوافه", "جوافة",
        "فواكه", "شوكولاته", "شوكولاتة", "شوكلاته", "شوكولا", "كاكاو", "فانيلا", "فانيليا",
        "كراميل", "قهوه", "قهوة", "بندق", "لوز", "فستق", "كاجو", "حار", "بارد", "ملح", "خل",
        "جبنه", "جبنة", "جبن", "شيدر", "كاتشب", "شطه", "شطة", "باربيكيو", "باربكيو", "شواء",
        "بصل", "طماطم", "زعتر", "زيتون", "ساده", "سادة", "اصلي", "أصلي",
        // With "بـ" / "بالـ"
        "بالفراوله", "بالفراولة", "بالنعناع", "بالليمون", "بالبرتقال", "بالتفاح", "بالعنب",
        "بالمانجو", "بالموز", "بالتوت", "بالرمان", "بالخوخ", "بالبطيخ", "بالكرز", "بالفواكه",
        "بالشوكولاته", "بالشوكولاتة", "بالفانيلا", "بالفانيليا", "بالكراميل", "بالقهوه",
        "بالقهوة", "بالبندق", "باللوز", "بالفستق", "بالجبنه", "بالجبنة", "بالجبن", "بالملح",
        "بالخل", "بالشطه", "بالشطة", "بالزعتر", "بالبصل", "بالطماطم", "بالشواء", "بالباربيكيو",
        // Descriptors (نكهة، طعم، شكل، تشكيلة)
        "بنكهه", "بنكهة", "بطعم", "نكهه", "نكهة", "طعم", "شكل", "نوع", "مشكل", "مشكله", "مشكلة",
        "متنوع", "متنوعه", "متنوعة",
        // Diet / Milk / Sugar (أنواع وسكر)
        "دايت", "لايت", "زيرو", "سكر", "بدون", "كامل", "قليل", "خالي", "الدسم", "دسم",
        "طازج", "مجفف", "مبستر", "مركز",
        // Size / Packaging (أحجام وعبوات)
        "حجم", "صغير", "وسط", "كبير", "عائلي", "ميني", "ماكسي", "علبه", "علبة", "كيس",
        "قنينه", "قنينة", "زجاجه", "زجاجة", "باكيت", "شريط", "حبه", "حبة", "قطعه", "قطعة"
    )
}
