package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.model.ProductEntity
import com.example.data.repository.PosRepository
import com.example.ui.PosUiState
import com.example.ui.model.CartItem
import com.example.ui.util.CommercialProductMatcher
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BarcodeCommercialResolutionTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: PosRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = PosRepository(db.productDao(), db.productBarcodeDao(), db.saleDao())
    }

    @After
    fun closeDb() {
        db.close()
    }

    /**
     * Helper mimicking the unified POS cart logic:
     * - Merges into existing line if CommercialProductMatcher.isSameCommercialProduct returns true.
     * - Increments quantity by qtyToAdd.
     */
    private fun addToCartSimulation(state: PosUiState, product: ProductEntity, qtyToAdd: Double = 1.0): PosUiState {
        val existingIndex = state.cartItems.indexOfFirst { item ->
            CommercialProductMatcher.isSameCommercialProduct(item.product, product)
        }

        val updatedCart = if (existingIndex >= 0) {
            state.cartItems.mapIndexed { index, item ->
                if (index == existingIndex) {
                    item.copy(quantity = item.quantity + qtyToAdd)
                } else {
                    item
                }
            }
        } else {
            state.cartItems + CartItem(
                product = product,
                quantity = qtyToAdd,
                unitPrice = product.price
            )
        }

        val targetIndex = if (existingIndex >= 0) existingIndex else updatedCart.lastIndex
        return state.copy(
            cartItems = updatedCart,
            selectedCartIndex = targetIndex,
            isUnregisteredPromptOpen = false,
            isAmbiguousBarcodeDialogOpen = false,
            unregisteredBarcode = null
        )
    }

    /**
     * Helper mimicking PosViewModel.onBarcodeScanned:
     * Returns a pair of (updatedState, dialogOpened)
     */
    private suspend fun scanBarcodeSimulation(currentState: PosUiState, barcode: String): Pair<PosUiState, Boolean> {
        val matchedProducts = repository.findProductsByBarcode(barcode)
        if (matchedProducts.isEmpty()) {
            return Pair(
                currentState.copy(
                    isUnregisteredPromptOpen = true,
                    unregisteredBarcode = barcode,
                    isAmbiguousBarcodeDialogOpen = false
                ),
                false
            )
        } else if (matchedProducts.size == 1) {
            val nextState = addToCartSimulation(currentState, matchedProducts.first(), 1.0)
            return Pair(nextState, false)
        } else {
            when (val res = CommercialProductMatcher.resolveBarcodeMatches(matchedProducts)) {
                is CommercialProductMatcher.BarcodeResolution.Single -> {
                    val existingItem = currentState.cartItems.firstOrNull { item ->
                        matchedProducts.any { CommercialProductMatcher.isSameCommercialProduct(item.product, it) }
                    }
                    val productToAdd = existingItem?.product ?: res.representativeProduct
                    val nextState = addToCartSimulation(currentState, productToAdd, 1.0)
                    return Pair(nextState, false)
                }
                is CommercialProductMatcher.BarcodeResolution.Ambiguous -> {
                    return Pair(
                        currentState.copy(
                            isAmbiguousBarcodeDialogOpen = true,
                            ambiguousBarcodeProducts = res.products
                        ),
                        true
                    )
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------
    // TEST 1: Scanning the exact same barcode 3 times adds 3 pieces on a single line
    // without any selection dialog.
    // ---------------------------------------------------------------------------------
    @Test
    fun `test 1 - scanning same barcode three times adds 3 pieces on a single line without dialog`() = runBlocking {
        val water = ProductEntity(
            name = "مياه نقي 330 مل",
            barcode = "6281001",
            price = 1.0
        )
        db.productDao().insertProduct(water)

        var state = PosUiState()

        // 1st scan
        val (state1, dialog1) = scanBarcodeSimulation(state, "6281001")
        assertFalse("Dialog must not open for single product", dialog1)
        assertEquals(1, state1.cartItems.size)
        assertEquals(1.0, state1.cartItems[0].quantity, 0.001)
        assertEquals(1.0, state1.totalAmount, 0.001)

        // 2nd scan
        val (state2, dialog2) = scanBarcodeSimulation(state1, "6281001")
        assertFalse("Dialog must not open for second scan", dialog2)
        assertEquals("Must remain a single line", 1, state2.cartItems.size)
        assertEquals(2.0, state2.cartItems[0].quantity, 0.001)
        assertEquals(2.0, state2.cartItems[0].totalPrice, 0.001)
        assertEquals(2.0, state2.totalAmount, 0.001)

        // 3rd scan
        val (state3, dialog3) = scanBarcodeSimulation(state2, "6281001")
        assertFalse("Dialog must not open for third scan", dialog3)
        assertEquals("Must remain a single line", 1, state3.cartItems.size)
        assertEquals(3.0, state3.cartItems[0].quantity, 0.001)
        assertEquals(3.0, state3.cartItems[0].totalPrice, 0.001)
        assertEquals(3.0, state3.totalAmount, 0.001)
    }

    // ---------------------------------------------------------------------------------
    // TEST 2: Scanning a barcode linked to different flavors with same company and price
    // adds the item directly to the cart without showing a selection dialog.
    // ---------------------------------------------------------------------------------
    @Test
    fun `test 2 - scanning barcode with different flavors having same price and company adds directly`() = runBlocking {
        // Three flavor variants sharing the same barcode, same company "شركة X", same price 2.0
        val gumStrawberry = ProductEntity(
            name = "علكة فراولة",
            barcode = "555111",
            price = 2.0,
            category = "شركة X"
        )
        val gumMint = ProductEntity(
            name = "علكة نعناع",
            barcode = "555111",
            price = 2.0,
            category = "شركة X"
        )
        val gumFruits = ProductEntity(
            name = "علكة فواكه",
            barcode = "555111",
            price = 2.0,
            category = "شركة X"
        )

        db.productDao().insertProduct(gumStrawberry)
        db.productDao().insertProduct(gumMint)
        db.productDao().insertProduct(gumFruits)

        var state = PosUiState()

        // 1st scan
        val (state1, dialog1) = scanBarcodeSimulation(state, "555111")
        assertFalse("Must NOT show selection dialog when flavors have same commercial identity and price", dialog1)
        assertEquals(1, state1.cartItems.size)
        assertEquals(1.0, state1.cartItems[0].quantity, 0.001)
        assertEquals(2.0, state1.cartItems[0].unitPrice, 0.001)
        assertEquals(2.0, state1.totalAmount, 0.001)

        // 2nd scan
        val (state2, dialog2) = scanBarcodeSimulation(state1, "555111")
        assertFalse("Must NOT show selection dialog on 2nd scan", dialog2)
        assertEquals("Must NOT create a second line for same commercial item", 1, state2.cartItems.size)
        assertEquals(2.0, state2.cartItems[0].quantity, 0.001)
        assertEquals(4.0, state2.cartItems[0].totalPrice, 0.001)
        assertEquals(4.0, state2.totalAmount, 0.001)

        // 3rd scan
        val (state3, dialog3) = scanBarcodeSimulation(state2, "555111")
        assertFalse("Must NOT show selection dialog on 3rd scan", dialog3)
        assertEquals(1, state3.cartItems.size)
        assertEquals(3.0, state3.cartItems[0].quantity, 0.001)
        assertEquals(6.0, state3.cartItems[0].totalPrice, 0.001)
        assertEquals(6.0, state3.totalAmount, 0.001)
    }

    // ---------------------------------------------------------------------------------
    // TEST 3: If product is registered in database, NEVER show unregistered prompt.
    // Only show unregistered prompt when barcode does NOT exist in database.
    // ---------------------------------------------------------------------------------
    @Test
    fun `test 3 - registered products never show unregistered dialog`() = runBlocking {
        val biscuit = ProductEntity(
            name = "بسكويت شاي",
            barcode = "777888",
            price = 5.0
        )
        db.productDao().insertProduct(biscuit)

        val state = PosUiState()

        // Scan registered product
        val (registeredState, _) = scanBarcodeSimulation(state, "777888")
        assertFalse("isUnregisteredPromptOpen must be FALSE for registered product", registeredState.isUnregisteredPromptOpen)
        assertEquals(1, registeredState.cartItems.size)

        // Scan completely unregistered barcode
        val (unregisteredState, _) = scanBarcodeSimulation(state, "000999888")
        assertTrue("isUnregisteredPromptOpen must be TRUE for unregistered barcode", unregisteredState.isUnregisteredPromptOpen)
        assertEquals("000999888", unregisteredState.unregisteredBarcode)
        assertEquals(0, unregisteredState.cartItems.size)
    }

    // ---------------------------------------------------------------------------------
    // TEST 4: If price differs between products linked to the same barcode,
    // DO NOT pick randomly or merge; MUST prompt cashier with selection dialog.
    // ---------------------------------------------------------------------------------
    @Test
    fun `test 4 - price differences between products sharing a barcode triggers selection dialog`() = runBlocking {
        // Product A: 2.0
        val smallPack = ProductEntity(
            name = "علكة حجم عادي",
            barcode = "444333",
            price = 2.0
        )
        // Product B: 5.0 (different price!)
        val familyPack = ProductEntity(
            name = "علكة حجم عائلي كبير",
            barcode = "444333",
            price = 5.0
        )

        db.productDao().insertProduct(smallPack)
        db.productDao().insertProduct(familyPack)

        val state = PosUiState()

        // Scan barcode that has conflicting prices
        val (nextState, dialogOpened) = scanBarcodeSimulation(state, "444333")
        assertTrue("MUST trigger selection dialog because prices differ (2.0 vs 5.0)", dialogOpened)
        assertTrue(nextState.isAmbiguousBarcodeDialogOpen)
        assertEquals(2, nextState.ambiguousBarcodeProducts.size)
        // Must NOT have added anything to cart automatically to avoid incorrect charging
        assertEquals(0, nextState.cartItems.size)
    }

    // ---------------------------------------------------------------------------------
    // TEST 5: Verify calculations of quantity, unit price, line total, and invoice total.
    // Also verify that distinct commercial products create separate rows.
    // ---------------------------------------------------------------------------------
    @Test
    fun `test 5 - verify line total and invoice total calculations and distinct rows`() = runBlocking {
        val milk = ProductEntity(name = "حليب نادك كامل الدسم", barcode = "1001", price = 4.50)
        val juice = ProductEntity(name = "عصير برتقال فلوريدا", barcode = "1002", price = 8.00)

        db.productDao().insertProduct(milk)
        db.productDao().insertProduct(juice)

        var state = PosUiState()

        // Scan milk twice
        state = scanBarcodeSimulation(state, "1001").first
        state = scanBarcodeSimulation(state, "1001").first

        // Scan juice three times
        state = scanBarcodeSimulation(state, "1002").first
        state = scanBarcodeSimulation(state, "1002").first
        state = scanBarcodeSimulation(state, "1002").first

        assertEquals("Must have 2 distinct lines", 2, state.cartItems.size)

        // Line 1: Milk
        val milkItem = state.cartItems[0]
        assertEquals("حليب نادك كامل الدسم", milkItem.product.name)
        assertEquals(2.0, milkItem.quantity, 0.001)
        assertEquals(4.50, milkItem.unitPrice, 0.001)
        assertEquals(9.00, milkItem.totalPrice, 0.001) // 2 * 4.50 = 9.00

        // Line 2: Juice
        val juiceItem = state.cartItems[1]
        assertEquals("عصير برتقال فلوريدا", juiceItem.product.name)
        assertEquals(3.0, juiceItem.quantity, 0.001)
        assertEquals(8.00, juiceItem.unitPrice, 0.001)
        assertEquals(24.00, juiceItem.totalPrice, 0.001) // 3 * 8.00 = 24.00

        // Total Invoice = 9.00 + 24.00 = 33.00
        assertEquals(33.00, state.totalAmount, 0.001)
    }
}
