package com.example

import com.example.data.model.InvoiceWithItems
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import com.example.ui.screens.SalesDateFilter
import com.example.ui.screens.SalesSortOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class SalesHistoryLogicTest {

    @Test
    fun `test filtering invoices by invoice number and product name`() {
        val now = System.currentTimeMillis()

        val invoice1 = InvoiceWithItems(
            invoice = SaleInvoiceEntity(
                invoiceId = 1,
                invoiceNumber = "1001",
                timestamp = now - 10000,
                totalAmount = 21.5,
                paidAmount = 25.0,
                changeAmount = 3.5,
                paymentMethod = "نقدًا",
                itemCount = 4
            ),
            items = listOf(
                SaleItemEntity(id = 1, invoiceId = 1, productName = "توابل زردة", quantity = 1.0, unitPrice = 5.0, totalPrice = 5.0),
                SaleItemEntity(id = 2, invoiceId = 1, productName = "كمون حوت", quantity = 2.0, unitPrice = 3.5, totalPrice = 7.0),
                SaleItemEntity(id = 3, invoiceId = 1, productName = "عدس أخضر", quantity = 1.0, unitPrice = 6.0, totalPrice = 6.0),
                SaleItemEntity(id = 4, invoiceId = 1, productName = "نشأة ذرة", quantity = 1.0, unitPrice = 3.5, totalPrice = 3.5)
            )
        )

        val invoice2 = InvoiceWithItems(
            invoice = SaleInvoiceEntity(
                invoiceId = 2,
                invoiceNumber = "1002",
                timestamp = now - 5000,
                totalAmount = 15.0,
                paidAmount = 20.0,
                changeAmount = 5.0,
                paymentMethod = "شبكة",
                itemCount = 1
            ),
            items = listOf(
                SaleItemEntity(id = 5, invoiceId = 2, productName = "حليب نادك", quantity = 3.0, unitPrice = 5.0, totalPrice = 15.0)
            )
        )

        val allInvoices = listOf(invoice1, invoice2)

        // 1. Search by invoice number
        val searchByNum = allInvoices.filter { it.invoice.invoiceNumber.contains("1001") }
        assertEquals(1, searchByNum.size)
        assertEquals("1001", searchByNum[0].invoice.invoiceNumber)

        // 2. Search by product name "كمون" inside invoice
        val searchByProduct = allInvoices.filter { inv ->
            inv.items.any { it.productName.contains("كمون") }
        }
        assertEquals(1, searchByProduct.size)
        assertEquals("1001", searchByProduct[0].invoice.invoiceNumber)

        // 3. Search by product name "حليب" inside invoice
        val searchByMilk = allInvoices.filter { inv ->
            inv.items.any { it.productName.contains("حليب") }
        }
        assertEquals(1, searchByMilk.size)
        assertEquals("1002", searchByMilk[0].invoice.invoiceNumber)

        // 4. Summary amounts calculation across filtered items
        val totalAmount = allInvoices.sumOf { it.invoice.totalAmount }
        assertEquals(36.5, totalAmount, 0.001)

        val totalCount = allInvoices.size
        assertEquals(2, totalCount)
    }

    @Test
    fun `test sorting orders between newest and oldest`() {
        val t1 = 1000000L
        val t2 = 2000000L
        val t3 = 3000000L

        val inv1 = InvoiceWithItems(
            invoice = SaleInvoiceEntity(invoiceId = 1, invoiceNumber = "INV-1", timestamp = t1, totalAmount = 10.0, paidAmount = 10.0, changeAmount = 0.0, itemCount = 1),
            items = emptyList()
        )
        val inv2 = InvoiceWithItems(
            invoice = SaleInvoiceEntity(invoiceId = 2, invoiceNumber = "INV-2", timestamp = t3, totalAmount = 20.0, paidAmount = 20.0, changeAmount = 0.0, itemCount = 1),
            items = emptyList()
        )
        val inv3 = InvoiceWithItems(
            invoice = SaleInvoiceEntity(invoiceId = 3, invoiceNumber = "INV-3", timestamp = t2, totalAmount = 30.0, paidAmount = 30.0, changeAmount = 0.0, itemCount = 1),
            items = emptyList()
        )

        val list = listOf(inv1, inv2, inv3)

        // Newest First
        val newestFirst = list.sortedByDescending { it.invoice.timestamp }
        assertEquals("INV-2", newestFirst[0].invoice.invoiceNumber)
        assertEquals("INV-3", newestFirst[1].invoice.invoiceNumber)
        assertEquals("INV-1", newestFirst[2].invoice.invoiceNumber)

        // Oldest First
        val oldestFirst = list.sortedBy { it.invoice.timestamp }
        assertEquals("INV-1", oldestFirst[0].invoice.invoiceNumber)
        assertEquals("INV-3", oldestFirst[1].invoice.invoiceNumber)
        assertEquals("INV-2", oldestFirst[2].invoice.invoiceNumber)
    }
}
