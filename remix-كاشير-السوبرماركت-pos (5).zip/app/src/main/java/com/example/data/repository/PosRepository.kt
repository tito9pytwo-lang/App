package com.example.data.repository

import com.example.data.InitialData
import com.example.data.dao.ProductBarcodeDao
import com.example.data.dao.ProductDao
import com.example.data.dao.SaleDao
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductBarcodeEntity
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import com.example.ui.util.BarcodeMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PosRepository(
    private val productDao: ProductDao,
    private val productBarcodeDao: ProductBarcodeDao,
    private val saleDao: SaleDao
) {
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val shortcutProducts: Flow<List<ProductEntity>> = productDao.getShortcutProducts()
    val allProductBarcodes: Flow<List<ProductBarcodeEntity>> = productBarcodeDao.getAllBarcodes()
    val allInvoices: Flow<List<InvoiceWithItems>> = saleDao.getAllInvoicesWithItems()
    val totalInvoiceCount: Flow<Int> = saleDao.getTotalInvoiceCount()
    val totalSalesAmount: Flow<Double> = saleDao.getTotalSalesAmount()

    suspend fun checkAndSeedInitialData() = withContext(Dispatchers.IO) {
        if (productDao.getProductCount() == 0) {
            productDao.insertProducts(InitialData.sampleProducts)
        }
        sanitizeExistingBarcodes()
    }

    /**
     * Sanitizes barcodes and shortcut codes in existing database records
     * so that all records are in standard normalized string format.
     */
    suspend fun sanitizeExistingBarcodes() = withContext(Dispatchers.IO) {
        try {
            val list = productDao.getAllProductsList()
            for (prod in list) {
                val cleanBarcode = prod.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                val cleanShortcut = prod.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                if (cleanBarcode != prod.barcode || cleanShortcut != prod.shortcutCode) {
                    productDao.updateProduct(prod.copy(barcode = cleanBarcode, shortcutCode = cleanShortcut))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Finds ALL products matching an exact barcode (or shortcut code).
     *
     * Core resolution rules:
     * 1. If the barcode is linked to a Parent Product in `product_barcodes`, returns the Parent Product.
     * 2. If the product found has `parentProductId != null`, resolves directly to the Parent Product.
     * 3. Multiple barcodes for different flavors (e.g. 1111, 2222, 3333 for "علكة متنوعة")
     *    all resolve to that single Parent Product!
     */
    suspend fun findProductsByBarcode(scannedBarcode: String): List<ProductEntity> = withContext(Dispatchers.IO) {
        val raw = scannedBarcode
        val norm = BarcodeMatcher.normalizeBarcode(raw)
        if (norm.isEmpty()) {
            BarcodeMatcher.logDiagnostic(raw, norm, null)
            return@withContext emptyList()
        }

        // 1. Check if this barcode is linked to a Parent Product via product_barcodes table
        val linkedBarcodes = productBarcodeDao.getBarcodeEntities(norm)
        if (linkedBarcodes.isNotEmpty()) {
            val parentIds = linkedBarcodes.map { it.parentProductId }.distinct()
            val parents = parentIds.mapNotNull { productDao.getProductById(it) }
            if (parents.isNotEmpty()) {
                BarcodeMatcher.logDiagnostic(
                    scannedBarcode = raw,
                    normalizedBarcode = norm,
                    foundProduct = parents.first()
                )
                return@withContext parents
            }
        }

        // 2. Direct database exact query for all products matching this barcode or shortcut
        var list = productDao.getProductsByBarcodeOrShortcut(norm)

        // 3. In-memory check across all products if database returned empty
        if (list.isEmpty()) {
            val all = productDao.getAllProductsList()
            list = BarcodeMatcher.findAllMatches(norm, all)
        }

        // 4. If any matched product has a parentProductId, resolve to the Parent Product
        val resolvedList = list.map { prod ->
            if (prod.parentProductId != null && prod.parentProductId > 0) {
                productDao.getProductById(prod.parentProductId) ?: prod
            } else {
                prod
            }
        }.distinctBy { it.id }

        // Log diagnostics for primary item found or null
        BarcodeMatcher.logDiagnostic(
            scannedBarcode = raw,
            normalizedBarcode = norm,
            foundProduct = resolvedList.firstOrNull()
        )

        resolvedList
    }

    /**
     * Finds a single product by exact barcode (or shortcut code).
     * If multiple exist, returns the first one.
     */
    suspend fun findProductByBarcode(scannedBarcode: String): ProductEntity? = withContext(Dispatchers.IO) {
        findProductsByBarcode(scannedBarcode).firstOrNull()
    }

    suspend fun findProductByCodeOrShortcut(code: String): ProductEntity? = withContext(Dispatchers.IO) {
        findProductByBarcode(code)
    }

    suspend fun findProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return productDao.searchProducts(query)
    }

    suspend fun saveProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        val normalizedProduct = product.copy(
            barcode = product.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } },
            shortcutCode = product.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
        )
        if (normalizedProduct.id == 0L) {
            productDao.insertProduct(normalizedProduct)
        } else {
            productDao.updateProduct(normalizedProduct)
            normalizedProduct.id
        }
    }

    suspend fun updateShortcutCode(productId: Long, shortcutCode: String?) = withContext(Dispatchers.IO) {
        val cleanCode = shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
        productDao.updateShortcutCode(productId, cleanCode)
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        productBarcodeDao.deleteBarcodesForProduct(product.id)
        productDao.deleteProduct(product)
    }

    /**
     * Finds all products that are linked to [targetProduct] by sharing the same barcode,
     * sharing a parent product group, or sharing linked flavor barcodes.
     */
    suspend fun getLinkedBarcodeProducts(targetProduct: ProductEntity): List<ProductEntity> = withContext(Dispatchers.IO) {
        val linkedIds = mutableSetOf<Long>()
        val allProducts = productDao.getAllProductsList()
        val normBarcode = targetProduct.barcode?.let { BarcodeMatcher.normalizeBarcode(it) }?.ifEmpty { null }

        // 1. Same normalized barcode in products table
        if (!normBarcode.isNullOrBlank()) {
            allProducts.filter { prod ->
                prod.id != targetProduct.id &&
                !prod.barcode.isNullOrBlank() &&
                BarcodeMatcher.isExactMatch(prod.barcode, normBarcode)
            }.forEach { linkedIds.add(it.id) }
        }

        // 2. Linked via product_barcodes table (if targetProduct's barcode is registered for a parent)
        if (!normBarcode.isNullOrBlank()) {
            val barcodeEntities = productBarcodeDao.getBarcodeEntities(normBarcode)
            for (be in barcodeEntities) {
                if (be.parentProductId != targetProduct.id) {
                    linkedIds.add(be.parentProductId)
                }
            }
        }

        // 3. If targetProduct is a child with parentProductId
        if (targetProduct.parentProductId != null && targetProduct.parentProductId > 0) {
            linkedIds.add(targetProduct.parentProductId)
            // Sibling children sharing the same parent
            allProducts.filter { it.parentProductId == targetProduct.parentProductId && it.id != targetProduct.id }
                .forEach { linkedIds.add(it.id) }
        }

        // 4. If targetProduct is a parent product with child flavors/variants
        allProducts.filter { it.parentProductId == targetProduct.id }
            .forEach { linkedIds.add(it.id) }

        // 5. If targetProduct has barcodes in product_barcodes table, any other product having those barcodes
        val parentBarcodes = productBarcodeDao.getBarcodesForProductList(targetProduct.id)
        for (pb in parentBarcodes) {
            allProducts.filter { prod ->
                prod.id != targetProduct.id &&
                !prod.barcode.isNullOrBlank() &&
                BarcodeMatcher.isExactMatch(prod.barcode, pb.barcode)
            }.forEach { linkedIds.add(it.id) }
        }

        allProducts.filter { it.id in linkedIds }
    }

    /**
     * Updates the price of [targetProduct] AND all products linked to it by barcode or parent/flavor group.
     * Returns the list of all updated products (including targetProduct).
     */
    suspend fun updateProductPriceAndLinked(targetProduct: ProductEntity, newPrice: Double): List<ProductEntity> = withContext(Dispatchers.IO) {
        val linked = getLinkedBarcodeProducts(targetProduct)
        val allToUpdateIds = (linked.map { it.id } + targetProduct.id).distinct()

        if (allToUpdateIds.isNotEmpty()) {
            productDao.updateProductsPrice(allToUpdateIds, newPrice)
        }

        val allProducts = productDao.getAllProductsList()
        allProducts.filter { it.id in allToUpdateIds }
    }

    // --- Linked Barcodes (Parent-Child Flavors / Multi-Barcodes) ---

    fun getBarcodesForProduct(parentProductId: Long): Flow<List<ProductBarcodeEntity>> {
        return productBarcodeDao.getBarcodesForProduct(parentProductId)
    }

    suspend fun getBarcodesForProductList(parentProductId: Long): List<ProductBarcodeEntity> = withContext(Dispatchers.IO) {
        productBarcodeDao.getBarcodesForProductList(parentProductId)
    }

    suspend fun getAllBarcodesList(): List<ProductBarcodeEntity> = withContext(Dispatchers.IO) {
        productBarcodeDao.getAllBarcodesList()
    }

    suspend fun addBarcodeToProduct(parentProductId: Long, barcode: String, label: String? = null): Long = withContext(Dispatchers.IO) {
        val cleanBarcode = BarcodeMatcher.normalizeBarcode(barcode)
        if (cleanBarcode.isBlank()) return@withContext 0L
        val entity = ProductBarcodeEntity(
            parentProductId = parentProductId,
            barcode = cleanBarcode,
            label = label?.trim()?.ifEmpty { null }
        )
        productBarcodeDao.insertBarcode(entity)
    }

    suspend fun removeBarcode(barcodeId: Long) = withContext(Dispatchers.IO) {
        productBarcodeDao.deleteBarcodeById(barcodeId)
    }

    suspend fun linkProductToParent(childProductId: Long, parentProductId: Long) = withContext(Dispatchers.IO) {
        productDao.updateParentProductId(childProductId, parentProductId)
    }

    suspend fun unlinkProductFromParent(childProductId: Long) = withContext(Dispatchers.IO) {
        productDao.updateParentProductId(childProductId, null)
    }

    // --- Sales / Invoices ---

    suspend fun completeSale(
        invoice: SaleInvoiceEntity,
        items: List<SaleItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        val invoiceId = saleDao.insertInvoice(invoice)
        val itemsWithInvoiceId = items.map { it.copy(invoiceId = invoiceId) }
        saleDao.insertSaleItems(itemsWithInvoiceId)
        invoiceId
    }

    suspend fun getInvoiceDetails(invoiceId: Long): InvoiceWithItems? = withContext(Dispatchers.IO) {
        saleDao.getInvoiceWithItemsById(invoiceId)
    }

    suspend fun getAllProductsList(): List<ProductEntity> = withContext(Dispatchers.IO) {
        productDao.getAllProductsList()
    }

    suspend fun getAllInvoicesWithItemsList(): List<InvoiceWithItems> = withContext(Dispatchers.IO) {
        saleDao.getAllInvoicesWithItemsList()
    }

    suspend fun importBackup(
        products: List<ProductEntity>,
        invoices: List<Pair<SaleInvoiceEntity, List<SaleItemEntity>>>
    ): com.example.data.backup.BackupImportResult = withContext(Dispatchers.IO) {
        try {
            val normalizedProducts = products.map { prod ->
                prod.copy(
                    barcode = prod.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } },
                    shortcutCode = prod.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                )
            }
            if (normalizedProducts.isNotEmpty()) {
                productDao.insertProducts(normalizedProducts)
            }
            for ((inv, items) in invoices) {
                val newInvoiceId = saleDao.insertInvoice(inv)
                val mappedItems = items.map { it.copy(invoiceId = newInvoiceId) }
                saleDao.insertSaleItems(mappedItems)
            }
            com.example.data.backup.BackupImportResult(
                productsImported = normalizedProducts.size,
                invoicesImported = invoices.size,
                errorMessage = null
            )
        } catch (e: Exception) {
            com.example.data.backup.BackupImportResult(
                productsImported = 0,
                invoicesImported = 0,
                errorMessage = e.localizedMessage ?: "حدث خطأ أثناء استيراد البيانات"
            )
        }
    }
}
