package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProductBarcodeEntity
import com.example.data.model.ProductEntity
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.util.BarcodeMatcher
import com.example.ui.util.NumberUtils

@Composable
fun EditProductPriceDialog(
    product: ProductEntity,
    allProducts: List<ProductEntity>,
    allProductBarcodes: List<ProductBarcodeEntity>,
    onSavePrice: (Double) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var newPriceText by remember {
        mutableStateOf(NumberUtils.formatNumber(product.price))
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Find all other products linked to this product by barcode or parent/child group
    val linkedProducts = remember(product, allProducts, allProductBarcodes) {
        val linkedIds = mutableSetOf<Long>()
        val normBarcode = product.barcode?.let { BarcodeMatcher.normalizeBarcode(it) }?.ifEmpty { null }

        // 1. Same normalized barcode in products list
        if (!normBarcode.isNullOrBlank()) {
            allProducts.filter { p ->
                p.id != product.id &&
                        !p.barcode.isNullOrBlank() &&
                        BarcodeMatcher.isExactMatch(p.barcode, normBarcode)
            }.forEach { linkedIds.add(it.id) }
        }

        // 2. Linked via product_barcodes table (if product's barcode is linked to a parent)
        if (!normBarcode.isNullOrBlank()) {
            val matchingBarcodeEntities = allProductBarcodes.filter {
                BarcodeMatcher.isExactMatch(it.barcode, normBarcode)
            }
            for (be in matchingBarcodeEntities) {
                if (be.parentProductId != product.id) {
                    linkedIds.add(be.parentProductId)
                }
            }
        }

        // 3. If product has parentProductId
        if (product.parentProductId != null && product.parentProductId > 0) {
            linkedIds.add(product.parentProductId)
            allProducts.filter { it.parentProductId == product.parentProductId && it.id != product.id }
                .forEach { linkedIds.add(it.id) }
        }

        // 4. If product is a parent with child products
        allProducts.filter { it.parentProductId == product.id }
            .forEach { linkedIds.add(it.id) }

        // 5. If product has barcodes in allProductBarcodes, other products having those barcodes
        val parentBarcodes = allProductBarcodes.filter { it.parentProductId == product.id }
        for (pb in parentBarcodes) {
            allProducts.filter { p ->
                p.id != product.id &&
                        !p.barcode.isNullOrBlank() &&
                        BarcodeMatcher.isExactMatch(p.barcode, pb.barcode)
            }.forEach { linkedIds.add(it.id) }
        }

        allProducts.filter { it.id in linkedIds }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFEFF6FF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = PosBluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "تعديل سعر المنتج",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "تحديث السعر وتوحيده لجميع النكهات المرتبطة",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Product Info Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (product.iconEmoji.isNotBlank()) {
                                Text(product.iconEmoji, fontSize = 20.sp)
                            }
                            Text(
                                text = product.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF1E293B)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = null,
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = if (product.barcode.isNullOrBlank()) "بدون باركود" else "الباركود: ${product.barcode}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF475569)
                                )
                            }

                            Text(
                                text = "السعر الحالي: ${NumberUtils.formatNumber(product.price)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                        }
                    }
                }

                // New Price Input Field
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = newPriceText,
                        onValueChange = {
                            newPriceText = it
                            errorMessage = null
                        },
                        label = { Text("السعر الجديد *") },
                        placeholder = { Text("0.00") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                tint = PosGreenCashLight
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_new_price"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PosBluePrimary,
                            unfocusedBorderColor = Color(0xFFCBD5E1)
                        )
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFDC2626),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Linked Products Alert (if any other products share this barcode)
                if (linkedProducts.isNotEmpty()) {
                    Surface(
                        color = Color(0xFFFFFBEB),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Link,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "تنبيه: يوجد ${linkedProducts.size} منتجات/نكهات أخرى مرتبطة بهذا الباركود:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF92400E)
                                )
                            }

                            Text(
                                text = "سيتم تلقائياً تحديث سعرها إلى السعر الجديد للحفاظ على توحيد الأسعار ومنع أي تضارب عند البيع:",
                                fontSize = 11.sp,
                                color = Color(0xFF78350F)
                            )

                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(if (linkedProducts.size > 2) 90.dp else 50.dp)
                            ) {
                                items(linkedProducts, key = { it.id }) { lp ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "• ${lp.name}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF1E293B)
                                        )
                                        Text(
                                            text = "السعر الحالي: ${NumberUtils.formatNumber(lp.price)}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            val parsedPrice = newPriceText.trim().toDoubleOrNull()
                            if (parsedPrice == null || parsedPrice < 0) {
                                errorMessage = "يرجى إدخال سعر صحيح (رقم موجب)"
                            } else {
                                onSavePrice(parsedPrice)
                                onDismiss()
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("btn_confirm_save_price"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary)
                    ) {
                        Text(
                            text = if (linkedProducts.isNotEmpty()) "حفظ وتحديث الكل (${linkedProducts.size + 1})" else "حفظ السعر الجديد",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
