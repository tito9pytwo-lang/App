package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.model.ProductEntity
import com.example.data.repository.PosRepository
import com.example.ui.PosUiState
import com.example.ui.model.CartItem
import com.example.ui.util.CommercialProductMatcher
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProductPriceUpdateTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: PosRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = PosRepository(db.productDao(), db.productBarcodeDao(), db.saleDao())
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `updating price of a product sharing barcode updates all products linked to that barcode`() = runBlocking {
        // 1. Create three products sharing the same barcode "777111" with initial price 2.0
        val p1 = ProductEntity(name = "علكة فراولة", barcode = "777111", price = 2.0, category = "شركة X")
        val p2 = ProductEntity(name = "علكة نعناع", barcode = "777111", price = 2.0, category = "شركة X")
        val p3 = ProductEntity(name = "علكة فواكه", barcode = "777111", price = 2.0, category = "شركة X")
        val unrelated = ProductEntity(name = "ماء", barcode = "999888", price = 1.0)

        val id1 = db.productDao().insertProduct(p1)
        val id2 = db.productDao().insertProduct(p2)
        val id3 = db.productDao().insertProduct(p3)
        val idUnrelated = db.productDao().insertProduct(unrelated)

        val savedP1 = db.productDao().getProductById(id1)!!

        // 2. Query linked products for p1
        val linked = repository.getLinkedBarcodeProducts(savedP1)
        assertEquals("Should identify 2 other products sharing barcode", 2, linked.size)
        val linkedIds = linked.map { it.id }.toSet()
        assertTrue(linkedIds.contains(id2))
        assertTrue(linkedIds.contains(id3))

        // 3. Update price of p1 to 3.5 using updateProductPriceAndLinked
        val updatedList = repository.updateProductPriceAndLinked(savedP1, 3.5)
        assertEquals("All 3 products must be updated", 3, updatedList.size)

        // 4. Verify all 3 products in database now have price 3.5
        val p1Reloaded = db.productDao().getProductById(id1)!!
        val p2Reloaded = db.productDao().getProductById(id2)!!
        val p3Reloaded = db.productDao().getProductById(id3)!!
        val unrelatedReloaded = db.productDao().getProductById(idUnrelated)!!

        assertEquals(3.5, p1Reloaded.price, 0.001)
        assertEquals(3.5, p2Reloaded.price, 0.001)
        assertEquals(3.5, p3Reloaded.price, 0.001)
        assertEquals(1.0, unrelatedReloaded.price, 0.001) // Unrelated product remains unchanged

        // 5. Verify scanning after price update continues to resolve seamlessly without dialog
        val matched = repository.findProductsByBarcode("777111")
        val resolution = CommercialProductMatcher.resolveBarcodeMatches(matched)
        assertTrue(
            "All variants have identical new price 3.5, so resolution must remain Single (no dialog)",
            resolution is CommercialProductMatcher.BarcodeResolution.Single
        )
    }

    @Test
    fun `updating price of parent product updates linked child variants`() = runBlocking {
        // Create parent product
        val parent = ProductEntity(name = "عصير طبيعي مشكل", price = 10.0)
        val parentId = db.productDao().insertProduct(parent)

        // Create child variants linked to parent
        val orangeChild = ProductEntity(name = "عصير برتقال", price = 10.0, parentProductId = parentId)
        val mangoChild = ProductEntity(name = "عصير مانجو", price = 10.0, parentProductId = parentId)
        val childId1 = db.productDao().insertProduct(orangeChild)
        val childId2 = db.productDao().insertProduct(mangoChild)

        // Update price of parent to 14.0
        val savedParent = db.productDao().getProductById(parentId)!!
        repository.updateProductPriceAndLinked(savedParent, 14.0)

        // Verify parent and children all have price 14.0
        assertEquals(14.0, db.productDao().getProductById(parentId)!!.price, 0.001)
        assertEquals(14.0, db.productDao().getProductById(childId1)!!.price, 0.001)
        assertEquals(14.0, db.productDao().getProductById(childId2)!!.price, 0.001)
    }

    @Test
    fun `updating price of a child variant updates parent and sibling variants`() = runBlocking {
        // Create parent product
        val parent = ProductEntity(name = "بسكويت سادة", price = 4.0)
        val parentId = db.productDao().insertProduct(parent)

        // Child variant
        val child1 = ProductEntity(name = "بسكويت شوكولاتة", price = 4.0, parentProductId = parentId)
        val childId1 = db.productDao().insertProduct(child1)

        val savedChild = db.productDao().getProductById(childId1)!!

        // Update child price to 5.5
        repository.updateProductPriceAndLinked(savedChild, 5.5)

        // Verify both parent and child updated to 5.5
        assertEquals(5.5, db.productDao().getProductById(parentId)!!.price, 0.001)
        assertEquals(5.5, db.productDao().getProductById(childId1)!!.price, 0.001)
    }
}
