package com.example.data.repository

import com.example.data.InitialData
import com.example.data.dao.ProductDao
import com.example.data.dao.SaleDao
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import com.example.ui.util.BarcodeMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PosRepository(
    private val productDao: ProductDao,
    private val saleDao: SaleDao
) {
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val shortcutProducts: Flow<List<ProductEntity>> = productDao.getShortcutProducts()
    val allInvoices: Flow<List<InvoiceWithItems>> = saleDao.getAllInvoicesWithItems()
    val totalInvoiceCount: Flow<Int> = saleDao.getTotalInvoiceCount()
    val totalSalesAmount: Flow<Double> = saleDao.getTotalSalesAmount()

    suspend fun checkAndSeedInitialData() = withContext(Dispatchers.IO) {
        if (productDao.getProductCount() == 0) {
            productDao.insertProducts(InitialData.sampleProducts)
        }
        sanitizeExistingBarcodes()
    }

    /**
     * Sanitizes barcodes and shortcut codes in existing database records
     * so that all records are in standard normalized string format.
     */
    suspend fun sanitizeExistingBarcodes() = withContext(Dispatchers.IO) {
        try {
            val list = productDao.getAllProductsList()
            for (prod in list) {
                val cleanBarcode = prod.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                val cleanShortcut = prod.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                if (cleanBarcode != prod.barcode || cleanShortcut != prod.shortcutCode) {
                    productDao.updateProduct(prod.copy(barcode = cleanBarcode, shortcutCode = cleanShortcut))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Finds a product by exact barcode (or shortcut code).
     * Strictly treats the barcode as a String without numerical conversion.
     * Preserves leading zeros and normalizes digits and whitespace.
     * Logs diagnostic output as required.
     */
    suspend fun findProductByBarcode(scannedBarcode: String): ProductEntity? = withContext(Dispatchers.IO) {
        val raw = scannedBarcode
        val norm = BarcodeMatcher.normalizeBarcode(raw)
        if (norm.isEmpty()) {
            BarcodeMatcher.logDiagnostic(raw, norm, null)
            return@withContext null
        }

        // 1. Direct database exact query
        var product = productDao.getProductByBarcodeOrShortcut(norm)

        // 2. Fallback: Trimmed database query
        if (product == null) {
            product = productDao.getProductByTrimmedBarcodeOrShortcut(norm)
        }

        // 3. Fallback: In-memory exact search across all products (handles any non-normalized stored records)
        if (product == null) {
            val all = productDao.getAllProductsList()
            product = BarcodeMatcher.findMatch(norm, all)
        }

        // 4. Log diagnostics strictly matching requested format
        BarcodeMatcher.logDiagnostic(
            scannedBarcode = raw,
            normalizedBarcode = norm,
            foundProduct = product
        )

        product
    }

    suspend fun findProductByCodeOrShortcut(code: String): ProductEntity? = withContext(Dispatchers.IO) {
        findProductByBarcode(code)
    }

    suspend fun findProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return productDao.searchProducts(query)
    }

    suspend fun saveProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        val normalizedProduct = product.copy(
            barcode = product.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } },
            shortcutCode = product.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
        )
        if (normalizedProduct.id == 0L) {
            productDao.insertProduct(normalizedProduct)
        } else {
            productDao.updateProduct(normalizedProduct)
            normalizedProduct.id
        }
    }

    suspend fun updateShortcutCode(productId: Long, shortcutCode: String?) = withContext(Dispatchers.IO) {
        val cleanCode = shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
        productDao.updateShortcutCode(productId, cleanCode)
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(product)
    }

    suspend fun completeSale(
        invoice: SaleInvoiceEntity,
        items: List<SaleItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        val invoiceId = saleDao.insertInvoice(invoice)
        val itemsWithInvoiceId = items.map { it.copy(invoiceId = invoiceId) }
        saleDao.insertSaleItems(itemsWithInvoiceId)
        invoiceId
    }

    suspend fun getInvoiceDetails(invoiceId: Long): InvoiceWithItems? = withContext(Dispatchers.IO) {
        saleDao.getInvoiceWithItemsById(invoiceId)
    }

    suspend fun getAllProductsList(): List<ProductEntity> = withContext(Dispatchers.IO) {
        productDao.getAllProductsList()
    }

    suspend fun getAllInvoicesWithItemsList(): List<InvoiceWithItems> = withContext(Dispatchers.IO) {
        saleDao.getAllInvoicesWithItemsList()
    }

    suspend fun importBackup(
        products: List<ProductEntity>,
        invoices: List<Pair<SaleInvoiceEntity, List<SaleItemEntity>>>
    ): com.example.data.backup.BackupImportResult = withContext(Dispatchers.IO) {
        try {
            val normalizedProducts = products.map { prod ->
                prod.copy(
                    barcode = prod.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } },
                    shortcutCode = prod.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
                )
            }
            if (normalizedProducts.isNotEmpty()) {
                productDao.insertProducts(normalizedProducts)
            }
            for ((inv, items) in invoices) {
                val newInvoiceId = saleDao.insertInvoice(inv)
                val mappedItems = items.map { it.copy(invoiceId = newInvoiceId) }
                saleDao.insertSaleItems(mappedItems)
            }
            com.example.data.backup.BackupImportResult(
                productsImported = normalizedProducts.size,
                invoicesImported = invoices.size,
                errorMessage = null
            )
        } catch (e: Exception) {
            com.example.data.backup.BackupImportResult(
                productsImported = 0,
                invoicesImported = 0,
                errorMessage = e.localizedMessage ?: "حدث خطأ أثناء استيراد البيانات"
            )
        }
    }
}
