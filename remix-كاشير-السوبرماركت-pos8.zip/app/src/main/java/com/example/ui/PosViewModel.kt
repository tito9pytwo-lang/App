package com.example.ui

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import com.example.data.repository.PosRepository
import com.example.ui.model.CartItem
import com.example.ui.model.NumPadMode
import com.example.ui.model.PosTab
import com.example.ui.util.BarcodeMatcher
import com.example.ui.util.NumberUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class PosUiState(
    val cartItems: List<CartItem> = emptyList(),
    val selectedCartIndex: Int? = null,
    val numPadBuffer: String = "",
    val numPadMode: NumPadMode = NumPadMode.BARCODE, // Default mode for fast code/shortcut input
    val manualCodeInput: String = "",
    val invoiceNumber: String = generateInvoiceNumber(),
    val cashierName: String = "كاشير 1",
    val isScannerOpen: Boolean = false,
    val isPaymentDialogOpen: Boolean = false,
    val isQuickProductsSheetOpen: Boolean = false,
    val isAddProductDialogOpen: Boolean = false,
    val isUnregisteredPromptOpen: Boolean = false,
    val isAssignShortcutDialogOpen: Boolean = false,
    val shortcutAssignmentTargetProduct: ProductEntity? = null,
    val pendingShortcutCodeToAssign: String? = null,
    val isProductManagementOpen: Boolean = false,
    val isSalesHistoryOpen: Boolean = false,
    val unregisteredBarcode: String? = null,
    val lastCompletedInvoice: InvoiceWithItems? = null,
    val isReceiptDialogOpen: Boolean = false,
    val bannerMessage: String? = null,
    val activeTab: PosTab = PosTab.POS,
    val heldCarts: List<HeldCart> = emptyList(),
    val isDataTransferDialogOpen: Boolean = false
) {
    val totalAmount: Double
        get() = cartItems.sumOf { it.totalPrice }

    val totalQuantity: Double
        get() = cartItems.sumOf { it.quantity }

    val distinctItemCount: Int
        get() = cartItems.size

    val selectedCartItem: CartItem?
        get() = selectedCartIndex?.let { cartItems.getOrNull(it) }

    companion object {
        fun generateInvoiceNumber(): String {
            val dateStr = SimpleDateFormat("yyMMdd-HHmm", Locale.ENGLISH).format(Date())
            val randomSuffix = (100..999).random()
            return "INV-$dateStr-$randomSuffix"
        }
    }
}

data class HeldCart(
    val id: String = UUID.randomUUID().toString(),
    val invoiceNumber: String,
    val timeFormatted: String,
    val items: List<CartItem>,
    val totalAmount: Double
)

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PosRepository
    private val vibrator: Vibrator?
    private var toneGenerator: ToneGenerator? = null

    private val _uiState = MutableStateFlow(PosUiState())
    val uiState: StateFlow<PosUiState> = _uiState.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = PosRepository(database.productDao(), database.saleDao())

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        // Initialize audio ToneGenerator for crisp barcode scan beep
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }

    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val shortcutProducts: StateFlow<List<ProductEntity>> = repository.shortcutProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allInvoices: StateFlow<List<InvoiceWithItems>> = repository.allInvoices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val totalSalesAmount: StateFlow<Double> = repository.totalSalesAmount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    val totalInvoiceCount: StateFlow<Int> = repository.totalInvoiceCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    /**
     * Crisp supermarket scanner "تك / Beep" alert sound.
     */
    fun playScanBeep() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
        } catch (_: Exception) {}
    }

    private fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(45)
            }
        } catch (_: Exception) {}
    }

    fun showBanner(message: String) {
        _uiState.update { it.copy(bannerMessage = message) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }

    fun setActiveTab(tab: PosTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun setManualCodeInput(text: String) {
        _uiState.update { it.copy(manualCodeInput = text) }
    }

    /**
     * Add product to cart or increment quantity if already present.
     * Always plays the crisp "تك / Beep" sound and haptic feedback.
     */
    fun addProductToCart(product: ProductEntity, qtyToAdd: Double = 1.0) {
        playScanBeep()
        triggerHaptic()

        _uiState.update { state ->
            val normProdBarcode = product.barcode?.let { BarcodeMatcher.normalizeBarcode(it) } ?: ""
            val existingIndex = state.cartItems.indexOfFirst { item ->
                val itemBarcode = item.product.barcode?.let { BarcodeMatcher.normalizeBarcode(it) } ?: ""
                (item.product.id > 0 && product.id > 0 && item.product.id == product.id) ||
                        (normProdBarcode.isNotEmpty() && itemBarcode.isNotEmpty() && normProdBarcode == itemBarcode)
            }

            val updatedCart = if (existingIndex >= 0) {
                state.cartItems.mapIndexed { index, item ->
                    if (index == existingIndex) {
                        item.copy(quantity = item.quantity + qtyToAdd)
                    } else {
                        item
                    }
                }
            } else {
                state.cartItems + CartItem(
                    product = product,
                    quantity = qtyToAdd,
                    unitPrice = product.price
                )
            }

            val targetIndex = if (existingIndex >= 0) existingIndex else updatedCart.lastIndex

            state.copy(
                cartItems = updatedCart,
                selectedCartIndex = targetIndex,
                numPadBuffer = "",
                isUnregisteredPromptOpen = false,
                isAddProductDialogOpen = false,
                unregisteredBarcode = null,
                bannerMessage = "تمت إضافة: ${product.name} (السعر: ${NumberUtils.formatNumber(product.price)}) - الكمية: ${NumberUtils.formatNumber(updatedCart[targetIndex].quantity)}"
            )
        }
    }

    /**
     * Core barcode processing flow:
     * 1. Barcode is read as String.
     * 2. Barcode is normalized (whitespace, invisible chars, Arabic numerals converted; leading zeros preserved).
     * 3. Database is searched for exact match (Barcode -> Barcode).
     * 4. If found:
     *    - Extract product name and price.
     *    - Add product directly to cart (or increment quantity if already scanned).
     *    - DO NOT show any registration dialog.
     * 5. If NOT found:
     *    - Show "هذا المنتج غير مسجل" prompt with [تسجيل منتج جديد] and [إلغاء].
     */
    fun onBarcodeScanned(barcode: String) {
        val normalizedCode = BarcodeMatcher.normalizeBarcode(barcode)
        if (normalizedCode.isBlank()) return

        viewModelScope.launch {
            val matchedProduct = repository.findProductByBarcode(barcode)
            if (matchedProduct != null) {
                // Product found! Add to cart directly without prompting for registration
                addProductToCart(matchedProduct, 1.0)
            } else {
                // Barcode truly not found in database: show unregistered prompt
                triggerHaptic()
                _uiState.update {
                    it.copy(
                        unregisteredBarcode = normalizedCode,
                        isUnregisteredPromptOpen = true,
                        isAddProductDialogOpen = false,
                        bannerMessage = "هذا المنتج غير مسجل ($normalizedCode)"
                    )
                }
            }
        }
    }

    fun onCodeOrShortcutEntered(code: String) {
        onBarcodeScanned(code)
    }

    fun submitManualCode() {
        val code = _uiState.value.manualCodeInput
        if (code.isBlank()) return
        _uiState.update { it.copy(manualCodeInput = "") }
        onBarcodeScanned(code)
    }

    fun proceedToRegisterUnregisteredProduct() {
        val barcode = _uiState.value.unregisteredBarcode
        _uiState.update {
            it.copy(
                isUnregisteredPromptOpen = false,
                isAddProductDialogOpen = true,
                pendingShortcutCodeToAssign = barcode
            )
        }
    }

    fun dismissUnregisteredPrompt() {
        _uiState.update {
            it.copy(
                isUnregisteredPromptOpen = false,
                unregisteredBarcode = null
            )
        }
    }

    fun selectCartItem(index: Int) {
        _uiState.update {
            it.copy(
                selectedCartIndex = index,
                numPadBuffer = ""
            )
        }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedCartIndex = null, numPadBuffer = "") }
    }

    fun incrementSelectedQuantity(amount: Double = 1.0) {
        val index = _uiState.value.selectedCartIndex ?: _uiState.value.cartItems.lastIndex
        if (index in _uiState.value.cartItems.indices) {
            playScanBeep()
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(quantity = item.quantity + amount) else item
                }
                state.copy(cartItems = updated)
            }
        }
    }

    fun decrementSelectedQuantity(amount: Double = 1.0) {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices) {
            triggerHaptic()
            _uiState.update { state ->
                val current = state.cartItems[index]
                if (current.quantity - amount <= 0.0) {
                    val updated = state.cartItems.filterIndexed { idx, _ -> idx != index }
                    val newIndex = if (updated.isEmpty()) null else (index - 1).coerceAtLeast(0)
                    state.copy(
                        cartItems = updated,
                        selectedCartIndex = newIndex,
                        bannerMessage = "تم حذف الصنف: ${current.product.name}"
                    )
                } else {
                    val updated = state.cartItems.mapIndexed { idx, item ->
                        if (idx == index) item.copy(quantity = item.quantity - amount) else item
                    }
                    state.copy(cartItems = updated)
                }
            }
        }
    }

    fun deleteSelectedCartItem() {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices) {
            triggerHaptic()
            _uiState.update { state ->
                val item = state.cartItems[index]
                val updated = state.cartItems.filterIndexed { idx, _ -> idx != index }
                val newIndex = if (updated.isEmpty()) null else (index - 1).coerceAtLeast(0)
                state.copy(
                    cartItems = updated,
                    selectedCartIndex = newIndex,
                    numPadBuffer = "",
                    bannerMessage = "تم حذف: ${item.product.name}"
                )
            }
        }
    }

    fun updateSelectedItemQuantity(newQty: Double) {
        val index = _uiState.value.selectedCartIndex ?: _uiState.value.cartItems.lastIndex
        if (index in _uiState.value.cartItems.indices && newQty > 0) {
            playScanBeep()
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(quantity = newQty) else item
                }
                state.copy(
                    cartItems = updated,
                    selectedCartIndex = index,
                    numPadBuffer = "",
                    bannerMessage = "تم تعيين الكمية: ${NumberUtils.formatNumber(newQty)} لـ ${updated[index].product.name}"
                )
            }
        }
    }

    /**
     * Sets the quantity directly from the numpad buffer (e.g. user typed 100).
     */
    fun setQuantityFromBuffer() {
        val buffer = _uiState.value.numPadBuffer.trim()
        val qty = buffer.toDoubleOrNull()
        if (qty != null && qty > 0) {
            updateSelectedItemQuantity(qty)
        } else {
            showBanner("يرجى كتابة رقم الكمية أولاً من لوحة الأرقام (مثال: 100)")
        }
    }

    fun updateSelectedItemPrice(newPrice: Double) {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices && newPrice >= 0) {
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(unitPrice = newPrice) else item
                }
                state.copy(cartItems = updated, numPadBuffer = "")
            }
        }
    }

    // --- Keypad Handlers ---
    fun setNumPadMode(mode: NumPadMode) {
        _uiState.update { it.copy(numPadMode = mode, numPadBuffer = "") }
    }

    fun onNumPadKeyPress(key: String) {
        triggerHaptic()
        val currentBuffer = _uiState.value.numPadBuffer
        when (key) {
            "C" -> {
                _uiState.update { it.copy(numPadBuffer = "") }
            }
            "DEL", "⌫" -> {
                if (currentBuffer.isNotEmpty()) {
                    _uiState.update { it.copy(numPadBuffer = currentBuffer.dropLast(1)) }
                }
            }
            "." -> {
                if (!currentBuffer.contains(".")) {
                    val newBuffer = if (currentBuffer.isEmpty()) "0." else "$currentBuffer."
                    _uiState.update { it.copy(numPadBuffer = newBuffer) }
                }
            }
            "OK", "ENTER" -> {
                applyNumPadBuffer()
            }
            else -> {
                // Digits 0-9
                if (currentBuffer.length < 18) {
                    val newBuffer = if (currentBuffer.isEmpty()) key else currentBuffer + key
                    _uiState.update { it.copy(numPadBuffer = newBuffer) }
                }
            }
        }
    }

    fun applyNumPadBuffer() {
        val state = _uiState.value
        val buffer = state.numPadBuffer.trim()
        if (buffer.isEmpty()) return

        when (state.numPadMode) {
            NumPadMode.QUANTITY -> {
                val qty = buffer.toDoubleOrNull()
                if (qty != null && qty > 0) {
                    updateSelectedItemQuantity(qty)
                }
            }
            NumPadMode.PRICE -> {
                val price = buffer.toDoubleOrNull()
                if (price != null && price >= 0) {
                    updateSelectedItemPrice(price)
                }
            }
            NumPadMode.BARCODE -> {
                viewModelScope.launch {
                    val matchedProduct = repository.findProductByBarcode(buffer)
                    if (matchedProduct != null) {
                        addProductToCart(matchedProduct, 1.0)
                        _uiState.update { it.copy(numPadBuffer = "") }
                    } else if (state.selectedCartIndex != null) {
                        val qty = buffer.toDoubleOrNull()
                        if (qty != null && qty > 0) {
                            updateSelectedItemQuantity(qty)
                        } else {
                            onBarcodeScanned(buffer)
                        }
                    } else {
                        onBarcodeScanned(buffer)
                    }
                }
            }
            NumPadMode.CASH_PAID -> {}
        }
    }

    // --- Custom Shortcuts Assignment ---
    fun openAssignShortcutDialog(targetProduct: ProductEntity? = null, presetCode: String? = null) {
        _uiState.update {
            it.copy(
                isAssignShortcutDialogOpen = true,
                shortcutAssignmentTargetProduct = targetProduct,
                pendingShortcutCodeToAssign = presetCode ?: it.pendingShortcutCodeToAssign
            )
        }
    }

    fun closeAssignShortcutDialog() {
        _uiState.update {
            it.copy(
                isAssignShortcutDialogOpen = false,
                shortcutAssignmentTargetProduct = null,
                pendingShortcutCodeToAssign = null
            )
        }
    }

    fun assignShortcutCode(productId: Long, newShortcutCode: String?) {
        viewModelScope.launch {
            repository.updateShortcutCode(productId, newShortcutCode)
            closeAssignShortcutDialog()
            showBanner("تم حفظ كود الاختصار ($newShortcutCode) للمنتج بنجاح!")
        }
    }

    // --- Hold / Park Invoice ---
    fun holdCurrentInvoice() {
        val state = _uiState.value
        if (state.cartItems.isEmpty()) {
            showBanner("لا توجد منتجات لحفظ الفاتورة الحالية في الانتظار")
            return
        }

        val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val heldCart = HeldCart(
            invoiceNumber = state.invoiceNumber,
            timeFormatted = timeFormatted,
            items = state.cartItems,
            totalAmount = state.totalAmount
        )

        _uiState.update {
            it.copy(
                heldCarts = it.heldCarts + heldCart,
                cartItems = emptyList(),
                selectedCartIndex = null,
                invoiceNumber = PosUiState.generateInvoiceNumber(),
                bannerMessage = "تم حفظ الفاتورة في الانتظار (#${heldCart.invoiceNumber})"
            )
        }
    }

    fun recallHeldInvoice(heldCart: HeldCart) {
        _uiState.update { state ->
            state.copy(
                heldCarts = state.heldCarts.filter { it.id != heldCart.id },
                cartItems = heldCart.items,
                selectedCartIndex = if (heldCart.items.isNotEmpty()) 0 else null,
                invoiceNumber = heldCart.invoiceNumber,
                bannerMessage = "تم استرجاع الفاتورة (#${heldCart.invoiceNumber})"
            )
        }
    }

    // --- Invoice Lifecycle ---
    fun startNewInvoice() {
        _uiState.update {
            it.copy(
                cartItems = emptyList(),
                selectedCartIndex = null,
                numPadBuffer = "",
                invoiceNumber = PosUiState.generateInvoiceNumber(),
                bannerMessage = "تم تفريغ الفاتورة للبدء من جديد"
            )
        }
    }

    // --- Cash Checkout & Completion ---
    fun openPaymentDialog() {
        if (_uiState.value.cartItems.isEmpty()) {
            showBanner("الفاتورة فارغة! أضف منتجات أولاً.")
            return
        }
        _uiState.update { it.copy(isPaymentDialogOpen = true) }
    }

    fun closePaymentDialog() {
        _uiState.update { it.copy(isPaymentDialogOpen = false) }
    }

    /**
     * Direct clean cash completion: records sale, clears cart, closes dialog.
     */
    fun completeCashPayment() {
        val state = _uiState.value
        if (state.cartItems.isEmpty()) return

        val total = state.totalAmount

        val invoiceEntity = SaleInvoiceEntity(
            invoiceNumber = state.invoiceNumber,
            timestamp = System.currentTimeMillis(),
            totalAmount = total,
            paidAmount = total,
            changeAmount = 0.0,
            paymentMethod = "كاش",
            itemCount = state.cartItems.size,
            cashierName = state.cashierName
        )

        val saleItems = state.cartItems.map { it.toSaleItem() }

        viewModelScope.launch {
            repository.completeSale(invoiceEntity, saleItems)

            _uiState.update {
                it.copy(
                    cartItems = emptyList(),
                    selectedCartIndex = null,
                    numPadBuffer = "",
                    invoiceNumber = PosUiState.generateInvoiceNumber(),
                    isPaymentDialogOpen = false,
                    bannerMessage = "تم إتمام الكاش بنجاح! الإجمالي: ${NumberUtils.formatNumber(total)}"
                )
            }
        }
    }

    // --- Dialogs & Sheets ---
    fun setScannerOpen(open: Boolean) {
        _uiState.update { it.copy(isScannerOpen = open) }
    }

    fun setQuickProductsSheetOpen(open: Boolean) {
        _uiState.update { it.copy(isQuickProductsSheetOpen = open) }
    }

    fun openAddProductDialog(barcodeOrShortcut: String? = null) {
        val norm = barcodeOrShortcut?.let { BarcodeMatcher.normalizeBarcode(it) }
        _uiState.update {
            it.copy(
                isAddProductDialogOpen = true,
                isUnregisteredPromptOpen = false,
                unregisteredBarcode = norm ?: it.unregisteredBarcode,
                pendingShortcutCodeToAssign = norm ?: it.pendingShortcutCodeToAssign
            )
        }
    }

    fun closeAddProductDialog() {
        _uiState.update {
            it.copy(
                isAddProductDialogOpen = false,
                unregisteredBarcode = null,
                pendingShortcutCodeToAssign = null
            )
        }
    }

    fun saveProduct(product: ProductEntity, addToCartImmediately: Boolean = false) {
        viewModelScope.launch {
            val normalizedProd = product.copy(
                barcode = product.barcode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } },
                shortcutCode = product.shortcutCode?.let { BarcodeMatcher.normalizeBarcode(it).ifEmpty { null } }
            )
            val id = repository.saveProduct(normalizedProd)
            val savedProduct = normalizedProd.copy(id = if (normalizedProd.id == 0L) id else normalizedProd.id)

            if (addToCartImmediately) {
                addProductToCart(savedProduct, 1.0)
            }

            _uiState.update {
                it.copy(
                    isAddProductDialogOpen = false,
                    isUnregisteredPromptOpen = false,
                    unregisteredBarcode = null,
                    pendingShortcutCodeToAssign = null,
                    bannerMessage = "تم حفظ الصنف: ${product.name}"
                )
            }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            showBanner("تم حذف المنتج: ${product.name}")
        }
    }

    // --- Data Export & Transfer Between Devices ---
    fun openDataTransferDialog() {
        _uiState.update { it.copy(isDataTransferDialogOpen = true) }
    }

    fun closeDataTransferDialog() {
        _uiState.update { it.copy(isDataTransferDialogOpen = false) }
    }

    fun exportAndShareData(context: Context) {
        viewModelScope.launch {
            try {
                val products = repository.getAllProductsList()
                val invoices = repository.getAllInvoicesWithItemsList()
                if (products.isEmpty() && invoices.isEmpty()) {
                    showBanner("لا توجد منتجات مسجلة للتصدير! أضف منتجات أولاً.")
                    return@launch
                }
                val json = com.example.data.backup.PosBackupManager.createBackupJson(products, invoices)
                com.example.data.backup.PosBackupManager.shareBackupFile(context, json)
                showBanner("تم إنشاء ملف البيانات بنجاح (${products.size} صنف)")
            } catch (e: Exception) {
                e.printStackTrace()
                showBanner("حدث خطأ أثناء تصدير البيانات: ${e.localizedMessage}")
            }
        }
    }

    fun importDataFromUri(context: Context, uri: android.net.Uri) {
        viewModelScope.launch {
            try {
                val jsonString = com.example.data.backup.PosBackupManager.readBackupFromUri(context, uri)
                if (jsonString.isNullOrBlank()) {
                    showBanner("تعذر قراءة ملف النسخة الاحتياطية")
                    return@launch
                }
                val (products, invoices) = com.example.data.backup.PosBackupManager.parseBackupJson(jsonString)
                val result = repository.importBackup(products, invoices)
                if (result.errorMessage != null) {
                    showBanner("خطأ في الاستيراد: ${result.errorMessage}")
                } else {
                    closeDataTransferDialog()
                    showBanner("تم استيراد ${result.productsImported} منتج و ${result.invoicesImported} عملية مبيعات بنجاح!")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                showBanner("الملف غير صالح أو حدث خطأ أثناء الاستيراد: ${e.localizedMessage}")
            }
        }
    }
}
