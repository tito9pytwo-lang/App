package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.backup.PosBackupManager
import com.example.data.model.ProductEntity
import com.example.ui.model.CartItem
import com.example.ui.util.BarcodeMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("كاشير السوبرماركت POS", appName)
    }

    @Test
    fun `cart item calculation is accurate`() {
        val pepsi = ProductEntity(
            id = 15,
            name = "بيبسي",
            barcode = "6281001234567",
            price = 2.50,
            unit = "علبة"
        )
        val cartItem1 = CartItem(
            product = pepsi,
            quantity = 1.0,
            unitPrice = 2.50
        )
        assertEquals(2.50, cartItem1.totalPrice, 0.001)

        val cartItem2 = cartItem1.copy(quantity = 2.0)
        assertEquals(5.00, cartItem2.totalPrice, 0.001)
    }

    @Test
    fun `custom shortcut code assignment works`() {
        val eggs = ProductEntity(
            name = "طبق بيض طازج",
            shortcutCode = "0",
            price = 18.00,
            unit = "قطعة"
        )
        assertEquals("0", eggs.shortcutCode)
        assertEquals(18.00, eggs.price, 0.001)
    }

    @Test
    fun `barcode normalization cleans whitespace and invisible chars while keeping leading zeros`() {
        // 1. Preserves leading zeros
        assertEquals("0123456789", BarcodeMatcher.normalizeBarcode("0123456789"))
        assertEquals("00123", BarcodeMatcher.normalizeBarcode(" 00123 "))

        // 2. Strips surrounding and internal whitespace
        assertEquals("6281001234567", BarcodeMatcher.normalizeBarcode(" 6281001234567 "))
        assertEquals("6281001234567", BarcodeMatcher.normalizeBarcode("628 100 123 4567"))
        assertEquals("6281001234567", BarcodeMatcher.normalizeBarcode("6281001234567\r\n\t"))

        // 3. Normalizes Arabic-Indic digits to standard digits
        assertEquals("6281001234567", BarcodeMatcher.normalizeBarcode("٦٢٨١٠٠١٢٣٤٥٦٧"))

        // 4. Strips zero-width and BOM characters
        assertEquals("6281001234567", BarcodeMatcher.normalizeBarcode("\uFEFF6281001234567\u200B"))
    }

    @Test
    fun `barcode matcher exact match according to requirements`() {
        val pepsi = ProductEntity(
            id = 15,
            name = "بيبسي",
            barcode = "6281001234567",
            price = 2.50,
            unit = "علبة"
        )

        // Exact match
        assertTrue(BarcodeMatcher.isMatch("6281001234567", pepsi))
        assertTrue(BarcodeMatcher.isMatch(" 6281001234567 ", pepsi))
        assertTrue(BarcodeMatcher.isMatch("6281001234567\r\n", pepsi))
        assertTrue(BarcodeMatcher.isMatch("٦٢٨١٠٠١٢٣٤٥٦٧", pepsi))

        // Different barcode must not match
        assertFalse(BarcodeMatcher.isMatch("6281009999999", pepsi))

        // Leading zeros must be treated strictly as Strings, not Int/Long
        val withZero = ProductEntity(
            name = "منتج مع صفر في البداية",
            barcode = "0123456789",
            price = 10.0
        )
        assertTrue(BarcodeMatcher.isMatch("0123456789", withZero))
        assertTrue(BarcodeMatcher.isMatch(" 0123456789 ", withZero))
        assertFalse(BarcodeMatcher.isMatch("123456789", withZero)) // Leading zero not stripped as number
    }

    @Test
    fun `barcode diagnostic logging prints expected format`() {
        val product = ProductEntity(
            id = 15,
            name = "بيبسي",
            barcode = "6281001234567",
            price = 2.50
        )
        // Verify no crash on log calls
        BarcodeMatcher.logDiagnostic(" 6281001234567 ", "6281001234567", product)
        BarcodeMatcher.logDiagnostic("9999999999999", "9999999999999", null)
    }

    @Test
    fun `backup and restore json fidelity`() {
        val products = listOf(
            ProductEntity(
                name = "طبق بيض طازج",
                barcode = "6281001",
                shortcutCode = "0",
                price = 18.0,
                unit = "طبق",
                category = "ألبان وبيض",
                iconEmoji = "🥚"
            ),
            ProductEntity(
                name = "خبز صامولي",
                barcode = "6281002",
                shortcutCode = "1",
                price = 1.0,
                unit = "كيس",
                category = "مخبوزات",
                iconEmoji = "🥖"
            )
        )

        val jsonString = PosBackupManager.createBackupJson(products, emptyList())
        assertNotNull(jsonString)

        val (parsedProducts, _) = PosBackupManager.parseBackupJson(jsonString)
        assertEquals(2, parsedProducts.size)
        assertEquals("طبق بيض طازج", parsedProducts[0].name)
        assertEquals("0", parsedProducts[0].shortcutCode)
        assertEquals(18.0, parsedProducts[0].price, 0.001)
        assertEquals("خبز صامولي", parsedProducts[1].name)
        assertEquals("1", parsedProducts[1].shortcutCode)
    }
}
