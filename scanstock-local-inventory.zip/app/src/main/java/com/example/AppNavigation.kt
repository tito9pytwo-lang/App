package com.example

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.data.ProductRepository
import com.example.ui.InventoryScreen
import com.example.ui.ScannerScreen
import com.example.viewmodel.InventoryViewModelFactory
import com.example.viewmodel.ScannerViewModelFactory

sealed class Screen(val route: String, @StringRes val titleResId: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Scanner : Screen("scanner", R.string.title_scanner, Icons.Default.QrCodeScanner)
    object Inventory : Screen("inventory", R.string.title_inventory, Icons.Default.List)
}

val items = listOf(
    Screen.Scanner,
    Screen.Inventory
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    
    // Quick DI setup
    val database = AppDatabase.getDatabase(context)
    val repository = ProductRepository(database.productDao())

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = null) },
                        label = { Text(stringResource(id = screen.titleResId)) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(navController, startDestination = Screen.Scanner.route, Modifier.padding(innerPadding)) {
            composable(Screen.Scanner.route) {
                val viewModel: com.example.viewmodel.ScannerViewModel = viewModel(
                    factory = ScannerViewModelFactory(repository)
                )
                ScannerScreen(viewModel = viewModel)
            }
            composable(Screen.Inventory.route) {
                val viewModel: com.example.viewmodel.InventoryViewModel = viewModel(
                    factory = InventoryViewModelFactory(repository)
                )
                InventoryScreen(viewModel = viewModel)
            }
        }
    }
}
