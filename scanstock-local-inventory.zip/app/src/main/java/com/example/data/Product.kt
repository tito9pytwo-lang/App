package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey
    val barcode: String,
    val name: String,
    val price: Double,
    val quantity: Int = 1
) {
    val finalPrice: Double
        get() = price * quantity
}

