package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Product
import com.example.data.ProductRepository
import com.example.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

sealed class ScanResultState {
    object Idle : ScanResultState()
    data class Loading(val barcode: String) : ScanResultState()
    data class Found(val product: Product) : ScanResultState()
    data class NotFound(val barcode: String, val suggestedName: String) : ScanResultState()
}

class ScannerViewModel(private val repository: ProductRepository) : ViewModel() {
    private val _scanState = MutableStateFlow<ScanResultState>(ScanResultState.Idle)
    val scanState: StateFlow<ScanResultState> = _scanState.asStateFlow()
    
    private var isProcessing = false

    fun onBarcodeScanned(barcode: String) {
        if (isProcessing) return
        isProcessing = true
        _scanState.value = ScanResultState.Loading(barcode)
        
        viewModelScope.launch {
            val product = repository.getProduct(barcode).firstOrNull()
            if (product != null) {
                _scanState.value = ScanResultState.Found(product)
            } else {
                var suggestedName = ""
                try {
                    val response = NetworkModule.api.getProduct(barcode)
                    if (response.status == 1 && response.product?.productName != null) {
                        suggestedName = response.product.productName
                    }
                } catch (e: Exception) {
                    // Ignore network errors and continue to manual entry
                }
                _scanState.value = ScanResultState.NotFound(barcode, suggestedName)
            }
        }
    }

    fun saveProduct(barcode: String, name: String, price: Double, quantity: Int) {
        viewModelScope.launch {
            repository.insert(Product(barcode, name, price, quantity))
            resumeScanning()
        }
    }

    fun updateProductQuantity(product: Product, newQuantity: Int) {
        viewModelScope.launch {
            repository.update(product.copy(quantity = newQuantity))
            resumeScanning()
        }
    }

    fun resumeScanning() {
        _scanState.value = ScanResultState.Idle
        isProcessing = false
    }
}
