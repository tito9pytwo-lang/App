package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.TypeConverter
import com.example.data.model.DataSimGuide
import com.example.data.model.InternetPackage
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray

class TelecomTypeConverters {
    @TypeConverter
    fun fromStringList(list: List<String>): String {
        val array = JSONArray()
        list.forEach { array.put(it) }
        return array.toString()
    }

    @TypeConverter
    fun toStringList(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList(array.length()) {
                for (i in 0 until array.length()) {
                    val value = array.optString(i)
                    if (value.isNotBlank()) add(value)
                }
            }
        }.getOrDefault(emptyList())
    }
}

@Dao
interface TelecomDao {

    @Query("SELECT * FROM providers WHERE isActive = 1 ORDER BY sortOrder ASC, nameAr ASC")
    fun observeActiveProviders(): Flow<List<TelecomProvider>>

    @Query("SELECT * FROM providers ORDER BY sortOrder ASC, nameAr ASC")
    fun observeAllProviders(): Flow<List<TelecomProvider>>

    @Query("SELECT * FROM ussd_codes WHERE isActive = 1 ORDER BY providerId ASC, category ASC, serviceNameAr ASC")
    fun observeActiveUssdCodes(): Flow<List<UssdCodeEntry>>

    @Query("SELECT * FROM ussd_codes ORDER BY providerId ASC, category ASC, serviceNameAr ASC")
    fun observeAllUssdCodes(): Flow<List<UssdCodeEntry>>

    @Query("SELECT * FROM packages WHERE isActive = 1 ORDER BY providerId ASC, priceLyd ASC")
    fun observeActivePackages(): Flow<List<InternetPackage>>

    @Query("SELECT * FROM packages ORDER BY providerId ASC, priceLyd ASC")
    fun observeAllPackages(): Flow<List<InternetPackage>>

    @Query("SELECT * FROM data_sim_guides WHERE isActive = 1 ORDER BY providerId ASC")
    fun observeActiveDataSimGuides(): Flow<List<DataSimGuide>>

    @Query("SELECT * FROM user_preferences WHERE id = :id LIMIT 1")
    fun observeUserPreferences(id: String = UserSimPreferences.SIM_CONFIG_ID): Flow<UserSimPreferences?>

    @Query("SELECT COUNT(*) FROM providers")
    suspend fun countProviders(): Int

    @Query("SELECT * FROM providers")
    suspend fun getAllProvidersOnce(): List<TelecomProvider>

    @Query("SELECT * FROM ussd_codes")
    suspend fun getAllUssdCodesOnce(): List<UssdCodeEntry>

    @Query("SELECT * FROM packages")
    suspend fun getAllPackagesOnce(): List<InternetPackage>

    @Query("SELECT * FROM data_sim_guides")
    suspend fun getAllDataSimGuidesOnce(): List<DataSimGuide>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProviders(items: List<TelecomProvider>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProvider(item: TelecomProvider)

    @Query("DELETE FROM providers WHERE id = :id")
    suspend fun deleteProviderById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUssdCodes(items: List<UssdCodeEntry>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUssdCode(item: UssdCodeEntry)

    @Query("DELETE FROM ussd_codes WHERE id = :id")
    suspend fun deleteUssdCodeById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackages(items: List<InternetPackage>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackage(item: InternetPackage)

    @Query("DELETE FROM packages WHERE id = :id")
    suspend fun deletePackageById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDataSimGuides(items: List<DataSimGuide>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDataSimGuide(item: DataSimGuide)

    @Query("DELETE FROM data_sim_guides WHERE id = :id")
    suspend fun deleteDataSimGuideById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUserPreferences(prefs: UserSimPreferences)

    @Transaction
    suspend fun upsertCatalogBundle(
        providers: List<TelecomProvider>,
        codes: List<UssdCodeEntry>,
        packages: List<InternetPackage>,
        guides: List<DataSimGuide>
    ) {
        if (providers.isNotEmpty()) upsertProviders(providers)
        if (codes.isNotEmpty()) upsertUssdCodes(codes)
        if (packages.isNotEmpty()) upsertPackages(packages)
        if (guides.isNotEmpty()) upsertDataSimGuides(guides)
    }
}
