package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.DataSimGuide
import com.example.data.model.InternetPackage
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry

@Database(
    entities = [
        TelecomProvider::class,
        UssdCodeEntry::class,
        InternetPackage::class,
        DataSimGuide::class,
        UserSimPreferences::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(TelecomTypeConverters::class)
abstract class TelecomDatabase : RoomDatabase() {
    abstract fun telecomDao(): TelecomDao

    companion object {
        private const val DATABASE_NAME = "libya_telecom_directory.db"

        @Volatile
        private var instance: TelecomDatabase? = null

        fun getInstance(context: Context): TelecomDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    TelecomDatabase::class.java,
                    DATABASE_NAME
                ).build().also { instance = it }
            }
        }
    }
}
