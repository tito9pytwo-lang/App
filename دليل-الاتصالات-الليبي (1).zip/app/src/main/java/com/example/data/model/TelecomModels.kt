package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CodeCategory(val key: String, val labelAr: String) {
    BALANCE("BALANCE", "معرفة الرصيد"),
    TOPUP("TOPUP", "تعبئة الرصيد"),
    INTERNET("INTERNET", "باقات الإنترنت"),
    RENEW("RENEW", "تجديد الاشتراكات"),
    SERVICES("SERVICES", "أكواد الخدمات"),
    EXTRA("EXTRA", "الخدمات الإضافية"),
    DATA_SIM("DATA_SIM", "شرائح الإنترنت والمودم");

    companion object {
        fun fromKey(key: String): CodeCategory =
            entries.firstOrNull { it.key == key } ?: SERVICES
    }
}

enum class SimType(val key: String, val labelAr: String) {
    VOICE("VOICE", "شريحة هاتف صوتية"),
    DATA("DATA", "شريحة بيانات / مودم"),
    BOTH("BOTH", "شرائح الهاتف والبيانات");

    companion object {
        fun fromKey(key: String): SimType =
            entries.firstOrNull { it.key == key } ?: BOTH
    }
}

enum class InputRequirement(val key: String, val labelAr: String) {
    NONE("NONE", "لا يتطلب إدخالاً"),
    CARD_NUMBER("CARD_NUMBER", "يتطلب رقم بطاقة التعبئة"),
    PHONE_NUMBER("PHONE_NUMBER", "يتطلب رقم الهاتف");

    companion object {
        fun fromKey(key: String): InputRequirement =
            entries.firstOrNull { it.key == key } ?: NONE
    }
}

enum class VerificationStatus(val key: String, val labelAr: String) {
    VERIFIED("VERIFIED", "تم التحقق"),
    NEEDS_REVIEW("NEEDS_REVIEW", "يحتاج مراجعة");

    companion object {
        fun fromKey(key: String): VerificationStatus =
            entries.firstOrNull { it.key == key } ?: NEEDS_REVIEW
    }
}

enum class PackageCategory(val key: String, val labelAr: String) {
    DAILY("DAILY", "يومية"),
    WEEKLY("WEEKLY", "أسبوعية"),
    MONTHLY("MONTHLY", "شهرية"),
    UNLIMITED("UNLIMITED", "غير محدودة"),
    DATA_SIM("DATA_SIM", "شرائح البيانات");

    companion object {
        fun fromKey(key: String): PackageCategory =
            entries.firstOrNull { it.key == key } ?: MONTHLY
    }
}

enum class AppThemeMode(val key: String, val labelAr: String) {
    SYSTEM("SYSTEM", "تلقائي (النظام)"),
    LIGHT("LIGHT", "الوضع النهاري"),
    DARK("DARK", "الوضع الليلي");

    companion object {
        fun fromKey(key: String): AppThemeMode =
            entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

@Entity(tableName = "providers")
data class TelecomProvider(
    @PrimaryKey val id: String = "",
    val nameAr: String = "",
    val nameEn: String = "",
    val shortCode: String = "",
    val accentColorHex: String = "#0D3B4C",
    val descriptionAr: String = "",
    val topUpTemplate: String = "",
    val officialUrl: String = "",
    val supportsDataSim: Boolean = true,
    val supportsVoiceSim: Boolean = true,
    val isActive: Boolean = true,
    val sortOrder: Long = 0L,
    val lastVerifiedDate: String = "",
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "ussd_codes")
data class UssdCodeEntry(
    @PrimaryKey val id: String = "",
    val providerId: String = "",
    val providerNameAr: String = "",
    val serviceNameAr: String = "",
    val category: String = CodeCategory.SERVICES.key,
    val ussdCode: String = "",
    val descriptionAr: String = "",
    val usageStepsAr: String = "",
    val supportedSimType: String = SimType.BOTH.key,
    val inputRequirement: String = InputRequirement.NONE.key,
    val verificationStatus: String = VerificationStatus.NEEDS_REVIEW.key,
    val lastVerifiedDate: String = "",
    val officialSourceUrl: String = "",
    val isActive: Boolean = true,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val categoryEnum: CodeCategory get() = CodeCategory.fromKey(category)
    val simTypeEnum: SimType get() = SimType.fromKey(supportedSimType)
    val inputRequirementEnum: InputRequirement get() = InputRequirement.fromKey(inputRequirement)
    val verificationEnum: VerificationStatus get() = VerificationStatus.fromKey(verificationStatus)

    val isDialableUssd: Boolean
        get() = ussdCode.startsWith("*") || ussdCode.startsWith("#") || ussdCode.all { it.isDigit() }
}

@Entity(tableName = "packages")
data class InternetPackage(
    @PrimaryKey val id: String = "",
    val providerId: String = "",
    val providerNameAr: String = "",
    val packageNameAr: String = "",
    val category: String = PackageCategory.MONTHLY.key,
    val dataDisplayAr: String = "",
    val dataMb: Long = 0L,
    val isUnlimited: Boolean = false,
    val priceLyd: Double = 0.0,
    val validityDays: Long = 30L,
    val activationCode: String = "",
    val renewalMethodAr: String = "",
    val termsAr: String = "",
    val verificationStatus: String = VerificationStatus.NEEDS_REVIEW.key,
    val lastVerifiedDate: String = "",
    val officialSourceUrl: String = "",
    val isActive: Boolean = true,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val categoryEnum: PackageCategory get() = PackageCategory.fromKey(category)
    val verificationEnum: VerificationStatus get() = VerificationStatus.fromKey(verificationStatus)

    val pricePerGbLyd: Double?
        get() = if (!isUnlimited && dataMb > 0L && priceLyd > 0.0) {
            priceLyd / (dataMb.toDouble() / 1024.0)
        } else {
            null
        }

    val isDialableActivation: Boolean
        get() = activationCode.startsWith("*") || activationCode.startsWith("#")
}

@Entity(tableName = "data_sim_guides")
data class DataSimGuide(
    @PrimaryKey val id: String = "",
    val providerId: String = "",
    val providerNameAr: String = "",
    val simTitleAr: String = "",
    val balanceCheckMethodAr: String = "",
    val topUpAndSubscribeAr: String = "",
    val routerInterfaceUrl: String = "",
    val routerDefaultNoteAr: String = "",
    val compatibilityWarningAr: String = "",
    val verificationStatus: String = VerificationStatus.VERIFIED.key,
    val lastVerifiedDate: String = "",
    val officialSourceUrl: String = "",
    val isActive: Boolean = true,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val verificationEnum: VerificationStatus get() = VerificationStatus.fromKey(verificationStatus)
}

@Entity(tableName = "user_preferences")
data class UserSimPreferences(
    @PrimaryKey val id: String = SIM_CONFIG_ID,
    val sim1ProviderId: String = "libyana",
    val sim1Label: String = "الشريحة 1 - ليبيانا",
    val sim2ProviderId: String = "almadar",
    val sim2Label: String = "الشريحة 2 - المدار الجديد",
    val favoriteCodeIds: List<String> = emptyList(),
    val themeMode: String = AppThemeMode.SYSTEM.key,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val themeModeEnum: AppThemeMode get() = AppThemeMode.fromKey(themeMode)

    companion object {
        const val SIM_CONFIG_ID = "sim_config"
    }
}
