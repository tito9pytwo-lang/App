package com.example.data.repository

import android.content.Context
import com.example.data.local.TelecomDao
import com.example.data.local.TelecomDatabase
import com.example.data.model.DataSimGuide
import com.example.data.model.InternetPackage
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry
import com.example.data.seed.OfficialSeedData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class TelecomDirectoryRepository(
    private val dao: TelecomDao
) {
    constructor(context: Context) : this(
        TelecomDatabase.getInstance(context.applicationContext).telecomDao()
    )

    fun observeProviders(includeInactive: Boolean = false): Flow<List<TelecomProvider>> =
        if (includeInactive) dao.observeAllProviders() else dao.observeActiveProviders()

    fun observeUssdCodes(includeInactive: Boolean = false): Flow<List<UssdCodeEntry>> =
        if (includeInactive) dao.observeAllUssdCodes() else dao.observeActiveUssdCodes()

    fun observePackages(includeInactive: Boolean = false): Flow<List<InternetPackage>> =
        if (includeInactive) dao.observeAllPackages() else dao.observeActivePackages()

    fun observeDataSimGuides(): Flow<List<DataSimGuide>> =
        dao.observeActiveDataSimGuides()

    fun observeUserPreferences(): Flow<UserSimPreferences> =
        dao.observeUserPreferences(UserSimPreferences.SIM_CONFIG_ID)
            .map { it ?: UserSimPreferences() }

    suspend fun ensureSeededIfEmpty(): Result<Boolean> = runCatching {
        withContext(Dispatchers.IO) {
            if (dao.countProviders() > 0) {
                return@withContext false
            }
            dao.upsertCatalogBundle(
                providers = OfficialSeedData.providers,
                codes = OfficialSeedData.ussdCodes,
                packages = OfficialSeedData.packages,
                guides = OfficialSeedData.dataSimGuides
            )
            dao.upsertUserPreferences(UserSimPreferences())
            true
        }
    }

    suspend fun restoreOfficialCatalog(): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.upsertCatalogBundle(
                providers = OfficialSeedData.providers,
                codes = OfficialSeedData.ussdCodes,
                packages = OfficialSeedData.packages,
                guides = OfficialSeedData.dataSimGuides
            )
        }
    }

    suspend fun saveUserPreferences(preferences: UserSimPreferences): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.upsertUserPreferences(
                preferences.copy(
                    id = UserSimPreferences.SIM_CONFIG_ID,
                    sim1Label = preferences.sim1Label.trim().ifBlank { "الشريحة 1" },
                    sim2Label = preferences.sim2Label.trim().ifBlank { "الشريحة 2" },
                    favoriteCodeIds = preferences.favoriteCodeIds.distinct().take(100),
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun saveProvider(provider: TelecomProvider): Result<String> = runCatching {
        withContext(Dispatchers.IO) {
            val id = provider.id.ifBlank { generateLocalId(provider.shortCode, "prov") }
            dao.upsertProvider(
                provider.copy(
                    id = id,
                    nameAr = provider.nameAr.trim(),
                    nameEn = provider.nameEn.trim(),
                    shortCode = provider.shortCode.trim().uppercase(),
                    accentColorHex = provider.accentColorHex.trim().ifBlank { "#0B4F6C" },
                    descriptionAr = provider.descriptionAr.trim(),
                    topUpTemplate = provider.topUpTemplate.trim(),
                    officialUrl = provider.officialUrl.trim(),
                    lastVerifiedDate = provider.lastVerifiedDate.trim().ifBlank { OfficialSeedData.VERIFICATION_DATE },
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            id
        }
    }

    suspend fun deleteProvider(providerId: String): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.deleteProviderById(providerId)
        }
    }

    suspend fun saveUssdCode(entry: UssdCodeEntry): Result<String> = runCatching {
        withContext(Dispatchers.IO) {
            val id = entry.id.ifBlank { generateLocalId(entry.providerId, "code") }
            dao.upsertUssdCode(
                entry.copy(
                    id = id,
                    providerId = entry.providerId.trim(),
                    providerNameAr = entry.providerNameAr.trim(),
                    serviceNameAr = entry.serviceNameAr.trim(),
                    ussdCode = entry.ussdCode.trim(),
                    descriptionAr = entry.descriptionAr.trim(),
                    usageStepsAr = entry.usageStepsAr.trim(),
                    lastVerifiedDate = entry.lastVerifiedDate.trim().ifBlank { OfficialSeedData.VERIFICATION_DATE },
                    officialSourceUrl = entry.officialSourceUrl.trim(),
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            id
        }
    }

    suspend fun deleteUssdCode(codeId: String): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.deleteUssdCodeById(codeId)
        }
    }

    suspend fun savePackage(pkg: InternetPackage): Result<String> = runCatching {
        withContext(Dispatchers.IO) {
            val id = pkg.id.ifBlank { generateLocalId(pkg.providerId, "pkg") }
            dao.upsertPackage(
                pkg.copy(
                    id = id,
                    providerId = pkg.providerId.trim(),
                    providerNameAr = pkg.providerNameAr.trim(),
                    packageNameAr = pkg.packageNameAr.trim(),
                    dataDisplayAr = pkg.dataDisplayAr.trim(),
                    activationCode = pkg.activationCode.trim(),
                    renewalMethodAr = pkg.renewalMethodAr.trim(),
                    termsAr = pkg.termsAr.trim(),
                    lastVerifiedDate = pkg.lastVerifiedDate.trim().ifBlank { OfficialSeedData.VERIFICATION_DATE },
                    officialSourceUrl = pkg.officialSourceUrl.trim(),
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            id
        }
    }

    suspend fun deletePackage(packageId: String): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.deletePackageById(packageId)
        }
    }

    suspend fun saveDataSimGuide(guide: DataSimGuide): Result<String> = runCatching {
        withContext(Dispatchers.IO) {
            val id = guide.id.ifBlank { generateLocalId(guide.providerId, "guide") }
            dao.upsertDataSimGuide(
                guide.copy(
                    id = id,
                    providerId = guide.providerId.trim(),
                    providerNameAr = guide.providerNameAr.trim(),
                    simTitleAr = guide.simTitleAr.trim(),
                    balanceCheckMethodAr = guide.balanceCheckMethodAr.trim(),
                    topUpAndSubscribeAr = guide.topUpAndSubscribeAr.trim(),
                    routerInterfaceUrl = guide.routerInterfaceUrl.trim(),
                    routerDefaultNoteAr = guide.routerDefaultNoteAr.trim(),
                    compatibilityWarningAr = guide.compatibilityWarningAr.trim(),
                    lastVerifiedDate = guide.lastVerifiedDate.trim().ifBlank { OfficialSeedData.VERIFICATION_DATE },
                    officialSourceUrl = guide.officialSourceUrl.trim(),
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            id
        }
    }

    suspend fun deleteDataSimGuide(guideId: String): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) {
            dao.deleteDataSimGuideById(guideId)
        }
    }

    /**
     * تصدير قاعدة البيانات المحلية بصيغة JSON لمشاركتها أو حفظ نسخة احتياطية دون اتصال بالإنترنت.
     */
    suspend fun exportCatalogJson(): Result<String> = runCatching {
        withContext(Dispatchers.IO) {
            val providers = dao.getAllProvidersOnce()
            val codes = dao.getAllUssdCodesOnce()
            val packages = dao.getAllPackagesOnce()
            val guides = dao.getAllDataSimGuidesOnce()

            val root = JSONObject().apply {
                put("version", 1)
                put("providers", JSONArray().apply {
                    providers.forEach { p ->
                        put(JSONObject().apply {
                            put("id", p.id)
                            put("nameAr", p.nameAr)
                            put("nameEn", p.nameEn)
                            put("shortCode", p.shortCode)
                            put("accentColorHex", p.accentColorHex)
                            put("descriptionAr", p.descriptionAr)
                            put("topUpTemplate", p.topUpTemplate)
                            put("officialUrl", p.officialUrl)
                            put("supportsDataSim", p.supportsDataSim)
                            put("supportsVoiceSim", p.supportsVoiceSim)
                            put("isActive", p.isActive)
                            put("sortOrder", p.sortOrder)
                            put("lastVerifiedDate", p.lastVerifiedDate)
                        })
                    }
                })
                put("ussdCodes", JSONArray().apply {
                    codes.forEach { c ->
                        put(JSONObject().apply {
                            put("id", c.id)
                            put("providerId", c.providerId)
                            put("providerNameAr", c.providerNameAr)
                            put("serviceNameAr", c.serviceNameAr)
                            put("category", c.category)
                            put("ussdCode", c.ussdCode)
                            put("descriptionAr", c.descriptionAr)
                            put("usageStepsAr", c.usageStepsAr)
                            put("supportedSimType", c.supportedSimType)
                            put("inputRequirement", c.inputRequirement)
                            put("verificationStatus", c.verificationStatus)
                            put("lastVerifiedDate", c.lastVerifiedDate)
                            put("officialSourceUrl", c.officialSourceUrl)
                            put("isActive", c.isActive)
                        })
                    }
                })
                put("packages", JSONArray().apply {
                    packages.forEach { k ->
                        put(JSONObject().apply {
                            put("id", k.id)
                            put("providerId", k.providerId)
                            put("providerNameAr", k.providerNameAr)
                            put("packageNameAr", k.packageNameAr)
                            put("category", k.category)
                            put("dataDisplayAr", k.dataDisplayAr)
                            put("dataMb", k.dataMb)
                            put("isUnlimited", k.isUnlimited)
                            put("priceLyd", k.priceLyd)
                            put("validityDays", k.validityDays)
                            put("activationCode", k.activationCode)
                            put("renewalMethodAr", k.renewalMethodAr)
                            put("termsAr", k.termsAr)
                            put("verificationStatus", k.verificationStatus)
                            put("lastVerifiedDate", k.lastVerifiedDate)
                            put("officialSourceUrl", k.officialSourceUrl)
                            put("isActive", k.isActive)
                        })
                    }
                })
                put("dataSimGuides", JSONArray().apply {
                    guides.forEach { g ->
                        put(JSONObject().apply {
                            put("id", g.id)
                            put("providerId", g.providerId)
                            put("providerNameAr", g.providerNameAr)
                            put("simTitleAr", g.simTitleAr)
                            put("balanceCheckMethodAr", g.balanceCheckMethodAr)
                            put("topUpAndSubscribeAr", g.topUpAndSubscribeAr)
                            put("routerInterfaceUrl", g.routerInterfaceUrl)
                            put("routerDefaultNoteAr", g.routerDefaultNoteAr)
                            put("compatibilityWarningAr", g.compatibilityWarningAr)
                            put("verificationStatus", g.verificationStatus)
                            put("lastVerifiedDate", g.lastVerifiedDate)
                            put("officialSourceUrl", g.officialSourceUrl)
                            put("isActive", g.isActive)
                        })
                    }
                })
            }
            root.toString(2)
        }
    }

    /**
     * استيراد وتحديث حزمة بيانات محلية بصيغة JSON دون الحاجة لإعادة تثبيت التطبيق أو الاتصال بالإنترنت.
     */
    suspend fun importCatalogJson(jsonText: String): Result<Int> = runCatching {
        withContext(Dispatchers.IO) {
            val root = JSONObject(jsonText.trim())
            val providers = parseProviders(root.optJSONArray("providers"))
            val codes = parseCodes(root.optJSONArray("ussdCodes"))
            val packages = parsePackages(root.optJSONArray("packages"))
            val guides = parseGuides(root.optJSONArray("dataSimGuides"))
            val totalImported = providers.size + codes.size + packages.size + guides.size
            require(totalImported > 0) { "ملف التحديث لا يحتوي على سجلات صالحة" }
            dao.upsertCatalogBundle(providers, codes, packages, guides)
            totalImported
        }
    }

    private fun parseProviders(array: JSONArray?): List<TelecomProvider> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val id = o.optString("id").trim()
                val nameAr = o.optString("nameAr").trim()
                if (id.isNotBlank() && nameAr.isNotBlank()) {
                    add(
                        TelecomProvider(
                            id = id,
                            nameAr = nameAr,
                            nameEn = o.optString("nameEn"),
                            shortCode = o.optString("shortCode", id.uppercase()),
                            accentColorHex = o.optString("accentColorHex", "#0B4F6C"),
                            descriptionAr = o.optString("descriptionAr"),
                            topUpTemplate = o.optString("topUpTemplate"),
                            officialUrl = o.optString("officialUrl"),
                            supportsDataSim = o.optBoolean("supportsDataSim", true),
                            supportsVoiceSim = o.optBoolean("supportsVoiceSim", true),
                            isActive = o.optBoolean("isActive", true),
                            sortOrder = o.optLong("sortOrder", 10L),
                            lastVerifiedDate = o.optString("lastVerifiedDate", OfficialSeedData.VERIFICATION_DATE)
                        )
                    )
                }
            }
        }
    }

    private fun parseCodes(array: JSONArray?): List<UssdCodeEntry> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val id = o.optString("id").trim()
                val service = o.optString("serviceNameAr").trim()
                val code = o.optString("ussdCode").trim()
                if (id.isNotBlank() && service.isNotBlank() && code.isNotBlank()) {
                    add(
                        UssdCodeEntry(
                            id = id,
                            providerId = o.optString("providerId"),
                            providerNameAr = o.optString("providerNameAr"),
                            serviceNameAr = service,
                            category = o.optString("category", "SERVICES"),
                            ussdCode = code,
                            descriptionAr = o.optString("descriptionAr"),
                            usageStepsAr = o.optString("usageStepsAr"),
                            supportedSimType = o.optString("supportedSimType", "BOTH"),
                            inputRequirement = o.optString("inputRequirement", "NONE"),
                            verificationStatus = o.optString("verificationStatus", "NEEDS_REVIEW"),
                            lastVerifiedDate = o.optString("lastVerifiedDate", OfficialSeedData.VERIFICATION_DATE),
                            officialSourceUrl = o.optString("officialSourceUrl"),
                            isActive = o.optBoolean("isActive", true)
                        )
                    )
                }
            }
        }
    }

    private fun parsePackages(array: JSONArray?): List<InternetPackage> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val id = o.optString("id").trim()
                val name = o.optString("packageNameAr").trim()
                if (id.isNotBlank() && name.isNotBlank()) {
                    add(
                        InternetPackage(
                            id = id,
                            providerId = o.optString("providerId"),
                            providerNameAr = o.optString("providerNameAr"),
                            packageNameAr = name,
                            category = o.optString("category", "MONTHLY"),
                            dataDisplayAr = o.optString("dataDisplayAr"),
                            dataMb = o.optLong("dataMb", 0L),
                            isUnlimited = o.optBoolean("isUnlimited", false),
                            priceLyd = o.optDouble("priceLyd", 0.0),
                            validityDays = o.optLong("validityDays", 30L),
                            activationCode = o.optString("activationCode"),
                            renewalMethodAr = o.optString("renewalMethodAr"),
                            termsAr = o.optString("termsAr"),
                            verificationStatus = o.optString("verificationStatus", "NEEDS_REVIEW"),
                            lastVerifiedDate = o.optString("lastVerifiedDate", OfficialSeedData.VERIFICATION_DATE),
                            officialSourceUrl = o.optString("officialSourceUrl"),
                            isActive = o.optBoolean("isActive", true)
                        )
                    )
                }
            }
        }
    }

    private fun parseGuides(array: JSONArray?): List<DataSimGuide> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val id = o.optString("id").trim()
                val title = o.optString("simTitleAr").trim()
                if (id.isNotBlank() && title.isNotBlank()) {
                    add(
                        DataSimGuide(
                            id = id,
                            providerId = o.optString("providerId"),
                            providerNameAr = o.optString("providerNameAr"),
                            simTitleAr = title,
                            balanceCheckMethodAr = o.optString("balanceCheckMethodAr"),
                            topUpAndSubscribeAr = o.optString("topUpAndSubscribeAr"),
                            routerInterfaceUrl = o.optString("routerInterfaceUrl"),
                            routerDefaultNoteAr = o.optString("routerDefaultNoteAr"),
                            compatibilityWarningAr = o.optString("compatibilityWarningAr"),
                            verificationStatus = o.optString("verificationStatus", "VERIFIED"),
                            lastVerifiedDate = o.optString("lastVerifiedDate", OfficialSeedData.VERIFICATION_DATE),
                            officialSourceUrl = o.optString("officialSourceUrl"),
                            isActive = o.optBoolean("isActive", true)
                        )
                    )
                }
            }
        }
    }

    private fun generateLocalId(prefixHint: String, fallbackPrefix: String): String {
        val cleaned = prefixHint.lowercase()
            .replace(Regex("[^a-z0-9_\\-]"), "_")
            .trim('_')
            .take(24)
            .ifBlank { fallbackPrefix }
        val suffix = UUID.randomUUID().toString().replace("-", "").take(10)
        return "${cleaned}_${suffix}"
    }
}
