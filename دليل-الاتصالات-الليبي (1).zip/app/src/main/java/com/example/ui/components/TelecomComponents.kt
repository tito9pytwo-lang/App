package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.OfflinePin
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material.icons.outlined.SimCard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SimType
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.VerificationStatus
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ReviewAmber
import com.example.ui.theme.ReviewAmberContainer
import com.example.ui.theme.ReviewAmberDarkContainer
import com.example.ui.theme.VerifiedGreen
import com.example.ui.theme.VerifiedGreenContainer
import com.example.ui.theme.VerifiedGreenDarkContainer
import com.example.ui.theme.parseHexColor
import com.example.util.DialAndClipboardHelper

@Composable
fun ProviderLogoBadge(
    provider: TelecomProvider?,
    size: Dp = 44.dp
) {
    val accent = parseHexColor(provider?.accentColorHex ?: defaultAccentForProviderId(provider?.id))
    val idUpper = provider?.id?.uppercase().orEmpty()
    val shortCode = provider?.shortCode?.uppercase().orEmpty()

    val iconRes = when {
        shortCode.contains("LIBYANA") || idUpper == "LIBYANA" -> R.drawable.ic_provider_libyana
        shortCode.contains("ALMADAR") || idUpper == "ALMADAR" -> R.drawable.ic_provider_almadar
        shortCode.contains("LTT") || idUpper == "LTT" -> R.drawable.ic_provider_ltt
        shortCode.contains("MODEM") || shortCode.contains("DATA") || idUpper == "DATA_MODEM" -> R.drawable.ic_provider_modem
        else -> R.drawable.ic_provider_generic
    }

    val shape = RoundedCornerShape(size * 0.28f)
    Box(
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(accent, accent.copy(alpha = 0.82f))
                )
            )
            .border(
                width = if (size >= 36.dp) 1.dp else 0.5.dp,
                color = Color.White.copy(alpha = 0.28f),
                shape = shape
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = iconRes),
            contentDescription = provider?.nameAr ?: "شعار الشركة",
            colorFilter = ColorFilter.tint(Color.White),
            modifier = Modifier.size(size * 0.62f)
        )
    }
}

private fun defaultAccentForProviderId(providerId: String?): String = when (providerId?.lowercase()) {
    "libyana" -> "#A31D6B"
    "almadar" -> "#008751"
    "ltt" -> "#0062AD"
    "data_modem" -> "#1E6B7B"
    else -> "#0B4F6C"
}

/**
 * يعرض الكود المختصر دائماً باتجاه LTR حتى لا تنقلب رموز * و # في الواجهة العربية RTL.
 */
@Composable
fun UssdCodePill(
    code: String,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        ),
        shape = RoundedCornerShape(10.dp),
        color = accentColor.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = code,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = accentColor,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun VerificationBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val isVerified = status == VerificationStatus.VERIFIED.key
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val bgColor = if (isVerified) {
        if (isDark) VerifiedGreenDarkContainer else VerifiedGreenContainer
    } else {
        if (isDark) ReviewAmberDarkContainer else ReviewAmberContainer
    }
    val fgColor = if (isVerified) VerifiedGreen else ReviewAmber
    val icon = if (isVerified) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber
    val label = if (isVerified) {
        stringResource(R.string.status_verified)
    } else {
        stringResource(R.string.status_needs_review)
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = fgColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = fgColor,
                maxLines = 1
            )
        }
    }
}

@Composable
fun OfflineDatabaseBanner(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.OfflinePin,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = stringResource(R.string.status_offline_local),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

data class DialRequest(
    val title: String,
    val codeOrUrl: String,
    val providerId: String,
    val providerNameAr: String,
    val supportedSimType: String = SimType.BOTH.key,
    val verificationStatus: String = VerificationStatus.VERIFIED.key,
    val isWebPortal: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DialConfirmBottomSheet(
    request: DialRequest,
    userPrefs: UserSimPreferences,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val (recommendedSlot, recommendedLabel) = remember(request.providerId, userPrefs) {
        DialAndClipboardHelper.recommendSimSlot(request.providerId, userPrefs)
    }
    var selectedSlot by remember(recommendedSlot) { mutableStateOf(recommendedSlot) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProviderLogoBadge(
                    provider = TelecomProvider(
                        id = request.providerId,
                        nameAr = request.providerNameAr,
                        shortCode = request.providerId.uppercase(),
                        accentColorHex = defaultAccentForProviderId(request.providerId)
                    ),
                    size = 40.dp
                )
                Text(
                    text = request.title,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                VerificationBadge(status = request.verificationStatus)
            }

            Text(
                text = "المشغّل: ${request.providerNameAr} • ${SimType.fromKey(request.supportedSimType).labelAr}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (request.supportedSimType == SimType.VOICE.key) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.65f)
                ) {
                    Text(
                        text = "ملاحظة: هذا الكود مخصص لشرائح الهاتف الصوتية وقد لا يعمل على شرائح البيانات الصرفة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (request.isWebPortal) "الرابط الرسمي للخدمة" else "الكود الجاهز للتنفيذ (مراجعة قبل الاتصال)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = request.codeOrUrl,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (!request.isWebPortal) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.SimCard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (recommendedLabel != null) {
                                "الشريحة المقترحة: $recommendedLabel"
                            } else {
                                "اختر الشريحة المناسبة في الهاتف ثنائي الشريحة:"
                            },
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = selectedSlot == 0,
                            onClick = { selectedSlot = if (selectedSlot == 0) null else 0 },
                            label = { Text(userPrefs.sim1Label, maxLines = 1) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = selectedSlot == 1,
                            onClick = { selectedSlot = if (selectedSlot == 1) null else 1 },
                            label = { Text(userPrefs.sim2Label, maxLines = 1) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        text = "سيتم فتح شاشة الاتصال (ACTION_DIAL) للمراجعة النهائية، ولن يتم إجراء أي اتصال أو اشتراك دون ضغطك على زر الاتصال في جهازك.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        DialAndClipboardHelper.copyToClipboard(context, request.title, request.codeOrUrl)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("sheet_copy_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.action_copy_code))
                }

                Button(
                    onClick = {
                        if (request.isWebPortal) {
                            DialAndClipboardHelper.openWebUrl(context, request.codeOrUrl)
                        } else {
                            DialAndClipboardHelper.openDialerSafely(
                                context = context,
                                ussdOrPhone = request.codeOrUrl,
                                preferredSimSlotIndex = selectedSlot
                            )
                        }
                        onDismiss()
                    },
                    modifier = Modifier
                        .weight(1.3f)
                        .height(52.dp)
                        .testTag("sheet_dial_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = if (request.isWebPortal) Icons.Outlined.OpenInBrowser else Icons.Filled.Call,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (request.isWebPortal) stringResource(R.string.action_open_portal)
                        else stringResource(R.string.action_dial_safe)
                    )
                }
            }
        }
    }
}
