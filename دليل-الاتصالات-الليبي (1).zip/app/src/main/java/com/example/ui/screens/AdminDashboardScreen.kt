package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.InternetPackage
import com.example.data.model.TelecomProvider
import com.example.data.model.UssdCodeEntry
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.components.VerificationBadge
import com.example.ui.viewmodel.DirectoryUiState
import com.example.util.DialAndClipboardHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    uiState: DirectoryUiState,
    onBack: () -> Unit,
    onRestoreOfficialCatalog: () -> Unit,
    onExportJson: () -> Unit,
    onClearExportedJson: () -> Unit,
    onImportJson: (String) -> Unit,
    onSaveProvider: (TelecomProvider) -> Unit,
    onDeleteProvider: (String) -> Unit,
    onSaveCode: (UssdCodeEntry) -> Unit,
    onDeleteCode: (String) -> Unit,
    onToggleCodeVerification: (UssdCodeEntry) -> Unit,
    onSavePackage: (InternetPackage) -> Unit,
    onDeletePackage: (String) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember { mutableIntStateOf(0) }
    var editingProvider by remember { mutableStateOf<TelecomProvider?>(null) }
    var showAddProvider by remember { mutableStateOf(false) }

    var editingCode by remember { mutableStateOf<UssdCodeEntry?>(null) }
    var showAddCode by remember { mutableStateOf(false) }

    var editingPackage by remember { mutableStateOf<InternetPackage?>(null) }
    var showAddPackage by remember { mutableStateOf(false) }

    var showJsonBundleDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("لوحة الإدارة المحلية", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = "إدارة وتحديث الشركات والأكواد والباقات محلياً دون إنترنت",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Button(
                onClick = {
                    when (selectedTab) {
                        0 -> showAddProvider = true
                        1 -> showAddCode = true
                        else -> showAddPackage = true
                    }
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("admin_add_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("إضافة")
            }
        }

        if (uiState.isBusyAction) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onRestoreOfficialCatalog,
                modifier = Modifier
                    .weight(1f)
                    .testTag("restore_official_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("استعادة الرسمية", maxLines = 1)
            }
            OutlinedButton(
                onClick = {
                    onExportJson()
                    showJsonBundleDialog = true
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("json_bundle_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.DataObject, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("تحديث / نسخ JSON", maxLines = 1)
            }
        }

        PrimaryTabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("الشركات (${uiState.providers.size})") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("الأكواد (${uiState.ussdCodes.size})") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("الباقات (${uiState.packages.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (selectedTab) {
                0 -> items(uiState.providers, key = { "adm_p_${it.id}" }) { provider ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ProviderLogoBadge(provider = provider, size = 38.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(provider.nameAr, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "الصيغة: ${provider.topUpTemplate.ifBlank { "بوابة إلكترونية" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { editingProvider = provider }) {
                                Icon(Icons.Filled.Edit, contentDescription = "تعديل")
                            }
                            IconButton(onClick = { onDeleteProvider(provider.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                1 -> items(uiState.ussdCodes, key = { "adm_c_${it.id}" }) { code ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(code.serviceNameAr, style = MaterialTheme.typography.titleSmall)
                                    Text("${code.providerNameAr} • ${code.ussdCode}", style = MaterialTheme.typography.bodySmall)
                                }
                                VerificationBadge(status = code.verificationStatus)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onToggleCodeVerification(code) }) {
                                    Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تبديل التحقق")
                                }
                                IconButton(onClick = { editingCode = code }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "تعديل")
                                }
                                IconButton(onClick = { onDeleteCode(code.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }

                else -> items(uiState.packages, key = { "adm_k_${it.id}" }) { pkg ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(pkg.packageNameAr, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${pkg.providerNameAr} • ${pkg.dataDisplayAr} • ${pkg.priceLyd.toInt()} د.ل",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            VerificationBadge(status = pkg.verificationStatus)
                            IconButton(onClick = { editingPackage = pkg }) {
                                Icon(Icons.Filled.Edit, contentDescription = "تعديل")
                            }
                            IconButton(onClick = { onDeletePackage(pkg.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showJsonBundleDialog) {
        LocalJsonUpdateDialog(
            initialJson = uiState.exportedJsonPreview.orEmpty(),
            onDismiss = {
                showJsonBundleDialog = false
                onClearExportedJson()
            },
            onImport = { json ->
                onImportJson(json)
                showJsonBundleDialog = false
                onClearExportedJson()
            }
        )
    }

    if (showAddProvider || editingProvider != null) {
        ProviderEditorDialog(
            initial = editingProvider,
            onDismiss = {
                showAddProvider = false
                editingProvider = null
            },
            onSave = {
                onSaveProvider(it)
                showAddProvider = false
                editingProvider = null
            }
        )
    }

    if (showAddCode || editingCode != null) {
        UssdCodeEditorDialog(
            providers = uiState.providers,
            initial = editingCode,
            onDismiss = {
                showAddCode = false
                editingCode = null
            },
            onSave = {
                onSaveCode(it)
                showAddCode = false
                editingCode = null
            }
        )
    }

    if (showAddPackage || editingPackage != null) {
        PackageEditorDialog(
            providers = uiState.providers,
            initial = editingPackage,
            onDismiss = {
                showAddPackage = false
                editingPackage = null
            },
            onSave = {
                onSavePackage(it)
                showAddPackage = false
                editingPackage = null
            }
        )
    }
}

@Composable
private fun LocalJsonUpdateDialog(
    initialJson: String,
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    val context = LocalContext.current
    var jsonText by remember { mutableStateOf(initialJson) }
    LaunchedEffect(initialJson) {
        if (jsonText.isBlank() && initialJson.isNotBlank()) {
            jsonText = initialJson
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تحديث أو نسخ قاعدة البيانات (JSON)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "يمكنك نسخ البيانات الحالية لمشاركتها، أو لصق حزمة تحديث JSON لاستيراد شركات وأكواد وباقات جديدة محلياً دون إعادة تثبيت التطبيق.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(
                        value = jsonText,
                        onValueChange = { jsonText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 260.dp),
                        label = { Text("JSON Catalog Bundle") }
                    )
                }
                OutlinedButton(
                    onClick = {
                        DialAndClipboardHelper.copyToClipboard(context, "LibyaTelecomJSON", jsonText)
                    },
                    enabled = jsonText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("نسخ JSON إلى الحافظة")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onImport(jsonText) },
                enabled = jsonText.isNotBlank()
            ) {
                Text("استيراد وتحديث")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}
