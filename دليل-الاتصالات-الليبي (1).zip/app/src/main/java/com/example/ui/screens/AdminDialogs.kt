package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CodeCategory
import com.example.data.model.InputRequirement
import com.example.data.model.InternetPackage
import com.example.data.model.PackageCategory
import com.example.data.model.SimType
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry
import com.example.data.model.VerificationStatus
import com.example.data.seed.OfficialSeedData
import com.example.ui.components.ProviderLogoBadge

@Composable
fun DualSimSettingsDialog(
    providers: List<TelecomProvider>,
    currentPrefs: UserSimPreferences,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var sim1Prov by remember { mutableStateOf(currentPrefs.sim1ProviderId) }
    var sim1Label by remember { mutableStateOf(currentPrefs.sim1Label) }
    var sim2Prov by remember { mutableStateOf(currentPrefs.sim2ProviderId) }
    var sim2Label by remember { mutableStateOf(currentPrefs.sim2Label) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تخصيص الشريحتين (Dual-SIM)") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("الشريحة الأولى (SIM 1):", style = MaterialTheme.typography.titleSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(providers, key = { "s1_${it.id}" }) { p ->
                        FilterChip(
                            selected = sim1Prov == p.id,
                            onClick = {
                                sim1Prov = p.id
                                sim1Label = "الشريحة 1 - ${p.nameAr}"
                            },
                            leadingIcon = { ProviderLogoBadge(provider = p, size = 20.dp) },
                            label = { Text(p.nameAr) }
                        )
                    }
                }
                OutlinedTextField(
                    value = sim1Label,
                    onValueChange = { sim1Label = it },
                    label = { Text("تسمية الشريحة 1") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("الشريحة الثانية (SIM 2):", style = MaterialTheme.typography.titleSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(providers, key = { "s2_${it.id}" }) { p ->
                        FilterChip(
                            selected = sim2Prov == p.id,
                            onClick = {
                                sim2Prov = p.id
                                sim2Label = "الشريحة 2 - ${p.nameAr}"
                            },
                            leadingIcon = { ProviderLogoBadge(provider = p, size = 20.dp) },
                            label = { Text(p.nameAr) }
                        )
                    }
                }
                OutlinedTextField(
                    value = sim2Label,
                    onValueChange = { sim2Label = it },
                    label = { Text("تسمية الشريحة 2") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(sim1Prov, sim1Label, sim2Prov, sim2Label) }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun ProviderEditorDialog(
    initial: TelecomProvider?,
    onDismiss: () -> Unit,
    onSave: (TelecomProvider) -> Unit
) {
    var nameAr by remember { mutableStateOf(initial?.nameAr ?: "") }
    var nameEn by remember { mutableStateOf(initial?.nameEn ?: "") }
    var shortCode by remember { mutableStateOf(initial?.shortCode ?: "") }
    var colorHex by remember { mutableStateOf(initial?.accentColorHex ?: "#0B4F6C") }
    var descAr by remember { mutableStateOf(initial?.descriptionAr ?: "") }
    var topUpTemplate by remember { mutableStateOf(initial?.topUpTemplate ?: "") }
    var officialUrl by remember { mutableStateOf(initial?.officialUrl ?: "") }
    var supportsData by remember { mutableStateOf(initial?.supportsDataSim ?: true) }
    var supportsVoice by remember { mutableStateOf(initial?.supportsVoiceSim ?: true) }
    var lastVerified by remember { mutableStateOf(initial?.lastVerifiedDate ?: OfficialSeedData.VERIFICATION_DATE) }

    val canSave = nameAr.isNotBlank() && nameEn.isNotBlank() && shortCode.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة شركة / مزود جديد" else "تعديل بيانات الشركة") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = nameAr, onValueChange = { nameAr = it }, label = { Text("الاسم بالعربية*") }, singleLine = true)
                OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text("الاسم بالإنجليزية*") }, singleLine = true)
                OutlinedTextField(value = shortCode, onValueChange = { shortCode = it }, label = { Text("الرمز المختصر (مثل LIBYANA)*") }, singleLine = true)
                OutlinedTextField(value = colorHex, onValueChange = { colorHex = it }, label = { Text("لون الهوية Hex") }, singleLine = true)
                OutlinedTextField(value = topUpTemplate, onValueChange = { topUpTemplate = it }, label = { Text("صيغة التعبئة (استخدم {CARD})") }, singleLine = true)
                OutlinedTextField(value = officialUrl, onValueChange = { officialUrl = it }, label = { Text("الموقع الرسمي") }, singleLine = true)
                OutlinedTextField(value = descAr, onValueChange = { descAr = it }, label = { Text("وصف الشركة") })
                OutlinedTextField(value = lastVerified, onValueChange = { lastVerified = it }, label = { Text("تاريخ التحقق") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("يدعم شرائح الهاتف")
                    Switch(checked = supportsVoice, onCheckedChange = { supportsVoice = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("يدعم شرائح البيانات")
                    Switch(checked = supportsData, onCheckedChange = { supportsData = it })
                }
            }
        },
        confirmButton = {
            Button(
                enabled = canSave,
                onClick = {
                    val item = (initial ?: TelecomProvider()).copy(
                        nameAr = nameAr,
                        nameEn = nameEn,
                        shortCode = shortCode.uppercase(),
                        accentColorHex = colorHex,
                        descriptionAr = descAr,
                        topUpTemplate = topUpTemplate,
                        officialUrl = officialUrl,
                        supportsDataSim = supportsData,
                        supportsVoiceSim = supportsVoice,
                        isActive = true,
                        sortOrder = initial?.sortOrder ?: 10L,
                        lastVerifiedDate = lastVerified.ifBlank { OfficialSeedData.VERIFICATION_DATE }
                    )
                    onSave(item)
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun UssdCodeEditorDialog(
    providers: List<TelecomProvider>,
    initial: UssdCodeEntry?,
    onDismiss: () -> Unit,
    onSave: (UssdCodeEntry) -> Unit
) {
    var providerId by remember { mutableStateOf(initial?.providerId ?: providers.firstOrNull()?.id ?: "libyana") }
    var serviceName by remember { mutableStateOf(initial?.serviceNameAr ?: "") }
    var ussdCode by remember { mutableStateOf(initial?.ussdCode ?: "") }
    var descAr by remember { mutableStateOf(initial?.descriptionAr ?: "") }
    var usageAr by remember { mutableStateOf(initial?.usageStepsAr ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: CodeCategory.SERVICES.key) }
    var simType by remember { mutableStateOf(initial?.supportedSimType ?: SimType.BOTH.key) }
    var inputReq by remember { mutableStateOf(initial?.inputRequirement ?: InputRequirement.NONE.key) }
    var verification by remember { mutableStateOf(initial?.verificationStatus ?: VerificationStatus.NEEDS_REVIEW.key) }
    var sourceUrl by remember { mutableStateOf(initial?.officialSourceUrl ?: "") }
    var verifiedDate by remember { mutableStateOf(initial?.lastVerifiedDate ?: OfficialSeedData.VERIFICATION_DATE) }

    val selectedProviderName = providers.firstOrNull { it.id == providerId }?.nameAr ?: ""
    val canSave = providerId.isNotBlank() && serviceName.isNotBlank() && ussdCode.isNotBlank() && descAr.isNotBlank() && usageAr.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة كود خدمة جديد" else "تعديل كود الخدمة") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("الشركة:", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(providers, key = { it.id }) { p ->
                        FilterChip(
                            selected = providerId == p.id,
                            onClick = { providerId = p.id },
                            leadingIcon = { ProviderLogoBadge(provider = p, size = 20.dp) },
                            label = { Text(p.nameAr) }
                        )
                    }
                }
                OutlinedTextField(value = serviceName, onValueChange = { serviceName = it }, label = { Text("اسم الخدمة*") }, singleLine = true)
                OutlinedTextField(value = ussdCode, onValueChange = { ussdCode = it }, label = { Text("الكود المختصر*") }, singleLine = true)
                OutlinedTextField(value = descAr, onValueChange = { descAr = it }, label = { Text("وصف الوظيفة*") })
                OutlinedTextField(value = usageAr, onValueChange = { usageAr = it }, label = { Text("طريقة الاستخدام*") })

                Text("التصنيف:", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(CodeCategory.entries) { cat ->
                        FilterChip(selected = category == cat.key, onClick = { category = cat.key }, label = { Text(cat.labelAr) })
                    }
                }

                Text("الشريحة المدعومة:", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(SimType.entries) { s ->
                        FilterChip(selected = simType == s.key, onClick = { simType = s.key }, label = { Text(s.labelAr) })
                    }
                }

                Text("حالة التحقق:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VerificationStatus.entries.forEach { st ->
                        FilterChip(selected = verification == st.key, onClick = { verification = st.key }, label = { Text(st.labelAr) })
                    }
                }

                OutlinedTextField(value = sourceUrl, onValueChange = { sourceUrl = it }, label = { Text("رابط المصدر الرسمي") }, singleLine = true)
                OutlinedTextField(value = verifiedDate, onValueChange = { verifiedDate = it }, label = { Text("تاريخ التحقق") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                enabled = canSave,
                onClick = {
                    val item = (initial ?: UssdCodeEntry()).copy(
                        providerId = providerId,
                        providerNameAr = selectedProviderName,
                        serviceNameAr = serviceName,
                        category = category,
                        ussdCode = ussdCode,
                        descriptionAr = descAr,
                        usageStepsAr = usageAr,
                        supportedSimType = simType,
                        inputRequirement = inputReq,
                        verificationStatus = verification,
                        lastVerifiedDate = verifiedDate.ifBlank { OfficialSeedData.VERIFICATION_DATE },
                        officialSourceUrl = sourceUrl,
                        isActive = true
                    )
                    onSave(item)
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun PackageEditorDialog(
    providers: List<TelecomProvider>,
    initial: InternetPackage?,
    onDismiss: () -> Unit,
    onSave: (InternetPackage) -> Unit
) {
    var providerId by remember { mutableStateOf(initial?.providerId ?: providers.firstOrNull()?.id ?: "libyana") }
    var packageName by remember { mutableStateOf(initial?.packageNameAr ?: "") }
    var dataDisplay by remember { mutableStateOf(initial?.dataDisplayAr ?: "") }
    var dataMbText by remember { mutableStateOf(initial?.dataMb?.toString() ?: "1024") }
    var isUnlimited by remember { mutableStateOf(initial?.isUnlimited ?: false) }
    var priceText by remember { mutableStateOf(initial?.priceLyd?.toString() ?: "") }
    var validityText by remember { mutableStateOf(initial?.validityDays?.toString() ?: "30") }
    var activationCode by remember { mutableStateOf(initial?.activationCode ?: "") }
    var renewalMethod by remember { mutableStateOf(initial?.renewalMethodAr ?: "") }
    var terms by remember { mutableStateOf(initial?.termsAr ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: PackageCategory.MONTHLY.key) }
    var verification by remember { mutableStateOf(initial?.verificationStatus ?: VerificationStatus.NEEDS_REVIEW.key) }
    var sourceUrl by remember { mutableStateOf(initial?.officialSourceUrl ?: "") }

    val selectedProviderName = providers.firstOrNull { it.id == providerId }?.nameAr ?: ""
    val priceVal = priceText.toDoubleOrNull()
    val validityVal = validityText.toLongOrNull()
    val dataMbVal = if (isUnlimited) 0L else (dataMbText.toLongOrNull() ?: 0L)
    val canSave = packageName.isNotBlank() && dataDisplay.isNotBlank() && priceVal != null && validityVal != null && validityVal > 0 && activationCode.isNotBlank() && renewalMethod.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة باقة إنترنت" else "تعديل الباقة") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(providers, key = { it.id }) { p ->
                        FilterChip(
                            selected = providerId == p.id,
                            onClick = { providerId = p.id },
                            leadingIcon = { ProviderLogoBadge(provider = p, size = 20.dp) },
                            label = { Text(p.nameAr) }
                        )
                    }
                }
                OutlinedTextField(value = packageName, onValueChange = { packageName = it }, label = { Text("اسم الباقة*") }, singleLine = true)
                OutlinedTextField(value = dataDisplay, onValueChange = { dataDisplay = it }, label = { Text("الحجم المعروض (مثل 25 جيجابايت)*") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("باقة غير محدودة")
                    Switch(checked = isUnlimited, onCheckedChange = { isUnlimited = it })
                }
                if (!isUnlimited) {
                    OutlinedTextField(
                        value = dataMbText,
                        onValueChange = { dataMbText = it.filter { c -> c.isDigit() } },
                        label = { Text("الحجم بالميجابايت (1 جيجا = 1024)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("السعر بالدينار الليبي*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = validityText,
                    onValueChange = { validityText = it.filter { c -> c.isDigit() } },
                    label = { Text("الصلاحية بالأيام*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                OutlinedTextField(value = activationCode, onValueChange = { activationCode = it }, label = { Text("كود الاشتراك أو البوابة*") }, singleLine = true)
                OutlinedTextField(value = renewalMethod, onValueChange = { renewalMethod = it }, label = { Text("طريقة التجديد*") })
                OutlinedTextField(value = terms, onValueChange = { terms = it }, label = { Text("شروط الاشتراك") })
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(PackageCategory.entries) { cat ->
                        FilterChip(selected = category == cat.key, onClick = { category = cat.key }, label = { Text(cat.labelAr) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VerificationStatus.entries.forEach { st ->
                        FilterChip(selected = verification == st.key, onClick = { verification = st.key }, label = { Text(st.labelAr) })
                    }
                }
                OutlinedTextField(value = sourceUrl, onValueChange = { sourceUrl = it }, label = { Text("رابط المصدر الرسمي") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                enabled = canSave,
                onClick = {
                    val item = (initial ?: InternetPackage()).copy(
                        providerId = providerId,
                        providerNameAr = selectedProviderName,
                        packageNameAr = packageName,
                        category = category,
                        dataDisplayAr = dataDisplay,
                        dataMb = dataMbVal,
                        isUnlimited = isUnlimited,
                        priceLyd = priceVal ?: 0.0,
                        validityDays = validityVal ?: 30L,
                        activationCode = activationCode,
                        renewalMethodAr = renewalMethod,
                        termsAr = terms,
                        verificationStatus = verification,
                        lastVerifiedDate = OfficialSeedData.VERIFICATION_DATE,
                        officialSourceUrl = sourceUrl,
                        isActive = true
                    )
                    onSave(item)
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
