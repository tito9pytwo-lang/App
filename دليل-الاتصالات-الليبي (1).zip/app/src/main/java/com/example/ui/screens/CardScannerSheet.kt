package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.VerifiedGreen
import com.example.util.CardExtractionResult
import com.example.util.CardOcrFilter
import com.example.util.CardPinCandidate
import com.example.util.OcrTextLine
import com.example.util.PinStabilityTracker
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardScannerSheet(
    accentColor: Color,
    onDismiss: () -> Unit,
    onPinConfirmed: (String) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var torchEnabled by remember { mutableStateOf(false) }
    var extractionResult by remember { mutableStateOf<CardExtractionResult?>(null) }
    var lockedPin by remember { mutableStateOf<String?>(null) }
    var selectedCandidate by remember { mutableStateOf<String?>(null) }
    var statusNote by remember { mutableStateOf("وجّه الإطار نحو أرقام كرت التعبئة فقط") }

    val stabilityTracker = remember { PinStabilityTracker(requiredConsistentFrames = 2) }
    val recognizer = remember { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    DisposableEffect(Unit) {
        onDispose {
            recognizer.close()
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            statusNote = "يمكنك منح إذن الكاميرا أو اختيار صورة الكرت من المعرض."
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            statusNote = "جاري تحليل الصورة واستخراج الأرقام…"
            runCatching {
                val image = InputImage.fromFilePath(context, uri)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val lines = visionText.toNormalizedLines(image.width, image.height)
                        val result = CardOcrFilter.extractPinCandidates(lines)
                        extractionResult = result
                        if (result.bestPin != null) {
                            lockedPin = result.bestPin
                            selectedCandidate = result.bestPin
                            statusNote = "تم استخراج الرقم السري وفرزه من النصوص"
                        } else {
                            statusNote = "لم يتم العثور على رقم تعبئة واضح (11-16 رقماً) في هذه الصورة"
                        }
                    }
                    .addOnFailureListener {
                        statusNote = "تعذر تحليل الصورة المختارة، حاول مرة أخرى"
                    }
            }.onFailure {
                statusNote = "تعذر قراءة الصورة المختارة"
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مسح كرت التعبئة بالكاميرا",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "فرز تلقائي للأرقام السرية وتجاهل النصوص والرقم التسلسلي",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "إغلاق")
                }
            }

            if (hasCameraPermission) {
                CameraRoiScannerBox(
                    accentColor = accentColor,
                    torchEnabled = torchEnabled,
                    isLocked = lockedPin != null,
                    recognizer = recognizer,
                    onFrameAnalyzed = { lines ->
                        if (lockedPin != null) return@CameraRoiScannerBox
                        val result = CardOcrFilter.extractPinCandidates(lines)
                        if (result.candidates.isNotEmpty()) {
                            extractionResult = result
                            val stable = stabilityTracker.recordAndCheckLocked(result.bestPin)
                            if (stable != null) {
                                lockedPin = stable
                                selectedCandidate = stable
                                statusNote = "تم التقاط الرقم وتثبيته بنجاح!"
                            } else {
                                selectedCandidate = result.bestPin
                                statusNote = "جاري التحقق من ثبات القراءة…"
                            }
                        }
                    },
                    onToggleTorch = { torchEnabled = !torchEnabled }
                )
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "نحتاج إلى إذن الكاميرا لمسح أرقام الكرت مباشرة، أو يمكنك اختيار صورة الكرت من جهازك.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                        ) {
                            Text("منح إذن الكاميرا")
                        }
                    }
                }
            }

            // Status + Pick Photo / Rescan controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("scanner_pick_photo_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("من صورة الكرت", maxLines = 1)
                }

                if (lockedPin != null) {
                    OutlinedButton(
                        onClick = {
                            lockedPin = null
                            selectedCandidate = null
                            extractionResult = null
                            stabilityTracker.reset()
                            statusNote = "وجّه الإطار نحو أرقام كرت التعبئة فقط"
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة المسح", maxLines = 1)
                    }
                }
            }

            // Live Detection Result Card
            val currentPin = selectedCandidate
            val allCandidates: List<CardPinCandidate> = extractionResult?.candidates.orEmpty()
            val borderColor by animateColorAsState(
                targetValue = if (lockedPin != null) VerifiedGreen else accentColor.copy(alpha = 0.45f),
                animationSpec = tween(250),
                label = "scanner_result_border"
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = if (lockedPin != null) VerifiedGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                border = BorderStroke(1.5.dp, borderColor)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (lockedPin != null) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = VerifiedGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = statusNote,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (lockedPin != null) VerifiedGreen else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (!currentPin.isNullOrBlank()) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = currentPin,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = accentColor,
                                modifier = Modifier.testTag("scanner_detected_pin")
                            )
                        }
                        Text(
                            text = "${currentPin.length} رقماً • جاهز للمراجعة والتعبئة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    AnimatedVisibility(visible = allCandidates.size > 1) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "أرقام أخرى رُصدت على البطاقة (اختر الصحيح إن لزم):",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(allCandidates, key = { it.digits }) { cand ->
                                    FilterChip(
                                        selected = selectedCandidate == cand.digits,
                                        onClick = {
                                            selectedCandidate = cand.digits
                                            lockedPin = cand.digits
                                        },
                                        label = {
                                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                                Text("${cand.digits} (${cand.digits.length})")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    val chosen = selectedCandidate
                    if (!chosen.isNullOrBlank()) {
                        onPinConfirmed(chosen)
                    }
                },
                enabled = !selectedCandidate.isNullOrBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("scanner_confirm_pin_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor)
            ) {
                Text("اعتماد الرقم في خانة التعبئة")
            }
        }
    }
}

@OptIn(ExperimentalGetImage::class)
@Composable
private fun CameraRoiScannerBox(
    accentColor: Color,
    torchEnabled: Boolean,
    isLocked: Boolean,
    recognizer: com.google.mlkit.vision.text.TextRecognizer,
    onFrameAnalyzed: (List<OcrTextLine>) -> Unit,
    onToggleTorch: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    val cameraController = remember(context) {
        LifecycleCameraController(context).apply {
            setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
        }
    }

    LaunchedEffect(torchEnabled) {
        cameraController.enableTorch(torchEnabled)
    }

    DisposableEffect(lifecycleOwner, cameraController) {
        cameraController.bindToLifecycle(lifecycleOwner)
        cameraController.setImageAnalysisAnalyzer(analysisExecutor) { imageProxy ->
            val mediaImage = imageProxy.image
            if (mediaImage == null) {
                imageProxy.close()
                return@setImageAnalysisAnalyzer
            }
            val rotation = imageProxy.imageInfo.rotationDegrees
            val uprightW = if (rotation == 90 || rotation == 270) imageProxy.height else imageProxy.width
            val uprightH = if (rotation == 90 || rotation == 270) imageProxy.width else imageProxy.height
            val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val lines = visionText.toNormalizedLines(uprightW, uprightH)
                    ContextCompat.getMainExecutor(context).execute {
                        onFrameAnalyzed(lines)
                    }
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        }

        onDispose {
            cameraController.clearImageAnalysisAnalyzer()
            cameraController.unbind()
            analysisExecutor.shutdown()
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "roi_pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "roi_alpha"
    )
    val frameColor = if (isLocked) VerifiedGreen else accentColor.copy(alpha = pulseAlpha)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    controller = cameraController
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Dim outer noise and highlight the central horizontal ROI strip
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
        ) {
            drawRect(color = Color.Black.copy(alpha = 0.52f))
            val roiLeft = size.width * 0.08f
            val roiTop = size.height * 0.28f
            val roiWidth = size.width * 0.84f
            val roiHeight = size.height * 0.44f
            drawRoundRect(
                color = Color.Transparent,
                topLeft = Offset(roiLeft, roiTop),
                size = Size(roiWidth, roiHeight),
                cornerRadius = CornerRadius(24f, 24f),
                blendMode = BlendMode.Clear
            )
            drawRoundRect(
                color = frameColor,
                topLeft = Offset(roiLeft, roiTop),
                size = Size(roiWidth, roiHeight),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 6f)
            )
        }

        Text(
            text = "ضع أرقام الكرت داخل هذا المستطيل",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
        )

        IconButton(
            onClick = onToggleTorch,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .size(44.dp)
                .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
        ) {
            Icon(
                imageVector = if (torchEnabled) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                contentDescription = "تشغيل أو إطفاء الفلاش",
                tint = Color.White
            )
        }
    }
}

private fun Text.toNormalizedLines(imageWidth: Int, imageHeight: Int): List<OcrTextLine> {
    if (imageWidth <= 0 || imageHeight <= 0) {
        return textBlocks.flatMap { block ->
            block.lines.map { OcrTextLine(it.text) }
        }
    }
    return textBlocks.flatMap { block ->
        block.lines.map { line ->
            val box = line.boundingBox
            OcrTextLine(
                text = line.text,
                centerXFraction = box?.exactCenterX()?.div(imageWidth.toFloat()),
                centerYFraction = box?.exactCenterY()?.div(imageHeight.toFloat())
            )
        }
    }
}
