package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DataSimGuide
import com.example.data.model.SimType
import com.example.data.model.TelecomProvider
import com.example.ui.components.DialRequest
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.ReviewAmber
import com.example.ui.theme.ReviewAmberContainer
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.DirectoryUiState
import com.example.util.DialAndClipboardHelper

@Composable
fun DataSimScreen(
    uiState: DirectoryUiState,
    onToggleFavorite: (String) -> Unit,
    onRequestDial: (DialRequest) -> Unit
) {
    val context = LocalContext.current
    val dataSimCodes = uiState.ussdCodes.filter {
        it.supportedSimType == SimType.DATA.key || it.supportedSimType == SimType.BOTH.key
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "شرائح الإنترنت والمودم والراوتر",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "دليل مخصص لشرائح Net+، شرائح المدار للبيانات، LTT 4G، وإعدادات الدخول لواجهة المودم.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = ReviewAmberContainer.copy(alpha = 0.85f)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Filled.WarningAmber,
                        contentDescription = null,
                        tint = ReviewAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "تنبيه التوافق: لا تعمل جميع أكواد الهاتف الصوتي على شرائح البيانات الصرفة أو أجهزة الراوتر. يُنصح باستخدام واجهة المودم أو التطبيق الرسمي لكل شركة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        items(uiState.dataSimGuides, key = { it.id }) { guide ->
            val provider = uiState.providers.firstOrNull { it.id == guide.providerId }
            DataSimGuideCard(
                guide = guide,
                provider = provider,
                onCopyRouterUrl = {
                    DialAndClipboardHelper.copyToClipboard(context, "رابط واجهة المودم", guide.routerInterfaceUrl)
                },
                onOpenRouterUrl = {
                    DialAndClipboardHelper.openWebUrl(context, guide.routerInterfaceUrl)
                }
            )
        }

        item {
            Text(
                text = "الأكواد المتوافقة مع شرائح البيانات",
                style = MaterialTheme.typography.titleLarge
            )
        }

        items(dataSimCodes, key = { "datasim_code_${it.id}" }) { code ->
            val provider = uiState.providers.firstOrNull { it.id == code.providerId }
            CodeQuickCard(
                code = code,
                provider = provider,
                isFavorite = code.id in uiState.userPreferences.favoriteCodeIds,
                onToggleFavorite = { onToggleFavorite(code.id) },
                onCopy = { DialAndClipboardHelper.copyToClipboard(context, code.serviceNameAr, code.ussdCode) },
                onAction = {
                    onRequestDial(
                        DialRequest(
                            title = code.serviceNameAr,
                            codeOrUrl = code.ussdCode,
                            providerId = code.providerId,
                            providerNameAr = code.providerNameAr,
                            supportedSimType = code.supportedSimType,
                            verificationStatus = code.verificationStatus,
                            isWebPortal = !code.isDialableUssd
                        )
                    )
                }
            )
        }
    }
}

@Composable
private fun DataSimGuideCard(
    guide: DataSimGuide,
    provider: TelecomProvider?,
    onCopyRouterUrl: () -> Unit,
    onOpenRouterUrl: () -> Unit
) {
    val accent = parseHexColor(provider?.accentColorHex ?: "#1E6B7B")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ProviderLogoBadge(provider = provider, size = 40.dp)
                    Column {
                        Text(text = guide.simTitleAr, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${guide.providerNameAr} • آخر تحقق: ${guide.lastVerifiedDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                VerificationBadge(status = guide.verificationStatus)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            GuideStepBlock(title = "معرفة الحصة المتبقية:", body = guide.balanceCheckMethodAr)
            GuideStepBlock(title = "طرق الاشتراك والتعبئة:", body = guide.topUpAndSubscribeAr)
            GuideStepBlock(title = "توافق الشريحة:", body = guide.compatibilityWarningAr)

            if (guide.routerInterfaceUrl.isNotBlank()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = accent.copy(alpha = 0.08f)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Router, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                            Text(
                                text = "واجهة إدارة المودم والراوتر",
                                style = MaterialTheme.typography.titleSmall,
                                color = accent
                            )
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = guide.routerInterfaceUrl,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = accent
                            )
                        }
                        if (guide.routerDefaultNoteAr.isNotBlank()) {
                            Text(
                                text = guide.routerDefaultNoteAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onCopyRouterUrl,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("نسخ العنوان")
                            }
                            Button(
                                onClick = onOpenRouterUrl,
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = accent)
                            ) {
                                Icon(Icons.Outlined.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.action_open_router))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideStepBlock(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
