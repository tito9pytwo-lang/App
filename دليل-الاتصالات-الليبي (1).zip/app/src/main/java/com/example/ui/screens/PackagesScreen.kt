package com.example.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.InternetPackage
import com.example.data.model.PackageCategory
import com.example.data.model.SimType
import com.example.data.model.TelecomProvider
import com.example.ui.components.DialRequest
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.components.UssdCodePill
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.DirectoryUiState
import com.example.ui.viewmodel.PackageSortOption
import java.util.Locale

@Composable
fun PackagesScreen(
    uiState: DirectoryUiState,
    onSelectProvider: (String) -> Unit,
    onSelectCategory: (PackageCategory?) -> Unit,
    onToggleCompareMode: (Boolean) -> Unit,
    onSelectCompareSort: (PackageSortOption) -> Unit,
    onToggleComparePackage: (String) -> Unit,
    onClearComparison: () -> Unit,
    onRequestDial: (DialRequest) -> Unit
) {
    val packageProviders = uiState.activeProviders.filter { it.id != "data_modem" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (uiState.compareMode) "مقارنة باقات الشركات" else "باقات الإنترنت الرسمية",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "الأسعار بالدينار الليبي والحصص حسب آخر تحقق من المصادر الرسمية",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CompareArrows,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text("مقارنة", style = MaterialTheme.typography.labelLarge)
                    Switch(
                        checked = uiState.compareMode,
                        onCheckedChange = onToggleCompareMode,
                        modifier = Modifier.testTag("packages_compare_switch")
                    )
                }
            }
        }

        if (!uiState.compareMode) {
            // Dedicated provider tabs
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(packageProviders, key = { it.id }) { provider ->
                        val isSelected = provider.id == uiState.selectedPackageProviderId
                        val pColor = parseHexColor(provider.accentColorHex)
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectProvider(provider.id) },
                            leadingIcon = { ProviderLogoBadge(provider = provider, size = 24.dp) },
                            label = { Text(provider.nameAr) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = pColor.copy(alpha = 0.16f),
                                selectedLabelColor = pColor
                            ),
                            modifier = Modifier.testTag("packages_provider_${provider.id}")
                        )
                    }
                }
            }
        } else {
            // Sort options in Compare Mode
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.comparedPackageIds.isNotEmpty()) {
                                "مقارنة ${uiState.comparedPackageIds.size} باقات مختارة"
                            } else {
                                "مقارنة شاملة لجميع الشركات"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (uiState.comparedPackageIds.isNotEmpty()) {
                            Text(
                                text = "إلغاء التحديد",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.clickable(onClick = onClearComparison)
                            )
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PackageSortOption.entries) { option ->
                            FilterChip(
                                selected = uiState.compareSortOption == option,
                                onClick = { onSelectCompareSort(option) },
                                label = { Text(option.labelAr) }
                            )
                        }
                    }
                }
            }
        }

        // Category filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = uiState.selectedPackageCategory == null,
                        onClick = { onSelectCategory(null) },
                        label = { Text("الكل") }
                    )
                }
                items(PackageCategory.entries) { category ->
                    FilterChip(
                        selected = uiState.selectedPackageCategory == category,
                        onClick = {
                            onSelectCategory(if (uiState.selectedPackageCategory == category) null else category)
                        },
                        label = { Text(category.labelAr) }
                    )
                }
            }
        }

        val displayedPackages = if (uiState.compareMode) {
            uiState.comparablePackagesSorted
        } else {
            uiState.packagesForSelectedProvider
        }

        val bestValueId = if (uiState.compareMode && displayedPackages.size > 1) {
            displayedPackages.minByOrNull { it.pricePerGbLyd ?: Double.MAX_VALUE }
                ?.takeIf { it.pricePerGbLyd != null }
                ?.id
        } else {
            null
        }

        if (displayedPackages.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = "لا توجد باقات مؤكدة حالياً ضمن هذا التصنيف. يمكن إضافة باقات جديدة من لوحة الإدارة المحلية عند الإعلان عنها رسمياً.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        } else {
            items(displayedPackages, key = { it.id }) { pkg ->
                val provider = uiState.providers.firstOrNull { it.id == pkg.providerId }
                PackageDetailCard(
                    pkg = pkg,
                    provider = provider,
                    isSelectedForCompare = pkg.id in uiState.comparedPackageIds,
                    isBestValue = pkg.id == bestValueId,
                    showCompareCheckbox = true,
                    modifier = Modifier.animateItem(),
                    onToggleCompare = { onToggleComparePackage(pkg.id) },
                    onActivateClick = {
                        onRequestDial(
                            DialRequest(
                                title = "${pkg.providerNameAr} - ${pkg.packageNameAr}",
                                codeOrUrl = if (pkg.isDialableActivation) pkg.activationCode else (pkg.officialSourceUrl.ifBlank { "https://www.ltt.ly" }),
                                providerId = pkg.providerId,
                                providerNameAr = pkg.providerNameAr,
                                supportedSimType = if (pkg.category == PackageCategory.DATA_SIM.key) SimType.DATA.key else SimType.BOTH.key,
                                verificationStatus = pkg.verificationStatus,
                                isWebPortal = !pkg.isDialableActivation
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun PackageDetailCard(
    pkg: InternetPackage,
    provider: TelecomProvider?,
    isSelectedForCompare: Boolean,
    isBestValue: Boolean,
    showCompareCheckbox: Boolean,
    modifier: Modifier = Modifier,
    onToggleCompare: () -> Unit,
    onActivateClick: () -> Unit
) {
    val accent = parseHexColor(provider?.accentColorHex ?: "#0B4F6C")
    val priceFormatted = if (pkg.priceLyd % 1.0 == 0.0) "${pkg.priceLyd.toInt()}" else String.format(Locale.US, "%.2f", pkg.priceLyd)
    val perGb = pkg.pricePerGbLyd?.let { String.format(Locale.US, "%.2f د.ل/جيجا", it) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (isSelectedForCompare) BorderStroke(2.dp, accent) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ProviderLogoBadge(provider = provider, size = 38.dp)
                    Column {
                        Text(
                            text = pkg.packageNameAr,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "${pkg.providerNameAr} • ${pkg.categoryEnum.labelAr}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (showCompareCheckbox) {
                    IconButton(
                        onClick = onToggleCompare,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = if (isSelectedForCompare) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                            contentDescription = "تحديد للمقارنة",
                            tint = if (isSelectedForCompare) accent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Metrics Strip: Volume, Price, Validity
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = accent.copy(alpha = 0.08f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("السعة", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            pkg.dataDisplayAr,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = accent
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("السعر", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "$priceFormatted د.ل",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("الصلاحية", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "${pkg.validityDays} يوم",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VerificationBadge(status = pkg.verificationStatus)
                    if (isBestValue) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "الأوفر للجيجا",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
                if (perGb != null) {
                    Text(
                        text = "التكلفة: $perGb",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            Text(
                text = "طريقة التجديد: ${pkg.renewalMethodAr}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (pkg.termsAr.isNotBlank()) {
                Text(
                    text = "الشروط: ${pkg.termsAr}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                UssdCodePill(code = pkg.activationCode, accentColor = accent)
                Button(
                    onClick = onActivateClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    modifier = Modifier.height(48.dp)
                ) {
                    Icon(
                        imageVector = if (pkg.isDialableActivation) Icons.Filled.Call else Icons.Outlined.OpenInBrowser,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (pkg.isDialableActivation) "اشتراك / معاينة" else "فتح البوابة",
                        color = Color.White
                    )
                }
            }
        }
    }
}
