package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.SimType
import com.example.data.model.VerificationStatus
import com.example.ui.components.DialRequest
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.DirectoryUiState
import com.example.util.DialAndClipboardHelper

@Composable
fun TopUpScreen(
    uiState: DirectoryUiState,
    onSelectProvider: (String) -> Unit,
    onCardNumberChange: (String) -> Unit,
    onRequestDial: (DialRequest) -> Unit
) {
    val context = LocalContext.current
    val selectedProvider = uiState.selectedTopUpProvider
    val accent = parseHexColor(selectedProvider?.accentColorHex ?: "#0B4F6C")
    val hasUssdTemplate = !selectedProvider?.topUpTemplate.isNullOrBlank()
    val generatedCode = uiState.generatedTopUpCode
    var showCardScanner by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "نظام تعبئة الرصيد الآمن",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "اختر الشركة وأدخل رقم كرت التعبئة لتكوين الكود الرسمي تلقائياً ومراجعته قبل فتح شاشة الاتصال.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Text(
                text = "1. اختر شركة الاتصالات",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(uiState.activeProviders, key = { it.id }) { provider ->
                    val isSelected = provider.id == selectedProvider?.id
                    val pColor = parseHexColor(provider.accentColorHex)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectProvider(provider.id) },
                        leadingIcon = {
                            ProviderLogoBadge(provider = provider, size = 24.dp)
                        },
                        label = {
                            Text(
                                text = provider.nameAr,
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = pColor.copy(alpha = 0.16f),
                            selectedLabelColor = pColor
                        ),
                        modifier = Modifier.testTag("topup_provider_chip_${provider.id}")
                    )
                }
            }
        }

        if (selectedProvider != null) {
            if (hasUssdTemplate) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ProviderLogoBadge(provider = selectedProvider, size = 40.dp)
                                Column {
                                    Text(
                                        text = "تعبئة رصيد ${selectedProvider.nameAr}",
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = "الصيغة الرسمية: ${selectedProvider.topUpTemplate}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontFamily = JetBrainsMonoFamily
                                            ),
                                            color = accent
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "2. أدخل رقم بطاقة التعبئة أو صوّر الكرت",
                                style = MaterialTheme.typography.titleSmall
                            )

                            FilledTonalButton(
                                onClick = { showCardScanner = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("topup_scan_card_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("تصوير كرت التعبئة (فرز الأرقام تلقائياً)")
                            }

                            OutlinedTextField(
                                value = uiState.topUpCardNumber,
                                onValueChange = onCardNumberChange,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("topup_card_input"),
                                placeholder = { Text("مثال: 1234567890123") },
                                leadingIcon = {
                                    Icon(Icons.Filled.AddCard, contentDescription = null, tint = accent)
                                },
                                trailingIcon = {
                                    if (uiState.topUpCardNumber.isNotEmpty()) {
                                        IconButton(onClick = { onCardNumberChange("") }) {
                                            Icon(Icons.Filled.Clear, contentDescription = "مسح الرقم")
                                        }
                                    } else {
                                        IconButton(onClick = { showCardScanner = true }) {
                                            Icon(Icons.Filled.CameraAlt, contentDescription = "مسح الكرت بالكاميرا", tint = accent)
                                        }
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                textStyle = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    textAlign = TextAlign.Center
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )

                            // Preview Box with animated highlight & digit count
                            val hasDigits = generatedCode.isNotBlank()
                            val previewBg by animateColorAsState(
                                targetValue = if (hasDigits) accent.copy(alpha = 0.13f) else accent.copy(alpha = 0.05f),
                                animationSpec = tween(250),
                                label = "topup_preview_bg"
                            )
                            val previewBorder by animateColorAsState(
                                targetValue = if (hasDigits) accent.copy(alpha = 0.65f) else accent.copy(alpha = 0.25f),
                                animationSpec = tween(250),
                                label = "topup_preview_border"
                            )
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateContentSize(),
                                shape = RoundedCornerShape(16.dp),
                                color = previewBg,
                                border = BorderStroke(1.5.dp, previewBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "3. مراجعة الكود المكوّن قبل التنفيذ",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (uiState.topUpCardNumber.isNotEmpty()) {
                                            Text(
                                                text = "${uiState.topUpCardNumber.length} رقم",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = accent
                                            )
                                        }
                                    }
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Text(
                                            text = generatedCode.ifBlank { selectedProvider.topUpTemplate },
                                            style = MaterialTheme.typography.headlineSmall.copy(
                                                fontFamily = JetBrainsMonoFamily,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = if (hasDigits) accent else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.testTag("topup_preview_code")
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        if (generatedCode.isNotBlank()) {
                                            DialAndClipboardHelper.copyToClipboard(
                                                context,
                                                "كود تعبئة ${selectedProvider.nameAr}",
                                                generatedCode
                                            )
                                        }
                                    },
                                    enabled = generatedCode.isNotBlank(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("topup_copy_button"),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(stringResource(R.string.action_copy_code))
                                }

                                Button(
                                    onClick = {
                                        onRequestDial(
                                            DialRequest(
                                                title = "تعبئة رصيد ${selectedProvider.nameAr}",
                                                codeOrUrl = generatedCode,
                                                providerId = selectedProvider.id,
                                                providerNameAr = selectedProvider.nameAr,
                                                supportedSimType = if (selectedProvider.supportsVoiceSim) SimType.BOTH.key else SimType.DATA.key,
                                                verificationStatus = VerificationStatus.VERIFIED.key,
                                                isWebPortal = false
                                            )
                                        )
                                    },
                                    enabled = generatedCode.isNotBlank(),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(54.dp)
                                        .testTag("topup_dial_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                                ) {
                                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(stringResource(R.string.action_dial_safe))
                                }
                            }
                        }
                    }
                }
            } else {
                // Non-USSD operators like LTT or Modem guides
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ProviderLogoBadge(provider = selectedProvider, size = 40.dp)
                                Text(
                                    text = "طريقة تعبئة ${selectedProvider.nameAr}",
                                    style = MaterialTheme.typography.titleLarge
                                )
                            }
                            Text(
                                text = "لا تعتمد شرائح ${selectedProvider.nameAr} على كود USSD مباشر من لوحة اتصال الهاتف. يتم الشحن عبر بوابة المشتركين أو التطبيق الرسمي للشركة أو صفحة واجهة المودم.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (selectedProvider.officialUrl.isNotBlank()) {
                                Button(
                                    onClick = {
                                        DialAndClipboardHelper.openWebUrl(context, selectedProvider.officialUrl)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                                ) {
                                    Icon(Icons.Outlined.OpenInBrowser, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("فتح البوابة الرسمية (${selectedProvider.nameEn})")
                                }
                            }
                        }
                    }
                }
            }

            item {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "أمان المستخدم أولاً: يفتح التطبيق شاشة الاتصال الافتراضية فقط (ACTION_DIAL) ويترك لك اختيار الشريحة والضغط النهائي على زر الاتصال في جهازك.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }

    if (showCardScanner) {
        CardScannerSheet(
            accentColor = accent,
            onDismiss = { showCardScanner = false },
            onPinConfirmed = { pin ->
                onCardNumberChange(pin)
                showCardScanner = false
            }
        )
    }
}
