package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand Palette (Deep Libyan Coastal Teal & Warm Gold/Emerald)
val TealPrimaryLight = Color(0xFF0B4F6C)
val OnTealPrimaryLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFCDEAF8)
val OnTealContainerLight = Color(0xFF001E2B)

val EmeraldSecondaryLight = Color(0xFF0A7D56)
val OnEmeraldSecondaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFC8F5E0)
val OnEmeraldContainerLight = Color(0xFF002114)

val GoldTertiaryLight = Color(0xFF8C5A00)
val OnGoldTertiaryLight = Color(0xFFFFFFFF)
val GoldContainerLight = Color(0xFFFFDEA8)
val OnGoldTertiaryContainerLight = Color(0xFF2C1900)

val BackgroundLight = Color(0xFFF5F7FA)
val OnBackgroundLight = Color(0xFF131B22)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE7EEF4)
val OnSurfaceLight = Color(0xFF131B22)
val OnSurfaceVariantLight = Color(0xFF475563)
val OutlineLight = Color(0xFFC8D3DD)

// Dark Palette
val TealPrimaryDark = Color(0xFF7DD0F2)
val OnTealPrimaryDark = Color(0xFF00344A)
val TealContainerDark = Color(0xFF083A50)
val OnTealContainerDark = Color(0xFFCDEAF8)

val EmeraldSecondaryDark = Color(0xFF69DBA8)
val OnEmeraldSecondaryDark = Color(0xFF003824)
val EmeraldContainerDark = Color(0xFF045237)
val OnEmeraldContainerDark = Color(0xFFC8F5E0)

val GoldTertiaryDark = Color(0xFFFFC266)
val OnGoldTertiaryDark = Color(0xFF492C00)
val GoldContainerDark = Color(0xFF684100)
val OnGoldContainerDark = Color(0xFFFFDEA8)

val BackgroundDark = Color(0xFF0B1219)
val OnBackgroundDark = Color(0xFFE9EFF5)
val SurfaceDark = Color(0xFF111B25)
val SurfaceVariantDark = Color(0xFF1B2937)
val OnSurfaceDark = Color(0xFFE9EFF5)
val OnSurfaceVariantDark = Color(0xFF9EB0C0)
val OutlineDark = Color(0xFF2D3E4E)

// Semantic Status & Operator Colors
val VerifiedGreen = Color(0xFF0E8A58)
val VerifiedGreenContainer = Color(0xFFD9F7E9)
val VerifiedGreenDarkContainer = Color(0xFF0B3B28)

val ReviewAmber = Color(0xFFC77700)
val ReviewAmberContainer = Color(0xFFFFF0D1)
val ReviewAmberDarkContainer = Color(0xFF472C00)

val DangerRed = Color(0xFFBA1A1A)
val DangerRedContainer = Color(0xFFFFDAD6)

fun parseHexColor(hex: String, fallback: Color = TealPrimaryLight): Color {
    return runCatching {
        val normalized = if (hex.startsWith("#")) hex else "#$hex"
        Color(android.graphics.Color.parseColor(normalized))
    }.getOrDefault(fallback)
}
