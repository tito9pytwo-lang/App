package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppThemeMode
import com.example.data.model.CodeCategory
import com.example.data.model.DataSimGuide
import com.example.data.model.InternetPackage
import com.example.data.model.PackageCategory
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry
import com.example.data.model.VerificationStatus
import com.example.data.repository.TelecomDirectoryRepository
import com.example.data.seed.OfficialSeedData
import com.example.util.DialAndClipboardHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class VerificationFilter(val labelAr: String) {
    ALL("الكل"),
    VERIFIED("تم التحقق"),
    NEEDS_REVIEW("يحتاج مراجعة")
}

enum class PackageSortOption(val labelAr: String) {
    PRICE_ASC("الأقل سعراً"),
    DATA_DESC("الأكبر حجماً"),
    VALUE_BEST("الأوفر للجيجا"),
    VALIDITY_DESC("الأطول صلاحية")
}

data class DirectoryUiState(
    val isLoading: Boolean = true,
    val providers: List<TelecomProvider> = emptyList(),
    val ussdCodes: List<UssdCodeEntry> = emptyList(),
    val packages: List<InternetPackage> = emptyList(),
    val dataSimGuides: List<DataSimGuide> = emptyList(),
    val userPreferences: UserSimPreferences = UserSimPreferences(),
    val searchQuery: String = "",
    val selectedProviderId: String? = null,
    val selectedCodeCategory: CodeCategory? = null,
    val verificationFilter: VerificationFilter = VerificationFilter.ALL,
    val selectedPackageProviderId: String = "libyana",
    val selectedPackageCategory: PackageCategory? = null,
    val compareMode: Boolean = false,
    val compareSortOption: PackageSortOption = PackageSortOption.PRICE_ASC,
    val comparedPackageIds: Set<String> = emptySet(),
    val topUpProviderId: String = "libyana",
    val topUpCardNumber: String = "",
    val snackbarMessage: String? = null,
    val isBusyAction: Boolean = false,
    val exportedJsonPreview: String? = null
) {
    val activeProviders: List<TelecomProvider>
        get() = providers.filter { it.isActive }

    val filteredCodes: List<UssdCodeEntry>
        get() {
            val q = searchQuery.trim().lowercase()
            return ussdCodes.filter { code ->
                val matchesProvider = selectedProviderId == null || code.providerId == selectedProviderId
                val matchesCat = selectedCodeCategory == null || code.category == selectedCodeCategory.key
                val matchesVerification = when (verificationFilter) {
                    VerificationFilter.ALL -> true
                    VerificationFilter.VERIFIED -> code.verificationStatus == VerificationStatus.VERIFIED.key
                    VerificationFilter.NEEDS_REVIEW -> code.verificationStatus == VerificationStatus.NEEDS_REVIEW.key
                }
                val matchesQuery = q.isEmpty() ||
                    code.serviceNameAr.lowercase().contains(q) ||
                    code.providerNameAr.lowercase().contains(q) ||
                    code.ussdCode.lowercase().contains(q) ||
                    code.descriptionAr.lowercase().contains(q)
                matchesProvider && matchesCat && matchesVerification && matchesQuery
            }
        }

    val filteredSearchPackages: List<InternetPackage>
        get() {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) return emptyList()
            return packages.filter { pkg ->
                pkg.packageNameAr.lowercase().contains(q) ||
                    pkg.providerNameAr.lowercase().contains(q) ||
                    pkg.dataDisplayAr.lowercase().contains(q) ||
                    pkg.activationCode.lowercase().contains(q)
            }
        }

    val packagesForSelectedProvider: List<InternetPackage>
        get() = packages.filter { pkg ->
            val matchesProvider = pkg.providerId == selectedPackageProviderId
            val matchesCat = selectedPackageCategory == null || pkg.category == selectedPackageCategory.key
            matchesProvider && matchesCat
        }

    val comparablePackagesSorted: List<InternetPackage>
        get() {
            val base = if (comparedPackageIds.isNotEmpty()) {
                packages.filter { it.id in comparedPackageIds }
            } else {
                packages.filter { pkg ->
                    selectedPackageCategory == null || pkg.category == selectedPackageCategory.key
                }
            }
            return when (compareSortOption) {
                PackageSortOption.PRICE_ASC -> base.sortedBy { it.priceLyd }
                PackageSortOption.DATA_DESC -> base.sortedWith(
                    compareByDescending<InternetPackage> { it.isUnlimited }.thenByDescending { it.dataMb }
                )
                PackageSortOption.VALUE_BEST -> base.sortedBy { it.pricePerGbLyd ?: Double.MAX_VALUE }
                PackageSortOption.VALIDITY_DESC -> base.sortedByDescending { it.validityDays }
            }
        }

    val selectedTopUpProvider: TelecomProvider?
        get() = providers.firstOrNull { it.id == topUpProviderId } ?: providers.firstOrNull()

    val generatedTopUpCode: String
        get() {
            val template = selectedTopUpProvider?.topUpTemplate.orEmpty()
            return DialAndClipboardHelper.buildTopUpCode(template, topUpCardNumber)
        }
}

private data class FilterState(
    val searchQuery: String = "",
    val selectedProviderId: String? = null,
    val selectedCodeCategory: CodeCategory? = null,
    val verificationFilter: VerificationFilter = VerificationFilter.ALL,
    val selectedPackageProviderId: String = "libyana",
    val selectedPackageCategory: PackageCategory? = null,
    val compareMode: Boolean = false,
    val compareSortOption: PackageSortOption = PackageSortOption.PRICE_ASC,
    val comparedPackageIds: Set<String> = emptySet(),
    val topUpProviderId: String = "libyana",
    val topUpCardNumber: String = "",
    val snackbarMessage: String? = null,
    val isBusyAction: Boolean = false,
    val exportedJsonPreview: String? = null
)

class DirectoryViewModel(
    private val repository: TelecomDirectoryRepository
) : ViewModel() {

    private val filterState = MutableStateFlow(FilterState())
    private val seedReadyFlow = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            repository.ensureSeededIfEmpty()
                .onFailure { Log.w(TAG, "Failed initial local seed", it) }
            seedReadyFlow.value = true
        }
    }

    private val providersStream = repository.observeProviders(includeInactive = false)
        .catch { error ->
            Log.w(TAG, "Providers stream error", error)
            emit(OfficialSeedData.providers)
        }

    private val codesStream = repository.observeUssdCodes(includeInactive = false)
        .catch { error ->
            Log.w(TAG, "Codes stream error", error)
            emit(OfficialSeedData.ussdCodes)
        }

    private val packagesStream = repository.observePackages(includeInactive = false)
        .catch { error ->
            Log.w(TAG, "Packages stream error", error)
            emit(OfficialSeedData.packages)
        }

    private val guidesStream = repository.observeDataSimGuides()
        .catch { error ->
            Log.w(TAG, "Guides stream error", error)
            emit(OfficialSeedData.dataSimGuides)
        }

    private val prefsStream = repository.observeUserPreferences()
        .catch { error ->
            Log.w(TAG, "Prefs stream error", error)
            emit(UserSimPreferences())
        }

    private val catalogFlow = combine(
        providersStream,
        codesStream,
        packagesStream,
        guidesStream,
        prefsStream
    ) { providers, codes, packages, guides, prefs ->
        CatalogBundle(providers, codes, packages, guides, prefs)
    }

    val uiState: StateFlow<DirectoryUiState> = combine(
        catalogFlow,
        seedReadyFlow,
        filterState
    ) { bundle, seedReady, filters ->
        val stillInitializing = !seedReady && bundle.providers.isEmpty()

        val resolvedPackageProvider = if (bundle.providers.any { it.id == filters.selectedPackageProviderId }) {
            filters.selectedPackageProviderId
        } else {
            bundle.providers.firstOrNull()?.id ?: "libyana"
        }

        val resolvedTopUpProvider = if (bundle.providers.any { it.id == filters.topUpProviderId }) {
            filters.topUpProviderId
        } else {
            bundle.providers.firstOrNull { it.topUpTemplate.isNotBlank() }?.id ?: "libyana"
        }

        DirectoryUiState(
            isLoading = stillInitializing,
            providers = bundle.providers,
            ussdCodes = bundle.codes,
            packages = bundle.packages,
            dataSimGuides = bundle.guides,
            userPreferences = bundle.prefs,
            searchQuery = filters.searchQuery,
            selectedProviderId = filters.selectedProviderId,
            selectedCodeCategory = filters.selectedCodeCategory,
            verificationFilter = filters.verificationFilter,
            selectedPackageProviderId = resolvedPackageProvider,
            selectedPackageCategory = filters.selectedPackageCategory,
            compareMode = filters.compareMode,
            compareSortOption = filters.compareSortOption,
            comparedPackageIds = filters.comparedPackageIds,
            topUpProviderId = resolvedTopUpProvider,
            topUpCardNumber = filters.topUpCardNumber,
            snackbarMessage = filters.snackbarMessage,
            isBusyAction = filters.isBusyAction,
            exportedJsonPreview = filters.exportedJsonPreview
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = DirectoryUiState(isLoading = true)
    )

    fun updateSearchQuery(query: String) {
        filterState.update { it.copy(searchQuery = query) }
    }

    fun selectProviderFilter(providerId: String?) {
        filterState.update { it.copy(selectedProviderId = providerId) }
    }

    fun selectCodeCategoryFilter(category: CodeCategory?) {
        filterState.update { it.copy(selectedCodeCategory = category) }
    }

    fun selectVerificationFilter(filter: VerificationFilter) {
        filterState.update { it.copy(verificationFilter = filter) }
    }

    fun selectPackageProvider(providerId: String) {
        filterState.update { it.copy(selectedPackageProviderId = providerId) }
    }

    fun selectPackageCategory(category: PackageCategory?) {
        filterState.update { it.copy(selectedPackageCategory = category) }
    }

    fun setCompareMode(enabled: Boolean) {
        filterState.update { it.copy(compareMode = enabled) }
    }

    fun setCompareSortOption(option: PackageSortOption) {
        filterState.update { it.copy(compareSortOption = option) }
    }

    fun toggleComparePackage(packageId: String) {
        filterState.update { state ->
            val updated = state.comparedPackageIds.toMutableSet()
            if (!updated.add(packageId)) {
                updated.remove(packageId)
            }
            state.copy(comparedPackageIds = updated)
        }
    }

    fun clearComparedPackages() {
        filterState.update { it.copy(comparedPackageIds = emptySet()) }
    }

    fun selectTopUpProvider(providerId: String) {
        filterState.update { it.copy(topUpProviderId = providerId) }
    }

    fun updateTopUpCardNumber(raw: String) {
        val digitsOnly = raw.filter { it.isDigit() }.take(24)
        filterState.update { it.copy(topUpCardNumber = digitsOnly) }
    }

    fun consumeSnackbar() {
        filterState.update { it.copy(snackbarMessage = null) }
    }

    fun clearExportedJsonPreview() {
        filterState.update { it.copy(exportedJsonPreview = null) }
    }

    fun toggleFavoriteCode(codeId: String) {
        val currentPrefs = uiState.value.userPreferences
        val updatedFavs = currentPrefs.favoriteCodeIds.toMutableList().apply {
            if (contains(codeId)) remove(codeId) else add(codeId)
        }
        savePreferences(currentPrefs.copy(favoriteCodeIds = updatedFavs))
    }

    fun updateSimLabels(sim1ProviderId: String, sim1Label: String, sim2ProviderId: String, sim2Label: String) {
        val currentPrefs = uiState.value.userPreferences
        savePreferences(
            currentPrefs.copy(
                sim1ProviderId = sim1ProviderId,
                sim1Label = sim1Label.trim().ifBlank { "الشريحة 1" },
                sim2ProviderId = sim2ProviderId,
                sim2Label = sim2Label.trim().ifBlank { "الشريحة 2" }
            ),
            successMsg = "تم حفظ إعدادات الشريحتين محلياً"
        )
    }

    fun setThemeMode(mode: AppThemeMode) {
        val currentPrefs = uiState.value.userPreferences
        savePreferences(currentPrefs.copy(themeMode = mode.key))
    }

    private fun savePreferences(prefs: UserSimPreferences, successMsg: String? = null) {
        viewModelScope.launch {
            val result = repository.saveUserPreferences(prefs)
            if (result.isSuccess && successMsg != null) {
                filterState.update { it.copy(snackbarMessage = successMsg) }
            } else if (result.isFailure) {
                filterState.update { it.copy(snackbarMessage = "تعذر حفظ الإعدادات المحلية") }
            }
        }
    }

    // --- Local Admin & Update Actions ---

    fun restoreOfficialDataNow() {
        runLocalMutation("تمت استعادة البيانات الرسمية المؤكدة محلياً") {
            repository.restoreOfficialCatalog()
        }
    }

    fun exportCatalogJson() {
        viewModelScope.launch {
            filterState.update { it.copy(isBusyAction = true) }
            val result = repository.exportCatalogJson()
            filterState.update {
                it.copy(
                    isBusyAction = false,
                    exportedJsonPreview = result.getOrNull(),
                    snackbarMessage = if (result.isFailure) "تعذر تصدير قاعدة البيانات" else null
                )
            }
        }
    }

    fun importCatalogJson(jsonText: String) {
        viewModelScope.launch {
            filterState.update { it.copy(isBusyAction = true) }
            val result = repository.importCatalogJson(jsonText)
            filterState.update {
                it.copy(
                    isBusyAction = false,
                    snackbarMessage = result.fold(
                        onSuccess = { count -> "تم تحديث قاعدة البيانات المحلية ($count سجل)" },
                        onFailure = { err -> "تعذر استيراد التحديث: ${err.localizedMessage ?: "صيغة غير صالحة"}" }
                    )
                )
            }
        }
    }

    fun saveProvider(provider: TelecomProvider) {
        runLocalMutation("تم حفظ بيانات الشركة محلياً") {
            repository.saveProvider(provider).map { }
        }
    }

    fun deleteProvider(providerId: String) {
        runLocalMutation("تم حذف الشركة من الدليل") {
            repository.deleteProvider(providerId)
        }
    }

    fun saveUssdCode(entry: UssdCodeEntry) {
        runLocalMutation("تم حفظ الكود في قاعدة البيانات المحلية") {
            repository.saveUssdCode(entry).map { }
        }
    }

    fun deleteUssdCode(codeId: String) {
        runLocalMutation("تم حذف الكود") {
            repository.deleteUssdCode(codeId)
        }
    }

    fun toggleCodeVerification(entry: UssdCodeEntry) {
        val nextStatus = if (entry.verificationStatus == VerificationStatus.VERIFIED.key) {
            VerificationStatus.NEEDS_REVIEW.key
        } else {
            VerificationStatus.VERIFIED.key
        }
        saveUssdCode(
            entry.copy(
                verificationStatus = nextStatus,
                lastVerifiedDate = OfficialSeedData.VERIFICATION_DATE
            )
        )
    }

    fun savePackage(pkg: InternetPackage) {
        runLocalMutation("تم حفظ الباقة محلياً") {
            repository.savePackage(pkg).map { }
        }
    }

    fun deletePackage(packageId: String) {
        runLocalMutation("تم حذف الباقة") {
            repository.deletePackage(packageId)
        }
    }

    fun saveDataSimGuide(guide: DataSimGuide) {
        runLocalMutation("تم حفظ دليل شريحة البيانات") {
            repository.saveDataSimGuide(guide).map { }
        }
    }

    fun deleteDataSimGuide(guideId: String) {
        runLocalMutation("تم حذف دليل شريحة البيانات") {
            repository.deleteDataSimGuide(guideId)
        }
    }

    private fun runLocalMutation(successMessage: String, block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            filterState.update { it.copy(isBusyAction = true) }
            val result = block()
            filterState.update {
                it.copy(
                    isBusyAction = false,
                    snackbarMessage = if (result.isSuccess) {
                        successMessage
                    } else {
                        "تعذر تنفيذ العملية في قاعدة البيانات المحلية"
                    }
                )
            }
        }
    }

    private data class CatalogBundle(
        val providers: List<TelecomProvider>,
        val codes: List<UssdCodeEntry>,
        val packages: List<InternetPackage>,
        val guides: List<DataSimGuide>,
        val prefs: UserSimPreferences
    )

    private companion object {
        const val TAG = "DirectoryViewModel"
    }
}
