package com.example.util

/**
 * سطر نصي مستخرج من الكاميرا أو الصورة مع موقعه النسبي داخل الإطار (0..1).
 */
data class OcrTextLine(
    val text: String,
    val centerXFraction: Float? = null,
    val centerYFraction: Float? = null
)

data class CardPinCandidate(
    val digits: String,
    val score: Int,
    val reasonAr: String,
    val isInsideRoi: Boolean
)

data class CardExtractionResult(
    val bestPin: String?,
    val candidates: List<CardPinCandidate>,
    val ignoredTokensCount: Int
)

/**
 * محرك ذكي لفرز وتصفية أرقام بطاقة التعبئة الليبية من النصوص الإرشادية
 * والأرقام التسلسلية والتواريخ وأكواد الخدمة المطبوعة على الكرت.
 */
object CardOcrFilter {

    private val serialKeywords = listOf(
        "serial", "s/n", "sn:", "sn ", "batch", "ref", "iccid", "barcode",
        "تسلسلي", "التسلسلي", "متسلسل", "رقم البطاقة التسلسلي", "المرجع", "باركود"
    )

    private val pinKeywords = listOf(
        "pin", "secret", "voucher", "scratch", "code",
        "الرقم السري", "سري", "للتعبئة", "تعبئة", "الشحن", "اكشط", "رمز الشحن"
    )

    private val instructionKeywords = listOf(
        "www.", "http", "support", "help", "customer", "call ",
        "للاستفسار", "خدمة العملاء", "الموقع", "للاتصال", "صالح"
    )

    private val dateRegex = Regex("""\b(?:\d{4}[-/]\d{1,2}(?:[-/]\d{1,2})?|\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b""")
    private val ussdRegex = Regex("""[*#][0-9*#]+[#]""")
    private val libyanPhoneRegex = Regex("""^(?:00218|218|\+218)?0?9[1-6]\d{7}$""")
    private val digitRunOrGroupedRegex = Regex("""[0-9A-Za-z٠-٩۰-۹][0-9A-Za-z٠-٩۰-۹\s\-]{9,24}[0-9A-Za-z٠-٩۰-۹]""")

    fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * يصحح أخطاء القراءة البصرية الشائعة (مثل O->0 أو I/l->1) فقط داخل المقاطع الرقمية
     * التي تحتوي فعلياً على 6 أرقام حقيقية على الأقل حتى لا تتحول الكلمات العادية لأرقام.
     */
    private fun cleanNumericCandidateToken(rawToken: String): String? {
        val trimmed = rawToken.trim()
        val realDigitCount = trimmed.count { it.isDigit() }
        val nonSpaceCount = trimmed.count { !it.isWhitespace() && it != '-' }
        if (nonSpaceCount == 0 || realDigitCount < 6) return null
        if (realDigitCount.toFloat() / nonSpaceCount.toFloat() < 0.72f) return null

        val mapped = StringBuilder()
        for (ch in trimmed) {
            when (ch) {
                in '0'..'9' -> mapped.append(ch)
                'O', 'o', 'D' -> mapped.append('0')
                'I', 'l', 'i', '|' -> mapped.append('1')
                'Z', 'z' -> mapped.append('2')
                'S', 's' -> mapped.append('5')
                'B' -> mapped.append('8')
                ' ', '-' -> Unit
                else -> return null
            }
        }
        return mapped.toString()
    }

    fun isInsideScanRoi(line: OcrTextLine): Boolean {
        val x = line.centerXFraction ?: return true
        val y = line.centerYFraction ?: return true
        return x in 0.08f..0.92f && y in 0.24f..0.76f
    }

    fun extractPinCandidates(lines: List<OcrTextLine>): CardExtractionResult {
        val bestByDigits = linkedMapOf<String, CardPinCandidate>()
        var ignoredCount = 0

        for (line in lines) {
            val normalizedLine = normalizeDigits(line.text)
            val lower = normalizedLine.lowercase()

            // Remove inline USSD codes (*121*...#) and dates before extracting digits
            val scrubbedLine = normalizedLine
                .replace(ussdRegex, " ")
                .replace(dateRegex, " ")

            val hasUssdNoise = normalizedLine != scrubbedLine
            if (hasUssdNoise) ignoredCount++

            val isSerialLine = serialKeywords.any { lower.contains(it) }
            val isPinCueLine = pinKeywords.any { lower.contains(it) }
            val isInstructionLine = instructionKeywords.any { lower.contains(it) }
            val insideRoi = isInsideScanRoi(line)

            val matches = digitRunOrGroupedRegex.findAll(scrubbedLine).toList()
            for (match in matches) {
                val rawChunk = match.value
                val digits = cleanNumericCandidateToken(rawChunk)
                if (digits == null) {
                    ignoredCount++
                    continue
                }

                // Filter out invalid lengths or phone numbers
                if (digits.length !in 11..16 || libyanPhoneRegex.matches(digits)) {
                    ignoredCount++
                    continue
                }

                var score = 0
                val reasons = mutableListOf<String>()

                when (digits.length) {
                    13 -> {
                        score += 65
                        reasons.add("طول قياسي 13 رقماً")
                    }
                    12, 14 -> {
                        score += 45
                        reasons.add("طول متوافق (${digits.length} رقماً)")
                    }
                    15, 16 -> {
                        score += 10
                        reasons.add("قد يكون رقماً تسلسلياً (${digits.length} رقماً)")
                    }
                    else -> {
                        score += 5
                    }
                }

                if (line.centerYFraction != null) {
                    if (insideRoi) {
                        score += 35
                        reasons.add("داخل إطار المسح")
                    } else {
                        score -= 15
                    }
                }

                if (isPinCueLine) {
                    score += 25
                    reasons.add("بجوار كلمة مفتاحية للشحن")
                }

                if (rawChunk.contains(' ') || rawChunk.contains('-')) {
                    score += 12
                }

                if (isSerialLine) {
                    score -= 60
                    reasons.add("قرب كلمة تسلسلي")
                }

                if (isInstructionLine) {
                    score -= 40
                }

                if (score <= 0) {
                    ignoredCount++
                    continue
                }

                val candidate = CardPinCandidate(
                    digits = digits,
                    score = score,
                    reasonAr = reasons.take(2).joinToString(" • "),
                    isInsideRoi = insideRoi
                )

                val existing = bestByDigits[digits]
                if (existing == null || candidate.score > existing.score) {
                    bestByDigits[digits] = candidate
                }
            }
        }

        val sorted = bestByDigits.values.sortedWith(
            compareByDescending<CardPinCandidate> { it.score }
                .thenByDescending { it.digits.length == 13 }
        )

        return CardExtractionResult(
            bestPin = sorted.firstOrNull()?.digits,
            candidates = sorted,
            ignoredTokensCount = ignoredCount
        )
    }
}

/**
 * متتبع استقرار القراءة عبر إطارات الكاميرا المتتالية لتجنب الأخطاء العشوائية في إطار واحد.
 */
class PinStabilityTracker(private val requiredConsistentFrames: Int = 2) {
    private val history = ArrayDeque<String>(6)

    fun recordAndCheckLocked(candidate: String?): String? {
        if (candidate.isNullOrBlank()) return null
        history.addLast(candidate)
        if (history.size > 6) {
            history.removeFirst()
        }
        val occurrences = history.count { it == candidate }
        return if (occurrences >= requiredConsistentFrames) candidate else null
    }

    fun reset() {
        history.clear()
    }
}
