package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.R
import com.example.data.model.UserSimPreferences

object DialAndClipboardHelper {

    /**
     * يبني كود التعبئة وفق صيغة الشركة، مع تنقية رقم البطاقة من الفراغات والرموز غير الرقمية.
     */
    fun buildTopUpCode(template: String, rawCardDigits: String): String {
        val cleanDigits = rawCardDigits.filter { it.isDigit() }
        if (template.isBlank() || cleanDigits.isBlank()) return ""
        return template.replace("{CARD}", cleanDigits)
    }

    /**
     * ينسخ النص إلى الحافظة ويعرض إشعاراً فورياً للمستخدم.
     */
    fun copyToClipboard(context: Context, label: String, value: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, value))
        Toast.makeText(context, context.getString(R.string.action_copied_toast), Toast.LENGTH_SHORT).show()
    }

    /**
     * يفتح شاشة الاتصال باستخدام ACTION_DIAL الآمن دون أي أذونات حساسة ودون تنفيذ تلقائي للمكالمة.
     * يتم تمرير تلميح اختياري لشريحة SIM لبعض تطبيقات الاتصال المتوافقة، مع عرض تأكيد بصري للمستخدم قبل الاتصال.
     */
    fun openDialerSafely(
        context: Context,
        ussdOrPhone: String,
        preferredSimSlotIndex: Int? = null
    ) {
        val trimmed = ussdOrPhone.trim()
        if (trimmed.isEmpty()) return

        val encoded = Uri.encode(trimmed)
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$encoded")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (preferredSimSlotIndex != null) {
                putExtra("com.android.phone.extra.slot", preferredSimSlotIndex)
                putExtra("simSlot", preferredSimSlotIndex)
            }
        }
        val resolved = intent.resolveActivity(context.packageManager)
        if (resolved != null) {
            context.startActivity(intent)
        } else {
            Toast.makeText(context, context.getString(R.string.action_no_dialer_found), Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * يفتح رابطاً رسمياً أو عنوان واجهة مودم في المتصفح.
     */
    fun openWebUrl(context: Context, url: String) {
        val normalized = if (url.startsWith("http://") || url.startsWith("https://")) {
            url.trim()
        } else {
            "https://${url.trim()}"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            Toast.makeText(context, context.getString(R.string.action_no_browser_found), Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * يحدد رقم الشريحة المقترح (0 للشريحة 1، 1 للشريحة 2) بناءً على تفضيلات المستخدم للشركة المختارة.
     */
    fun recommendSimSlot(providerId: String, prefs: UserSimPreferences): Pair<Int?, String?> {
        return when (providerId) {
            prefs.sim1ProviderId -> 0 to prefs.sim1Label
            prefs.sim2ProviderId -> 1 to prefs.sim2Label
            else -> null to null
        }
    }
}
