package com.example.data.repository

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.TelecomDatabase
import com.example.data.model.AppThemeMode
import com.example.data.model.CodeCategory
import com.example.data.model.InternetPackage
import com.example.data.model.PackageCategory
import com.example.data.model.TelecomProvider
import com.example.data.model.UserSimPreferences
import com.example.data.model.UssdCodeEntry
import com.example.data.model.VerificationStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TelecomDirectoryRepositoryTest {

    private lateinit var database: TelecomDatabase
    private lateinit var repository: TelecomDirectoryRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, TelecomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = TelecomDirectoryRepository(database.telecomDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun ensureSeededIfEmpty_seedsOfficialCatalogOnceAndPreservesOfflineData() = runTest {
        val firstRun = repository.ensureSeededIfEmpty()
        assertTrue(firstRun.isSuccess)
        assertTrue(firstRun.getOrDefault(false))

        val providers = repository.observeProviders().first()
        val codes = repository.observeUssdCodes().first()
        val packages = repository.observePackages().first()
        val guides = repository.observeDataSimGuides().first()

        assertEquals(4, providers.size)
        assertTrue(codes.isNotEmpty())
        assertTrue(packages.isNotEmpty())
        assertEquals(3, guides.size)

        val secondRun = repository.ensureSeededIfEmpty()
        assertTrue(secondRun.isSuccess)
        assertFalse(secondRun.getOrDefault(true))
    }

    @Test
    fun localAdminCrud_savesAndDeletesProvidersCodesAndPackagesOffline() = runTest {
        repository.ensureSeededIfEmpty()

        val savedProvId = repository.saveProvider(
            TelecomProvider(
                nameAr = "مزود تجريبي",
                nameEn = "Test ISP",
                shortCode = "TESTISP",
                topUpTemplate = "*199*{CARD}#"
            )
        ).getOrThrow()

        val providersAfterAdd = repository.observeProviders().first()
        assertTrue(providersAfterAdd.any { it.id == savedProvId && it.nameAr == "مزود تجريبي" })

        val savedCodeId = repository.saveUssdCode(
            UssdCodeEntry(
                providerId = savedProvId,
                providerNameAr = "مزود تجريبي",
                serviceNameAr = "فحص الرصيد التجريبي",
                category = CodeCategory.BALANCE.key,
                ussdCode = "*199#",
                descriptionAr = "كود تجريبي",
                usageStepsAr = "اطلب *199#",
                verificationStatus = VerificationStatus.NEEDS_REVIEW.key
            )
        ).getOrThrow()

        val codesAfterAdd = repository.observeUssdCodes().first()
        assertTrue(codesAfterAdd.any { it.id == savedCodeId && it.ussdCode == "*199#" })

        val savedPkgId = repository.savePackage(
            InternetPackage(
                providerId = savedProvId,
                providerNameAr = "مزود تجريبي",
                packageNameAr = "باقة تجريبية 10 جيجا",
                category = PackageCategory.MONTHLY.key,
                dataDisplayAr = "10 جيجابايت",
                dataMb = 10L * 1024L,
                priceLyd = 15.0,
                validityDays = 30L,
                activationCode = "*199*1#",
                renewalMethodAr = "عبر الكود"
            )
        ).getOrThrow()

        assertTrue(repository.observePackages().first().any { it.id == savedPkgId })

        repository.deletePackage(savedPkgId).getOrThrow()
        repository.deleteUssdCode(savedCodeId).getOrThrow()
        repository.deleteProvider(savedProvId).getOrThrow()

        assertFalse(repository.observeProviders().first().any { it.id == savedProvId })
    }

    @Test
    fun preferencesAndJsonBundle_persistAndUpdateOffline() = runTest {
        repository.ensureSeededIfEmpty()

        repository.saveUserPreferences(
            UserSimPreferences(
                sim1ProviderId = "almadar",
                sim1Label = "المدار الشخصي",
                sim2ProviderId = "libyana",
                sim2Label = "ليبيانا للعمل",
                favoriteCodeIds = listOf("almadar_balance", "libyana_internet_balance"),
                themeMode = AppThemeMode.DARK.key
            )
        ).getOrThrow()

        val prefs = repository.observeUserPreferences().first()
        assertEquals("almadar", prefs.sim1ProviderId)
        assertEquals(AppThemeMode.DARK.key, prefs.themeMode)
        assertEquals(2, prefs.favoriteCodeIds.size)

        val json = repository.exportCatalogJson().getOrThrow()
        assertTrue(json.contains("libyana"))
        assertTrue(json.contains("almadar"))

        val importedCount = repository.importCatalogJson(json).getOrThrow()
        assertTrue(importedCount > 0)
    }
}
