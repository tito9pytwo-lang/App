package com.example.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CardOcrFilterTest {

    @Test
    fun extractPinCandidates_ignoresInstructionsSerialDatesAndSelects13DigitPin() {
        val noisyCardLines = listOf(
            OcrTextLine("Libyana 10 LYD Recharge Card", centerXFraction = 0.5f, centerYFraction = 0.12f),
            OcrTextLine("للتعبئة اطلب *121*الرقم السري#", centerXFraction = 0.5f, centerYFraction = 0.20f),
            OcrTextLine("Exp: 2027/12/31", centerXFraction = 0.5f, centerYFraction = 0.22f),
            OcrTextLine("PIN: 4829 1038 57291", centerXFraction = 0.5f, centerYFraction = 0.48f),
            OcrTextLine("S/N: 990011223344556", centerXFraction = 0.5f, centerYFraction = 0.86f),
            OcrTextLine("Customer Care 0912100000", centerXFraction = 0.5f, centerYFraction = 0.92f)
        )

        val result = CardOcrFilter.extractPinCandidates(noisyCardLines)
        assertEquals("4829103857291", result.bestPin)
        assertTrue(result.ignoredTokensCount >= 1)
    }

    @Test
    fun extractPinCandidates_handlesArabicIndicDigitsAndOcrConfusablesInNumericRuns() {
        val lines = listOf(
            OcrTextLine("اكشط هنا", centerXFraction = 0.5f, centerYFraction = 0.35f),
            OcrTextLine("١٢٣٤ ٥٦٧٨ ٩٠١٢٣", centerXFraction = 0.5f, centerYFraction = 0.50f),
            OcrTextLine("Serial 112233445566778", centerXFraction = 0.5f, centerYFraction = 0.85f)
        )

        val result = CardOcrFilter.extractPinCandidates(lines)
        assertEquals("1234567890123", result.bestPin)
    }

    @Test
    fun extractPinCandidates_rejectsPlainWordsAndTooShortNumbers() {
        val lines = listOf(
            OcrTextLine("ALMADAR ALJADID LIBYA"),
            OcrTextLine("Call *112*1234567890123#"),
            OcrTextLine("Date 14/11/2026 Price 5 LYD")
        )

        val result = CardOcrFilter.extractPinCandidates(lines)
        assertNull(result.bestPin)
    }

    @Test
    fun pinStabilityTracker_requiresConsistentFramesBeforeLocking() {
        val tracker = PinStabilityTracker(requiredConsistentFrames = 2)
        assertNull(tracker.recordAndCheckLocked("4829103857291"))
        assertEquals("4829103857291", tracker.recordAndCheckLocked("4829103857291"))

        tracker.reset()
        assertNull(tracker.recordAndCheckLocked("4829103857291"))
    }
}
