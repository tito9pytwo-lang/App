package com.example.util

import com.example.data.model.UserSimPreferences
import com.example.data.seed.OfficialSeedData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DialAndClipboardHelperTest {

    @Test
    fun buildTopUpCode_libyana_stripsSpacesAndFormatsCorrectly() {
        val code = DialAndClipboardHelper.buildTopUpCode("*121*{CARD}#", "1234 5678-9012")
        assertEquals("*121*123456789012#", code)
    }

    @Test
    fun buildTopUpCode_almadar_stripsNonDigits() {
        val code = DialAndClipboardHelper.buildTopUpCode("*112*{CARD}#", "abc987654321xyz")
        assertEquals("*112*987654321#", code)
    }

    @Test
    fun buildTopUpCode_blankTemplateOrCard_returnsEmpty() {
        assertEquals("", DialAndClipboardHelper.buildTopUpCode("", "12345"))
        assertEquals("", DialAndClipboardHelper.buildTopUpCode("*121*{CARD}#", "   "))
    }

    @Test
    fun recommendSimSlot_matchesConfiguredSim1AndSim2() {
        val prefs = UserSimPreferences(
            sim1ProviderId = "libyana",
            sim1Label = "ليبيانا",
            sim2ProviderId = "almadar",
            sim2Label = "المدار"
        )
        assertEquals(0 to "ليبيانا", DialAndClipboardHelper.recommendSimSlot("libyana", prefs))
        assertEquals(1 to "المدار", DialAndClipboardHelper.recommendSimSlot("almadar", prefs))
        assertEquals(null to null, DialAndClipboardHelper.recommendSimSlot("ltt", prefs))
    }

    @Test
    fun officialSeedData_allReferencesValidAndDatesPresent() {
        val providerIds = OfficialSeedData.providers.map { it.id }.toSet()
        assertTrue(OfficialSeedData.ussdCodes.all { it.providerId in providerIds && it.lastVerifiedDate.isNotBlank() })
        assertTrue(OfficialSeedData.packages.all { it.providerId in providerIds && it.lastVerifiedDate.isNotBlank() })
        assertTrue(OfficialSeedData.dataSimGuides.all { it.providerId in providerIds && it.lastVerifiedDate.isNotBlank() })
    }
}
