package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.repository.TelecomDirectoryRepository
import com.example.ui.components.DialConfirmBottomSheet
import com.example.ui.components.DialRequest
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CodesDirectoryScreen
import com.example.ui.screens.DataSimScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PackagesScreen
import com.example.ui.screens.TopUpScreen
import com.example.ui.theme.LibyaTelecomTheme
import com.example.ui.viewmodel.DirectoryViewModel

enum class MainTab(
    val labelRes: Int,
    val icon: ImageVector,
    val testTag: String
) {
    HOME(R.string.nav_home, Icons.Filled.Home, "nav_home"),
    TOPUP(R.string.nav_topup, Icons.Filled.AddCard, "nav_topup"),
    PACKAGES(R.string.nav_packages, Icons.Filled.Wifi, "nav_packages"),
    DATA_SIMS(R.string.nav_data_sims, Icons.Filled.Router, "nav_data_sims"),
    CODES(R.string.nav_codes_admin, Icons.Filled.Dialpad, "nav_codes_admin")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LibyaTelecomDirectoryApp()
        }
    }
}

@Composable
fun LibyaTelecomDirectoryApp() {
    val viewModel: DirectoryViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val repository = TelecomDirectoryRepository(app.applicationContext)
                DirectoryViewModel(repository)
            }
        }
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var activeTab by remember { mutableStateOf(MainTab.HOME) }
    var showAdminScreen by remember { mutableStateOf(false) }
    var pendingDialRequest by remember { mutableStateOf<DialRequest?>(null) }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    LibyaTelecomTheme(themeMode = uiState.userPreferences.themeModeEnum) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useNavigationRail && !showAdminScreen) {
                        NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                            MainTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = activeTab == tab,
                                    onClick = { activeTab = tab },
                                    icon = { Icon(tab.icon, contentDescription = stringResource(tab.labelRes)) },
                                    label = { Text(stringResource(tab.labelRes), maxLines = 1) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail && !showAdminScreen) {
                        NavigationRail {
                            MainTab.entries.forEach { tab ->
                                NavigationRailItem(
                                    selected = activeTab == tab,
                                    onClick = { activeTab = tab },
                                    icon = { Icon(tab.icon, contentDescription = stringResource(tab.labelRes)) },
                                    label = { Text(stringResource(tab.labelRes), maxLines = 1) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .widthIn(max = 920.dp)
                                .fillMaxSize()
                        ) {
                            when {
                                uiState.isLoading -> {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }

                                showAdminScreen -> {
                                    AdminDashboardScreen(
                                        uiState = uiState,
                                        onBack = { showAdminScreen = false },
                                        onRestoreOfficialCatalog = viewModel::restoreOfficialDataNow,
                                        onExportJson = viewModel::exportCatalogJson,
                                        onClearExportedJson = viewModel::clearExportedJsonPreview,
                                        onImportJson = viewModel::importCatalogJson,
                                        onSaveProvider = viewModel::saveProvider,
                                        onDeleteProvider = viewModel::deleteProvider,
                                        onSaveCode = viewModel::saveUssdCode,
                                        onDeleteCode = viewModel::deleteUssdCode,
                                        onToggleCodeVerification = viewModel::toggleCodeVerification,
                                        onSavePackage = viewModel::savePackage,
                                        onDeletePackage = viewModel::deletePackage
                                    )
                                }

                                else -> {
                                    when (activeTab) {
                                        MainTab.HOME -> HomeScreen(
                                            uiState = uiState,
                                            onSearchChange = viewModel::updateSearchQuery,
                                            onNavigateToTopUp = { providerId ->
                                                if (providerId != null) viewModel.selectTopUpProvider(providerId)
                                                activeTab = MainTab.TOPUP
                                            },
                                            onNavigateToPackages = { providerId ->
                                                if (providerId != null) viewModel.selectPackageProvider(providerId)
                                                activeTab = MainTab.PACKAGES
                                            },
                                            onNavigateToDataSims = {
                                                activeTab = MainTab.DATA_SIMS
                                            },
                                            onNavigateToCodesCategory = { providerId, category ->
                                                viewModel.selectProviderFilter(providerId)
                                                viewModel.selectCodeCategoryFilter(category)
                                                activeTab = MainTab.CODES
                                            },
                                            onToggleTheme = viewModel::setThemeMode,
                                            onToggleFavorite = viewModel::toggleFavoriteCode,
                                            onRequestDial = { pendingDialRequest = it }
                                        )

                                        MainTab.TOPUP -> TopUpScreen(
                                            uiState = uiState,
                                            onSelectProvider = viewModel::selectTopUpProvider,
                                            onCardNumberChange = viewModel::updateTopUpCardNumber,
                                            onRequestDial = { pendingDialRequest = it }
                                        )

                                        MainTab.PACKAGES -> PackagesScreen(
                                            uiState = uiState,
                                            onSelectProvider = viewModel::selectPackageProvider,
                                            onSelectCategory = viewModel::selectPackageCategory,
                                            onToggleCompareMode = viewModel::setCompareMode,
                                            onSelectCompareSort = viewModel::setCompareSortOption,
                                            onToggleComparePackage = viewModel::toggleComparePackage,
                                            onClearComparison = viewModel::clearComparedPackages,
                                            onRequestDial = { pendingDialRequest = it }
                                        )

                                        MainTab.DATA_SIMS -> DataSimScreen(
                                            uiState = uiState,
                                            onToggleFavorite = viewModel::toggleFavoriteCode,
                                            onRequestDial = { pendingDialRequest = it }
                                        )

                                        MainTab.CODES -> CodesDirectoryScreen(
                                            uiState = uiState,
                                            onSearchChange = viewModel::updateSearchQuery,
                                            onSelectProvider = viewModel::selectProviderFilter,
                                            onSelectCategory = viewModel::selectCodeCategoryFilter,
                                            onSelectVerificationFilter = viewModel::selectVerificationFilter,
                                            onToggleFavorite = viewModel::toggleFavoriteCode,
                                            onRequestDial = { pendingDialRequest = it },
                                            onSaveSimSettings = viewModel::updateSimLabels,
                                            onOpenAdminPanel = { showAdminScreen = true }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            val dialRequest = pendingDialRequest
            if (dialRequest != null) {
                DialConfirmBottomSheet(
                    request = dialRequest,
                    userPrefs = uiState.userPreferences,
                    onDismiss = { pendingDialRequest = null }
                )
            }
        }
    }
}
