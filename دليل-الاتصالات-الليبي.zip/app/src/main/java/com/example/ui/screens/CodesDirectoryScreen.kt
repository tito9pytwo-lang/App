package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CodeCategory
import com.example.data.model.TelecomProvider
import com.example.data.model.UssdCodeEntry
import com.example.ui.components.DialRequest
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.components.UssdCodePill
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.DirectoryUiState
import com.example.ui.viewmodel.VerificationFilter
import com.example.util.DialAndClipboardHelper

@Composable
fun CodesDirectoryScreen(
    uiState: DirectoryUiState,
    onSearchChange: (String) -> Unit,
    onSelectProvider: (String?) -> Unit,
    onSelectCategory: (CodeCategory?) -> Unit,
    onSelectVerificationFilter: (VerificationFilter) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onRequestDial: (DialRequest) -> Unit,
    onSaveSimSettings: (String, String, String, String) -> Unit,
    onOpenAdminPanel: () -> Unit
) {
    val context = LocalContext.current
    var showDualSimDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "دليل الأكواد والإعدادات",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "أكواد مصنفة مع حالة التحقق والمصدر وتاريخ المراجعة",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Dual-SIM & Admin action cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { showDualSimDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("dual_sim_settings_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.SimCard, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("إعداد الشريحتين", maxLines = 1)
                }

                Button(
                    onClick = onOpenAdminPanel,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("open_admin_panel_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("لوحة الإدارة", maxLines = 1)
                }
            }
        }

        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث بالكود أو اسم الخدمة…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Filled.Clear, contentDescription = "مسح")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
        }

        // Provider filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = uiState.selectedProviderId == null,
                        onClick = { onSelectProvider(null) },
                        label = { Text("كل الشركات") }
                    )
                }
                items(uiState.activeProviders, key = { it.id }) { provider ->
                    val pColor = parseHexColor(provider.accentColorHex)
                    FilterChip(
                        selected = uiState.selectedProviderId == provider.id,
                        onClick = {
                            onSelectProvider(if (uiState.selectedProviderId == provider.id) null else provider.id)
                        },
                        leadingIcon = { ProviderLogoBadge(provider = provider, size = 22.dp) },
                        label = { Text(provider.nameAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = pColor.copy(alpha = 0.16f),
                            selectedLabelColor = pColor
                        )
                    )
                }
            }
        }

        // Category filter chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = uiState.selectedCodeCategory == null,
                        onClick = { onSelectCategory(null) },
                        label = { Text("كل التصنيفات") }
                    )
                }
                items(CodeCategory.entries) { category ->
                    FilterChip(
                        selected = uiState.selectedCodeCategory == category,
                        onClick = {
                            onSelectCategory(if (uiState.selectedCodeCategory == category) null else category)
                        },
                        label = { Text(category.labelAr) }
                    )
                }
            }
        }

        // Verification status filter chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VerificationFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = uiState.verificationFilter == filter,
                        onClick = { onSelectVerificationFilter(filter) },
                        label = { Text(filter.labelAr) }
                    )
                }
            }
        }

        val codes = uiState.filteredCodes
        if (codes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = "لا توجد أكواد مطابقة لمعايير التصفية الحالية.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        } else {
            items(codes, key = { it.id }) { code ->
                val provider = uiState.providers.firstOrNull { it.id == code.providerId }
                DetailedUssdCodeCard(
                    code = code,
                    provider = provider,
                    isFavorite = code.id in uiState.userPreferences.favoriteCodeIds,
                    onToggleFavorite = { onToggleFavorite(code.id) },
                    onCopy = { DialAndClipboardHelper.copyToClipboard(context, code.serviceNameAr, code.ussdCode) },
                    onOpenSource = {
                        if (code.officialSourceUrl.isNotBlank()) {
                            DialAndClipboardHelper.openWebUrl(context, code.officialSourceUrl)
                        }
                    },
                    onAction = {
                        onRequestDial(
                            DialRequest(
                                title = code.serviceNameAr,
                                codeOrUrl = code.ussdCode,
                                providerId = code.providerId,
                                providerNameAr = code.providerNameAr,
                                supportedSimType = code.supportedSimType,
                                verificationStatus = code.verificationStatus,
                                isWebPortal = !code.isDialableUssd
                            )
                        )
                    }
                )
            }
        }
    }

    if (showDualSimDialog) {
        DualSimSettingsDialog(
            providers = uiState.activeProviders,
            currentPrefs = uiState.userPreferences,
            onDismiss = { showDualSimDialog = false },
            onSave = { p1, l1, p2, l2 ->
                onSaveSimSettings(p1, l1, p2, l2)
                showDualSimDialog = false
            }
        )
    }
}

@Composable
private fun DetailedUssdCodeCard(
    code: UssdCodeEntry,
    provider: TelecomProvider?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onOpenSource: () -> Unit,
    onAction: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val accent = parseHexColor(provider?.accentColorHex ?: "#0B4F6C")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ProviderLogoBadge(provider = provider, size = 38.dp)
                    Column {
                        Text(text = code.serviceNameAr, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${code.providerNameAr} • ${code.categoryEnum.labelAr}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(48.dp)) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "مفضلة",
                        tint = if (isFavorite) Color(0xFFE09F00) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                UssdCodePill(code = code.ussdCode, accentColor = accent, onClick = onAction)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    VerificationBadge(status = code.verificationStatus)
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "التفاصيل"
                    )
                }
            }

            Text(
                text = code.descriptionAr,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    MetaRow(label = "طريقة الاستخدام:", value = code.usageStepsAr)
                    MetaRow(label = "نوع الشريحة المدعومة:", value = code.simTypeEnum.labelAr)
                    MetaRow(label = "المدخلات المطلوبة:", value = code.inputRequirementEnum.labelAr)
                    MetaRow(label = "تاريخ آخر تحقق:", value = code.lastVerifiedDate)
                    if (code.officialSourceUrl.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "المصدر الرسمي: ${code.officialSourceUrl}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = onOpenSource) {
                                Icon(Icons.Outlined.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("زيارة")
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCopy,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.action_copy_code))
                }
                Button(
                    onClick = onAction,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Icon(
                        imageVector = if (code.isDialableUssd) Icons.Filled.Call else Icons.Outlined.OpenInBrowser,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (code.isDialableUssd) stringResource(R.string.action_dial_safe) else "فتح البوابة",
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
