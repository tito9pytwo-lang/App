package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppThemeMode
import com.example.data.model.CodeCategory
import com.example.data.model.TelecomProvider
import com.example.data.model.UssdCodeEntry
import com.example.ui.components.DialRequest
import com.example.ui.components.OfflineDatabaseBanner
import com.example.ui.components.ProviderLogoBadge
import com.example.ui.components.UssdCodePill
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.parseHexColor
import com.example.ui.viewmodel.DirectoryUiState
import com.example.util.DialAndClipboardHelper

private data class QuickShortcutItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tintColor: Color,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    uiState: DirectoryUiState,
    onSearchChange: (String) -> Unit,
    onNavigateToTopUp: (String?) -> Unit,
    onNavigateToPackages: (String?) -> Unit,
    onNavigateToDataSims: () -> Unit,
    onNavigateToCodesCategory: (String?, CodeCategory?) -> Unit,
    onToggleTheme: (AppThemeMode) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onRequestDial: (DialRequest) -> Unit
) {
    val context = LocalContext.current
    val nextTheme = when (uiState.userPreferences.themeModeEnum) {
        AppThemeMode.SYSTEM -> AppThemeMode.DARK
        AppThemeMode.DARK -> AppThemeMode.LIGHT
        AppThemeMode.LIGHT -> AppThemeMode.SYSTEM
    }

    val shortcuts = listOf(
        QuickShortcutItem(
            title = "معرفة الرصيد",
            subtitle = "رصيد الهاتف والإنترنت",
            icon = Icons.Filled.AccountBalanceWallet,
            tintColor = Color(0xFF0B4F6C),
            onClick = { onNavigateToCodesCategory(null, CodeCategory.BALANCE) }
        ),
        QuickShortcutItem(
            title = "تعبئة الرصيد",
            subtitle = "مولد كود الشحن السريع",
            icon = Icons.Filled.AddCard,
            tintColor = Color(0xFF008751),
            onClick = { onNavigateToTopUp(null) }
        ),
        QuickShortcutItem(
            title = "باقات الإنترنت",
            subtitle = "استعراض ومقارنة الباقات",
            icon = Icons.Filled.Wifi,
            tintColor = Color(0xFFA31D6B),
            onClick = { onNavigateToPackages(null) }
        ),
        QuickShortcutItem(
            title = "تجديد الاشتراكات",
            subtitle = "إدارة وتفعيل الخطوط",
            icon = Icons.Filled.Autorenew,
            tintColor = Color(0xFF0062AD),
            onClick = { onNavigateToCodesCategory(null, CodeCategory.RENEW) }
        ),
        QuickShortcutItem(
            title = "أكواد الخدمات",
            subtitle = "كل الأكواد الموثقة",
            icon = Icons.Filled.Dialpad,
            tintColor = Color(0xFF5B4B8A),
            onClick = { onNavigateToCodesCategory(null, null) }
        ),
        QuickShortcutItem(
            title = "شرائح الإنترنت والمودم",
            subtitle = "Net+ و LTT وراوتر",
            icon = Icons.Filled.Router,
            tintColor = Color(0xFF1E6B7B),
            onClick = onNavigateToDataSims
        ),
        QuickShortcutItem(
            title = "الخدمات الإضافية",
            subtitle = "سلفني، 4G، كروت تالفة",
            icon = Icons.Filled.Extension,
            tintColor = Color(0xFF8C5A00),
            onClick = { onNavigateToCodesCategory(null, CodeCategory.EXTRA) }
        )
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = stringResource(R.string.app_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = { onToggleTheme(nextTheme) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("theme_toggle_button")
                ) {
                    Icon(
                        imageVector = if (uiState.userPreferences.themeModeEnum == AppThemeMode.DARK) {
                            Icons.Filled.LightMode
                        } else {
                            Icons.Filled.DarkMode
                        },
                        contentDescription = "تبديل الوضع الليلي والنهاري",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        item {
            OfflineDatabaseBanner()
        }

        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_field"),
                placeholder = { Text(stringResource(R.string.search_placeholder)) },
                leadingIcon = {
                    Icon(Icons.Filled.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Filled.Clear, contentDescription = "مسح البحث")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        if (uiState.searchQuery.isNotBlank()) {
            val matchingCodes = uiState.filteredCodes
            val matchingPackages = uiState.filteredSearchPackages

            item {
                Text(
                    text = "نتائج البحث (${matchingCodes.size} كود • ${matchingPackages.size} باقة)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (matchingCodes.isEmpty() && matchingPackages.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(
                            text = "لم يتم العثور على أكواد أو باقات مطابقة لـ \"${uiState.searchQuery}\". جرب البحث باسم الشركة أو رقم الكود.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(matchingCodes, key = { "search_code_${it.id}" }) { code ->
                    val provider = uiState.providers.firstOrNull { it.id == code.providerId }
                    CodeQuickCard(
                        code = code,
                        provider = provider,
                        isFavorite = code.id in uiState.userPreferences.favoriteCodeIds,
                        onToggleFavorite = { onToggleFavorite(code.id) },
                        onCopy = { DialAndClipboardHelper.copyToClipboard(context, code.serviceNameAr, code.ussdCode) },
                        onAction = {
                            onRequestDial(
                                DialRequest(
                                    title = code.serviceNameAr,
                                    codeOrUrl = code.ussdCode,
                                    providerId = code.providerId,
                                    providerNameAr = code.providerNameAr,
                                    supportedSimType = code.supportedSimType,
                                    verificationStatus = code.verificationStatus,
                                    isWebPortal = !code.isDialableUssd
                                )
                            )
                        }
                    )
                }

                items(matchingPackages, key = { "search_pkg_${it.id}" }) { pkg ->
                    val pkgProvider = uiState.providers.firstOrNull { it.id == pkg.providerId }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToPackages(pkg.providerId) },
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProviderLogoBadge(provider = pkgProvider, size = 36.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${pkg.providerNameAr} • ${pkg.packageNameAr}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "${pkg.dataDisplayAr} • ${pkg.priceLyd.toInt()} د.ل • ${pkg.validityDays} يوم",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            UssdCodePill(code = pkg.activationCode)
                        }
                    }
                }
            }
        } else {
            // Supported Companies Carousel
            item {
                Text(
                    text = "الشركات ومزودو الخدمة في ليبيا",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.activeProviders, key = { it.id }) { provider ->
                        OperatorBrandCard(
                            provider = provider,
                            onCodesClick = { onNavigateToCodesCategory(provider.id, null) },
                            onPackagesClick = {
                                if (provider.id == "data_modem") {
                                    onNavigateToDataSims()
                                } else {
                                    onNavigateToPackages(provider.id)
                                }
                            }
                        )
                    }
                }
            }

            // Quick Actions 7-Section Grid (2 columns)
            item {
                Text(
                    text = "الوصول السريع للخدمات",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            items(shortcuts.chunked(2)) { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { item ->
                        QuickActionTile(
                            item = item,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // Favorite or Essential Verified Codes
            val highlightedCodes = rememberHighlightedCodes(uiState)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (uiState.userPreferences.favoriteCodeIds.isNotEmpty()) {
                            "أكوادك المفضلة"
                        } else {
                            "أبرز الأكواد الرسمية الموثقة"
                        },
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "عرض الكل",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onNavigateToCodesCategory(null, null) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            items(highlightedCodes, key = { "home_code_${it.id}" }) { code ->
                val provider = uiState.providers.firstOrNull { it.id == code.providerId }
                CodeQuickCard(
                    code = code,
                    provider = provider,
                    isFavorite = code.id in uiState.userPreferences.favoriteCodeIds,
                    onToggleFavorite = { onToggleFavorite(code.id) },
                    onCopy = { DialAndClipboardHelper.copyToClipboard(context, code.serviceNameAr, code.ussdCode) },
                    onAction = {
                        onRequestDial(
                            DialRequest(
                                title = code.serviceNameAr,
                                codeOrUrl = code.ussdCode,
                                providerId = code.providerId,
                                providerNameAr = code.providerNameAr,
                                supportedSimType = code.supportedSimType,
                                verificationStatus = code.verificationStatus,
                                isWebPortal = !code.isDialableUssd
                            )
                        )
                    }
                )
            }
        }
    }
}

private fun rememberHighlightedCodes(uiState: DirectoryUiState): List<UssdCodeEntry> {
    val favIds = uiState.userPreferences.favoriteCodeIds
    if (favIds.isNotEmpty()) {
        val favs = uiState.ussdCodes.filter { it.id in favIds }
        if (favs.isNotEmpty()) return favs
    }
    return uiState.ussdCodes.take(5)
}

@Composable
private fun OperatorBrandCard(
    provider: TelecomProvider,
    onCodesClick: () -> Unit,
    onPackagesClick: () -> Unit
) {
    val accent = parseHexColor(provider.accentColorHex)
    Card(
        modifier = Modifier
            .width(210.dp)
            .clickable(onClick = onCodesClick)
            .testTag("provider_card_${provider.id}"),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(accent.copy(alpha = 0.12f), Color.Transparent)
                    )
                )
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(accent)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProviderLogoBadge(provider = provider, size = 50.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = provider.nameAr,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = provider.nameEn,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }

            Text(
                text = provider.descriptionAr,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(onClick = onCodesClick),
                    shape = RoundedCornerShape(10.dp),
                    color = accent.copy(alpha = 0.14f)
                ) {
                    Text(
                        text = "الأكواد",
                        style = MaterialTheme.typography.labelMedium,
                        color = accent,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                    )
                }
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(onClick = onPackagesClick),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = if (provider.id == "data_modem") "المودم" else "الباقات",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionTile(
    item: QuickShortcutItem,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable(onClick = item.onClick)
            .testTag("quick_action_${item.title}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(item.tintColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    tint = item.tintColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun CodeQuickCard(
    code: UssdCodeEntry,
    provider: TelecomProvider?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onAction: () -> Unit
) {
    val accent = parseHexColor(provider?.accentColorHex ?: "#0B4F6C")
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onAction),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ProviderLogoBadge(provider = provider, size = 36.dp)
                    Column {
                        Text(
                            text = code.serviceNameAr,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${code.providerNameAr} • ${code.categoryEnum.labelAr}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "تفضيل الكود",
                        tint = if (isFavorite) Color(0xFFE09F00) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = code.descriptionAr,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                UssdCodePill(
                    code = code.ussdCode,
                    accentColor = accent,
                    onClick = onAction
                )
                VerificationBadge(status = code.verificationStatus)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "آخر تحقق: ${code.lastVerifiedDate}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCopy,
                        contentDescription = stringResource(R.string.action_copy_code),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onAction),
                    color = accent
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (code.isDialableUssd) "اتصال" else "فتح",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
