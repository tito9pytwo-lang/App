package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProductEntity
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.theme.PosRedDelete
import com.example.ui.util.NumberUtils

@Composable
fun AssignShortcutDialog(
    products: List<ProductEntity>,
    initialTargetProduct: ProductEntity?,
    initialCode: String?,
    onSaveShortcut: (productId: Long, shortcutCode: String?) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedProduct by remember { mutableStateOf(initialTargetProduct) }
    var shortcutCodeText by remember {
        mutableStateOf(initialTargetProduct?.shortcutCode ?: initialCode ?: "")
    }
    var productSearchQuery by remember { mutableStateOf("") }

    val filteredProducts = remember(products, productSearchQuery) {
        if (productSearchQuery.isBlank()) products
        else products.filter {
            it.name.contains(productSearchQuery, ignoreCase = true) ||
                    (it.shortcutCode != null && it.shortcutCode.contains(productSearchQuery))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dialpad,
                            contentDescription = null,
                            tint = PosBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "تخصيص كود اختصار سريع من لوحة الأرقام",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = PosBluePrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Text(
                    text = "عيّن رقم اختصار مخصص (مثل: 0 للبيض) لإضافته فور كتابة الرقم من لوحة المفاتيح والضغط على تطبيق.",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )

                // Shortcut Code Input Field
                OutlinedTextField(
                    value = shortcutCodeText,
                    onValueChange = { shortcutCodeText = it },
                    label = { Text("رقم الاختصار (مثال: 0) *") },
                    placeholder = { Text("اكتب رقم الاختصار...") },
                    leadingIcon = {
                        Icon(Icons.Default.Dialpad, contentDescription = null, tint = PosBluePrimary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_shortcut_code"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                // Selected Product Preview
                if (selectedProduct != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(selectedProduct!!.iconEmoji, fontSize = 24.sp)
                                Column {
                                    Text(
                                        text = selectedProduct!!.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "السعر: ${NumberUtils.formatNumber(selectedProduct!!.price)}",
                                        fontSize = 12.sp,
                                        color = PosBluePrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Text(
                                text = "تغيير",
                                color = PosBluePrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { selectedProduct = null }
                                    .padding(4.dp)
                            )
                        }
                    }
                } else {
                    // Pick a product from the list
                    Text(
                        text = "اختر الصنف المراد ربطه بهذا الاختصار:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = productSearchQuery,
                        onValueChange = { productSearchQuery = it },
                        placeholder = { Text("ابحث عن صنف (بيض، خبز...)...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredProducts, key = { it.id }) { prod ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                                    .clickable { selectedProduct = prod }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(prod.iconEmoji, fontSize = 18.sp)
                                    Column {
                                        Text(prod.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text("السعر: ${NumberUtils.formatNumber(prod.price)}", fontSize = 11.sp, color = PosGreenCashLight)
                                    }
                                }

                                if (!prod.shortcutCode.isNullOrBlank()) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFE0F2FE), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("اختصار: ${prod.shortcutCode}", fontSize = 11.sp, color = PosBluePrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Actions: Save or Remove Shortcut
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (selectedProduct != null && !selectedProduct!!.shortcutCode.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = {
                                onSaveShortcut(selectedProduct!!.id, null)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PosRedDelete),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف الاختصار")
                        }
                    }

                    Button(
                        onClick = {
                            selectedProduct?.let {
                                onSaveShortcut(it.id, shortcutCodeText.trim())
                            }
                        },
                        enabled = selectedProduct != null && shortcutCodeText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = PosGreenCashLight),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("btn_save_shortcut")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ وتعيين الاختصار", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
