package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProductEntity
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight

@Composable
fun PosAddProductDialog(
    initialBarcode: String? = null,
    onSaveProduct: (ProductEntity, addToCart: Boolean) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf(initialBarcode ?: "") }
    var shortcutCode by remember { mutableStateOf(if (initialBarcode != null && initialBarcode.length <= 4) initialBarcode else "") }
    var priceText by remember { mutableStateOf("") }
    var costPriceText by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("قطعة") } // قطعة أو كجم
    var isShortcut by remember { mutableStateOf(true) }
    var selectedEmoji by remember { mutableStateOf("📦") }
    var selectedCategory by remember { mutableStateOf("عام") }
    var addToCartImmediately by remember { mutableStateOf(true) }

    val emojis = listOf("📦", "🥤", "🍬", "🍞", "🥚", "🥬", "🍎", "🍌", "🥛", "🍫", "🧀", "🧃", "🥔", "🐟", "🍾", "🍚", "☕", "🧴")
    val units = listOf("قطعة", "كجم", "لتر", "علبة")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (initialBarcode != null) "تسجيل منتج غير مسجل" else "إضافة منتج جديد",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PosBluePrimary
                        )
                        if (initialBarcode != null) {
                            Text(
                                text = "الكود المدخل: $initialBarcode",
                                fontSize = 12.sp,
                                color = Color(0xFFE65100),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Name field
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الصنف / المنتج *") },
                    placeholder = { Text("مثال: بيض، بيبسي، طماطم...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_product_name"),
                    singleLine = true
                )

                // Shortcut Number & Barcode in one row or stacked
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Shortcut Code (مثل: 0 للبيض)
                    OutlinedTextField(
                        value = shortcutCode,
                        onValueChange = { shortcutCode = it },
                        label = { Text("رقم الاختصار (مثل: 0)") },
                        placeholder = { Text("0") },
                        leadingIcon = {
                            Icon(Icons.Default.Dialpad, contentDescription = null, tint = PosBluePrimary)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_product_shortcut_code"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    // Barcode field
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("الباركود (اختياري)") },
                        placeholder = { Text("باركود...") },
                        leadingIcon = {
                            Icon(Icons.Default.QrCode, contentDescription = null, tint = Color(0xFF64748B))
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("input_product_barcode"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                // Price and Cost Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("سعر البيع (ر.س) *") },
                        placeholder = { Text("0.00") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_product_price"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )

                    OutlinedTextField(
                        value = costPriceText,
                        onValueChange = { costPriceText = it },
                        label = { Text("سعر التكلفة") },
                        placeholder = { Text("0.00") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }

                // Unit selection (قطعة أو بالوزن كجم)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("نوع البيع:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    units.forEach { u ->
                        FilterChip(
                            selected = unit == u,
                            onClick = { unit = u },
                            label = { Text(u) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PosBluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Emoji picker for shortcut button
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("أيقونة الصنف (رمز تعبيري):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(emojis) { emoji ->
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selectedEmoji == emoji) Color(0xFFBBDEFB) else Color(0xFFF1F5F9))
                                    .border(
                                        1.dp,
                                        if (selectedEmoji == emoji) PosBluePrimary else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedEmoji = emoji },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(emoji, fontSize = 20.sp)
                            }
                        }
                    }
                }

                // Checkbox: Add to current cart immediately?
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { addToCartImmediately = !addToCartImmediately },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = addToCartImmediately,
                        onCheckedChange = { addToCartImmediately = it }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إضافة هذا المنتج إلى الفاتورة الحالية فوراً",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PosBluePrimary
                    )
                }

                // Action Button
                val priceVal = priceText.toDoubleOrNull() ?: 0.0
                val isValid = name.isNotBlank() && priceVal > 0

                Button(
                    onClick = {
                        val product = ProductEntity(
                            name = name.trim(),
                            barcode = barcode.trim().ifEmpty { null },
                            shortcutCode = shortcutCode.trim().ifEmpty { null },
                            price = priceVal,
                            costPrice = costPriceText.toDoubleOrNull() ?: 0.0,
                            unit = unit,
                            isShortcut = isShortcut,
                            iconEmoji = selectedEmoji,
                            category = selectedCategory
                        )
                        onSaveProduct(product, addToCartImmediately)
                    },
                    enabled = isValid,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_save_product"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PosGreenCashLight,
                        disabledContainerColor = Color(0xFFCBD5E1)
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Text(
                            text = if (addToCartImmediately) "حفظ وإضافة إلى الفاتورة" else "حفظ المنتج",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
