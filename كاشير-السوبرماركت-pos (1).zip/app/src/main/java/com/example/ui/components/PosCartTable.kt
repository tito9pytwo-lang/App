package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.CartItem
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.theme.PosRedDelete
import com.example.ui.theme.PosTableRowAlternate
import com.example.ui.theme.PosTableRowSelected
import com.example.ui.util.NumberUtils

@Composable
fun PosCartTable(
    cartItems: List<CartItem>,
    selectedIndex: Int?,
    onSelectItem: (Int) -> Unit,
    onIncrementItem: (Int) -> Unit,
    onDecrementItem: (Int) -> Unit,
    onDeleteItem: (Int) -> Unit,
    onOpenAddProduct: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto-scroll to selected or newly added item
    LaunchedEffect(selectedIndex, cartItems.size) {
        if (selectedIndex != null && selectedIndex in cartItems.indices) {
            listState.animateScrollToItem(selectedIndex)
        } else if (cartItems.isNotEmpty()) {
            listState.animateScrollToItem(cartItems.lastIndex)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .border(1.5.dp, Color(0xFF64B5F6), RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        color = Color.White
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Table Header Bar (Clear and High Contrast)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PosBlueHeader)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ت",
                    modifier = Modifier.width(36.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "الصنف",
                    modifier = Modifier.weight(2.6f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "الكمية",
                    modifier = Modifier.weight(1.3f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "السعر",
                    modifier = Modifier.weight(1.3f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "الإجمالي",
                    modifier = Modifier.weight(1.4f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Table Body
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFFB0BEC5)
                        )
                        Text(
                            text = "لا توجد منتجات ممسوحة حالياً",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF455A64)
                        )
                        Text(
                            text = "امسح الباركود، أو اكتب رقم اختصار الصنف (مثل: 0 للبيض) من لوحة الأرقام",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = onOpenAddProduct,
                            colors = ButtonDefaults.buttonColors(containerColor = PosBluePrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("empty_cart_add_product_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("➕ إضافة منتج جديد إلى المخزن", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(cartItems, key = { _, item -> item.cartItemId }) { index, item ->
                        val isSelected = selectedIndex == index
                        val rowBg = when {
                            isSelected -> PosTableRowSelected
                            index % 2 == 1 -> PosTableRowAlternate
                            else -> Color.White
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .clickable { onSelectItem(index) }
                                .testTag("cart_row_$index")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Index
                                Text(
                                    text = "${index + 1}",
                                    modifier = Modifier.width(36.dp),
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = if (isSelected) PosBluePrimary else Color(0xFF475569),
                                    fontSize = 15.sp,
                                    textAlign = TextAlign.Center
                                )

                                // Product Name
                                Column(modifier = Modifier.weight(2.6f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (item.product.iconEmoji.isNotBlank()) {
                                            Text(
                                                text = item.product.iconEmoji,
                                                fontSize = 18.sp,
                                                modifier = Modifier.padding(end = 6.dp)
                                            )
                                        }
                                        Text(
                                            text = item.product.name,
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF0F172A),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (!item.product.barcode.isNullOrBlank()) {
                                        Text(
                                            text = item.product.barcode,
                                            fontSize = 12.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                // Quantity (Without unnecessary decimals e.g. 100 instead of 100.0)
                                val qtyFormatted = NumberUtils.formatNumber(item.quantity)
                                Text(
                                    text = qtyFormatted,
                                    modifier = Modifier.weight(1.3f),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = PosBluePrimary,
                                    textAlign = TextAlign.Center
                                )

                                // Unit Price (Without currency, and e.g. 3 instead of 3.00)
                                val priceFormatted = NumberUtils.formatNumber(item.unitPrice)
                                Text(
                                    text = priceFormatted,
                                    modifier = Modifier.weight(1.3f),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF334155),
                                    textAlign = TextAlign.Center
                                )

                                // Total (Without currency, and e.g. 300 instead of 300.00)
                                val totalFormatted = NumberUtils.formatNumber(item.totalPrice)
                                Text(
                                    text = totalFormatted,
                                    modifier = Modifier.weight(1.4f),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = Color(0xFF0F172A),
                                    textAlign = TextAlign.Center
                                )
                            }

                            // If row is selected: inline quick tools (+, -, delete)
                            if (isSelected) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFE3F2FD))
                                        .padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "تعديل: ${item.product.name} (اكتب الكمية من الأرقام)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PosBluePrimary
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Minus Button
                                        IconButton(
                                            onClick = { onDecrementItem(index) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .background(Color.White, CircleShape)
                                                .border(1.dp, Color(0xFF90CAF9), CircleShape)
                                                .testTag("inline_decrement_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Remove,
                                                contentDescription = "إنقاص 1",
                                                tint = Color(0xFF1565C0),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        // Plus Button
                                        IconButton(
                                            onClick = { onIncrementItem(index) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .background(PosBluePrimary, CircleShape)
                                                .testTag("inline_increment_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "زيادة 1",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        // Delete Button
                                        IconButton(
                                            onClick = { onDeleteItem(index) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .background(Color(0xFFFFEBEE), CircleShape)
                                                .testTag("inline_delete_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف الصنف",
                                                tint = PosRedDelete,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Divider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                        }
                    }
                }
            }
        }
    }
}
