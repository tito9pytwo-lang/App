package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.PosTab
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary

@Composable
fun PosTopBar(
    manualCodeInput: String,
    onCodeChange: (String) -> Unit,
    onSubmitCode: () -> Unit,
    onOpenScanner: () -> Unit,
    onOpenAddProduct: () -> Unit,
    onSelectTab: (PosTab) -> Unit,
    modifier: Modifier = Modifier
) {
    var isSettingsMenuOpen by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = PosBlueHeader,
        shadowElevation = 2.dp
    ) {
        // Single minimal, clean, high-visibility row as requested
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Settings Button ⚙️ with popup menu
            Box {
                IconButton(
                    onClick = { isSettingsMenuOpen = true },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0x33FFFFFF), CircleShape)
                        .testTag("pos_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات والقوائم",
                        tint = Color.White
                    )
                }

                DropdownMenu(
                    expanded = isSettingsMenuOpen,
                    onDismissRequest = { isSettingsMenuOpen = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("➕ إضافة منتج جديد", fontWeight = FontWeight.Bold) },
                        onClick = {
                            isSettingsMenuOpen = false
                            onOpenAddProduct()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("📦 إدارة المنتجات والأصناف") },
                        onClick = {
                            isSettingsMenuOpen = false
                            onSelectTab(PosTab.PRODUCTS)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("📜 سجل المبيعات والفواتير") },
                        onClick = {
                            isSettingsMenuOpen = false
                            onSelectTab(PosTab.SALES)
                        }
                    )
                }
            }

            // Spacious Search / Barcode input field
            OutlinedTextField(
                value = manualCodeInput,
                onValueChange = onCodeChange,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("barcode_input_field"),
                placeholder = {
                    Text(
                        text = "بحث بالاسم أو مسح كود الصنف...",
                        color = Color(0xFFB0BEC5),
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = Color(0xFF90CAF9)
                    )
                },
                trailingIcon = {
                    if (manualCodeInput.isNotEmpty()) {
                        IconButton(onClick = { onCodeChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "مسح الإدخال",
                                tint = Color.White
                            )
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(
                    onSearch = { onSubmitCode() }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1E3A8A),
                    unfocusedContainerColor = Color(0xFF172554),
                    focusedBorderColor = Color(0xFF60A5FA),
                    unfocusedBorderColor = Color(0xFF3B82F6),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp)
            )

            // Submit Button
            androidx.compose.material3.Button(
                onClick = onSubmitCode,
                modifier = Modifier
                    .height(50.dp)
                    .testTag("submit_barcode_button"),
                shape = RoundedCornerShape(8.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = PosBluePrimary
                )
            ) {
                Text("إدخال", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            // Camera Barcode Scanner Button
            IconButton(
                onClick = onOpenScanner,
                modifier = Modifier
                    .size(50.dp)
                    .background(Color(0xFF2E7D32), RoundedCornerShape(8.dp))
                    .testTag("open_scanner_button")
            ) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = "مسح باركود بالكاميرا",
                    tint = Color.White
                )
            }
        }
    }
}
