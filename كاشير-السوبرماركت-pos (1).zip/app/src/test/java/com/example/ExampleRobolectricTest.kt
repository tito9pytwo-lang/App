package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ProductEntity
import com.example.ui.model.CartItem
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("كاشير السوبرماركت POS", appName)
    }

    @Test
    fun `cart item calculation is accurate`() {
        val pepsi = ProductEntity(
            name = "بيبسي بارد",
            barcode = "6281001100123",
            price = 2.00,
            unit = "قطعة"
        )
        val cartItem = CartItem(
            product = pepsi,
            quantity = 3.0,
            unitPrice = 2.00
        )
        assertEquals(6.00, cartItem.totalPrice, 0.001)
    }

    @Test
    fun `custom shortcut code assignment works`() {
        val eggs = ProductEntity(
            name = "طبق بيض طازج",
            shortcutCode = "0",
            price = 18.00,
            unit = "قطعة"
        )
        assertEquals("0", eggs.shortcutCode)
        assertEquals(18.00, eggs.price, 0.001)
    }
}
