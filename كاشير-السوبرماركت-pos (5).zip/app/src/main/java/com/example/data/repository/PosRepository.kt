package com.example.data.repository

import com.example.data.InitialData
import com.example.data.dao.ProductDao
import com.example.data.dao.SaleDao
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PosRepository(
    private val productDao: ProductDao,
    private val saleDao: SaleDao
) {
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val shortcutProducts: Flow<List<ProductEntity>> = productDao.getShortcutProducts()
    val allInvoices: Flow<List<InvoiceWithItems>> = saleDao.getAllInvoicesWithItems()
    val totalInvoiceCount: Flow<Int> = saleDao.getTotalInvoiceCount()
    val totalSalesAmount: Flow<Double> = saleDao.getTotalSalesAmount()

    suspend fun checkAndSeedInitialData() = withContext(Dispatchers.IO) {
        if (productDao.getProductCount() == 0) {
            productDao.insertProducts(InitialData.sampleProducts)
        }
    }

    suspend fun findProductByBarcode(barcode: String): ProductEntity? = withContext(Dispatchers.IO) {
        val cleanBarcode = barcode.trim()
        productDao.getProductByBarcode(cleanBarcode)
    }

    suspend fun findProductByCodeOrShortcut(code: String): ProductEntity? = withContext(Dispatchers.IO) {
        val cleanCode = code.trim()
        if (cleanCode.isEmpty()) return@withContext null
        // 1. Look up by shortcut code or barcode
        val directMatch = productDao.getProductByBarcodeOrShortcut(cleanCode)
        if (directMatch != null) return@withContext directMatch

        // 2. Check if ID matches
        val idLong = cleanCode.toLongOrNull()
        if (idLong != null) {
            val byId = productDao.getProductById(idLong)
            if (byId != null) return@withContext byId
        }

        null
    }

    suspend fun findProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return productDao.searchProducts(query)
    }

    suspend fun saveProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        if (product.id == 0L) {
            productDao.insertProduct(product)
        } else {
            productDao.updateProduct(product)
            product.id
        }
    }

    suspend fun updateShortcutCode(productId: Long, shortcutCode: String?) = withContext(Dispatchers.IO) {
        productDao.updateShortcutCode(productId, shortcutCode?.trim()?.ifEmpty { null })
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(product)
    }

    suspend fun completeSale(
        invoice: SaleInvoiceEntity,
        items: List<SaleItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        val invoiceId = saleDao.insertInvoice(invoice)
        val itemsWithInvoiceId = items.map { it.copy(invoiceId = invoiceId) }
        saleDao.insertSaleItems(itemsWithInvoiceId)
        invoiceId
    }

    suspend fun getInvoiceDetails(invoiceId: Long): InvoiceWithItems? = withContext(Dispatchers.IO) {
        saleDao.getInvoiceWithItemsById(invoiceId)
    }

    suspend fun getAllProductsList(): List<ProductEntity> = withContext(Dispatchers.IO) {
        productDao.getAllProductsList()
    }

    suspend fun getAllInvoicesWithItemsList(): List<InvoiceWithItems> = withContext(Dispatchers.IO) {
        saleDao.getAllInvoicesWithItemsList()
    }

    suspend fun importBackup(
        products: List<ProductEntity>,
        invoices: List<Pair<SaleInvoiceEntity, List<SaleItemEntity>>>
    ): com.example.data.backup.BackupImportResult = withContext(Dispatchers.IO) {
        try {
            if (products.isNotEmpty()) {
                productDao.insertProducts(products)
            }
            for ((inv, items) in invoices) {
                val newInvoiceId = saleDao.insertInvoice(inv)
                val mappedItems = items.map { it.copy(invoiceId = newInvoiceId) }
                saleDao.insertSaleItems(mappedItems)
            }
            com.example.data.backup.BackupImportResult(
                productsImported = products.size,
                invoicesImported = invoices.size,
                errorMessage = null
            )
        } catch (e: Exception) {
            com.example.data.backup.BackupImportResult(
                productsImported = 0,
                invoicesImported = 0,
                errorMessage = e.localizedMessage ?: "حدث خطأ أثناء استيراد البيانات"
            )
        }
    }
}
