package com.example.ui.util

import com.example.data.model.ProductEntity

object BarcodeMatcher {

    /**
     * Extracts only digit characters from a string (e.g. "628-1001" -> "6281001").
     */
    fun extractDigits(input: String?): String {
        if (input.isNullOrBlank()) return ""
        return input.filter { it.isDigit() }
    }

    /**
     * Normalizes digits by removing leading zeros.
     * If the string contains only zeros, returns "0".
     */
    fun normalizeDigits(input: String?): String {
        val digits = extractDigits(input)
        if (digits.isEmpty()) return ""
        val trimmed = digits.trimStart('0')
        return if (trimmed.isEmpty()) "0" else trimmed
    }

    /**
     * Checks if a scanned or entered code matches a product's barcode or shortcut code.
     * Uses multiple matching strategies:
     * 1. Exact string match (case-insensitive, trimmed)
     * 2. Pure digits match (ignoring dashes, spaces, slashes)
     * 3. Leading-zero agnostic match (e.g. 06281001 == 6281001)
     * 4. UPC-A (12 digits) to EAN-13 (13 digits with leading zero)
     * 5. Core numeric sequence match (for barcodes with check-digits or prefixes)
     */
    fun isMatch(scannedCode: String, product: ProductEntity): Boolean {
        val rawScanned = scannedCode.trim()
        if (rawScanned.isEmpty()) return false

        val prodBarcode = product.barcode?.trim() ?: ""
        val prodShortcut = product.shortcutCode?.trim() ?: ""

        // 1. Direct exact string match
        if (prodBarcode.isNotEmpty() && prodBarcode.equals(rawScanned, ignoreCase = true)) return true
        if (prodShortcut.isNotEmpty() && prodShortcut.equals(rawScanned, ignoreCase = true)) return true

        // 2. Pure digits match
        val scannedDigits = extractDigits(rawScanned)
        val barcodeDigits = extractDigits(prodBarcode)
        val shortcutDigits = extractDigits(prodShortcut)

        if (scannedDigits.isNotEmpty()) {
            if (barcodeDigits.isNotEmpty() && scannedDigits == barcodeDigits) return true
            if (shortcutDigits.isNotEmpty() && scannedDigits == shortcutDigits) return true

            // 3. Leading-zero agnostic match (e.g., 0012345 == 12345)
            val scannedNorm = normalizeDigits(scannedDigits)
            val barcodeNorm = normalizeDigits(barcodeDigits)
            val shortcutNorm = normalizeDigits(shortcutDigits)

            if (barcodeNorm.isNotEmpty() && scannedNorm == barcodeNorm) return true
            if (shortcutNorm.isNotEmpty() && scannedNorm == shortcutNorm) return true

            // 4. UPC-A vs EAN-13 compatibility:
            // Scanned might be EAN-13 (13 digits starting with 0), product is UPC-A (12 digits)
            if (scannedDigits.length == 13 && scannedDigits.startsWith("0") && barcodeDigits.length == 12) {
                if (scannedDigits.substring(1) == barcodeDigits) return true
            }
            // Scanned is UPC-A (12 digits), product is EAN-13 (13 digits starting with 0)
            if (barcodeDigits.length == 13 && barcodeDigits.startsWith("0") && scannedDigits.length == 12) {
                if (barcodeDigits.substring(1) == scannedDigits) return true
            }

            // 5. Core substring matching for long barcodes (>= 7 digits)
            // Some scanners include packaging/check digits at the start/end
            if (scannedNorm.length >= 7 && barcodeNorm.length >= 7) {
                if (scannedNorm.contains(barcodeNorm) || barcodeNorm.contains(scannedNorm)) {
                    return true
                }
            }
        }

        return false
    }

    /**
     * Finds the best matching product from a list of products.
     * Evaluates in priority order:
     * 1. Exact match
     * 2. Pure digits match
     * 3. Leading-zero normalized match
     * 4. UPC/EAN standard compatibility
     * 5. Core substring match
     */
    fun findMatch(scannedCode: String, products: List<ProductEntity>): ProductEntity? {
        val rawScanned = scannedCode.trim()
        if (rawScanned.isEmpty()) return null

        // Priority 1: Exact matches
        val exact = products.firstOrNull { prod ->
            val b = prod.barcode?.trim() ?: ""
            val s = prod.shortcutCode?.trim() ?: ""
            b.equals(rawScanned, ignoreCase = true) || s.equals(rawScanned, ignoreCase = true)
        }
        if (exact != null) return exact

        // Priority 2: Pure digits match
        val scannedDigits = extractDigits(rawScanned)
        if (scannedDigits.isNotEmpty()) {
            val digitsMatch = products.firstOrNull { prod ->
                extractDigits(prod.barcode) == scannedDigits || extractDigits(prod.shortcutCode) == scannedDigits
            }
            if (digitsMatch != null) return digitsMatch

            // Priority 3: Leading-zero normalized match
            val scannedNorm = normalizeDigits(scannedDigits)
            val normMatch = products.firstOrNull { prod ->
                normalizeDigits(prod.barcode) == scannedNorm || normalizeDigits(prod.shortcutCode) == scannedNorm
            }
            if (normMatch != null) return normMatch

            // Priority 4: UPC-A (12) vs EAN-13 (13)
            val upcMatch = products.firstOrNull { prod ->
                val bDigits = extractDigits(prod.barcode)
                (scannedDigits.length == 13 && scannedDigits.startsWith("0") && scannedDigits.substring(1) == bDigits) ||
                        (bDigits.length == 13 && bDigits.startsWith("0") && bDigits.substring(1) == scannedDigits)
            }
            if (upcMatch != null) return upcMatch

            // Priority 5: Core sequence match
            if (scannedNorm.length >= 7) {
                val coreMatch = products.firstOrNull { prod ->
                    val bNorm = normalizeDigits(prod.barcode)
                    bNorm.length >= 7 && (scannedNorm.contains(bNorm) || bNorm.contains(scannedNorm))
                }
                if (coreMatch != null) return coreMatch
            }
        }

        return null
    }

    /**
     * Generates a list of likely barcode query variations for fast SQL lookup.
     */
    fun getCandidateQueries(code: String): List<String> {
        val candidates = linkedSetOf<String>()
        val trimmed = code.trim()
        if (trimmed.isEmpty()) return emptyList()

        candidates.add(trimmed)

        val digits = extractDigits(trimmed)
        if (digits.isNotEmpty()) {
            candidates.add(digits)

            val norm = normalizeDigits(digits)
            if (norm.isNotEmpty()) {
                candidates.add(norm)
                // Add single leading zero variant (UPC-A to EAN-13)
                if (!digits.startsWith("0")) {
                    candidates.add("0$digits")
                }
            }
        }

        return candidates.toList()
    }
}
