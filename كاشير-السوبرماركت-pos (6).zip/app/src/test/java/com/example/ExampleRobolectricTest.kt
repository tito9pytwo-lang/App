package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.backup.PosBackupManager
import com.example.data.model.ProductEntity
import com.example.ui.model.CartItem
import com.example.ui.util.BarcodeMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("كاشير السوبرماركت POS", appName)
    }

    @Test
    fun `cart item calculation is accurate`() {
        val pepsi = ProductEntity(
            name = "بيبسي بارد",
            barcode = "6281001100123",
            price = 2.00,
            unit = "قطعة"
        )
        val cartItem = CartItem(
            product = pepsi,
            quantity = 3.0,
            unitPrice = 2.00
        )
        assertEquals(6.00, cartItem.totalPrice, 0.001)
    }

    @Test
    fun `custom shortcut code assignment works`() {
        val eggs = ProductEntity(
            name = "طبق بيض طازج",
            shortcutCode = "0",
            price = 18.00,
            unit = "قطعة"
        )
        assertEquals("0", eggs.shortcutCode)
        assertEquals(18.00, eggs.price, 0.001)
    }

    @Test
    fun `barcode matcher matches leading zero variations`() {
        val product = ProductEntity(
            name = "حليب نادك",
            barcode = "6281001100123",
            price = 5.0,
            unit = "حبة"
        )

        // 1. Scanned with leading zero
        assertTrue(BarcodeMatcher.isMatch("06281001100123", product))
        // 2. Scanned with multiple leading zeros
        assertTrue(BarcodeMatcher.isMatch("006281001100123", product))
        // 3. Scanned with dashes or spaces
        assertTrue(BarcodeMatcher.isMatch("628-1001-100123", product))
        assertTrue(BarcodeMatcher.isMatch(" 6281001100123 ", product))
    }

    @Test
    fun `barcode matcher matches upc to ean standard`() {
        // UPC-A 12 digits
        val product = ProductEntity(
            name = "شوكولاتة",
            barcode = "012345678905",
            price = 3.5,
            unit = "قطعة"
        )

        // Scanned without the leading zero (11-12 digits) or as 13-digit EAN
        assertTrue(BarcodeMatcher.isMatch("12345678905", product))
        assertTrue(BarcodeMatcher.isMatch("0012345678905", product))
    }

    @Test
    fun `backup and restore json fidelity`() {
        val products = listOf(
            ProductEntity(
                name = "طبق بيض طازج",
                barcode = "6281001",
                shortcutCode = "0",
                price = 18.0,
                unit = "طبق",
                category = "ألبان وبيض",
                iconEmoji = "🥚"
            ),
            ProductEntity(
                name = "خبز صامولي",
                barcode = "6281002",
                shortcutCode = "1",
                price = 1.0,
                unit = "كيس",
                category = "مخبوزات",
                iconEmoji = "🥖"
            )
        )

        val jsonString = PosBackupManager.createBackupJson(products, emptyList())
        assertNotNull(jsonString)

        val (parsedProducts, _) = PosBackupManager.parseBackupJson(jsonString)
        assertEquals(2, parsedProducts.size)
        assertEquals("طبق بيض طازج", parsedProducts[0].name)
        assertEquals("0", parsedProducts[0].shortcutCode)
        assertEquals(18.0, parsedProducts[0].price, 0.001)
        assertEquals("خبز صامولي", parsedProducts[1].name)
        assertEquals("1", parsedProducts[1].shortcutCode)
    }
}
