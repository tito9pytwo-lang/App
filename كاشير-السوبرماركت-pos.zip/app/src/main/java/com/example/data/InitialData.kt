package com.example.data

import com.example.data.model.ProductEntity

object InitialData {
    val sampleProducts = listOf(
        ProductEntity(
            name = "طبق بيض طازج (30 بيضة)",
            barcode = null, // بدون باركود
            shortcutCode = "0", // اختصار رقم 0 من لوحة الأرقام كالمثال المطلوب
            price = 18.00,
            costPrice = 14.00,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🥚",
            category = "ألبان وبيض"
        ),
        ProductEntity(
            name = "خبز صامولي طازج",
            barcode = null, // بدون باركود
            shortcutCode = "1", // اختصار رقم 1
            price = 1.00,
            costPrice = 0.60,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🍞",
            category = "مخبوزات"
        ),
        ProductEntity(
            name = "حلوة جيلي فواكه",
            barcode = "6281001100456",
            shortcutCode = "2", // اختصار رقم 2
            price = 1.50,
            costPrice = 0.90,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🍬",
            category = "حلويات"
        ),
        ProductEntity(
            name = "خضار مشكل طازج",
            barcode = null, // بالوزن
            shortcutCode = "3",
            price = 5.00,
            costPrice = 3.50,
            unit = "كجم",
            isShortcut = true,
            iconEmoji = "🥬",
            category = "خضروات"
        ),
        ProductEntity(
            name = "تفاح أحمر سكري",
            barcode = null, // بالوزن
            shortcutCode = "4",
            price = 7.50,
            costPrice = 5.00,
            unit = "كجم",
            isShortcut = true,
            iconEmoji = "🍎",
            category = "فواكه"
        ),
        ProductEntity(
            name = "موز كافنديش طازج",
            barcode = null, // بالوزن
            shortcutCode = "5",
            price = 6.00,
            costPrice = 4.00,
            unit = "كجم",
            isShortcut = true,
            iconEmoji = "🍌",
            category = "فواكه"
        ),
        ProductEntity(
            name = "مياه نبع طبيعية 600 مل",
            barcode = "6281001100789",
            shortcutCode = "6",
            price = 1.00,
            costPrice = 0.50,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "💧",
            category = "مشروبات"
        ),
        ProductEntity(
            name = "بيبسي بارد 330 مل",
            barcode = "6281001100123",
            shortcutCode = "7",
            price = 2.00,
            costPrice = 1.40,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🥤",
            category = "مشروبات"
        ),
        ProductEntity(
            name = "شوكولاتة فاخرة",
            barcode = "7613035345678",
            shortcutCode = "8",
            price = 3.00,
            costPrice = 2.00,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🍫",
            category = "حلويات"
        ),
        ProductEntity(
            name = "حليب طازج كامل الدسم 1 لتر",
            barcode = "6281007123456",
            shortcutCode = "9",
            price = 4.50,
            costPrice = 3.20,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🥛",
            category = "ألبان وبيض"
        ),
        ProductEntity(
            name = "جبن مثلثات / مربعات",
            barcode = "6281008765432",
            shortcutCode = "10",
            price = 8.50,
            costPrice = 6.00,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🧀",
            category = "ألبان وبيض"
        ),
        ProductEntity(
            name = "عصير مانجو طبيعي",
            barcode = "6281009988776",
            shortcutCode = "11",
            price = 3.50,
            costPrice = 2.40,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🧃",
            category = "مشروبات"
        ),
        ProductEntity(
            name = "بطاطس شيبس مقرمشة",
            barcode = "6281005544332",
            shortcutCode = "12",
            price = 2.50,
            costPrice = 1.70,
            unit = "قطعة",
            isShortcut = true,
            iconEmoji = "🥔",
            category = "تسالي"
        ),
        ProductEntity(
            name = "تونة لحم أبيض بزيت الزيتون",
            barcode = "6281002233445",
            shortcutCode = null,
            price = 6.00,
            costPrice = 4.50,
            unit = "قطعة",
            isShortcut = false,
            iconEmoji = "🐟",
            category = "معلبات"
        ),
        ProductEntity(
            name = "زيت ذرة للطهي 1.5 لتر",
            barcode = "6281006677889",
            shortcutCode = null,
            price = 14.00,
            costPrice = 10.50,
            unit = "قطعة",
            isShortcut = false,
            iconEmoji = "🍾",
            category = "بقالة"
        ),
        ProductEntity(
            name = "أرز بسمتي أبيض 5 كجم",
            barcode = "6281003344556",
            shortcutCode = null,
            price = 32.00,
            costPrice = 25.00,
            unit = "قطعة",
            isShortcut = false,
            iconEmoji = "🍚",
            category = "بقالة"
        )
    )
}
