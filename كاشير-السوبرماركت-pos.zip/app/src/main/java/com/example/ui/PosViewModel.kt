package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.model.InvoiceWithItems
import com.example.data.model.ProductEntity
import com.example.data.model.SaleInvoiceEntity
import com.example.data.model.SaleItemEntity
import com.example.data.repository.PosRepository
import com.example.ui.model.CartItem
import com.example.ui.model.NumPadMode
import com.example.ui.model.PosTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class PosUiState(
    val cartItems: List<CartItem> = emptyList(),
    val selectedCartIndex: Int? = null,
    val numPadBuffer: String = "",
    val numPadMode: NumPadMode = NumPadMode.BARCODE, // Default to code/shortcut mode for fast numeric typing
    val manualCodeInput: String = "",
    val invoiceNumber: String = generateInvoiceNumber(),
    val cashierName: String = "موظف مبيعات 1",
    val isScannerOpen: Boolean = false,
    val isPaymentDialogOpen: Boolean = false,
    val isQuickProductsSheetOpen: Boolean = false,
    val isAddProductDialogOpen: Boolean = false,
    val isAssignShortcutDialogOpen: Boolean = false,
    val shortcutAssignmentTargetProduct: ProductEntity? = null,
    val pendingShortcutCodeToAssign: String? = null,
    val isProductManagementOpen: Boolean = false,
    val isSalesHistoryOpen: Boolean = false,
    val unregisteredBarcode: String? = null,
    val lastCompletedInvoice: InvoiceWithItems? = null,
    val isReceiptDialogOpen: Boolean = false,
    val bannerMessage: String? = null,
    val activeTab: PosTab = PosTab.POS,
    val heldCarts: List<HeldCart> = emptyList()
) {
    val totalAmount: Double
        get() = cartItems.sumOf { it.totalPrice }

    val totalQuantity: Double
        get() = cartItems.sumOf { it.quantity }

    val distinctItemCount: Int
        get() = cartItems.size

    val selectedCartItem: CartItem?
        get() = selectedCartIndex?.let { cartItems.getOrNull(it) }

    companion object {
        fun generateInvoiceNumber(): String {
            val dateStr = SimpleDateFormat("yyMMdd-HHmm", Locale.ENGLISH).format(Date())
            val randomSuffix = (100..999).random()
            return "INV-$dateStr-$randomSuffix"
        }
    }
}

data class HeldCart(
    val id: String = UUID.randomUUID().toString(),
    val invoiceNumber: String,
    val timeFormatted: String,
    val items: List<CartItem>,
    val totalAmount: Double
)

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PosRepository
    private val vibrator: Vibrator?

    private val _uiState = MutableStateFlow(PosUiState())
    val uiState: StateFlow<PosUiState> = _uiState.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = PosRepository(database.productDao(), database.saleDao())

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val shortcutProducts: StateFlow<List<ProductEntity>> = repository.shortcutProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allInvoices: StateFlow<List<InvoiceWithItems>> = repository.allInvoices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val totalSalesAmount: StateFlow<Double> = repository.totalSalesAmount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    val totalInvoiceCount: StateFlow<Int> = repository.totalInvoiceCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    private fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(45)
            }
        } catch (_: Exception) {}
    }

    fun showBanner(message: String) {
        _uiState.update { it.copy(bannerMessage = message) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }

    fun setActiveTab(tab: PosTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun setManualCodeInput(text: String) {
        _uiState.update { it.copy(manualCodeInput = text) }
    }

    /**
     * Add product to cart or increment quantity if already present.
     */
    fun addProductToCart(product: ProductEntity, qtyToAdd: Double = 1.0) {
        triggerHaptic()
        _uiState.update { state ->
            val existingIndex = state.cartItems.indexOfFirst {
                it.product.id == product.id ||
                        (!product.barcode.isNullOrBlank() && it.product.barcode == product.barcode)
            }

            val updatedCart = if (existingIndex >= 0) {
                state.cartItems.mapIndexed { index, item ->
                    if (index == existingIndex) {
                        item.copy(quantity = item.quantity + qtyToAdd)
                    } else {
                        item
                    }
                }
            } else {
                state.cartItems + CartItem(
                    product = product,
                    quantity = qtyToAdd,
                    unitPrice = product.price
                )
            }

            val targetIndex = if (existingIndex >= 0) existingIndex else updatedCart.lastIndex

            state.copy(
                cartItems = updatedCart,
                selectedCartIndex = targetIndex,
                numPadBuffer = "",
                bannerMessage = "تمت إضافة: ${product.name} (السعر: ${String.format(Locale.ENGLISH, "%.2f", product.price)} ر.س) - الكمية: ${updatedCart[targetIndex].quantity}"
            )
        }
    }

    /**
     * Look up by barcode OR custom shortcut code (e.g., "0" for eggs).
     * If found, adds/increments in current cart.
     * If not found, opens prompt to register or assign.
     */
    fun onCodeOrShortcutEntered(code: String) {
        val cleanCode = code.trim()
        if (cleanCode.isBlank()) return

        viewModelScope.launch {
            val product = repository.findProductByCodeOrShortcut(cleanCode)
            if (product != null) {
                addProductToCart(product, 1.0)
            } else {
                triggerHaptic()
                _uiState.update {
                    it.copy(
                        pendingShortcutCodeToAssign = cleanCode,
                        unregisteredBarcode = cleanCode,
                        isAddProductDialogOpen = true,
                        bannerMessage = "الكود أو الاختصار [$cleanCode] غير مسجل"
                    )
                }
            }
        }
    }

    fun onBarcodeScanned(barcode: String) {
        onCodeOrShortcutEntered(barcode)
    }

    fun submitManualCode() {
        val code = _uiState.value.manualCodeInput.trim()
        if (code.isBlank()) return
        _uiState.update { it.copy(manualCodeInput = "") }
        onCodeOrShortcutEntered(code)
    }

    fun selectCartItem(index: Int) {
        _uiState.update {
            it.copy(
                selectedCartIndex = if (it.selectedCartIndex == index) index else index,
                numPadBuffer = ""
            )
        }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedCartIndex = null, numPadBuffer = "") }
    }

    fun incrementSelectedQuantity(amount: Double = 1.0) {
        val index = _uiState.value.selectedCartIndex ?: _uiState.value.cartItems.lastIndex
        if (index in _uiState.value.cartItems.indices) {
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(quantity = item.quantity + amount) else item
                }
                state.copy(cartItems = updated)
            }
        }
    }

    fun decrementSelectedQuantity(amount: Double = 1.0) {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices) {
            triggerHaptic()
            _uiState.update { state ->
                val current = state.cartItems[index]
                if (current.quantity - amount <= 0.0) {
                    val updated = state.cartItems.filterIndexed { idx, _ -> idx != index }
                    val newIndex = if (updated.isEmpty()) null else (index - 1).coerceAtLeast(0)
                    state.copy(
                        cartItems = updated,
                        selectedCartIndex = newIndex,
                        bannerMessage = "تم حذف الصنف: ${current.product.name}"
                    )
                } else {
                    val updated = state.cartItems.mapIndexed { idx, item ->
                        if (idx == index) item.copy(quantity = item.quantity - amount) else item
                    }
                    state.copy(cartItems = updated)
                }
            }
        }
    }

    fun deleteSelectedCartItem() {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices) {
            triggerHaptic()
            _uiState.update { state ->
                val item = state.cartItems[index]
                val updated = state.cartItems.filterIndexed { idx, _ -> idx != index }
                val newIndex = if (updated.isEmpty()) null else (index - 1).coerceAtLeast(0)
                state.copy(
                    cartItems = updated,
                    selectedCartIndex = newIndex,
                    numPadBuffer = "",
                    bannerMessage = "تم حذف: ${item.product.name}"
                )
            }
        }
    }

    fun updateSelectedItemQuantity(newQty: Double) {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices && newQty > 0) {
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(quantity = newQty) else item
                }
                state.copy(cartItems = updated, numPadBuffer = "")
            }
        }
    }

    fun updateSelectedItemPrice(newPrice: Double) {
        val index = _uiState.value.selectedCartIndex ?: return
        if (index in _uiState.value.cartItems.indices && newPrice >= 0) {
            triggerHaptic()
            _uiState.update { state ->
                val updated = state.cartItems.mapIndexed { idx, item ->
                    if (idx == index) item.copy(unitPrice = newPrice) else item
                }
                state.copy(cartItems = updated, numPadBuffer = "")
            }
        }
    }

    // --- Keypad Handlers ---
    fun setNumPadMode(mode: NumPadMode) {
        _uiState.update { it.copy(numPadMode = mode, numPadBuffer = "") }
    }

    fun onNumPadKeyPress(key: String) {
        triggerHaptic()
        val currentBuffer = _uiState.value.numPadBuffer
        when (key) {
            "C" -> {
                _uiState.update { it.copy(numPadBuffer = "") }
            }
            "DEL", "⌫" -> {
                if (currentBuffer.isNotEmpty()) {
                    _uiState.update { it.copy(numPadBuffer = currentBuffer.dropLast(1)) }
                }
            }
            "." -> {
                if (!currentBuffer.contains(".")) {
                    val newBuffer = if (currentBuffer.isEmpty()) "0." else "$currentBuffer."
                    _uiState.update { it.copy(numPadBuffer = newBuffer) }
                }
            }
            "OK", "ENTER" -> {
                applyNumPadBuffer()
            }
            else -> {
                // Digits 0-9
                if (currentBuffer.length < 12) {
                    // Allow leading zero for shortcut codes like "0" or "00"
                    val newBuffer = if (currentBuffer.isEmpty()) key else currentBuffer + key
                    _uiState.update { it.copy(numPadBuffer = newBuffer) }
                }
            }
        }
    }

    fun applyNumPadBuffer() {
        val state = _uiState.value
        val buffer = state.numPadBuffer.trim()
        if (buffer.isEmpty()) return

        when (state.numPadMode) {
            NumPadMode.QUANTITY -> {
                val qty = buffer.toDoubleOrNull()
                if (qty != null && qty > 0) {
                    updateSelectedItemQuantity(qty)
                }
            }
            NumPadMode.PRICE -> {
                val price = buffer.toDoubleOrNull()
                if (price != null && price >= 0) {
                    updateSelectedItemPrice(price)
                }
            }
            NumPadMode.BARCODE -> {
                // User entered a barcode or shortcut code (e.g., "0" for eggs)
                onCodeOrShortcutEntered(buffer)
                _uiState.update { it.copy(numPadBuffer = "") }
            }
            NumPadMode.CASH_PAID -> {
                // Handled in payment dialog directly
            }
        }
    }

    // --- Custom Shortcuts Assignment ---
    fun openAssignShortcutDialog(targetProduct: ProductEntity? = null, presetCode: String? = null) {
        _uiState.update {
            it.copy(
                isAssignShortcutDialogOpen = true,
                shortcutAssignmentTargetProduct = targetProduct,
                pendingShortcutCodeToAssign = presetCode ?: it.pendingShortcutCodeToAssign
            )
        }
    }

    fun closeAssignShortcutDialog() {
        _uiState.update {
            it.copy(
                isAssignShortcutDialogOpen = false,
                shortcutAssignmentTargetProduct = null,
                pendingShortcutCodeToAssign = null
            )
        }
    }

    fun assignShortcutCode(productId: Long, newShortcutCode: String?) {
        viewModelScope.launch {
            repository.updateShortcutCode(productId, newShortcutCode)
            closeAssignShortcutDialog()
            showBanner("تم حفظ كود الاختصار ($newShortcutCode) للمنتج بنجاح!")
        }
    }

    // --- Hold / Park Invoice ---
    fun holdCurrentInvoice() {
        val state = _uiState.value
        if (state.cartItems.isEmpty()) {
            showBanner("لا توجد منتجات لحفظ الفاتورة الحالية في الانتظار")
            return
        }

        val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val heldCart = HeldCart(
            invoiceNumber = state.invoiceNumber,
            timeFormatted = timeFormatted,
            items = state.cartItems,
            totalAmount = state.totalAmount
        )

        _uiState.update {
            it.copy(
                heldCarts = it.heldCarts + heldCart,
                cartItems = emptyList(),
                selectedCartIndex = null,
                invoiceNumber = PosUiState.generateInvoiceNumber(),
                bannerMessage = "تم حفظ الفاتورة في الانتظار (#${heldCart.invoiceNumber})"
            )
        }
    }

    fun recallHeldInvoice(heldCart: HeldCart) {
        _uiState.update { state ->
            state.copy(
                heldCarts = state.heldCarts.filter { it.id != heldCart.id },
                cartItems = heldCart.items,
                selectedCartIndex = if (heldCart.items.isNotEmpty()) 0 else null,
                invoiceNumber = heldCart.invoiceNumber,
                bannerMessage = "تم استرجاع الفاتورة (#${heldCart.invoiceNumber})"
            )
        }
    }

    // --- Invoice Lifecycle ---
    fun startNewInvoice() {
        _uiState.update {
            it.copy(
                cartItems = emptyList(),
                selectedCartIndex = null,
                numPadBuffer = "",
                invoiceNumber = PosUiState.generateInvoiceNumber(),
                bannerMessage = "تم بدء فاتورة جديدة فارغة"
            )
        }
    }

    // --- Cash Checkout & Completion ---
    fun openPaymentDialog() {
        if (_uiState.value.cartItems.isEmpty()) {
            showBanner("الفاتورة فارغة! أضف منتجات أولاً.")
            return
        }
        _uiState.update { it.copy(isPaymentDialogOpen = true) }
    }

    fun closePaymentDialog() {
        _uiState.update { it.copy(isPaymentDialogOpen = false) }
    }

    fun completePayment(paidAmount: Double, paymentMethod: String) {
        val state = _uiState.value
        if (state.cartItems.isEmpty()) return

        val total = state.totalAmount
        val change = (paidAmount - total).coerceAtLeast(0.0)

        val invoiceEntity = SaleInvoiceEntity(
            invoiceNumber = state.invoiceNumber,
            timestamp = System.currentTimeMillis(),
            totalAmount = total,
            paidAmount = paidAmount,
            changeAmount = change,
            paymentMethod = paymentMethod,
            itemCount = state.cartItems.size,
            cashierName = state.cashierName
        )

        val saleItems = state.cartItems.map { it.toSaleItem() }

        viewModelScope.launch {
            val invoiceId = repository.completeSale(invoiceEntity, saleItems)
            val fullInvoice = repository.getInvoiceDetails(invoiceId)

            _uiState.update {
                it.copy(
                    cartItems = emptyList(),
                    selectedCartIndex = null,
                    numPadBuffer = "",
                    invoiceNumber = PosUiState.generateInvoiceNumber(),
                    isPaymentDialogOpen = false,
                    lastCompletedInvoice = fullInvoice,
                    isReceiptDialogOpen = true,
                    bannerMessage = "تم إتمام البيع بنجاح! الباقي: ${String.format(Locale.ENGLISH, "%.2f", change)}"
                )
            }
        }
    }

    fun closeReceiptDialog() {
        _uiState.update { it.copy(isReceiptDialogOpen = false) }
    }

    // --- Dialogs & Sheets ---
    fun setScannerOpen(open: Boolean) {
        _uiState.update { it.copy(isScannerOpen = open) }
    }

    fun setQuickProductsSheetOpen(open: Boolean) {
        _uiState.update { it.copy(isQuickProductsSheetOpen = open) }
    }

    fun openAddProductDialog(barcodeOrShortcut: String? = null) {
        _uiState.update {
            it.copy(
                isAddProductDialogOpen = true,
                unregisteredBarcode = barcodeOrShortcut ?: it.unregisteredBarcode,
                pendingShortcutCodeToAssign = barcodeOrShortcut ?: it.pendingShortcutCodeToAssign
            )
        }
    }

    fun closeAddProductDialog() {
        _uiState.update {
            it.copy(
                isAddProductDialogOpen = false,
                unregisteredBarcode = null,
                pendingShortcutCodeToAssign = null
            )
        }
    }

    fun saveProduct(product: ProductEntity, addToCartImmediately: Boolean = false) {
        viewModelScope.launch {
            val id = repository.saveProduct(product)
            val savedProduct = product.copy(id = if (product.id == 0L) id else product.id)

            if (addToCartImmediately) {
                addProductToCart(savedProduct, 1.0)
            }

            _uiState.update {
                it.copy(
                    isAddProductDialogOpen = false,
                    unregisteredBarcode = null,
                    pendingShortcutCodeToAssign = null,
                    bannerMessage = "تم حفظ الصنف: ${product.name} (كود الاختصار: ${product.shortcutCode ?: "بدون"})"
                )
            }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            showBanner("تم حذف المنتج: ${product.name}")
        }
    }
}
