package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.CartItem
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosRedDelete
import com.example.ui.theme.PosTableRowAlternate
import com.example.ui.theme.PosTableRowSelected
import java.util.Locale

@Composable
fun PosCartTable(
    cartItems: List<CartItem>,
    selectedIndex: Int?,
    onSelectItem: (Int) -> Unit,
    onIncrementItem: (Int) -> Unit,
    onDecrementItem: (Int) -> Unit,
    onDeleteItem: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto-scroll to newly added or selected item
    LaunchedEffect(selectedIndex, cartItems.size) {
        if (selectedIndex != null && selectedIndex in cartItems.indices) {
            listState.animateScrollToItem(selectedIndex)
        } else if (cartItems.isNotEmpty()) {
            listState.animateScrollToItem(cartItems.lastIndex)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        color = Color.White
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Table Header Bar (Supermarket style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PosBlueHeader)
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ت",
                    modifier = Modifier.width(32.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "بيان الصنف",
                    modifier = Modifier.weight(2.6f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "الكمية",
                    modifier = Modifier.weight(1.2f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "السعر",
                    modifier = Modifier.weight(1.2f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "الإجمالي",
                    modifier = Modifier.weight(1.3f),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Table Body
            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(54.dp),
                            tint = Color(0xFFB0BEC5)
                        )
                        Text(
                            text = "الفاتورة فارغة حالياً",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF546E7A)
                        )
                        Text(
                            text = "امسح الباركود بالكاميرا أو اختر صنفاً من القائمة السريعة",
                            fontSize = 13.sp,
                            color = Color(0xFF78909C),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(cartItems, key = { _, item -> item.cartItemId }) { index, item ->
                        val isSelected = selectedIndex == index
                        val rowBg = when {
                            isSelected -> PosTableRowSelected
                            index % 2 == 1 -> PosTableRowAlternate
                            else -> Color.White
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .clickable { onSelectItem(index) }
                                .testTag("cart_row_$index")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Index
                                Text(
                                    text = "${index + 1}",
                                    modifier = Modifier.width(32.dp),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) PosBluePrimary else Color(0xFF455A64),
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )

                                // Item Name + Barcode / Unit
                                Column(modifier = Modifier.weight(2.6f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.product.iconEmoji,
                                            fontSize = 14.sp,
                                            modifier = Modifier.padding(end = 4.dp)
                                        )
                                        Text(
                                            text = item.product.name,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = Color(0xFF1E293B),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (!item.product.barcode.isNullOrBlank()) {
                                        Text(
                                            text = item.product.barcode,
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                // Quantity (with unit)
                                val qtyStr = if (item.quantity % 1.0 == 0.0) {
                                    item.quantity.toInt().toString()
                                } else {
                                    String.format(Locale.ENGLISH, "%.2f", item.quantity)
                                }
                                Text(
                                    text = "$qtyStr ${item.product.unit}",
                                    modifier = Modifier.weight(1.2f),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = PosBluePrimary,
                                    textAlign = TextAlign.Center
                                )

                                // Unit Price
                                Text(
                                    text = String.format(Locale.ENGLISH, "%.2f", item.unitPrice),
                                    modifier = Modifier.weight(1.2f),
                                    fontSize = 13.sp,
                                    color = Color(0xFF334155),
                                    textAlign = TextAlign.Center
                                )

                                // Total
                                Text(
                                    text = String.format(Locale.ENGLISH, "%.2f", item.totalPrice),
                                    modifier = Modifier.weight(1.3f),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF0F172A),
                                    textAlign = TextAlign.Center
                                )
                            }

                            // If row is selected, show quick inline action bar (+, -, delete)
                            if (isSelected) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFE3F2FD))
                                        .padding(horizontal = 16.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "تعديل الصنف المحدد:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = PosBluePrimary
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Minus Button
                                        IconButton(
                                            onClick = { onDecrementItem(index) },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(Color.White, CircleShape)
                                                .border(1.dp, Color(0xFF90CAF9), CircleShape)
                                                .testTag("inline_decrement_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Remove,
                                                contentDescription = "إنقاص الكمية",
                                                tint = Color(0xFF1565C0),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        // Plus Button
                                        IconButton(
                                            onClick = { onIncrementItem(index) },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(PosBluePrimary, CircleShape)
                                                .testTag("inline_increment_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "زيادة الكمية",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        // Delete Button
                                        IconButton(
                                            onClick = { onDeleteItem(index) },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(Color(0xFFFFEBEE), CircleShape)
                                                .testTag("inline_delete_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف الصنف",
                                                tint = PosRedDelete,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Divider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
                        }
                    }
                }
            }
        }
    }
}
