package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosGreenCash
import com.example.ui.theme.PosGreenCashLight
import java.util.Locale

@Composable
fun PosCashPaymentDialog(
    totalAmount: Double,
    onConfirmPayment: (paidAmount: Double, paymentMethod: String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMethod by remember { mutableStateOf("كاش") } // كاش أو شبكة
    var paidAmountText by remember {
        mutableStateOf(String.format(Locale.ENGLISH, "%.2f", totalAmount))
    }

    val paidAmount = paidAmountText.toDoubleOrNull() ?: 0.0
    val changeAmount = (paidAmount - totalAmount).coerceAtLeast(0.0)
    val isEnough = if (selectedMethod == "كاش") paidAmount >= totalAmount else true

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = PosGreenCash,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "إتمام عملية البيع والدفع",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Payment Method Selector Tabs
                TabRow(
                    selectedTabIndex = if (selectedMethod == "كاش") 0 else 1,
                    containerColor = Color(0xFFF1F5F9),
                    contentColor = PosBluePrimary,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedMethod == "كاش",
                        onClick = {
                            selectedMethod = "كاش"
                            if (paidAmount < totalAmount) {
                                paidAmountText = String.format(Locale.ENGLISH, "%.2f", totalAmount)
                            }
                        },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Money, contentDescription = null, modifier = Modifier.size(18.dp))
                                Text("نقدي (Cash)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedMethod == "شبكة / بطاقة",
                        onClick = {
                            selectedMethod = "شبكة / بطاقة"
                            paidAmountText = String.format(Locale.ENGLISH, "%.2f", totalAmount)
                        },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(18.dp))
                                Text("بطاقة / مدى (Card)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                // Breakdown Card: Total, Paid, Change
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "إجمالي الفاتورة المطلوب:",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "${String.format(Locale.ENGLISH, "%.2f", totalAmount)} ر.س",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PosBluePrimary
                            )
                        }

                        // Paid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المبلغ المدفوع من العميل:",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "${String.format(Locale.ENGLISH, "%.2f", paidAmount)} ر.س",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }

                        // Change Due
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isEnough) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isEnough) "الباقي للعميل (المتبقي):" else "المبلغ غير كافٍ! متبقي:",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isEnough) PosGreenCash else Color(0xFFC62828)
                            )
                            Text(
                                text = "${String.format(Locale.ENGLISH, "%.2f", if (isEnough) changeAmount else (totalAmount - paidAmount))} ر.س",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isEnough) PosGreenCash else Color(0xFFC62828)
                            )
                        }
                    }
                }

                // If Cash, show Quick Denominations and Numpad
                if (selectedMethod == "كاش") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "فئات نقدية سريعة:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )

                        // Quick denomination chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QuickCashButton(
                                text = "الضبط",
                                onClick = {
                                    paidAmountText = String.format(Locale.ENGLISH, "%.2f", totalAmount)
                                },
                                modifier = Modifier.weight(1.2f)
                            )
                            listOf(10, 20, 50, 100, 200).forEach { amount ->
                                QuickCashButton(
                                    text = "$amount",
                                    onClick = {
                                        paidAmountText = amount.toString()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // Custom paid amount input
                        OutlinedTextField(
                            value = paidAmountText,
                            onValueChange = { paidAmountText = it },
                            label = { Text("أدخل المبلغ المدفوع يدويًا") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_paid_amount"),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Confirm and Complete Button
                Button(
                    onClick = {
                        onConfirmPayment(paidAmount, selectedMethod)
                    },
                    enabled = isEnough,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("confirm_payment_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PosGreenCashLight,
                        disabledContainerColor = Color(0xFFCBD5E1)
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Text(
                            text = "تأكيد الدفع وإنهاء الفاتورة",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCashButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(8.dp))
            .background(Color(0xFFE3F2FD))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = PosBluePrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
