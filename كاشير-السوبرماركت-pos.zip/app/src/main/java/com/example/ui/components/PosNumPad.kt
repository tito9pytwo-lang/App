package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.CartItem
import com.example.ui.model.NumPadMode
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosBlueSecondary

@Composable
fun PosNumPad(
    currentBuffer: String,
    mode: NumPadMode,
    selectedItem: CartItem?,
    onModeChange: (NumPadMode) -> Unit,
    onKeyPress: (String) -> Unit,
    onApply: () -> Unit,
    onDeleteSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp)),
        color = Color(0xFFF1F5F9),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Mode Selectors (كود / اختصار، الكمية، السعر)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                NumPadModeChip(
                    text = "كود / اختصار (0)",
                    isSelected = mode == NumPadMode.BARCODE,
                    onClick = { onModeChange(NumPadMode.BARCODE) },
                    modifier = Modifier.weight(1.2f),
                    testTag = "mode_barcode"
                )
                NumPadModeChip(
                    text = "الكمية",
                    isSelected = mode == NumPadMode.QUANTITY,
                    onClick = { onModeChange(NumPadMode.QUANTITY) },
                    modifier = Modifier.weight(1f),
                    testTag = "mode_qty"
                )
                NumPadModeChip(
                    text = "السعر",
                    isSelected = mode == NumPadMode.PRICE,
                    onClick = { onModeChange(NumPadMode.PRICE) },
                    modifier = Modifier.weight(1f),
                    testTag = "mode_price"
                )
            }

            // NumPad Display (Shows what is being entered)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val label = when (mode) {
                        NumPadMode.BARCODE -> "أدخل رقم الاختصار (مثال: 0) أو الباركود"
                        NumPadMode.QUANTITY -> if (selectedItem != null) "كمية [${selectedItem.product.name}]" else "إدخال كمية"
                        NumPadMode.PRICE -> if (selectedItem != null) "سعر [${selectedItem.product.name}]" else "إدخال سعر"
                        NumPadMode.CASH_PAID -> "المبلغ المدفوع"
                    }
                    Text(
                        text = label,
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        maxLines = 1
                    )

                    Text(
                        text = currentBuffer.ifEmpty { "0" },
                        color = Color(0xFF38BDF8),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End
                    )
                }
            }

            // Keypad Grid: 7 8 9, 4 5 6, 1 2 3, C . 0
            val rows = listOf(
                listOf("7", "8", "9"),
                listOf("4", "5", "6"),
                listOf("1", "2", "3"),
                listOf("C", "0", ".")
            )

            rows.forEach { rowKeys ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    rowKeys.forEach { key ->
                        NumPadKeyButton(
                            key = key,
                            onClick = { onKeyPress(key) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Action row: Backspace (⌫), Delete item (X), and Apply (✔ تطبيق)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Backspace
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE2E8F0))
                        .clickable { onKeyPress("DEL") }
                        .testTag("numpad_key_backspace"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Backspace,
                        contentDescription = "مسح",
                        tint = Color(0xFF334155),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Delete item from cart button (X)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFFEBEE))
                        .clickable { onDeleteSelected() }
                        .testTag("numpad_key_delete_item"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف الصنف",
                        tint = Color(0xFFC62828),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Apply button (OK)
                Box(
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(PosBlueSecondary, PosBluePrimary)
                            )
                        )
                        .clickable { onApply() }
                        .testTag("numpad_key_apply"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "تطبيق",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "تطبيق",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NumPadModeChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (isSelected) PosBluePrimary else Color(0xFFCBD5E1)
            )
            .clickable { onClick() }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (isSelected) Color.White else Color(0xFF1E293B),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun NumPadKeyButton(
    key: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isClearKey = key == "C"
    val isZeroKey = key == "0"
    val bgGradient = if (isClearKey) {
        Brush.verticalGradient(listOf(Color(0xFFFFCDD2), Color(0xFFEF9A9A)))
    } else if (isZeroKey) {
        Brush.verticalGradient(listOf(Color(0xFFE3F2FD), Color(0xFFBBDEFB)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE2E8F0)))
    }

    val textColor = when {
        isClearKey -> Color(0xFFB71C1C)
        isZeroKey -> PosBluePrimary
        else -> Color(0xFF0F172A)
    }

    Box(
        modifier = modifier
            .height(52.dp)
            .shadow(1.dp, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp))
            .background(bgGradient)
            .border(
                1.dp,
                if (isClearKey) Color(0xFFE57373) else if (isZeroKey) Color(0xFF90CAF9) else Color(0xFFCBD5E1),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .testTag("numpad_key_$key"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = key,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}
