package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PosGreenCash
import com.example.ui.theme.PosGreenCashLight
import com.example.ui.theme.PosOrangePrice
import com.example.ui.theme.PosRedDelete

@Composable
fun PosSideControls(
    onCashClick: () -> Unit,
    onQuickProductsClick: () -> Unit,
    onScannerClick: () -> Unit,
    onIncrementSelected: () -> Unit,
    onDecrementSelected: () -> Unit,
    onDeleteSelected: () -> Unit,
    onChangePriceClick: () -> Unit,
    onHoldInvoiceClick: () -> Unit,
    onNewInvoiceClick: () -> Unit,
    hasSelectedItem: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Dominant Large CASH Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(PosGreenCashLight, PosGreenCash)
                    )
                )
                .border(2.dp, Color(0xFF81C784), RoundedCornerShape(10.dp))
                .clickable { onCashClick() }
                .testTag("pos_cash_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = "كاش",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Cash / كاش",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "إنهاء البيع والدفع",
                        color = Color(0xFFC8E6C9),
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Quick Products (القائمة السريعة)
        PosSideButton(
            title = "القائمة السريعة",
            subtitle = "أصناف بدون باركود",
            icon = Icons.Default.Bolt,
            bgColors = listOf(Color(0xFF1E88E5), Color(0xFF1565C0)),
            onClick = onQuickProductsClick,
            testTag = "btn_quick_products"
        )

        // Barcode Scanner button
        PosSideButton(
            title = "مسح باركود",
            subtitle = "كاميرا الهاتف",
            icon = Icons.Default.QrCodeScanner,
            bgColors = listOf(Color(0xFF00897B), Color(0xFF00695C)),
            onClick = onScannerClick,
            testTag = "btn_open_camera_scanner"
        )

        // Increment & Decrement row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2E7D32))
                    .clickable { onIncrementSelected() }
                    .testTag("btn_side_increment"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "زيادة", tint = Color.White)
                    Text("زيادة (+)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF57C00))
                    .clickable { onDecrementSelected() }
                    .testTag("btn_side_decrement"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "إنقاص", tint = Color.White)
                    Text("إنقاص (-)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Change price button
        PosSideButton(
            title = "تغيير سعر",
            subtitle = if (hasSelectedItem) "للصنف المحدد" else "حدد صنفاً أولاً",
            icon = Icons.Default.EditNote,
            bgColors = listOf(PosOrangePrice, Color(0xFFBF360C)),
            onClick = onChangePriceClick,
            testTag = "btn_change_price"
        )

        // Delete selected item
        PosSideButton(
            title = "حذف الصنف (X)",
            subtitle = "حذف من الفاتورة",
            icon = Icons.Default.Delete,
            bgColors = listOf(Color(0xFFE53935), PosRedDelete),
            onClick = onDeleteSelected,
            testTag = "btn_delete_item"
        )

        // Hold / Park invoice & New Invoice row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF455A64))
                    .clickable { onHoldInvoiceClick() }
                    .testTag("btn_hold_invoice"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.PauseCircle, contentDescription = "انتظار", tint = Color.White, modifier = Modifier.size(16.dp))
                    Text("انتظار", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF37474F))
                    .clickable { onNewInvoiceClick() }
                    .testTag("btn_new_invoice"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.NoteAdd, contentDescription = "فاتورة جديدة", tint = Color.White, modifier = Modifier.size(16.dp))
                    Text("فاتورة جديدة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PosSideButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    bgColors: List<Color>,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Brush.horizontalGradient(bgColors))
            .clickable { onClick() }
            .testTag(testTag)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        color = Color(0xFFE0E0E0),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}
