package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PosUiState
import com.example.ui.model.PosTab
import com.example.ui.theme.PosBlueHeader
import com.example.ui.theme.PosBluePrimary
import com.example.ui.theme.PosOrangePrice
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PosTopBar(
    uiState: PosUiState,
    onCodeChange: (String) -> Unit,
    onSubmitCode: () -> Unit,
    onOpenScanner: () -> Unit,
    onSelectTab: (PosTab) -> Unit,
    onShowHeldCarts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentDateStr = remember {
        SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date())
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = PosBlueHeader,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // First Row: Cashier info, Current date, Held invoices, and Barcode Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Info badges
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF1565C0), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "👤 ${uiState.cashierName}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0xFF0D47A1), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "📅 $currentDateStr",
                            color = Color(0xFFE3F2FD),
                            fontSize = 12.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0xFF004D40), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "# ${uiState.invoiceNumber}",
                            color = Color(0xFFA7FFEB),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Held Invoices Button if any
                    if (uiState.heldCarts.isNotEmpty()) {
                        BadgedBox(
                            badge = {
                                Badge(containerColor = PosOrangePrice) {
                                    Text("${uiState.heldCarts.size}")
                                }
                            }
                        ) {
                            IconButton(
                                onClick = onShowHeldCarts,
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("held_invoices_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PauseCircle,
                                    contentDescription = "الفواتير المعلقة",
                                    tint = PosOrangePrice
                                )
                            }
                        }
                    }
                }

                // Camera Scanner trigger button
                IconButton(
                    onClick = onOpenScanner,
                    modifier = Modifier
                        .background(Color(0xFF2E7D32), RoundedCornerShape(8.dp))
                        .size(40.dp)
                        .testTag("open_scanner_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "فتح الماسح بالكاميرا",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Second Row: Barcode / Code search input & Quick Barcode Add
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = uiState.manualCodeInput,
                    onValueChange = onCodeChange,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("barcode_input_field"),
                    placeholder = {
                        Text(
                            text = "إدخال كود الباركود أو اسم الصنف...",
                            color = Color(0xFFB0BEC5),
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = Color(0xFF90CAF9)
                        )
                    },
                    trailingIcon = {
                        if (uiState.manualCodeInput.isNotEmpty()) {
                            IconButton(onClick = { onCodeChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح الإدخال",
                                    tint = Color.White
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = { onSubmitCode() }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF1E3A8A),
                        unfocusedContainerColor = Color(0xFF172554),
                        focusedBorderColor = Color(0xFF60A5FA),
                        unfocusedBorderColor = Color(0xFF3B82F6),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                // Quick Add/Enter Button
                androidx.compose.material3.Button(
                    onClick = onSubmitCode,
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("submit_barcode_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = PosBluePrimary
                    )
                ) {
                    Text("إدخال / بحث", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Navigation Tabs (الكاشير، المنتجات، سجل المبيعات)
            TabRow(
                selectedTabIndex = uiState.activeTab.ordinal,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                divider = {}
            ) {
                Tab(
                    selected = uiState.activeTab == PosTab.POS,
                    onClick = { onSelectTab(PosTab.POS) },
                    text = { Text("شاشة الكاشير", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.PointOfSale, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_pos")
                )
                Tab(
                    selected = uiState.activeTab == PosTab.PRODUCTS,
                    onClick = { onSelectTab(PosTab.PRODUCTS) },
                    text = { Text("إدارة المنتجات", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_products")
                )
                Tab(
                    selected = uiState.activeTab == PosTab.SALES,
                    onClick = { onSelectTab(PosTab.SALES) },
                    text = { Text("سجل المبيعات", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_sales")
                )
            }
        }
    }
}
