package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.ui.HeldCart
import com.example.ui.PosUiState
import com.example.ui.components.AssignShortcutDialog
import com.example.ui.components.HeldInvoicesDialog
import com.example.ui.components.PosAddProductDialog
import com.example.ui.components.PosCartTable
import com.example.ui.components.PosCashPaymentDialog
import com.example.ui.components.PosNumPad
import com.example.ui.components.PosQuickProductsSheet
import com.example.ui.components.PosReceiptDialog
import com.example.ui.components.PosScannerDialog
import com.example.ui.components.PosSideControls
import com.example.ui.components.PosTopBar
import com.example.ui.components.PosTotalsFooter
import com.example.ui.model.NumPadMode
import com.example.ui.model.PosTab
import kotlinx.coroutines.delay

@Composable
fun PosMainScreen(
    uiState: PosUiState,
    allProducts: List<ProductEntity>,
    shortcutProducts: List<ProductEntity>,
    onCodeChange: (String) -> Unit,
    onSubmitCode: () -> Unit,
    onBarcodeScanned: (String) -> Unit,
    onSelectItem: (Int) -> Unit,
    onIncrementItem: (Int) -> Unit,
    onDecrementItem: (Int) -> Unit,
    onDeleteItem: (Int) -> Unit,
    onNumPadModeChange: (NumPadMode) -> Unit,
    onNumPadKeyPress: (String) -> Unit,
    onNumPadApply: () -> Unit,
    onCashClick: () -> Unit,
    onHoldInvoice: () -> Unit,
    onRecallHeldInvoice: (HeldCart) -> Unit,
    onNewInvoice: () -> Unit,
    onOpenScanner: () -> Unit,
    onCloseScanner: () -> Unit,
    onOpenQuickProducts: () -> Unit,
    onCloseQuickProducts: () -> Unit,
    onSelectQuickProduct: (ProductEntity) -> Unit,
    onOpenAddProduct: (String?) -> Unit,
    onCloseAddProduct: () -> Unit,
    onSaveProduct: (ProductEntity, Boolean) -> Unit,
    onOpenAssignShortcut: (ProductEntity?) -> Unit,
    onCloseAssignShortcut: () -> Unit,
    onSaveShortcutCode: (Long, String?) -> Unit,
    onConfirmPayment: (Double, String) -> Unit,
    onClosePaymentDialog: () -> Unit,
    onCloseReceiptDialog: () -> Unit,
    onSelectTab: (PosTab) -> Unit,
    onDismissBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showHeldDialog by remember { mutableStateOf(false) }

    // Auto-dismiss banner message after 3 seconds
    LaunchedEffect(uiState.bannerMessage) {
        if (uiState.bannerMessage != null) {
            delay(3200)
            onDismissBanner()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top POS Navigation and Barcode Bar
            PosTopBar(
                uiState = uiState,
                onCodeChange = onCodeChange,
                onSubmitCode = onSubmitCode,
                onOpenScanner = onOpenScanner,
                onSelectTab = onSelectTab,
                onShowHeldCarts = { showHeldDialog = true }
            )

            // Banner Notification
            AnimatedVisibility(
                visible = uiState.bannerMessage != null,
                enter = slideInVertically(),
                exit = slideOutVertically()
            ) {
                uiState.bannerMessage?.let { msg ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = msg,
                            color = Color(0xFF38BDF8),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Main Content Area with Adaptive Layout
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(6.dp)
            ) {
                val isWide = maxWidth >= 640.dp

                if (isWide) {
                    // Landscape / POS Terminal layout
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Main Part (الجزء الأكبر): Cart Table
                        Box(
                            modifier = Modifier
                                .weight(2.2f)
                                .fillMaxHeight()
                        ) {
                            PosCartTable(
                                cartItems = uiState.cartItems,
                                selectedIndex = uiState.selectedCartIndex,
                                onSelectItem = onSelectItem,
                                onIncrementItem = onIncrementItem,
                                onDecrementItem = onDecrementItem,
                                onDeleteItem = onDeleteItem
                            )
                        }

                        // Side Controls Column
                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight()
                        ) {
                            PosSideControls(
                                onCashClick = onCashClick,
                                onQuickProductsClick = onOpenQuickProducts,
                                onScannerClick = onOpenScanner,
                                onIncrementSelected = { onIncrementItem(uiState.selectedCartIndex ?: uiState.cartItems.lastIndex) },
                                onDecrementSelected = { uiState.selectedCartIndex?.let { onDecrementItem(it) } },
                                onDeleteSelected = { uiState.selectedCartIndex?.let { onDeleteItem(it) } },
                                onChangePriceClick = { onNumPadModeChange(NumPadMode.PRICE) },
                                onHoldInvoiceClick = onHoldInvoice,
                                onNewInvoiceClick = onNewInvoice,
                                hasSelectedItem = uiState.selectedCartIndex != null
                            )
                        }

                        // Keypad Column
                        Box(
                            modifier = Modifier
                                .weight(1.3f)
                                .fillMaxHeight()
                        ) {
                            PosNumPad(
                                currentBuffer = uiState.numPadBuffer,
                                mode = uiState.numPadMode,
                                selectedItem = uiState.selectedCartItem,
                                onModeChange = onNumPadModeChange,
                                onKeyPress = onNumPadKeyPress,
                                onApply = onNumPadApply,
                                onDeleteSelected = { uiState.selectedCartIndex?.let { onDeleteItem(it) } }
                            )
                        }
                    }
                } else {
                    // Portrait Mobile Layout: Table on top, Controls + Numpad at bottom
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Cart Table (Flexible weight)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            PosCartTable(
                                cartItems = uiState.cartItems,
                                selectedIndex = uiState.selectedCartIndex,
                                onSelectItem = onSelectItem,
                                onIncrementItem = onIncrementItem,
                                onDecrementItem = onDecrementItem,
                                onDeleteItem = onDeleteItem
                            )
                        }

                        // Bottom Section: Side Controls + Numpad side-by-side
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Side Controls
                            Box(modifier = Modifier.weight(1f)) {
                                PosSideControls(
                                    onCashClick = onCashClick,
                                    onQuickProductsClick = onOpenQuickProducts,
                                    onScannerClick = onOpenScanner,
                                    onIncrementSelected = { onIncrementItem(uiState.selectedCartIndex ?: uiState.cartItems.lastIndex) },
                                    onDecrementSelected = { uiState.selectedCartIndex?.let { onDecrementItem(it) } },
                                    onDeleteSelected = { uiState.selectedCartIndex?.let { onDeleteItem(it) } },
                                    onChangePriceClick = { onNumPadModeChange(NumPadMode.PRICE) },
                                    onHoldInvoiceClick = onHoldInvoice,
                                    onNewInvoiceClick = onNewInvoice,
                                    hasSelectedItem = uiState.selectedCartIndex != null
                                )
                            }

                            // NumPad
                            Box(modifier = Modifier.weight(1.2f)) {
                                PosNumPad(
                                    currentBuffer = uiState.numPadBuffer,
                                    mode = uiState.numPadMode,
                                    selectedItem = uiState.selectedCartItem,
                                    onModeChange = onNumPadModeChange,
                                    onKeyPress = onNumPadKeyPress,
                                    onApply = onNumPadApply,
                                    onDeleteSelected = { uiState.selectedCartIndex?.let { onDeleteItem(it) } }
                                )
                            }
                        }
                    }
                }
            }

            // Bottom POS LED Grand Total Footer
            PosTotalsFooter(
                totalAmount = uiState.totalAmount,
                itemCount = uiState.distinctItemCount,
                totalQuantity = uiState.totalQuantity,
                onCashClick = onCashClick
            )
        }

        // --- Dialogs ---

        // Continuous Barcode Scanner Dialog
        if (uiState.isScannerOpen) {
            PosScannerDialog(
                onBarcodeScanned = onBarcodeScanned,
                onDismiss = onCloseScanner
            )
        }

        // Quick Products Sheet (اختصارات المنتجات)
        if (uiState.isQuickProductsSheetOpen) {
            PosQuickProductsSheet(
                products = shortcutProducts.ifEmpty { allProducts },
                onSelectProduct = onSelectQuickProduct,
                onAddNewShortcut = {
                    onCloseQuickProducts()
                    onOpenAddProduct(null)
                },
                onAssignShortcutCode = { targetProduct ->
                    onCloseQuickProducts()
                    onOpenAssignShortcut(targetProduct)
                },
                onDismiss = onCloseQuickProducts
            )
        }

        // Assign Custom Shortcut Code Dialog
        if (uiState.isAssignShortcutDialogOpen) {
            AssignShortcutDialog(
                products = allProducts,
                initialTargetProduct = uiState.shortcutAssignmentTargetProduct,
                initialCode = uiState.pendingShortcutCodeToAssign,
                onSaveShortcut = onSaveShortcutCode,
                onDismiss = onCloseAssignShortcut
            )
        }

        // Cash / Payment Dialog
        if (uiState.isPaymentDialogOpen) {
            PosCashPaymentDialog(
                totalAmount = uiState.totalAmount,
                onConfirmPayment = onConfirmPayment,
                onDismiss = onClosePaymentDialog
            )
        }

        // Receipt Dialog
        if (uiState.isReceiptDialogOpen && uiState.lastCompletedInvoice != null) {
            PosReceiptDialog(
                invoiceWithItems = uiState.lastCompletedInvoice,
                onDismiss = onCloseReceiptDialog
            )
        }

        // Add Product Dialog (Manual or for Unregistered barcode)
        if (uiState.isAddProductDialogOpen) {
            PosAddProductDialog(
                initialBarcode = uiState.unregisteredBarcode,
                onSaveProduct = onSaveProduct,
                onDismiss = onCloseAddProduct
            )
        }

        // Held / Parked Carts Dialog
        if (showHeldDialog) {
            HeldInvoicesDialog(
                heldCarts = uiState.heldCarts,
                onRecall = onRecallHeldInvoice,
                onDismiss = { showHeldDialog = false }
            )
        }
    }
}
