package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val sourceUrl: String,
    val downloadUrl: String,
    val localFilePath: String,
    val platform: String,
    val thumbnailUrl: String?,
    val fileSizeBytes: Long,
    val durationSeconds: Int,
    val downloadTimestamp: Long = System.currentTimeMillis(),
    val qualityLabel: String,
    val isAudio: Boolean = false
)
