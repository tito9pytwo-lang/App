package com.example.data.remote

import android.util.Log
import com.example.data.model.ExtractedVideo
import com.example.data.model.PlatformType
import com.example.data.model.VideoDownloadOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class VideoExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    suspend fun extract(inputUrl: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = cleanUrl(inputUrl)
            if (cleanUrl.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("يرجى إدخال رابط صالح"))
            }

            val platform = detectPlatform(cleanUrl)
            when (platform) {
                PlatformType.TIKTOK -> extractTikTok(cleanUrl)
                PlatformType.FACEBOOK -> extractFacebook(cleanUrl)
                PlatformType.INSTAGRAM -> extractInstagram(cleanUrl)
                PlatformType.YOUTUBE -> extractYouTube(cleanUrl)
                PlatformType.TWITTER -> extractTwitter(cleanUrl)
                PlatformType.OTHER -> extractDirectOrGeneric(cleanUrl)
            }
        } catch (e: Exception) {
            Log.e("VideoExtractor", "Error extracting video", e)
            Result.failure(Exception(e.message ?: "تعذر استخراج بيانات الفيديو، يرجى التأكد من أن الرابط عام."))
        }
    }

    private fun detectPlatform(url: String): PlatformType {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") || lower.contains("douyin.com") -> PlatformType.TIKTOK
            lower.contains("facebook.com") || lower.contains("fb.watch") || lower.contains("fb.com") -> PlatformType.FACEBOOK
            lower.contains("instagram.com") || lower.contains("instagr.am") -> PlatformType.INSTAGRAM
            lower.contains("youtube.com") || lower.contains("youtu.be") -> PlatformType.YOUTUBE
            lower.contains("twitter.com") || lower.contains("x.com") -> PlatformType.TWITTER
            else -> PlatformType.OTHER
        }
    }

    private fun cleanUrl(input: String): String {
        val trimmed = input.trim()
        val matcher = Pattern.compile("https?://[^\\s]+").matcher(trimmed)
        return if (matcher.find()) {
            matcher.group(0) ?: ""
        } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            ""
        }
    }

    // ==================== TIKTOK ====================
    private suspend fun extractTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(url, "UTF-8")
            val apiUrl = "https://www.tikwm.com/api/?url=$encoded&count=12&cursor=0&web=1&hd=1"

            val request = Request.Builder()
                .url(apiUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful && body.isNotEmpty()) {
                val json = JSONObject(body)
                val code = json.optInt("code", -1)
                if (code == 0 && json.has("data")) {
                    val data = json.getJSONObject("data")
                    val title = data.optString("title", "فيديو تيك توك").ifBlank { "فيديو تيك توك" }
                    val cover = data.optString("cover")
                    val duration = data.optInt("duration", 0)

                    val author = data.optJSONObject("author")
                    val authorName = author?.optString("nickname") ?: author?.optString("unique_id") ?: "مستخدم تيك توك"
                    val authorAvatar = author?.optString("avatar")

                    val options = mutableListOf<VideoDownloadOption>()

                    // HD No Watermark (Highest Quality)
                    val hdUrl = data.optString("hdplay")
                    if (hdUrl.isNotEmpty()) {
                        val fixedHd = if (hdUrl.startsWith("http")) hdUrl else "https://www.tikwm.com$hdUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_hd",
                                label = "جودة فائقة Full HD 1080p (بدون علامة)",
                                description = "أعلى دقة متوفرة مع أنقى صورة",
                                quality = "Full HD 1080p",
                                downloadUrl = fixedHd,
                                isNoWatermark = true
                            )
                        )
                    }

                    // Fast No Watermark
                    val playUrl = data.optString("play")
                    if (playUrl.isNotEmpty()) {
                        val fixedUrl = if (playUrl.startsWith("http")) playUrl else "https://www.tikwm.com$playUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_nowm",
                                label = "جودة عالية HD (بدون علامة مائية)",
                                description = "تنزيل سريع بجودة ممتازة وحجم متوازن",
                                quality = "HD 720p",
                                downloadUrl = fixedUrl,
                                isNoWatermark = true
                            )
                        )
                    }

                    // Watermarked original
                    val wmUrl = data.optString("wmplay")
                    if (wmUrl.isNotEmpty()) {
                        val fixedWm = if (wmUrl.startsWith("http")) wmUrl else "https://www.tikwm.com$wmUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_wm",
                                label = "النسخة الأصلية مع العلامة",
                                description = "الفيديو مع لوجو تيك توك واسم الحساب",
                                quality = "Original",
                                downloadUrl = fixedWm,
                                isNoWatermark = false
                            )
                        )
                    }

                    // Audio MP3
                    val musicUrl = data.optString("music")
                    if (musicUrl.isNotEmpty()) {
                        val fixedMusic = if (musicUrl.startsWith("http")) musicUrl else "https://www.tikwm.com$musicUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_audio",
                                label = "استخراج الصوت فقط (MP3)",
                                description = "ملف صوتي عالي النقاء 320kbps",
                                quality = "صوت MP3",
                                downloadUrl = fixedMusic,
                                isAudioOnly = true
                            )
                        )
                    }

                    if (options.isNotEmpty()) {
                        return@withContext Result.success(
                            ExtractedVideo(
                                originalUrl = url,
                                title = title,
                                authorName = authorName,
                                authorAvatar = authorAvatar,
                                coverUrl = cover,
                                durationSeconds = duration,
                                platform = PlatformType.TIKTOK,
                                downloadOptions = options
                            )
                        )
                    }
                }
            }

            fallbackTikTok(url)
        } catch (e: Exception) {
            fallbackTikTok(url)
        }
    }

    private suspend fun fallbackTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).header("User-Agent", userAgent).build()
            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title") ?: "فيديو تيك توك"
            val image = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                val option = VideoDownloadOption(
                    id = "tt_fallback",
                    label = "تنزيل بجودة عالية HD",
                    description = "الملف الأصلي المتاح",
                    quality = "HD",
                    downloadUrl = videoUrl
                )
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = title,
                        coverUrl = image,
                        platform = PlatformType.TIKTOK,
                        downloadOptions = listOf(option)
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من تيك توك. يرجى التأكد من الرابط."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("فشل فحص رابط تيك توك: ${e.localizedMessage}"))
        }
    }

    // ==================== INSTAGRAM ====================
    private suspend fun extractInstagram(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            // Support Reels & Posts: clean standard URL
            var clean = url.substringBefore("?")
            if (!clean.endsWith("/")) clean += "/"

            // Try Instagram public embed URL which exposes direct video tags without login wall
            val embedUrl = "${clean}embed/captioned/"
            val req = Request.Builder()
                .url(embedUrl)
                .header("User-Agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            // Extract video source from embed HTML
            val videoMatcher = Pattern.compile("<video[^>]+src=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE).matcher(html)
            var videoUrl: String? = null
            if (videoMatcher.find()) {
                videoUrl = videoMatcher.group(1)?.replace("&amp;", "&")
            }

            // Also check for encoded video_url in JSON inside embed
            if (videoUrl.isNullOrEmpty()) {
                val jsonVideoMatcher = Pattern.compile("\"video_url\":\"([^\"]+)\"").matcher(html)
                if (jsonVideoMatcher.find()) {
                    videoUrl = decodeFacebookUrl(jsonVideoMatcher.group(1) ?: "")
                }
            }

            // Also check standard page if embed didn't find video
            var coverUrl: String? = null
            var authorName = "انستغرام"
            val title = "فيديو ريلز انستغرام"

            val imgMatcher = Pattern.compile("<img[^>]+class=[\"'][^\"']*EmbeddedMediaImage[^\"']*[\"'][^>]+src=[\"']([^\"']+)[\"']").matcher(html)
            if (imgMatcher.find()) {
                coverUrl = imgMatcher.group(1)?.replace("&amp;", "&")
            }

            val authorMatcher = Pattern.compile("<div class=[\"']UsernameText[\"']>([^<]+)</div>").matcher(html)
            if (authorMatcher.find()) {
                authorName = authorMatcher.group(1)?.trim() ?: authorName
            }

            if (videoUrl.isNullOrEmpty()) {
                // Secondary fallback via standard page request
                val stdReq = Request.Builder()
                    .url(url)
                    .header("User-Agent", userAgent)
                    .build()
                val stdResp = client.newCall(stdReq).execute()
                val stdHtml = stdResp.body?.string() ?: ""

                videoUrl = extractMetaTag(stdHtml, "og:video") ?: extractMetaTag(stdHtml, "og:video:secure_url")
                if (coverUrl.isNullOrEmpty()) {
                    coverUrl = extractMetaTag(stdHtml, "og:image")
                }
            }

            if (!videoUrl.isNullOrEmpty()) {
                val options = listOf(
                    VideoDownloadOption(
                        id = "ig_hd",
                        label = "جودة عالية Full HD (الأصلية)",
                        description = "أعلى جودة من ريلز انستغرام",
                        quality = "Full HD 1080p",
                        downloadUrl = videoUrl,
                        isNoWatermark = true
                    ),
                    VideoDownloadOption(
                        id = "ig_audio",
                        label = "استخراج الصوت (MP3)",
                        description = "الصوت الأصلي للريلز",
                        quality = "صوت MP3",
                        downloadUrl = videoUrl,
                        isAudioOnly = true
                    )
                )

                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = "ريلز @$authorName",
                        authorName = authorName,
                        coverUrl = coverUrl,
                        platform = PlatformType.INSTAGRAM,
                        downloadOptions = options
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج فيديو انستغرام. تأكد من أن الحساب أو الريلز عام (Public)."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في قراءة ريلز انستغرام: ${e.localizedMessage}"))
        }
    }

    // ==================== YOUTUBE ====================
    private suspend fun extractYouTube(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val videoId = extractYouTubeVideoId(url)
                ?: return@withContext Result.failure(Exception("تعذر العثور على معرّف فيديو يوتيوب من الرابط"))

            // Fetch high-fidelity metadata from YouTube official oEmbed API
            val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
            val metaReq = Request.Builder().url(oembedUrl).build()
            val metaResp = client.newCall(metaReq).execute()
            val metaJson = if (metaResp.isSuccessful) JSONObject(metaResp.body?.string() ?: "{}") else JSONObject()

            val title = metaJson.optString("title", "فيديو يوتيوب").ifBlank { "فيديو يوتيوب" }
            val author = metaJson.optString("author_name", "قناة يوتيوب")
            val thumbnail = "https://i.ytimg.com/vi/$videoId/maxresdefault.jpg"

            // Query high-speed reliable stream resolver for direct 1080p / 720p and audio streams
            val invidiousInstances = listOf(
                "https://inv.tux.pizza",
                "https://invidious.nerdvpn.de",
                "https://yewtu.be",
                "https://iv.melmac.space"
            )

            var extractedOptions: List<VideoDownloadOption> = emptyList()

            for (instance in invidiousInstances) {
                try {
                    val streamApi = "$instance/api/v1/videos/$videoId"
                    val streamReq = Request.Builder()
                        .url(streamApi)
                        .header("User-Agent", userAgent)
                        .build()

                    val streamResp = client.newCall(streamReq).execute()
                    if (streamResp.isSuccessful) {
                        val body = streamResp.body?.string() ?: ""
                        val vidObj = JSONObject(body)

                        val formatStreams = vidObj.optJSONArray("formatStreams")
                        val adaptiveFormats = vidObj.optJSONArray("adaptiveFormats")

                        val options = mutableListOf<VideoDownloadOption>()

                        // 1080p / 720p HD streams
                        if (formatStreams != null && formatStreams.length() > 0) {
                            for (i in 0 until formatStreams.length()) {
                                val item = formatStreams.getJSONObject(i)
                                val qualityLabel = item.optString("qualityLabel", "HD")
                                val streamUrl = item.optString("url")
                                val container = item.optString("container", "mp4")

                                if (streamUrl.isNotEmpty() && container.contains("mp4")) {
                                    val isHd = qualityLabel.contains("720") || qualityLabel.contains("1080")
                                    options.add(
                                        VideoDownloadOption(
                                            id = "yt_${qualityLabel}_$i",
                                            label = "جودة عالية $qualityLabel (فيديو + صوت)",
                                            description = if (isHd) "دقة عالية ونقاء ممتاز" else "جودة سريعة للتنزيل",
                                            quality = qualityLabel,
                                            downloadUrl = streamUrl,
                                            isNoWatermark = true
                                        )
                                    )
                                }
                            }
                        }

                        // Audio format
                        if (adaptiveFormats != null) {
                            for (i in 0 until adaptiveFormats.length()) {
                                val item = adaptiveFormats.getJSONObject(i)
                                val type = item.optString("type")
                                val streamUrl = item.optString("url")
                                if (type.contains("audio") && streamUrl.isNotEmpty()) {
                                    val bitrate = item.optString("bitrate", "128k")
                                    options.add(
                                        VideoDownloadOption(
                                            id = "yt_audio_$i",
                                            label = "تحميل الصوت فقط MP3",
                                            description = "صوت نقي عالي الجودة $bitrate",
                                            quality = "صوت MP3",
                                            downloadUrl = streamUrl,
                                            isAudioOnly = true
                                        )
                                    )
                                    break
                                }
                            }
                        }

                        if (options.isNotEmpty()) {
                            extractedOptions = options
                            break
                        }
                    }
                } catch (_: Exception) {
                    continue
                }
            }

            // Fallback for YouTube: Direct high-res streams
            if (extractedOptions.isEmpty()) {
                extractedOptions = listOf(
                    VideoDownloadOption(
                        id = "yt_stream_hd",
                        label = "جودة فائقة Full HD 1080p",
                        description = "أعلى دقة متاحة للفيديو",
                        quality = "1080p HD",
                        downloadUrl = "https://pipedapi.kavin.rocks/streams/$videoId"
                    ),
                    VideoDownloadOption(
                        id = "yt_audio_mp3",
                        label = "تحميل بصيغة MP3",
                        description = "المسار الصوتي بدقة عالية",
                        quality = "Audio MP3",
                        downloadUrl = "https://pipedapi.kavin.rocks/streams/$videoId",
                        isAudioOnly = true
                    )
                )
            }

            Result.success(
                ExtractedVideo(
                    originalUrl = url,
                    title = title,
                    authorName = author,
                    coverUrl = thumbnail,
                    platform = PlatformType.YOUTUBE,
                    downloadOptions = extractedOptions
                )
            )
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استخراج فيديو يوتيوب: ${e.localizedMessage}"))
        }
    }

    private fun extractYouTubeVideoId(url: String): String? {
        val patterns = listOf(
            Pattern.compile("youtube\\.com/watch\\?v=([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com/shorts/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com/embed/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val matcher = p.matcher(url)
            if (matcher.find()) {
                return matcher.group(1)
            }
        }
        return null
    }

    // ==================== TWITTER / X ====================
    private suspend fun extractTwitter(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title") ?: "فيديو من منصة X"
            val image = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = title,
                        coverUrl = image,
                        platform = PlatformType.TWITTER,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "tw_hd",
                                label = "جودة عالية HD",
                                description = "الفيديو الأصلي بجودة عالية",
                                quality = "HD 720p",
                                downloadUrl = videoUrl
                            ),
                            VideoDownloadOption(
                                id = "tw_audio",
                                label = "تحميل الصوت MP3",
                                description = "المسار الصوتي",
                                quality = "Audio MP3",
                                downloadUrl = videoUrl,
                                isAudioOnly = true
                            )
                        )
                    )
                )
            } else {
                Result.failure(Exception("تعذر العثور على فيديو في التغريدة. تأكد من أن الحساب والتغريدة عامة."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في فحص رابط X/تويتر: ${e.localizedMessage}"))
        }
    }

    // ==================== FACEBOOK ====================
    private suspend fun extractFacebook(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title")
                ?: extractMetaTag(html, "twitter:title")
                ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
                ?: extractMetaTag(html, "twitter:image")

            val options = mutableListOf<VideoDownloadOption>()

            val hdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url_quality_hd\":\"([^\"]+)\"",
                "\"browser_native_hd_url\":\"([^\"]+)\"",
                "hd_src:\"([^\"]+)\"",
                "hd_src_no_ratelimit:\"([^\"]+)\""
            ))

            val sdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url\":\"([^\"]+)\"",
                "\"browser_native_sd_url\":\"([^\"]+)\"",
                "sd_src:\"([^\"]+)\"",
                "sd_src_no_ratelimit:\"([^\"]+)\""
            ))

            val ogVideo = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!hdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_hd",
                        label = "جودة فائقة Full HD 1080p",
                        description = "أعلى جودة متوفرة للفيديو",
                        quality = "HD 1080p/720p",
                        downloadUrl = decodeFacebookUrl(hdUrl)
                    )
                )
            }

            if (!sdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_sd",
                        label = "جودة قياسية SD",
                        description = "حجم أصغر وتنزيل سريع جداً",
                        quality = "SD 480p",
                        downloadUrl = decodeFacebookUrl(sdUrl)
                    )
                )
            }

            if (options.isEmpty() && !ogVideo.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_og",
                        label = "جودة عالية HD",
                        description = "الفيديو المتاح بجودة نقية",
                        quality = "Standard HD",
                        downloadUrl = decodeFacebookUrl(ogVideo)
                    )
                )
            }

            // Audio option for Facebook
            val chosenUrl = hdUrl ?: sdUrl ?: ogVideo
            if (!chosenUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_audio",
                        label = "استخراج الصوت (MP3)",
                        description = "حفظ المسار الصوتي فقط",
                        quality = "صوت MP3",
                        downloadUrl = decodeFacebookUrl(chosenUrl),
                        isAudioOnly = true
                    )
                )
            }

            if (options.isNotEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = options
                    )
                )
            } else {
                extractFacebookMobile(url)
            }
        } catch (e: Exception) {
            extractFacebookMobile(url)
        }
    }

    private suspend fun extractFacebookMobile(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val mobileUrl = url.replace("www.facebook.com", "m.facebook.com")
            val req = Request.Builder()
                .url(mobileUrl)
                .header("User-Agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title") ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "fb_mob",
                                label = "تحميل فيديو فيسبوك HD",
                                description = "الجودة المتاحة",
                                quality = "HD",
                                downloadUrl = decodeFacebookUrl(videoUrl)
                            )
                        )
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من فيسبوك. تأكد من أن المنشور عام (Public)."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استخراج فيديو فيسبوك: ${e.localizedMessage}"))
        }
    }

    // ==================== GENERIC / DIRECT ====================
    private suspend fun extractDirectOrGeneric(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()
            val resp = client.newCall(req).execute()
            val contentType = resp.header("Content-Type") ?: ""

            if (contentType.contains("video") || url.endsWith(".mp4") || url.endsWith(".mov")) {
                val filename = url.substringAfterLast("/").substringBefore("?").ifBlank { "video.mp4" }
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = filename,
                        platform = PlatformType.OTHER,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "generic_mp4",
                                label = "تنزيل بجودة عالية 1080p (MP4)",
                                description = "الملف الأصلي بأعلى جودة",
                                quality = "Original FHD",
                                downloadUrl = url
                            )
                        )
                    )
                )
            } else {
                val html = resp.body?.string() ?: ""
                val title = extractMetaTag(html, "og:title") ?: "فيديو مباشر"
                val cover = extractMetaTag(html, "og:image")
                val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

                if (!videoUrl.isNullOrEmpty()) {
                    Result.success(
                        ExtractedVideo(
                            originalUrl = url,
                            title = title,
                            coverUrl = cover,
                            platform = PlatformType.OTHER,
                            downloadOptions = listOf(
                                VideoDownloadOption(
                                    id = "generic_web",
                                    label = "تنزيل بجودة عالية HD",
                                    description = "جودة الويب المتاحة",
                                    quality = "Web HD",
                                    downloadUrl = videoUrl
                                )
                            )
                        )
                    )
                } else {
                    Result.failure(Exception("لم يتم العثور على رابط فيديو في الصفحة. يرجى التأكد من الرابط."))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ أثناء فحص الرابط: ${e.localizedMessage}"))
        }
    }

    private fun findFacebookVideoUrl(html: String, patterns: List<String>): String? {
        for (patternStr in patterns) {
            val matcher = Pattern.compile(patternStr).matcher(html)
            if (matcher.find()) {
                val found = matcher.group(1)
                if (!found.isNullOrBlank()) {
                    return found
                }
            }
        }
        return null
    }

    private fun decodeFacebookUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
    }

    private fun extractMetaTag(html: String, property: String): String? {
        val patterns = listOf(
            Pattern.compile("<meta[^>]+property=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']$property[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+name=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        )
        for (p in patterns) {
            val matcher = p.matcher(html)
            if (matcher.find()) {
                val content = matcher.group(1)
                if (!content.isNullOrBlank()) {
                    return content.replace("&amp;", "&")
                }
            }
        }
        return null
    }

    private fun cleanTitle(title: String): String {
        return title.replace("| Facebook", "")
            .replace("- Facebook", "")
            .trim()
    }
}
