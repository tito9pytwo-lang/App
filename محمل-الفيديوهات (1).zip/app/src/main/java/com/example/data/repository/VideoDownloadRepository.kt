package com.example.data.repository

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.TimeUnit

class VideoDownloadRepository(
    private val downloadDao: DownloadDao,
    private val videoExtractor: VideoExtractor = VideoExtractor()
) {

    // Optimized HTTP client for high-speed video streaming
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()

    fun getDownloadsByPlatform(platform: String): Flow<List<DownloadEntity>> =
        downloadDao.getDownloadsByPlatform(platform)

    suspend fun extractVideo(url: String): Result<ExtractedVideo> {
        return videoExtractor.extract(url)
    }

    /**
     * Downloads video with high-speed 64KB buffering directly into device public MediaStore
     * so it appears instantly in the phone's native Gallery / Studio app!
     */
    suspend fun downloadAndSave(
        context: Context,
        video: ExtractedVideo,
        option: VideoDownloadOption,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        try {
            val extension = if (option.isAudioOnly) "mp3" else "mp4"
            val mimeType = if (option.isAudioOnly) "audio/mp3" else "video/mp4"

            val sanitizedTitle = video.title
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .take(45)
                .trim()
                .ifBlank { "video_${System.currentTimeMillis()}" }

            val fileName = "${video.platform.name.lowercase()}_${sanitizedTitle}_${System.currentTimeMillis()}.$extension"

            val request = Request.Builder()
                .url(option.downloadUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .header("Referer", video.originalUrl)
                .header("Accept", "*/*")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("استجابة الخادم غير ناجحة: ${response.code}"))
            }

            val body = response.body ?: return@withContext Result.failure(Exception("محتوى ملف التحميل فارغ"))
            val totalBytes = body.contentLength()
            var downloadedBytes = 0L

            var finalLocalPath: String
            var contentUri: Uri? = null

            // Use 64KB chunk buffer for optimized download throughput
            val buffer = ByteArray(65536)
            var bytesRead: Int
            val inputStream: InputStream = body.byteStream()
            val startTime = System.currentTimeMillis()
            var lastUpdate = 0L

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ (Q+) MediaStore Public Insertion -> Directly into Phone's Studio/Gallery app
                val relativeFolder = if (option.isAudioOnly) {
                    "${Environment.DIRECTORY_MUSIC}/VideoDownloader"
                } else {
                    "${Environment.DIRECTORY_MOVIES}/VideoDownloader"
                }

                val collection = if (option.isAudioOnly) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                contentUri = context.contentResolver.insert(collection, values)
                    ?: return@withContext Result.failure(Exception("تعذر إنشاء مسار في استوديو الهاتف"))

                val outputStream: OutputStream = context.contentResolver.openOutputStream(contentUri)
                    ?: return@withContext Result.failure(Exception("تعذر فتح ملف الكتابة في استوديو الهاتف"))

                outputStream.use { out ->
                    inputStream.use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                            downloadedBytes += bytesRead

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate > 120) {
                                lastUpdate = now
                                val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                                val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                                val progress = if (totalBytes > 0) {
                                    (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    0.5f
                                }

                                onProgress(
                                    DownloadProgress(
                                        percentage = progress,
                                        downloadedBytes = downloadedBytes,
                                        totalBytes = totalBytes,
                                        speedKbps = speedKbps,
                                        statusText = "جارٍ التنزيل في الاستوديو... ${(progress * 100).toInt()}%"
                                    )
                                )
                            }
                        }
                        out.flush()
                    }
                }

                // Mark video as ready in MediaStore so Phone Studio/Gallery indexes it immediately
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(contentUri, values, null, null)

                finalLocalPath = contentUri.toString()
            } else {
                // Android 9 and lower: Public Movies directory
                @Suppress("DEPRECATION")
                val publicDir = Environment.getExternalStoragePublicDirectory(
                    if (option.isAudioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
                )
                val targetDir = File(publicDir, "VideoDownloader")
                if (!targetDir.exists()) targetDir.mkdirs()

                val targetFile = File(targetDir, fileName)
                val outputStream = FileOutputStream(targetFile)

                outputStream.use { out ->
                    inputStream.use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                            downloadedBytes += bytesRead

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate > 120) {
                                lastUpdate = now
                                val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                                val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                                val progress = if (totalBytes > 0) {
                                    (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    0.5f
                                }

                                onProgress(
                                    DownloadProgress(
                                        percentage = progress,
                                        downloadedBytes = downloadedBytes,
                                        totalBytes = totalBytes,
                                        speedKbps = speedKbps,
                                        statusText = "جارٍ التنزيل في الاستوديو... ${(progress * 100).toInt()}%"
                                    )
                                )
                            }
                        }
                        out.flush()
                    }
                }

                finalLocalPath = targetFile.absolutePath

                // Trigger MediaScanner so Gallery shows it instantly
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetFile.absolutePath),
                    arrayOf(mimeType),
                    null
                )
            }

            // Save to Room DB
            val entity = DownloadEntity(
                title = video.title,
                sourceUrl = video.originalUrl,
                downloadUrl = option.downloadUrl,
                localFilePath = finalLocalPath,
                platform = video.platform.name,
                thumbnailUrl = video.coverUrl,
                fileSizeBytes = downloadedBytes,
                durationSeconds = video.durationSeconds,
                downloadTimestamp = System.currentTimeMillis(),
                qualityLabel = option.quality,
                isAudio = option.isAudioOnly
            )

            val newId = downloadDao.insert(entity)
            Result.success(entity.copy(id = newId))
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Download failed", e)
            Result.failure(e)
        }
    }

    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            if (entity.localFilePath.startsWith("content://")) {
                val uri = Uri.parse(entity.localFilePath)
                context.contentResolver.delete(uri, null, null)
            } else {
                val file = File(entity.localFilePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            downloadDao.deleteById(entity.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete file", e)
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                if (!file.exists()) return
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }

            val mimeType = if (entity.isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, entity.title)
                putExtra(Intent.EXTRA_TEXT, "تم التحميل بواسطة تطبيق محمل الفيديوهات")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة الفيديو عبر")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Share failed", e)
        }
    }

    fun openInPhoneGallery(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }

            val mimeType = if (entity.isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Open in gallery failed", e)
        }
    }
}
