package com.example.data.remote

import android.util.Log
import androidx.core.text.HtmlCompat
import com.example.data.model.ExtractedVideo
import com.example.data.model.PlatformType
import com.example.data.model.VideoDownloadOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class VideoExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val userAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    private val ytAndroidVrUserAgent =
        "com.google.android.youtube/1.60.19 (Linux; U; Android 12L) gzip"

    private val ytAndroidUserAgent =
        "com.google.android.youtube/20.10.38 (Linux; U; Android 13) gzip"

    suspend fun extract(inputUrl: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = cleanUrl(inputUrl)
            if (cleanUrl.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("يرجى إدخال رابط صالح"))
            }

            val platform = detectPlatform(cleanUrl)
            when (platform) {
                PlatformType.TIKTOK -> extractTikTok(cleanUrl)
                PlatformType.FACEBOOK -> extractFacebook(cleanUrl)
                PlatformType.INSTAGRAM -> extractInstagram(cleanUrl)
                PlatformType.YOUTUBE -> extractYouTube(cleanUrl)
                PlatformType.TWITTER -> extractTwitter(cleanUrl)
                PlatformType.OTHER -> extractDirectOrGeneric(cleanUrl)
            }
        } catch (e: Exception) {
            Log.e("VideoExtractor", "Error extracting video", e)
            Result.failure(Exception(e.message ?: "تعذر استخراج بيانات الفيديو، يرجى التأكد من أن الرابط عام."))
        }
    }

    private fun detectPlatform(url: String): PlatformType {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") || lower.contains("douyin.com") -> PlatformType.TIKTOK
            lower.contains("facebook.com") || lower.contains("fb.watch") || lower.contains("fb.com") -> PlatformType.FACEBOOK
            lower.contains("instagram.com") || lower.contains("instagr.am") -> PlatformType.INSTAGRAM
            lower.contains("youtube.com") || lower.contains("youtu.be") -> PlatformType.YOUTUBE
            lower.contains("twitter.com") || lower.contains("x.com") -> PlatformType.TWITTER
            else -> PlatformType.OTHER
        }
    }

    private fun cleanUrl(input: String): String {
        val trimmed = input.trim()
        val matcher = Pattern.compile("https?://[^\\s\"'<>]+").matcher(trimmed)
        return if (matcher.find()) {
            matcher.group(0)?.trimEnd('.', ',', ')', ']') ?: ""
        } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            ""
        }
    }

    // ==================== TIKTOK ====================
    private suspend fun extractTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(url, "UTF-8")
            val apiUrl = "https://www.tikwm.com/api/?url=$encoded&count=12&cursor=0&web=1&hd=1"

            val request = Request.Builder()
                .url(apiUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful && body.isNotEmpty()) {
                val json = JSONObject(body)
                val code = json.optInt("code", -1)
                if (code == 0 && json.has("data")) {
                    val data = json.getJSONObject("data")
                    val title = data.optString("title", "فيديو تيك توك").ifBlank { "فيديو تيك توك" }
                    val cover = data.optString("cover")
                    val duration = data.optInt("duration", 0)

                    val author = data.optJSONObject("author")
                    val authorName = author?.optString("nickname")?.ifBlank { null }
                        ?: author?.optString("unique_id")?.ifBlank { null }
                        ?: "مستخدم تيك توك"
                    val authorAvatar = author?.optString("avatar")

                    val options = mutableListOf<VideoDownloadOption>()

                    val hdUrl = data.optString("hdplay")
                    if (hdUrl.isNotEmpty()) {
                        val fixedHd = if (hdUrl.startsWith("http")) hdUrl else "https://www.tikwm.com$hdUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_hd",
                                label = "جودة فائقة Full HD 1080p (بدون علامة)",
                                description = "أعلى دقة متوفرة مع أنقى صورة",
                                quality = "Full HD 1080p",
                                downloadUrl = fixedHd,
                                isNoWatermark = true
                            )
                        )
                    }

                    val playUrl = data.optString("play")
                    if (playUrl.isNotEmpty()) {
                        val fixedUrl = if (playUrl.startsWith("http")) playUrl else "https://www.tikwm.com$playUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_nowm",
                                label = "جودة عالية HD (بدون علامة مائية)",
                                description = "تنزيل سريع بجودة ممتازة وحجم متوازن",
                                quality = "HD 720p",
                                downloadUrl = fixedUrl,
                                isNoWatermark = true
                            )
                        )
                    }

                    val wmUrl = data.optString("wmplay")
                    if (wmUrl.isNotEmpty()) {
                        val fixedWm = if (wmUrl.startsWith("http")) wmUrl else "https://www.tikwm.com$wmUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_wm",
                                label = "النسخة الأصلية مع العلامة",
                                description = "الفيديو مع لوجو تيك توك واسم الحساب",
                                quality = "Original",
                                downloadUrl = fixedWm,
                                isNoWatermark = false
                            )
                        )
                    }

                    val musicUrl = data.optString("music")
                    if (musicUrl.isNotEmpty()) {
                        val fixedMusic = if (musicUrl.startsWith("http")) musicUrl else "https://www.tikwm.com$musicUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_audio",
                                label = "استخراج الصوت فقط (MP3)",
                                description = "ملف صوتي عالي النقاء 320kbps",
                                quality = "صوت MP3",
                                downloadUrl = fixedMusic,
                                isAudioOnly = true,
                                fileExtension = "mp3",
                                mimeType = "audio/mpeg"
                            )
                        )
                    }

                    if (options.isNotEmpty()) {
                        return@withContext Result.success(
                            ExtractedVideo(
                                originalUrl = url,
                                title = title,
                                authorName = authorName,
                                authorAvatar = authorAvatar,
                                coverUrl = cover,
                                durationSeconds = duration,
                                platform = PlatformType.TIKTOK,
                                downloadOptions = options
                            )
                        )
                    }
                }
            }

            fallbackTikTok(url)
        } catch (e: Exception) {
            fallbackTikTok(url)
        }
    }

    private suspend fun fallbackTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).header("User-Agent", userAgent).build()
            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = decodeHtmlEntities(extractMetaTag(html, "og:title")) ?: "فيديو تيك توك"
            val image = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                val option = VideoDownloadOption(
                    id = "tt_fallback",
                    label = "تنزيل بجودة عالية HD",
                    description = "الملف الأصلي المتاح",
                    quality = "HD",
                    downloadUrl = videoUrl
                )
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = title,
                        coverUrl = image,
                        platform = PlatformType.TIKTOK,
                        downloadOptions = listOf(option)
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من تيك توك. يرجى التأكد من الرابط."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("فشل فحص رابط تيك توك: ${e.localizedMessage}"))
        }
    }

    // ==================== INSTAGRAM ====================
    private suspend fun extractInstagram(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val normalizedUrl = normalizeInstagramUrl(url)
            val initialShortcode = extractInstagramShortcode(normalizedUrl)

            // Primary attempt: Fetch full Instagram web page with browser navigation headers.
            // Instagram embeds full media JSON (video_versions, video_dash_manifest, caption, user) inside <script type="application/json">.
            val primaryFetch = fetchInstagramHtml(normalizedUrl)
            var html = primaryFetch.first
            var finalUrl = primaryFetch.second
            val finalShortcode = extractInstagramShortcode(finalUrl) ?: initialShortcode

            var parsed = parseInstagramFromHtml(html, finalUrl, finalShortcode)

            // Secondary attempt: If URL was /reel/ or /tv/ and yielded no video, try canonical /p/<shortcode>/
            if (parsed == null && finalShortcode != null) {
                val canonicalPostUrl = "https://www.instagram.com/p/$finalShortcode/"
                if (!finalUrl.contains("/p/$finalShortcode")) {
                    val altFetch = fetchInstagramHtml(canonicalPostUrl)
                    val altParsed = parseInstagramFromHtml(altFetch.first, altFetch.second, finalShortcode)
                    if (altParsed != null) {
                        parsed = altParsed
                        html = altFetch.first
                    }
                }
            }

            // Tertiary attempt: Try /embed/captioned/ with full browser navigation headers
            if (parsed == null && finalShortcode != null) {
                val embedUrl = "https://www.instagram.com/p/$finalShortcode/embed/captioned/"
                val embedFetch = fetchInstagramHtml(embedUrl)
                val embedParsed = parseInstagramFromHtml(embedFetch.first, embedFetch.second, finalShortcode)
                if (embedParsed != null) {
                    parsed = embedParsed
                }
            }

            if (parsed != null) {
                Result.success(parsed)
            } else {
                val errorReason = when {
                    finalUrl.contains("/accounts/login") ->
                        "طلب انستغرام تسجيل الدخول؛ تأكد من أن الحساب والفيديو عام (Public) وأعد المحاولة."
                    html.contains("EmbedBrokenMedia") || html.contains("Sorry, this page isn't available") ->
                        "هذا الرابط غير متاح أو تم حذف المنشور من انستغرام."
                    !extractMetaTag(html, "og:image").isNullOrEmpty() &&
                        !html.contains("video_versions") &&
                        !html.contains("video_url") ->
                        "هذا المنشور عبارة عن صورة فقط ولا يحتوي على فيديو."
                    else ->
                        "تعذر استخراج فيديو انستغرام. تأكد من أن الحساب والمنشور عام (Public)."
                }
                Result.failure(Exception(errorReason))
            }
        } catch (e: Exception) {
            Log.e("VideoExtractor", "Instagram extract error", e)
            Result.failure(Exception("خطأ في قراءة فيديو انستغرام: ${e.localizedMessage}"))
        }
    }

    private fun normalizeInstagramUrl(url: String): String {
        var result = url.replace("m.instagram.com", "www.instagram.com")
            .replace("://instagram.com", "://www.instagram.com")
        // Keep query params for /share/ links since they can carry share tokens, otherwise strip tracking params
        if (!result.contains("/share/")) {
            result = result.substringBefore("?")
            if (!result.endsWith("/")) result += "/"
        }
        return result
    }

    private fun extractInstagramShortcode(url: String): String? {
        val matcher = Pattern.compile("/(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)").matcher(url)
        return if (matcher.find()) matcher.group(1) else null
    }

    private fun fetchInstagramHtml(targetUrl: String): Pair<String, String> {
        val req = Request.Builder()
            .url(targetUrl)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
            .header("Sec-Fetch-Dest", "document")
            .header("Sec-Fetch-Mode", "navigate")
            .header("Sec-Fetch-Site", "none")
            .header("Sec-Fetch-User", "?1")
            .header("Upgrade-Insecure-Requests", "1")
            .build()

        client.newCall(req).execute().use { resp ->
            val html = resp.body?.string() ?: ""
            val finalUrl = resp.request.url.toString()
            return html to finalUrl
        }
    }

    private fun parseInstagramFromHtml(
        html: String,
        originalUrl: String,
        targetShortcode: String?
    ): ExtractedVideo? {
        if (html.isBlank()) return null

        var coverUrl = extractMetaTag(html, "og:image")
            ?: extractMetaTag(html, "twitter:image")
        val metaTitle = decodeHtmlEntities(
            extractMetaTag(html, "og:title") ?: extractMetaTag(html, "twitter:title")
        )
        val metaDesc = decodeHtmlEntities(extractMetaTag(html, "og:description"))

        var title: String? = null
        var authorName: String? = null
        var authorAvatar: String? = null
        var durationSeconds = 0
        var originalWidth = 0
        var originalHeight = 0
        val options = mutableListOf<VideoDownloadOption>()

        // 1. Parse embedded <script type="application/json"> RelayPrefetchedStreamCache blocks
        val scriptMatcher = Pattern.compile(
            "<script[^>]*type=[\"']application/json[\"'][^>]*>(.*?)</script>",
            Pattern.DOTALL or Pattern.CASE_INSENSITIVE
        ).matcher(html)

        var matchedMedia: JSONObject? = null
        while (scriptMatcher.find()) {
            val jsonText = scriptMatcher.group(1) ?: continue
            if (!jsonText.contains("video_versions") && !jsonText.contains("video_url")) continue
            try {
                val root = JSONObject(jsonText)
                val found = findInstagramMediaObject(root, targetShortcode)
                if (found != null) {
                    matchedMedia = found
                    break
                }
            } catch (_: Exception) {
            }
        }

        if (matchedMedia != null) {
            val userObj = matchedMedia.optJSONObject("user")
            val username = userObj?.optString("username")?.ifBlank { null }
            val fullName = userObj?.optString("full_name")?.ifBlank { null }
            authorName = when {
                !fullName.isNullOrBlank() && !username.isNullOrBlank() -> "$fullName (@$username)"
                !username.isNullOrBlank() -> "@$username"
                !fullName.isNullOrBlank() -> fullName
                else -> null
            }
            authorAvatar = userObj?.optString("profile_pic_url")?.ifBlank { null }
                ?: userObj?.optString("profile_image_uri")?.ifBlank { null }

            val captionObj = matchedMedia.optJSONObject("caption")
            val captionText = captionObj?.optString("text")?.trim()?.ifBlank { null }
            if (!captionText.isNullOrBlank()) {
                title = captionText
            }

            if (coverUrl.isNullOrEmpty()) {
                val candidates = matchedMedia.optJSONObject("image_versions2")?.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    coverUrl = candidates.getJSONObject(0).optString("url").ifBlank { null }
                }
            }

            durationSeconds = matchedMedia.optDouble("video_duration", 0.0).toInt()
            originalWidth = matchedMedia.optInt("original_width", 0)
            originalHeight = matchedMedia.optInt("original_height", 0)

            // Parse progressive MP4 video_versions (sorted highest quality first)
            val videoVersions = matchedMedia.optJSONArray("video_versions")
            val progressiveUrls = extractInstagramVideoVersions(videoVersions)

            // Parse DASH manifest if present for real AAC audio track (and optional 1080p stream)
            val dashManifest = matchedMedia.optString("video_dash_manifest")
            val dashStreams = if (dashManifest.isNotBlank()) parseInstagramDashManifest(dashManifest) else null

            val bestDashVideo = dashStreams?.first
            val dashAudioUrl = dashStreams?.second

            if (bestDashVideo != null && dashAudioUrl != null && bestDashVideo.height > maxOf(originalWidth, originalHeight).coerceAtMost(1080)) {
                // Only add DASH muxed if it genuinely provides higher resolution than progressive
                options.add(
                    VideoDownloadOption(
                        id = "ig_dash_fhd",
                        label = "جودة فائقة Full HD (${bestDashVideo.label})",
                        description = "أعلى دقة متوفرة من انستغرام (فيديو + صوت)",
                        quality = bestDashVideo.label,
                        downloadUrl = bestDashVideo.url,
                        audioStreamUrl = dashAudioUrl,
                        isNoWatermark = true,
                        customUserAgent = userAgent
                    )
                )
            }

            if (progressiveUrls.isNotEmpty()) {
                val resLabel = formatResolutionLabel(originalWidth, originalHeight)
                options.add(
                    VideoDownloadOption(
                        id = "ig_hd",
                        label = "جودة عالية $resLabel (تنزيل مباشر)",
                        description = "الفيديو الأصلي بجودة نقية بدون علامة",
                        quality = resLabel,
                        downloadUrl = progressiveUrls.first(),
                        isNoWatermark = true,
                        customUserAgent = userAgent
                    )
                )

                if (progressiveUrls.size > 1 && progressiveUrls.last() != progressiveUrls.first()) {
                    options.add(
                        VideoDownloadOption(
                            id = "ig_sd",
                            label = "جودة سريعة (حجم أقل)",
                            description = "نسخة مضغوطة للتنزيل السريع",
                            quality = "SD",
                            downloadUrl = progressiveUrls.last(),
                            isNoWatermark = true,
                            customUserAgent = userAgent
                        )
                    )
                }
            } else if (bestDashVideo != null && dashAudioUrl != null) {
                options.add(
                    VideoDownloadOption(
                        id = "ig_dash_hd",
                        label = "جودة عالية ${bestDashVideo.label} (فيديو + صوت)",
                        description = "أعلى جودة متوفرة من ريلز انستغرام",
                        quality = bestDashVideo.label,
                        downloadUrl = bestDashVideo.url,
                        audioStreamUrl = dashAudioUrl,
                        isNoWatermark = true,
                        customUserAgent = userAgent
                    )
                )
            }

            // Real audio-only option
            if (!dashAudioUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "ig_audio",
                        label = "استخراج الصوت فقط (M4A)",
                        description = "المسار الصوتي الأصلي للريلز بجودة عالية",
                        quality = "صوت M4A",
                        downloadUrl = dashAudioUrl,
                        isAudioOnly = true,
                        fileExtension = "m4a",
                        mimeType = "audio/mp4",
                        customUserAgent = userAgent
                    )
                )
            } else if (progressiveUrls.isNotEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "ig_audio_mp4",
                        label = "حفظ الصوت (M4A)",
                        description = "الصوت الأصلي للفيديو",
                        quality = "صوت",
                        downloadUrl = progressiveUrls.first(),
                        isAudioOnly = true,
                        fileExtension = "m4a",
                        mimeType = "audio/mp4",
                        customUserAgent = userAgent
                    )
                )
            }
        }

        // 2. Regex fallback directly on HTML (handles embed/captioned or partial JSON responses)
        if (options.isEmpty()) {
            val vvMatcher = Pattern.compile("\"video_versions\"\\s*:\\s*(\\[[^\\]]+\\])").matcher(html)
            if (vvMatcher.find()) {
                try {
                    val arr = JSONArray(vvMatcher.group(1))
                    val urls = extractInstagramVideoVersions(arr)
                    if (urls.isNotEmpty()) {
                        options.add(
                            VideoDownloadOption(
                                id = "ig_hd_raw",
                                label = "جودة عالية HD (الأصلية)",
                                description = "أعلى جودة من ريلز انستغرام",
                                quality = "HD",
                                downloadUrl = urls.first(),
                                isNoWatermark = true,
                                customUserAgent = userAgent
                            )
                        )
                    }
                } catch (_: Exception) {
                }
            }
        }

        if (options.isEmpty()) {
            val videoUrlMatcher = Pattern.compile("\"video_url\"\\s*:\\s*\"([^\"]+)\"").matcher(html)
            val htmlVideoTag = Pattern.compile("<video[^>]+src=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE).matcher(html)
            val fallbackUrl = when {
                videoUrlMatcher.find() -> decodeEscapedUrl(videoUrlMatcher.group(1) ?: "")
                htmlVideoTag.find() -> htmlVideoTag.group(1)?.replace("&amp;", "&")
                else -> extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:secure_url")
            }

            if (!fallbackUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "ig_hd_fb",
                        label = "جودة عالية HD (الأصلية)",
                        description = "أعلى جودة من انستغرام",
                        quality = "HD",
                        downloadUrl = fallbackUrl,
                        isNoWatermark = true,
                        customUserAgent = userAgent
                    )
                )
            }
        }

        if (options.isEmpty()) return null

        // Build clean title & author fallback from OG meta tags if JSON didn't provide them
        if (authorName.isNullOrBlank()) {
            val embedAuthor = Pattern.compile("<div[^>]+class=[\"'][^\"']*UsernameText[^\"']*[\"'][^>]*>([^<]+)</div>").matcher(html)
            if (embedAuthor.find()) {
                authorName = embedAuthor.group(1)?.trim()
            } else if (!metaTitle.isNullOrBlank()) {
                val atMatch = Pattern.compile("\\(@([A-Za-z0-9_.]+)\\)").matcher(metaTitle)
                val onIgMatch = Pattern.compile("^(.+?)\\s+on Instagram:", Pattern.CASE_INSENSITIVE).matcher(metaTitle)
                authorName = when {
                    atMatch.find() -> "@${atMatch.group(1)}"
                    onIgMatch.find() -> onIgMatch.group(1)?.trim()
                    else -> "انستغرام"
                }
            } else {
                authorName = "انستغرام"
            }
        }

        if (coverUrl.isNullOrEmpty()) {
            val imgMatcher = Pattern.compile(
                "<img[^>]+class=[\"'][^\"']*EmbeddedMediaImage[^\"']*[\"'][^>]+src=[\"']([^\"']+)[\"']"
            ).matcher(html)
            if (imgMatcher.find()) {
                coverUrl = imgMatcher.group(1)?.replace("&amp;", "&")
            }
        }

        val finalTitle = title?.take(140)
            ?: metaTitle?.replace("on Instagram:", "")?.trim()?.ifBlank { null }
            ?: metaDesc?.take(140)
            ?: "فيديو ريلز انستغرام"

        return ExtractedVideo(
            originalUrl = originalUrl,
            title = finalTitle,
            authorName = authorName,
            authorAvatar = authorAvatar,
            coverUrl = coverUrl,
            durationSeconds = durationSeconds,
            platform = PlatformType.INSTAGRAM,
            downloadOptions = options
        )
    }

    private fun findInstagramMediaObject(node: Any?, targetShortcode: String?): JSONObject? {
        var firstFallback: JSONObject? = null

        fun search(current: Any?): JSONObject? {
            when (current) {
                is JSONObject -> {
                    if (current.has("video_versions")) {
                        val vv = current.optJSONArray("video_versions")
                        if (vv != null && vv.length() > 0) {
                            val code = current.optString("code")
                            if (targetShortcode == null || code == targetShortcode) {
                                return current
                            }
                            if (firstFallback == null) {
                                firstFallback = current
                            }
                        }
                    }
                    val keys = current.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val res = search(current.opt(key))
                        if (res != null) return res
                    }
                }
                is JSONArray -> {
                    for (i in 0 until current.length()) {
                        val res = search(current.opt(i))
                        if (res != null) return res
                    }
                }
            }
            return null
        }

        return search(node) ?: firstFallback
    }

    private fun extractInstagramVideoVersions(arr: JSONArray?): List<String> {
        if (arr == null || arr.length() == 0) return emptyList()
        data class Item(val type: Int, val width: Int, val url: String)
        val items = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val u = decodeEscapedUrl(obj.optString("url"))
            if (u.startsWith("http")) {
                items.add(Item(obj.optInt("type", 999), obj.optInt("width", 0), u))
            }
        }
        // In Instagram video_versions, type 101 is typically highest progressive HD, or higher width is better
        return items
            .sortedWith(compareByDescending<Item> { it.width }.thenBy { it.type })
            .map { it.url }
            .distinct()
    }

    private data class DashVideoCandidate(val height: Int, val bandwidth: Int, val label: String, val url: String)

    private fun parseInstagramDashManifest(manifest: String): Pair<DashVideoCandidate?, String?> {
        var bestVideo: DashVideoCandidate? = null
        var bestAudioUrl: String? = null
        var bestAudioBw = -1

        val repMatcher = Pattern.compile("<Representation([^>]*)>(.*?)</Representation>", Pattern.DOTALL).matcher(manifest)
        while (repMatcher.find()) {
            val attrs = repMatcher.group(1) ?: ""
            val inner = repMatcher.group(2) ?: ""
            val baseUrlMatcher = Pattern.compile("<BaseURL>(.*?)</BaseURL>", Pattern.DOTALL).matcher(inner)
            if (!baseUrlMatcher.find()) continue
            val rawBaseUrl = (baseUrlMatcher.group(1) ?: "").replace("&amp;", "&").trim()
            if (!rawBaseUrl.startsWith("http")) continue

            val bw = Pattern.compile("bandwidth=\"(\\d+)\"").matcher(attrs).let { if (it.find()) it.group(1)?.toIntOrNull() ?: 0 else 0 }
            val height = Pattern.compile("height=\"(\\d+)\"").matcher(attrs).let { if (it.find()) it.group(1)?.toIntOrNull() ?: 0 else 0 }
            val width = Pattern.compile("width=\"(\\d+)\"").matcher(attrs).let { if (it.find()) it.group(1)?.toIntOrNull() ?: 0 else 0 }

            if (attrs.contains("audio/mp4") || inner.contains("audio")) {
                if (bw > bestAudioBw) {
                    bestAudioBw = bw
                    bestAudioUrl = rawBaseUrl
                }
            } else if (attrs.contains("video/mp4")) {
                val qualityDim = minOf(width, height).takeIf { it > 0 } ?: maxOf(width, height)
                val label = if (qualityDim >= 1080) "1080p" else if (qualityDim >= 720) "720p" else "${qualityDim}p"
                if (bestVideo == null || bw > bestVideo.bandwidth) {
                    bestVideo = DashVideoCandidate(qualityDim, bw, label, rawBaseUrl)
                }
            }
        }
        return bestVideo to bestAudioUrl
    }

    private fun formatResolutionLabel(width: Int, height: Int): String {
        val minDim = minOf(width, height)
        return when {
            minDim >= 1080 -> "Full HD 1080p"
            minDim >= 720 -> "HD 720p"
            minDim >= 480 -> "480p"
            else -> "HD"
        }
    }

    // ==================== YOUTUBE ====================
    private suspend fun extractYouTube(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val videoId = extractYouTubeVideoId(url)
                ?: return@withContext Result.failure(Exception("تعذر العثور على معرّف فيديو يوتيوب من الرابط"))

            // Fetch metadata via oEmbed as baseline
            var title = "فيديو يوتيوب"
            var author = "قناة يوتيوب"
            try {
                val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
                val metaReq = Request.Builder().url(oembedUrl).build()
                client.newCall(metaReq).execute().use { metaResp ->
                    if (metaResp.isSuccessful) {
                        val metaJson = JSONObject(metaResp.body?.string() ?: "{}")
                        title = metaJson.optString("title", title).ifBlank { title }
                        author = metaJson.optString("author_name", author).ifBlank { author }
                    }
                }
            } catch (_: Exception) {
            }

            var thumbnail = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
            var durationSeconds = 0

            // Try InnerTube API (ANDROID_VR primary, ANDROID fallback)
            val ytClients = listOf(
                YouTubeClientConfig(
                    clientName = "ANDROID_VR",
                    clientVersion = "1.60.19",
                    deviceMake = "Oculus",
                    deviceModel = "Quest 3",
                    osVersion = "12L",
                    userAgent = ytAndroidVrUserAgent
                ),
                YouTubeClientConfig(
                    clientName = "ANDROID",
                    clientVersion = "20.10.38",
                    deviceMake = "Google",
                    deviceModel = "Pixel 7",
                    osVersion = "13",
                    userAgent = ytAndroidUserAgent
                )
            )

            var extractedOptions: List<VideoDownloadOption> = emptyList()
            var lastPlayabilityError: String? = null

            for (ytClient in ytClients) {
                try {
                    val payload = JSONObject().apply {
                        put("context", JSONObject().apply {
                            put("client", JSONObject().apply {
                                put("clientName", ytClient.clientName)
                                put("clientVersion", ytClient.clientVersion)
                                put("deviceMake", ytClient.deviceMake)
                                put("deviceModel", ytClient.deviceModel)
                                put("osName", "Android")
                                put("osVersion", ytClient.osVersion)
                                put("hl", "en")
                                put("gl", "US")
                            })
                        })
                        put("videoId", videoId)
                        put("contentCheckOk", true)
                        put("racyCheckOk", true)
                    }

                    val req = Request.Builder()
                        .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                        .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                        .header("User-Agent", ytClient.userAgent)
                        .header("Content-Type", "application/json")
                        .build()

                    client.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) return@use
                        val body = resp.body?.string() ?: return@use
                        val root = JSONObject(body)

                        val playability = root.optJSONObject("playabilityStatus")
                        val status = playability?.optString("status") ?: ""
                        if (status != "OK") {
                            lastPlayabilityError = playability?.optString("reason")?.ifBlank { null }
                        }

                        val videoDetails = root.optJSONObject("videoDetails")
                        if (videoDetails != null) {
                            title = videoDetails.optString("title", title).ifBlank { title }
                            author = videoDetails.optString("author", author).ifBlank { author }
                            durationSeconds = videoDetails.optString("lengthSeconds", "0").toIntOrNull() ?: 0
                            val thumbs = videoDetails.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
                            if (thumbs != null && thumbs.length() > 0) {
                                thumbnail = thumbs.getJSONObject(thumbs.length() - 1).optString("url", thumbnail)
                            }
                        }

                        val streamingData = root.optJSONObject("streamingData") ?: return@use
                        val options = buildYouTubeDownloadOptions(streamingData, ytClient.userAgent)
                        if (options.isNotEmpty()) {
                            extractedOptions = options
                        }
                    }

                    if (extractedOptions.isNotEmpty()) break
                } catch (e: Exception) {
                    Log.w("VideoExtractor", "InnerTube ${ytClient.clientName} failed", e)
                }
            }

            if (extractedOptions.isEmpty()) {
                val msg = lastPlayabilityError
                    ?: "تعذر استخراج روابط البث المباشر من يوتيوب. قد يكون الفيديو محمياً أو خاصاً أو مقيداً بالعمر."
                return@withContext Result.failure(Exception(msg))
            }

            Result.success(
                ExtractedVideo(
                    originalUrl = url,
                    title = title,
                    authorName = author,
                    coverUrl = thumbnail,
                    durationSeconds = durationSeconds,
                    platform = PlatformType.YOUTUBE,
                    downloadOptions = extractedOptions
                )
            )
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استخراج فيديو يوتيوب: ${e.localizedMessage}"))
        }
    }

    private data class YouTubeClientConfig(
        val clientName: String,
        val clientVersion: String,
        val deviceMake: String,
        val deviceModel: String,
        val osVersion: String,
        val userAgent: String
    )

    private fun buildYouTubeDownloadOptions(
        streamingData: JSONObject,
        ytUserAgent: String
    ): List<VideoDownloadOption> {
        val options = mutableListOf<VideoDownloadOption>()

        val formats = streamingData.optJSONArray("formats")
        val adaptiveFormats = streamingData.optJSONArray("adaptiveFormats")

        // 1. Find best AAC audio stream (itag 140 or audio/mp4)
        var bestAudioUrl: String? = null
        var bestAudioBitrate = -1
        if (adaptiveFormats != null) {
            for (i in 0 until adaptiveFormats.length()) {
                val item = adaptiveFormats.optJSONObject(i) ?: continue
                val mime = item.optString("mimeType")
                val streamUrl = item.optString("url")
                if (streamUrl.isNotBlank() && mime.contains("audio/mp4")) {
                    val bitrate = item.optInt("bitrate", 0)
                    val itag = item.optInt("itag", 0)
                    if (itag == 140 || (bestAudioUrl == null && bitrate > bestAudioBitrate) || (itag != 139 && bitrate > bestAudioBitrate)) {
                        bestAudioBitrate = bitrate
                        bestAudioUrl = streamUrl
                        if (itag == 140) break
                    }
                }
            }
        }

        // 2. Collect H.264 (avc1) adaptive MP4 video streams for muxing with AAC audio (1080p, 720p, 480p)
        data class AdaptiveVideo(val height: Int, val qualityLabel: String, val url: String)
        val adaptiveVideos = mutableListOf<AdaptiveVideo>()
        if (adaptiveFormats != null && !bestAudioUrl.isNullOrBlank()) {
            val seenHeights = mutableSetOf<Int>()
            for (i in 0 until adaptiveFormats.length()) {
                val item = adaptiveFormats.optJSONObject(i) ?: continue
                val mime = item.optString("mimeType")
                val streamUrl = item.optString("url")
                val height = item.optInt("height", 0)
                val qLabel = item.optString("qualityLabel", "${height}p")
                if (streamUrl.isNotBlank() && mime.contains("video/mp4") && mime.contains("avc1") && height in listOf(1080, 720, 480)) {
                    if (seenHeights.add(height)) {
                        adaptiveVideos.add(AdaptiveVideo(height, qLabel, streamUrl))
                    }
                }
            }
        }

        // 3. Collect direct muxed streams (e.g., 720p itag 22 or 360p itag 18)
        data class MuxedVideo(val height: Int, val qualityLabel: String, val url: String)
        val muxedVideos = mutableListOf<MuxedVideo>()
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val item = formats.optJSONObject(i) ?: continue
                val mime = item.optString("mimeType")
                val streamUrl = item.optString("url")
                val height = item.optInt("height", 360)
                val qLabel = item.optString("qualityLabel", "${height}p")
                if (streamUrl.isNotBlank() && mime.contains("video/mp4")) {
                    muxedVideos.add(MuxedVideo(height, qLabel, streamUrl))
                }
            }
        }

        // Emit 1080p (muxed on device with MediaMuxer)
        adaptiveVideos.find { it.height == 1080 }?.let { v ->
            options.add(
                VideoDownloadOption(
                    id = "yt_1080p",
                    label = "جودة فائقة Full HD 1080p",
                    description = "فيديو + صوت مدمج بأعلى نقاء",
                    quality = "Full HD 1080p",
                    downloadUrl = v.url,
                    audioStreamUrl = bestAudioUrl,
                    isNoWatermark = true,
                    fileExtension = "mp4",
                    mimeType = "video/mp4",
                    customUserAgent = ytUserAgent
                )
            )
        }

        // Emit 720p (prefer direct muxed itag 22 if available, otherwise adaptive + audio)
        val muxed720 = muxedVideos.find { it.height >= 720 }
        if (muxed720 != null) {
            options.add(
                VideoDownloadOption(
                    id = "yt_720p_direct",
                    label = "جودة عالية HD 720p (تنزيل مباشر)",
                    description = "دقة عالية وحفظ فوري",
                    quality = "HD 720p",
                    downloadUrl = muxed720.url,
                    isNoWatermark = true,
                    fileExtension = "mp4",
                    mimeType = "video/mp4",
                    customUserAgent = ytUserAgent
                )
            )
        } else {
            adaptiveVideos.find { it.height == 720 }?.let { v ->
                options.add(
                    VideoDownloadOption(
                        id = "yt_720p",
                        label = "جودة عالية HD 720p",
                        description = "فيديو + صوت بجودة عالية",
                        quality = "HD 720p",
                        downloadUrl = v.url,
                        audioStreamUrl = bestAudioUrl,
                        isNoWatermark = true,
                        fileExtension = "mp4",
                        mimeType = "video/mp4",
                        customUserAgent = ytUserAgent
                    )
                )
            }
        }

        // Emit 480p if available and no 720p muxed, or alongside
        adaptiveVideos.find { it.height == 480 }?.let { v ->
            options.add(
                VideoDownloadOption(
                    id = "yt_480p",
                    label = "جودة متوسطة 480p",
                    description = "حجم متوازن وسريع",
                    quality = "480p",
                    downloadUrl = v.url,
                    audioStreamUrl = bestAudioUrl,
                    fileExtension = "mp4",
                    mimeType = "video/mp4",
                    customUserAgent = ytUserAgent
                )
            )
        }

        // Emit 360p fast direct download
        muxedVideos.find { it.height in 240..480 }?.let { v ->
            options.add(
                VideoDownloadOption(
                    id = "yt_360p",
                    label = "جودة قياسية ${v.qualityLabel} (تنزيل فوري)",
                    description = "حجم صغير للتنزيل السريع جداً",
                    quality = v.qualityLabel,
                    downloadUrl = v.url,
                    fileExtension = "mp4",
                    mimeType = "video/mp4",
                    customUserAgent = ytUserAgent
                )
            )
        }

        // Emit Audio Only M4A
        if (!bestAudioUrl.isNullOrBlank()) {
            options.add(
                VideoDownloadOption(
                    id = "yt_audio_m4a",
                    label = "استخراج الصوت فقط (M4A)",
                    description = "ملف صوتي نقي عالي الجودة",
                    quality = "صوت M4A",
                    downloadUrl = bestAudioUrl,
                    isAudioOnly = true,
                    fileExtension = "m4a",
                    mimeType = "audio/mp4",
                    customUserAgent = ytUserAgent
                )
            )
        }

        return options
    }

    private fun extractYouTubeVideoId(url: String): String? {
        val patterns = listOf(
            Pattern.compile("[?&]v=([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com/shorts/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com/embed/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com/live/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val matcher = p.matcher(url)
            if (matcher.find()) {
                return matcher.group(1)
            }
        }
        return null
    }

    // ==================== TWITTER / X ====================
    private suspend fun extractTwitter(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            // Try api.vxtwitter.com first for clean JSON video streams
            val pathMatch = Pattern.compile("(?:twitter\\.com|x\\.com)/([^/]+/status/\\d+)").matcher(url)
            if (pathMatch.find()) {
                val tweetPath = pathMatch.group(1)
                try {
                    val apiReq = Request.Builder()
                        .url("https://api.vxtwitter.com/$tweetPath")
                        .header("User-Agent", "VideoDownloader/1.0")
                        .build()
                    client.newCall(apiReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val json = JSONObject(resp.body?.string() ?: "{}")
                            val mediaArr = json.optJSONArray("media_extended")
                            val options = mutableListOf<VideoDownloadOption>()
                            var cover: String? = null
                            if (mediaArr != null) {
                                for (i in 0 until mediaArr.length()) {
                                    val item = mediaArr.optJSONObject(i) ?: continue
                                    val type = item.optString("type")
                                    if (type == "video" || type == "gif") {
                                        val vidUrl = item.optString("url")
                                        cover = cover ?: item.optString("thumbnail_url").ifBlank { null }
                                        if (vidUrl.isNotBlank()) {
                                            options.add(
                                                VideoDownloadOption(
                                                    id = "tw_hd_$i",
                                                    label = if (i == 0) "جودة عالية HD (MP4)" else "فيديو ${i + 1} (HD)",
                                                    description = "الفيديو الأصلي من منصة X",
                                                    quality = "HD",
                                                    downloadUrl = vidUrl,
                                                    isNoWatermark = true
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                            if (options.isNotEmpty()) {
                                val text = json.optString("text", "فيديو من منصة X").ifBlank { "فيديو من منصة X" }
                                val user = json.optString("user_name", "منصة X")
                                return@withContext Result.success(
                                    ExtractedVideo(
                                        originalUrl = url,
                                        title = text.take(140),
                                        authorName = user,
                                        coverUrl = cover,
                                        platform = PlatformType.TWITTER,
                                        downloadOptions = options
                                    )
                                )
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }

            // HTML meta fallback
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = decodeHtmlEntities(extractMetaTag(html, "og:title")) ?: "فيديو من منصة X"
            val image = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = title,
                        coverUrl = image,
                        platform = PlatformType.TWITTER,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "tw_hd",
                                label = "جودة عالية HD",
                                description = "الفيديو الأصلي بجودة عالية",
                                quality = "HD 720p",
                                downloadUrl = videoUrl
                            )
                        )
                    )
                )
            } else {
                Result.failure(Exception("تعذر العثور على فيديو في التغريدة. تأكد من أن الحساب والتغريدة عامة."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في فحص رابط X/تويتر: ${e.localizedMessage}"))
        }
    }

    // ==================== FACEBOOK ====================
    private suspend fun extractFacebook(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
                .header("Sec-Fetch-Dest", "document")
                .header("Sec-Fetch-Mode", "navigate")
                .header("Sec-Fetch-Site", "none")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = decodeHtmlEntities(
                extractMetaTag(html, "og:title") ?: extractMetaTag(html, "twitter:title")
            ) ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
                ?: extractMetaTag(html, "twitter:image")

            val options = mutableListOf<VideoDownloadOption>()

            val hdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url_quality_hd\":\"([^\"]+)\"",
                "\"browser_native_hd_url\":\"([^\"]+)\"",
                "hd_src:\"([^\"]+)\"",
                "hd_src_no_ratelimit:\"([^\"]+)\""
            ))

            val sdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url\":\"([^\"]+)\"",
                "\"browser_native_sd_url\":\"([^\"]+)\"",
                "sd_src:\"([^\"]+)\"",
                "sd_src_no_ratelimit:\"([^\"]+)\""
            ))

            val ogVideo = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!hdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_hd",
                        label = "جودة فائقة Full HD 1080p",
                        description = "أعلى جودة متوفرة للفيديو",
                        quality = "HD 1080p/720p",
                        downloadUrl = decodeEscapedUrl(hdUrl),
                        isNoWatermark = true
                    )
                )
            }

            if (!sdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_sd",
                        label = "جودة قياسية SD",
                        description = "حجم أصغر وتنزيل سريع جداً",
                        quality = "SD 480p",
                        downloadUrl = decodeEscapedUrl(sdUrl)
                    )
                )
            }

            if (options.isEmpty() && !ogVideo.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_og",
                        label = "جودة عالية HD",
                        description = "الفيديو المتاح بجودة نقية",
                        quality = "Standard HD",
                        downloadUrl = decodeEscapedUrl(ogVideo)
                    )
                )
            }

            val chosenUrl = hdUrl ?: sdUrl ?: ogVideo
            if (!chosenUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_audio",
                        label = "استخراج الصوت (M4A)",
                        description = "حفظ المسار الصوتي",
                        quality = "صوت M4A",
                        downloadUrl = decodeEscapedUrl(chosenUrl),
                        isAudioOnly = true,
                        fileExtension = "m4a",
                        mimeType = "audio/mp4"
                    )
                )
            }

            if (options.isNotEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = options
                    )
                )
            } else {
                extractFacebookMobile(url)
            }
        } catch (e: Exception) {
            extractFacebookMobile(url)
        }
    }

    private suspend fun extractFacebookMobile(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val mobileUrl = url.replace("www.facebook.com", "m.facebook.com")
            val req = Request.Builder()
                .url(mobileUrl)
                .header("User-Agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = decodeHtmlEntities(extractMetaTag(html, "og:title")) ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "fb_mob",
                                label = "تحميل فيديو فيسبوك HD",
                                description = "الجودة المتاحة",
                                quality = "HD",
                                downloadUrl = decodeEscapedUrl(videoUrl)
                            )
                        )
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من فيسبوك. تأكد من أن المنشور عام (Public)."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استخراج فيديو فيسبوك: ${e.localizedMessage}"))
        }
    }

    // ==================== GENERIC / DIRECT ====================
    private suspend fun extractDirectOrGeneric(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()
            val resp = client.newCall(req).execute()
            val contentType = resp.header("Content-Type") ?: ""

            if (contentType.contains("video") || url.endsWith(".mp4") || url.endsWith(".mov")) {
                val filename = url.substringAfterLast("/").substringBefore("?").ifBlank { "video.mp4" }
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = filename,
                        platform = PlatformType.OTHER,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "generic_mp4",
                                label = "تنزيل بجودة عالية 1080p (MP4)",
                                description = "الملف الأصلي بأعلى جودة",
                                quality = "Original FHD",
                                downloadUrl = url
                            )
                        )
                    )
                )
            } else {
                val html = resp.body?.string() ?: ""
                val title = decodeHtmlEntities(extractMetaTag(html, "og:title")) ?: "فيديو مباشر"
                val cover = extractMetaTag(html, "og:image")
                val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

                if (!videoUrl.isNullOrEmpty()) {
                    Result.success(
                        ExtractedVideo(
                            originalUrl = url,
                            title = title,
                            coverUrl = cover,
                            platform = PlatformType.OTHER,
                            downloadOptions = listOf(
                                VideoDownloadOption(
                                    id = "generic_web",
                                    label = "تنزيل بجودة عالية HD",
                                    description = "جودة الويب المتاحة",
                                    quality = "Web HD",
                                    downloadUrl = videoUrl
                                )
                            )
                        )
                    )
                } else {
                    Result.failure(Exception("لم يتم العثور على رابط فيديو في الصفحة. يرجى التأكد من الرابط."))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ أثناء فحص الرابط: ${e.localizedMessage}"))
        }
    }

    private fun findFacebookVideoUrl(html: String, patterns: List<String>): String? {
        for (patternStr in patterns) {
            val matcher = Pattern.compile(patternStr).matcher(html)
            if (matcher.find()) {
                val found = matcher.group(1)
                if (!found.isNullOrBlank()) {
                    return found
                }
            }
        }
        return null
    }

    private fun decodeEscapedUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u0025", "%")
            .replace("&amp;", "&")
    }

    private fun decodeHtmlEntities(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        return HtmlCompat.fromHtml(raw, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()
    }

    private fun extractMetaTag(html: String, property: String): String? {
        val patterns = listOf(
            Pattern.compile("<meta[^>]+property=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']$property[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+name=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+name=[\"']$property[\"']", Pattern.CASE_INSENSITIVE)
        )
        for (p in patterns) {
            val matcher = p.matcher(html)
            if (matcher.find()) {
                val content = matcher.group(1)
                if (!content.isNullOrBlank()) {
                    return content.replace("&amp;", "&")
                }
            }
        }
        return null
    }

    private fun cleanTitle(title: String): String {
        return title.replace("| Facebook", "")
            .replace("- Facebook", "")
            .trim()
    }
}
