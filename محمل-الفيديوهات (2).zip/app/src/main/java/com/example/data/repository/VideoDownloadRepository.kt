package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.util.concurrent.TimeUnit

class VideoDownloadRepository(
    private val downloadDao: DownloadDao,
    private val videoExtractor: VideoExtractor = VideoExtractor()
) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val defaultUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()

    fun getDownloadsByPlatform(platform: String): Flow<List<DownloadEntity>> =
        downloadDao.getDownloadsByPlatform(platform)

    suspend fun extractVideo(url: String): Result<ExtractedVideo> {
        return videoExtractor.extract(url)
    }

    /**
     * Downloads video (or muxes adaptive video + audio for Full HD YouTube / Instagram streams)
     * and saves directly into device public MediaStore so it appears instantly in the Phone Studio / Gallery.
     */
    suspend fun downloadAndSave(
        context: Context,
        video: ExtractedVideo,
        option: VideoDownloadOption,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        val tempFiles = mutableListOf<File>()
        try {
            val extension = option.fileExtension ?: if (option.isAudioOnly) "mp3" else "mp4"
            val mimeType = option.mimeType ?: when (extension) {
                "m4a" -> "audio/mp4"
                "mp3" -> "audio/mpeg"
                else -> "video/mp4"
            }

            val sanitizedTitle = video.title
                .replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_")
                .take(45)
                .trim()
                .ifBlank { "video_${System.currentTimeMillis()}" }

            val fileName = "${video.platform.name.lowercase()}_${sanitizedTitle}_${System.currentTimeMillis()}.$extension"
            val ua = option.customUserAgent ?: defaultUserAgent

            var finalLocalPath = ""
            var downloadedBytes = 0L

            if (!option.audioStreamUrl.isNullOrBlank() && !option.isAudioOnly) {
                // Adaptive HD/FHD path: download video + audio separately, mux cleanly, then save to MediaStore
                val stamp = System.currentTimeMillis()
                val tempVideo = File(context.cacheDir, "tmp_vid_$stamp.mp4").also { tempFiles.add(it) }
                val tempAudio = File(context.cacheDir, "tmp_aud_$stamp.m4a").also { tempFiles.add(it) }
                val tempMuxed = File(context.cacheDir, "tmp_mux_$stamp.mp4").also { tempFiles.add(it) }

                val videoBytes = downloadToFile(
                    url = option.downloadUrl,
                    targetFile = tempVideo,
                    userAgent = ua,
                    referer = null,
                    progressStart = 0f,
                    progressEnd = 0.68f,
                    statusPrefix = "جارٍ تنزيل الفيديو",
                    onProgress = onProgress
                )

                val audioBytes = downloadToFile(
                    url = option.audioStreamUrl,
                    targetFile = tempAudio,
                    userAgent = ua,
                    referer = null,
                    progressStart = 0.68f,
                    progressEnd = 0.86f,
                    statusPrefix = "جارٍ تنزيل الصوت",
                    onProgress = onProgress
                )

                onProgress(
                    DownloadProgress(
                        percentage = 0.90f,
                        downloadedBytes = videoBytes + audioBytes,
                        totalBytes = videoBytes + audioBytes,
                        speedKbps = 0L,
                        statusText = "جارٍ دمج الفيديو والصوت..."
                    )
                )

                muxVideoAndAudio(tempVideo, tempAudio, tempMuxed)
                downloadedBytes = tempMuxed.length()

                onProgress(
                    DownloadProgress(
                        percentage = 0.96f,
                        downloadedBytes = downloadedBytes,
                        totalBytes = downloadedBytes,
                        speedKbps = 0L,
                        statusText = "جارٍ الحفظ في الاستوديو..."
                    )
                )

                finalLocalPath = saveLocalFileToMediaStore(
                    context = context,
                    sourceFile = tempMuxed,
                    fileName = fileName,
                    mimeType = mimeType,
                    isAudioOnly = false
                )
            } else {
                // Direct progressive stream download
                val referer = if (option.downloadUrl.contains("googlevideo.com") ||
                    option.downloadUrl.contains("cdninstagram.com")
                ) {
                    null
                } else {
                    video.originalUrl
                }

                val requestBuilder = Request.Builder()
                    .url(option.downloadUrl)
                    .header("User-Agent", ua)
                    .header("Accept", "*/*")
                if (referer != null) {
                    requestBuilder.header("Referer", referer)
                }

                httpClient.newCall(requestBuilder.build()).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(Exception("استجابة الخادم غير ناجحة: ${response.code}"))
                    }

                    val body = response.body ?: return@withContext Result.failure(Exception("محتوى ملف التحميل فارغ"))
                    val totalBytes = body.contentLength()
                    val inputStream: InputStream = body.byteStream()

                    val resultPair = writeStreamToGallery(
                        context = context,
                        inputStream = inputStream,
                        totalBytes = totalBytes,
                        fileName = fileName,
                        mimeType = mimeType,
                        isAudioOnly = option.isAudioOnly,
                        onProgress = onProgress
                    )
                    finalLocalPath = resultPair.first
                    downloadedBytes = resultPair.second
                }
            }

            val entity = DownloadEntity(
                title = video.title,
                sourceUrl = video.originalUrl,
                downloadUrl = option.downloadUrl,
                localFilePath = finalLocalPath,
                platform = video.platform.name,
                thumbnailUrl = video.coverUrl,
                fileSizeBytes = downloadedBytes,
                durationSeconds = video.durationSeconds,
                downloadTimestamp = System.currentTimeMillis(),
                qualityLabel = option.quality,
                isAudio = option.isAudioOnly
            )

            val newId = downloadDao.insert(entity)
            Result.success(entity.copy(id = newId))
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Download failed", e)
            Result.failure(e)
        } finally {
            tempFiles.forEach { file ->
                try {
                    if (file.exists()) file.delete()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun downloadToFile(
        url: String,
        targetFile: File,
        userAgent: String,
        referer: String?,
        progressStart: Float,
        progressEnd: Float,
        statusPrefix: String,
        onProgress: (DownloadProgress) -> Unit
    ): Long {
        val reqBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "*/*")
        if (referer != null) reqBuilder.header("Referer", referer)

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("استجابة الخادم غير ناجحة: ${response.code}")
            }
            val body = response.body ?: throw Exception("محتوى ملف التحميل فارغ")
            val totalBytes = body.contentLength()
            var downloadedBytes = 0L
            val buffer = ByteArray(65536)
            val startTime = System.currentTimeMillis()
            var lastUpdate = 0L

            FileOutputStream(targetFile).use { out ->
                body.byteStream().use { input ->
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead

                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 120) {
                            lastUpdate = now
                            val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                            val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                            val subProgress = if (totalBytes > 0) {
                                (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                            } else {
                                0.5f
                            }
                            val overallProgress = progressStart + (progressEnd - progressStart) * subProgress
                            onProgress(
                                DownloadProgress(
                                    percentage = overallProgress,
                                    downloadedBytes = downloadedBytes,
                                    totalBytes = totalBytes,
                                    speedKbps = speedKbps,
                                    statusText = "$statusPrefix... ${(overallProgress * 100).toInt()}%"
                                )
                            )
                        }
                    }
                    out.flush()
                }
            }
            return downloadedBytes
        }
    }

    private fun muxVideoAndAudio(videoFile: File, audioFile: File, outputFile: File) {
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            audioExtractor.setDataSource(audioFile.absolutePath)

            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    videoFormat = fmt
                    break
                }
            }

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until audioExtractor.trackCount) {
                val fmt = audioExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }

            if (videoTrackIndex == -1 || videoFormat == null) {
                throw Exception("تعذر قراءة مسار الفيديو للدمج")
            }

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerVideoTrack = muxer.addTrack(videoFormat)
            val muxerAudioTrack = if (audioTrackIndex != -1 && audioFormat != null) {
                muxer.addTrack(audioFormat)
            } else {
                -1
            }

            muxer.start()

            val bufferSize = 1024 * 1024
            val buffer = ByteBuffer.allocate(bufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            // Copy video samples
            videoExtractor.selectTrack(videoTrackIndex)
            while (true) {
                val sampleSize = videoExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = videoExtractor.sampleTime
                bufferInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
                videoExtractor.advance()
            }

            // Copy audio samples
            if (muxerAudioTrack != -1) {
                audioExtractor.selectTrack(audioTrackIndex)
                while (true) {
                    val sampleSize = audioExtractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = audioExtractor.sampleTime
                    bufferInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    audioExtractor.advance()
                }
            }
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
            try {
                videoExtractor.release()
            } catch (_: Exception) {
            }
            try {
                audioExtractor.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun saveLocalFileToMediaStore(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean
    ): String {
        val total = sourceFile.length()
        FileInputStream(sourceFile).use { input ->
            val result = writeStreamToGallery(
                context = context,
                inputStream = input,
                totalBytes = total,
                fileName = fileName,
                mimeType = mimeType,
                isAudioOnly = isAudioOnly,
                onProgress = {}
            )
            return result.first
        }
    }

    private fun writeStreamToGallery(
        context: Context,
        inputStream: InputStream,
        totalBytes: Long,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean,
        onProgress: (DownloadProgress) -> Unit
    ): Pair<String, Long> {
        var downloadedBytes = 0L
        val buffer = ByteArray(65536)
        var bytesRead: Int
        val startTime = System.currentTimeMillis()
        var lastUpdate = 0L

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativeFolder = if (isAudioOnly) {
                "${Environment.DIRECTORY_MUSIC}/VideoDownloader"
            } else {
                "${Environment.DIRECTORY_MOVIES}/VideoDownloader"
            }

            val collection = if (isAudioOnly) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val contentUri = context.contentResolver.insert(collection, values)
                ?: throw Exception("تعذر إنشاء مسار في استوديو الهاتف")

            try {
                val outputStream: OutputStream = context.contentResolver.openOutputStream(contentUri)
                    ?: throw Exception("تعذر فتح ملف الكتابة في استوديو الهاتف")

                outputStream.use { out ->
                    inputStream.use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                            downloadedBytes += bytesRead

                            val now = System.currentTimeMillis()
                            if (now - lastUpdate > 120) {
                                lastUpdate = now
                                val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                                val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                                val progress = if (totalBytes > 0) {
                                    (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    0.5f
                                }

                                onProgress(
                                    DownloadProgress(
                                        percentage = progress,
                                        downloadedBytes = downloadedBytes,
                                        totalBytes = totalBytes,
                                        speedKbps = speedKbps,
                                        statusText = "جارٍ التنزيل في الاستوديو... ${(progress * 100).toInt()}%"
                                    )
                                )
                            }
                        }
                        out.flush()
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(contentUri, values, null, null)

                return contentUri.toString() to downloadedBytes
            } catch (e: Exception) {
                try {
                    context.contentResolver.delete(contentUri, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val publicDir = Environment.getExternalStoragePublicDirectory(
                if (isAudioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
            )
            val targetDir = File(publicDir, "VideoDownloader")
            if (!targetDir.exists()) targetDir.mkdirs()

            val targetFile = File(targetDir, fileName)
            FileOutputStream(targetFile).use { out ->
                inputStream.use { input ->
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead

                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 120) {
                            lastUpdate = now
                            val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                            val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                            val progress = if (totalBytes > 0) {
                                (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                            } else {
                                0.5f
                            }

                            onProgress(
                                DownloadProgress(
                                    percentage = progress,
                                    downloadedBytes = downloadedBytes,
                                    totalBytes = totalBytes,
                                    speedKbps = speedKbps,
                                    statusText = "جارٍ التنزيل في الاستوديو... ${(progress * 100).toInt()}%"
                                )
                            )
                        }
                    }
                    out.flush()
                }
            }

            MediaScannerConnection.scanFile(
                context,
                arrayOf(targetFile.absolutePath),
                arrayOf(mimeType),
                null
            )

            return targetFile.absolutePath to downloadedBytes
        }
    }

    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            if (entity.localFilePath.startsWith("content://")) {
                val uri = Uri.parse(entity.localFilePath)
                context.contentResolver.delete(uri, null, null)
            } else {
                val file = File(entity.localFilePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            downloadDao.deleteById(entity.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete file", e)
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                if (!file.exists()) return
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }

            val mimeType = if (entity.isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, entity.title)
                putExtra(Intent.EXTRA_TEXT, "تم التحميل بواسطة تطبيق محمل الفيديوهات")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة الفيديو عبر")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Share failed", e)
        }
    }

    fun openInPhoneGallery(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }

            val mimeType = if (entity.isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Open in gallery failed", e)
        }
    }
}
