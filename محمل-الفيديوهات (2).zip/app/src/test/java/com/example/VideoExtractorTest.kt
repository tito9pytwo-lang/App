package com.example

import com.example.data.model.PlatformType
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VideoExtractorTest {

    private val extractor = VideoExtractor()

    @Test
    fun `extract public Instagram reel returns cover, title, and direct mp4 options`() = runBlocking {
        val result = extractor.extract("https://www.instagram.com/reel/CxOWiQNP2MO/?igsh=MzRlODBiNWFlZA==")
        assertTrue("Instagram extract failed: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val video = result.getOrThrow()
        assertEquals(PlatformType.INSTAGRAM, video.platform)
        assertFalse(video.title.isBlank())
        assertNotNull(video.coverUrl)
        assertTrue(video.downloadOptions.isNotEmpty())
        assertTrue(video.downloadOptions.first().downloadUrl.startsWith("https://"))
    }

    @Test
    fun `extract YouTube video returns direct googlevideo streams`() = runBlocking {
        val result = extractor.extract("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assertTrue("YouTube extract failed: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val video = result.getOrThrow()
        assertEquals(PlatformType.YOUTUBE, video.platform)
        assertFalse(video.title.isBlank())
        assertNotNull(video.coverUrl)
        assertTrue(video.downloadOptions.isNotEmpty())
        assertTrue(video.downloadOptions.none { it.downloadUrl.contains("pipedapi.kavin.rocks") })
        assertTrue(video.downloadOptions.any { it.downloadUrl.contains("googlevideo.com") })
    }
}
