package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.local.PartialDownloadDao
import com.example.data.local.PartialDownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.HttpClientProvider
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer

class VideoDownloadRepository(
    private val downloadDao: DownloadDao,
    private val partialDownloadDao: PartialDownloadDao,
    private val videoExtractor: VideoExtractor = VideoExtractor()
) {

    private class ExpiredStreamUrlException(val httpCode: Int) : IOException("رابط البث انتهت صلاحيته ($httpCode)")

    private val httpClient get() = HttpClientProvider.client

    private val defaultUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()
    val allPartialDownloads: Flow<List<PartialDownloadEntity>> = partialDownloadDao.getAllPartialDownloads()

    suspend fun extractVideo(url: String): Result<ExtractedVideo> {
        return videoExtractor.extract(url)
    }

    /**
     * Starts a fresh download staged through persistent partial files so network interruptions
     * automatically retry and can always be resumed later from the exact stopped byte.
     */
    suspend fun downloadAndSave(
        context: Context,
        video: ExtractedVideo,
        option: VideoDownloadOption,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        val partialDir = File(context.filesDir, "partial_downloads").apply {
            if (!exists()) mkdirs()
        }

        val extension = option.fileExtension ?: when {
            option.isImageOnly -> "jpg"
            option.isAudioOnly -> "mp3"
            else -> "mp4"
        }
        val mimeType = option.mimeType ?: when (extension) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "m4a" -> "audio/mp4"
            "mp3" -> "audio/mpeg"
            else -> "video/mp4"
        }

        val stamp = System.currentTimeMillis()
        val videoPartFile = File(partialDir, "part_vid_$stamp.$extension")
        val audioPartFile = if (!option.audioStreamUrl.isNullOrBlank() && !option.isAudioOnly && !option.isImageOnly) {
            File(partialDir, "part_aud_$stamp.m4a")
        } else {
            null
        }

        val initialPartial = PartialDownloadEntity(
            title = video.title,
            sourceUrl = video.originalUrl,
            downloadUrl = option.downloadUrl,
            audioStreamUrl = option.audioStreamUrl,
            platform = video.platform.name,
            thumbnailUrl = video.coverUrl,
            qualityLabel = option.quality,
            fileExtension = extension,
            mimeType = mimeType,
            customUserAgent = option.customUserAgent,
            isAudio = option.isAudioOnly,
            isImage = option.isImageOnly,
            videoPartPath = videoPartFile.absolutePath,
            audioPartPath = audioPartFile?.absolutePath,
            downloadedBytes = 0L,
            totalBytes = -1L,
            phase = "VIDEO",
            errorMessage = null,
            updatedAt = stamp
        )

        val partialId = partialDownloadDao.upsert(initialPartial)
        val savedPartial = initialPartial.copy(id = partialId)

        executeResumableDownload(context, savedPartial, onProgress)
    }

    /**
     * Resumes a previously interrupted or paused download from its exact byte offset.
     * Automatically refreshes expired CDN URLs if the server rejects the old link (403/410).
     */
    suspend fun resumeDownload(
        context: Context,
        partial: PartialDownloadEntity,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        executeResumableDownload(context, partial.copy(errorMessage = null), onProgress)
    }

    suspend fun deletePartialDownload(partial: PartialDownloadEntity) = withContext(Dispatchers.IO) {
        try {
            File(partial.videoPartPath).takeIf { it.exists() }?.delete()
            partial.audioPartPath?.let { path ->
                File(path).takeIf { it.exists() }?.delete()
            }
            partialDownloadDao.deleteById(partial.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete partial download", e)
        }
    }

    private suspend fun executeResumableDownload(
        context: Context,
        initialPartial: PartialDownloadEntity,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        var currentPartial = initialPartial
        val videoFile = File(currentPartial.videoPartPath).apply { parentFile?.mkdirs() }
        val audioFile = currentPartial.audioPartPath?.let { File(it).apply { parentFile?.mkdirs() } }
        var muxedTempFile: File? = null

        try {
            val hasAdaptiveAudio = !currentPartial.audioStreamUrl.isNullOrBlank() &&
                !currentPartial.isAudio &&
                !currentPartial.isImage
            val ua = currentPartial.customUserAgent ?: defaultUserAgent

            // Phase 1: Video / Audio-only / Thumbnail download (with automatic URL refresh if expired)
            if (currentPartial.phase != "AUDIO" && currentPartial.phase != "MUX") {
                try {
                    currentPartial = downloadWithUrlRefreshFallback(
                        partial = currentPartial,
                        targetFile = videoFile,
                        isAudioPhase = false,
                        userAgent = ua,
                        progressStart = 0f,
                        progressEnd = if (hasAdaptiveAudio) 0.70f else 0.94f,
                        statusPrefix = when {
                            currentPartial.isImage -> "جارٍ تنزيل الصورة المصغرة"
                            currentPartial.isAudio -> "جارٍ تنزيل الصوت"
                            else -> "جارٍ تنزيل الفيديو"
                        },
                        onProgress = onProgress
                    )
                } catch (e: Exception) {
                    val savedBytes = if (videoFile.exists()) videoFile.length() else 0L
                    val phaseStatus = if (e is CancellationException) "PAUSED" else "VIDEO"
                    val msg = if (e is CancellationException) "تم إيقاف التنزيل مؤقتاً" else (e.message ?: "انقطع الاتصال بالشبكة")
                    partialDownloadDao.upsert(
                        currentPartial.copy(
                            downloadedBytes = savedBytes,
                            phase = phaseStatus,
                            errorMessage = msg,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    if (e is CancellationException) throw e
                    return@withContext Result.failure(
                        Exception("توقف التنزيل عند ${formatBytes(savedBytes)} بسبب الشبكة. يمكنك استكماله من مكان التوقف!")
                    )
                }
            }

            // Phase 2: Adaptive Audio Track (for Full HD YouTube / Instagram DASH)
            if (hasAdaptiveAudio && audioFile != null) {
                currentPartial = currentPartial.copy(phase = "AUDIO", updatedAt = System.currentTimeMillis())
                partialDownloadDao.upsert(currentPartial)

                try {
                    currentPartial = downloadWithUrlRefreshFallback(
                        partial = currentPartial,
                        targetFile = audioFile,
                        isAudioPhase = true,
                        userAgent = ua,
                        progressStart = 0.70f,
                        progressEnd = 0.88f,
                        statusPrefix = "جارٍ تنزيل مسار الصوت",
                        onProgress = onProgress
                    )
                } catch (e: Exception) {
                    val savedBytes = if (audioFile.exists()) audioFile.length() else 0L
                    partialDownloadDao.upsert(
                        currentPartial.copy(
                            downloadedBytes = videoFile.length() + savedBytes,
                            phase = "AUDIO",
                            errorMessage = e.message ?: "انقطع الاتصال أثناء تنزيل الصوت",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    if (e is CancellationException) throw e
                    return@withContext Result.failure(
                        Exception("توقف تنزيل الصوت بسبب الشبكة. يمكنك استكمال التنزيل من مكان التوقف!")
                    )
                }

                // Phase 3: Mux video + audio on device
                onProgress(
                    DownloadProgress(
                        percentage = 0.92f,
                        downloadedBytes = videoFile.length() + audioFile.length(),
                        totalBytes = videoFile.length() + audioFile.length(),
                        speedKbps = 0L,
                        statusText = "جارٍ دمج الفيديو والصوت..."
                    )
                )

                muxedTempFile = File(context.cacheDir, "tmp_mux_${System.currentTimeMillis()}.mp4")
                muxVideoAndAudio(videoFile, audioFile, muxedTempFile)
            }

            val sourceToPublish = muxedTempFile ?: videoFile
            val finalSize = sourceToPublish.length()

            onProgress(
                DownloadProgress(
                    percentage = 0.97f,
                    downloadedBytes = finalSize,
                    totalBytes = finalSize,
                    speedKbps = 0L,
                    statusText = "جارٍ الحفظ في الاستوديو..."
                )
            )

            val sanitizedTitle = currentPartial.title
                .replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_")
                .take(45)
                .trim()
                .ifBlank { "media_${System.currentTimeMillis()}" }

            val fileName = "${currentPartial.platform.lowercase()}_${sanitizedTitle}_${System.currentTimeMillis()}.${currentPartial.fileExtension}"

            val finalLocalPath = saveLocalFileToMediaStore(
                context = context,
                sourceFile = sourceToPublish,
                fileName = fileName,
                mimeType = currentPartial.mimeType,
                isAudioOnly = currentPartial.isAudio,
                isImageOnly = currentPartial.isImage
            )

            // Clean up staged partial files & record on success
            try {
                if (videoFile.exists()) videoFile.delete()
                if (audioFile != null && audioFile.exists()) audioFile.delete()
                if (muxedTempFile != null && muxedTempFile.exists()) muxedTempFile.delete()
                partialDownloadDao.deleteById(currentPartial.id)
            } catch (_: Exception) {
            }

            val entity = DownloadEntity(
                title = currentPartial.title,
                sourceUrl = currentPartial.sourceUrl,
                downloadUrl = currentPartial.downloadUrl,
                localFilePath = finalLocalPath,
                platform = currentPartial.platform,
                thumbnailUrl = currentPartial.thumbnailUrl,
                fileSizeBytes = finalSize,
                durationSeconds = 0,
                downloadTimestamp = System.currentTimeMillis(),
                qualityLabel = currentPartial.qualityLabel,
                isAudio = currentPartial.isAudio,
                isImage = currentPartial.isImage
            )

            val newId = downloadDao.insert(entity)
            Result.success(entity.copy(id = newId))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Download failed", e)
            muxedTempFile?.takeIf { it.exists() }?.delete()
            Result.failure(e)
        }
    }

    private suspend fun downloadWithUrlRefreshFallback(
        partial: PartialDownloadEntity,
        targetFile: File,
        isAudioPhase: Boolean,
        userAgent: String,
        progressStart: Float,
        progressEnd: Float,
        statusPrefix: String,
        onProgress: (DownloadProgress) -> Unit
    ): PartialDownloadEntity {
        var activePartial = partial
        val urlToFetch = if (isAudioPhase) activePartial.audioStreamUrl!! else activePartial.downloadUrl

        return try {
            downloadFileWithAutoRangeRetry(
                partial = activePartial,
                url = urlToFetch,
                targetFile = targetFile,
                userAgent = userAgent,
                progressStart = progressStart,
                progressEnd = progressEnd,
                statusPrefix = statusPrefix,
                onProgress = onProgress
            )
        } catch (expired: ExpiredStreamUrlException) {
            // Re-extract fresh stream URLs from sourceUrl and continue resuming!
            val refreshed = videoExtractor.extract(activePartial.sourceUrl).getOrNull()
                ?: throw expired
            val matchingOption = refreshed.downloadOptions.find { opt ->
                opt.quality == activePartial.qualityLabel &&
                    opt.isAudioOnly == activePartial.isAudio &&
                    opt.isImageOnly == activePartial.isImage
            } ?: refreshed.downloadOptions.firstOrNull { opt ->
                opt.isAudioOnly == activePartial.isAudio && opt.isImageOnly == activePartial.isImage
            } ?: throw expired

            activePartial = activePartial.copy(
                downloadUrl = matchingOption.downloadUrl,
                audioStreamUrl = matchingOption.audioStreamUrl ?: activePartial.audioStreamUrl,
                customUserAgent = matchingOption.customUserAgent ?: activePartial.customUserAgent,
                updatedAt = System.currentTimeMillis()
            )
            partialDownloadDao.upsert(activePartial)

            val freshUrl = if (isAudioPhase) {
                activePartial.audioStreamUrl ?: throw expired
            } else {
                activePartial.downloadUrl
            }

            downloadFileWithAutoRangeRetry(
                partial = activePartial,
                url = freshUrl,
                targetFile = targetFile,
                userAgent = activePartial.customUserAgent ?: userAgent,
                progressStart = progressStart,
                progressEnd = progressEnd,
                statusPrefix = statusPrefix,
                onProgress = onProgress
            )
        }
    }

    private suspend fun downloadFileWithAutoRangeRetry(
        partial: PartialDownloadEntity,
        url: String,
        targetFile: File,
        userAgent: String,
        progressStart: Float,
        progressEnd: Float,
        statusPrefix: String,
        onProgress: (DownloadProgress) -> Unit
    ): PartialDownloadEntity {
        var activePartial = partial
        var lastError: Exception? = null

        for (attempt in 1..3) {
            try {
                val existingBytes = if (targetFile.exists()) targetFile.length() else 0L
                val referer = if (url.contains("googlevideo.com") || url.contains("cdninstagram.com")) {
                    null
                } else {
                    activePartial.sourceUrl
                }

                val reqBuilder = Request.Builder()
                    .url(url)
                    .header("User-Agent", userAgent)
                    .header("Accept", "*/*")
                if (referer != null) {
                    reqBuilder.header("Referer", referer)
                }
                if (existingBytes > 0L) {
                    reqBuilder.header("Range", "bytes=$existingBytes-")
                }

                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    val code = response.code

                    if (code == 416) {
                        // Server says existing range is already beyond end of file
                        if (activePartial.totalBytes > 0L && existingBytes >= activePartial.totalBytes) {
                            return activePartial
                        }
                        if (targetFile.exists()) targetFile.delete()
                        throw IOException("إعادة ضبط نطاق التحميل")
                    }

                    if (code == 403 || code == 410) {
                        throw ExpiredStreamUrlException(code)
                    }

                    if (!response.isSuccessful && code != 206) {
                        throw IOException("استجابة الخادم غير ناجحة: $code")
                    }

                    val body = response.body ?: throw IOException("محتوى ملف التحميل فارغ")
                    val isPartialContent = code == 206
                    val contentLength = body.contentLength()
                    val totalBytes = when {
                        isPartialContent -> {
                            parseTotalFromContentRange(response.header("Content-Range"))
                                ?: if (contentLength > 0) existingBytes + contentLength else activePartial.totalBytes
                        }
                        contentLength > 0 -> contentLength
                        else -> activePartial.totalBytes
                    }

                    val appendMode = isPartialContent && existingBytes > 0L
                    var downloadedBytes = if (appendMode) existingBytes else 0L

                    activePartial = activePartial.copy(
                        downloadedBytes = downloadedBytes,
                        totalBytes = totalBytes,
                        updatedAt = System.currentTimeMillis()
                    )
                    partialDownloadDao.upsert(activePartial)

                    val buffer = ByteArray(65536)
                    val startTime = System.currentTimeMillis()
                    var bytesThisSession = 0L
                    var lastUiUpdate = 0L
                    var lastDbPersist = downloadedBytes

                    FileOutputStream(targetFile, appendMode).use { out ->
                        body.byteStream().use { input ->
                            var bytesRead: Int
                            while (input.read(buffer).also { bytesRead = it } != -1) {
                                out.write(buffer, 0, bytesRead)
                                downloadedBytes += bytesRead
                                bytesThisSession += bytesRead

                                val now = System.currentTimeMillis()
                                if (now - lastUiUpdate > 140) {
                                    lastUiUpdate = now
                                    val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                                    val speedKbps = ((bytesThisSession / 1024f) / elapsedSec).toLong()
                                    val subProgress = if (totalBytes > 0) {
                                        (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                                    } else {
                                        0.5f
                                    }
                                    val overall = progressStart + (progressEnd - progressStart) * subProgress
                                    onProgress(
                                        DownloadProgress(
                                            percentage = overall,
                                            downloadedBytes = downloadedBytes,
                                            totalBytes = totalBytes,
                                            speedKbps = speedKbps,
                                            statusText = "$statusPrefix... ${(overall * 100).toInt()}%"
                                        )
                                    )
                                }

                                if (downloadedBytes - lastDbPersist >= 524_288L) {
                                    lastDbPersist = downloadedBytes
                                    activePartial = activePartial.copy(
                                        downloadedBytes = downloadedBytes,
                                        totalBytes = totalBytes,
                                        updatedAt = now
                                    )
                                    partialDownloadDao.upsert(activePartial)
                                }
                            }
                            out.flush()
                        }
                    }

                    activePartial = activePartial.copy(
                        downloadedBytes = downloadedBytes,
                        totalBytes = if (totalBytes > 0) totalBytes else downloadedBytes,
                        updatedAt = System.currentTimeMillis()
                    )
                    partialDownloadDao.upsert(activePartial)
                    return activePartial
                }
            } catch (e: ExpiredStreamUrlException) {
                throw e
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                lastError = e
                Log.w("VideoDownloadRepo", "Download stream interrupted (attempt $attempt/3): ${e.message}")
                if (attempt < 3) {
                    delay(700L * attempt)
                }
            }
        }

        throw lastError ?: IOException("انقطع الاتصال بالشبكة أثناء التحميل")
    }

    private fun parseTotalFromContentRange(header: String?): Long? {
        if (header.isNullOrBlank()) return null
        val slashPart = header.substringAfter("/", "").trim()
        return slashPart.toLongOrNull()
    }

    private fun muxVideoAndAudio(videoFile: File, audioFile: File, outputFile: File) {
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            audioExtractor.setDataSource(audioFile.absolutePath)

            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    videoFormat = fmt
                    break
                }
            }

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until audioExtractor.trackCount) {
                val fmt = audioExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }

            if (videoTrackIndex == -1 || videoFormat == null) {
                throw Exception("تعذر قراءة مسار الفيديو للدمج")
            }

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerVideoTrack = muxer.addTrack(videoFormat)
            val muxerAudioTrack = if (audioTrackIndex != -1 && audioFormat != null) {
                muxer.addTrack(audioFormat)
            } else {
                -1
            }

            muxer.start()

            val buffer = ByteBuffer.allocate(1024 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            videoExtractor.selectTrack(videoTrackIndex)
            while (true) {
                val sampleSize = videoExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = videoExtractor.sampleTime
                bufferInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
                videoExtractor.advance()
            }

            if (muxerAudioTrack != -1) {
                audioExtractor.selectTrack(audioTrackIndex)
                while (true) {
                    val sampleSize = audioExtractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = audioExtractor.sampleTime
                    bufferInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    audioExtractor.advance()
                }
            }
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
            try {
                videoExtractor.release()
            } catch (_: Exception) {
            }
            try {
                audioExtractor.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun saveLocalFileToMediaStore(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean,
        isImageOnly: Boolean
    ): String {
        FileInputStream(sourceFile).use { input ->
            return writeStreamToGallery(
                context = context,
                inputStream = input,
                fileName = fileName,
                mimeType = mimeType,
                isAudioOnly = isAudioOnly,
                isImageOnly = isImageOnly
            )
        }
    }

    private fun writeStreamToGallery(
        context: Context,
        inputStream: InputStream,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean,
        isImageOnly: Boolean
    ): String {
        val buffer = ByteArray(65536)
        var bytesRead: Int

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativeFolder = when {
                isImageOnly -> "${Environment.DIRECTORY_PICTURES}/VideoDownloader"
                isAudioOnly -> "${Environment.DIRECTORY_MUSIC}/VideoDownloader"
                else -> "${Environment.DIRECTORY_MOVIES}/VideoDownloader"
            }

            val collection = when {
                isImageOnly -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                isAudioOnly -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val contentUri = context.contentResolver.insert(collection, values)
                ?: throw Exception("تعذر إنشاء مسار في استوديو الهاتف")

            try {
                val outputStream: OutputStream = context.contentResolver.openOutputStream(contentUri)
                    ?: throw Exception("تعذر فتح ملف الكتابة في استوديو الهاتف")

                outputStream.use { out ->
                    inputStream.use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                        }
                        out.flush()
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(contentUri, values, null, null)

                return contentUri.toString()
            } catch (e: Exception) {
                try {
                    context.contentResolver.delete(contentUri, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val publicDir = Environment.getExternalStoragePublicDirectory(
                when {
                    isImageOnly -> Environment.DIRECTORY_PICTURES
                    isAudioOnly -> Environment.DIRECTORY_MUSIC
                    else -> Environment.DIRECTORY_MOVIES
                }
            )
            val targetDir = File(publicDir, "VideoDownloader")
            if (!targetDir.exists()) targetDir.mkdirs()

            val targetFile = File(targetDir, fileName)
            FileOutputStream(targetFile).use { out ->
                inputStream.use { input ->
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                    }
                    out.flush()
                }
            }

            MediaScannerConnection.scanFile(
                context,
                arrayOf(targetFile.absolutePath),
                arrayOf(mimeType),
                null
            )

            return targetFile.absolutePath
        }
    }

    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            if (entity.localFilePath.startsWith("content://")) {
                val uri = Uri.parse(entity.localFilePath)
                context.contentResolver.delete(uri, null, null)
            } else {
                val file = File(entity.localFilePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            downloadDao.deleteById(entity.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete file", e)
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                if (!file.exists()) return
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }

            val mimeType = when {
                entity.isImage -> "image/*"
                entity.isAudio -> "audio/*"
                else -> "video/*"
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, entity.title)
                putExtra(Intent.EXTRA_TEXT, "تم التحميل بواسطة تطبيق محمل الفيديوهات")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة الملف عبر")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Share failed", e)
        }
    }

    fun openInPhoneGallery(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }

            val mimeType = when {
                entity.isImage -> "image/*"
                entity.isAudio -> "audio/*"
                else -> "video/*"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Open in gallery failed", e)
        }
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024f * 1024f)
        return if (mb >= 1f) "%.1f MB".format(mb) else "${bytes / 1024} KB"
    }
}
