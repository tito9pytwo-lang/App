package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PartialDownloadDao {
    @Query("SELECT * FROM partial_downloads ORDER BY updatedAt DESC")
    fun getAllPartialDownloads(): Flow<List<PartialDownloadEntity>>

    @Query("SELECT * FROM partial_downloads WHERE id = :id")
    suspend fun getById(id: Long): PartialDownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PartialDownloadEntity): Long

    @Query("DELETE FROM partial_downloads WHERE id = :id")
    suspend fun deleteById(id: Long)
}
