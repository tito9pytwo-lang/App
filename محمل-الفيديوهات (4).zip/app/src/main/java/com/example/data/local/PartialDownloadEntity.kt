package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "partial_downloads")
data class PartialDownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val sourceUrl: String,
    val downloadUrl: String,
    val audioStreamUrl: String? = null,
    val platform: String,
    val thumbnailUrl: String? = null,
    val qualityLabel: String,
    val fileExtension: String = "mp4",
    val mimeType: String = "video/mp4",
    val customUserAgent: String? = null,
    val isAudio: Boolean = false,
    val isImage: Boolean = false,
    val videoPartPath: String,
    val audioPartPath: String? = null,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = -1L,
    val phase: String = "VIDEO",
    val errorMessage: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
