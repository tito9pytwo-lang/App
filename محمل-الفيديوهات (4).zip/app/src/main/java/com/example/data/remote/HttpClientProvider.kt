package com.example.data.remote

import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

object HttpClientProvider {

    private class InMemoryCookieJar : CookieJar {
        private val cookieStore = ConcurrentHashMap<String, MutableList<Cookie>>()

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val host = normalizeDomain(url.host)
            val existing = cookieStore.getOrPut(host) { mutableListOf() }
            synchronized(existing) {
                val now = System.currentTimeMillis()
                existing.removeAll { it.expiresAt < now }
                for (newCookie in cookies) {
                    existing.removeAll { it.name == newCookie.name && it.domain == newCookie.domain && it.path == newCookie.path }
                    if (newCookie.expiresAt >= now) {
                        existing.add(newCookie)
                    }
                }
            }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val now = System.currentTimeMillis()
            val result = mutableListOf<Cookie>()
            cookieStore.forEach { (domainKey, list) ->
                if (url.host == domainKey || url.host.endsWith(".$domainKey")) {
                    synchronized(list) {
                        list.removeAll { it.expiresAt < now }
                        result.addAll(list.filter { it.matches(url) })
                    }
                }
            }
            return result
        }

        fun hasCookiesFor(domain: String): Boolean {
            val key = normalizeDomain(domain)
            val list = cookieStore[key] ?: return false
            synchronized(list) {
                val now = System.currentTimeMillis()
                list.removeAll { it.expiresAt < now }
                return list.isNotEmpty()
            }
        }

        private fun normalizeDomain(host: String): String {
            return when {
                host.endsWith("instagram.com") -> "instagram.com"
                host.endsWith("youtube.com") -> "youtube.com"
                host.endsWith("facebook.com") -> "facebook.com"
                host.endsWith("tiktok.com") -> "tiktok.com"
                else -> host
            }
        }
    }

    private val sharedCookieJar = InMemoryCookieJar()

    val client: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(sharedCookieJar)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectionPool(ConnectionPool(8, 5, TimeUnit.MINUTES))
        .build()

    fun hasInstagramCookies(): Boolean = sharedCookieJar.hasCookiesFor("instagram.com")
}
