package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.remote.ExtractorEngineState
import com.example.ui.components.DownloaderScreen
import com.example.ui.components.DownloadsScreen
import com.example.ui.components.VideoPlayerScreen
import com.example.ui.theme.FacebookBlue
import com.example.ui.theme.TikTokPink

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val urlInput by viewModel.urlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val isDownloading by viewModel.isDownloading.collectAsStateWithLifecycle()
    val activeProgress by viewModel.activeProgress.collectAsStateWithLifecycle()
    val extractedVideo by viewModel.extractedVideo.collectAsStateWithLifecycle()
    val clipboardCandidateUrl by viewModel.clipboardDetectedUrl.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedPlatformFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsList.collectAsStateWithLifecycle()
    val partialDownloads by viewModel.partialDownloads.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val activePlayingVideo by viewModel.activePlayingVideo.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val successMessage by viewModel.successMessage.collectAsStateWithLifecycle()

    var showAboutDialog by remember { mutableStateOf(false) }
    var showEngineUpdateDialog by remember { mutableStateOf(false) }

    // Check clipboard on startup
    LaunchedEffect(Unit) {
        viewModel.checkClipboard(context)
    }

    // Display messages
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissMessages()
        }
    }
    LaunchedEffect(successMessage) {
        successMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissMessages()
        }
    }

    // Back button behavior: if on tab 1 or 2, back navigates to Downloader tab
    BackHandler(enabled = selectedTab != 0) {
        viewModel.setTab(0)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = stringResource(id = R.string.app_name),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "TikTok",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TikTokPink
                                )
                                Text(text = " • ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "Instagram",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.InstagramPink
                                )
                                Text(text = " • ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "YouTube",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = com.example.ui.theme.YouTubeRed
                                )
                                Text(text = " • ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "FB",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FacebookBlue
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showEngineUpdateDialog = true },
                        modifier = Modifier.testTag("engine_update_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = "تحديث أداة الاستخراج YT",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showAboutDialog = true },
                        modifier = Modifier.testTag("about_app_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "حول التطبيق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { viewModel.setTab(0) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = stringResource(id = R.string.tab_download)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(id = R.string.tab_download),
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_download_tab")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { viewModel.setTab(1) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (downloads.isNotEmpty()) {
                                    Badge(
                                        containerColor = MaterialTheme.colorScheme.primary
                                    ) {
                                        Text(text = "${downloads.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.VideoLibrary,
                                contentDescription = stringResource(id = R.string.tab_my_videos)
                            )
                        }
                    },
                    label = {
                        Text(
                            text = stringResource(id = R.string.tab_my_videos),
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_gallery_tab")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { viewModel.setTab(2) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = stringResource(id = R.string.tab_player)
                        )
                    },
                    label = {
                        Text(
                            text = stringResource(id = R.string.tab_player),
                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_player_tab")
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            modifier = Modifier.padding(innerPadding),
            label = "ScreenTransition"
        ) { tabIndex ->
            when (tabIndex) {
                0 -> DownloaderScreen(
                    urlInput = urlInput,
                    onUrlChanged = viewModel::onUrlChanged,
                    isAnalyzing = isAnalyzing,
                    isDownloading = isDownloading,
                    downloadProgress = activeProgress,
                    extractedVideo = extractedVideo,
                    partialDownloads = partialDownloads,
                    clipboardCandidateUrl = clipboardCandidateUrl,
                    onApplyClipboard = viewModel::applyDetectedClipboard,
                    onDismissClipboard = viewModel::dismissClipboardBanner,
                    onPasteClicked = { viewModel.pasteFromClipboard(context) },
                    onAnalyzeClicked = viewModel::analyzeUrl,
                    onDownloadOptionClicked = { option ->
                        viewModel.startDownload(context, option)
                    },
                    onPauseDownload = viewModel::pauseActiveDownload,
                    onResumePartial = { partial ->
                        viewModel.resumePartialDownload(context, partial)
                    },
                    onDeletePartial = viewModel::deletePartialDownload
                )

                1 -> DownloadsScreen(
                    downloads = downloads,
                    selectedFilter = selectedFilter,
                    searchQuery = searchQuery,
                    onFilterChanged = viewModel::setPlatformFilter,
                    onSearchChanged = viewModel::setSearchQuery,
                    onPlayClicked = viewModel::playVideo,
                    onShareClicked = { item -> viewModel.shareVideo(context, item) },
                    onOpenExternalClicked = { item -> viewModel.openInPhoneGallery(context, item) },
                    onDeleteClicked = { item -> viewModel.deleteDownload(context, item) },
                    onNavigateToDownloader = { viewModel.setTab(0) }
                )

                2 -> VideoPlayerScreen(
                    video = activePlayingVideo,
                    onShare = { item -> viewModel.shareVideo(context, item) },
                    onOpenExternal = { item -> viewModel.openInPhoneGallery(context, item) },
                    onNavigateToGallery = { viewModel.setTab(1) }
                )
            }
        }
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Text("محمل الفيديوهات الشامل", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تطبيق احترافي فائق السرعة لتنزيل الفيديوهات من:")
                    Text("• انستغرام (Instagram): ريلز، منشورات وبوستات بأعلى جودة.")
                    Text("• يوتيوب (YouTube & Shorts): فيديوهات وشورتس 1080p وصوت MP3.")
                    Text("• تيك توك (TikTok): إزالة العلامة المائية وجودة فائقة Ultra HD.")
                    Text("• فيسبوك (Facebook): مقاطع الفيديو وReels بجودة HD/SD.")
                    Text("• تويتر / X: حفظ التغريدات المرئية مباشرة.")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "يتم حفظ الفيديوهات تلقائياً في استوديو الهاتف (المعرض/Gallery) لتشاهدها بدون إنترنت وتشاركها مباشرة.",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("حسناً")
                }
            }
        )
    }

    if (showEngineUpdateDialog) {
        EngineUpdateDialog(
            engineState = engineState,
            onSyncNow = { customUrl -> viewModel.syncExtractorEngine(customUrl) },
            onDismiss = { showEngineUpdateDialog = false }
        )
    }
}

@Composable
private fun EngineUpdateDialog(
    engineState: ExtractorEngineState,
    onSyncNow: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    var customConfigUrl by remember(engineState.customConfigUrl) {
        mutableStateOf(engineState.customConfigUrl)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.SystemUpdate,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("تحديث أداة الاستخراج (YT / IG)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "يقوم هذا التحديث بمزامنة أحدث إصدارات عملاء يوتيوب ومعرفات الجلسة من خوادم يوتيوب وإنستغرام مباشرة داخل التطبيق دون الحاجة لإعادة تثبيت.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "إصدار المحرك: v${engineState.engineVersion}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "إصدار عميل يوتيوب النشط: ${engineState.youtubeWebClientVersion}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "معرف إنستغرام: ${engineState.instagramAppId}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "آخر تحديث: ${engineState.formattedLastSync()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = engineState.lastSyncMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = customConfigUrl,
                    onValueChange = { customConfigUrl = it },
                    label = { Text("رابط ملف إعدادات JSON بعيد (اختياري)", fontSize = 11.sp) },
                    placeholder = { Text("https://.../yt_engine_config.json", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_config_url_input")
                )

                Button(
                    onClick = { onSyncNow(customConfigUrl.takeIf { it.isNotBlank() }) },
                    enabled = !engineState.isSyncing,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sync_engine_now_button")
                ) {
                    if (engineState.isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جارٍ التحديث والمزامنة...")
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تحديث أداة YT والاستخراج الآن", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

