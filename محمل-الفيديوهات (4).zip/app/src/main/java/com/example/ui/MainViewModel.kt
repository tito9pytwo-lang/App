package com.example.ui

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.local.PartialDownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.ExtractorConfigManager
import com.example.data.remote.ExtractorEngineState
import com.example.data.repository.VideoDownloadRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VideoDownloadRepository

    init {
        ExtractorConfigManager.init(application)
        val database = AppDatabase.getDatabase(application)
        repository = VideoDownloadRepository(database.downloadDao(), database.partialDownloadDao())
    }

    val engineState: StateFlow<ExtractorEngineState> = ExtractorConfigManager.state

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _extractedVideo = MutableStateFlow<ExtractedVideo?>(null)
    val extractedVideo: StateFlow<ExtractedVideo?> = _extractedVideo.asStateFlow()

    private val _isDownloading = MutableStateFlow(false)
    val isDownloading: StateFlow<Boolean> = _isDownloading.asStateFlow()

    private val _activeProgress = MutableStateFlow<DownloadProgress?>(null)
    val activeProgress: StateFlow<DownloadProgress?> = _activeProgress.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _selectedPlatformFilter = MutableStateFlow("ALL")
    val selectedPlatformFilter: StateFlow<String> = _selectedPlatformFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activePlayingVideo = MutableStateFlow<DownloadEntity?>(null)
    val activePlayingVideo: StateFlow<DownloadEntity?> = _activePlayingVideo.asStateFlow()

    private val _clipboardDetectedUrl = MutableStateFlow<String?>(null)
    val clipboardDetectedUrl: StateFlow<String?> = _clipboardDetectedUrl.asStateFlow()

    private var activeDownloadJob: Job? = null

    val partialDownloads: StateFlow<List<PartialDownloadEntity>> = repository.allPartialDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val downloadsList: StateFlow<List<DownloadEntity>> = combine(
        repository.allDownloads,
        _selectedPlatformFilter,
        _searchQuery
    ) { list, filter, query ->
        list.filter { item ->
            val matchFilter = when (filter) {
                "TIKTOK" -> item.platform.equals("TIKTOK", ignoreCase = true)
                "FACEBOOK" -> item.platform.equals("FACEBOOK", ignoreCase = true)
                "INSTAGRAM" -> item.platform.equals("INSTAGRAM", ignoreCase = true)
                "YOUTUBE" -> item.platform.equals("YOUTUBE", ignoreCase = true)
                "TWITTER" -> item.platform.equals("TWITTER", ignoreCase = true)
                else -> true
            }
            val matchQuery = query.isBlank() || item.title.contains(query, ignoreCase = true)
            matchFilter && matchQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        if (_errorMessage.value != null) _errorMessage.value = null
    }

    fun setTab(index: Int) {
        _selectedTab.value = index
    }

    fun setPlatformFilter(filter: String) {
        _selectedPlatformFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun checkClipboard(context: Context) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = clipboard?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0)?.text?.toString()?.trim() ?: ""
                if (isPotentialVideoUrl(text) && text != _urlInput.value) {
                    _clipboardDetectedUrl.value = text
                }
            }
        } catch (_: Exception) {}
    }

    fun applyDetectedClipboard() {
        val url = _clipboardDetectedUrl.value ?: return
        _urlInput.value = url
        _clipboardDetectedUrl.value = null
        analyzeUrl()
    }

    fun dismissClipboardBanner() {
        _clipboardDetectedUrl.value = null
    }

    fun pasteFromClipboard(context: Context) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = clipboard?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0)?.text?.toString()?.trim() ?: ""
                if (text.isNotEmpty()) {
                    _urlInput.value = text
                    analyzeUrl()
                }
            }
        } catch (e: Exception) {
            _errorMessage.value = "تعذر الوصول إلى الحافظة"
        }
    }

    private fun isPotentialVideoUrl(text: String): Boolean {
        val lower = text.lowercase()
        return (lower.startsWith("http://") || lower.startsWith("https://")) &&
                (lower.contains("tiktok.com") || lower.contains("facebook.com") ||
                        lower.contains("fb.watch") || lower.contains("fb.com") ||
                        lower.contains("instagram.com") || lower.contains("instagr.am") ||
                        lower.contains("youtube.com") || lower.contains("youtu.be") ||
                        lower.contains("twitter.com") || lower.contains("x.com") ||
                        lower.endsWith(".mp4"))
    }

    fun analyzeUrl() {
        val url = _urlInput.value.trim()
        if (url.isEmpty()) {
            _errorMessage.value = "الرجاء إدخال أو لصق رابط الفيديو أولاً"
            return
        }

        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _extractedVideo.value = null

            val result = repository.extractVideo(url)
            _isAnalyzing.value = false

            result.onSuccess { extracted ->
                _extractedVideo.value = extracted
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "حدث خطأ أثناء فحص الرابط"
            }
        }
    }

    fun startDownload(context: Context, option: VideoDownloadOption) {
        val video = _extractedVideo.value ?: return
        if (_isDownloading.value) return

        activeDownloadJob = viewModelScope.launch {
            _isDownloading.value = true
            _activeProgress.value = DownloadProgress(
                percentage = 0.03f,
                statusText = if (option.isImageOnly) "بدء تنزيل الصورة المصغرة..." else "بدء التنزيل والحفظ في الاستوديو..."
            )
            _errorMessage.value = null

            try {
                val result = repository.downloadAndSave(
                    context = context,
                    video = video,
                    option = option,
                    onProgress = { progress ->
                        _activeProgress.value = progress
                    }
                )

                _isDownloading.value = false
                _activeProgress.value = null
                result.onSuccess { savedEntity ->
                    _successMessage.value = if (savedEntity.isImage) {
                        "تم حفظ الصورة المصغرة بنجاح في استوديو الصور!"
                    } else {
                        "تم تنزيل الفيديو بنجاح! تم الحفظ مباشرة في استوديو هاتفك."
                    }
                    _selectedTab.value = 1
                    if (!savedEntity.isImage) {
                        _activePlayingVideo.value = savedEntity
                    }
                }.onFailure { err ->
                    _errorMessage.value = err.message ?: "فشل التنزيل"
                }
            } catch (_: CancellationException) {
                _isDownloading.value = false
                _activeProgress.value = null
                _successMessage.value = "تم إيقاف التنزيل مؤقتاً. يمكنك استكماله من نفس النقطة."
            } catch (e: Exception) {
                _isDownloading.value = false
                _activeProgress.value = null
                _errorMessage.value = e.message ?: "حدث خطأ غير متوقع أثناء التنزيل"
            }
        }
    }

    fun pauseActiveDownload() {
        activeDownloadJob?.cancel()
        activeDownloadJob = null
    }

    fun resumePartialDownload(context: Context, partial: PartialDownloadEntity) {
        if (_isDownloading.value) return

        activeDownloadJob = viewModelScope.launch {
            _isDownloading.value = true
            val initialPct = if (partial.totalBytes > 0) {
                (partial.downloadedBytes.toFloat() / partial.totalBytes.toFloat()).coerceIn(0f, 0.99f)
            } else {
                0.05f
            }
            _activeProgress.value = DownloadProgress(
                percentage = initialPct,
                downloadedBytes = partial.downloadedBytes,
                totalBytes = partial.totalBytes,
                statusText = "جارٍ استكمال التنزيل من ${(initialPct * 100).toInt()}%..."
            )
            _errorMessage.value = null

            try {
                val result = repository.resumeDownload(
                    context = context,
                    partial = partial,
                    onProgress = { progress ->
                        _activeProgress.value = progress
                    }
                )
                _isDownloading.value = false
                _activeProgress.value = null

                result.onSuccess { savedEntity ->
                    _successMessage.value = "تم استكمال التنزيل والحفظ بنجاح في استوديو هاتفك!"
                    _selectedTab.value = 1
                    if (!savedEntity.isImage) {
                        _activePlayingVideo.value = savedEntity
                    }
                }.onFailure { err ->
                    _errorMessage.value = err.message ?: "تعذر استكمال التنزيل"
                }
            } catch (_: CancellationException) {
                _isDownloading.value = false
                _activeProgress.value = null
                _successMessage.value = "تم إيقاف التنزيل مؤقتاً وحفظ التقدم."
            } catch (e: Exception) {
                _isDownloading.value = false
                _activeProgress.value = null
                _errorMessage.value = e.message ?: "حدث خطأ غير متوقع أثناء الاستكمال"
            }
        }
    }

    fun deletePartialDownload(partial: PartialDownloadEntity) {
        viewModelScope.launch {
            repository.deletePartialDownload(partial)
        }
    }

    fun syncExtractorEngine(customConfigUrl: String? = null) {
        viewModelScope.launch {
            val result = ExtractorConfigManager.syncLiveEngine(
                context = getApplication(),
                customUrl = customConfigUrl
            )
            result.onSuccess { state ->
                _successMessage.value = state.lastSyncMessage
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "تعذر تحديث محرك الاستخراج"
            }
        }
    }

    fun playVideo(entity: DownloadEntity) {
        if (entity.isImage) return
        _activePlayingVideo.value = entity
        _selectedTab.value = 2
    }

    fun clearActivePlayer() {
        _activePlayingVideo.value = null
    }

    fun deleteDownload(context: Context, entity: DownloadEntity) {
        viewModelScope.launch {
            if (_activePlayingVideo.value?.id == entity.id) {
                _activePlayingVideo.value = null
            }
            repository.deleteDownload(context, entity)
            _successMessage.value = "تم حذف الملف بنجاح من الاستوديو"
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        repository.shareVideo(context, entity)
    }

    fun openInPhoneGallery(context: Context, entity: DownloadEntity) {
        repository.openInPhoneGallery(context, entity)
    }

    fun dismissMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}
