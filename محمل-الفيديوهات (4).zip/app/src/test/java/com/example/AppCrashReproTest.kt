package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.PartialDownloadEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.util.Locale
import kotlin.concurrent.thread

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AppCrashReproTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private var serverSocket: ServerSocket? = null
    private var serverPort: Int = 0
    private var previousLocale: Locale = Locale.getDefault()

    @Before
    fun setUp() {
        previousLocale = Locale.getDefault()
        Locale.setDefault(Locale.forLanguageTag("ar-SA"))

        val context = ApplicationProvider.getApplicationContext<Context>()
        runBlocking(kotlinx.coroutines.Dispatchers.IO) {
            AppDatabase.getDatabase(context).clearAllTables()
        }

        serverSocket = ServerSocket(0).also { ss ->
            serverPort = ss.localPort
            thread(isDaemon = true) {
                while (!ss.isClosed) {
                    try {
                        val socket = ss.accept()
                        thread(isDaemon = true) {
                            socket.use { s ->
                                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                                val requestLine = reader.readLine() ?: return@use
                                while (true) {
                                    val line = reader.readLine() ?: break
                                    if (line.isEmpty()) break
                                }
                                val path = requestLine.split(" ").getOrNull(1) ?: "/"
                                val out = s.getOutputStream()
                                when {
                                    path.startsWith("/fb_page") -> {
                                        val html = """
                                            <html><head>
                                            <meta property="og:title" content="FB Test" />
                                            <meta property="og:image" content="http://127.0.0.1:$serverPort/thumb.jpg" />
                                            </head><body>
                                            <script>{"playable_url":"http://127.0.0.1:$serverPort/slow_video.mp4"}</script>
                                            </body></html>
                                        """.trimIndent().toByteArray()
                                        out.write("HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Type: text/html\r\nContent-Length: ${html.size}\r\n\r\n".toByteArray())
                                        out.write(html)
                                        out.flush()
                                    }
                                    path.startsWith("/slow_video.mp4") -> {
                                        val totalSize = 32768
                                        out.write("HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Type: video/mp4\r\nContent-Length: $totalSize\r\nAccept-Ranges: bytes\r\n\r\n".toByteArray())
                                        val chunk = ByteArray(4096) { 0x1A }
                                        repeat(8) {
                                            out.write(chunk)
                                            out.flush()
                                            Thread.sleep(40)
                                        }
                                    }
                                    path.startsWith("/thumb.jpg") -> {
                                        val payload = ByteArray(4096) { 0x2B }
                                        out.write("HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Type: image/jpeg\r\nContent-Length: ${payload.size}\r\nAccept-Ranges: bytes\r\n\r\n".toByteArray())
                                        out.write(payload)
                                        out.flush()
                                    }
                                    else -> {
                                        out.write("HTTP/1.1 500 Internal Server Error\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
                                        out.flush()
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    @After
    fun tearDown() {
        Locale.setDefault(previousLocale)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
    }

    @Test
    fun `slow download of video audio and thumbnail works without crashing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("url_input_field").performTextInput("http://127.0.0.1:$serverPort/fb_page?facebook.com=1")
        composeRule.onNodeWithTag("analyze_button").performClick()

        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("extracted_video_card").fetchSemanticsNodes().isNotEmpty()
        }

        // 1. Download video
        composeRule.onNodeWithTag("option_fb_sd").performScrollTo().performClick()
        repeat(5) {
            Thread.sleep(60)
            composeRule.waitForIdle()
        }
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("downloads_list").fetchSemanticsNodes().isNotEmpty()
        }

        // 2. Download audio (scroll past Snackbar to avoid overlay interception in test)
        composeRule.onNodeWithTag("nav_download_tab").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("option_thumb_hd").performScrollTo()
        composeRule.onNodeWithTag("option_fb_audio").performScrollTo().performClick()
        repeat(5) {
            Thread.sleep(60)
            composeRule.waitForIdle()
        }
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("downloads_list").fetchSemanticsNodes().isNotEmpty()
        }

        // 3. Download thumbnail
        composeRule.onNodeWithTag("nav_download_tab").performClick()
        composeRule.mainClock.advanceTimeBy(5000)
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("option_thumb_hd").performScrollTo().performClick()
        composeRule.waitUntil(timeoutMillis = 10_000) {
            composeRule.onAllNodesWithTag("downloads_list").fetchSemanticsNodes().isNotEmpty()
        }

        val count = db.openHelper.readableDatabase.query("SELECT COUNT(*) FROM downloads").use { c ->
            c.moveToFirst()
            c.getInt(0)
        }
        assertEquals(3, count)
    }

    @Test
    fun `launch MainActivity when partial download with totalBytes exists does not crash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)
        runBlocking {
            db.partialDownloadDao().upsert(
                PartialDownloadEntity(
                    title = "فيديو متوقف",
                    sourceUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    downloadUrl = "http://127.0.0.1:$serverPort/slow_video.mp4",
                    platform = "YOUTUBE",
                    qualityLabel = "HD 720p",
                    videoPartPath = "${context.filesDir}/partial_downloads/test_part.mp4",
                    downloadedBytes = 1024L * 512L,
                    totalBytes = 1024L * 1024L * 10L,
                    phase = "PAUSED"
                )
            )
        }

        composeRule.activityRule.scenario.recreate()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("resumable_downloads_card").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `test Room migration 1 to 2 with existing rows does not crash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbFile = context.getDatabasePath("test_mig_db_3")
        dbFile.parentFile?.mkdirs()
        if (dbFile.exists()) dbFile.delete()

        val sqlite = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqlite.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `downloads` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `title` TEXT NOT NULL,
                `sourceUrl` TEXT NOT NULL,
                `downloadUrl` TEXT NOT NULL,
                `localFilePath` TEXT NOT NULL,
                `platform` TEXT NOT NULL,
                `thumbnailUrl` TEXT,
                `fileSizeBytes` INTEGER NOT NULL,
                `durationSeconds` INTEGER NOT NULL,
                `downloadTimestamp` INTEGER NOT NULL,
                `qualityLabel` TEXT NOT NULL,
                `isAudio` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        sqlite.execSQL(
            """
            INSERT INTO `downloads` (title, sourceUrl, downloadUrl, localFilePath, platform, thumbnailUrl, fileSizeBytes, durationSeconds, downloadTimestamp, qualityLabel, isAudio)
            VALUES ('old video', 'https://tiktok.com/1', 'https://cdn/1.mp4', '/tmp/1.mp4', 'TIKTOK', NULL, 1024, 10, 1700000000000, 'HD', 0)
            """.trimIndent()
        )
        sqlite.execSQL("PRAGMA user_version = 1")
        sqlite.close()

        val roomDb = androidx.room.Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "test_mig_db_3"
        ).addMigrations(AppDatabase.MIGRATION_1_2)
            .allowMainThreadQueries()
            .build()

        val cursor = roomDb.openHelper.writableDatabase.query("SELECT * FROM downloads")
        assertNotNull(cursor)
        cursor.close()
        roomDb.close()
    }
}
