package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.PlatformType
import com.example.data.remote.ExtractorConfigManager
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VideoExtractorTest {

    private val extractor = VideoExtractor()

    @Test
    fun `extract public Instagram reel on first attempt returns cover, title, mp4, and thumbnail option`() = runBlocking {
        val result = extractor.extract("https://www.instagram.com/reel/CxOWiQNP2MO/?igsh=MzRlODBiNWFlZA==")
        assertTrue("Instagram extract failed: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val video = result.getOrThrow()
        assertEquals(PlatformType.INSTAGRAM, video.platform)
        assertFalse(video.title.isBlank())
        assertNotNull(video.coverUrl)
        assertTrue(video.downloadOptions.any { !it.isImageOnly && !it.isAudioOnly && it.downloadUrl.startsWith("https://") })
        assertTrue(video.downloadOptions.any { it.isImageOnly && it.downloadUrl.startsWith("https://") })
    }

    @Test
    fun `extract YouTube video on first attempt returns direct googlevideo streams and HD thumbnail`() = runBlocking {
        val result = extractor.extract("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assertTrue("YouTube extract failed: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val video = result.getOrThrow()
        assertEquals(PlatformType.YOUTUBE, video.platform)
        assertFalse(video.title.isBlank())
        assertNotNull(video.coverUrl)
        assertTrue(video.downloadOptions.none { it.downloadUrl.contains("pipedapi.kavin.rocks") })
        assertTrue(video.downloadOptions.any { it.downloadUrl.contains("googlevideo.com") })
        assertTrue(video.downloadOptions.any { it.isImageOnly && it.downloadUrl.contains("ytimg.com") })
    }

    @Test
    fun `syncLiveEngine updates live YouTube and Instagram parameters`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        ExtractorConfigManager.init(context)
        val syncResult = ExtractorConfigManager.syncLiveEngine(context)
        assertTrue("Engine sync failed: ${syncResult.exceptionOrNull()?.message}", syncResult.isSuccess)
        val state = syncResult.getOrThrow()
        assertFalse(state.youtubeWebClientVersion.isBlank())
        assertFalse(state.youtubeVisitorData.isBlank())
        assertFalse(state.instagramAppId.isBlank())
    }
}
