package com.example.data.remote

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

data class ExtractorEngineState(
    val engineVersion: String = "2026.11.17",
    val youtubeWebClientVersion: String = "2.20261116.00.00",
    val youtubeVisitorData: String = "",
    val youtubeVrClientVersion: String = "1.65.10",
    val youtubeAndroidClientVersion: String = "20.10.38",
    val youtubeIosClientVersion: String = "20.10.4",
    val instagramAppId: String = "936619743392459",
    val instagramLsdToken: String = "",
    val tikwmApiBase: String = "https://www.tikwm.com/api/",
    val customConfigUrl: String = "",
    val lastSyncTimestamp: Long = 0L,
    val lastSyncMessage: String = "الإعدادات الافتراضية المدمجة نشطة",
    val isSyncing: Boolean = false
) {
    fun formattedLastSync(): String {
        if (lastSyncTimestamp <= 0L) return "لم يتم التحديث اليدوي بعد"
        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        return sdf.format(Date(lastSyncTimestamp))
    }
}

object ExtractorConfigManager {

    private const val PREFS_NAME = "extractor_engine_prefs"
    private const val KEY_JSON = "engine_state_json"

    private val _state = MutableStateFlow(ExtractorEngineState())
    val state: StateFlow<ExtractorEngineState> = _state.asStateFlow()

    @Volatile
    private var initialized = false

    private val browserUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            try {
                val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val raw = prefs.getString(KEY_JSON, null)
                if (!raw.isNullOrBlank()) {
                    val json = JSONObject(raw)
                    _state.value = ExtractorEngineState(
                        engineVersion = json.optString("engineVersion", "2026.11.17"),
                        youtubeWebClientVersion = json.optString("youtubeWebClientVersion", "2.20261116.00.00"),
                        youtubeVisitorData = json.optString("youtubeVisitorData", ""),
                        youtubeVrClientVersion = json.optString("youtubeVrClientVersion", "1.65.10"),
                        youtubeAndroidClientVersion = json.optString("youtubeAndroidClientVersion", "20.10.38"),
                        youtubeIosClientVersion = json.optString("youtubeIosClientVersion", "20.10.4"),
                        instagramAppId = json.optString("instagramAppId", "936619743392459"),
                        instagramLsdToken = json.optString("instagramLsdToken", ""),
                        tikwmApiBase = json.optString("tikwmApiBase", "https://www.tikwm.com/api/"),
                        customConfigUrl = json.optString("customConfigUrl", ""),
                        lastSyncTimestamp = json.optLong("lastSyncTimestamp", 0L),
                        lastSyncMessage = json.optString("lastSyncMessage", "الإعدادات المحفوظة نشطة"),
                        isSyncing = false
                    )
                }
            } catch (e: Exception) {
                Log.w("ExtractorConfig", "Failed to load saved engine config", e)
            }
            initialized = true
        }
    }

    private fun saveState(context: Context?, newState: ExtractorEngineState) {
        _state.value = newState
        if (context == null) return
        try {
            val json = JSONObject().apply {
                put("engineVersion", newState.engineVersion)
                put("youtubeWebClientVersion", newState.youtubeWebClientVersion)
                put("youtubeVisitorData", newState.youtubeVisitorData)
                put("youtubeVrClientVersion", newState.youtubeVrClientVersion)
                put("youtubeAndroidClientVersion", newState.youtubeAndroidClientVersion)
                put("youtubeIosClientVersion", newState.youtubeIosClientVersion)
                put("instagramAppId", newState.instagramAppId)
                put("instagramLsdToken", newState.instagramLsdToken)
                put("tikwmApiBase", newState.tikwmApiBase)
                put("customConfigUrl", newState.customConfigUrl)
                put("lastSyncTimestamp", newState.lastSyncTimestamp)
                put("lastSyncMessage", newState.lastSyncMessage)
            }
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_JSON, json.toString())
                .apply()
        } catch (e: Exception) {
            Log.w("ExtractorConfig", "Failed to save engine config", e)
        }
    }

    /**
     * Fetches fresh live session parameters directly from YouTube (sw.js_data) and Instagram,
     * plus optional remote JSON config if customUrl is provided.
     */
    suspend fun syncLiveEngine(
        context: Context? = null,
        customUrl: String? = null
    ): Result<ExtractorEngineState> = withContext(Dispatchers.IO) {
        val prev = _state.value
        _state.value = prev.copy(isSyncing = true)

        try {
            var ytWebVersion = prev.youtubeWebClientVersion
            var ytVisitorData = prev.youtubeVisitorData
            var ytVrVersion = prev.youtubeVrClientVersion
            var ytAndroidVersion = prev.youtubeAndroidClientVersion
            var ytIosVersion = prev.youtubeIosClientVersion
            var igAppId = prev.instagramAppId
            var igLsd = prev.instagramLsdToken
            var tikwmBase = prev.tikwmApiBase
            var engineVersion = prev.engineVersion
            val effectiveCustomUrl = customUrl?.trim() ?: prev.customConfigUrl

            var ytUpdated = false
            var igUpdated = false

            // 1. Live sync YouTube InnerTube clientVersion + visitorData
            try {
                val ytReq = Request.Builder()
                    .url("https://www.youtube.com/sw.js_data")
                    .header("User-Agent", browserUserAgent)
                    .header("Accept", "*/*")
                    .build()
                HttpClientProvider.client.newCall(ytReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string() ?: ""
                        val cvMatch = Pattern.compile("\"(2\\.\\d{8}\\.\\d{2}\\.\\d{2})\"").matcher(body)
                        if (cvMatch.find()) {
                            ytWebVersion = cvMatch.group(1) ?: ytWebVersion
                        }
                        val vdMatch = Pattern.compile("\"(Cg[A-Za-z0-9_%-]{15,})\"").matcher(body)
                        if (vdMatch.find()) {
                            ytVisitorData = vdMatch.group(1) ?: ytVisitorData
                        }
                        ytUpdated = true
                    }
                }
            } catch (e: Exception) {
                Log.w("ExtractorConfig", "YouTube live sync partial error", e)
            }

            // 2. Live sync Instagram App ID, LSD token & warm up session cookies
            try {
                val igReq = Request.Builder()
                    .url("https://www.instagram.com/")
                    .header("User-Agent", browserUserAgent)
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Sec-Fetch-Dest", "document")
                    .header("Sec-Fetch-Mode", "navigate")
                    .header("Sec-Fetch-Site", "none")
                    .build()
                HttpClientProvider.client.newCall(igReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val html = resp.body?.string() ?: ""
                        val appMatch = Pattern.compile("\"X-IG-App-ID\"\\s*:\\s*\"(\\d+)\"|\"appId\"\\s*:\\s*\"(\\d+)\"").matcher(html)
                        if (appMatch.find()) {
                            igAppId = appMatch.group(1) ?: appMatch.group(2) ?: igAppId
                        }
                        val lsdMatch = Pattern.compile("\"LSD\",\\[\\],\\{\"token\":\"([^\"]+)\"").matcher(html)
                        if (lsdMatch.find()) {
                            igLsd = lsdMatch.group(1) ?: igLsd
                        }
                        igUpdated = true
                    }
                }
            } catch (e: Exception) {
                Log.w("ExtractorConfig", "Instagram live sync partial error", e)
            }

            // 3. Optional remote JSON config overrides (safe data-only configuration, no executable code)
            var remoteApplied = false
            if (effectiveCustomUrl.startsWith("http://") || effectiveCustomUrl.startsWith("https://")) {
                val cfgReq = Request.Builder()
                    .url(effectiveCustomUrl)
                    .header("User-Agent", "VideoDownloader/1.0")
                    .header("Accept", "application/json")
                    .build()
                HttpClientProvider.client.newCall(cfgReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = JSONObject(resp.body?.string() ?: "{}")
                        engineVersion = json.optString("engineVersion", engineVersion).ifBlank { engineVersion }
                        ytVrVersion = json.optString("youtubeVrClientVersion", ytVrVersion).ifBlank { ytVrVersion }
                        ytAndroidVersion = json.optString("youtubeAndroidClientVersion", ytAndroidVersion).ifBlank { ytAndroidVersion }
                        ytIosVersion = json.optString("youtubeIosClientVersion", ytIosVersion).ifBlank { ytIosVersion }
                        ytWebVersion = json.optString("youtubeWebClientVersion", ytWebVersion).ifBlank { ytWebVersion }
                        igAppId = json.optString("instagramAppId", igAppId).ifBlank { igAppId }
                        tikwmBase = json.optString("tikwmApiBase", tikwmBase).ifBlank { tikwmBase }
                        remoteApplied = true
                    } else {
                        throw Exception("فشل جلب ملف التحديث من الرابط (${resp.code})")
                    }
                }
            }

            if (!ytUpdated && !igUpdated && !remoteApplied) {
                val failedState = prev.copy(
                    isSyncing = false,
                    lastSyncMessage = "تعذر الاتصال بخوادم التحديث. تحقق من الإنترنت."
                )
                saveState(context, failedState)
                return@withContext Result.failure(Exception(failedState.lastSyncMessage))
            }

            val dateStamp = SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date())
            if (!remoteApplied) {
                engineVersion = dateStamp
            }

            val parts = mutableListOf<String>()
            if (ytUpdated) parts.add("يوتيوب ($ytWebVersion)")
            if (igUpdated) parts.add("إنستغرام (AppID: $igAppId)")
            if (remoteApplied) parts.add("ملف الإعدادات البعيد")

            val updatedState = ExtractorEngineState(
                engineVersion = engineVersion,
                youtubeWebClientVersion = ytWebVersion,
                youtubeVisitorData = ytVisitorData,
                youtubeVrClientVersion = ytVrVersion,
                youtubeAndroidClientVersion = ytAndroidVersion,
                youtubeIosClientVersion = ytIosVersion,
                instagramAppId = igAppId,
                instagramLsdToken = igLsd,
                tikwmApiBase = tikwmBase,
                customConfigUrl = effectiveCustomUrl,
                lastSyncTimestamp = System.currentTimeMillis(),
                lastSyncMessage = "تم التحديث بنجاح: ${parts.joinToString(" + ")}",
                isSyncing = false
            )
            saveState(context, updatedState)
            Result.success(updatedState)
        } catch (e: Exception) {
            val errState = prev.copy(
                isSyncing = false,
                lastSyncMessage = "فشل التحديث: ${e.localizedMessage ?: "خطأ غير متوقع"}"
            )
            saveState(context, errState)
            Result.failure(e)
        }
    }

    suspend fun ensureYouTubeVisitorData(forceRefresh: Boolean = false): String = withContext(Dispatchers.IO) {
        val current = _state.value.youtubeVisitorData
        if (!forceRefresh && current.isNotBlank()) return@withContext current
        try {
            val ytReq = Request.Builder()
                .url("https://www.youtube.com/sw.js_data")
                .header("User-Agent", browserUserAgent)
                .build()
            HttpClientProvider.client.newCall(ytReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string() ?: ""
                    val vdMatch = Pattern.compile("\"(Cg[A-Za-z0-9_%-]{15,})\"").matcher(body)
                    if (vdMatch.find()) {
                        val vd = vdMatch.group(1) ?: ""
                        if (vd.isNotBlank()) {
                            _state.value = _state.value.copy(youtubeVisitorData = vd)
                            return@withContext vd
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        current
    }
}
