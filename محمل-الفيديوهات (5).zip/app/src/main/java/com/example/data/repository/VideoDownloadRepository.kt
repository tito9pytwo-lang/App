package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.local.PartialDownloadDao
import com.example.data.local.PartialDownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.HttpClientProvider
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.util.Locale

class VideoDownloadRepository(
    private val downloadDao: DownloadDao,
    private val partialDownloadDao: PartialDownloadDao,
    private val videoExtractor: VideoExtractor = VideoExtractor()
) {

    companion object {
        private const val CHUNK_SIZE_BYTES = 4L * 1024L * 1024L // 4 MB chunks avoid YouTube open-stream throttling & resets
        private const val MAX_CHUNK_RETRIES = 5
        private const val MAX_URL_REFRESH_ATTEMPTS = 3
    }

    private class ExpiredStreamUrlException(val httpCode: Int) : IOException("رابط البث انتهت صلاحيته ($httpCode)")

    private val httpClient get() = HttpClientProvider.client

    private val defaultUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()
    val allPartialDownloads: Flow<List<PartialDownloadEntity>> = partialDownloadDao.getAllPartialDownloads()

    suspend fun extractVideo(url: String): Result<ExtractedVideo> {
        return videoExtractor.extract(url)
    }

    /**
     * Starts a fresh download staged through persistent partial files so network interruptions
     * automatically retry and can always be resumed later from the exact stopped byte.
     */
    suspend fun downloadAndSave(
        context: Context,
        video: ExtractedVideo,
        option: VideoDownloadOption,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        val partialDir = File(context.filesDir, "partial_downloads").apply {
            if (!exists()) mkdirs()
        }

        val extension = option.fileExtension ?: when {
            option.isImageOnly -> "jpg"
            option.isAudioOnly -> "mp3"
            else -> "mp4"
        }
        val mimeType = option.mimeType ?: when (extension) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "m4a" -> "audio/mp4"
            "mp3" -> "audio/mpeg"
            else -> "video/mp4"
        }

        val stamp = System.currentTimeMillis()
        val videoPartFile = File(partialDir, "part_vid_$stamp.$extension")
        val audioPartFile = if (!option.audioStreamUrl.isNullOrBlank() && !option.isAudioOnly && !option.isImageOnly) {
            File(partialDir, "part_aud_$stamp.m4a")
        } else {
            null
        }

        val initialPartial = PartialDownloadEntity(
            title = video.title,
            sourceUrl = video.originalUrl,
            downloadUrl = option.downloadUrl,
            audioStreamUrl = option.audioStreamUrl,
            platform = video.platform.name,
            thumbnailUrl = video.coverUrl,
            qualityLabel = option.quality,
            fileExtension = extension,
            mimeType = mimeType,
            customUserAgent = option.customUserAgent,
            isAudio = option.isAudioOnly,
            isImage = option.isImageOnly,
            videoPartPath = videoPartFile.absolutePath,
            audioPartPath = audioPartFile?.absolutePath,
            downloadedBytes = 0L,
            totalBytes = option.expectedSizeBytes,
            phase = "VIDEO",
            errorMessage = null,
            updatedAt = stamp
        )

        val partialId = try {
            partialDownloadDao.upsert(initialPartial)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to save initial partial record", e)
            0L
        }
        val savedPartial = initialPartial.copy(id = partialId)

        executeResumableDownload(
            context = context,
            initialPartial = savedPartial,
            initialExpectedAudioBytes = option.expectedAudioSizeBytes,
            onProgress = onProgress
        )
    }

    /**
     * Resumes a previously interrupted or paused download from its exact byte offset.
     * Automatically refreshes expired CDN URLs if the server rejects the old link (403/410)
     * or if a connection keeps dropping mid-download.
     */
    suspend fun resumeDownload(
        context: Context,
        partial: PartialDownloadEntity,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        executeResumableDownload(
            context = context,
            initialPartial = partial.copy(errorMessage = null),
            initialExpectedAudioBytes = if (partial.phase == "AUDIO") partial.totalBytes else -1L,
            onProgress = onProgress
        )
    }

    suspend fun deletePartialDownload(partial: PartialDownloadEntity) = withContext(Dispatchers.IO) {
        try {
            File(partial.videoPartPath).takeIf { it.exists() }?.delete()
            partial.audioPartPath?.let { path ->
                File(path).takeIf { it.exists() }?.delete()
            }
            partialDownloadDao.deleteById(partial.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete partial download", e)
        }
    }

    private suspend fun executeResumableDownload(
        context: Context,
        initialPartial: PartialDownloadEntity,
        initialExpectedAudioBytes: Long = -1L,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        var currentPartial = initialPartial
        var expectedAudioBytes = initialExpectedAudioBytes
        val videoFile = File(currentPartial.videoPartPath).apply { parentFile?.mkdirs() }
        val audioFile = currentPartial.audioPartPath?.let { File(it).apply { parentFile?.mkdirs() } }
        var muxedTempFile: File? = null

        try {
            val hasAdaptiveAudio = !currentPartial.audioStreamUrl.isNullOrBlank() &&
                !currentPartial.isAudio &&
                !currentPartial.isImage
            val ua = currentPartial.customUserAgent ?: defaultUserAgent

            // Phase 1: Video / Audio-only / Thumbnail download
            if (currentPartial.phase != "AUDIO" && currentPartial.phase != "MUX") {
                try {
                    val result = downloadWithUrlRefreshFallback(
                        partial = currentPartial,
                        targetFile = videoFile,
                        isAudioPhase = false,
                        knownTotalBytesHint = currentPartial.totalBytes,
                        userAgent = ua,
                        progressStart = 0f,
                        progressEnd = if (hasAdaptiveAudio) 0.70f else 0.94f,
                        statusPrefix = when {
                            currentPartial.isImage -> "جارٍ تنزيل الصورة المصغرة"
                            currentPartial.isAudio -> "جارٍ تنزيل الصوت"
                            else -> "جارٍ تنزيل الفيديو"
                        },
                        onProgress = onProgress
                    )
                    currentPartial = result.first
                    if (result.second > 0L) {
                        expectedAudioBytes = result.second
                    }
                } catch (e: Exception) {
                    val savedBytes = if (videoFile.exists()) videoFile.length() else 0L
                    val phaseStatus = if (e is CancellationException) "PAUSED" else "VIDEO"
                    val msg = if (e is CancellationException) "تم إيقاف التنزيل مؤقتاً" else buildResumableErrorMessage(savedBytes, e)
                    try {
                        partialDownloadDao.upsert(
                            currentPartial.copy(
                                downloadedBytes = savedBytes,
                                phase = phaseStatus,
                                errorMessage = msg,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    } catch (_: Exception) {
                    }
                    if (e is CancellationException) throw e
                    return@withContext Result.failure(Exception(msg))
                }
            }

            // Phase 2: Adaptive Audio Track (for Full HD YouTube / Instagram DASH)
            if (hasAdaptiveAudio && audioFile != null && currentPartial.phase != "MUX") {
                val audioPhasePartial = currentPartial.copy(
                    phase = "AUDIO",
                    downloadedBytes = if (audioFile.exists()) audioFile.length() else 0L,
                    totalBytes = expectedAudioBytes,
                    updatedAt = System.currentTimeMillis()
                )
                currentPartial = audioPhasePartial
                partialDownloadDao.upsert(currentPartial)

                try {
                    val result = downloadWithUrlRefreshFallback(
                        partial = currentPartial,
                        targetFile = audioFile,
                        isAudioPhase = true,
                        knownTotalBytesHint = expectedAudioBytes,
                        userAgent = ua,
                        progressStart = 0.70f,
                        progressEnd = 0.88f,
                        statusPrefix = "جارٍ تنزيل مسار الصوت",
                        onProgress = onProgress
                    )
                    currentPartial = result.first
                } catch (e: Exception) {
                    val savedBytes = if (audioFile.exists()) audioFile.length() else 0L
                    val msg = if (e is CancellationException) "تم إيقاف تنزيل الصوت مؤقتاً" else buildResumableErrorMessage(savedBytes, e)
                    try {
                        partialDownloadDao.upsert(
                            currentPartial.copy(
                                downloadedBytes = savedBytes,
                                phase = "AUDIO",
                                errorMessage = msg,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    } catch (_: Exception) {
                    }
                    if (e is CancellationException) throw e
                    return@withContext Result.failure(Exception(msg))
                }
            }

            // Phase 3: Mux video + audio on device
            if (hasAdaptiveAudio && audioFile != null) {
                onProgress(
                    DownloadProgress(
                        percentage = 0.92f,
                        downloadedBytes = videoFile.length() + audioFile.length(),
                        totalBytes = videoFile.length() + audioFile.length(),
                        speedKbps = 0L,
                        statusText = "جارٍ دمج الفيديو والصوت..."
                    )
                )

                muxedTempFile = File(context.cacheDir, "tmp_mux_${System.currentTimeMillis()}.mp4")
                muxVideoAndAudio(videoFile, audioFile, muxedTempFile)

                // Release staged track files immediately after verified muxing to save disk space on long videos
                if (muxedTempFile.exists() && muxedTempFile.length() > 0L) {
                    try {
                        if (videoFile.exists()) videoFile.delete()
                        if (audioFile.exists()) audioFile.delete()
                    } catch (_: Exception) {
                    }
                }
            }

            val sourceToPublish = muxedTempFile ?: videoFile
            val finalSize = sourceToPublish.length()
            if (!sourceToPublish.exists() || finalSize <= 0L) {
                throw IOException("الملف الذي تم تنزيله فارغ أو غير صالح")
            }

            onProgress(
                DownloadProgress(
                    percentage = 0.97f,
                    downloadedBytes = finalSize,
                    totalBytes = finalSize,
                    speedKbps = 0L,
                    statusText = "جارٍ الحفظ في الاستوديو..."
                )
            )

            val sanitizedTitle = currentPartial.title
                .replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_")
                .take(45)
                .trim()
                .ifBlank { "media_${System.currentTimeMillis()}" }

            val fileName = "${currentPartial.platform.lowercase()}_${sanitizedTitle}_${System.currentTimeMillis()}.${currentPartial.fileExtension}"

            val finalLocalPath = saveLocalFileToMediaStore(
                context = context,
                sourceFile = sourceToPublish,
                fileName = fileName,
                mimeType = currentPartial.mimeType,
                isAudioOnly = currentPartial.isAudio,
                isImageOnly = currentPartial.isImage
            )

            // Clean up staged partial files & record on success
            try {
                if (videoFile.exists()) videoFile.delete()
                if (audioFile != null && audioFile.exists()) audioFile.delete()
                if (muxedTempFile != null && muxedTempFile.exists()) muxedTempFile.delete()
                partialDownloadDao.deleteById(currentPartial.id)
            } catch (_: Exception) {
            }

            val entity = DownloadEntity(
                title = currentPartial.title,
                sourceUrl = currentPartial.sourceUrl,
                downloadUrl = currentPartial.downloadUrl,
                localFilePath = finalLocalPath,
                platform = currentPartial.platform,
                thumbnailUrl = currentPartial.thumbnailUrl,
                fileSizeBytes = finalSize,
                durationSeconds = 0,
                downloadTimestamp = System.currentTimeMillis(),
                qualityLabel = currentPartial.qualityLabel,
                isAudio = currentPartial.isAudio,
                isImage = currentPartial.isImage
            )

            val newId = downloadDao.insert(entity)
            Result.success(entity.copy(id = newId))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Download failed", e)
            muxedTempFile?.takeIf { it.exists() }?.delete()
            Result.failure(e)
        }
    }

    private fun buildResumableErrorMessage(savedBytes: Long, e: Exception): String {
        val raw = e.message ?: ""
        return when {
            raw.contains("ENOSPC", ignoreCase = true) || raw.contains("No space", ignoreCase = true) ->
                "توقف التنزيل عند ${formatBytes(savedBytes)}: مساحة التخزين ممتلئة على الهاتف."
            e is ExpiredStreamUrlException ->
                "توقف التنزيل عند ${formatBytes(savedBytes)} بسبب انتهاء صلاحية رابط البث (${e.httpCode}). اضغط استكمال للمحاولة برابط جديد."
            else ->
                "توقف التنزيل عند ${formatBytes(savedBytes)} بسبب الشبكة. يمكنك استكماله من مكان التوقف!"
        }
    }

    /**
     * Downloads a media track cleanly, re-extracting fresh CDN URLs up to MAX_URL_REFRESH_ATTEMPTS
     * times whenever YouTube/CDN returns 403/410 OR drops/resets connections repeatedly.
     * Returns (updatedPartial, refreshedAudioExpectedSize).
     */
    private suspend fun downloadWithUrlRefreshFallback(
        partial: PartialDownloadEntity,
        targetFile: File,
        isAudioPhase: Boolean,
        knownTotalBytesHint: Long,
        userAgent: String,
        progressStart: Float,
        progressEnd: Float,
        statusPrefix: String,
        onProgress: (DownloadProgress) -> Unit
    ): Pair<PartialDownloadEntity, Long> {
        var activePartial = partial
        var currentTotalHint = knownTotalBytesHint
        var refreshedAudioHint = -1L
        var lastError: Exception? = null

        for (refreshAttempt in 0..MAX_URL_REFRESH_ATTEMPTS) {
            val urlToFetch = if (isAudioPhase) {
                activePartial.audioStreamUrl ?: throw IOException("رابط المسار الصوتي غير متوفر")
            } else {
                activePartial.downloadUrl
            }

            try {
                val updated = downloadFileChunkedWithAutoRetry(
                    partial = activePartial,
                    url = urlToFetch,
                    targetFile = targetFile,
                    knownTotalBytesHint = currentTotalHint,
                    userAgent = activePartial.customUserAgent ?: userAgent,
                    progressStart = progressStart,
                    progressEnd = progressEnd,
                    statusPrefix = statusPrefix,
                    onProgress = onProgress
                )
                return updated to refreshedAudioHint
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                Log.w(
                    "VideoDownloadRepo",
                    "Download stalled/failed (refreshAttempt=$refreshAttempt/$MAX_URL_REFRESH_ATTEMPTS): ${e.message}"
                )
                if (refreshAttempt >= MAX_URL_REFRESH_ATTEMPTS) break

                // Wait briefly before re-extracting a fresh CDN URL
                delay(600L * (refreshAttempt + 1))

                val extractedResult = videoExtractor.extract(activePartial.sourceUrl)
                val refreshed = extractedResult.getOrNull() ?: continue

                val matchingOption = refreshed.downloadOptions.find { opt ->
                    opt.quality == activePartial.qualityLabel &&
                        opt.isAudioOnly == activePartial.isAudio &&
                        opt.isImageOnly == activePartial.isImage
                } ?: refreshed.downloadOptions.firstOrNull { opt ->
                    opt.isAudioOnly == activePartial.isAudio && opt.isImageOnly == activePartial.isImage
                } ?: continue

                val newExpectedSize = if (isAudioPhase) {
                    if (matchingOption.isAudioOnly) matchingOption.expectedSizeBytes else matchingOption.expectedAudioSizeBytes
                } else {
                    matchingOption.expectedSizeBytes
                }

                // If fallback extracted a different encode/size than our partial bytes, reset partial file
                if (newExpectedSize > 0L && currentTotalHint > 0L && kotlin.math.abs(newExpectedSize - currentTotalHint) > 4096L) {
                    if (targetFile.exists()) targetFile.delete()
                    currentTotalHint = newExpectedSize
                } else if (newExpectedSize > 0L && currentTotalHint <= 0L) {
                    currentTotalHint = newExpectedSize
                }

                if (matchingOption.expectedAudioSizeBytes > 0L) {
                    refreshedAudioHint = matchingOption.expectedAudioSizeBytes
                }

                activePartial = activePartial.copy(
                    downloadUrl = matchingOption.downloadUrl,
                    audioStreamUrl = matchingOption.audioStreamUrl ?: activePartial.audioStreamUrl,
                    customUserAgent = matchingOption.customUserAgent ?: activePartial.customUserAgent,
                    totalBytes = currentTotalHint,
                    downloadedBytes = if (targetFile.exists()) targetFile.length() else 0L,
                    updatedAt = System.currentTimeMillis()
                )
                try {
                    partialDownloadDao.upsert(activePartial)
                } catch (_: Exception) {
                }
            }
        }

        throw lastError ?: IOException("انقطع الاتصال بالشبكة أثناء التحميل")
    }

    /**
     * Streams large files (especially YouTube googlevideo.com streams) in bounded 4 MB Range chunks
     * so YouTube CDN serves at full burst speed instead of throttling/resetting long open-ended connections.
     * Falls back cleanly to single GET when the origin server does not support Range requests.
     */
    private suspend fun downloadFileChunkedWithAutoRetry(
        partial: PartialDownloadEntity,
        url: String,
        targetFile: File,
        knownTotalBytesHint: Long,
        userAgent: String,
        progressStart: Float,
        progressEnd: Float,
        statusPrefix: String,
        onProgress: (DownloadProgress) -> Unit
    ): PartialDownloadEntity {
        var activePartial = partial
        var knownTotalBytes = knownTotalBytesHint.takeIf { it > 0L }
            ?: activePartial.totalBytes.takeIf { it > 0L }
            ?: -1L
        var forceFreshSocket = false
        var restartedOnceFor416 = false

        val cleanUa = userAgent.filter { it.code in 0x20..0x7E }.ifBlank { defaultUserAgent }
        val referer = if (url.contains("googlevideo.com") || url.contains("cdninstagram.com")) {
            null
        } else {
            activePartial.sourceUrl.filter { it.code in 0x20..0x7E }.takeIf { it.startsWith("http") }
        }

        val sessionStartTime = System.currentTimeMillis()
        var sessionBytesTransferred = 0L
        var lastUiUpdate = 0L
        var lastDbPersist = if (targetFile.exists()) targetFile.length() else 0L

        while (true) {
            val currentOffset = if (targetFile.exists()) targetFile.length() else 0L
            if (knownTotalBytes > 0L && currentOffset >= knownTotalBytes) {
                activePartial = activePartial.copy(
                    downloadedBytes = currentOffset,
                    totalBytes = knownTotalBytes,
                    updatedAt = System.currentTimeMillis()
                )
                partialDownloadDao.upsert(activePartial)
                return activePartial
            }

            // Use bounded 4 MB chunk requests when resuming, streaming from googlevideo, or downloading > 4 MB / unknown-size streams
            val useBoundedChunk = url.contains("googlevideo.com") ||
                currentOffset > 0L ||
                knownTotalBytes <= 0L ||
                knownTotalBytes > CHUNK_SIZE_BYTES

            var chunkCompletedOrStreamDone = false
            var chunkError: Exception? = null

            for (attempt in 1..MAX_CHUNK_RETRIES) {
                try {
                    val attemptOffset = if (targetFile.exists()) targetFile.length() else 0L
                    if (knownTotalBytes > 0L && attemptOffset >= knownTotalBytes) {
                        chunkCompletedOrStreamDone = true
                        break
                    }

                    val reqBuilder = Request.Builder()
                        .url(url)
                        .header("User-Agent", cleanUa)
                        .header("Accept", "*/*")
                    if (!referer.isNullOrBlank()) {
                        reqBuilder.header("Referer", referer)
                    }
                    if (forceFreshSocket || attempt > 1) {
                        reqBuilder.header("Connection", "close")
                        forceFreshSocket = false
                    }

                    val requestedRangeEnd: Long
                    if (useBoundedChunk) {
                        requestedRangeEnd = if (knownTotalBytes > 0L) {
                            minOf(attemptOffset + CHUNK_SIZE_BYTES - 1L, knownTotalBytes - 1L)
                        } else {
                            attemptOffset + CHUNK_SIZE_BYTES - 1L
                        }
                        reqBuilder.header("Range", "bytes=$attemptOffset-$requestedRangeEnd")
                    } else {
                        requestedRangeEnd = -1L
                    }

                    httpClient.newCall(reqBuilder.build()).execute().use { response ->
                        val code = response.code

                        if (code == 416) {
                            val totalFrom416 = parseTotalFromContentRange(response.header("Content-Range"))
                            if (totalFrom416 != null && totalFrom416 > 0L) {
                                knownTotalBytes = totalFrom416
                                if (attemptOffset >= totalFrom416) {
                                    chunkCompletedOrStreamDone = true
                                    return@use
                                }
                            } else if (knownTotalBytes > 0L && attemptOffset >= knownTotalBytes) {
                                chunkCompletedOrStreamDone = true
                                return@use
                            }
                            if (!restartedOnceFor416) {
                                restartedOnceFor416 = true
                                if (targetFile.exists()) targetFile.delete()
                                chunkCompletedOrStreamDone = false
                                return@use
                            }
                            throw IOException("نطاق التحميل غير صالح (416)")
                        }

                        if (code == 403 || code == 410 || code == 401) {
                            throw ExpiredStreamUrlException(code)
                        }

                        if (!response.isSuccessful && code != 206) {
                            throw IOException("استجابة الخادم غير ناجحة: $code")
                        }

                        val body = response.body ?: throw IOException("محتوى ملف التحميل فارغ")
                        val isPartialContent = code == 206
                        val contentLength = body.contentLength()
                        val serverAcceptsRanges = isPartialContent ||
                            response.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true

                        if (isPartialContent) {
                            val crTotal = parseTotalFromContentRange(response.header("Content-Range"))
                            if (crTotal != null && crTotal > 0L) {
                                knownTotalBytes = crTotal
                            } else if (knownTotalBytes <= 0L && contentLength > 0L) {
                                // Only if entire remaining was sent (non-bounded), fallback carefully
                                val guessed = attemptOffset + contentLength
                                if (!useBoundedChunk || contentLength < CHUNK_SIZE_BYTES) {
                                    knownTotalBytes = guessed
                                }
                            }
                        } else {
                            // Server sent 200 OK (full representation from byte 0)
                            if (contentLength > 0L) {
                                knownTotalBytes = contentLength
                            }
                        }

                        val appendMode = isPartialContent && attemptOffset > 0L
                        var downloadedBytes = if (appendMode) attemptOffset else 0L

                        activePartial = activePartial.copy(
                            downloadedBytes = downloadedBytes,
                            totalBytes = knownTotalBytes,
                            updatedAt = System.currentTimeMillis()
                        )
                        partialDownloadDao.upsert(activePartial)

                        val buffer = ByteArray(65536)
                        var bytesWrittenThisCall = 0L

                        FileOutputStream(targetFile, appendMode).use { out ->
                            body.byteStream().use { input ->
                                var bytesRead: Int
                                while (input.read(buffer).also { bytesRead = it } != -1) {
                                    out.write(buffer, 0, bytesRead)
                                    downloadedBytes += bytesRead
                                    bytesWrittenThisCall += bytesRead
                                    sessionBytesTransferred += bytesRead

                                    val now = System.currentTimeMillis()
                                    if (now - lastUiUpdate > 140) {
                                        lastUiUpdate = now
                                        val elapsedSec = ((now - sessionStartTime) / 1000f).coerceAtLeast(0.01f)
                                        val speedKbps = ((sessionBytesTransferred / 1024f) / elapsedSec).toLong()
                                        val subProgress = if (knownTotalBytes > 0L) {
                                            (downloadedBytes.toFloat() / knownTotalBytes.toFloat()).coerceIn(0f, 1f)
                                        } else {
                                            0.5f
                                        }
                                        val overall = progressStart + (progressEnd - progressStart) * subProgress
                                        onProgress(
                                            DownloadProgress(
                                                percentage = overall,
                                                downloadedBytes = downloadedBytes,
                                                totalBytes = knownTotalBytes,
                                                speedKbps = speedKbps,
                                                statusText = "$statusPrefix... ${(overall * 100).toInt()}%"
                                            )
                                        )
                                    }

                                    if (downloadedBytes - lastDbPersist >= 524_288L) {
                                        lastDbPersist = downloadedBytes
                                        activePartial = activePartial.copy(
                                            downloadedBytes = downloadedBytes,
                                            totalBytes = knownTotalBytes,
                                            updatedAt = now
                                        )
                                        partialDownloadDao.upsert(activePartial)
                                    }
                                }
                                out.flush()
                            }
                        }

                        // Persist exact file size at end of chunk
                        val diskSize = targetFile.length()
                        lastDbPersist = diskSize
                        activePartial = activePartial.copy(
                            downloadedBytes = diskSize,
                            totalBytes = knownTotalBytes,
                            updatedAt = System.currentTimeMillis()
                        )
                        partialDownloadDao.upsert(activePartial)

                        // Decide whether the whole file is done or another chunk is needed
                        if (!isPartialContent) {
                            // 200 OK full stream ended
                            if (knownTotalBytes > 0L && diskSize < knownTotalBytes) {
                                if (serverAcceptsRanges) {
                                    chunkCompletedOrStreamDone = true
                                    return@use
                                }
                                throw IOException("انقطع البث عند $diskSize من $knownTotalBytes")
                            }
                            if (knownTotalBytes <= 0L) {
                                knownTotalBytes = diskSize
                            }
                            chunkCompletedOrStreamDone = true
                        } else {
                            // 206 Partial Content chunk finished
                            if (knownTotalBytes > 0L && diskSize >= knownTotalBytes) {
                                chunkCompletedOrStreamDone = true
                            } else if (bytesWrittenThisCall == 0L) {
                                // Empty 206 body with knownTotalBytes == -1 indicates end of file
                                if (knownTotalBytes <= 0L && diskSize > 0L) {
                                    knownTotalBytes = diskSize
                                }
                                chunkCompletedOrStreamDone = true
                            } else if (knownTotalBytes <= 0L && useBoundedChunk && bytesWrittenThisCall < CHUNK_SIZE_BYTES) {
                                // Server had no Content-Range total and sent fewer bytes than requested -> EOF reached
                                knownTotalBytes = diskSize
                                chunkCompletedOrStreamDone = true
                            } else {
                                // More chunks remaining! Move to next chunk cleanly.
                                chunkCompletedOrStreamDone = true
                            }
                        }
                    }

                    if (chunkCompletedOrStreamDone) {
                        break
                    }
                } catch (e: ExpiredStreamUrlException) {
                    throw e
                } catch (e: CancellationException) {
                    throw e
                } catch (e: IOException) {
                    chunkError = e
                    forceFreshSocket = true
                    Log.w("VideoDownloadRepo", "Chunk interrupted (attempt $attempt/$MAX_CHUNK_RETRIES): ${e.message}")
                    if (attempt < MAX_CHUNK_RETRIES) {
                        delay(500L * attempt)
                    }
                }
            }

            if (!chunkCompletedOrStreamDone) {
                throw chunkError ?: IOException("انقطع الاتصال بالشبكة أثناء التحميل")
            }

            val updatedOffset = if (targetFile.exists()) targetFile.length() else 0L
            if (knownTotalBytes > 0L && updatedOffset >= knownTotalBytes) {
                activePartial = activePartial.copy(
                    downloadedBytes = updatedOffset,
                    totalBytes = knownTotalBytes,
                    updatedAt = System.currentTimeMillis()
                )
                partialDownloadDao.upsert(activePartial)
                return activePartial
            }
        }
    }

    private fun parseTotalFromContentRange(header: String?): Long? {
        if (header.isNullOrBlank()) return null
        val slashPart = header.substringAfter("/", "").trim()
        return slashPart.toLongOrNull()
    }

    private fun muxVideoAndAudio(videoFile: File, audioFile: File, outputFile: File) {
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            audioExtractor.setDataSource(audioFile.absolutePath)

            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    videoFormat = fmt
                    break
                }
            }

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until audioExtractor.trackCount) {
                val fmt = audioExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }

            if (videoTrackIndex == -1 || videoFormat == null) {
                throw Exception("تعذر قراءة مسار الفيديو للدمج")
            }

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerVideoTrack = muxer.addTrack(videoFormat)
            val muxerAudioTrack = if (audioTrackIndex != -1 && audioFormat != null) {
                muxer.addTrack(audioFormat)
            } else {
                -1
            }

            muxer.start()

            val buffer = ByteBuffer.allocate(1024 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            videoExtractor.selectTrack(videoTrackIndex)
            while (true) {
                val sampleSize = videoExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = videoExtractor.sampleTime
                bufferInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
                videoExtractor.advance()
            }

            if (muxerAudioTrack != -1) {
                audioExtractor.selectTrack(audioTrackIndex)
                while (true) {
                    val sampleSize = audioExtractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = audioExtractor.sampleTime
                    bufferInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    audioExtractor.advance()
                }
            }
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
            try {
                videoExtractor.release()
            } catch (_: Exception) {
            }
            try {
                audioExtractor.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun saveLocalFileToMediaStore(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean,
        isImageOnly: Boolean
    ): String {
        FileInputStream(sourceFile).use { input ->
            return writeStreamToGallery(
                context = context,
                inputStream = input,
                fileName = fileName,
                mimeType = mimeType,
                isAudioOnly = isAudioOnly,
                isImageOnly = isImageOnly
            )
        }
    }

    private fun writeStreamToGallery(
        context: Context,
        inputStream: InputStream,
        fileName: String,
        mimeType: String,
        isAudioOnly: Boolean,
        isImageOnly: Boolean
    ): String {
        val buffer = ByteArray(65536)
        var bytesRead: Int

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativeFolder = when {
                isImageOnly -> "${Environment.DIRECTORY_PICTURES}/VideoDownloader"
                isAudioOnly -> "${Environment.DIRECTORY_MUSIC}/VideoDownloader"
                else -> "${Environment.DIRECTORY_MOVIES}/VideoDownloader"
            }

            val collection = when {
                isImageOnly -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                isAudioOnly -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val contentUri = context.contentResolver.insert(collection, values)
                ?: throw Exception("تعذر إنشاء مسار في استوديو الهاتف")

            try {
                val outputStream: OutputStream = context.contentResolver.openOutputStream(contentUri)
                    ?: throw Exception("تعذر فتح ملف الكتابة في استوديو الهاتف")

                outputStream.use { out ->
                    inputStream.use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                        }
                        out.flush()
                    }
                }

                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(contentUri, values, null, null)

                return contentUri.toString()
            } catch (e: Exception) {
                try {
                    context.contentResolver.delete(contentUri, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val publicDir = Environment.getExternalStoragePublicDirectory(
                when {
                    isImageOnly -> Environment.DIRECTORY_PICTURES
                    isAudioOnly -> Environment.DIRECTORY_MUSIC
                    else -> Environment.DIRECTORY_MOVIES
                }
            )
            val targetDir = File(publicDir, "VideoDownloader")
            if (!targetDir.exists()) targetDir.mkdirs()

            val targetFile = File(targetDir, fileName)
            FileOutputStream(targetFile).use { out ->
                inputStream.use { input ->
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                    }
                    out.flush()
                }
            }

            MediaScannerConnection.scanFile(
                context,
                arrayOf(targetFile.absolutePath),
                arrayOf(mimeType),
                null
            )

            return targetFile.absolutePath
        }
    }

    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            if (entity.localFilePath.startsWith("content://")) {
                val uri = Uri.parse(entity.localFilePath)
                context.contentResolver.delete(uri, null, null)
            } else {
                val file = File(entity.localFilePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            downloadDao.deleteById(entity.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete file", e)
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                if (!file.exists()) return
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }

            val mimeType = when {
                entity.isImage -> "image/*"
                entity.isAudio -> "audio/*"
                else -> "video/*"
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, entity.title)
                putExtra(Intent.EXTRA_TEXT, "تم التحميل بواسطة تطبيق محمل الفيديوهات")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة الملف عبر")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Share failed", e)
        }
    }

    fun openInPhoneGallery(context: Context, entity: DownloadEntity) {
        try {
            val uri: Uri = if (entity.localFilePath.startsWith("content://")) {
                Uri.parse(entity.localFilePath)
            } else {
                val file = File(entity.localFilePath)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }

            val mimeType = when {
                entity.isImage -> "image/*"
                entity.isAudio -> "audio/*"
                else -> "video/*"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Open in gallery failed", e)
        }
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024f * 1024f)
        return if (mb >= 1f) "${String.format(Locale.US, "%.1f", mb)} MB" else "${bytes / 1024} KB"
    }
}
