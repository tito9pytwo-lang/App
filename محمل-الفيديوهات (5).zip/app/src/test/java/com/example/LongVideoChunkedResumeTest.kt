package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.ExtractedVideo
import com.example.data.model.PlatformType
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.VideoExtractor
import com.example.data.repository.VideoDownloadRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.ServerSocket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LongVideoChunkedResumeTest {

    private lateinit var serverSocket: ServerSocket
    private var port: Int = 0
    private val totalSize = 9 * 1024 * 1024 // 9 MB -> forces 3 bounded 4 MB chunks (4MB + 4MB + 1MB)
    private val payload = ByteArray(totalSize) { idx -> (idx % 251).toByte() }
    private val observedRangeHeaders = CopyOnWriteArrayList<String>()
    private val chunk1ResetOnce = AtomicInteger(0)
    private val allowFreshUrl = AtomicInteger(0)

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        runBlocking(kotlinx.coroutines.Dispatchers.IO) {
            AppDatabase.getDatabase(context).clearAllTables()
        }

        serverSocket = ServerSocket(0)
        port = serverSocket.localPort
        thread(isDaemon = true) {
            while (!serverSocket.isClosed) {
                try {
                    val socket = serverSocket.accept()
                    thread(isDaemon = true) {
                        socket.use { s ->
                            val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                            val reqLine = reader.readLine() ?: return@use
                            val headers = mutableMapOf<String, String>()
                            while (true) {
                                val line = reader.readLine() ?: break
                                if (line.isEmpty()) break
                                val idx = line.indexOf(':')
                                if (idx > 0) {
                                    headers[line.substring(0, idx).trim().lowercase()] =
                                        line.substring(idx + 1).trim()
                                }
                            }
                            val path = reqLine.split(" ").getOrNull(1) ?: "/"
                            val out = s.getOutputStream()

                            if (path.startsWith("/watch_long")) {
                                val freshUrl = "http://127.0.0.1:$port/fresh_stream.mp4"
                                val html = """
                                    <html><head>
                                    <meta property="og:title" content="Long 1H YouTube Sim" />
                                    </head><body>
                                    <script>{"playable_url":"$freshUrl"}</script>
                                    </body></html>
                                """.trimIndent().toByteArray()
                                out.write("HTTP/1.1 200 OK\r\nConnection: close\r\nContent-Type: text/html\r\nContent-Length: ${html.size}\r\n\r\n".toByteArray())
                                out.write(html)
                                out.flush()
                                return@use
                            }

                            if (path.startsWith("/old_stream.mp4") && allowFreshUrl.get() == 0) {
                                val range = headers["range"] ?: ""
                                observedRangeHeaders.add(range)
                                val parsed = parseRange(range, totalSize)
                                val start = parsed.first
                                val end = parsed.second
                                // Once download starts (> 1 MB), simulate 403 expiry on chunk 2 so repo must re-extract!
                                if (start >= 4 * 1024 * 1024) {
                                    allowFreshUrl.set(1)
                                    out.write("HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
                                    out.flush()
                                    return@use
                                }
                                val sliceLen = (end - start + 1).toInt()
                                out.write(
                                    ("HTTP/1.1 206 Partial Content\r\nConnection: close\r\n" +
                                        "Content-Type: video/mp4\r\nAccept-Ranges: bytes\r\n" +
                                        "Content-Range: bytes $start-$end/$totalSize\r\n" +
                                        "Content-Length: $sliceLen\r\n\r\n").toByteArray()
                                )
                                // Drop connection midway on first chunk attempt to test exact mid-chunk recovery!
                                if (start == 0L && chunk1ResetOnce.getAndIncrement() == 0) {
                                    out.write(payload, 0, 1_500_000)
                                    out.flush()
                                    return@use
                                }
                                out.write(payload, start.toInt(), sliceLen)
                                out.flush()
                                return@use
                            }

                            if (path.startsWith("/fresh_stream.mp4") || path.startsWith("/old_stream.mp4")) {
                                val range = headers["range"] ?: ""
                                observedRangeHeaders.add(range)
                                val (start, end) = parseRange(range, totalSize)
                                val sliceLen = (end - start + 1).toInt()
                                out.write(
                                    ("HTTP/1.1 206 Partial Content\r\nConnection: close\r\n" +
                                        "Content-Type: video/mp4\r\nAccept-Ranges: bytes\r\n" +
                                        "Content-Range: bytes $start-$end/$totalSize\r\n" +
                                        "Content-Length: $sliceLen\r\n\r\n").toByteArray()
                                )
                                out.write(payload, start.toInt(), sliceLen)
                                out.flush()
                                return@use
                            }

                            out.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\nContent-Length: 0\r\n\r\n".toByteArray())
                            out.flush()
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun parseRange(rangeHeader: String, total: Int): Pair<Long, Long> {
        if (!rangeHeader.startsWith("bytes=")) return 0L to (total - 1L)
        val parts = rangeHeader.removePrefix("bytes=").split("-")
        val start = parts[0].toLongOrNull() ?: 0L
        val end = parts.getOrNull(1)?.toLongOrNull()?.coerceAtMost(total - 1L) ?: (total - 1L)
        return start to end
    }

    @After
    fun tearDown() {
        try {
            serverSocket.close()
        } catch (_: Exception) {
        }
    }

    @Test
    fun `chunked download recovers from mid-chunk drop and 403 URL expiration automatically`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)
        val repo = VideoDownloadRepository(db.downloadDao(), db.partialDownloadDao(), VideoExtractor())

        val sourceUrl = "http://127.0.0.1:$port/watch_long?facebook.com=1"
        val video = ExtractedVideo(
            originalUrl = sourceUrl,
            title = "Long 1 Hour Video Test",
            platform = PlatformType.FACEBOOK,
            downloadOptions = listOf(
                VideoDownloadOption(
                    id = "fb_sd",
                    label = "HD",
                    description = "Test",
                    quality = "HD",
                    downloadUrl = "http://127.0.0.1:$port/old_stream.mp4",
                    expectedSizeBytes = totalSize.toLong()
                )
            )
        )

        val result = repo.downloadAndSave(context, video, video.downloadOptions.first()) {}
        assertTrue("Expected recovery to succeed, got: ${result.exceptionOrNull()?.message}", result.isSuccess)
        val saved = result.getOrThrow()
        assertEquals(totalSize.toLong(), saved.fileSizeBytes)

        // Verify all Range requests were bounded (never open-ended "bytes=X-")
        assertTrue("Expected multiple chunk Range requests", observedRangeHeaders.size >= 3)
        assertTrue(
            "Every Range header must specify explicit end byte, got: $observedRangeHeaders",
            observedRangeHeaders.all { Regex("^bytes=\\d+-\\d+$").matches(it) }
        )

        val bytes1 = readSavedBytes(context, saved.localFilePath)
        assertEquals(totalSize, bytes1.size)
    }

    private fun readSavedBytes(context: Context, localFilePath: String): ByteArray {
        return if (localFilePath.startsWith("content://")) {
            context.contentResolver.openInputStream(android.net.Uri.parse(localFilePath))!!.use { it.readBytes() }
        } else {
            File(localFilePath).readBytes()
        }
    }

    @Test
    fun `resumeDownload completes cleanly after interruption even when old URL returns 403`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)
        val repo = VideoDownloadRepository(db.downloadDao(), db.partialDownloadDao(), VideoExtractor())

        allowFreshUrl.set(0)
        val partialDir = File(context.filesDir, "partial_downloads").apply { mkdirs() }
        val partFile = File(partialDir, "resume_9mb.mp4")
        // Pre-write exact first 4.5 MB (simulating interrupted long download)
        val initialBytes = 4_500_000
        partFile.writeBytes(payload.copyOfRange(0, initialBytes))

        val partialId = db.partialDownloadDao().upsert(
            com.example.data.local.PartialDownloadEntity(
                title = "Resumed 1H Video",
                sourceUrl = "http://127.0.0.1:$port/watch_long?facebook.com=1",
                downloadUrl = "http://127.0.0.1:$port/old_stream.mp4",
                platform = "FACEBOOK",
                qualityLabel = "HD",
                videoPartPath = partFile.absolutePath,
                downloadedBytes = initialBytes.toLong(),
                totalBytes = totalSize.toLong(),
                phase = "VIDEO"
            )
        )

        val partial = db.partialDownloadDao().getById(partialId)!!
        val res = repo.resumeDownload(context, partial) {}
        assertTrue("Resume should succeed after 403 refresh: ${res.exceptionOrNull()?.message}", res.isSuccess)
        val saved = res.getOrThrow()
        assertEquals(totalSize.toLong(), saved.fileSizeBytes)
        val bytesOnDisk = readSavedBytes(context, saved.localFilePath)
        assertEquals(totalSize, bytesOnDisk.size)
        assertEquals(payload[0], bytesOnDisk[0])
        assertEquals(payload[initialBytes], bytesOnDisk[initialBytes])
        assertEquals(payload[totalSize - 1], bytesOnDisk[totalSize - 1])
    }
}
