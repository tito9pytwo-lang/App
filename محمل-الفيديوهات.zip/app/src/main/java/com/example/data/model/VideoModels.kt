package com.example.data.model

enum class PlatformType(val displayName: String) {
    TIKTOK("تيك توك"),
    FACEBOOK("فيسبوك"),
    OTHER("فيديو مباشر")
}

data class VideoDownloadOption(
    val id: String,
    val label: String,
    val description: String,
    val quality: String,
    val downloadUrl: String,
    val isAudioOnly: Boolean = false,
    val isNoWatermark: Boolean = false
)

data class ExtractedVideo(
    val originalUrl: String,
    val title: String,
    val authorName: String? = null,
    val authorAvatar: String? = null,
    val coverUrl: String? = null,
    val durationSeconds: Int = 0,
    val platform: PlatformType,
    val downloadOptions: List<VideoDownloadOption> = emptyList()
)

data class DownloadProgress(
    val percentage: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val speedKbps: Long = 0L,
    val statusText: String = ""
)
