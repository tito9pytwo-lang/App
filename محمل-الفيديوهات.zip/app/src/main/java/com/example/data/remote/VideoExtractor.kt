package com.example.data.remote

import android.util.Log
import com.example.data.model.ExtractedVideo
import com.example.data.model.PlatformType
import com.example.data.model.VideoDownloadOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class VideoExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

    suspend fun extract(inputUrl: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = cleanUrl(inputUrl)
            if (cleanUrl.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("يرجى إدخال رابط صالح"))
            }

            val platform = detectPlatform(cleanUrl)
            when (platform) {
                PlatformType.TIKTOK -> extractTikTok(cleanUrl)
                PlatformType.FACEBOOK -> extractFacebook(cleanUrl)
                PlatformType.OTHER -> extractDirectOrGeneric(cleanUrl)
            }
        } catch (e: Exception) {
            Log.e("VideoExtractor", "Error extracting video", e)
            Result.failure(Exception(e.message ?: "تعذر استخراج بيانات الفيديو، يرجى التأكد من أن الفيديو عام والرابط صالح."))
        }
    }

    private fun detectPlatform(url: String): PlatformType {
        val lower = url.lowercase()
        return when {
            lower.contains("tiktok.com") || lower.contains("douyin.com") -> PlatformType.TIKTOK
            lower.contains("facebook.com") || lower.contains("fb.watch") || lower.contains("fb.com") -> PlatformType.FACEBOOK
            else -> PlatformType.OTHER
        }
    }

    private fun cleanUrl(input: String): String {
        val trimmed = input.trim()
        val matcher = Pattern.compile("https?://[^\\s]+").matcher(trimmed)
        return if (matcher.find()) {
            matcher.group(0) ?: ""
        } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            ""
        }
    }

    private suspend fun extractTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(url, "UTF-8")
            val apiUrl = "https://www.tikwm.com/api/?url=$encoded&count=12&cursor=0&web=1&hd=1"

            val request = Request.Builder()
                .url(apiUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful && body.isNotEmpty()) {
                val json = JSONObject(body)
                val code = json.optInt("code", -1)
                if (code == 0 && json.has("data")) {
                    val data = json.getJSONObject("data")
                    val title = data.optString("title", "فيديو تيك توك").ifBlank { "فيديو تيك توك" }
                    val cover = data.optString("cover")
                    val duration = data.optInt("duration", 0)

                    val author = data.optJSONObject("author")
                    val authorName = author?.optString("nickname") ?: author?.optString("unique_id") ?: "مستخدم تيك توك"
                    val authorAvatar = author?.optString("avatar")

                    val options = mutableListOf<VideoDownloadOption>()

                    // 1. No watermark (Play)
                    val playUrl = data.optString("play")
                    if (playUrl.isNotEmpty()) {
                        val fixedUrl = if (playUrl.startsWith("http")) playUrl else "https://www.tikwm.com$playUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_nowm",
                                label = "بدون علامة مائية (سريع)",
                                description = "أفضل جودة مع إزالة شعار تيك توك",
                                quality = "HD بدون علامة",
                                downloadUrl = fixedUrl,
                                isNoWatermark = true
                            )
                        )
                    }

                    // 2. HD No Watermark if present
                    val hdUrl = data.optString("hdplay")
                    if (hdUrl.isNotEmpty()) {
                        val fixedHd = if (hdUrl.startsWith("http")) hdUrl else "https://www.tikwm.com$hdUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_hd",
                                label = "جودة فائقة Ultra HD",
                                description = "أعلى دقة متوفرة بدون علامة",
                                quality = "Full HD",
                                downloadUrl = fixedHd,
                                isNoWatermark = true
                            )
                        )
                    }

                    // 3. Watermark version
                    val wmUrl = data.optString("wmplay")
                    if (wmUrl.isNotEmpty()) {
                        val fixedWm = if (wmUrl.startsWith("http")) wmUrl else "https://www.tikwm.com$wmUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_wm",
                                label = "بالعلامة المائية الأصلية",
                                description = "النسخة الأصلية مع حقوق الناشر",
                                quality = "Original",
                                downloadUrl = fixedWm,
                                isNoWatermark = false
                            )
                        )
                    }

                    // 4. Audio (Music)
                    val musicUrl = data.optString("music")
                    if (musicUrl.isNotEmpty()) {
                        val fixedMusic = if (musicUrl.startsWith("http")) musicUrl else "https://www.tikwm.com$musicUrl"
                        options.add(
                            VideoDownloadOption(
                                id = "tt_audio",
                                label = "تحميل الصوت فقط (MP3)",
                                description = "الموسيقى أو الصوت المستخدم في الفيديو",
                                quality = "صوت MP3",
                                downloadUrl = fixedMusic,
                                isAudioOnly = true
                            )
                        )
                    }

                    if (options.isNotEmpty()) {
                        return@withContext Result.success(
                            ExtractedVideo(
                                originalUrl = url,
                                title = title,
                                authorName = authorName,
                                authorAvatar = authorAvatar,
                                coverUrl = cover,
                                durationSeconds = duration,
                                platform = PlatformType.TIKTOK,
                                downloadOptions = options
                            )
                        )
                    }
                }
            }

            // Fallback for TikTok direct extraction
            fallbackTikTok(url)
        } catch (e: Exception) {
            fallbackTikTok(url)
        }
    }

    private suspend fun fallbackTikTok(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            // Direct request to fetch HTML and extract canonical tags
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()
            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title") ?: "فيديو تيك توك"
            val image = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                val option = VideoDownloadOption(
                    id = "tt_fallback",
                    label = "تنزيل مباشر",
                    description = "جودة الفيديو الأساسية",
                    quality = "Standard",
                    downloadUrl = videoUrl
                )
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = title,
                        coverUrl = image,
                        platform = PlatformType.TIKTOK,
                        downloadOptions = listOf(option)
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من تيك توك، يرجى التأكد من الرابط."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("فشل الاتصال بخدمة التحليل: ${e.localizedMessage}"))
        }
    }

    private suspend fun extractFacebook(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title")
                ?: extractMetaTag(html, "twitter:title")
                ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
                ?: extractMetaTag(html, "twitter:image")

            val options = mutableListOf<VideoDownloadOption>()

            // Extract HD link: "playable_url_quality_hd":"..." or "browser_native_hd_url":"..." or hd_src:"..."
            val hdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url_quality_hd\":\"([^\"]+)\"",
                "\"browser_native_hd_url\":\"([^\"]+)\"",
                "hd_src:\"([^\"]+)\"",
                "hd_src_no_ratelimit:\"([^\"]+)\""
            ))

            // Extract SD link: "playable_url":"..." or "browser_native_sd_url":"..." or sd_src:"..."
            val sdUrl = findFacebookVideoUrl(html, listOf(
                "\"playable_url\":\"([^\"]+)\"",
                "\"browser_native_sd_url\":\"([^\"]+)\"",
                "sd_src:\"([^\"]+)\"",
                "sd_src_no_ratelimit:\"([^\"]+)\""
            ))

            val ogVideo = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!hdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_hd",
                        label = "جودة عالية HD",
                        description = "دقة عالية 720p/1080p",
                        quality = "HD 720p/1080p",
                        downloadUrl = decodeFacebookUrl(hdUrl)
                    )
                )
            }

            if (!sdUrl.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_sd",
                        label = "جودة قياسية SD",
                        description = "حجم أصغر وتنزيل أسرع",
                        quality = "SD 360p/480p",
                        downloadUrl = decodeFacebookUrl(sdUrl)
                    )
                )
            }

            if (options.isEmpty() && !ogVideo.isNullOrEmpty()) {
                options.add(
                    VideoDownloadOption(
                        id = "fb_og",
                        label = "تنزيل بجودة قياسية",
                        description = "فيديو فيسبوك المتاح",
                        quality = "Standard",
                        downloadUrl = decodeFacebookUrl(ogVideo)
                    )
                )
            }

            if (options.isNotEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = options
                    )
                )
            } else {
                // Secondary fallback using mobile web view parser
                extractFacebookMobile(url)
            }
        } catch (e: Exception) {
            extractFacebookMobile(url)
        }
    }

    private suspend fun extractFacebookMobile(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val mobileUrl = url.replace("www.facebook.com", "m.facebook.com")
            val req = Request.Builder()
                .url(mobileUrl)
                .header("User-Agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1")
                .build()

            val resp = client.newCall(req).execute()
            val html = resp.body?.string() ?: ""

            val title = extractMetaTag(html, "og:title") ?: "فيديو فيسبوك"
            val cover = extractMetaTag(html, "og:image")
            val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

            if (!videoUrl.isNullOrEmpty()) {
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = cleanTitle(title),
                        authorName = "فيسبوك",
                        coverUrl = cover,
                        platform = PlatformType.FACEBOOK,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "fb_mob",
                                label = "تحميل فيديو فيسبوك",
                                description = "الجودة المتاحة",
                                quality = "HD/SD",
                                downloadUrl = decodeFacebookUrl(videoUrl)
                            )
                        )
                    )
                )
            } else {
                Result.failure(Exception("تعذر استخراج الفيديو من فيسبوك. تأكد من أن المنشور عام (Public) وليس خاصاً."))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استخراج فيديو فيسبوك: ${e.localizedMessage}"))
        }
    }

    private suspend fun extractDirectOrGeneric(url: String): Result<ExtractedVideo> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()
            val resp = client.newCall(req).execute()
            val contentType = resp.header("Content-Type") ?: ""

            if (contentType.contains("video") || url.endsWith(".mp4") || url.endsWith(".mov")) {
                val filename = url.substringAfterLast("/").substringBefore("?").ifBlank { "video.mp4" }
                Result.success(
                    ExtractedVideo(
                        originalUrl = url,
                        title = filename,
                        platform = PlatformType.OTHER,
                        downloadOptions = listOf(
                            VideoDownloadOption(
                                id = "generic_mp4",
                                label = "تنزيل مباشر MP4",
                                description = "الملف الأصلي",
                                quality = "Original",
                                downloadUrl = url
                            )
                        )
                    )
                )
            } else {
                val html = resp.body?.string() ?: ""
                val title = extractMetaTag(html, "og:title") ?: "فيديو مباشر"
                val cover = extractMetaTag(html, "og:image")
                val videoUrl = extractMetaTag(html, "og:video") ?: extractMetaTag(html, "og:video:url")

                if (!videoUrl.isNullOrEmpty()) {
                    Result.success(
                        ExtractedVideo(
                            originalUrl = url,
                            title = title,
                            coverUrl = cover,
                            platform = PlatformType.OTHER,
                            downloadOptions = listOf(
                                VideoDownloadOption(
                                    id = "generic_web",
                                    label = "تنزيل الفيديو",
                                    description = "جودة الويب المتاحة",
                                    quality = "Web",
                                    downloadUrl = videoUrl
                                )
                            )
                        )
                    )
                } else {
                    Result.failure(Exception("لم يتم العثور على رابط فيديو في الصفحة. يرجى التأكد من الرابط."))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ أثناء فحص الرابط: ${e.localizedMessage}"))
        }
    }

    private fun findFacebookVideoUrl(html: String, patterns: List<String>): String? {
        for (patternStr in patterns) {
            val matcher = Pattern.compile(patternStr).matcher(html)
            if (matcher.find()) {
                val found = matcher.group(1)
                if (!found.isNullOrBlank()) {
                    return found
                }
            }
        }
        return null
    }

    private fun decodeFacebookUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("&amp;", "&")
    }

    private fun extractMetaTag(html: String, property: String): String? {
        val patterns = listOf(
            Pattern.compile("<meta[^>]+property=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+property=[\"']$property[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("<meta[^>]+name=[\"']$property[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        )
        for (p in patterns) {
            val matcher = p.matcher(html)
            if (matcher.find()) {
                val content = matcher.group(1)
                if (!content.isNullOrBlank()) {
                    return content.replace("&amp;", "&")
                }
            }
        }
        return null
    }

    private fun cleanTitle(title: String): String {
        return title.replace("| Facebook", "")
            .replace("- Facebook", "")
            .trim()
    }
}
