package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.data.model.DownloadProgress
import com.example.data.model.ExtractedVideo
import com.example.data.model.VideoDownloadOption
import com.example.data.remote.VideoExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class VideoDownloadRepository(
    private val downloadDao: DownloadDao,
    private val videoExtractor: VideoExtractor = VideoExtractor()
) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()

    fun getDownloadsByPlatform(platform: String): Flow<List<DownloadEntity>> =
        downloadDao.getDownloadsByPlatform(platform)

    suspend fun extractVideo(url: String): Result<ExtractedVideo> {
        return videoExtractor.extract(url)
    }

    suspend fun downloadAndSave(
        context: Context,
        video: ExtractedVideo,
        option: VideoDownloadOption,
        onProgress: (DownloadProgress) -> Unit
    ): Result<DownloadEntity> = withContext(Dispatchers.IO) {
        try {
            val extension = if (option.isAudioOnly) "mp3" else "mp4"
            val sanitizedTitle = video.title
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .take(50)
                .trim()
                .ifBlank { "video_${System.currentTimeMillis()}" }

            val fileName = "${video.platform.name.lowercase()}_${sanitizedTitle}_${System.currentTimeMillis()}.$extension"

            // Target file in app's movies / downloads directory
            val destinationDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?: context.filesDir
            if (!destinationDir.exists()) {
                destinationDir.mkdirs()
            }
            val targetFile = File(destinationDir, fileName)

            val request = Request.Builder()
                .url(option.downloadUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Referer", video.originalUrl)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("فشل الخادم برمز: ${response.code}"))
            }

            val body = response.body ?: return@withContext Result.failure(Exception("محتوى الملف فارغ"))
            val totalBytes = body.contentLength()
            var downloadedBytes = 0L

            val buffer = ByteArray(8192)
            var bytesRead: Int
            val inputStream: InputStream = body.byteStream()
            val outputStream = FileOutputStream(targetFile)

            val startTime = System.currentTimeMillis()
            var lastUpdate = 0L

            outputStream.use { out ->
                inputStream.use { input ->
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead

                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > 150) { // Throttle UI updates
                            lastUpdate = now
                            val elapsedSec = ((now - startTime) / 1000f).coerceAtLeast(0.01f)
                            val speedKbps = ((downloadedBytes / 1024f) / elapsedSec).toLong()
                            val progress = if (totalBytes > 0) {
                                (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                            } else {
                                0.5f // Indeterminate fallback
                            }

                            onProgress(
                                DownloadProgress(
                                    percentage = progress,
                                    downloadedBytes = downloadedBytes,
                                    totalBytes = totalBytes,
                                    speedKbps = speedKbps,
                                    statusText = "جارٍ التنزيل... ${(progress * 100).toInt()}%"
                                )
                            )
                        }
                    }
                    out.flush()
                }
            }

            // Register in MediaStore so it appears in device Gallery if Android supports it
            registerInMediaStore(context, targetFile, fileName, option.isAudioOnly)

            // Save to Room DB
            val entity = DownloadEntity(
                title = video.title,
                sourceUrl = video.originalUrl,
                downloadUrl = option.downloadUrl,
                localFilePath = targetFile.absolutePath,
                platform = video.platform.name,
                thumbnailUrl = video.coverUrl,
                fileSizeBytes = targetFile.length(),
                durationSeconds = video.durationSeconds,
                downloadTimestamp = System.currentTimeMillis(),
                qualityLabel = option.quality,
                isAudio = option.isAudioOnly
            )

            val newId = downloadDao.insert(entity)
            Result.success(entity.copy(id = newId))
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Download failed", e)
            Result.failure(e)
        }
    }

    private fun registerInMediaStore(context: Context, file: File, displayName: String, isAudio: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val collection = if (isAudio) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }
                val values = ContentValues().apply {
                    put(if (isAudio) MediaStore.Audio.Media.DISPLAY_NAME else MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(if (isAudio) MediaStore.Audio.Media.MIME_TYPE else MediaStore.Video.Media.MIME_TYPE, if (isAudio) "audio/mp3" else "video/mp4")
                    put(if (isAudio) MediaStore.Audio.Media.DATA else MediaStore.Video.Media.DATA, file.absolutePath)
                }
                context.contentResolver.insert(collection, values)
            }
        } catch (e: Exception) {
            Log.w("VideoDownloadRepo", "Could not register file in MediaStore", e)
        }
    }

    suspend fun deleteDownload(context: Context, entity: DownloadEntity) = withContext(Dispatchers.IO) {
        try {
            val file = File(entity.localFilePath)
            if (file.exists()) {
                file.delete()
            }
            downloadDao.deleteById(entity.id)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Failed to delete file", e)
        }
    }

    fun shareVideo(context: Context, entity: DownloadEntity) {
        try {
            val file = File(entity.localFilePath)
            if (!file.exists()) return

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (entity.isAudio) "audio/mp3" else "video/mp4"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, entity.title)
                putExtra(Intent.EXTRA_TEXT, "تم التحميل بواسطة تطبيق محمل الفيديوهات")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة الفيديو عبر")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "Share failed", e)
        }
    }

    fun openInExternalPlayer(context: Context, entity: DownloadEntity) {
        try {
            val file = File(entity.localFilePath)
            if (!file.exists()) return

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (entity.isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloadRepo", "External player launch failed", e)
        }
    }
}
