package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand accents
val TikTokCyan = Color(0xFF00F2FE)
val TikTokPink = Color(0xFFFE2C55)
val FacebookBlue = Color(0xFF1877F2)
val AccentGreen = Color(0xFF10B981)

// Dark Palette
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF161E2E)
val DarkSurfaceVariant = Color(0xFF222F45)
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF031628)
val DarkSecondary = Color(0xFF818CF8)
val DarkTertiary = Color(0xFFF472B6)
val DarkOutline = Color(0xFF334155)

// Light Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightPrimary = Color(0xFF0284C7)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightSecondary = Color(0xFF4F46E5)
val LightTertiary = Color(0xFFDB2777)
val LightOutline = Color(0xFFCBD5E1)
